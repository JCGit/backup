//
//  InAppPurchase.m
//  dxlxxxl
//
//  Created by yunzhong on 16/2/15.
//
//
#import "InAppPurchase.h"
#import "LuaObjectCBridge.h"
#include "scripting/lua-bindings/manual/CCLuaBridge.h"

using namespace cocos2d;
@implementation InAppPurchase

static InAppPurchase* s_inAppP = nullptr;

+ (InAppPurchase*) shared
{
    // dispatch_once will ensure that the method is only called once (thread-safe)
    static dispatch_once_t pred = 0;
    dispatch_once(&pred, ^{
        s_inAppP = [[InAppPurchase alloc] init];
        [s_inAppP initStore];
    });
    return s_inAppP;
}

- (void)initStore
{
    _payHandler = 0;
    
    [[SKPaymentQueue defaultQueue] addTransactionObserver:self];
}

+ (void) buyProduct:(NSDictionary* )dict
{
    int tag = [[dict objectForKey:@"tag"] intValue];
    
    [[InAppPurchase shared] purchaseProduct:tag];
}

+ (void) registerPayHandler:(NSDictionary *)dict
{
    [[InAppPurchase shared] setPayHandler:[[dict objectForKey:@"_payHandler"] intValue]];
}

+ (void) unregisterPayHandler
{
    [[InAppPurchase shared] setPayHandler:0];
}

- (void) setPayHandler:(int)scriptHandler
{
    if (_payHandler)
    {
        LuaBridge::releaseLuaFunctionById(_payHandler);
        _payHandler = 0;
    }
    _payHandler = scriptHandler;
}

- (int) getPayHandler
{
    return _payHandler;
}

- (void) purchaseProduct:(int)tag
{
    if ([SKPaymentQueue canMakePayments]) {

        NSLog(@"---------請求商品信息------------");
        NSArray *product = [[NSArray alloc] initWithObjects:[NSString stringWithFormat:@"%ld",(long)tag],nil];
        NSSet *set = [NSSet setWithArray:product];
        SKProductsRequest *request = [[SKProductsRequest alloc] initWithProductIdentifiers: set];
        request.delegate = self;
        [request start];
        [product release];
        
        [self showLoadingDialog:@"正在支付中，請稍候..."];
    }
    else
    {
        [self showPrompt:@"支付失敗，用戶禁止在遊戲內購買。"];
    }
}

- (void)productsRequest:(SKProductsRequest *)request didReceiveResponse:(SKProductsResponse *)response{
    
    NSArray *myProduct = response.products;
    if (myProduct.count == 0) {
        NSLog(@"無法獲取商品信息，購買失敗。");
        [self removeAlert];
        [self showPrompt:@"無法獲取商品信息，購買失敗。"];
        return;
    }
    SKPayment * payment = [SKPayment paymentWithProduct:myProduct[0]];
    [[SKPaymentQueue defaultQueue] addPayment:payment];
}

- (void)paymentQueue:(SKPaymentQueue *)queue updatedTransactions:(NSArray *)transactions
{
    for(SKPaymentTransaction *transaction in transactions)
    {
        switch (transaction.transactionState)
        {
            case SKPaymentTransactionStatePurchased://交易完成
            {
                [self removeAlert];
                
                [self payCallback2Game:transaction];
                
                // Remove the transaction from the payment queue.
                [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
                break;
            }
                
            case SKPaymentTransactionStateFailed://交易失敗
            {
                [self removeAlert];
                
                NSString * errorMsg = @"订单无法完成";
                switch(transaction.error.code) {
                    case  SKErrorClientInvalid:
                        errorMsg = @"当前苹果账户无法购买商品(如有疑问，可以询问苹果客服)";
                        break;
                    case SKErrorPaymentCancelled:
                        errorMsg = @"订单已取消";
                        break;
                    case SKErrorPaymentNotAllowed:
                        errorMsg = @"当前苹果设备无法购买商品(如有疑问，可以询问苹果客服)";
                        break;
                    case SKErrorPaymentInvalid:
                        errorMsg = @"订单无效(如有疑问，可以询问游戏客服)";
                        break;
                    case SKErrorStoreProductNotAvailable:
                        errorMsg = @"当前商品不可用";
                        break;
                }
                
                [self showPrompt:errorMsg];
                [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
                break;
            }
            case SKPaymentTransactionStateRestored://已經購買過該商品
                
                [self payCallback2Game:transaction];
                
                [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
                break;
            case SKPaymentTransactionStatePurchasing://商品添加進列表
                NSLog(@"商品添加進列表");
                break;
            default:
                break;
        }
    }
}

- (void) payCallback2Game:(SKPaymentTransaction*) transaction
{
    // Your application should implement these two methods.
    NSString *transactionIdentifier = transaction.transactionIdentifier;
    NSString *receipt = [transaction.transactionReceipt base64Encoding];
    
    if ([transactionIdentifier length] > 0) {
        // 向自己的服务器验证购买凭证
        NSLog(@"-----驗證交易--------");
        
        int scriptHandler = [[InAppPurchase shared] getPayHandler];
        if (scriptHandler)
        {
            LuaBridge::pushLuaFunctionById(scriptHandler);
            LuaStack *stack = LuaBridge::getStack();
            
            LuaValueDict item;
            item["productId"] = LuaValue::stringValue([transactionIdentifier UTF8String]);
            item["product"] = LuaValue::stringValue([receipt UTF8String]);
            item["success"] = LuaValue::booleanValue(TRUE);
            LuaBridge::getStack()->pushLuaValueDict(item);
            
            stack->executeFunction(1);
        }
    }
}

- (void) showLoadingDialog:(NSString *)msg
{
    alert = [[UIAlertView alloc] initWithTitle:nil
                                        message:msg
                                       delegate:nil
                              cancelButtonTitle:nil
                              otherButtonTitles:nil];
    
    UIActivityIndicatorView *activityView = [[UIActivityIndicatorView alloc]
                                             initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    if ([[[UIDevice currentDevice] systemVersion] compare:@"7.0"] != NSOrderedAscending) {
        [alert setValue:activityView forKey:@"accessoryView"];
    }else{
        [alert addSubview:activityView];
    }
    [activityView startAnimating];
    [activityView release];
    
    [alert show];
}

- (void) showPrompt:(NSString *)msg
{
    alert =  [[UIAlertView alloc] initWithTitle:nil
                                        message:msg
                                       delegate:nil
                              cancelButtonTitle:@"關閉"
                              otherButtonTitles:nil];
    [alert show];
    [alert release];
}

- (void)removeAlert
{
    if (alert != nil)
    {
        [alert dismissWithClickedButtonIndex:0 animated:YES];
        [alert release];
        alert = nil;
    }
}

- (void)dealloc
{
    [[SKPaymentQueue defaultQueue] removeTransactionObserver:self];
    
    [super dealloc];
}

@end
