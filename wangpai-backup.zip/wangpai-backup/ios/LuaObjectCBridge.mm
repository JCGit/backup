#import "LuaObjectCBridge.h"

#include "cocos2d.h"
#include "scripting/lua-bindings/manual/CCLuaEngine.h"
#include "scripting/lua-bindings/manual/CCLuaBridge.h"

#include "Reachability.h"
#include "Keychain.h"

#include "InAppPurchase.h"

NSString *KEY_PACKAGE_NAME = @"com.yunzhong.wangpai";
NSString *KEY_UUID = @"uuid";

using namespace cocos2d;

@implementation LuaObjectCBridge

static LuaObjectCBridge* s_instance = nil;

+ (LuaObjectCBridge*) getInstance
{
    if (!s_instance)
    {
        s_instance = [LuaObjectCBridge alloc];
        [s_instance init];
    }
    
    return s_instance;
}

+ (void) destroyInstance
{
    [s_instance release];
}

- (void) setNetworkHandler:(int)scriptHandler
{
    if (_networkHandler)
    {
        LuaBridge::releaseLuaFunctionById(_networkHandler);
        _networkHandler = 0;
    }
    _networkHandler = scriptHandler;
}

- (int) getNetworkHandler
{
    return _networkHandler;
}


+(void) registerNetworkStatus:(NSDictionary *)dict
{
    [[LuaObjectCBridge getInstance] setNetworkHandler:[[dict objectForKey:@"_networkHandler"] intValue]];
 
    
    // Allocate a reachability object
    Reachability* reach = [Reachability reachabilityWithHostname:@"www.google.com"];
    
    // Set the blocks
    reach.reachableBlock = ^(Reachability*reach)
    {
        // keep in mind this is called on a background thread
        // and if you are updating the UI it needs to happen
        // on the main thread, like this:
        dispatch_async(dispatch_get_main_queue(), ^{
//            NSLog(@"REACHABLE!", [NSThread mainThread]);
            
            NSString* status = [LuaObjectCBridge getCurrentNetworkType];
            
            int scriptHandler = [[LuaObjectCBridge getInstance] getNetworkHandler];
            if (scriptHandler)
            {
                LuaBridge::pushLuaFunctionById(scriptHandler);
                LuaStack *stack = LuaBridge::getStack();
                
                stack->pushString([status UTF8String]);
                stack->executeFunction(1);
            }
        });
    };
    
    reach.unreachableBlock = ^(Reachability*reach)
    {
        dispatch_async(dispatch_get_main_queue(), ^{
           
//            NSLog(@"UNREACHABLE!", [NSThread mainThread]);
            NSString* status = @"none";
            int scriptHandler = [[LuaObjectCBridge getInstance] getNetworkHandler];
            if (scriptHandler)
            {
                LuaBridge::pushLuaFunctionById(scriptHandler);
                LuaStack *stack = LuaBridge::getStack();
                
                stack->pushString([status UTF8String]);
                stack->executeFunction(1);
            }
        });
    };
    
    // Start the notifier, which will cause the reachability object to retain itself!
    [reach startNotifier];
}


+ (void) unregisterNetworkStatus
{
    [[LuaObjectCBridge getInstance] setNetworkHandler:0];
}

+ (int)  addTwoNumbers:(NSDictionary *)dict
{
    int num1 = [[dict objectForKey:@"num1"] intValue];
    int num2 = [[dict objectForKey:@"num2"] intValue];
    
    return num1 + num2;
}

+ (void) callbackNetworkHandler
{
    int scriptHandler = [[LuaObjectCBridge getInstance] getNetworkHandler];
    if (scriptHandler)
    {
        LuaBridge::pushLuaFunctionById(scriptHandler);
        LuaStack *stack = LuaBridge::getStack();
//        stack->pushString("success");
        
        
//        [NSString stringWithUTF8String:content.c_str()]init];
//        stack->pushString(status)
        
        stack->executeFunction(1);
    }
}
    
+ (NSString *) getCurrentNetworkType
{
    // 通过statusbar，状态栏获取用户网络状态
    // 状态栏是由app控制的，首先获取app
    UIApplication *app = [UIApplication sharedApplication];
    
    NSArray *children = [[[app valueForKeyPath:@"statusBar"] valueForKeyPath:@"foregroundView"] subviews];
    
    int type = 0;
    for (id child in children) {
        if ([child isKindOfClass:[NSClassFromString(@"UIStatusBarDataNetworkItemView") class]]){
            type = [[child valueForKeyPath:@"dataNetworkType"] intValue];
        }
    }
    
    NSString *stateString = @"none";
    switch (type) {
        case 0:
            stateString = @"none";//not reachable
        break;
        
        case 1:
            stateString = @"2g";
        break;
        
        case 2:
            stateString = @"3g";
        break;
        
        case 3:
            stateString = @"4g";
        break;
        
        case 4:
            //stateString = @"lte";
        //break;
        
        case 5:
            stateString = @"wifi";
        break;
        
        default:
        break;
    }
    return stateString;
}

+ (void) copyToClipboard:(NSDictionary *)dict
{
    
    NSString *text = [dict objectForKey:@"_text"];
    NSString *url = [dict objectForKey:@"_url"];

    NSString *newString = [NSString stringWithFormat:@"%@\n%@",text,url];
    
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
    pasteboard.string = newString;//text + url;
}

+ (NSString *) getDeviceInfo
{
    NSString* idfv = [LuaObjectCBridge reloadIdfv];
    if ([idfv isEqualToString:@""]) {
        [LuaObjectCBridge saveIdfv];
    }else{
        return idfv;
    }
    
    return [LuaObjectCBridge reloadIdfv];
}

+ (NSString *) reloadIdfv
{
    NSMutableDictionary *loadData = [Keychain load:KEY_PACKAGE_NAME];
    NSString *loadIdfv = [loadData objectForKey:KEY_UUID];
    if(loadIdfv) {
        return loadIdfv;
    } else {
        return @"";
    }
}

+ (void) saveIdfv
{
    NSString *idfv = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
//    NSLog(@"get from UIDevice, idfv is %@", idfv);
    
    NSMutableDictionary *dataDict = [NSMutableDictionary dictionary];
    [dataDict setObject:idfv forKey:KEY_UUID];
    BOOL ret = [Keychain save:KEY_PACKAGE_NAME data:dataDict];
    NSLog(@"save %@ %@", idfv, ret?@"succ":@"fail");
}

float getBatteryLevel()
{
    [[UIDevice currentDevice]setBatteryMonitoringEnabled:YES ];
    return 100 * [[UIDevice currentDevice] batteryLevel];
}

const char* getUserLocation()
{
    NSLocale *locale = [NSLocale currentLocale];
    NSString *country = [locale displayNameForKey:NSLocaleIdentifier value:[locale localeIdentifier]];
    return [country UTF8String];
}

const char* getAppVersion()
{
    NSString* version = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    return [version UTF8String];
}
const char* getAppBundleID()
{
    NSString* bundleID = [[NSBundle mainBundle] bundleIdentifier];
    return [bundleID UTF8String];
}

- (id)init
{
    _networkHandler = 0;
    return self;
}

@end
