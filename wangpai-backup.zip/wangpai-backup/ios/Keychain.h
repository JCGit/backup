//
//  Keychain.h
//  UUIDdemo
//
//  Created by 555chy on 6/10/16.
//  Copyright © 2016 555chy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Security/Security.h>

@interface Keychain : NSObject

+ (BOOL)save:(NSString*)service data:(id)data;
+ (id)load:(NSString*)service;
+ (void)delete:(NSString*)service;

@end
