//
//  ImagePickerIOS.h
//  JMZJH
//
//  Created by yuebao on 13-11-21.
//
//

#ifndef __ZJH__ImagePickerIOS__
#define __ZJH__ImagePickerIOS__

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
//#import "ImagePicker.h"
#include "cocos2d.h"

@protocol ImagePickerDelegateIOS <NSObject>

-(void)onImageData:(UIImage *)image;

@end

@interface ImagePickerIOS : UIViewController<UIActionSheetDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIPopoverControllerDelegate, ImagePickerDelegateIOS>
{
//    ImagePickerDelegate * _imagePickerDelegate;
    int _pickerHandler;
    UIPopoverController * _popOver;
}

//@property(nonatomic, assign) ImagePickerDelegate * imagePickerDelegate;

+(ImagePickerIOS *) showImagePicker:(NSDictionary* )dict;


-(BOOL) shouldAutorotate;
-(void)chooseImageSour:(NSDictionary* )dict;

-(void)openImagePicker:(int) action;

@end



#endif /* defined(__ZJH__ImagePickerIOS__) */
