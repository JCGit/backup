//
//  InAppPurchase.h
//  MyLuaGame
//
//  Created by yunzhong on 12/6/16.
//
//

#ifndef InAppPurchase_h
#define InAppPurchase_h

#import <Foundation/Foundation.h>
#import "StoreKit/StoreKit.h"


//@interface InAppPurchase : NSObject
@interface InAppPurchase : NSObject <SKProductsRequestDelegate, SKPaymentTransactionObserver>
{
    
    int _payHandler;
    UIAlertView *alert;
}

+ (InAppPurchase*) shared;

+ (void) buyProduct:(NSDictionary* )dict;
+ (void) registerPayHandler:(NSDictionary *)dict;
+ (void) unregisterPayHandler;


- (void) purchaseProduct:(int)tag;

@end



#endif /* InAppPurchase_h */
