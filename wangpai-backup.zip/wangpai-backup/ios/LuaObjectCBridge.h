#ifndef COCOS2DX_IOS_LUAOBJECTCBRIDGETEST_H
#define COCOS2DX_IOS_LUAOBJECTCBRIDGETEST_H
#import <Foundation/Foundation.h>

@interface LuaObjectCBridge : NSObject {
    int _networkHandler;
    
}
+ (LuaObjectCBridge*) getInstance;
+ (void) destroyInstance;

+ (void) registerNetworkStatus:(NSDictionary *)dict;
+ (void) unregisterNetworkStatus;

+ (int)  addTwoNumbers:(NSDictionary *)dict;
+ (void) callbackScriptHandler;
    
    
+ (NSString *) getCurrentNetworkType;

+ (void) copyToClipboard:(NSDictionary *)dict;

+ (NSString *) getDeviceInfo;


+ (NSString *) reloadIdfv;
+ (void) saveIdfv;

float getBatteryLevel();

const char* getAppVersion();
const char* getAppBundleID();

const char* getUserLocation();

- (id) init;
@end

#endif  //  COCOS2DX_IOS_LUAOBJECTCBRIDGETEST_H
