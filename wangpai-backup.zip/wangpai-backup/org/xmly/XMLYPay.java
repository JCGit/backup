package org.xmly;

import org.cocos2dx.lua.ThirdSDK;

import android.app.Activity;
import android.app.Application;

public class XMLYPay extends ThirdSDK{

	@Override
	public void onApplicationCreate(Application _a) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onApplicationAttachBaseContext(Application _a) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onActivityCreate(Activity _a) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onActivityPause(Activity _a) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onActivityResume(Activity _a) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onActivityStop(Activity _a) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onActivityResult(Activity _a) {
		// TODO Auto-generated method stub
		
	}

}
