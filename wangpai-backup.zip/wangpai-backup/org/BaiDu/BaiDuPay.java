//package org.BaiDu;
//
//import android.app.Activity;
//import android.content.Intent;
//import android.os.Bundle;
//import android.os.Handler;
//import android.os.Message;
//import android.text.TextUtils;
//import android.util.Log;
//import android.view.View;
//import android.widget.Toast;
//import org.WeiXinPay.WeiXinPayUtil;
//import org.alipay.PayResult;
//import org.cocos2dx.lib.Cocos2dxLuaJavaBridge;
//import org.cocos2dx.lua.AppActivity;
//import org.cocos2dx.lua.CustomWebview;
//import org.cocos2dx.lua.SDKFactory;
//import org.json.JSONObject;
//import com.duoku.platform.single.DKPlatform;
//import com.duoku.platform.single.DKPlatformSettings;
//import com.duoku.platform.single.DkErrorCode;
//import com.duoku.platform.single.DkProtocolKeys;
//import com.duoku.platform.single.callback.IDKSDKCallBack;
//import com.duoku.platform.single.item.DKCMGBData;
//import com.duoku.platform.single.item.DKCMMMData;
//import com.duoku.platform.single.item.GamePropsInfo;
//
//import java.util.Map;
//
///**
// * Created by Administrator on 2016/1/11.
// */
//public class BaiDuPay extends SDKFactory {
//	
//	private static final int SDK_LOGIN_FLAG = 1;
//	private static final int SDK_PAY_FLAG = 2;
//	private static final int SDK_EXIT_FLAG = 3;
//	
//	private IDKSDKCallBack loginlistener;
//
//    public BaiDuPay(Activity _a, final Map<String, Integer> LuaFunctionCallbackTable, String name) {
//        super(_a, LuaFunctionCallbackTable, name);
//    }
//    
//    private Handler mHandler = new Handler(_activity.getApplicationContext().getMainLooper()) {
//		public void handleMessage(Message msg) {
//			switch (msg.what) {
//			case SDK_LOGIN_FLAG: {
//				DKPlatform.getInstance().invokeBDLogin(_activity, loginlistener);
//				break;
//			}
//			case SDK_PAY_FLAG: {
//				break;
//			}
//			case SDK_EXIT_FLAG: {
//				break;
//			}
//			default:
//				break;
//			}
//		};
//	};
//    
// // 初始化SDK
// 	public void doInit(){
// 		//回调函数
// 		IDKSDKCallBack initcompletelistener = new IDKSDKCallBack(){
// 			@Override
// 			public void onResponse(String paramString) {
// 				Log.d("GameMainActivity", paramString);
// 				try {
// 					JSONObject jsonObject = new JSONObject(paramString);
// 					// 返回的操作状态码
// 					int mFunctionCode = jsonObject.getInt(DkProtocolKeys.FUNCTION_CODE);
// 					
// 					//初始化完成
// 					if(mFunctionCode == DkErrorCode.BDG_CROSSRECOMMEND_INIT_FINSIH){
// 						System.out.println("566677878900");
// 						initLogin();
// 						initAds();
// 					}
// 					
// 				} catch (Exception e) {
// 					e.printStackTrace();
// 				}
// 			}
// 		};
// 		
// 		//初始化函数
// 		DKPlatform.getInstance().init(_activity, true, DKPlatformSettings.SdkMode.SDK_PAY,null,null,initcompletelistener);
// 	}
// 	
// 	//登陆初始化
// 	private void initLogin(){
// 		//回调函数
// 		 loginlistener = new IDKSDKCallBack(){
// 			@Override
// 			public void onResponse(String paramString) {
// 				try {
// 					JSONObject jsonObject = new JSONObject(paramString);
// 					// 返回的操作状态码
// 					int mFunctionCode = jsonObject.getInt(DkProtocolKeys.FUNCTION_CODE);
// 					// 返回的百度uid，供cp绑定使用
// 					String bduid = jsonObject.getString(DkProtocolKeys.BD_UID);
// 					
// 					//登陆成功
// 					if(mFunctionCode == DkErrorCode.DK_ACCOUNT_LOGIN_SUCCESS){
// 						//隐藏登陆按钮，显示修改密码和切换账号按钮
// 					//登陆失败
// 					}else if(mFunctionCode == DkErrorCode.DK_ACCOUNT_LOGIN_FAIL){
// 						//显示登陆按钮，隐藏修改密码和切换账号按钮
// 					//快速注册成功
// 					}else if(mFunctionCode == DkErrorCode.DK_ACCOUNT_QUICK_REG_SUCCESS){
// 						//快速试玩登陆成功，都需要隐藏
// 					}
// 					
// 				} catch (Exception e) {
// 					e.printStackTrace();
// 				}
// 				
//// 				initAds();
// 			}
// 		};
// 		DKPlatform.getInstance().invokeBDInit(_activity, loginlistener);
// 	}
// 	
// 	private void initAds(){
//		DKPlatform.getInstance().bdgameInit(_activity, new IDKSDKCallBack() {
//			@Override
//			public void onResponse(String paramString) {
//				Log.d("GameMainActivity","bggameInit success");
//			}
//		});
//	}
// 	
// 	
// 	/**
//	 * 支付处理过程的结果回调函数
//	 * */
//	IDKSDKCallBack RechargeCallback = new IDKSDKCallBack(){
//		@Override
//		public void onResponse(String paramString) {
//			// TODO Auto-generated method stub
//			Log.d("GamePropsActivity", paramString);
//			try {
//				JSONObject jsonObject = new JSONObject(paramString);
//				// 支付状态码
//				int mStatusCode = jsonObject.getInt(DkProtocolKeys.FUNCTION_STATUS_CODE);
//				
//				if(mStatusCode == DkErrorCode.BDG_RECHARGE_SUCCESS){
//					// 返回支付成功的状态码，开发者可以在此处理相应的逻辑
//					
//					// 订单ID
//					String mOrderId = null;
//					// 订单状态
//					String mOrderStatus = null;
//					// 道具ID
//					String mOrderProductId = null;
//					// 道具实际支付的价格
//					String mOrderPrice = null;
//					// 支付通道
//					String mOrderPayChannel = null;
//					//道具原始价格，若微信、支付宝未配置打折该值为空，
//					String mOrderPriceOriginal = null;
//					
//					if(jsonObject.has(DkProtocolKeys.BD_ORDER_ID)){						
//						mOrderId = jsonObject.getString(DkProtocolKeys.BD_ORDER_ID);	
//					}
//					if(jsonObject.has(DkProtocolKeys.BD_ORDER_STATUS)){
//						mOrderStatus = jsonObject.getString(DkProtocolKeys.BD_ORDER_STATUS);
//					}
//					if(jsonObject.has(DkProtocolKeys.BD_ORDER_PRODUCT_ID)){			
//						mOrderProductId = jsonObject.getString(DkProtocolKeys.BD_ORDER_PRODUCT_ID);
//					}
//					if(jsonObject.has(DkProtocolKeys.BD_ORDER_PAY_CHANNEL)){						
//						mOrderPayChannel = jsonObject.getString(DkProtocolKeys.BD_ORDER_PAY_CHANNEL);
//					}
//					if(jsonObject.has(DkProtocolKeys.BD_ORDER_PRICE)){						
//						mOrderPrice = jsonObject.getString(DkProtocolKeys.BD_ORDER_PRICE);
//					}
//					//int mNum = Integer.valueOf(mOrderPrice) * 10;
//					if(jsonObject.has(DkProtocolKeys.BD_ORDER_PAY_ORIGINAL)){						
//						mOrderPriceOriginal = jsonObject.getString(DkProtocolKeys.BD_ORDER_PAY_ORIGINAL);
//					}
//					int mNum = 0;
//					if( "".equals(mOrderPriceOriginal) ||null==mOrderPriceOriginal){
//						mNum = Integer.valueOf(mOrderPrice) * 10;
//					}else{
//						mNum = Integer.valueOf(mOrderPriceOriginal) * 10;
//					}
//					String propsType = "1";
//					Toast.makeText(_activity, "道具购买成功!\n金额:"+mOrderPrice+"元", Toast.LENGTH_LONG).show();
//					
//					Integer lua_func = LuaFunctionCallbackTable.get("SDK_Pay_onSuccess");
//					if(lua_func!=null)
//					{
//						Cocos2dxLuaJavaBridge.callLuaFunctionWithString(lua_func, "");
//						Cocos2dxLuaJavaBridge.releaseLuaFunction(lua_func);
//					}
//					
//				}else if(mStatusCode == DkErrorCode.BDG_RECHARGE_USRERDATA_ERROR){
//					
//				}else if(mStatusCode == DkErrorCode.BDG_RECHARGE_ACTIVITY_CLOSED){
//					
//					// 返回玩家手动关闭支付中心的状态码，开发者可以在此处理相应的逻辑
//					Toast.makeText(_activity, "玩家关闭支付中心", Toast.LENGTH_LONG).show();
//					
//				}else if(mStatusCode == DkErrorCode.BDG_RECHARGE_FAIL){ 
//					// 返回支付失败的状态码，开发者可以在此处理相应的逻辑
//					Toast.makeText(_activity, "购买失败", Toast.LENGTH_LONG).show();
//					
//				} else if(mStatusCode == DkErrorCode.BDG_RECHARGE_EXCEPTION){ 
//					
//					// 返回支付出现异常的状态码，开发者可以在此处理相应的逻辑
//					Toast.makeText(_activity, "购买出现异常", Toast.LENGTH_LONG).show();
//					
//				} else if(mStatusCode == DkErrorCode.BDG_RECHARGE_CANCEL){ 
//					
//					// 返回取消支付的状态码，开发者可以在此处理相应的逻辑
//					Toast.makeText(_activity, "玩家取消支付", Toast.LENGTH_LONG).show();
//					
//				} else {
//					Toast.makeText(_activity, "未知情况", Toast.LENGTH_LONG).show();
//					
//				}
//				
//			} catch (Exception e) {
//				// TODO: handle exception
//				e.printStackTrace();
//			}
//		}
//	};
//
//	
//	@Override
//	public void doPay(String jsonData) {
//		System.out.println("my jsonData  = " + jsonData);
//		JSONObject jb;
//		String pid = "";
//		String price = "";
//		String orderId = "";
//		String name = "";
//        try {
//            jb = new JSONObject(jsonData);
//            int ret = jb.optInt("result", -1);
//            if (ret == 0) {
//            	pid = jb.optString("baiduId");
//            	price = jb.optString("price");
//            	orderId = jb.optString("orderId");
//            	name = jb.optString("name");
//            	System.out.println("##$$$       pid = "+pid);
//            	System.out.println("##$$        price = "+price);
//            	System.out.println("##$$        name = "+name);
//            	System.out.println("##$$        orderId = "+orderId);
//            	GamePropsInfo propsFirst = new GamePropsInfo(pid, price, name, orderId);
//            	DKPlatform.getInstance().invokePayCenterActivity(_activity, 
//            			propsFirst, 
//            			null,null, null,null,RechargeCallback);
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//	}
//
//	public void doExitGame(){
//		DKPlatform.getInstance().bdgameExit(_activity, new IDKSDKCallBack() {
//			@Override
//			public void onResponse(String paramString) {
//				Toast.makeText(_activity, "退出游戏", Toast.LENGTH_LONG).show();
//				_activity.finish();
//				android.os.Process.killProcess(android.os.Process.myPid());
//			}
//		});
//	}
//}
//
