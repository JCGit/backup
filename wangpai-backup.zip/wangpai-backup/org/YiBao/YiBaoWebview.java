package org.YiBao;


        import android.app.Activity;
        import android.content.pm.ActivityInfo;
        import android.graphics.Bitmap;
        import android.net.Uri;
        import android.os.Bundle;
        import android.util.Log;
        import android.view.Window;
        import android.view.WindowManager;
        import android.webkit.JavascriptInterface;
        import android.webkit.WebSettings;
        import android.webkit.WebView;
        import android.webkit.WebViewClient;

        import com.icloud.game.flord.mm.R;
        import org.cocos2dx.lib.Cocos2dxLuaJavaBridge;

        import java.io.File;

/**
 * Created by Administrator on 2015/12/15.
 */
public class YiBaoWebview extends Activity {
    String TAG = "YiBaoWebview";
    boolean isChargeSuccess = false;
    Integer lua_succ = null;
    Integer lua_fail = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        setContentView(R.layout.webview_layout);
        WebView wv;
        wv = (WebView) findViewById(R.id.webView);

        Bundle bundle = this.getIntent().getExtras();
        String url = bundle.getString("filepath");

         lua_succ = bundle.getInt("success");
         lua_fail = bundle.getInt("fail");

        Uri u = null;
            //process file from assets.
            Log.d(TAG, "onCreate: is exists:" + (new File(url)).exists());
            if(url.contains("assets/"))
            {
                url = "file:///"+url.replaceFirst("assets","android_asset");
            }
            else
            {
                u = Uri.fromFile(new File(url));
                url = u.toString();
            }
        wv.getSettings().setDefaultZoom(WebSettings.ZoomDensity.FAR);
        wv.getSettings().setSupportZoom(true);
        wv.getSettings().setBuiltInZoomControls(true);
        wv.getSettings().setLoadWithOverviewMode(true);
        wv.getSettings().setJavaScriptEnabled(true);

        wv.loadUrl(url);
        final class InJavaScriptLocalObj {
            @JavascriptInterface
            public String toString() { return "cloudpay"; }
            @JavascriptInterface
            public void showSource(String html) {
                Log.d("HTML", html);
                if(html.contains("付款成功"))
                {
                    YiBaoWebview.this.isChargeSuccess = true;
                }
            }
            @JavascriptInterface
            public void close() {
                YiBaoWebview.this.aboutToFinish();
            }
        }
        final class MyWebViewClient extends WebViewClient {
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                Log.d("WebView","onPageStarted");
                super.onPageStarted(view, url, favicon);
            }
            public void onPageFinished(WebView view, String url) {
                Log.d("WebView","onPageFinished ");
                view.loadUrl("javascript:window.cloudpay.showSource('<head>'+" +
                        "document.getElementsByTagName('html')[0].innerHTML+'</head>');");
                super.onPageFinished(view, url);
            }
        }
            wv.addJavascriptInterface(new InJavaScriptLocalObj(), "cloudpay");
            wv.setWebViewClient(new MyWebViewClient());

    }

    public void aboutToFinish()
    {
        if(isChargeSuccess)
        {
            if(lua_succ!=null)
            {
                Cocos2dxLuaJavaBridge.callLuaFunctionWithString(lua_succ, "succ");
                Cocos2dxLuaJavaBridge.releaseLuaFunction(lua_succ);
            }
        }
        else
        {

            if(lua_fail!=null)
            {

                Cocos2dxLuaJavaBridge.callLuaFunctionWithString(lua_fail,  "fail");
                Cocos2dxLuaJavaBridge.releaseLuaFunction(lua_fail);
            }

        }
        this.finish();
    }

}
