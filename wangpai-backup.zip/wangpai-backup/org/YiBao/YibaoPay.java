package org.YiBao;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import org.cocos2dx.lua.AppActivity;
import org.cocos2dx.lua.CustomWebview;
import org.cocos2dx.lua.SDKFactory;

import java.util.Map;

/**
 * Created by Administrator on 2016/1/11.
 */
public class YibaoPay extends SDKFactory {

    public YibaoPay(Activity _a, final Map<String, Integer> LuaFunctionCallbackTable, String name) {
        super(_a, LuaFunctionCallbackTable, name);
    }


    @Override
    public void doPay(String URLPath) {
        super.doPay(URLPath);
        Intent intent = new Intent();
        Bundle bundle = new Bundle();
        bundle.putString("filepath", URLPath);
        if(this.LuaFunctionCallbackTable.containsKey("SDK_Pay_onSuccess"))
            bundle.putInt("success",LuaFunctionCallbackTable.get("SDK_Pay_onSuccess") );
        if(this.LuaFunctionCallbackTable.containsKey("SDK_Pay_onFail"))
            bundle.putInt("fail",LuaFunctionCallbackTable.get("SDK_Pay_onFail") );

        intent.putExtras(bundle);
        intent.setClass(AppActivity.AppInstance, YiBaoWebview.class);
        AppActivity.AppInstance.startActivity(intent);
    }
}

