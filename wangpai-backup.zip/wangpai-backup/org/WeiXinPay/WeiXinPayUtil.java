package org.WeiXinPay;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Map;

import org.cocos2dx.lib.Cocos2dxHelper;
import org.cocos2dx.lib.Cocos2dxLuaJavaBridge;
import org.cocos2dx.lua.AppActivity;
import org.cocos2dx.lua.SDKFactory;
import org.cocos2dx.lua.Util;
import org.json.JSONObject;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import com.tencent.mm.sdk.modelbase.BaseResp;
import com.tencent.mm.sdk.modelmsg.SendMessageToWX;
import com.tencent.mm.sdk.modelmsg.WXImageObject;
import com.tencent.mm.sdk.modelmsg.WXMediaMessage;
import com.tencent.mm.sdk.modelpay.PayReq;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.WXAPIFactory;

public class WeiXinPayUtil  extends SDKFactory {
    public String TAG = getClass().getSimpleName();
    // APP_ID 替换为你的应用从官方网站申请到的合法appId
   // public static final String APP_ID = "wxf788cd8572c560f3";
    public static final String APP_ID = "wxa4ee4535a446f677";

    IWXAPI msgApi;
    public WeiXinPayUtil(Activity _a, final Map<String, Integer> LuaFunctionCallbackTable, String name) {
        super(_a, LuaFunctionCallbackTable, name);
    }

    public void regist() {
        if (msgApi == null) {
            msgApi = WXAPIFactory.createWXAPI(_activity, null);
            msgApi.registerApp(APP_ID);
        }
    }

    public void doPay( String jsonData) {
        super.doPay(jsonData);
        Log.d("doPay", "000000000000000000000000000000000");
        //boolean bool= sendPicture(_activity, BitmapFactory.decodeResource(_activity.getResources(), R.drawable.icon));
        // Log.d("doPay", "000000000000000000000000000000000"+bool);
        if (!isWXAppInstalled(_activity)){
            Log.d("weixin****","33333");
            Integer lua_func = AppActivity.LuaFunctionCallbackTable.get("SDK_Pay_onFail");
            if (lua_func != null) {
                Cocos2dxLuaJavaBridge.callLuaFunctionWithString(lua_func, "noApp");
                Log.d("weixin****", "44444");
                Cocos2dxLuaJavaBridge.releaseLuaFunction(lua_func);
            }
            return;
        }
        regist();
        JSONObject jb;
        Log.d("doPay",jsonData);
        System.out.print("--x--" + jsonData);
        try {
            jb = new JSONObject(jsonData);
            int ret = jb.optInt("result", -1);
            if (ret == 0) {
                msgApi.registerApp(WeiXinPayUtil.APP_ID);
                PayReq request = new PayReq();
                //request.appId = APP_ID;
                request.appId = jb.optString("appid");
                request.partnerId = jb.optString("partnerid");
                request.prepayId = jb.optString("prepayid");
                request.packageValue = jb.optString("package");
                request.nonceStr = jb.optString("noncestr");
                request.timeStamp = jb.optString("timestamp");
                request.sign = jb.optString("sign");
                msgApi.sendReq(request);
            }
        } catch (Exception e) {
            Log.w(TAG, "doPay: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void res(BaseResp resp,String type) {
        Log.d("resp******",resp.errStr);
        if (resp.errCode == BaseResp.ErrCode.ERR_OK) {
            Log.d("resp*********",resp.errStr);
            Integer lua_func = LuaFunctionCallbackTable.get("SDK_"+type+"_onSuccess");
            if (lua_func != null) {
                Log.d("*********",resp.errStr);
                Cocos2dxLuaJavaBridge.callLuaFunctionWithString(lua_func,"success");
                Cocos2dxLuaJavaBridge.releaseLuaFunction(lua_func);
        }
        } else {
            Integer lua_func = LuaFunctionCallbackTable.get("SDK_"+type+"_onFail");
            if (lua_func != null) {
                Cocos2dxLuaJavaBridge.callLuaFunctionWithString(lua_func,"fail");
                Cocos2dxLuaJavaBridge.releaseLuaFunction(lua_func);
            }
        }
    }
    public Bitmap getBitmapFromPath(String path) {
        if (!new File(path).exists()) {
            System.err.println("getBitmapFromPath: file not exists");
            return null;
        }
        // Bitmap bitmap = Bitmap.createBitmap(1366, 768, Config.ARGB_8888);
        // Canvas canvas = new Canvas(bitmap);
        // Movie movie = Movie.decodeFile(path);
        // movie.draw(canvas, 0, 0);
        //
        // return bitmap;

        byte[] buf = new byte[1024 * 1024];// 1M
        Bitmap bitmap = null;

        try {
            FileInputStream fis = new FileInputStream(path);
            int len = fis.read(buf, 0, buf.length);
            bitmap = BitmapFactory.decodeByteArray(buf, 0, len);
            if (bitmap == null) {
                System.out.println("len= " + len);
                System.err.println("path: " + path + "  could not be decode!!!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bitmap;
    }


    public void  doShare()
    {
        boolean bool= sendPicture();
        // Log.d("doPay", "000000000000000000000000000000000"+bool);
    }

    public boolean sendPicture() {
        super.doShare();
        String path = Cocos2dxHelper.getCocos2dxWritablePath() + "/wx_share_temp.png";
       // String path = Cocos2dxHelper.getCocos
        Log.d("sendPicture","1111111111111111111111111111111111111");
        Log.d("path",path);
       // printf(Cocos2dxHelper.getCocos2dxWritablePath() + "\\wx_share_temp.png");
        if (!isWXAppInstalled(_activity)){
            Log.d("weixin****","11111111");
            Integer lua_func = AppActivity.LuaFunctionCallbackTable.get("SDK_Share_onFail");
            if (lua_func != null) {
                Cocos2dxLuaJavaBridge.callLuaFunctionWithString(lua_func, "noApp");
                Log.d("weixin****", "222");
                Cocos2dxLuaJavaBridge.releaseLuaFunction(lua_func);
            }
            return false;
        }
        Bitmap bmp = getBitmapFromPath(path);
        if (bmp != null )
        {
            WXImageObject imgObj = new WXImageObject(bmp);
            WXMediaMessage msg = new WXMediaMessage();
            msg.mediaObject = imgObj;
            Bitmap thumbBmp = Bitmap.createScaledBitmap(bmp, 100, 100, true);
            bmp.recycle();
            msg.thumbData = Util.bmpToByteArray(thumbBmp, true);
            SendMessageToWX.Req req = new SendMessageToWX.Req();
            req.transaction = String.valueOf(System.currentTimeMillis());
            req.message = msg;
            req.scene = SendMessageToWX.Req.WXSceneTimeline;
            return msgApi.sendReq(req);
        }
        return false;
    }


    public boolean isWXAppInstalled(Activity ctx) {
        regist();
        return msgApi.isWXAppInstalled();

    }
}
