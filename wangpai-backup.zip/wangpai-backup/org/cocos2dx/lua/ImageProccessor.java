package org.cocos2dx.lua;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;

import com.icloud.game.flord.mm.R;
import org.cocos2dx.lib.Cocos2dxHelper;
import org.cocos2dx.lib.Cocos2dxLuaJavaBridge;

public class ImageProccessor extends Activity {
	private static final int REQUEST_CODE_GETIMAGE_BYSDCARD = 0;// 从sd卡得到图像的请求码
	private static final int REQUEST_CODE_GETIMAGE_BYCAMERA = 1;// 从相机得到图像的请求码

	int imgWidth = 0;
	int imgHeight = 0;

	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		// 窗体状态设置-设置为无标题栏状态【全屏】
		this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		// 强制横屏
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		setContentView(R.layout.image_proccessor);
		// TODO Auto-generated method stub
		CharSequence[] items = { "手机相册", "手机拍照", "取消" };
		imageChooseItem(items);

		Bundle bundle = this.getIntent().getExtras();
		this.lua_callback = bundle.getInt("lua_callback");

		this.imgWidth = bundle.getInt("imgWidth");
		this.imgHeight = bundle.getInt("imgHeight");
	}

	/**
	 * 操作选择
	 *
	 * @param items
	 */
	public void imageChooseItem(CharSequence[] items) {
		AlertDialog imageDialog = new AlertDialog.Builder(this)
				.setTitle("选择图片")
				.setItems(items, new DialogInterface.OnClickListener() {

					public void onClick(DialogInterface dialog, int item) {
						Log.d("blah", "onClick: imageChooseItem");
						if (item == 0) {
							// 手机选图
							// if (Build.VERSION.SDK_INT < 19) {
							/*
							 * Intent intent = new Intent(
							 * Intent.ACTION_GET_CONTENT); //
							 * 
							 * intent.setDataAndType(MediaStore.Images.Media.
							 * EXTERNAL_CONTENT_URI, "image/*");
							 * startActivityForResult(intent,
							 * REQUEST_CODE_GETIMAGE_BYSDCARD);
							 */

							Intent intent = new Intent(Intent.ACTION_PICK, null);
							intent.setDataAndType(
									MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
									"image/*");
							startActivityForResult(intent,
									REQUEST_CODE_GETIMAGE_BYSDCARD);

							// }
							// else {
							// Intent intent
							// = new Intent(Intent.ACTION_OPEN_DOCUMENT);
							// intent.addCategory(Intent.CATEGORY_OPENABLE);
							// // intent.setType("image/*");
							// intent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
							// "image/*");
							// startActivityForResult(intent,
							// REQUEST_CODE_GETIMAGE_BYSDCARD);
							// }

						}
						// 拍照
						else if (item == 1) {
							try {
								Intent intentC = new Intent(
										MediaStore.ACTION_IMAGE_CAPTURE);
								Uri u = Uri.fromFile(new File(IMAGE_PATH,
										IMAGE_NAME));
								intentC.putExtra(MediaStore.EXTRA_OUTPUT, u);
								startActivityForResult(intentC,
										REQUEST_CODE_GETIMAGE_BYCAMERA);
							} catch (Exception e) {
								Log.d("blah", "onClick: " + e.toString());
							}
						} else {
							String s = "{\"succ\" : \"false\",\"msg\":\"canceled\"}";
							Cocos2dxLuaJavaBridge.callLuaFunctionWithString(
									ImageProccessor.this.lua_callback, s);
							ImageProccessor.this.finish();
						}
					}
				}).setOnCancelListener(new DialogInterface.OnCancelListener() {
					@Override
					public void onCancel(DialogInterface dialog) {
						ImageProccessor.this.finish();
					}
				}).create();

		imageDialog.show();
	}

	public static String IMAGE_PATH = Environment.getExternalStorageDirectory()
			.toString();// Cocos2dxHelper.getCocos2dxWritablePath();
	public static String IMAGE_NAME = "usrImage.jpg";

	// 获取图片
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		Log.d("blah", "onActivityResult:requestCode: " + requestCode
				+ "resultCode:" + resultCode);
		if (requestCode == REQUEST_CODE_GETIMAGE_BYSDCARD) {
			if (data != null) {
				Uri selectedImage = data.getData();
				if (selectedImage != null) {

					final Intent intent1 = new Intent(
							"com.android.camera.action.CROP");
					intent1.setDataAndType(selectedImage, "image/*");
					intent1.putExtra("crop", "true");
					intent1.putExtra("aspectX", 1);// this.imgWidth);
					intent1.putExtra("aspectY", 1);// this.imgHeight);
					intent1.putExtra("outputX", 150);// this.imgWidth);
					intent1.putExtra("outputY", 150);// this.imgHeight);
					intent1.putExtra("return-data", true);
					startActivityForResult(intent1, 4);
				}
			} else {

				CharSequence[] items = { "手机相册", "手机拍照", "取消" };
				imageChooseItem(items);
			}

		}
		// 拍摄图片
		else if (requestCode == REQUEST_CODE_GETIMAGE_BYCAMERA) {
			if (resultCode != RESULT_OK) {
				Log.d("blah", "onActivityResult: (resultCode != RESULT_OK");
				CharSequence[] items = { "手机相册", "手机拍照", "取消" };
				imageChooseItem(items);
				return;
			}

			// 设置文件保存路径这里放在跟目录下
			String path = IMAGE_PATH + "/" + IMAGE_NAME;
			File picture = new File(path);
			startPhotoZoom(Uri.fromFile(picture));

		} else if (requestCode == 4) {

			if (data != null) {
				Bitmap bmp = data.getParcelableExtra("data");
				writeBMP(bmp);

				String s = "{\"succ\" : \"true\",\"path\":\"" + IMAGE_PATH
						+ "/" + IMAGE_NAME + "\"}";
				Cocos2dxLuaJavaBridge.callLuaFunctionWithString(
						ImageProccessor.this.lua_callback, s);
				ImageProccessor.this.finish();
			}

		}

		else if (requestCode == 5) {

			Bundle extras = null;
			if (data != null)
				extras = data.getExtras();
			else {

				CharSequence[] items = { "手机相册", "手机拍照", "取消" };
				imageChooseItem(items);
			}
			if (extras != null && data != null) {
				Bitmap bmp = data.getParcelableExtra("data");
				writeBMP(bmp);
				Log.d("blah",
						"onActivityResult:requestCode == 5 (take photo & crop success)");

				String s = "{\"succ\" : \"true\",\"path\":\"" + IMAGE_PATH
						+ "/" + IMAGE_NAME + "\"}";
				Cocos2dxLuaJavaBridge.callLuaFunctionWithString(
						ImageProccessor.this.lua_callback, s);
				ImageProccessor.this.finish();
			}

		} else {
			ImageProccessor.this.finish();
		}
	}

	public void writeBMP(Bitmap bmp) {
		try {
			DataOutputStream out = new DataOutputStream(new FileOutputStream(
					IMAGE_PATH + "/" + IMAGE_NAME));
			bmp.compress(Bitmap.CompressFormat.JPEG, 100, out);
			out.close();
		} catch (Exception e) {
			String s = "{\"succ\" : \"false\",\"msg\":\"" + e.toString()
					+ "\"}";
			Cocos2dxLuaJavaBridge.callLuaFunctionWithString(
					ImageProccessor.this.lua_callback, s);
			ImageProccessor.this.finish();
		}
	}

	public Integer lua_callback = null;
	public static final String IMAGE_UNSPECIFIED = "image/*";

	public void startPhotoZoom(Uri uri) {
		System.out.println(uri);
		Intent intent = new Intent("com.android.camera.action.CROP");
		intent.setDataAndType(uri, IMAGE_UNSPECIFIED);
		intent.putExtra("crop", "true");
		// aspectX aspectY 是宽高的比例
		intent.putExtra("aspectX", this.imgWidth);
		intent.putExtra("aspectY", this.imgHeight);
		// outputX outputY 是裁剪图片宽高
		intent.putExtra("outputX", this.imgWidth);
		intent.putExtra("outputY", this.imgHeight);
		intent.putExtra("return-data", true);
		startActivityForResult(intent, 5);
	}

}
