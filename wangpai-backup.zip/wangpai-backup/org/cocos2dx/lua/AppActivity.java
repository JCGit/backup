/****************************************************************************
Copyright (c) 2008-2010 Ricardo Quesada
Copyright (c) 2010-2012 cocos2d-x.org
Copyright (c) 2011      Zynga Inc.
Copyright (c) 2013-2014 Chukong Technologies Inc.
 
http://www.cocos2d-x.org

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
****************************************************************************/
package org.cocos2dx.lua;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Dictionary;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import com.icloud.game.flord.mm.R;

import org.apache.http.util.EncodingUtils;
import org.cocos2dx.lib.Cocos2dxGLSurfaceView;
import org.cocos2dx.lib.Cocos2dxActivity;
import org.cocos2dx.lib.Cocos2dxLuaJavaBridge;
import org.cocos2dx.lib.Cocos2dxWebView;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
//import android.os.PersistableBundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.WindowManager;
import android.webkit.WebView;

public class AppActivity extends Cocos2dxActivity {

	private static ThirdSDK thirdSDK = null;
    private IntentFilter mIntentFilter;
    static String hostIPAdress = "0.0.0.0";
    public SDKFactory _SDKHandler = null;
    public static AppActivity AppInstance = null;
    private NetworkInfo netInfo;
    public Vector<Integer> batteryCallbackPool = new Vector<Integer>();
    public Vector<Integer> networkCallbackPool = new Vector<Integer>();
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    public String currBatteryStatus = "";
    public static Map<String, Integer> LuaFunctionCallbackTable = new HashMap<String, Integer>();

    private BroadcastReceiver mIntentReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            String action = intent.getAction();
            if (action.equals(Intent.ACTION_BATTERY_CHANGED)) {
                int status = intent.getIntExtra("status", 0);
                int health = intent.getIntExtra("health", 0);
                boolean present = intent.getBooleanExtra("present", false);
                int level = intent.getIntExtra("level", 0);
                int scale = intent.getIntExtra("scale", 0);
                int icon_small = intent.getIntExtra("icon-small", 0);
                int plugged = intent.getIntExtra("plugged", 0);
                int voltage = intent.getIntExtra("voltage", 0);
                int temperature = intent.getIntExtra("temperature", 0);
                String technology = intent.getStringExtra("technology");
                String statusString = "";
                switch (status) {
                    case BatteryManager.BATTERY_STATUS_UNKNOWN:
                        statusString = "unknown";
                        break;
                    case BatteryManager.BATTERY_STATUS_CHARGING:
                        statusString = "charging";
                        break;
                    case BatteryManager.BATTERY_STATUS_DISCHARGING:
                        statusString = "discharging";
                        break;
                    case BatteryManager.BATTERY_STATUS_NOT_CHARGING:
                        statusString = "not charging";
                        break;
                    case BatteryManager.BATTERY_STATUS_FULL:
                        statusString = "full";
                        break;
                }
                String healthString = "";
                switch (health) {
                    case BatteryManager.BATTERY_HEALTH_UNKNOWN:
                        healthString = "unknown";
                        break;
                    case BatteryManager.BATTERY_HEALTH_GOOD:
                        healthString = "good";
                        break;
                    case BatteryManager.BATTERY_HEALTH_OVERHEAT:
                        healthString = "overheat";
                        break;
                    case BatteryManager.BATTERY_HEALTH_DEAD:
                        healthString = "dead";
                        break;
                    case BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE:
                        healthString = "voltage";
                        break;
                    case BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE:
                        healthString = "unspecified failure";
                        break;
                }
                String acString = "";
                switch (plugged) {
                    case BatteryManager.BATTERY_PLUGGED_AC:
                        acString = "plugged ac";
                        break;
                    case BatteryManager.BATTERY_PLUGGED_USB:
                        acString = "plugged usb";
                        break;
                }
             /*   Log.i("cat", statusString);
                Log.i("cat", healthString);
                Log.i("cat", String.valueOf(present));
                Log.i("cat", String.valueOf(level));
                Log.i("cat", String.valueOf(scale));
                Log.i("cat", String.valueOf(icon_small));
                Log.i("cat", acString);
                Log.i("cat", String.valueOf(voltage));
                Log.i("cat", String.valueOf(temperature));
                Log.i("cat", technology);
                //要看看是不是我们要处理的消息
                //电池电量，数字
                Log.d("Battery", "" + intent.getIntExtra("level", 0));
                //电池最大容量
                Log.d("Battery", "" + intent.getIntExtra("scale", 0));
                //电池伏数
                Log.d("Battery", "" + intent.getIntExtra("voltage", 0));
                //电池温度
                Log.d("Battery", "" + intent.getIntExtra("temperature", 0));
                //电池状态，返回是一个数字
                // BatteryManager.BATTERY_STATUS_CHARGING 表示是充电状态
                // BatteryManager.BATTERY_STATUS_DISCHARGING 放电中
                // BatteryManager.BATTERY_STATUS_NOT_CHARGING 未充电
                // BatteryManager.BATTERY_STATUS_FULL 电池满
                Log.d("Battery", "ss" + intent.getIntExtra("status", BatteryManager.BATTERY_STATUS_CHARGING));
                //充电类型 BatteryManager.BATTERY_PLUGGED_AC 表示是充电器，不是这个值，表示是 USB
                Log.d("Battery", "" + intent.getIntExtra("plugged", 0));
                //电池健康情况，返回也是一个数字
                //BatteryManager.BATTERY_HEALTH_GOOD 良好
                //BatteryManager.BATTERY_HEALTH_OVERHEAT 过热
                //BatteryManager.BATTERY_HEALTH_DEAD 没电
                //BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE 过电压
                //BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE 未知错误
                Log.d("Battery", "" + intent.getIntExtra("health", BatteryManager.BATTERY_HEALTH_UNKNOWN));*/

                String ret = "{\"statusString\":\"" + statusString + "\","
                        +"\"healthString\":\"" + healthString + "\","
                        +"\"present\":\"" + present + "\","
                        +"\"scale\":\"" + scale + "\","
                        +"\"icon_small\":\"" + icon_small + "\","
                        +"\"level\":\"" + level + "\","
                        +"\"acString\":\"" + acString + "\","
                        +"\"voltage\":\"" + voltage + "\","
                        +"\"temperature\":\"" + temperature + "\","
                        +"\"technology\":\"" + technology + "\","
                        +"\"status\":\"" +  intent.getIntExtra("status", BatteryManager.BATTERY_STATUS_CHARGING) + "\","
                        +"\"plugged\":\"" + intent.getIntExtra("plugged", 0) + "\"}";
                currBatteryStatus = ret;
                    for (int i = 0 ; i <AppActivity.AppInstance.batteryCallbackPool.size();i++)
                    {
                        Cocos2dxLuaJavaBridge.callLuaFunctionWithString(AppActivity.AppInstance.batteryCallbackPool.get(i),ret);
                    }
            }

            if (action.equals(ConnectivityManager.CONNECTIVITY_ACTION)) {

                ConnectivityManager mConnectivityManager = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
                netInfo = mConnectivityManager.getActiveNetworkInfo();
//                mConnectivityManager.get
               // if(netInfo != null && netInfo.isAvailable()) {

                    for (int i = 0 ; i <AppActivity.AppInstance.networkCallbackPool.size();i++)
                    {
                        Cocos2dxLuaJavaBridge.callLuaFunctionWithString(AppActivity.AppInstance.networkCallbackPool.get(i),AppActivity.AppInstance.getCurrentNetType());
                    }

               // }
            }

        }
    };
    @Override
    public Cocos2dxGLSurfaceView onCreateView() {
        super.onCreateView();
        Cocos2dxGLSurfaceView glSurfaceView = new Cocos2dxGLSurfaceView(this);
        glSurfaceView.setEGLConfigChooser(5, 6, 5, 0, 16, 8);

        return glSurfaceView;

    }


    public static void openURL(final String url,final String type)
    {

        Intent intent = new Intent();
        Bundle bundle=new Bundle();
        bundle.putString("url", url);
        bundle.putString("type", type);
//

        intent.putExtras(bundle);
        intent.setClass(AppActivity.AppInstance, CustomWebview.class);
        AppActivity.AppInstance.startActivity(intent);
//        Uri uri = null;
//        File f = new File("file:///android_asset/res/bangzhu.html");
//        if(f.exists())
//        {
//            Log.d("blah", "openURL: exists");
//            uri = Uri.fromFile(f);
////            Cocos2dxWebView.
//        }
//        else
//        {
//            Log.d("blah", "openURL: not exists!");
//            uri = Uri.parse(url);
//        }
//////
//////
//        Log.d("blah", "openURL: "+uri.toString());
//         Intent it = new Intent(Intent.ACTION_VIEW, uri);
//        AppActivity.AppInstance.startActivity(it);

//        WebView wb = new WebView( AppActivity.AppInstance);
//        wb.loadUrl("file:///android_asset/res/bangzhu.htm");
//        AppActivity.AppInstance.setContentView(wb);

    }

    public static void getAvatar(final int luaCallback,final  int imgWidth,final int imgHeight)
    {

        Intent intent = new Intent();
        Bundle bundle=new Bundle();
        bundle.putInt("lua_callback", luaCallback);

        bundle.putInt("imgWidth", imgWidth);
        bundle.putInt("imgHeight", imgHeight);

        intent.putExtras(bundle);
        intent.setClass(AppActivity.AppInstance, ImageProccessor.class);
        AppActivity.AppInstance.startActivity(intent);

    }

    public static void registerBatteryCallback(final int luaCallback)
    {
        AppActivity.AppInstance.batteryCallbackPool.add(luaCallback);
    }

    public static void registerNetworkCallback(final int luaCallback)
    {
        AppActivity.AppInstance.networkCallbackPool.add(luaCallback);
    }

    public static void unregisterBatteryCallback(final int luaCallback)
    {
        for (int i = 0; i <  AppActivity.AppInstance.batteryCallbackPool.size();i++)
        {
            if (AppActivity.AppInstance.batteryCallbackPool.get(i) == luaCallback)
            {
                AppActivity.AppInstance.batteryCallbackPool.removeElementAt(i);
                return;
            }
        }
    }


    public static void unregisterNetworkCallback(final  int luacallback)
    {
        for (int i = 0; i <  AppActivity.AppInstance.networkCallbackPool.size();i++)
        {
            if (AppActivity.AppInstance.networkCallbackPool.get(i) == luacallback)
            {
                AppActivity.AppInstance.networkCallbackPool.removeElementAt(i);
                return;
            }
        }
    }

    public static String getCurrentNetworkType()
    {
        return AppActivity.AppInstance.getCurrentNetType();
    }

    public static String getBatteryStatus()
    {
      return  AppActivity.AppInstance.currBatteryStatus;
    }


    public  String getCurrentNetType() {
        Context context = this.getApplicationContext();
        String type = "";
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = cm.getActiveNetworkInfo();
        if (info == null) {
            type = "none";
        } else if (info.getType() == ConnectivityManager.TYPE_WIFI) {
            type = "wifi";
        } else if (info.getType() == ConnectivityManager.TYPE_MOBILE) {
            int subType = info.getSubtype();
            if (subType == TelephonyManager.NETWORK_TYPE_CDMA || subType == TelephonyManager.NETWORK_TYPE_GPRS
                    || subType == TelephonyManager.NETWORK_TYPE_EDGE) {
                type = "2g";
            } else if (subType == TelephonyManager.NETWORK_TYPE_UMTS || subType == TelephonyManager.NETWORK_TYPE_HSDPA
                    || subType == TelephonyManager.NETWORK_TYPE_EVDO_A || subType == TelephonyManager.NETWORK_TYPE_EVDO_0
                    || subType == TelephonyManager.NETWORK_TYPE_EVDO_B) {
                type = "3g";
            } else if (subType == TelephonyManager.NETWORK_TYPE_LTE) {// LTE是3g到4g的过渡，是3.9G的全球标准
                type = "4g";
            }

        }
        return type;
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(mIntentReceiver, mIntentFilter);
        if (thirdSDK != null) {
        	thirdSDK.onActivityResume(this);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(mIntentReceiver);
        if (thirdSDK != null) {
			thirdSDK.onActivityPause(this);
		}
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CrashHandler crashHandler = CrashHandler.getInstance();
        crashHandler.init(getApplicationContext());



        mIntentFilter = new IntentFilter();
        mIntentFilter.addAction(Intent.ACTION_BATTERY_CHANGED);
        mIntentFilter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        AppInstance = this;
        if (nativeIsLandScape()) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        } else {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
        }

        //2.Set the format of window

        // Check the wifi is opened when the native is debug.
        if (nativeIsDebug()) {
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON, WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            if (!isNetworkConnected()) {
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Warning");
                builder.setMessage("Please open WIFI for debuging...");
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
                        finish();
                        System.exit(0);
                    }
                });

                builder.setNegativeButton("Cancel", null);
                builder.setCancelable(true);
                builder.show();
            }
            hostIPAdress = getHostIpAddress();
        }
        if (thirdSDK == null) {
        	thirdSDK = AppApplication.getThirdSDK();
		}
        if (thirdSDK != null) {
        	thirdSDK.onActivityCreate(this);
		}
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (_SDKHandler != null){
        	_SDKHandler.setOnActivityResultCallback(requestCode, resultCode, data);
        }
        if (thirdSDK != null) {
        	thirdSDK.onActivityResult(this);
		}
    }

    public static void SDKSetup(String _type,String name) {
       SDKFactory.buildInstance(SDKFactory.SDKType.valueOf(_type), AppActivity.AppInstance, LuaFunctionCallbackTable, name);
    }

    public static void SDKLogin(final int lua_onSueccCallback,final int lua_onCancelCallback,final int lua_onErrorCallback,final String name) {
        LuaFunctionCallbackTable.put("SDK_Login_onSuccess",lua_onSueccCallback);
        LuaFunctionCallbackTable.put("SDK_Login_onCancel",lua_onCancelCallback);
        LuaFunctionCallbackTable.put("SDK_Login_oError", lua_onErrorCallback);
        AppActivity.AppInstance.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                SDKFactory.SDKPool.get(name).doLogin();
            }
        });
    }


    public static void SDKPay(final int lua_onSueccCallback,final int lua_onPendingCallback,final int lua_onErrorCallback, final String jsonData,final String name) {
        LuaFunctionCallbackTable.put("SDK_Pay_onSuccess", lua_onSueccCallback);
        LuaFunctionCallbackTable.put("SDK_Pay_onPending",lua_onPendingCallback);
        LuaFunctionCallbackTable.put("SDK_Pay_onFail", lua_onErrorCallback);

        AppActivity.AppInstance.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                System.out.print("-----SDKPay");
                SDKFactory.SDKPool.get(name).doPay(jsonData);
            }
        });
    }

    public static void SDKShare(final int lua_onSueccCallback,final int lua_onPendingCallback,final int lua_onErrorCallback, final String jsonData,final String name) {
        LuaFunctionCallbackTable.put("SDK_Share_onSuccess",lua_onSueccCallback);
        LuaFunctionCallbackTable.put("SDK_Share_onPending",lua_onPendingCallback);
        LuaFunctionCallbackTable.put("SDK_Share_onFail", lua_onErrorCallback);

        AppActivity.AppInstance.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                System.out.print("-----SDKShare");
                SDKFactory.SDKPool.get(name).doShare();
            }
        });
    }
    
    public static void thirdSDKDoLogin(final int success,final int canel,final int error,final String str) {
    	if (thirdSDK != null) {
    		thirdSDK.setLoginCallBack(success, canel, error);
    		AppActivity.AppInstance.runOnUiThread(new Runnable() {
    			@Override
    			public void run() {
					thirdSDK.doLogin(AppInstance, str);
    			}
    		});
    	}
    }
    
    public static void thirdSDKDoLogin(final int success,final int canel,final int error) {
    	if (thirdSDK != null) {
    		thirdSDK.setLoginCallBack(success, canel, error);
    		AppActivity.AppInstance.runOnUiThread(new Runnable() {
    			@Override
    			public void run() {
					thirdSDK.doLogin(AppInstance);
    			}
    		});
    	}
    }
    
    public static void thirdSDKDoPay(final int success,final int pending,final int error,final String str) {
    	if (thirdSDK != null) {
    		thirdSDK.setPayCallBack(success, pending, error);
    		AppActivity.AppInstance.runOnUiThread(new Runnable() {
    			@Override
    			public void run() {
					thirdSDK.doPay(AppInstance, str);
    			}
    		});
    	}
    }
    
    public static void thirdSDKDoPay(final int success,final int pending,final int error) {
    	if (thirdSDK != null) {
    		thirdSDK.setPayCallBack(success, pending, error);
    		AppActivity.AppInstance.runOnUiThread(new Runnable() {
    			@Override
    			public void run() {
					thirdSDK.doPay(AppInstance);
    			}
    		});
    	}
    }
    
    public static void thirdSDKExitGame() {
        AppActivity.AppInstance.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (thirdSDK != null) {
					thirdSDK.doExitGame(AppInstance);
				}
            }
        });
    }
    
    public static void thirdSDKDoShowAdv() {
    	AppActivity.AppInstance.runOnUiThread(new Runnable() {
    		@Override
    		public void run() {
    			if (thirdSDK != null) {
					thirdSDK.doShowAdv(AppInstance);
				}
    		}
    	});
    }

    private boolean isNetworkConnected() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm != null) {
            NetworkInfo networkInfo = cm.getActiveNetworkInfo();
            ArrayList networkTypes = new ArrayList();
            networkTypes.add(ConnectivityManager.TYPE_WIFI);
            try {
                networkTypes.add(ConnectivityManager.class.getDeclaredField("TYPE_ETHERNET").getInt(null));
            } catch (NoSuchFieldException nsfe) {
            } catch (IllegalAccessException iae) {
                throw new RuntimeException(iae);
            }
            if (networkInfo != null && networkTypes.contains(networkInfo.getType())) {
                return true;
            }
        }
        return false;
    }

    public static String getMac()
    {
        String macSerial =  "";
        String str = "";

        try
        {
            Process pp = Runtime.getRuntime().exec("cat /sys/class/net/wlan0/address ");
            InputStreamReader ir = new InputStreamReader(pp.getInputStream());
            LineNumberReader input = new LineNumberReader(ir);

            for (; null != str;)
            {
                str = input.readLine();
                if (str != null)
                {
                    macSerial = str.trim();// 去空格
                    break;
                }
            }
        } catch (IOException ex) {
            // 赋予默认值
            ex.printStackTrace();
        }
        return macSerial;
    }


    public static String getAllInfomationYouNeeded()
    {
        String ts = Context.TELEPHONY_SERVICE;
        TelephonyManager mTelephonyMgr = (TelephonyManager)  AppActivity.AppInstance.getSystemService(ts);
        String imsi = "";
        try {
            if(mTelephonyMgr.getSubscriberId()!=null)
                imsi = mTelephonyMgr.getSubscriberId();
        }
        catch (Exception e)
        {
            Log.e("blah", "getAllInfomationYouNeeded: " + e.toString());
        }
        String imei = mTelephonyMgr.getDeviceId();
        WifiManager manager = (WifiManager)AppActivity.AppInstance.getSystemService(Context.WIFI_SERVICE);
        WifiInfo info = manager.getConnectionInfo();
        return "{"+
                "\"imsi\":\"" +imsi.toString() +"\""+
                "\"imei\":\"" +imei.toString() +"\""+
                "\"mac\":\"" + getMac() +"\""+
                "\"model\":\"" + android.os.Build.MODEL +"\""+
                "}";
    }

    public String getHostIpAddress() {
        WifiManager wifiMgr = (WifiManager) getSystemService(WIFI_SERVICE);
        WifiInfo wifiInfo = wifiMgr.getConnectionInfo();
        int ip = wifiInfo.getIpAddress();
        return ((ip & 0xFF) + "." + ((ip >>>= 8) & 0xFF) + "." + ((ip >>>= 8) & 0xFF) + "." + ((ip >>>= 8) & 0xFF));
    }

    public static String getLocalIpAddress() {
        return hostIPAdress;
    }

//    @Override
//    public void onCreate(Bundle savedInstanceState, PersistableBundle persistentState) {
//        super.onCreate(savedInstanceState, persistentState);
//    }

    public static void restartApplication() {
        Intent mStartActivity = new Intent(AppActivity.getContext(), AppActivity.class);
        int mPendingIntentId = 123456;
        PendingIntent mPendingIntent = PendingIntent.getActivity(AppActivity.getContext(), mPendingIntentId, mStartActivity, PendingIntent.FLAG_CANCEL_CURRENT);
        AlarmManager mgr = (AlarmManager)AppActivity.getContext().getSystemService(Context.ALARM_SERVICE);
        mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 100, mPendingIntent);
        System.exit(0);

//    	AppActivity.getContext()
//    	 final Intent intent = AppActivity.getContext().getPackageManager().getLaunchIntentForPackage( AppActivity.getContext().getPackageName());  
//         intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);  
//         AppActivity.getContext().startActivity(intent);  
    }

    //获取SD卡根目录
    public static String getAndroidRoot()
    {
        String rootDir = null;
        if (Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())) {
            rootDir = Environment.getExternalStorageDirectory().getAbsolutePath();
        }
        return rootDir;
    }

    //在浏览器打开网页
    public static void openWebURL(String _url)
    {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(_url));
        AppActivity.AppInstance.startActivity(intent);
    }

    //拨打电话
    public static  void dialPhone(String _numb) {
        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse(_numb));
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        AppActivity.AppInstance.startActivity(intent);
    }

    //分享
    public static void shares(String _url,String _title, String _content){
        String desc  = AppActivity.AppInstance.getString(R.string.app_name) +_content ;

        Intent intent=new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_SUBJECT, _title);
        intent.putExtra(Intent.EXTRA_TEXT, desc + "\n" + _url);

        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        AppActivity.AppInstance.startActivity(Intent.createChooser(intent, AppActivity.AppInstance.getString(R.string.app_name)));
    }
public static String getChannelID()
{
    String ret = "yz";
    try {
        ApplicationInfo appInfo = AppActivity.AppInstance.getPackageManager()
                .getApplicationInfo(AppActivity.getContext().getPackageName(),
                        PackageManager.GET_META_DATA);
        ret = appInfo.metaData.getString("MOBILE_CHANNEL");
    }
    catch (Exception e)
    {
        Log.e("getChannelID", "getChannelID: " + e.getMessage());
    }

   return ret;
}


    public static void listFiles(String path){
        File file = new File(path);
        File [] files = file.listFiles();
        String [] names = file.list();
        if(names != null)
        for(File a:files)
        {
            Log.d("listDir", "listDir: " +a.toString() );
            File f = new File(a.toString());
            try {
                InputStream in = new FileInputStream(f);
                byte b[]=new byte[(int)f.length()];     //创建合适文件大小的数组
                in.read(b);    //读取文件中的内容到b[]数组
                in.close();
                Log.d("content", new String(b));
            }
            catch (Exception e)
            {
                Log.e("content",e.getMessage());
            }

        }
    }

    //复制
    @Override
    protected void onStop() {
        super.onStop();
        if (thirdSDK != null) {
        	thirdSDK.onActivityStop(this);
		}
    }
    public static void copyToClipboard(final String _text,final String _url){
        AppActivity.AppInstance.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Context context = AppActivity.AppInstance.getApplicationContext();
                String desc = AppActivity.AppInstance.getString(R.string.app_name) + _text;
                if (android.os.Build.VERSION.SDK_INT > 11) {
                    ClipboardManager c = (ClipboardManager) context.getSystemService(CLIPBOARD_SERVICE);
                    c.setPrimaryClip(ClipData.newPlainText("", (desc + "\n" + _url)));

                } else {
                    android.text.ClipboardManager c = (android.text.ClipboardManager) context.getSystemService(CLIPBOARD_SERVICE);
                    c.setText((desc + "\n" + _url));
                }
            }
        });

    }

    private static native boolean nativeIsLandScape();

    private static native boolean nativeIsDebug();

    protected static int OPENFILECALLBACK = 0;
    public static void openFile(final int callback,final String url)
    {
        OPENFILECALLBACK = callback;

        AppActivity.AppInstance.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    Intent intent = new Intent();
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.setAction(android.content.Intent.ACTION_VIEW);
                    intent.setDataAndType(Uri.fromFile(new File(url)),
                            "application/vnd.android.package-archive");
                    AppActivity.AppInstance.startActivity(intent);
                }catch (Exception e){
                    System.out.println();
                }
            }
        });
    }

}
