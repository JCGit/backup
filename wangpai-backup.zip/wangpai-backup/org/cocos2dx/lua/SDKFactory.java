package org.cocos2dx.lua;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.util.Log;

import org.YiBao.YibaoPay;
import org.alipay.AlipayHandler;
import org.WeiXinPay.WeiXinPayUtil;

import java.util.HashMap;
import java.util.Map;

public  class SDKFactory {
    static public String TAG = "SDKFactory";
    static public  Map<String, SDKFactory> SDKPool = new HashMap<String, SDKFactory>();
public  enum SDKType
{
    NONE,
    FACEBOOK,
    ALIPAY,
    YIBAO,
    WEIXIN,
    SHARE_WEIXIN,
}
    protected Activity _activity;
    protected String poolMemberName = "";
    public Map<String, Integer> LuaFunctionCallbackTable = null;
    public  SDKFactory ( Activity _a, Map<String, Integer> _LuaFunctionCallbackTable,String poolMemberName)
    {
        _activity = _a;
        LuaFunctionCallbackTable = _LuaFunctionCallbackTable;
       this.poolMemberName = poolMemberName;
    }
    public void doLogin()
    {
        Log.d("SDKFactory", "doLogin: NONE");
    }

    public void doInit(){}
    public void doPay(String jsonData){}
    public void doLogo(){}
    public void doExitGame(){}
    public void doShare(){}
    public void onLogin(Boolean isLoginSucc)
    {
        Log.d("SDKFactory", "onLogin: NONE");
    }
    public void setOnActivityResultCallback(int requestCode, int resultCode, Intent data)
    {
    }
    public static SDKFactory buildInstance(SDKType _type,  Activity _a, Map<String, Integer> _LuaFunctionCallbackTable,String poolMemberName)
    {
        SDKFactory ret = null;

        if( SDKFactory.SDKPool.containsKey(poolMemberName))
        {
            Log.w(TAG, "buildInstance: duplicated SDK detected: ["+poolMemberName+" ],returning exist one.");
            return SDKFactory.SDKPool.get(poolMemberName);
    }
        switch (_type) {
            case NONE:
                ret = new SDKFactory(_a,_LuaFunctionCallbackTable,poolMemberName);
                break;
            case FACEBOOK:
//                ret = new FBHandler(_a,_LuaFunctionCallbackTable,poolMemberName);
                break;
            case ALIPAY:
                ret = new AlipayHandler(_a,_LuaFunctionCallbackTable,poolMemberName);
                break;
            case YIBAO:
                ret = new YibaoPay(_a,_LuaFunctionCallbackTable,poolMemberName);
                break;
            case WEIXIN:
                ret = new WeiXinPayUtil(_a,_LuaFunctionCallbackTable,poolMemberName);
                break;
            case SHARE_WEIXIN:
                ret = new WeiXinPayUtil(_a,_LuaFunctionCallbackTable,poolMemberName);
                break;
        }
        SDKFactory.SDKPool.put(poolMemberName,ret);

        return ret;
    }
    public static SDKFactory getInfo(String poolMemberName){
        if( SDKFactory.SDKPool.containsKey(poolMemberName))
        {
            Log.w(TAG, "buildInstance: duplicated SDK detected: ["+poolMemberName+" ],returning exist one.");
            return SDKFactory.SDKPool.get(poolMemberName);
        }
        return null;
    }

}
