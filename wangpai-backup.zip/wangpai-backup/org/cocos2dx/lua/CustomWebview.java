package org.cocos2dx.lua;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import com.icloud.game.flord.mm.R;

import java.io.File;

/**
 * Created by Administrator on 2015/12/15.
 */
public class CustomWebview extends Activity{
    String TAG = "CustomWebview";
    boolean isChargeSuccess = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        // 强制横屏
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        setContentView(R.layout.webview_layout);
        WebView wv;
        wv = (WebView) findViewById(R.id.webView);

        Bundle bundle = this.getIntent().getExtras();
        String url = bundle.getString("url");
        String type = bundle.getString("type");
        String intergrated = bundle.getString("intergrated");
        Uri u = null;

        if(type.contentEquals("online"))
        {
            u = Uri.parse(url);
            url = u.toString();
        }
        else if(type.contentEquals("local"))
        {


            //process file from assets.
            Log.d(TAG, "onCreate: is exists:" + (new File(url)).exists());
            if(url.contains("assets/"))
            {
                url = "file:///"+url.replaceFirst("assets","android_asset");
            }
            else
            {
                u = Uri.fromFile(new File(url));
                url = u.toString();
            }
        }
        //1st try:
        wv.getSettings().setDefaultZoom(WebSettings.ZoomDensity.FAR);
        wv.getSettings().setSupportZoom(true);
        wv.getSettings().setBuiltInZoomControls(true);
        wv.getSettings().setLoadWithOverviewMode(true);
        wv.getSettings().setJavaScriptEnabled(true);
//        wv.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);

        wv.loadUrl(url);   // now it will not fail here
        final class InJavaScriptLocalObj {
            @JavascriptInterface
            public String toString() { return "cloudpay"; }
            @JavascriptInterface
            public void showSource(String html) {
                Log.d("HTML", html);
            }
            @JavascriptInterface
            public void close() {
                CustomWebview.this.aboutToFinish();
            }
        }
        final class MyWebViewClient extends WebViewClient{
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                Log.d("WebView","onPageStarted");
                super.onPageStarted(view, url, favicon);
            }
            public void onPageFinished(WebView view, String url) {
                Log.d("WebView","onPageFinished ");
                view.loadUrl("javascript:window.local_obj.showSource('<head>'+" +
                        "document.getElementsByTagName('html')[0].innerHTML+'</head>');");
                super.onPageFinished(view, url);
            }
        }
        if(intergrated!=null) {
            wv.addJavascriptInterface(new InJavaScriptLocalObj(), "cloudpay");
            wv.setWebViewClient(new MyWebViewClient());
        }

    }

    public void aboutToFinish()
    {

    }

}
