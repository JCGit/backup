package org.cocos2dx.lua;

import android.app.Application;
import android.content.Context;


public class AppApplication extends Application {

	private static ThirdSDK thirdSDK = null;
    @Override
    protected void attachBaseContext(Context ctx){
        super.attachBaseContext(ctx);
        if (thirdSDK != null) {
        	thirdSDK.onApplicationAttachBaseContext(this);
		}
    }
    
    @Override
	public void onCreate() {
		super.onCreate();
		if (thirdSDK != null) {
			thirdSDK.onApplicationCreate(this);
		}
	}
    
    public static ThirdSDK getThirdSDK(){
    	return thirdSDK;
    }
}