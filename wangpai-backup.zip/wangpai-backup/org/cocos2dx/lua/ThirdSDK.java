package org.cocos2dx.lua;

import android.app.Activity;
import android.app.Application;

public abstract class ThirdSDK {

	protected int LOGIN_SUCCESS = 0; 
	protected int LOGIN_CANEL = 0; 
	protected int LOGIN_ERROR = 0; 
	
	protected int PAY_SUCCESS = 0; 
	protected int PAY_PENDING = 0; 
	protected int PAY_ERROR = 0; 
	
	public void setLoginCallBack(int success, int canel, int error){
		this.LOGIN_SUCCESS = success;
		this.LOGIN_CANEL = canel;
		this.LOGIN_ERROR = error;
	}
	
	public void setPayCallBack(int success, int pending, int error){
		this.PAY_SUCCESS = success;
		this.PAY_PENDING = pending;
		this.PAY_ERROR = error;
	}
	
	public abstract void onApplicationCreate(Application _a);
	public abstract void onApplicationAttachBaseContext(Application _a);
	public abstract void onActivityCreate(Activity _a);
	public abstract void onActivityPause(Activity _a);
	public abstract void onActivityResume(Activity _a);
	public abstract void onActivityStop(Activity _a);
	public abstract void onActivityResult(Activity _a);
	public void doLogin(Activity _a){}
	public void doPay(Activity _a){}
	public void doLogin(Activity _a, String str){}
	public void doPay(Activity _a, String str){}
	public void doExitGame(Activity _a){}
	public void doShowAdv(Activity _a){}
	
	
}
