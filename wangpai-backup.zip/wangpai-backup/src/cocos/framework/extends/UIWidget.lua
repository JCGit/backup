--[[

Copyright (c) 2011-2014 chukong-inc.com

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

]]

local Widget = ccui.Widget

function Widget:setDontPlayDefaultSFX(isPlay)
    self.dontPlayDefaultSFX = isPlay
end

function Widget:onTouch(callback,dontPlayDefaultSFX)
    self:addTouchEventListener(function(sender, state)
        local event = {x = 0, y = 0}

        if state == 0 then
            local tmpPos = self:getTouchBeganPosition()
            event.pos = self:convertToNodeSpace(tmpPos)
            event.name = "began"   
            if self.___ButtonSFX == nil  then
                self.___ButtonSFX = Sound.SoundTable['sfx']['Button'] 
                self.setButtonSFX = function(sfx)
                    self.___ButtonSFX = sfx
                end 
            end 
            if self.dontPlayDefaultSFX ~= true then
                audio.playSound(self.___ButtonSFX, false)
            end
        elseif state == 1 then
            local tmpPos = self:getTouchMovePosition()
            event.pos = self:convertToNodeSpace(tmpPos)
            event.name = "moved"
        elseif state == 2 then
            local tmpPos = self:getTouchEndPosition()
            event.pos = self:convertToNodeSpace(tmpPos)
            event.name = "ended"
        else 
            event.name = "cancelled"
        end
        event.target = sender
        callback(event)
    end)

    self.callback = callback

    return self
end
