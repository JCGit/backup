
local THirdSDKHandler = class('THirdSDKHandler')

function THirdSDKHandler.doSDKLogin(onSueccCallback, onCancelCallback, onErrorCallback, str)
    if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) and LuaTools.CheckJavaMethod("thirdSDKDoLogin") then
        local args = {onSueccCallback, onCancelCallback, onErrorCallback, str}
        local sigs = "(IIILjava/lang/String;)V"
        local luaj = require "cocos.cocos2d.luaj"
        local className = "org/cocos2dx/lua/AppActivity"
        local ok,ret = luaj.callStaticMethod(className,"thirdSDKDoLogin",args,sigs) 
        if not ok then  
            print(ok.."error:"..ret)  
        end
    end
end

function THirdSDKHandler.doUmengMethod(onSueccCallback, onCancelCallback, onErrorCallback, str)
    if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) and LuaTools.CheckJavaMethod("GetUmengMethod") then
        local args = {onSueccCallback, onCancelCallback, onErrorCallback, json.encode(str)}
        local sigs = "(IIILjava/lang/String;)V"
        local luaj = require "cocos.cocos2d.luaj"
        local className = "org/cocos2dx/lua/AppActivity"
        local ok,ret = luaj.callStaticMethod(className,"GetUmengMethod",args,sigs) 
        if not ok then  
            print(ok.."error:"..ret)  
        end
    end
end

function THirdSDKHandler.callSDKPay(onSueccCallback, onPendingCallback, onErrorCallback, str, conf)
    if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) and LuaTools.CheckJavaMethod("thirdSDKDoPay") then
        local args = {onSueccCallback, onPendingCallback, onErrorCallback, str}
        local sigs = "(IIILjava/lang/String;)V"
        local luaj = require "cocos.cocos2d.luaj"
        local className = "org/cocos2dx/lua/AppActivity"
        local ok,ret = luaj.callStaticMethod(className,"thirdSDKDoPay",args,sigs) 
        if not ok then  
            print(ok.."error:"..ret)  
        end
    elseif LuaTools.isPlatformIOS() then

        local luaoc = require "cocos.cocos2d.luaoc"
        local className = "InAppPurchase"

        local function iosPayCallback(...)
            local function succ(sargs)
                local dst = cc.FileUtils:getInstance():getWritablePath() .. 'appstore_pay.html'
                cc.FileUtils:getInstance():removeFile(dst)
            end 

            local function fail(sargs) 

            end

            local iosReturn = {...}
            local payServer = {
                orderId = conf.orderId,
                receipt = iosReturn[1].product,
                cmd     = conf.notifyUrl, --拿到服务器支付回调地址
            }

            local payString = json.encode(payServer)

            -- 本地存储订单id 和 苹果支付凭证
            LuaTools.writeFileToCache(payString,'appstore_pay.html')

            -- 请求游戏服发货
            LuaTools.fastRequest(payServer,succ,fail, {disableAlert =true})

            luaoc.callStaticMethod(className,"unregisterPayHandler", {_status = "success" })
        end

        luaoc.callStaticMethod(className,"registerPayHandler", {_payHandler = iosPayCallback })

        -- 请求appstore购买
        local arg = {tag = conf.pid}
        luaoc.callStaticMethod(className,"buyProduct", arg)
    end
end

function THirdSDKHandler.reCallServerPay()

    if LuaTools.isPlatformIOS() then
        local dst = cc.FileUtils:getInstance():getWritablePath() .. 'appstore_pay.html'
        if cc.FileUtils:getInstance():isFileExist(dst) then

            local payServer = json.decode(io.readfile(dst))

            local function succ(sargs)
                cc.FileUtils:getInstance():removeFile(dst)
            end 

            local function fail(sargs) 
                print("THirdSDKHandler.reCallServerPay...")
                dump(payServer)
            end

            -- 请求游戏服发货
            LuaTools.fastRequest(payServer,succ,fail, {disableAlert =true})
        end
    end
end

function THirdSDKHandler.callSDKInit(onSueccCallback, onPendingCallback, onErrorCallback, str)
    if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) and LuaTools.CheckJavaMethod("thirdSDKInit") then
        local args = {onSueccCallback, onPendingCallback, onErrorCallback, str}
        local sigs = "(IIILjava/lang/String;)V"
        local luaj = require "cocos.cocos2d.luaj"
        local className = "org/cocos2dx/lua/AppActivity"
        local ok,ret = luaj.callStaticMethod(className,"thirdSDKInit",args,sigs) 
        if not ok then  
            print(ok.."error:"..ret)  
        end
    end
end

function THirdSDKHandler.doSDKExitGame()
    if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) and LuaTools.CheckJavaMethod("thirdSDKExitGame") then
        local args = {}
        local sigs = "()V"
        local luaj = require "cocos.cocos2d.luaj"
        local className = "org/cocos2dx/lua/AppActivity"
        return luaj.callStaticMethod(className,"thirdSDKExitGame",args,sigs) 
    end
end

function THirdSDKHandler.doShowAdv()
    if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) and LuaTools.CheckJavaMethod("thirdSDKShowAdv") then
        local args = {}
        local sigs = "()V"
        local luaj = require "cocos.cocos2d.luaj"
        local className = "org/cocos2dx/lua/AppActivity"
        return luaj.callStaticMethod(className,"thirdSDKShowAdv",args,sigs) 
    end
end

function THirdSDKHandler.doSDKPay(onSueccCallback, onCancelCallback, onErrorCallback, args)
    local HttpHandler = require("app.network.HttpHandler")
	local PayConfig = require("app.data.PayConfig")
	local conf = {};
	local temp = PayConfig[G_CHANNELID];--根据渠道获取对象sdk配置参数
	for key, value in pairs(temp) do      
		if temp[key] ~= nil then
			conf[key] = temp[key];
		end
	end  
	for key, value in pairs(conf) do      
		if args[key] ~= nil then
			conf[key] = args[key];
		end
	end

    local function succ(args)
        for key, value in pairs(args) do      
            if args[key] ~= nil then
                conf[key] = args[key];
            end
        end
        
        THirdSDKHandler.callSDKPay(onSueccCallback, onCancelCallback, onErrorCallback, json.encode(args), conf)
    end 

    local function fail(args) 
        conf = nil;
    end
    -- dump(conf,"pay info")
    LuaTools.fastRequest(conf,succ,fail,{ 
        disableAlert =true
        })
end

function THirdSDKHandler.doSDKInit(onSueccCallback, onCancelCallback, onErrorCallback, args)
	local HttpHandler = require("app.network.HttpHandler")
	THirdSDKHandler.callSDKInit(onSueccCallback, onCancelCallback, onErrorCallback, json.encode(args))
end

return THirdSDKHandler