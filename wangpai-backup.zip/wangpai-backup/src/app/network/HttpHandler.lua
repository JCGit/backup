--
-- Author: Wayne Dimart (wjweini@gmail.com)
-- Date: 2015-10-27 10:37:22
--
local HttpHandler = class("HttpHandler")
require('cocos.cocos2d.json')
require('cocos.network.NetworkConstants')
require('app.network.rc4')
require('app.network.UNC2UTF8')
--printWarning
HttpHandler.CMDTABLE = {
    LOGIN            =  "account/login",
    GET_DEVICE_ID    =  "account/getDeviceId",
    QUICK_LOGIN      =  "account/createGuest",
    REGISTER         =  "account/createAccount",
    MODIFY_PWD       =  "account/modify_pw",
    BINDING          =  "account/setGuestPhone",
    MODIFY_PHONE     =  "account/modifyPhone",
    SET_PHONE        =  "account/setPhone",
    GET_SMS          =  "account/sendSms",
    FIND_PWD         =  "account/forgetPwd",
    RESET_PWD        =  "account/reset_pwd",
    MODIFY_NICK      =  "account/modify_nick",
    MODIFY_INFO      =  "account/modify_info",
    MODIFY_ICON      =  "account/modify_icon",
    GET_PRODUCT      =  "mall/get_products",
    BUY_PRODUCT      =  "mall/buy_products",
    NEW_PRODUCT      =  'mall/getVipAndProp',
    TRADE_MARKET     =  "trade/market",
    SELL_COINS       =  "trade/sell_coins",
    OFF_MARKET       =  "trade/off_market",
    BUY_COINS        =  "trade/buy_coins",
    SHOP_ACCU        =  "mall/accu_products",
    ACCU_EXCHANGE    =  "mall/accu_exchange",
    TELFEE_EXCHANGE  =  "mall/telfee_exchange",
    GET_FRIEND_LIST  =  'friend/friends',
    ADD_FRIEND       =  'friend/friend_add',
    DEL_FRIEND       =  'friend/friend_del',
    BANK_SETPWD      =  'asset/setBankPwd',
    BANK_CHANGEPWD   =  'asset/changeBankPwd',
    BANK_SAVEMONEY   =  'asset/save_money',
    BANK_DRAWMONEY   =  'asset/draw_money',
    BANK_FINDPWD     =  'asset/retrieveBankPwd',
    SHARE            =  'friendshare',
    THANKSFRIEND     =  'friend/thanks',
    FEEDBACK         =  'operation/feedback',
    NEW_FEEDBACK     =  'operation/add_exception',
    GIFT_CLEAREGGS   =  'asset/clear_egg',
    OPEN_CHEST       =  'asset/open_bag',
    GIFT_GIVE        =  'asset/add_gifts',  -- 赠送礼物
    GIFT_SELL        =  'asset/sale_gifts',
    ACT_ANNOUNCE     =  'activity/get_announcement',
    PRIVATE_GETLIST  =  'proom/getRoomList',
    PRIVATE_CREATE   =  'proom/createroom',
    PRIVATE_DELETE   =  'proom/dismiss',
    GET_WEDDING_LIST =  'marriage/weddingList', --婚礼列表
    CREATE_WED       =  'marriage/create',       --创建婚礼房间
    GET_MERRIED      =  'marriage/marriage',     --结婚 
    DIVORCE          =  'marriage/divorce',      --离婚  
    GET_RANKS        =  'friend/getranks',       --排行
    GET_USERINFOS    =  'account/get_uinfo',     --个人信息   
    SIGN_REWARD      =  'reward/sign_awards',     --签到
    GET_SIGN_REWARD  =  'reward/get_sign_awards',   --领取签到奖励
    ACTIVITY_LIST    =  'activity/activeSummary',   --获取活动列表
    ACTIVITY_PROCCESS=  'activity/activeProccess',  --获取活动详情
    ACTIVITY_NEW     =  'activity/activeRank',      --排行活动接口
    ACTIVITY_GOLD    =  'activity/getUniLuckyNum',  --夺宝：领号码
    ACTIVITY_HADNUMS =  'activity/getMyLuckyNums',  --夺宝：已领号码
    ACTIVITY_WEBLIST =  'activity/activeList',      --网页版活动列表
    ACTIVITY_WEBDEAL =  'activity/activeViews',      --网页版活动详情
    ACTIVITY_ANNOUNCEMENT = 'activity/get_announcement', --公告
    ACTIVITY_UPACKS     ='activity/activeProccess',   --各种礼包
    ACTIVITY_GETUPACKS  ='activity/getGpackActiveReward',--领取各种礼包

    GIFT_EXCHANGE    =  'asset/exchangeCode',     
    GET_ONLINE_REWARD=  'reward/game_online_time',   --领取在线时长奖励
    GET_ONLINE_TIME  =  'reward/game_online_clock',  --存取在线时长
    MAIL_SEND        =  'mail/send_mail', 
    MAIL_GET         =  'mail/get_mails', 
    MAIL_READ        =  'mail/read_mail', 
    MAIL_DEL         =  'mail/del_mail',  
    MAIL_VERFY       =  'mail/friend_verify',  
    MAIL_REWARD      =  'mail/get_reward',  
    GET_TASK         =  'reward/taskProccess',    --获取任务
    GET_TASK_REWARD  =  'reward/taskAward',
    NEW_TASK_REWARD  =  'reward/getScoreTaskAward',
    GET_FREE_COIN    =  'reward/automatic_add_coins',  --破产补助
    GET_VIP_REWARD   =  'task/get_sign_awards',
    GET_HRANKS       =  'rank/getmranks',
    APPLY_MRANKS     =  'rank/apply_mrank',
    GET_GIFTPACK     =  'mall/firstDiscount',   --首冲礼包
    IOS_SHOP         =  'mall/get_products',
    MIT_GETLIST      =  'match/get_mitlist',
    PAY_ALIPAY       =  'pay/wp_aliOrder',
    PAY_YIBAO        =  'payways/payment',
    PAY_WEIXIN_ORDER =  'pay/wp_weixinOrder',
    PAY_WEIXIN       =  'pay/weixinPay',
    PAY_WEIXIN_ORDER1 =  'pay/wp_weixinOrder_GDT',
    PAY_BAIDU        =  'pay/wp_bdzsOrder',

    
    MATCH_ROOMS      =  'game/getRoundsInfo',
    MIT_SIGNUP       =  'match/signup_mit',
    MIT_SIGNOUT      =  'match/signout_mit',
    MIT_GETRESULT    =  'match/get_mitrank',
    SYS_UPDATE       =  'operation/version_upgrade',
    --大转盘  reward
    GET_LOTTERT      =  'luck/zpInfo',
    LOTTERY_ONE      =  'luck/oneTime',
    LOTTERY_TEN      =  'luck/tenTimes',

    --自律书
    selfPromise      = 'account/selfPromise', 

    --比赛场
    MATCH_GAME       = 'match/getMatchList',
    MATCH_SIGHUP     = 'match/regMatch',
    MATCH_CANCEL     = 'match/unRegMatch',
    MATCH_FIRST      = 'match/getFirstPrizeList',


    --新增抢红包
    REDPACKETS_LIST  = 'reward/getDayTaskProcess',
    REDPACKETS_GET   = 'reward/getDayTaskReward',


}

local isovertime = false--超时标示
local scheduler = require("app.models.QScheduler")
local scheduler_hand = nil
function HttpHandler:ctor(ParaTable)
             -- dump(ParaTable)
             dump(ParaTable,'创建了http链接')
  
    if type(ParaTable) ~= 'table' then print("HttpHandler ERROR! the ParaTable is invalid.") return end
    if not ParaTable.cmd or type(ParaTable.cmd) ~= 'string' then print("HttpHandler ERROR! the CMD is invalid.") return end
    local _dataTable = ParaTable or {}
    local _method     = _dataTable.method or 'POST'
    local _dontdecode = _dataTable.dontdecode 
    local _dontencode = _dataTable.dontencode 
    local _dontdejson = _dataTable.dontdejson  
    local _dontenjson = _dataTable.dontenjson  
    local _baseUrl    = _dataTable.baseUrl or DEFAULT_HTTP_URL
    local _callback = _dataTable.callback or function() print("HttpHandler Callback IS NIL.") end
           -- printf('dontdecode:%s',_dontdecode)   
           --  dump(ParaTable)
           --  dump(_dataTable)
    _dataTable.method       =nil
    _dataTable.dontdecode   =nil
    _dataTable.dontencode   =nil
    _dataTable.dontdejson   =nil
    _dataTable.baseUrl      =nil
    _dataTable.dontenjson   =nil

           -- printf('AFTER dontdecode:%s',_dontdecode)


    print("======[HttpHandler Constructor Called!]======")
    self.xhr = cc.XMLHttpRequest:new()
    self.xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_ARRAY_BUFFER
    local httpUrl = _baseUrl..ParaTable.cmd
    print( _baseUrl..ParaTable.cmd)
    _dataTable.cmd=nil

    if _method == "GET" then
        httpUrl = httpUrl .. '?'
        for k,v in pairs(_dataTable) do
            if type(v) == 'number' or type(v) == 'string' then
                httpUrl = httpUrl..k.."="..v.."&"
            end 
        end
    end

        printf("using %s method:%s",_method,httpUrl)
    self.xhr:open(_method,httpUrl)

    local encodedJson = ""
 
    if _dontenjson == true then
        for k,v in pairs(_dataTable) do
            if type(v) == 'number' or type(v) == 'string' then
                encodedJson = encodedJson..k.."="..v.."&"
            end 
        end
    else
        encodedJson = json.encode(_dataTable)
    end
    print("encoded json POST data:"..encodedJson)
    local enc 
    if _dontencode == true then
        enc = encodedJson
    else
        enc = RC4(SHARED_KEY, encodedJson)
    end
    -- print('tttttttttttttttttttttttttttttttt='..enc)

    local function onReadyStateChange()
         
        local response =  self.xhr.response
        local _status = self.xhr.status
        print("status:".._status)
        -- dump(response)
        if self.xhr.readyState == 4 and (self.xhr.status >= 200 and self.xhr.status < 207) then

            local buffer = {}
            for i=1,#response do
                buffer[#buffer+1] = string.char(response[i])
            end
            buffer = table.concat(buffer)

            printf('HttpHandler:buffer::[%s]==>>>>%s',httpUrl,buffer)
            if _dontdecode == true then 
                _callback(buffer)
            else 
                local decoded_data = RC4(SHARED_KEY, buffer)
                print(decoded_data)

                if _dontdejson == true then
                    decoded_data = unicode_to_utf8(decoded_data)
                else  
                    decoded_data = json.decode(unicode_to_utf8(decoded_data)) 
                end
                -- dump(decoded_data,"decoded_data")
                _callback(decoded_data)
            end
        else

            print("xhr.readyState is:", self.xhr.readyState, "xhr.status is: ",self.xhr.status)
            local argTbl = {
                msg = "网络连接不可用",--Network Error (readyState: "..self.xhr.readyState..",status:"..self.xhr.status..")",
                result = "1"
            }
            _callback(argTbl)
        end
    end
     self.xhr:registerScriptHandler(onReadyStateChange)
     self.xhr:send(enc)
end

return HttpHandler
