--
-- Author: Wayne Dimart (wjweini@gmail.com)
-- Date: 2015-10-29 09:44:06
--

local ByteArray = require('app.network.ByteArray')
local ByteBufferManager = class('ByteBufferManager')

function ByteBufferManager:ctor()
	self.byteArray = ByteArray.new(ByteArray.ENDIAN_BIG)
end

function ByteBufferManager:clear()

	self.byteArray=nil
	self.byteArray = ByteArray.new(ByteArray.ENDIAN_BIG)

end

function ByteBufferManager:setHeader(argTable)
	if argTable ~= nil and next(argTable) then
		
	end
end


return ByteBufferManager