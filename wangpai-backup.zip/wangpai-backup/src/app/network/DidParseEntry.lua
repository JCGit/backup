--
-- Author: Wayne Dimart (wjweini@gmail.com)
-- Date: 2015-10-27 10:54:14
--
local  luabit = require"bit"

local ByteArray = require('app.network.ByteArray')
 DidParseEntry = {}

	DidParseEntry.sendMap =  {};
	DidParseEntry.recvMap = {};

function  DidParseEntry.init()
	DidParseEntry.sendMap[0x0] = 0xdc
	DidParseEntry.sendMap[0x1] = 0xe2
	DidParseEntry.sendMap[0x2] = 0xfd
	DidParseEntry.sendMap[0x3] = 0x7c
	DidParseEntry.sendMap[0x4] = 0x56
	DidParseEntry.sendMap[0x5] = 0x51
	DidParseEntry.sendMap[0x6] = 0x6b
	DidParseEntry.sendMap[0x7] = 0xff
	DidParseEntry.sendMap[0x8] = 0xb
	DidParseEntry.sendMap[0x9] = 0x7a
	DidParseEntry.sendMap[0xa] = 0xbd
	DidParseEntry.sendMap[0xb] = 0x99
	DidParseEntry.sendMap[0xc] = 0x5f
	DidParseEntry.sendMap[0xd] = 0xc4
	DidParseEntry.sendMap[0xe] = 0x6c
	DidParseEntry.sendMap[0xf] = 0x2
	DidParseEntry.sendMap[0x10] = 0xd7
	DidParseEntry.sendMap[0x11] = 0xeb
	DidParseEntry.sendMap[0x12] = 0xcf
	DidParseEntry.sendMap[0x13] = 0xc5
	DidParseEntry.sendMap[0x14] = 0xb3
	DidParseEntry.sendMap[0x15] = 0x97
	DidParseEntry.sendMap[0x16] = 0x3b
	DidParseEntry.sendMap[0x17] = 0x54
	DidParseEntry.sendMap[0x18] = 0x36
	DidParseEntry.sendMap[0x19] = 0x72
	DidParseEntry.sendMap[0x1a] = 0x67
	DidParseEntry.sendMap[0x1b] = 0xbb
	DidParseEntry.sendMap[0x1c] = 0xfe
	DidParseEntry.sendMap[0x1d] = 0x4c
	DidParseEntry.sendMap[0x1e] = 0xf
	DidParseEntry.sendMap[0x1f] = 0xe0
	DidParseEntry.sendMap[0x20] = 0xc1
	DidParseEntry.sendMap[0x21] = 0xe8
	DidParseEntry.sendMap[0x22] = 0xa5
	DidParseEntry.sendMap[0x23] = 0x58
	DidParseEntry.sendMap[0x24] = 0x3e
	DidParseEntry.sendMap[0x25] = 0xc9
	DidParseEntry.sendMap[0x26] = 0xfc
	DidParseEntry.sendMap[0x27] = 0xd
	DidParseEntry.sendMap[0x28] = 0x79
	DidParseEntry.sendMap[0x29] = 0x92
	DidParseEntry.sendMap[0x2a] = 0xc7
	DidParseEntry.sendMap[0x2b] = 0xd8
	DidParseEntry.sendMap[0x2c] = 0xea
	DidParseEntry.sendMap[0x2d] = 0x40
	DidParseEntry.sendMap[0x2e] = 0x17
	DidParseEntry.sendMap[0x2f] = 0x89
	DidParseEntry.sendMap[0x30] = 0x2c
	DidParseEntry.sendMap[0x31] = 0x65
	DidParseEntry.sendMap[0x32] = 0x93
	DidParseEntry.sendMap[0x33] = 0x29
	DidParseEntry.sendMap[0x34] = 0xf4
	DidParseEntry.sendMap[0x35] = 0x3f
	DidParseEntry.sendMap[0x36] = 0xee
	DidParseEntry.sendMap[0x37] = 0x96
	DidParseEntry.sendMap[0x38] = 0x6a
	DidParseEntry.sendMap[0x39] = 0xe1
	DidParseEntry.sendMap[0x3a] = 0x60
	DidParseEntry.sendMap[0x3b] = 0x74
	DidParseEntry.sendMap[0x3c] = 0x4e
	DidParseEntry.sendMap[0x3d] = 0x4d
	DidParseEntry.sendMap[0x3e] = 0x95
	DidParseEntry.sendMap[0x3f] = 0x10
	DidParseEntry.sendMap[0x40] = 0xe9
	DidParseEntry.sendMap[0x41] = 0x52
	DidParseEntry.sendMap[0x42] = 0xb4
	DidParseEntry.sendMap[0x43] = 0xf7
	DidParseEntry.sendMap[0x44] = 0x9a
	DidParseEntry.sendMap[0x45] = 0xd5
	DidParseEntry.sendMap[0x46] = 0xdd
	DidParseEntry.sendMap[0x47] = 0xd3
	DidParseEntry.sendMap[0x48] = 0x9d
	DidParseEntry.sendMap[0x49] = 0xd9
	DidParseEntry.sendMap[0x4a] = 0xe7
	DidParseEntry.sendMap[0x4b] = 0x53
	DidParseEntry.sendMap[0x4c] = 0x3d
	DidParseEntry.sendMap[0x4d] = 0x42
	DidParseEntry.sendMap[0x4e] = 0xb8
	DidParseEntry.sendMap[0x4f] = 0x8
	DidParseEntry.sendMap[0x50] = 0xc3
	DidParseEntry.sendMap[0x51] = 0xf8
	DidParseEntry.sendMap[0x52] = 0x30
	DidParseEntry.sendMap[0x53] = 0xa6
	DidParseEntry.sendMap[0x54] = 0xcb
	DidParseEntry.sendMap[0x55] = 0xfb
	DidParseEntry.sendMap[0x56] = 0xaf
	DidParseEntry.sendMap[0x57] = 0x5b
	DidParseEntry.sendMap[0x58] = 0x61
	DidParseEntry.sendMap[0x59] = 0x2f
	DidParseEntry.sendMap[0x5a] = 0x77
	DidParseEntry.sendMap[0x5b] = 0x94
	DidParseEntry.sendMap[0x5c] = 0xba
	DidParseEntry.sendMap[0x5d] = 0xb0
	DidParseEntry.sendMap[0x5e] = 0x76
	DidParseEntry.sendMap[0x5f] = 0xf6
	DidParseEntry.sendMap[0x60] = 0x6
	DidParseEntry.sendMap[0x61] = 0xdf
	DidParseEntry.sendMap[0x62] = 0xb1
	DidParseEntry.sendMap[0x63] = 0x15
	DidParseEntry.sendMap[0x64] = 0xc0
	DidParseEntry.sendMap[0x65] = 0x8f
	DidParseEntry.sendMap[0x66] = 0xc2
	DidParseEntry.sendMap[0x67] = 0xe4
	DidParseEntry.sendMap[0x68] = 0x1f
	DidParseEntry.sendMap[0x69] = 0xf3
	DidParseEntry.sendMap[0x6a] = 0x8d
	DidParseEntry.sendMap[0x6b] = 0x9
	DidParseEntry.sendMap[0x6c] = 0x19
	DidParseEntry.sendMap[0x6d] = 0x12
	DidParseEntry.sendMap[0x6e] = 0x2a
	DidParseEntry.sendMap[0x6f] = 0xa1
	DidParseEntry.sendMap[0x70] = 0xb5
	DidParseEntry.sendMap[0x71] = 0x7f
	DidParseEntry.sendMap[0x72] = 0x13
	DidParseEntry.sendMap[0x73] = 0xa3
	DidParseEntry.sendMap[0x74] = 0x48
	DidParseEntry.sendMap[0x75] = 0x71
	DidParseEntry.sendMap[0x76] = 0x31
	DidParseEntry.sendMap[0x77] = 0xd6
	DidParseEntry.sendMap[0x78] = 0x32
	DidParseEntry.sendMap[0x79] = 0x7d
	DidParseEntry.sendMap[0x7a] = 0xbc
	DidParseEntry.sendMap[0x7b] = 0xb2
	DidParseEntry.sendMap[0x7c] = 0x0
	DidParseEntry.sendMap[0x7d] = 0x37
	DidParseEntry.sendMap[0x7e] = 0x45
	DidParseEntry.sendMap[0x7f] = 0x66
	DidParseEntry.sendMap[0x80] = 0x63
	DidParseEntry.sendMap[0x81] = 0x1b
	DidParseEntry.sendMap[0x82] = 0x21
	DidParseEntry.sendMap[0x83] = 0xab
	DidParseEntry.sendMap[0x84] = 0x75
	DidParseEntry.sendMap[0x85] = 0xd2
	DidParseEntry.sendMap[0x86] = 0x41
	DidParseEntry.sendMap[0x87] = 0xa7
	DidParseEntry.sendMap[0x88] = 0xb9
	DidParseEntry.sendMap[0x89] = 0xdb
	DidParseEntry.sendMap[0x8a] = 0xfa
	DidParseEntry.sendMap[0x8b] = 0xd0
	DidParseEntry.sendMap[0x8c] = 0x25
	DidParseEntry.sendMap[0x8d] = 0x84
	DidParseEntry.sendMap[0x8e] = 0xa8
	DidParseEntry.sendMap[0x8f] = 0x87
	DidParseEntry.sendMap[0x90] = 0x3c
	DidParseEntry.sendMap[0x91] = 0xd4
	DidParseEntry.sendMap[0x92] = 0xf2
	DidParseEntry.sendMap[0x93] = 0x4f
	DidParseEntry.sendMap[0x94] = 0x16
	DidParseEntry.sendMap[0x95] = 0x14
	DidParseEntry.sendMap[0x96] = 0x28
	DidParseEntry.sendMap[0x97] = 0x5d
	DidParseEntry.sendMap[0x98] = 0xbe
	DidParseEntry.sendMap[0x99] = 0x44
	DidParseEntry.sendMap[0x9a] = 0x6f
	DidParseEntry.sendMap[0x9b] = 0x8a
	DidParseEntry.sendMap[0x9c] = 0x2b
	DidParseEntry.sendMap[0x9d] = 0x8b
	DidParseEntry.sendMap[0x9e] = 0x6e
	DidParseEntry.sendMap[0x9f] = 0xa0
	DidParseEntry.sendMap[0xa0] = 0x46
	DidParseEntry.sendMap[0xa1] = 0x50
	DidParseEntry.sendMap[0xa2] = 0x9c
	DidParseEntry.sendMap[0xa3] = 0xca
	DidParseEntry.sendMap[0xa4] = 0xa4
	DidParseEntry.sendMap[0xa5] = 0x38
	DidParseEntry.sendMap[0xa6] = 0xe6
	DidParseEntry.sendMap[0xa7] = 0x2d
	DidParseEntry.sendMap[0xa8] = 0x8c
	DidParseEntry.sendMap[0xa9] = 0xa
	DidParseEntry.sendMap[0xaa] = 0x9b
	DidParseEntry.sendMap[0xab] = 0x78
	DidParseEntry.sendMap[0xac] = 0x80
	DidParseEntry.sendMap[0xad] = 0x5c
	DidParseEntry.sendMap[0xae] = 0xcc
	DidParseEntry.sendMap[0xaf] = 0x4a
	DidParseEntry.sendMap[0xb0] = 0x59
	DidParseEntry.sendMap[0xb1] = 0x5
	DidParseEntry.sendMap[0xb2] = 0x9e
	DidParseEntry.sendMap[0xb3] = 0xc6
	DidParseEntry.sendMap[0xb4] = 0xb6
	DidParseEntry.sendMap[0xb5] = 0x9f
	DidParseEntry.sendMap[0xb6] = 0x55
	DidParseEntry.sendMap[0xb7] = 0x64
	DidParseEntry.sendMap[0xb8] = 0xde
	DidParseEntry.sendMap[0xb9] = 0x18
	DidParseEntry.sendMap[0xba] = 0xac
	DidParseEntry.sendMap[0xbb] = 0x34
	DidParseEntry.sendMap[0xbc] = 0x69
	DidParseEntry.sendMap[0xbd] = 0x3a
	DidParseEntry.sendMap[0xbe] = 0xce
	DidParseEntry.sendMap[0xbf] = 0x11
	DidParseEntry.sendMap[0xc0] = 0xc8
	DidParseEntry.sendMap[0xc1] = 0xe5
	DidParseEntry.sendMap[0xc2] = 0xe
	DidParseEntry.sendMap[0xc3] = 0xec
	DidParseEntry.sendMap[0xc4] = 0xef
	DidParseEntry.sendMap[0xc5] = 0x27
	DidParseEntry.sendMap[0xc6] = 0x7e
	DidParseEntry.sendMap[0xc7] = 0x8e
	DidParseEntry.sendMap[0xc8] = 0x1a
	DidParseEntry.sendMap[0xc9] = 0x6d
	DidParseEntry.sendMap[0xca] = 0x1c
	DidParseEntry.sendMap[0xcb] = 0x2e
	DidParseEntry.sendMap[0xcc] = 0x35
	DidParseEntry.sendMap[0xcd] = 0x86
	DidParseEntry.sendMap[0xce] = 0xb7
	DidParseEntry.sendMap[0xcf] = 0x4
	DidParseEntry.sendMap[0xd0] = 0xf9
	DidParseEntry.sendMap[0xd1] = 0x82
	DidParseEntry.sendMap[0xd2] = 0x39
	DidParseEntry.sendMap[0xd3] = 0xf5
	DidParseEntry.sendMap[0xd4] = 0x90
	DidParseEntry.sendMap[0xd5] = 0x83
	DidParseEntry.sendMap[0xd6] = 0x5e
	DidParseEntry.sendMap[0xd7] = 0x98
	DidParseEntry.sendMap[0xd8] = 0x26
	DidParseEntry.sendMap[0xd9] = 0x1d
	DidParseEntry.sendMap[0xda] = 0x43
	DidParseEntry.sendMap[0xdb] = 0x91
	DidParseEntry.sendMap[0xdc] = 0x22
	DidParseEntry.sendMap[0xdd] = 0x81
	DidParseEntry.sendMap[0xde] = 0xae
	DidParseEntry.sendMap[0xdf] = 0xd1
	DidParseEntry.sendMap[0xe0] = 0xe3
	DidParseEntry.sendMap[0xe1] = 0x23
	DidParseEntry.sendMap[0xe2] = 0xa2
	DidParseEntry.sendMap[0xe3] = 0x70
	DidParseEntry.sendMap[0xe4] = 0x57
	DidParseEntry.sendMap[0xe5] = 0x62
	DidParseEntry.sendMap[0xe6] = 0x24
	DidParseEntry.sendMap[0xe7] = 0xf0
	DidParseEntry.sendMap[0xe8] = 0x5a
	DidParseEntry.sendMap[0xe9] = 0xaa
	DidParseEntry.sendMap[0xea] = 0xcd
	DidParseEntry.sendMap[0xeb] = 0x1
	DidParseEntry.sendMap[0xec] = 0x7
	DidParseEntry.sendMap[0xed] = 0x20
	DidParseEntry.sendMap[0xee] = 0xda
	DidParseEntry.sendMap[0xef] = 0xf1
	DidParseEntry.sendMap[0xf0] = 0x88
	DidParseEntry.sendMap[0xf1] = 0xed
	DidParseEntry.sendMap[0xf2] = 0xc
	DidParseEntry.sendMap[0xf3] = 0x49
	DidParseEntry.sendMap[0xf4] = 0x3
	DidParseEntry.sendMap[0xf5] = 0x73
	DidParseEntry.sendMap[0xf6] = 0x4b
	DidParseEntry.sendMap[0xf7] = 0x47
	DidParseEntry.sendMap[0xf8] = 0x7b
	DidParseEntry.sendMap[0xf9] = 0x68
	DidParseEntry.sendMap[0xfa] = 0xbf
	DidParseEntry.sendMap[0xfb] = 0x85
	DidParseEntry.sendMap[0xfc] = 0x33
	DidParseEntry.sendMap[0xfd] = 0x1e
	DidParseEntry.sendMap[0xfe] = 0xa9
	DidParseEntry.sendMap[0xff] = 0xad

	DidParseEntry.recvMap[0xc4] = 0x0
	DidParseEntry.recvMap[0xe2] = 0x1
	DidParseEntry.recvMap[0x24] = 0x2
	DidParseEntry.recvMap[0xc8] = 0x3
	DidParseEntry.recvMap[0x12] = 0x4
	DidParseEntry.recvMap[0x16] = 0x5
	DidParseEntry.recvMap[0x2d] = 0x6
	DidParseEntry.recvMap[0x15] = 0x7
	DidParseEntry.recvMap[0xa5] = 0x8
	DidParseEntry.recvMap[0xc7] = 0x9
	DidParseEntry.recvMap[0xbb] = 0xa
	DidParseEntry.recvMap[0xe5] = 0xb
	DidParseEntry.recvMap[0xfe] = 0xc
	DidParseEntry.recvMap[0x50] = 0xd
	DidParseEntry.recvMap[0x1f] = 0xe
	DidParseEntry.recvMap[0x4b] = 0xf
	DidParseEntry.recvMap[0xf1] = 0x10
	DidParseEntry.recvMap[0x30] = 0x11
	DidParseEntry.recvMap[0xf] = 0x12
	DidParseEntry.recvMap[0xd2] = 0x13
	DidParseEntry.recvMap[0x58] = 0x14
	DidParseEntry.recvMap[0x8] = 0x15
	DidParseEntry.recvMap[0x25] = 0x16
	DidParseEntry.recvMap[0xe7] = 0x17
	DidParseEntry.recvMap[0x40] = 0x18
	DidParseEntry.recvMap[0x2f] = 0x19
	DidParseEntry.recvMap[0x96] = 0x1a
	DidParseEntry.recvMap[0x83] = 0x1b
	DidParseEntry.recvMap[0xb9] = 0x1c
	DidParseEntry.recvMap[0x7f] = 0x1d
	DidParseEntry.recvMap[0xab] = 0x1e
	DidParseEntry.recvMap[0xaf] = 0x1f
	DidParseEntry.recvMap[0x10] = 0x20
	DidParseEntry.recvMap[0x9b] = 0x21
	DidParseEntry.recvMap[0x90] = 0x22
	DidParseEntry.recvMap[0x6f] = 0x23
	DidParseEntry.recvMap[0xa2] = 0x24
	DidParseEntry.recvMap[0x8d] = 0x25
	DidParseEntry.recvMap[0x85] = 0x26
	DidParseEntry.recvMap[0x91] = 0x27
	DidParseEntry.recvMap[0x81] = 0x28
	DidParseEntry.recvMap[0xce] = 0x29
	DidParseEntry.recvMap[0x61] = 0x2a
	DidParseEntry.recvMap[0xb5] = 0x2b
	DidParseEntry.recvMap[0xff] = 0x2c
	DidParseEntry.recvMap[0xfa] = 0x2d
	DidParseEntry.recvMap[0x98] = 0x2e
	DidParseEntry.recvMap[0x38] = 0x2f
	DidParseEntry.recvMap[0x26] = 0x30
	DidParseEntry.recvMap[0x33] = 0x31
	DidParseEntry.recvMap[0xc5] = 0x32
	DidParseEntry.recvMap[0x57] = 0x33
	DidParseEntry.recvMap[0x4f] = 0x34
	DidParseEntry.recvMap[0x27] = 0x35
	DidParseEntry.recvMap[0xd1] = 0x36
	DidParseEntry.recvMap[0xba] = 0x37
	DidParseEntry.recvMap[0x5d] = 0x38
	DidParseEntry.recvMap[0x37] = 0x39
	DidParseEntry.recvMap[0x9e] = 0x3a
	DidParseEntry.recvMap[0x5] = 0x3b
	DidParseEntry.recvMap[0x3b] = 0x3c
	DidParseEntry.recvMap[0x80] = 0x3d
	DidParseEntry.recvMap[0x69] = 0x3e
	DidParseEntry.recvMap[0x6a] = 0x3f
	DidParseEntry.recvMap[0xad] = 0x40
	DidParseEntry.recvMap[0x86] = 0x41
	DidParseEntry.recvMap[0xf0] = 0x42
	DidParseEntry.recvMap[0x5c] = 0x43
	DidParseEntry.recvMap[0x2c] = 0x44
	DidParseEntry.recvMap[0xe6] = 0x45
	DidParseEntry.recvMap[0x51] = 0x46
	DidParseEntry.recvMap[0x34] = 0x47
	DidParseEntry.recvMap[0xf3] = 0x48
	DidParseEntry.recvMap[0x1c] = 0x49
	DidParseEntry.recvMap[0x8f] = 0x4a
	DidParseEntry.recvMap[0x4d] = 0x4b
	DidParseEntry.recvMap[0xa7] = 0x4c
	DidParseEntry.recvMap[0x53] = 0x4d
	DidParseEntry.recvMap[0x21] = 0x4e
	DidParseEntry.recvMap[0xc] = 0x4f
	DidParseEntry.recvMap[0x6] = 0x50
	DidParseEntry.recvMap[0xcc] = 0x51
	DidParseEntry.recvMap[0x66] = 0x52
	DidParseEntry.recvMap[0xaa] = 0x53
	DidParseEntry.recvMap[0xd9] = 0x54
	DidParseEntry.recvMap[0x79] = 0x55
	DidParseEntry.recvMap[0xa9] = 0x56
	DidParseEntry.recvMap[0x65] = 0x57
	DidParseEntry.recvMap[0x56] = 0x58
	DidParseEntry.recvMap[0x60] = 0x59
	DidParseEntry.recvMap[0xb] = 0x5a
	DidParseEntry.recvMap[0x36] = 0x5b
	DidParseEntry.recvMap[0xbd] = 0x5c
	DidParseEntry.recvMap[0x8e] = 0x5d
	DidParseEntry.recvMap[0x19] = 0x5e
	DidParseEntry.recvMap[0x7e] = 0x5f
	DidParseEntry.recvMap[0x99] = 0x60
	DidParseEntry.recvMap[0xc3] = 0x61
	DidParseEntry.recvMap[0x3d] = 0x62
	DidParseEntry.recvMap[0x2] = 0x63
	DidParseEntry.recvMap[0xa0] = 0x64
	DidParseEntry.recvMap[0x9c] = 0x65
	DidParseEntry.recvMap[0xd7] = 0x66
	DidParseEntry.recvMap[0x29] = 0x67
	DidParseEntry.recvMap[0x3] = 0x68
	DidParseEntry.recvMap[0xee] = 0x69
	DidParseEntry.recvMap[0x2b] = 0x6a
	DidParseEntry.recvMap[0xa8] = 0x6b
	DidParseEntry.recvMap[0x5b] = 0x6c
	DidParseEntry.recvMap[0xa] = 0x6d
	DidParseEntry.recvMap[0x35] = 0x6e
	DidParseEntry.recvMap[0x97] = 0x6f
	DidParseEntry.recvMap[0x0] = 0x70
	DidParseEntry.recvMap[0x47] = 0x71
	DidParseEntry.recvMap[0x42] = 0x72
	DidParseEntry.recvMap[0x82] = 0x73
	DidParseEntry.recvMap[0xb2] = 0x74
	DidParseEntry.recvMap[0xc2] = 0x75
	DidParseEntry.recvMap[0x48] = 0x76
	DidParseEntry.recvMap[0x7b] = 0x77
	DidParseEntry.recvMap[0x77] = 0x78
	DidParseEntry.recvMap[0xed] = 0x79
	DidParseEntry.recvMap[0x2e] = 0x7a
	DidParseEntry.recvMap[0x95] = 0x7b
	DidParseEntry.recvMap[0x31] = 0x7c
	DidParseEntry.recvMap[0xfb] = 0x7d
	DidParseEntry.recvMap[0x14] = 0x7e
	DidParseEntry.recvMap[0xd8] = 0x7f
	DidParseEntry.recvMap[0xd5] = 0x80
	DidParseEntry.recvMap[0x4a] = 0x81
	DidParseEntry.recvMap[0xde] = 0x82
	DidParseEntry.recvMap[0xe1] = 0x83
	DidParseEntry.recvMap[0x11] = 0x84
	DidParseEntry.recvMap[0x1d] = 0x85
	DidParseEntry.recvMap[0xf5] = 0x86
	DidParseEntry.recvMap[0x22] = 0x87
	DidParseEntry.recvMap[0x73] = 0x88
	DidParseEntry.recvMap[0x18] = 0x89
	DidParseEntry.recvMap[0x55] = 0x8a
	DidParseEntry.recvMap[0xcb] = 0x8b
	DidParseEntry.recvMap[0x9d] = 0x8c
	DidParseEntry.recvMap[0x32] = 0x8d
	DidParseEntry.recvMap[0xc0] = 0x8e
	DidParseEntry.recvMap[0x5a] = 0x8f
	DidParseEntry.recvMap[0xbe] = 0x90
	DidParseEntry.recvMap[0xdd] = 0x91
	DidParseEntry.recvMap[0x43] = 0x92
	DidParseEntry.recvMap[0x68] = 0x93
	DidParseEntry.recvMap[0xa3] = 0x94
	DidParseEntry.recvMap[0xf2] = 0x95
	DidParseEntry.recvMap[0x6b] = 0x96
	DidParseEntry.recvMap[0xdf] = 0x97
	DidParseEntry.recvMap[0x45] = 0x98
	DidParseEntry.recvMap[0xe9] = 0x99
	DidParseEntry.recvMap[0xe] = 0x9a
	DidParseEntry.recvMap[0x1b] = 0x9b
	DidParseEntry.recvMap[0x3f] = 0x9c
	DidParseEntry.recvMap[0xe3] = 0x9d
	DidParseEntry.recvMap[0xac] = 0x9e
	DidParseEntry.recvMap[0xc6] = 0x9f
	DidParseEntry.recvMap[0xf4] = 0xa0
	DidParseEntry.recvMap[0x1] = 0xa1
	DidParseEntry.recvMap[0x8a] = 0xa2
	DidParseEntry.recvMap[0xef] = 0xa3
	DidParseEntry.recvMap[0x28] = 0xa4
	DidParseEntry.recvMap[0x9a] = 0xa5
	DidParseEntry.recvMap[0xe4] = 0xa6
	DidParseEntry.recvMap[0x1a] = 0xa7
	DidParseEntry.recvMap[0xa4] = 0xa8
	DidParseEntry.recvMap[0x49] = 0xa9
	DidParseEntry.recvMap[0xc1] = 0xaa
	DidParseEntry.recvMap[0xf7] = 0xab
	DidParseEntry.recvMap[0x1e] = 0xac
	DidParseEntry.recvMap[0xd3] = 0xad
	DidParseEntry.recvMap[0xb7] = 0xae
	DidParseEntry.recvMap[0x75] = 0xaf
	DidParseEntry.recvMap[0xeb] = 0xb0
	DidParseEntry.recvMap[0x52] = 0xb1
	DidParseEntry.recvMap[0x6d] = 0xb2
	DidParseEntry.recvMap[0x4c] = 0xb3
	DidParseEntry.recvMap[0x62] = 0xb4
	DidParseEntry.recvMap[0x17] = 0xb5
	DidParseEntry.recvMap[0x89] = 0xb6
	DidParseEntry.recvMap[0xca] = 0xb7
	DidParseEntry.recvMap[0x9f] = 0xb8
	DidParseEntry.recvMap[0x6e] = 0xb9
	DidParseEntry.recvMap[0xd] = 0xba
	DidParseEntry.recvMap[0xbc] = 0xbb
	DidParseEntry.recvMap[0xf6] = 0xbc
	DidParseEntry.recvMap[0x63] = 0xbd
	DidParseEntry.recvMap[0x59] = 0xbe
	DidParseEntry.recvMap[0xb3] = 0xbf
	DidParseEntry.recvMap[0xdc] = 0xc0
	DidParseEntry.recvMap[0x23] = 0xc1
	DidParseEntry.recvMap[0x70] = 0xc2
	DidParseEntry.recvMap[0x2a] = 0xc3
	DidParseEntry.recvMap[0x39] = 0xc4
	DidParseEntry.recvMap[0x88] = 0xc5
	DidParseEntry.recvMap[0x7] = 0xc6
	DidParseEntry.recvMap[0x3e] = 0xc7
	DidParseEntry.recvMap[0xcd] = 0xc8
	DidParseEntry.recvMap[0x3a] = 0xc9
	DidParseEntry.recvMap[0xfd] = 0xca
	DidParseEntry.recvMap[0x92] = 0xcb
	DidParseEntry.recvMap[0x41] = 0xcc
	DidParseEntry.recvMap[0xcf] = 0xcd
	DidParseEntry.recvMap[0xd6] = 0xce
	DidParseEntry.recvMap[0x7d] = 0xcf
	DidParseEntry.recvMap[0xf8] = 0xd0
	DidParseEntry.recvMap[0xd0] = 0xd1
	DidParseEntry.recvMap[0x3c] = 0xd2
	DidParseEntry.recvMap[0x4e] = 0xd3
	DidParseEntry.recvMap[0xea] = 0xd4
	DidParseEntry.recvMap[0x20] = 0xd5
	DidParseEntry.recvMap[0xd4] = 0xd6
	DidParseEntry.recvMap[0x7c] = 0xd7
	DidParseEntry.recvMap[0x64] = 0xd8
	DidParseEntry.recvMap[0xb8] = 0xd9
	DidParseEntry.recvMap[0xa1] = 0xda
	DidParseEntry.recvMap[0x93] = 0xdb
	DidParseEntry.recvMap[0xb4] = 0xdc
	DidParseEntry.recvMap[0xec] = 0xdd
	DidParseEntry.recvMap[0x76] = 0xde
	DidParseEntry.recvMap[0xe0] = 0xdf
	DidParseEntry.recvMap[0x74] = 0xe0
	DidParseEntry.recvMap[0xdb] = 0xe1
	DidParseEntry.recvMap[0x8c] = 0xe2
	DidParseEntry.recvMap[0xae] = 0xe3
	DidParseEntry.recvMap[0x72] = 0xe4
	DidParseEntry.recvMap[0xb6] = 0xe5
	DidParseEntry.recvMap[0x94] = 0xe6
	DidParseEntry.recvMap[0x46] = 0xe7
	DidParseEntry.recvMap[0x9] = 0xe8
	DidParseEntry.recvMap[0xe8] = 0xe9
	DidParseEntry.recvMap[0x7a] = 0xea
	DidParseEntry.recvMap[0xfc] = 0xeb
	DidParseEntry.recvMap[0x5f] = 0xec
	DidParseEntry.recvMap[0x5e] = 0xed
	DidParseEntry.recvMap[0xc9] = 0xee
	DidParseEntry.recvMap[0x4] = 0xef
	DidParseEntry.recvMap[0x44] = 0xf0
	DidParseEntry.recvMap[0x67] = 0xf1
	DidParseEntry.recvMap[0x78] = 0xf2
	DidParseEntry.recvMap[0x13] = 0xf3
	DidParseEntry.recvMap[0xb1] = 0xf4
	DidParseEntry.recvMap[0xb0] = 0xf5
	DidParseEntry.recvMap[0xf9] = 0xf6
	DidParseEntry.recvMap[0x6c] = 0xf7
	DidParseEntry.recvMap[0x71] = 0xf8
	DidParseEntry.recvMap[0xa6] = 0xf9
	DidParseEntry.recvMap[0x87] = 0xfa
	DidParseEntry.recvMap[0x8b] = 0xfb
	DidParseEntry.recvMap[0xda] = 0xfc
	DidParseEntry.recvMap[0xbf] = 0xfd
	DidParseEntry.recvMap[0x84] = 0xfe
	DidParseEntry.recvMap[0x54] = 0xff
		 
end

function DidParseEntry.EncryptBufferNoCC(b,  nbegin,  dataSize)
	DidParseEntry.init();

	local tStr = {}
	print('=========BEGIN DidParseEntry EncryptBufferNoCC=============')
	for i=nbegin,dataSize do  
		tStr[i] = (DidParseEntry.MapSendByte(b[i], DidParseEntry.sendMap))
		--printf("enOut[%d]:%s", i,tStr[i])
	end 
	print('=========END DidParseEntry EncryptBufferNoCC=============')
    return  table.concat(tStr)
end

function DidParseEntry.CrevasseBufferNoCC(b, nbegin,  wDataSize)
	--DidParseEntry.init();
	DidSaveEntry.init();
	local tStr = {}
	print('=========BEGIN DidParseEntry CrevasseBufferNoCC=============')
	for i=nbegin,wDataSize do
		tStr[i] = (DidParseEntry.MapRecvByte(b[i], DidSaveEntry.recvMap))  
		--printf("enOut[%d]:%s", i,tStr[i])	
	end
	print('=========END DidParseEntry CrevasseBufferNoCC=============')
	return tStr
end

function DidParseEntry.CrevasseBufferNoCCOld(b, nbegin,  wDataSize)
	DidParseEntry.init();
	--DidSaveEntry.init();
	local tStr = {}
	-- print('=========BEGIN DidParseEntry CrevasseBufferNoCC=============')
	-- dump(DidParseEntry.recvMap,'999999999999999999999999')
	for i=nbegin,wDataSize do
		tStr[i] = (DidParseEntry.MapRecvByte(b[i], DidParseEntry.recvMap))  
		--printf("enOut[%d]:%s", i,tStr[i])	
	end
	print('=========END DidParseEntry CrevasseBufferNoCC=============')
	return tStr
end


function DidParseEntry.EncryptBuffer(b,  nbegin,  dataSize,  sendMap)
	DidParseEntry.init();
	local cbCheckCode = 0; 
	--convert to table first


	local tStr = {}
	for i=nbegin,dataSize  do
	    tStr[i] = b:sub(i, i)
	end 

	for i=nbegin,dataSize do  
		cbCheckCode = cbCheckCode + DidParseEntry.toUnsign(string.byte(tStr[i]))

		local before = string.byte(tStr[i])
		tStr[i] = string.char(DidParseEntry.MapSendByte(string.byte(tStr[i]), sendMap)) 

		--printf("CLUA ENCODEING (%02X) => (%02X) ",before, string.byte(tStr[i]) );
	end 
	cbCheckCode=luabit.bnot(cbCheckCode)+1 
    return  DidParseEntry.inttochar(cbCheckCode),table.concat(tStr)
end

function  DidParseEntry.inttochar(int) 
	return luabit.band(int,0xFF)
end

function  DidParseEntry.CrevasseBuffer(b,  nbegin,  wDataSize,  cbCheckCode,  recvMap)
	DidParseEntry.init();
     
	local tStr = {}
	for i=1,wDataSize  do
	    tStr[i] = b:sub(i, i)
	end 

 
	for i=1,#tStr do
		tStr[i] = string.char(DidParseEntry.MapRecvByte(string.byte(tStr[i]), recvMap))  
		cbCheckCode  =    cbCheckCode+DidParseEntry.toUnsign( string.byte(tStr[i]) )   
		cbCheckCode = cbCheckCode/256;
		-- print('tStr['..i..']:'..tStr[i])
	end
	-- for (int i = nbegin; i < wDataSize; i++) {
	-- 	b[i] = (char) MapRecvByte(b[i], recvMap);
	-- 	cbCheckCode += toUnsign(b[i]);
	-- 	cbCheckCode /= 256;
	-- }
	return DidParseEntry.inttochar(cbCheckCode),table.concat(tStr);
end

function  DidParseEntry.toUnsign(oldByte) 
	local ret = 0
	local b = oldByte
	local c = 0
	c = luabit.band(b,0x7f)
	if b < 0 then
		ret = 128;
	end 
	-- printf("LUA toUnsign b:%02X,c:%02X,ret:%02X (returning oldByte directlly:%d)",b,c,ret + c,oldByte)
	return oldByte--ret + c;
end

function  DidParseEntry.MapSendByte( cbData, sendMap)
	cbData = DidParseEntry.toUnsign(cbData);
	return sendMap[cbData];
end
function  DidParseEntry.MapRecvByte( cbData,  recvMap)
	cbData = DidParseEntry.toUnsign(cbData);
	return recvMap[cbData];
end

