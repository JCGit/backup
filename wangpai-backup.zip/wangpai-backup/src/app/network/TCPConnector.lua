--
-- Author: Wayne Dimart (wjweini@gmail.com)
-- Date: 2015-10-28 16:46:58
-- 
local SocketTCP = require("app.network.SocketTCP")  
local ByteArray = require("app.network.ByteArray") 
local TCPConnector = class("TCPConnector") 
local DataUnpacker = require('app.network.DataUnpacker')

	function TCPConnector:connect()
		 self.socket:connect()
	end

	function TCPConnector:disconnect()
		print("DISCONNECTING.....")
		self.socket:disconnect()
		self.socket:removeAllEventListeners()
		dump(self.socket)
		print("DONE DISCONNECTING.")
	end

	function TCPConnector:removeAllEventListeners()
		self.socket:removeAllEventListeners()
	end

	function TCPConnector:close()
		self.socket:close()
	end

	function TCPConnector:getSocket()
		return self.socket
	end


	function TCPConnector:sendData(bufferArray) 
		self.socket:send(bufferArray)
	end


	function TCPConnector:status(__event)

		-- dump(__event,"__event")
		-- echoInfo("status") 
		if self.listenerTable and self.listenerTable.status then
			 self.listenerTable.status(__event)
		end
		 
	end


	function TCPConnector:readShort(str)
		return ByteArray.new(ByteArray.ENDIAN_BIG):writeStringBytes(str):setPos(1):readShort()
	end
 

	function TCPConnector:onData(__event)
--		 dump(__event,"ONDATA __event")
        
		if self.listenerTable.data then
		 	self.listenerTable.data(__event)
		end 
	end
 

	function TCPConnector:setListeners(listenerTable)

		self.listenerTable = listenerTable 
        self.socket:addEventListener(SocketTCP.EVENT_CONNECTED, handler(self,self.status))
        self.socket:addEventListener(SocketTCP.EVENT_CLOSE, handler(self,self.status))
        self.socket:addEventListener(SocketTCP.EVENT_CLOSED, handler(self,self.status))
        self.socket:addEventListener(SocketTCP.EVENT_CONNECT_FAILURE, handler(self,self.status))
        self.socket:addEventListener(SocketTCP.EVENT_DATA, handler(self,self.onData))
	end
	function TCPConnector:ctor(ip,port,retryConnectWhenFailure,dontUnpackMsg) 
		self.dontUnpackMsg = dontUnpackMsg 
		self.ip = ip
		self.port = port
		self.retryIfFailure = retryConnectWhenFailure		
		self.socket = SocketTCP.new(ip,port,retryConnectWhenFailure)  
        local scheduler = require("app.models.QScheduler")

 
	end


return TCPConnector