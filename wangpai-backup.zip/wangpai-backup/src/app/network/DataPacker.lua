--
-- Author: Wayne Dimart (wjweini@gmail.com)
-- Date: 2015-10-29 14:48:09
--
local DataPacker = class('DataPacker')
local ByteArray = require('app.network.ByteArray')
require('app.network.BufferEncrypt')
DataPacker.BYTE='Byte'
DataPacker.SHORT='Short'
DataPacker.INT='Int'
DataPacker.LONG='Long' 

DataPacker.UBYTE='UByte'
DataPacker.USHORT='UShort'
DataPacker.UINT='UInt'
DataPacker.ULONG='ULong' 
DataPacker.STRING='String' 
DataPacker.HEADER_SIZE = 6
 

function DataPacker:ctor(CMD,extra)
	extra = extra or {}
	self.dataList = {}
	self.contentBuffer = ''
	self.headerTable = {}
	self.headerBuffer = ''
	self.packageLenth = 0
	self.gameID = 0
	self.cmd = CMD
	self.protocalVersion = extra.protocalVersion or 0
	self.checkCode = 0
	self.packed = false
	self.byteArrayContent = ByteArray.new(ByteArray.ENDIAN_BIG)
	self.byteArrayHeader = ByteArray.new(ByteArray.ENDIAN_BIG) 

	--setup header

end

function DataPacker:dumpPackage() 
	if self.packed == true then
		printError("Failed to dump package buffer. You must pack you data first. try call doPack()")
		return
	end
	local buf = ByteArray.new(ByteArray.ENDIAN_BIG)
	buf:writeString(self.fullPackageBuffer)
	print("[ "..buf:toString().."]")
end

function DataPacker:getPackageBuffer()

	if self.packed == true then
		printError("Failed to get package buffer. You must pack you data first. try call doPack()")
		return
	end
	return self.fullPackageBuffer
end

function DataPacker:getPackageBufferLength()
	if self.packed == true then
		printError("Failed to get package buffer length. You must pack you data first. try call doPack()")
		return
	end
	return self.packageLenth
end

function DataPacker:doPack()

	--clear buffer builder

	self.byteArrayContent = ByteArray.new(ByteArray.ENDIAN_BIG)
	self.byteArrayHeader = ByteArray.new(ByteArray.ENDIAN_BIG)

	--content process
	for k,v in pairs(self.dataList) do 
		if v.type == DataPacker.STRING then
			local stringLenth = string.len(v.val)
			self.byteArrayContent:writeShort(stringLenth)
			self.byteArrayContent:writeString(v.val)
		else
			self.byteArrayContent['write'..v.type](self.byteArrayContent,v.val)
		end 
		-- printf("DataPacker Packing %s as %s using %s method. ",v.val,v.type,'write'..v.type) 
	end

	local contentBufferLength = self.byteArrayContent:getLen()
	self.contentBuffer = self.byteArrayContent:getPack()
	self.packageLenth = contentBufferLength + DataPacker.HEADER_SIZE
--	print("data before encrypt lua"..self.byteArrayContent:toString())
	-- print(BufferEncrypt.inttochar(-2947))
	self.checkCode ,self.contentBuffer= BufferEncrypt.EncryptBuffer(self.contentBuffer,  1,  contentBufferLength,  BufferEncrypt.sendMap)

	--print('cbCheckCode:'..self.checkCode)
	--WRITE DATA 
	self.byteArrayHeader:writeShort(self.packageLenth)
	self.byteArrayHeader:writeByte(self.gameID)
	self.byteArrayHeader:writeByte(self.cmd)
	self.byteArrayHeader:writeByte(self.protocalVersion)
	self.byteArrayHeader:writeByte(self.checkCode)
	
	self.headerBuffer = self.byteArrayHeader:getPack()
	local ret = self.headerBuffer .. self.contentBuffer 
	self.fullPackageBuffer = ret
	-- printf('DUMPING HEADER...\n%s',self.byteArrayHeader:toString())

	-- local encrypted = ByteArray.new(ByteArray.ENDIAN_BIG)
	-- encrypted:writeBuf(self.contentBuffer)
	-- printf('DUMPING CONTENT...\n%s',encrypted:toString())

	-- print('self.headerBuffer:'..self.headerBuffer)
	-- print('self.contentBuffer:'..self.contentBuffer)
	-- print("Packed Data:"..ret)
	-- print("Packed Size:"..self.packageLenth)
	-- print("Packed checkCode:"..self.checkCode) 
	--print("DATA READY FOR SERVER LUA")
	-- self:dumpPackage() 

	self.packed=true
	return ret
 
end

function DataPacker:writeData(data,dataType) 
	if self.packed == true then
		printError("You can not write data once you've pack your data. Please create a new instance.")
		return
	end
	table.insert(self.dataList, {type = dataType,val = data})
end
 
return DataPacker