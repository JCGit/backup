TCPGearbox = class('TCPGearbox')
TCPGearbox.pool = {}
local DataUnpacker = require('app.network.DataUnpacker') 
 require('cocos.cocos2d.json')
TCPGearbox.badNetwork = nil

TCPGearbox.enableLog = true
TCPGearbox.connFailureCount = 0
--   三张牌
--   TableType_Primary int8     = 60  //初级场
--   TableType_Middle  int8     = 61  //中级场
--   TableType_Advance int8     = 62  //高级场
--   TableType_Super int8       = 63  //至尊场
--   TableType_Prop   int8      = 64  //道具场
--   TableType_CloseLook   int8 = 65 //闷比场
--   五人斗牛
--   TableType_BullFight_Primary   int8 = 48 //五人斗牛场初级
--   TableType_BullFight   int8         = 49 //五人斗牛场中级
--   TableType_BullFight_Advance   int8 = 50 //五人斗牛场高级
--   TableType_BullFight_Super   int8   = 51 //五人斗牛场至尊
        -- 斗地主
         
function TCPGearbox.setup()  
	-- TCPGearbox.serverConfig = json.decode(server_config)
	-- dump(TCPGearbox.serverConfig.config.sites,"TCPGearbox.serverConfig,")
	LuaTools.registerNetworkStatus(function(status) 
    printf('-------------ON NETWORK STATUS CHANGE-------------')
    printf('--------------------------------------------------')
    printf('--------------------------------------------------')
    printf('---------------------[%s]--------------',status)
    printf('--------------------------------------------------')
    printf('--------------------------------------------------')
    printf('--------------------------------------------------')
    printf('--------------------------------------------------')
	 	if status == 'none' then
	 		TCPGearbox.networkNotAvailable = true
	 		if TCPGearbox.connFailureCount <= 0 then
	 			TCPGearbox.badNetwork = G_BASEAPP:addView('UIWaiting',999999,true,'当前无网络连接，请确认网络',1,true)
	 		end
      TCPGearbox.connFailureCount= TCPGearbox.connFailureCount + 1 
      printf('registerNetworkStatus TCPGearbox.connFailureCount increased:%d',TCPGearbox.connFailureCount)
	 	else --status == 'none'
      TCPGearbox.connFailureCount = TCPGearbox.connFailureCount-1
      TCPGearbox.networkNotAvailable = nil 
      if TCPGearbox.connFailureCount <= 0 then
        TCPGearbox.connFailureCount = 0
        if TCPGearbox.badNetwork and tolua.isnull(TCPGearbox.badNetwork) == false then
          TCPGearbox.badNetwork:removeSelf()
          TCPGearbox.badNetwork = nil
        end 
      end --TCPGearbox.connFailureCount == 0   
      printf('registerNetworkStatus TCPGearbox.connFailureCount decreased:%d',TCPGearbox.connFailureCount)

	 	end --status == 'none'
	end)
end
-- TCPGearbox.setup()


function TCPGearbox.getInstanceByName(name)  
	return TCPGearbox.pool[name]
end


function TCPGearbox:setDelegate(delegate)  
	self.delegate = delegate
end

function TCPGearbox:sendData(data)   
	self.tcpManager:enqueueDataForSending(data)
end

function TCPGearbox:closeAndRelease(delay)   
  delay = delay or 0.2

    printf('%s is releasing',self.name)
  local scheduler = require("app.models.QScheduler")
  scheduler.performWithDelayGlobal(function() 
    self.tcpManager:release() 
    -- print("before release")
    for k,v in pairs(TCPGearbox.pool) do
      print(k,v)
    end
    TCPGearbox.pool[self.name] = nil
    -- print("after release")
    for k,v in pairs(TCPGearbox.pool) do
      print(k,v)
    end

    printf('%s is released',self.name)
    self = nil
  end,delay)
 
end
function TCPGearbox.log(...)
	if TCPGearbox.enableLog then
		printf(...)
	end
end

function TCPGearbox.buildInstance(argTable)
  dump(argTable, 'TCPGearbox.buildInstance')
	if argTable and argTable.name and TCPGearbox.pool[argTable.name]  then
		local ret = TCPGearbox.pool[argTable.name]
		printf("The gearbox instance %s with name %s exists, returning existing instance.",ret,ret.name)
		return ret
	end
	return TCPGearbox.new(argTable)
end

function TCPGearbox:ctor(argTable)  
	if argTable then
		-- self.tcpManager 			= argTable.tcpManager
		self.unpackerType 			= argTable.unpackerType 
		self.delegate 				= argTable.delegate  
		self.callbackPrefix 		= argTable.callbackPrefix or ""  
		self.name 					= argTable.name or tostring(self)  
    self.port           = argTable.port 
    self.ip           = argTable.ip 
	end
  -- print('dangaaaaaaaaaaaaaaaaaaaaaaaa')
  -- print(self.ip)
	TCPGearbox.pool[self.name] = self

	local res = string.split(G_IMIP,':') 
  dump(res,'网络信息')
	local configTable = 
	{
		[DataUnpacker.Type.HALL]  = {
			keyword = "HALLR",
			ip = self.ip  or res[1],
			port = self.port or res[2],
			name = "Game Hall Tcp"
		},
    [DataUnpacker.Type.GAME]  = {
      keyword = "CMDB",
      ip =self.ip  or  res[1],--DEFAULT_TCP_ADDRESS,
      port = self.port or DEFAULT_TCP_PORT, 
      name = "Game Table Tcp"
    },
    [DataUnpacker.Type.WEDDING]  = {
      keyword = "WEDDING",
      ip = self.ip  or res[1],--DEFAULT_TCP_ADDRESS,
      port = self.port or 6836, 
      name = "WEDDING Tcp"
    },
    [DataUnpacker.Type.GAME_Douniu]  = {
      keyword = "GAMED",
      ip = self.ip  or res[1],--DEFAULT_TCP_ADDRESS,
      port = self.port or 6835, 
      name = "DOUNIU TCP"
    },
    [DataUnpacker.Type.GAME_Sanzhang]  = {
      keyword = "GAME_Sanzhang",
      ip = self.ip  or res[1],--DEFAULT_TCP_ADDRESS,
      port = self.port or 6829, 
      name = "Sanzhang TCP"
    },
    [DataUnpacker.Type.Texus]  = {
      keyword = "Texus",
      ip = self.ip  or res[1],--DEFAULT_TCP_ADDRESS,
      port = self.port or 6840, 
      name = "Texus TCP"
    },
    [DataUnpacker.Type.GAME_Paodekuai]  = {
      keyword = "GAME_Paodekuai",
      ip = self.ip  or res[1],--DEFAULT_TCP_ADDRESS,
      port = self.port or 6877, 
      name = "Paodekuai TCP"
    },
    [DataUnpacker.Type.GAME_Wanren]  = {
      keyword = "GAME_Wanren",
      ip = self.ip  or res[1],--DEFAULT_TCP_ADDRESS,
      port = self.port or 18706, 
      name = "Wanren TCP"
    },
    [DataUnpacker.Type.MATCH_GAME]  = {
      keyword = "MATCH_GAME",
      ip = self.ip  or res[1],--DEFAULT_TCP_ADDRESS,
      port = self.port or 6873, 
      name = "MATCH_GAME TCP"
    }
	}


	local currConfig = configTable[self.unpackerType]
	self.tcpManager = TCPManager.new({
                ip = currConfig.ip,
                port = currConfig.port,
                retryConnectWhenFailure = true,
                failureRetryTime = 999, -- try infinitily
                name = currConfig.name,
            })

	TCPGearbox.log("TCPGearbox %s is connecting to %s:%s",currConfig.name,currConfig.ip,currConfig.port)
	TCPGearbox.log("setting up tcpManager") 
	self.tcpManager:addEventListener(self.tcpManager.socket.EVENT_CONNECTED,
        function() 
          TCPGearbox.log("TCPGEAR ====>>>>>>>>>>>>>>> EVENT_CONNECTED")
        	local callbackFunctionName = self.callbackPrefix..'onConnected'
        	local callFunc = nil
            if self.delegate then
               	callFunc = self.delegate[callbackFunctionName]
            end
            if type(callFunc)== 'function' then
                callFunc(self.delegate, _data)
            else 
            	printf("TCPGearbox(%s): status changed but not handled, the function %s does not exists.",self.name,callbackFunctionName)
            end 

        end)

	local function networkFailureProcess(event) 
		TCPGearbox.log('TCPGearbox:networkFailureProcess:'..event)
			-- if TCPGearbox.networkNotAvailable == true then return end -- 本来就没有wifi.
		if TCPGearbox.connFailureCount<=0 then
			TCPGearbox.badNetwork = G_BASEAPP:addView('UIWaiting',999999,true,'当前网络状态不稳定，正尝试重连中..',5,true)
		end
		if self.isAddedFailureCount ~= true then
		  TCPGearbox.connFailureCount=TCPGearbox.connFailureCount+1
		  self.isAddedFailureCount = true
		  -- printf('networkFailureProcess(%s) TCPGearbox.connFailureCount increased:%d',self.name,TCPGearbox.connFailureCount)
		end
	end

	self.tcpManager:addEventListener(self.tcpManager.socket.EVENT_CONNECT_FAILURE,networkFailureProcess)
	self.tcpManager:addEventListener(self.tcpManager.socket.EVENT_CONNECT_FAILURE_NO_DATA_RCVD,networkFailureProcess)


	self.TCPCommandTable = {} 
	local keyWordTable = {
		[DataUnpacker.Type.GAME] 	= "CMDB",
		[DataUnpacker.Type.HALL] 	= "HALLR",
		[DataUnpacker.Type.WEDDING] = "WDR",
	} 

    for k,v in pairs(DataUnpacker.CMD[self.unpackerType]['RCV']) do  
            self.TCPCommandTable[v] = k 
    end 

	if self.tcpManager then
		self.tcpManager:addEventListener(self.tcpManager.socket.EVENT_DATA_QUEUE,function(_rawData)  
      
      if self.isAddedFailureCount == true then 
        TCPGearbox.connFailureCount = TCPGearbox.connFailureCount - 1
        self.isAddedFailureCount = nil
      end
			if TCPGearbox.connFailureCount <= 0 then
        TCPGearbox.connFailureCount = 0
        if TCPGearbox.badNetwork and tolua.isnull(TCPGearbox.badNetwork) == false then 
	 			 TCPGearbox.badNetwork:removeSelf()
	 			 TCPGearbox.badNetwork = nil
        end 
      end
      -- printf('networkFailureProcess(%s) TCPGearbox.connFailureCount decreased:%d',self.name,TCPGearbox.connFailureCount)

      TCPGearbox.log("TCPGearbox %s using type %s",currConfig.name,self.unpackerType)
      -- dump(DataUnpacker.CMD[self.unpackerType]['RCV'])
			local unpacker = DataUnpacker.new(_rawData,self.unpackerType)
			local _dataList = unpacker:unpackByCMD()
      
			for k,_data in pairs(_dataList) do 
          local CMDNAME = self.TCPCommandTable[_data.CMD]
          -- printf("CMD:%d, CMDNAME:%s(%s)", _data.CMD, CMDNAME,currConfig.keyword)
          local callbackFunctionName = self.callbackPrefix..string.gsub(CMDNAME, currConfig.keyword.."_",'')
				  local callFunc = nil
          if self.delegate then
            	callFunc = self.delegate[callbackFunctionName]
            end
          if type(callFunc)== 'function' then
              callFunc(self.delegate, _data)
          else 
          	printf("TCPGearbox(%s): CMD 0x%02X received but not handled, the function %s does not exists.",self.name,_data.CMD,callbackFunctionName)
          end 
			end
		end)
	end
	TCPGearbox.log("self.tcpManager:connect()")
	self.tcpManager:connect()

end

