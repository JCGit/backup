--
-- Author: Wayne Dimart (wjweini@gmail.com)
-- Date: 2015-10-30 11:04:15
--
local DataUnpacker = class('DataUnpacker')

local DataPacker = require('app.network.DataPacker')
local ByteArray = require('app.network.ByteArray')

local PlayerData = require('app.data.PlayerData')

 require('cocos.cocos2d.json')
require('app.network.BufferEncrypt')

DataUnpacker.unpackTable = {}
DataUnpacker.CONST_TEXT = 
{
	{},-- emoji
	{   '快点吧~我等得花儿都谢了',
		'投降输一半，速度投降吧',
		'你的牌打得太好了',
		'吐了个槽的，整个一个杯具啊',
		'天灵灵，地灵灵，给手好牌行不行',
		'大清早的，鸡还没叫呢，慌什么嘛',
		'不要走，决战到天亮',
		'大家好，很高兴见到各位！',
		'出来混，迟早要还的',
		'再见了，我会想念大家的'}
 }
 
DataUnpacker.Type =
{
	GAME = 1,--斗地主
	HALL = 2,--大厅
	WEDDING = 3, --婚礼
	GAME_Sanzhang = 4, --三张
	GAME_Douniu = 5,--斗牛
	Texus = 6,
	GAME_Paodekuai = 7,--跑的快
	GAME_Wanren = 8,--万人场
	MATCH_GAME  = 9 --比赛场
}

DataUnpacker.Config = 
{
	[DataUnpacker.Type.GAME_Sanzhang] = 
	{
		-- /**
		--      * 尚未准备
		--      * */
    	['PlayerStateUnReady']   = 0,
    	-- /**,
    	--  * 已经准备,
    	--  * */,
    	['PlayerStateReady'] = 1,
    	-- /**,
    	--  * 已经进入游戏，等待下注,
    	--  * */,
    	['PlayerStateWaitBet']   = 2,
    	-- /**,
    	--  * 已经进入游戏，正在下注,
    	--  * */,
    	['PlayerStateBetOn'] = 3,
    	-- /**,
    	--  * 已经进入游戏，弃牌,
    	--  * */,
    	['PlayerStateGiveUp']  = 4,
		
    	['JINNIU_ROOM_STATE_IDLE'] = 0,--刚刚进厂

    	['JINNIU_ROOM_STATE_WAIT'] = 1,--准备阶段
    	
		['JINNIU_ROOM_STATE_PLAY'] = 2,--打牌阶段
	}
}


DataUnpacker.CMD =  --DataUnpacker.CMD[DataUnpacker.Type.HALL]['REQ'] ['HALL_SEND_MSG_SERVICE']
{


	[DataUnpacker.Type.GAME_Wanren] = {
		['REQ'] = {
			TABLE_LOGIN 					= 0x01,
			GRAB_DEALER		 				= 0x02,  --请求上庄
			DROP_DEALER 					= 0x03,  --请求下庄
			BET 							= 0x04,  --下注
			ASK_LEAVE        				= 0x05,  --离开房间
			HEARTBEAT 						= 0x10, 
			UPDATA_INFO                     = 0x06,  --更新信息
			ASK_SIT 						= 0x07,  --坐下
			ASK_STAND	 					= 0x08,  --请求站起
			CHAT 							= 0x0E, 
			EMOJI		 					= 0x0F, 
			CONST_TEXT 						= 0x11, 
			},

		['RCV'] = {
			HEARTBEAT 						= 0x40,
			LOGIN_SUCC 						= 0x31,  
            GRAB_SUCC                       = 0x32,  --申请上庄成功
            DROP_SUCC                       = 0x33,  --申请下庄成功     
            SEND_FIRST                      = 0x34,  --发第一张
            BET_SUCC                        = 0x35,  --下注 
            POOL_INFO                       = 0x36,  --每个下注池的下注额
            FORBID_BET                      = 0x3A,  --等待结果,禁止下注 
            PLAYER_COUNT                    = 0x3B,  --个人结算
            CHANGE_DEALER                   = 0x3C,  --换庄 

            LOGOUT_SUCC						= 0x42,  --登出成功 
			UPDATE_PLAYER 					= 0x45,  --更新信息
            MSG_TIPS				     	= 0x4A,  --消息提示 
			FINAL_RESULT                    = 0x4B,  --最后结果
            PLSYER_SITDOWN                  = 0x4C,  --玩家坐下 
            PLSYER_STANDUP                  = 0x4D,  --玩家站起 
            DEALER_LIST                     = 0x4E,  --庄家列表  
            SOMEONE_BET                     = 0x4F,  --有人下注
            SOMEONE_IN                      = 0x50,  --有人进入
            SOMEONE_OUT                     = 0x51,  --有人离开

            CHAT 							= 0x53,
			EMOJI 							= 0x54,
			CONST_TEXT						= 0x55,
    	}
    },

    [DataUnpacker.Type.GAME_Douniu] = {
		['REQ'] = {
		-- /*Client to Server*/
			TABLE_LOGIN 					= 0x01,
			TABLE_DISCONNECT 				= 0x02,
			CHANGE_TABLE 					= 0x04, 
			UPDATE_PLAYER 					= 0x05, 
			HEARTBEAT 						= 0x06, 
			
			READY 							= 0x07, 
			GRAB_HOST	 					= 0x08, 
			-- FOLLOW_BET 						= 0x09, 
			MULTIPLY 						= 0x0A, 
			SHOW_CARDS 						= 0x0B, 
			-- COMPARE_CARDS					= 0x0C, 
			-- ALLIN							= 0x0D, 
			
			CHAT 							= 0x0E, 
			EMOJI		 					= 0x0F, 
			CONST_TEXT 						= 0x10, 
			SENDGIFT 						= 0x11, 
			
			KIKPLAYER 						= 0x12, 
			-- FORBID							= 0x13, 
			-- MULTIPLY_FIVE					= 0x14,
			-- MULTIPLY_TEN					= 0x15,
			-- CHANGE_CARD						= 0x16,
			
			NETWORK_ACK						= 0x18,
			FRIEND_REQUEST					= 0x19,
			FRIEND_REQUEST_RESULT			= 0x1A,
			TABLE_LOGIN_EX					= 0x21,
			-- BET_TIMEOUT_ACTION				= 0x1B, 


			},
		['RCV'] = {
		-- /*Server to Client*/ 
			HEARTBEAT 						= 0x46,
			RSPD_FAIL 						= 0x40,
			LOGIN_SUCC 						= 0x41,
			LOGOUT_SUCC						= 0x42,
			LOGIN_CONFLICT					= 0x43,
			UPDATE_PLAYER 					= 0x45,
			PLAYER_CONNECTED				= 0x47,
			PLAYER_DISCONNECTED				= 0x48,

			-- GAME_READY						= 0x49,
			START_GRAB_HOST					= 0x4A,
			START_MULTIPLY					= 0x4B,
			START_SHOW_CARDS				= 0x4C,
			PLAYER_READY					= 0x4D,
			PLAYER_GRAB_HOST				= 0x4E,

			PLAYER_MULTIPLY					= 0x50,
			PLAYER_SHOW_CARDS				= 0x51,


			-- PLAYER_DROP_CARDS				= 0x4F,
			-- PLAYER_COMPARE					= 0x50,
			-- PLAYER_ALLIN					= 0x51,
			GAME_ROUND_OVER					= 0x52,

			CHAT 							= 0x53,
			EMOJI 							= 0x54,
			CONST_TEXT						= 0x55,
			SENDGIFT						= 0x56,

			KIKPLAYER						= 0x57,
			-- FORBID 							= 0x58,
			-- MULTIPLY_FIVE					= 0x59,
			-- MULTIPLY_TEN					= 0x5A,
			-- CHANGE_CARD 					= 0x5B,
			-- CHANGE_CARD_APPLY				= 0x5C,
			-- ITEM_EXPIRED					= 0x5D,
			SYS_INFO						= 0x5E,
			-- MATCH_NEW_ROUND					= 0x60,
			-- MATCH_OVER						= 0x61,
			NETWORK_BAD_TRAFFIC				= 0x62,
			FRIEND_REQUEST					= 0x63,
			FRIEND_REQUEST_RESULT			= 0x64,
			-- TIMEOUT_ACTION_SUCC				= 0x65, 

    	}
    },
	[DataUnpacker.Type.GAME_Sanzhang] = {
		['REQ'] = {
		-- /*Client to Server*/
			TABLE_LOGIN 					= 0x01,
			TABLE_DISCONNECT 				= 0x02,
			CHANGE_TABLE 					= 0x04, 
			UPDATE_PLAYER 					= 0x05, 
			HEARTBEAT 						= 0x06, 
			
			READY 							= 0x07, 
			PEEK_CARDS	 					= 0x08, 
			FOLLOW_BET 						= 0x09, 
			ADD_BET 						= 0x0A, 
			DROP_CARDS 						= 0x0B, 
			COMPARE_CARDS					= 0x0C, 
			ALLIN							= 0x0D, 
			
			CHAT 							= 0x0E, 
			EMOJI		 					= 0x0F, 
			CONST_TEXT 						= 0x10, 
			SENDGIFT 						= 0x11, 
			
			KIKPLAYER 						= 0x12, 
			FORBID							= 0x13, 
			MULTIPLY_FIVE					= 0x14,
			MULTIPLY_TEN					= 0x15,
			CHANGE_CARD						= 0x16,
			
			NETWORK_ACK						= 0x18,
			FRIEND_REQUEST					= 0x19,
			FRIEND_REQUEST_RESULT			= 0x1A,
			BET_TIMEOUT_ACTION				= 0x1B, 


			},
		['RCV'] = {
		-- /*Server to Client*/ 
			HEARTBEAT 						= 0x46,
			RSPD_FAIL 						= 0x40,
			LOGIN_SUCC 						= 0x41,
			LOGOUT_SUCC						= 0x42,
			LOGIN_CONFLICT					= 0x43,
			UPDATE_PLAYER 					= 0x45,
			PLAYER_CONNECTED				= 0x47,
			PLAYER_DISCONNECTED				= 0x48,

			GAME_READY						= 0x49,
			GAME_START 						= 0x4A,
			PLAYER_READY					= 0x4B,
			PLAYER_PEEK						= 0x4C,
			PLAYER_FOLLOW					= 0x4D,
			PLAYER_ADD_BET					= 0x4E,

			FOUTH_CARD						= 0x3F,
			LAST_CARD						= 0x3E,


			PLAYER_DROP_CARDS				= 0x4F,
			PLAYER_COMPARE					= 0x50,
			PLAYER_ALLIN					= 0x51,
			GAME_ROUND_OVER					= 0x52,

			CHAT 							= 0x53,
			EMOJI 							= 0x54,
			CONST_TEXT						= 0x55,
			SENDGIFT						= 0x56,

			KIKPLAYER						= 0x57,
			FORBID 							= 0x58,
			MULTIPLY_FIVE					= 0x59,
			MULTIPLY_TEN					= 0x5A,
			CHANGE_CARD 					= 0x5B,
			CHANGE_CARD_APPLY				= 0x5C,
			ITEM_EXPIRED					= 0x5D,
			SYS_INFO						= 0x5E,
			MATCH_NEW_ROUND					= 0x60,
			MATCH_OVER						= 0x61,
			NETWORK_BAD_TRAFFIC				= 0x62,
			FRIEND_REQUEST					= 0x63,
			FRIEND_REQUEST_RESULT			= 0x64,
			TIMEOUT_ACTION_SUCC				= 0x65, 

    	}
    },
	[DataUnpacker.Type.GAME] = {
		['REQ'] = {
		-- /*Client to Server*/
			TABLE_LOGIN 		= 0x01,
			TABLE_DISCONNECT 	= 0x02,
			CHANGE_TABLE 		= 0x03,
			USER_READY 			= 0x04,
			PLAY_CARD 			= 0x05,
			PASS 				= 0x06,
			SIGNUP_CAMPAIN 		= 0x2B,
			UNDO_SIGNUP_CAMPAIN = 0x2C,
			WANT_TO_BELORD 		= 0x10,
			ACCEPT_DOUBLE 		= 0x11,
			UPDATE_PLAYER		= 0x13,
			USER_CALL_LORD		= 0x16, 
			USER_GRAB_LORD		= 0x17, 
			HEARTBEAT 			= 0x21, 
			UPDATE_AUTOPLAY 	= 0x23, 
			CHAT 				= 0x24, 
			CHAT_TEXT_CONSTANCE = 0x25, 
			USER_KICK			= 0x26, 
			SEND_GIFT			= 0x27, 
			FRIEND_REQUEST		= 0x28, 
			ACCEPT_OR_DENY		= 0x29, 
			GET_TASK_BONUS		= 0x2A, 
			},
		['RCV'] = {
		-- /*Server to Client*/
			TABLE_LOGIN_SUCESS 			= 0x30,
			TABLE_LOGOUT_SUCESS 		= 0x32, 
			PLAYER_DISCONNECTED 		= 0x33, 
			PLAYER_CONNECTED 			= 0x34, 
			PLAYER_READY 				= 0x35, 
			DEAL_CARDS 					= 0x36, 
			PLAYER_PLAY_CARD 			= 0x37, 
			PLAYER_PASS 				= 0x38, 
			ROUND_OVER 					= 0x39, 
			PLAY_CARD_ERROR 			= 0x3A, 
			CAMP_SIGNUP_RESULT 			= 0x3B,
			CAMP_WITHDRAW_RESULT 		= 0x3C,
			CAMP_INFO 					= 0x3D,
			CAMP_RESULT 				= 0x3E,

			WHO_DECIDE_TO_BE_LORD		= 0x40,
			LORD_SATTLED_WHOS_DOUBLE 	= 0x41,
			WHO_DOUBLED 				= 0x42,
			UPDATE_PLAYER	 			= 0x43,
			WHO_DECIDE_TO_CALL_LORD 	= 0x46,
			WHO_DECIDE_TO_GRAB_LORD 	= 0x47,
			CAMP_PLAYER_DATA 			= 0x50,
			HEARTBEAT 					= 0x51,
			FORCE_KICK 					= 0x52, 
			PLAYER_AUTOPLAY 			= 0x53, 
			PLAYER_CHAT_TEXT			= 0x54, 
			PLAYER_CHAT_TEXT_CONSTANCE	= 0x55, 
			PLAYER_KICK 				= 0x56, 
			PLAYER_SENT_GIFT 			= 0x57,  
			FRIEND_REQUEST 				= 0x58, 
			FRIEND_REQUEST_RESULT 		= 0x59, 
			CURRENT_TASKS 				= 0x5A, 
			CURRENT_TASKS_ACCOMPLISHED 	= 0x5B, 
			CURRENT_TASKS_BONUS_RESULT 	= 0x5C, 
			MESSAGE_POPUP				= 0x62,
			SERVER_FAIL					= 0x63,
    	}
    },
	[DataUnpacker.Type.MATCH_GAME] = {
		['REQ'] = {
			TABLE_LOGIN 	= 0x01,
			TABLE_DISCONNECT = 0x02,
			PLAY_CARD 		= 0x05,
			PASS 		    = 0x06,
			USER_CALL_LORD  = 0x07,
			NO_CALL_LORD    = 0x08,
			USER_GRAB_LORD  = 0x09,
 			NO_DROP_LORD    = 0x0a,
			ACCEPT_DOUBLE   = 0x0b,
			NO_DOUBLE       = 0x0c,
			HEARTBEAT       = 0x21,
			UPDATE_AUTOPLAY = 0x23,
			XIAZHU_RES      = 0x2b,
			},
		['RCV'] = {
		    DIF_LOGIN       			= 0x30,
		    HEARTBEAT                   = 0x31,
			FORCE_KICK           		= 0x32, 
			PLAYER_AUTOPLAY       		= 0x33, 
			MESSAGE_POPUP      			= 0x34, 
			NET_TROUBLE 				= 0x35, 
			SERVER_FAIL 				= 0x36, 
			TABLE_LOGIN_SUCESS       	= 0x37, 
			TABLE_LOGOUT_SUCESS 		= 0x38, 
			NEW_ROUND 					= 0x39, 
			LOGIN_TABLE_SUCC 			= 0x3a,
			PLAYER_DISCONNECTED      	= 0x3b,
			PLAYER_CONNECTED 	        = 0x3c,
			DEAL_CARDS 					= 0x3d,
			WHO_DECIDE_TO_CALL_LORD 	= 0x3e,
			NO_CALL_LORD_RES		    = 0x40,
			WHO_DECIDE_TO_GRAB_LORD     = 0x41,
			NO_DROP_LORD_RES 			= 0x42,
			WHO_DOUBLED	 		    	= 0x43,
			PLAY_NO_DOUBLE_RES	 	    = 0x44,
			PLAYER_PLAY_CARD         	= 0x45,
			PLAYER_PASS                 = 0x46,
			ROUND_OVER 					= 0x47,
			WAITING_OTHERS  			= 0x48,
			ONE_ROUND_OVER       		= 0x49,
            MATCH_OVER                  = 0x4a,
            LORD_SATTLED_WHOS_DOUBLE    = 0x4b,
            MATCH_FAIL                  = 0x4c,
            MATCH_RANK                  = 0x4d,
    	}

    },
	----------------hall commands---------------
	[DataUnpacker.Type.HALL] = {
			['REQ'] = {

				HALL_LOGIN 	= 0x01,
				HALL_LOGOUT = 0x02,
				HALL_GET_ONLINE_PLAYERS_COUNT = 0x06,
				HALL_SEND_SPEAKER = 0x23,
				HALL_SEND_MSG_FRIEND = 0x11,
				HALL_SEND_MSG_SERVICE = 0x12,
				HALL_INVITE_FRIEND = 0x13,
				HALL_HEARTBEAT = 0x21,
				HALL_QUERY_NEWBIE = 0x15,
			},
			['RCV'] = {
				HALLR_LOGIN_SUCC 					= 0x30,
				HALLR_GET_ONLINE_PLAYERS_COUNT 		= 0x36,
				HALLR_SYS_NEWBOARDCAST				= 0x53,
				HALLR_SYS_OLDBOARDCAST				= 0x37,
				HALLR_FRIEND_MSG 					= 0x41,
				HALLR_SYS_INFO 						= 0x42,
				HALLR_INVITE_FRIEND 				= 0x43,
				HALLR_SERVICE_MSG 					= 0x44,
				HALLR_SYNC_INFO 					= 0x4A,
				HALLR_OFFLINE_MSG 					= 0x4C,
				HALLR_HEARTBEAT 					= 0x51,
				HALLR_FORCE_OFFLINE 				= 0x52,
				HALLR_MISSION_ONCHANGE 				= 0x38,
				HALLR_NEW_MAIL 						= 0x56,
				HALLR_QUERY_NEWBIE 					= 0x57,
				HALLR_TIP_MATCH_BEGIN               = 0x58,
				HALLR_GAME_COUNT                    = 0x39,   --新增游戏局数统计
			}
	},
	
	------------------WEDDING commands---------------------
	[DataUnpacker.Type.WEDDING] = {
			['REQ'] = {
				HEARTBEAT = 0x06,
				LOGIN = 0x01,
				LOGOUT = 0x02,
				UPDATE_USER_INFO = 0x03,
				CHATSTRING= 0x0e,
				CHATEMOJI = 0x0f,
				CHATSTRINGID = 0x10,
				SENDGIFT = 0x11,
				KIKPLAYER = 0x12,
				SENDREDPOCKET = 0x13,
				SENDCOIN = 0x14,
				SENDBALLOON= 0x15,
				SENDFLOWERS = 0x16,
				INVITE_OTHER = 0x17,
				PROPOSAL = 0x18,
				PROPOSAL_ACCEPT = 0x19,
				PROPOSAL_DENY = 0x1a,
			},
			['RCV'] = {
				HEARTBEAT 					= 0x46,
				LOGIN_SUCC 					= 0x41,
				LOGOUT_SUCC 				= 0x42,
				LOGIN_CONFLICT 				= 0x43,
				UPDATE_USERINFO 			= 0x45,
				USER_ENTER 					= 0x47,
				USER_LEFT 					= 0x48,
				CHAT						= 0x53,
				EMOJI						= 0x54,
				CHATSTRID					= 0x55,
				SENDGIFT					= 0x56,
				SENDREDPOCKET				= 0x58,
				SENDMONEY			     	= 0x59,
				SENDBALLOON					= 0x5A,
				SENDFLOWERS					= 0x5B,
				SINVITE_SUCC				= 0x5F,
				BE_PROPOSALED				= 0x60,
				BE_PROPOSALED_ACCEPT		= 0x61,
				BE_PROPOSALED_DENY			= 0x62,
				BE_PROPOSALED_FAIL			= 0x63,
				KIK_PLAYER					= 0x57,
				ERROR						= 0x40,
				SYS_INFO					= 0x5E,
			},
	},
	[DataUnpacker.Type.Texus] = {
			['REQ'] = {
				LOGIN          = 0x01,
				EXIT_RQ        = 0x02,
				CHANGE_TAB     = 0x03,
				UPDATA_INFO    = 0x04,
				HEARTBEAT      = 0x05,
				SIT_DOWN       = 0x06,				
				STAND_UP       = 0x07,
				SEE_CARD       = 0x08,
				FOLLOW_CHIP    = 0x09,
				ADD_CHIP       = 0x0a,
				ABANDON_CARD   = 0x0b,
				ALL_IN         = 0x0c,
				CHAT_WORD      = 0x0d,
				CHAT_FACE      = 0x0e,
				CHAT_COMMON    = 0x0f,
				GIVE_GIFT      = 0x10,
				LET_GO         = 0x11,
				NET_RES        = 0x12,
				ASK_FRI        = 0x13,				
				RES_FRI        = 0x14,
				AUTO_BUY       = 0x15,
				BUY_CHIP       = 0x18,
				SHOW_CARD      = 0x19,
				SER_FEE        = 0x1a,
			},
			['RCV'] = {
				ALL_LOSE                    = 0x40,
				LOGIN_SUCC 					= 0x41,
				LOGOUT_SUCC 				= 0x42,
				LOGIN_CONFLICT 				= 0x43,   --异地登录
				UPDATE_USERINFO 			= 0x44,
				HEARTBEAT 					= 0x45,
				USER_ENTER 					= 0x46,
				USER_LEFT 					= 0x47,
				USER_SIT 					= 0x48,
				USER_STAND 					= 0x49,
				GAME_START 					= 0x4a,
				TURN_CARD                   = 0x4b,
				OVER_CARD                   = 0x4c,
				RIVER_CARD                  = 0x4d,
				SEE_CARD                    = 0x4e,
				FOLLOW_CHIP                 = 0x4f,
				ADD_CHIP                    = 0x50,
                ABANDON_CARD                = 0x51,
                ALL_IN                      = 0x52,
                ONE_ROUND_OVER              = 0x53,
                GAME_OVER                   = 0x54,
				CHAT_STR					= 0x55,
				FACE_ID				     	= 0x56,
				COMMON_ID				    = 0x57,
				SENDGIFT			     	= 0x58,
				KICK_PEOPLE					= 0x59,
				SYS_INFOS					= 0x5a,
				NET_PRO				     	= 0x5b,
				ASK_FRIEND				    = 0x5c,
				RESQ_FRIEND				    = 0x5d,
				FORCE_STANDUP			    = 0x5f,
				SHOW_CARD    				= 0x60,
				GIVE_FEE         			= 0x62,
				FIRST_BEGIN     			= 0x63,
				EXP_ADD         			= 0x64,
			}
	},

}

DataUnpacker.ConfigTable = { 
		ROOM_STATE_WAIT 		= 0,-- 房间等待
		ROOM_STATE_CALL_LORD 	= 1,-- 房间正在要地主
		ROOM_STATE_CALL_MUL 	= 2,-- 房间加倍
		ROOM_STATE_PLAY 		= 3,-- 房间正在出牌
		ROOM_STATE_GRAB_CALL 	= 4,-- 等待叫地主
		ROOM_STATE_GRAB_GRAB 	= 5,-- 等待抢地主 
		LORD_CALL_YES 			= 1;   	-- 用户要地主
		ORD_CALL_NO 			= 0;   	-- 用户不要地主
		UL_CALL_YES 			= 1;   	-- 用户加倍
		UL_CALL_NO 				= 0;   	-- 用户不加倍
		OOL_GIFT_USE_OK 		= 0x01;	-- 道具或礼物使用成功
		OOL_GIFT_USE_FAIL 		= 0x02;	-- 道具或礼物使用失败
		OOM_NEW_TURN_YES 		= 0x01;	-- 新的一轮
		OOM_NEW_TURN_NO 		= 0x02;	-- 不是新的一轮
		LAYER_TRUST_YES 		= 0x01;	-- 玩家托管
		LAYER_TRUST_NO 			= 0x02;	-- 玩家取消托管
		ET_STATE_WIFI 			= 0x01;
		ET_STATE_2G 			= 0x02;
		ET_STATE_3G 			= 0x03;
		ET_STATE_4G 			= 0x04;
		SERVER_NORMAL_SITE 		= 0x01;
		SERVER_GRAB_SITE = 0x12,
		SERVER_DAJIANG_SITE = 0x21, 
		SERVER_MERRY = 0x0e,--婚礼场
		SERVER_WRDOUNIU_SITE = 0x09,
		SERVER_PRIVATE_SITE = 0x07,
		SERVER_FDOUNIU_SITE = 0x31,
		SERVER_JINNIU_SITE = 0x34,
		SERVER_JINNIU_SITE_PRI = 0x39,
		SERVER_MATCH_SITE = 0x05,
		SERVER_Fee_SITE = 0x06,-- 话费比赛场
		SERVER_JINHUA_PRIMARY = 0x3C,-- 初级
		SERVER_JINHUA_MIDDLE = 0x3D,-- 中级
		SERVER_JINHUA_SENIOR = 0x3E,-- 高级
		SERVER_JINHUA_FA = 0x3F,-- 发哥场
		SERVER_JINHUA_CloseLook = 0x41,--秒
		MatchCoinPrimary = 0x01, -- 比赛场-金币-初级场
		MatchCoinMiddle = 0x02, -- 比赛场-金币-中级场
		MatchCoinSenior = 0x03,-- 比赛场-金币-高级场
		MatchGemPrimary = 0x04,-- 比赛场-元宝-初级场
		MatchGemMiddle = 0x05,-- 比赛场-元宝-初级场
		MatchGemSenior = 0x06,-- 比赛场-元宝-初级场
		MatchFeePrimary = 0x07, -- 比赛场-话费券-初级场
		MatchFeeMiddle = 0x08, -- 比赛场-话费券-初级场
		MatchFeeSenior = 0x09, -- 比赛场-话费券-初级场
		FeeFeePrimary  = 0x11 ,--话费场-话费券-初级场
		FeeFeeMiddle  = 0x12, --话费场-话费券-初级场
		FeeFeeSenior  = 0x13 ,--话费场-话费券-初级场
		FLORD_TYPE_ONE  = 0x00 ,--斗地主-叫/抢-初级场
		FLORD_TYPE_TWO  = 0x01 ,--斗地主-叫/抢-中级场
		FLORD_TYPE_THREE  = 0x02 ,--斗地主-叫/抢-高级场
		FLORD_TYPE_FOUR  = 0x03 ,--斗地主-叫/抢-至尊场
		WUNIU_TYPE_ONE  = 0x00 ,--五人斗牛-初级场
		WUNIU_TYPE_TWO  = 0x01 ,--五人斗牛-中级场
		WUNIU_TYPE_THREE  = 0x02 ,--五人斗牛-高级场
		WUNIU_TYPE_FOUR  = 0x03 ,--五人斗牛-至尊场
		JINNIU_TYPE_ONE  = 0x00 ,--金牛-初级场
		JINNIU_TYPE_TWO  = 0x01 ,--金牛-中级场
		JINNIU_TYPE_THREE  = 0x02 ,--金牛-高级场
		JINNIU_TYPE_FOUR  = 0x03 ,--金牛-至尊场
		TOOL_KICK = 4,
		TOOL_BROADCAST = 7,
		TOOL_Fee = 0x101,
		GIFT_FLOWER = 0x01,
		GIFT_EGG = 0x02,
		GIFT_CAR = 0x03,
		GIFT_SHIP = 0x04,
		GIFT_PLANE = 0x05,
		COIN_UPDATE_TASK = 1,-- 任务
		COIN_UPDATE_CHEST = 2,-- 宝箱
		COIN_UPDATE_BUY = 3,-- 商城购买
		COIN_UPDATE_SALE_GIFT = 4,-- 卖礼物
		COIN_UPDATE_BRANK = 5,-- 破产补助
		COIN_UPDATE_PAY = 6,-- 支付
		TASK_STATE_NO = 0,-- 不可领奖
		TASK_STATE_YES = 1, -- 可以领奖
		TASK_REWARD_RES_OK = 1, -- 领取任务奖励OK
		TASK_REWARD_TYPE_BAG = 1, -- 领取任务奖励-背包
		MatchCoinTypeCoin = 1,-- 比赛场金币类型
		MatchCoinTypeGem = 2,-- 比赛场元宝类型
		MatchCoinTypeFee = 3,-- 比赛场话费券类型
		GrabActIdCallCallY = 1,-- 要地主
		GrabActIdCallCallN = 2, -- 不要地主
		GrabActIdGrabCallY = 3, -- 叫地主
		GrabActIdGrabCallN = 4, -- 不叫地主
		GrabActIdGrabGrabY = 5, -- 抢地主
		GrabActIdGrabGrabN = 6, -- 不抢
		GrabActIdCallMulY = 7, -- 加倍
		GrabActIdCallMulN = 8, -- 不加倍
		MESSAGE_GIF = 0x01,
		MESSAGE_COMMOM = 0x02,
}

function DataUnpacker:initUnpackTable()

    local playerdata = PlayerData.new()
    DataUnpacker.unpackTable = {}

	DataUnpacker.unpackTable[DataUnpacker.Type.MATCH_GAME] =
	{
    	[DataUnpacker.CMD[DataUnpacker.Type.MATCH_GAME]['RCV'].DIF_LOGIN ] = 
		{},
		[DataUnpacker.CMD[DataUnpacker.Type.MATCH_GAME]['RCV'].HEARTBEAT ] = 
		{},
		[DataUnpacker.CMD[DataUnpacker.Type.MATCH_GAME]['RCV'].FORCE_KICK ] = 
		{
			{dataType = DataPacker.BYTE ,dataName='msgType'}, 
			{dataType = DataPacker.STRING,dataName='msg'},

		},
		[DataUnpacker.CMD[DataUnpacker.Type.MATCH_GAME]['RCV'].PLAYER_AUTOPLAY ] = 
		{
			{dataType = DataPacker.BYTE ,dataName='seatId'}, 
			{dataType = DataPacker.BYTE ,dataName='state'},   --1托管 2取消托管

		},
		[DataUnpacker.CMD[DataUnpacker.Type.MATCH_GAME]['RCV'].MESSAGE_POPUP ] = 
		{
			{dataType = DataPacker.BYTE ,dataName='msgType'}, --1：toast,2:popWindow,3:closeConn
			{dataType = DataPacker.STRING,dataName='msg'},
		},
		[DataUnpacker.CMD[DataUnpacker.Type.MATCH_GAME]['RCV'].NET_TROUBLE ] = 
		{
			{dataType = DataPacker.BYTE ,dataName='seatId'}, 
			{dataType = DataPacker.BYTE,dataName='type'},		--堵塞类型
		},
		[DataUnpacker.CMD[DataUnpacker.Type.MATCH_GAME]['RCV'].SERVER_FAIL ] = 
        function(byteArray) 
            local ret = {} 
            ret.actionId   = byteArray:readByte()   
            ret.failedType = byteArray:readByte()   
            ret.failedStr  = byteArray:readString(byteArray:readShort())  
            local len = byteArray:readByte()   
            if len > 0 then 
               ret.cards = {} 
               for k=1,len do
               	    local temp = byteArray:readByte()
               	    if temp == 0x50 then
						temp = 0x01
					end
					if temp == 0x51 then
						temp = 0x02
					end
                   table.insert(ret.cards,temp)
               end 	
            end  	
            return ret
        end,  	
		[DataUnpacker.CMD[DataUnpacker.Type.MATCH_GAME]['RCV'].TABLE_LOGIN_SUCESS ] = 
		function(byteArray)
		   local ret = {}
           ret.matchId        = byteArray:readInt()    
           ret.CallLordTime   = byteArray:readByte()   
           ret.DropLordTime   = byteArray:readByte()   
           ret.DoubleTime     = byteArray:readByte()   
           ret.SendCardTime   = byteArray:readByte() 
           ret.round = byteArray:readByte()
		   ret.passNum = byteArray:readInt()
		   ret.thisRoundLefTime = byteArray:readShort()
		   ret.allNum = byteArray:readShort()
		   ret.myRank = byteArray:readShort()  

           ret.info = {} 
           ret.info.uid    =   byteArray:readInt()     
           ret.info.nick   =   byteArray:readString(byteArray:readShort()) 
           ret.info.coin   =   byteArray:readLong()
           ret.info.sex    =   byteArray:readByte()    
           ret.info.vip_level = byteArray:readByte()     
           ret.info.vipType   = byteArray:readByte()   
           ret.info.icon    = byteArray:readString(byteArray:readShort()) 
           ret.info.other   = byteArray:readString(byteArray:readShort()) 
           ret.otherInfo    = byteArray:readString(byteArray:readShort()) 
           return ret 
	    end,
		[DataUnpacker.CMD[DataUnpacker.Type.MATCH_GAME]['RCV'].TABLE_LOGOUT_SUCESS ] = 
		{},
		[DataUnpacker.CMD[DataUnpacker.Type.MATCH_GAME]['RCV'].NEW_ROUND ] = 
		{  
			{dataType = DataPacker.BYTE ,dataName='round'}, 
			{dataType = DataPacker.INT ,dataName='passNum'}, 
			{dataType = DataPacker.STRING ,dataName='info'}, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.MATCH_GAME]['RCV'].LOGIN_TABLE_SUCC  ] = 
        function(byteArray) 
             local ret= {}
             ret.diZhu        = byteArray:readInt()    
             ret.roundNumber  = byteArray:readByte()
             ret.totalNumber  = byteArray:readInt()    
             ret.lordSeatId   = byteArray:readByte()
             ret.selfSeat     = byteArray:readByte()
             ret.roomState    = byteArray:readByte() 
             ret.userNum      = byteArray:readByte() 
             ret.userData = {}
			    for i=1,ret.userNum do
					local tab = {} 
					tab.seatID = byteArray:readByte()
					tab.UID    = byteArray:readInt() 
					tab.nickName = byteArray:readString(byteArray:readShort())
					tab.coins = byteArray:readLong() 
					tab.sex   = byteArray:readByte()
					tab.vipLevel = byteArray:readByte()
					tab.vipType  = byteArray:readByte()
					tab.autoPlayStatus = byteArray:readByte()
					tab.status = byteArray:readByte()
					tab.iconUrl = byteArray:readString(byteArray:readShort())
					tab.nowCardLen = byteArray:readByte() 
					tab.cardLen = byteArray:readByte()					
					if tab.cardLen > 0 then 
						tab.userCards = {} 
						for k=1,tab.cardLen do
							local temp = byteArray:readByte()
							if temp == 0x50 then
								temp = 0x01
							end
							if temp == 0x51 then
								temp = 0x02
							end
	                        table.insert(tab.userCards,temp)
					    end 		
					end     
					tab.ext= byteArray:readString(byteArray:readShort())
					table.insert(ret.userData ,tab)
				end
				if ret.roomState ~= 0 then 
					ret.doubleAmount = byteArray:readShort() 
					ret.lordCardCount = byteArray:readByte()
					if  ret.lordCardCount> 0 then 
						ret.lordCards = {}
						for i=1,ret.lordCardCount do
							local temp = byteArray:readByte()
							if temp == 0x50 then
								temp = 0x01
							end
							if temp == 0x51 then
								temp = 0x02
							end
							table.insert(ret.lordCards,temp)
						end
				    end 		
					ret.currentSeat =  byteArray:readByte()
					ret.lastPlayerSeatID = byteArray:readByte()
					ret.lastPlayerCardType = byteArray:readByte()
					ret.lastPlayerCardCount = byteArray:readByte()
					ret.lastPlayerCards = {}
					for i=1,ret.lastPlayerCardCount do
						local temp = byteArray:readByte()
						if temp == 0x50 then
							temp = 0x01
						end
						if temp == 0x51 then
							temp = 0x02
						end
						table.insert(ret.lastPlayerCards,temp)
					end 
				end	
			ret.otherInfo = byteArray:readString(byteArray:readShort())
			return ret
        end, 	
		[DataUnpacker.CMD[DataUnpacker.Type.MATCH_GAME]['RCV'].PLAYER_DISCONNECTED] = 
		{
			{dataType = DataPacker.BYTE ,dataName='seatID'}, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.MATCH_GAME]['RCV'].PLAYER_CONNECTED  ] = 
		{
			{dataType = DataPacker.BYTE ,dataName='seatID'}, 
			{dataType = DataPacker.INT ,dataName='UID'}, 
			{dataType = DataPacker.STRING ,dataName='nickName'}, 
			{dataType = DataPacker.LONG ,dataName='coins'}, 
			{dataType = DataPacker.BYTE ,dataName='sex'}, 
			{dataType = DataPacker.BYTE ,dataName='vipLevel'}, 
			{dataType = DataPacker.BYTE ,dataName='vipType'}, 
			-- {dataType = DataPacker.BYTE ,dataName='status'}, 
			{dataType = DataPacker.STRING ,dataName='iconUrl'}, 
			{dataType = DataPacker.STRING ,dataName='ext'}, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.MATCH_GAME]['RCV'].DEAL_CARDS  ] = 
		function(byteArray)
            local ret = {}
			ret.len = byteArray:readByte()
			ret.cards = {}
			for i=1,ret.len  do
				local temp = byteArray:readByte()
				if temp == 0x50 then
					temp = 0x01
				end
				if temp == 0x51 then
					temp = 0x02
				end
				table.insert(ret.cards, temp)
			end
			return ret
		end,
		[DataUnpacker.CMD[DataUnpacker.Type.MATCH_GAME]['RCV'].WHO_DECIDE_TO_CALL_LORD  ] = 
		{
				{dataType = DataPacker.BYTE ,dataName='seatId'}, 
			    {dataType = DataPacker.BYTE ,dataName='NextSeatId'}, 

		},
		[DataUnpacker.CMD[DataUnpacker.Type.MATCH_GAME]['RCV'].NO_CALL_LORD_RES ] = 
		{				
		        {dataType = DataPacker.BYTE ,dataName='seatId'}, 
			    {dataType = DataPacker.BYTE ,dataName='NextSeatId'}, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.MATCH_GAME]['RCV'].WHO_DECIDE_TO_GRAB_LORD ] = 
		{
				{dataType = DataPacker.BYTE ,dataName='seatId'}, 
			    {dataType = DataPacker.BYTE ,dataName='NextSeatId'}, 
		},																										
		[DataUnpacker.CMD[DataUnpacker.Type.MATCH_GAME]['RCV'].NO_DROP_LORD_RES ] = 
		{
				{dataType = DataPacker.BYTE ,dataName='seatId'}, 
			    {dataType = DataPacker.BYTE ,dataName='NextSeatId'}, 
		},	
		[DataUnpacker.CMD[DataUnpacker.Type.MATCH_GAME]['RCV'].WHO_DOUBLED ] = 
		{
				{dataType = DataPacker.BYTE ,dataName='seatId'}, 
		},			    
		[DataUnpacker.CMD[DataUnpacker.Type.MATCH_GAME]['RCV'].PLAY_NO_DOUBLE_RES ] = 
		{
				{dataType = DataPacker.BYTE ,dataName='seatId'}, 		
		},	
		[DataUnpacker.CMD[DataUnpacker.Type.MATCH_GAME]['RCV'].PLAYER_PLAY_CARD ] = 
		function(byteArray)
			local ret = {}
			ret.seatID = byteArray:readByte()
			ret.nextID = byteArray:readByte()
			ret.cardLen = byteArray:readByte()
			ret.cards = {}
			for i=1,ret.cardLen  do
				local temp = byteArray:readByte()
				if temp == 0x50 then
					temp = 0x01
				end
				if temp == 0x51 then
					temp = 0x02
				end
				table.insert(ret.cards,temp)
			end
			ret.cardType = byteArray:readByte()
			return ret
	    end,	
		[DataUnpacker.CMD[DataUnpacker.Type.MATCH_GAME]['RCV'].PLAYER_PASS ] = 
		{
			{dataType = DataPacker.BYTE ,dataName='seatID'}, 
			{dataType = DataPacker.BYTE ,dataName='nextID'}, 
			{dataType = DataPacker.BYTE ,dataName='isNewRound'}, 
		},	
		[DataUnpacker.CMD[DataUnpacker.Type.MATCH_GAME]['RCV'].ROUND_OVER ] = 
		function(byteArray)
			local ret = {}
			ret.doubleAmount = byteArray:readShort()
			ret.playerCount = byteArray:readByte()
			ret.results = {}
			for i=1,ret.playerCount do
				local r = {}
				r.seatID = byteArray:readByte()
				r.totalCoins = byteArray:readLong()
				r.currenWinAmount = byteArray:readLong()
				r.cardLen = byteArray:readByte()
				r.cards = {}
				for i=1,r.cardLen  do
					local temp = byteArray:readByte()
					if temp == 0x50 then
						temp = 0x01
					end
					if temp == 0x51 then
						temp = 0x02
					end
					table.insert(r.cards,temp)
				end 
				r.otherInfo = byteArray:readString(byteArray:readShort())
				table.insert(ret.results,r)
			end 
			ret.Extra = byteArray:readString(byteArray:readShort())
			if ret.Extra and ret.Extra ~= "" then 
				ret.Extra = json.decode(ret.Extra)
			end
			return ret
		end,	
		[DataUnpacker.CMD[DataUnpacker.Type.MATCH_GAME]['RCV'].WAITING_OTHERS ] = 
		{},	
		[DataUnpacker.CMD[DataUnpacker.Type.MATCH_GAME]['RCV'].ONE_ROUND_OVER ] = 
		{
			{dataType = DataPacker.BYTE ,dataName='round'}, 
			{dataType = DataPacker.STRING,dataName='otherInfo'},
		},
		[DataUnpacker.CMD[DataUnpacker.Type.MATCH_GAME]['RCV'].MATCH_OVER ] = 
		{
			{dataType = DataPacker.LONG,dataName='point'},
			{dataType = DataPacker.SHORT,dataName='rank'},
			{dataType = DataPacker.STRING,dataName='otherInfo'},

		},	
		[DataUnpacker.CMD[DataUnpacker.Type.MATCH_GAME]['RCV'].LORD_SATTLED_WHOS_DOUBLE ] = 
		function(byteArray)
			local ret =  {} 
			ret.lordSeatID = byteArray:readByte()
			ret.cardLen = byteArray:readByte()
			ret.cards={}
			for i=1,ret.cardLen  do
				local temp = byteArray:readByte()
				if temp == 0x50 then
					temp = 0x01
				end
				if temp == 0x51 then
					temp = 0x02
				end
				table.insert(ret.cards,temp)
			end  
			return ret
		end,	
		[DataUnpacker.CMD[DataUnpacker.Type.MATCH_GAME]['RCV'].MATCH_FAIL ] = 
        {
           {dataType = DataPacker.STRING,dataName='msg'},
        },	
		[DataUnpacker.CMD[DataUnpacker.Type.MATCH_GAME]['RCV'].MATCH_RANK] = 
		{
			{dataType = DataPacker.SHORT,dataName='rank'},
			{dataType = DataPacker.SHORT,dataName='totalNumber'},

		},	
	}  


    DataUnpacker.unpackTable[DataUnpacker.Type.GAME_Wanren] = 
    {
    	[DataUnpacker.CMD[DataUnpacker.Type.GAME_Wanren]['RCV'].HEARTBEAT 			] = 
		{
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Wanren]['RCV'].LOGIN_SUCC 			] = 
        function(byteArray)
           local ret = {}
           ret.ZhuangNeed     = byteArray:readInt()    --上庄金币条件
           ret.WaitChipTime   = byteArray:readByte()   --等待下注时间
           ret.WaitResTime    = byteArray:readByte()   --等待结果时间 
           ret.BaseChip       = byteArray:readInt()    --最小下注 
           ret.MaxChip        = byteArray:readInt()    --最大限制
           ret.NiuState       = byteArray:readByte()   --当前状态 

           ret.DealerUid      = byteArray:readInt()    --庄家
           ret.DealerNick     = byteArray:readString(byteArray:readShort()) 
           ret.DealerChip     = byteArray:readLong() 
           ret.DealerVipType  = byteArray:readByte()  
           ret.DealerVipLevel = byteArray:readByte()  
           ret.DealerSex      = byteArray:readByte()  
           ret.DealerIcon     = byteArray:readString(byteArray:readShort()) 
           ret.DealerOtherInfo= byteArray:readString(byteArray:readShort()) 
            
           
           ret.poolCount =  byteArray:readByte() 
           if ret.poolCount > 0 then 
               ret.poolInfo = {} 
	           for key = 1 ,ret.poolCount do 
	               local t = {}  
	               t.seatId         = byteArray:readByte()  
	               t.chip           = byteArray:readLong() 
	               
	               t.cardCount      = byteArray:readByte()   
	               if t.cardCount > 0 then 
	                  t.card = {}
	                  for i = 1 ,t.cardCount do 
	                  	  t.card[i] = byteArray:readByte()   
	                  end 
	               end      	  
	               table.insert(ret.poolInfo,t)
	           end   
	       end     
           -- 自己
           ret.uid         =   byteArray:readInt()    
           ret.nick        =   byteArray:readString(byteArray:readShort()) 
           ret.chip        =   byteArray:readLong() 
           ret.vipType     =   byteArray:readByte()  
           ret.vipLevel    =   byteArray:readByte()  
           ret.sex         =   byteArray:readByte()  
           ret.icon        =   byteArray:readString(byteArray:readShort()) 
           ret.otherInfo   =   byteArray:readString(byteArray:readShort()) 

           ret.chipCount   =   byteArray:readByte()  
           if ret.chipCount > 0 then 
              ret.chipInfo = {} --自己各个奖池的下注信息
              for k = 1 ,ret.chipCount do 
              	  local t = {} 
              	  t.seatId =  byteArray:readByte()  
              	  t.chip   =  byteArray:readLong() 
                  table.insert(ret.chipInfo,t)
              end     
           end 	
           ret.SeatCount   =  byteArray:readByte()  

           if ret.SeatCount > 0 then  
              ret.seatInfo = {}  --每个座位上的玩家信息
              for k = 1, ret.SeatCount do 
                  local t = {} 
                  t.seatId      =  byteArray:readByte()  
                  t.uid         =  byteArray:readInt()    
                  t.nick        =  byteArray:readString(byteArray:readShort()) 
              	  t.coin        =  byteArray:readLong() 
		          t.vipType     =   byteArray:readByte()  
		          t.vipLevel    =   byteArray:readByte()  
		          t.sex         =   byteArray:readByte()  
		          t.icon        =   byteArray:readString(byteArray:readShort()) 
		          t.otherInfo   =   byteArray:readString(byteArray:readShort()) 
		          table.insert(ret.seatInfo,t)
              end  
           end
           

           ret.HisTrendCount =  byteArray:readByte()   
           if ret.HisTrendCount > 0 then 
              ret.HisTrend = {} --历史走势
              for k = 1 ,ret.HisTrendCount do 
              	  local t = {} 
              	  local length = byteArray:readByte()  
              	  if length > 0 then 
              	     for i=1 ,length do 
              	     	t[i] = byteArray:readByte()   
              	     end  	
              	  end    
                  table.insert(ret.HisTrend,t)
              end     
           end

           ret.DealerNumCount = byteArray:readShort()   
           if ret.DealerNumCount > 0 then  
              ret.DealerList = {}  --庄家列表
              for k = 1, ret.DealerNumCount do 
                  local t = {} 
                  t.dealerId      =  byteArray:readShort()  
                  t.uid         =  byteArray:readInt()    
                  t.nick        =  byteArray:readString(byteArray:readShort()) 
              	  t.coin        =  byteArray:readLong() 
		          t.vipType     =   byteArray:readByte()  
		          t.vipLevel    =   byteArray:readByte()  
		          t.sex         =   byteArray:readByte()  
		          t.icon        =   byteArray:readString(byteArray:readShort()) 
		          t.otherInfo   =   byteArray:readString(byteArray:readShort()) 
		          table.insert(ret.DealerList,t)
              end  
           end

           ret.currChipTime = byteArray:readByte()  
           ret.currWResTime = byteArray:readByte()
        

           ret.PlayerNumCount = byteArray:readShort()   
           if ret.PlayerNumCount > 0 then  
              ret.PlayerList = {}  --玩家列表
              for k = 1, ret.PlayerNumCount do 
                  local t = {} 
                  t.uid         =   byteArray:readInt()    
                  t.nick        =   byteArray:readString(byteArray:readShort()) 
              	  t.coin        =   byteArray:readLong() 
		          t.vipType     =   byteArray:readByte()  
		          t.vipLevel    =   byteArray:readByte()  
		          t.sex         =   byteArray:readByte()  
		          t.icon        =   byteArray:readString(byteArray:readShort()) 
		          t.otherInfo   =   byteArray:readString(byteArray:readShort()) 
		          table.insert(ret.PlayerList,t)
              end  
           end

           return ret
		end,
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Wanren]['RCV'].GRAB_SUCC 			] = 
		{
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Wanren]['RCV'].DROP_SUCC 			] = 
		{
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Wanren]['RCV'].SEND_FIRST 			] = 
        function(byteArray)
        	local ret =  {}
        	ret.count = byteArray:readByte() 
        	if ret.count > 0 then 
        		ret.cardInfo = {} 
        		for k=1,ret.count do 
	               local t = {}  
	               t.seatId         = byteArray:readByte()  
	               
	               t.cardCount      = byteArray:readByte()   
	               if t.cardCount > 0 then 
	                  t.card = {}
	                  for i = 1 ,t.cardCount do 
	                  	  t.card[i] = byteArray:readByte()   
	                  end 
	               end      	  
	               table.insert(ret.cardInfo,t)
	            end 
	        end 
	        return ret       
	    end,
	    [DataUnpacker.CMD[DataUnpacker.Type.GAME_Wanren]['RCV'].BET_SUCC 			] = 
		{
			{dataType = DataPacker.BYTE ,dataName='seatID'}, 
			{dataType = DataPacker.LONG ,dataName='InChip'},  
			{dataType = DataPacker.LONG ,dataName='LastChip'}, 
			{dataType = DataPacker.INT , dataName='uid'},  
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Wanren]['RCV'].POOL_INFO 			] = 
		function(byteArray)
		   local ret= {}
           ret.poolCount =  byteArray:readByte() 
           if ret.poolCount > 0 then 
               ret.poolInfo = {} 
	           for key = 1 ,ret.poolCount do 
	               local t = {}  
	               t.seatId         = byteArray:readByte()  
	               t.chip           = byteArray:readLong() 	                  	 
	               table.insert(ret.poolInfo,t)
	           end   
	       end 
	       return ret 
	    end, 
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Wanren]['RCV'].FORBID_BET ] = 
		{
		},	   
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Wanren]['RCV'].CHAT 				] = 
		{ 
			{dataType = DataPacker.INT ,dataName	='playerUID'    }, 
			{dataType = DataPacker.STRING ,dataName	='msg'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Wanren]['RCV'].EMOJI 				] = 
		{ 
			{dataType = DataPacker.INT ,dataName	='playerUID'    }, 
			{dataType = DataPacker.SHORT ,dataName	='msg'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Wanren]['RCV'].CONST_TEXT 			] = 
		{
			{dataType = DataPacker.INT ,dataName	='playerUID'    }, 
			{dataType = DataPacker.SHORT ,dataName	='msg'    }, 
		},
		 		
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Wanren]['RCV'].PLAYER_COUNT 			] = 
		function(byteArray)
			local ret = {}
			ret.count = byteArray:readByte()   
			if ret.count>0 then 
			   ret.chipInfo = {} 
	           for key = 1 ,ret.count do 
	               local t = {}  
	               t.seatId         = byteArray:readByte()  
	               t.chip           = byteArray:readLong() 
	                  	  
	               table.insert(ret.chipInfo,t)
	           end 
	        end 
	        ret.playerCoin  =  byteArray:readLong()
	        ret.dealerCoin  =  byteArray:readLong()

	        ret.PlayersCount = byteArray:readShort()  
	        if ret.PlayersCount> 0 then  --有座位的玩家输赢信息
	        	ret.Players = {} 
	        	for key =1 ,ret.PlayersCount  do 
                    local t = {} 
                    t.uid  = byteArray:readInt()  
                    t.length = byteArray:readByte()   
                    if t.length > 0 then 
                    	t.info = {} 
                    	for i = 1,t.length do 
                    		local s = {} 
                    		s.siteId = byteArray:readByte()    
                    		s.result = byteArray:readLong()  
                    		table.insert(t.info,s)
                        end 
                    end 
                    t.coin = byteArray:readLong()  
                    table.insert(ret.Players ,t)    		
	            end 		
	        end    
	        return ret 
		end,	
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Wanren]['RCV'].CHANGE_DEALER 			] = 
		{

			{dataType = DataPacker.INT , dataName='uid'},  
			{dataType = DataPacker.STRING,dataName='nick'},
			{dataType = DataPacker.LONG ,dataName='coin'}, 
			{dataType = DataPacker.BYTE ,dataName='vipType'}, 
			{dataType = DataPacker.BYTE ,dataName='vipLevel'}, 
			{dataType = DataPacker.BYTE ,dataName='sex'}, 
			{dataType = DataPacker.STRING ,dataName='icon'},
			{dataType = DataPacker.STRING ,dataName='otherInfo'},
		},	
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Wanren]['RCV'].LOGOUT_SUCC 			] = 
		{
			{dataType = DataPacker.LONG ,dataName='coin'}, 
		},	
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Wanren]['RCV'].UPDATE_PLAYER 			] = 
		{
			{dataType = DataPacker.LONG ,dataName='coin'}, 
		},	
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Wanren]['RCV'].MSG_TIPS 			] = 
		{
			{dataType = DataPacker.BYTE ,dataName='msgCode'}, 
			{dataType = DataPacker.STRING 	,dataName='msg'},
			{dataType = DataPacker.BYTE ,dataName='seatId'}, 
		},	
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Wanren]['RCV'].FINAL_RESULT 	] = 
		function(byteArray)
            local ret = {}
            ret.count = byteArray:readByte()   
            if ret.count>0 then 
			   ret.doubleInfo = {} 
	           for key = 1 ,ret.count do 
	               local t = {}  
	               t.seatId         = byteArray:readByte()  
	               t.multi          = byteArray:readByte() 
	               t.cardType       = byteArray:readByte() 
	               t.valueCount     = byteArray:readByte()  
	               if  t.valueCount > 0 then 
	                   t.cardValue = {} 
	                   for i = 1,  t.valueCount do 
	                   	   t.cardValue[i] =  byteArray:readByte()   
	                   end 
	               end     	  
	               table.insert(ret.doubleInfo,t)
	           end 
	        end 
	        return ret
        end, 
        [DataUnpacker.CMD[DataUnpacker.Type.GAME_Wanren]['RCV'].PLSYER_SITDOWN 			] = 
		{
            {dataType = DataPacker.BYTE ,dataName='seatId'}, 
			{dataType = DataPacker.INT , dataName='uid'},  
			{dataType = DataPacker.STRING,dataName='nick'},
			{dataType = DataPacker.LONG ,dataName='coin'}, 
			{dataType = DataPacker.BYTE ,dataName='vipType'}, 
			{dataType = DataPacker.BYTE ,dataName='vipLevel'}, 
			{dataType = DataPacker.BYTE ,dataName='sex'}, 
			{dataType = DataPacker.STRING 	,dataName='icon'},
			{dataType = DataPacker.STRING 	,dataName='otherInfo'},
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Wanren]['RCV'].PLSYER_STANDUP 			] = 
		{
			{dataType = DataPacker.BYTE ,dataName='SeatId'}, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Wanren]['RCV'].DEALER_LIST 			] = 
        function(byteArray)
           local ret= {} 
           ret.DealerNumCount = byteArray:readShort()   
           if ret.DealerNumCount > 0 then  
              ret.DealerList = {}  --庄家列表
              for k = 1, ret.DealerNumCount do 
                  local t = {} 
                  t.dealerId    =   byteArray:readShort()  
                  t.uid         =   byteArray:readInt()    
                  t.nick        =   byteArray:readString(byteArray:readShort()) 
              	  t.coin        =   byteArray:readLong() 
		          t.vipType     =   byteArray:readByte()  
		          t.vipLevel    =   byteArray:readByte()  
		          t.sex         =   byteArray:readByte()  
		          t.icon        =   byteArray:readString(byteArray:readShort()) 
		          t.otherInfo   =   byteArray:readString(byteArray:readShort()) 
		          table.insert(ret.DealerList,t)
              end  
           end
           return ret 
        end,
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Wanren]['RCV'].SOMEONE_BET 			] = 
		{
			{dataType = DataPacker.BYTE ,dataName='seatId'}, 
			{dataType = DataPacker.LONG ,dataName='coin'}, 
			{dataType = DataPacker.INT , dataName='uid'},  
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Wanren]['RCV'].SOMEONE_IN 			] = 
		{
			{dataType = DataPacker.INT , dataName='uid'},  
			{dataType = DataPacker.STRING,dataName='nick'},
			{dataType = DataPacker.LONG ,dataName='coin'}, 
			{dataType = DataPacker.BYTE ,dataName='vipType'}, 
			{dataType = DataPacker.BYTE ,dataName='vipLevel'}, 
			{dataType = DataPacker.BYTE ,dataName='sex'}, 
			{dataType = DataPacker.STRING 	,dataName='icon'},
			{dataType = DataPacker.STRING 	,dataName='otherInfo'},
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Wanren]['RCV'].SOMEONE_OUT 			] = 
		{
		   	{dataType = DataPacker.INT , dataName='uid'},  
	    },
    }


    DataUnpacker.unpackTable[DataUnpacker.Type.GAME_Douniu] =
    { 	 

    	[DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].HEARTBEAT 			] = 
		{
			
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].RSPD_FAIL 			] = 
		{ 
			{dataType = DataPacker.BYTE ,dataName='actionId'}, 
			{dataType = DataPacker.BYTE ,dataName='failedType'}, 
			{dataType = DataPacker.STRING ,dataName='failedStr'}, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].LOGIN_SUCC 			] = 
		
			function(byteArray)
				local ret = {}
				ret.MySeatID 				= byteArray:readByte()
				ret.tableType 				= byteArray:readByte()
				ret.GrabTimeOut 			= byteArray:readByte()
				ret.MultiTimeOut 			= byteArray:readByte()
				ret.TurnTimeOut 			= byteArray:readByte()
				ret.baseChip 				= byteArray:readInt() 
				ret.TableOther 				= byteArray:readString(byteArray:readShort())
				ret.TableState 				= byteArray:readByte()
				ret.CurrentDealerSeatId 	= byteArray:readByte()
				ret.CurrentStateGoneTime 	= byteArray:readByte()
				ret.CurrentDealerMulti 		= byteArray:readInt() 
 
				ret.users = {}
				ret.userCount = byteArray:readByte()

				for i=1,ret.userCount do
					local t = {}
					t.seatID         	= byteArray:readByte()
					t.Uid            	= byteArray:readInt()
					t.Coin           	= byteArray:readLong()
					t.Sex            	= byteArray:readByte()

					t.Name           	= byteArray:readString(byteArray:readShort())
 
					t.PicUrl           	= byteArray:readString(byteArray:readShort())
					t.VLevel         	= byteArray:readUByte()
					t.VType          	= byteArray:readUByte()
					t.PlayerState    	= byteArray:readByte()
					t.GrabMulti  		= byteArray:readInt()
					t.MaxGrabMulti 		= byteArray:readInt()
					t.Multi 	 		= byteArray:readInt()
					t.MinMulti  		= byteArray:readInt()
					t.MaxMulti  		= byteArray:readInt()
					t.TurnCardType   		= byteArray:readByte()
					t.CardCount   		= byteArray:readByte()
					t.Cards 			= {
						[1] = byteArray:readByte(),
						[2] = byteArray:readByte(),
						[3] = byteArray:readByte(),
						[4] = byteArray:readByte(),
						[5] = byteArray:readByte(),
					}
					t.extra = byteArray:readString(byteArray:readShort())
					-- for i=1,t.CardCount do
					-- 	table.insert(t.Cards,byteArray:readUByte())
					-- end  
					-- dump(ret,"ret")
					-- dump(t,"t")
					table.insert(ret.users,t)
				end 
				return ret
			end,
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].LOGOUT_SUCC			] = 
		{
			
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].LOGIN_CONFLICT		] = 
		{
			
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].UPDATE_PLAYER 		] = 
		{
			
			{dataType = DataPacker.INT ,dataName='playerUID'}, 
			{dataType = DataPacker.LONG ,dataName='coins'}, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].PLAYER_CONNECTED	] = 
		{
			
			{dataType = DataPacker.BYTE ,dataName	='seatID' }, 
			{dataType = DataPacker.INT ,dataName	='Uid'    }, 
			{dataType = DataPacker.LONG ,dataName	='Coin'   }, 
			{dataType = DataPacker.BYTE ,dataName	='Sex'}, 
			{dataType = DataPacker.STRING ,dataName	='Name'}, 
			{dataType = DataPacker.STRING ,dataName	='PicUrl'},  
			{dataType = DataPacker.UBYTE ,dataName	='VLevel'}, 
			{dataType = DataPacker.UBYTE ,dataName	='VType'}, 
			{dataType = DataPacker.UBYTE ,dataName	='PlayerState'}, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].PLAYER_DISCONNECTED	] = 
		{
			{dataType = DataPacker.INT ,dataName	='Uid' },  
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].START_GRAB_HOST] =  	
		 
			function (byteArray)
				local ret = {}
				ret.EnterGameSeatId = {}
				local len = byteArray:readByte()
				for i=1,len do
					table.insert(ret.EnterGameSeatId,byteArray:readByte())
				end
				ret.CardCount = byteArray:readUByte()
				ret.Cards = {} 
				for i=1,ret.CardCount do
					table.insert(ret.Cards,byteArray:readUByte())
				end

				ret.MaxMulti = byteArray:readInt()
				return ret
			end,
		 
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].PLAYER_READY		] = 
		{
			
			{dataType = DataPacker.BYTE ,dataName	='seatID'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].START_MULTIPLY			] = 
		{

			{dataType = DataPacker.BYTE ,dataName	='DealSeatId' }, 
			{dataType = DataPacker.INT ,dataName	='GrabMulti'    }, 
			{dataType = DataPacker.INT ,dataName	='MinMulti'    }, 
			{dataType = DataPacker.INT ,dataName	='MaxMulti'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].START_SHOW_CARDS		] = 
		function ( byteArray )
			local ret = {}
			ret.CardCount = byteArray:readByte()
			ret.cards = {}
			for i=1,ret.CardCount do
				table.insert(ret.cards,byteArray:readUByte())
			end
			return ret
		end,
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].PLAYER_GRAB_HOST		] = 
		{
			
			{dataType = DataPacker.BYTE ,dataName	='seatID'    }, 
			{dataType = DataPacker.INT ,dataName	='multi'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].PLAYER_MULTIPLY			] = 
		{
			
			{dataType = DataPacker.BYTE ,dataName	='seatID'    }, 
			{dataType = DataPacker.INT ,dataName	='multi'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].PLAYER_SHOW_CARDS			] = 
		{

			{dataType = DataPacker.BYTE ,dataName	='seatID'    }, 
			{dataType = DataPacker.BYTE ,dataName	='CardType'    }, 

			{dataType = DataPacker.UBYTE ,dataName	='card1'    }, 
			{dataType = DataPacker.UBYTE ,dataName	='card2'    }, 
			{dataType = DataPacker.UBYTE ,dataName	='card3'    }, 
			{dataType = DataPacker.UBYTE ,dataName	='card4'    }, 
			{dataType = DataPacker.UBYTE ,dataName	='card5'    }, 
		},
		-- [DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].PLAYER_DROP_CARDS	] = 
		-- {
			
		-- 	{dataType = DataPacker.BYTE ,dataName	='seatID'    }, 
		-- 	{dataType = DataPacker.BYTE ,dataName	='NextSeatId'    }, 
		-- 	{dataType = DataPacker.BYTE ,dataName	='WheelCount'    }, 
		-- },
		-- [DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].PLAYER_COMPARE		] = 
		-- {
			
		-- 	{dataType = DataPacker.BYTE ,dataName	='seatID'    }, 
		-- 	{dataType = DataPacker.INT ,dataName	='FitCardChip'    }, 
		-- 	{dataType = DataPacker.BYTE ,dataName	='ToFitSeatId'    }, 
		-- 	{dataType = DataPacker.BYTE ,dataName	='IsWin'    }, 
		-- 	{dataType = DataPacker.BYTE ,dataName	='NextSeatId'    }, 
		-- 	{dataType = DataPacker.BYTE ,dataName	='WheelCount'    }, 
		-- },
		-- [DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].PLAYER_ALLIN		] = 
		-- {
			
		-- 	{dataType = DataPacker.BYTE ,dataName	='seatID'    }, 
		-- 	{dataType = DataPacker.INT ,dataName	='allinCoin'    }, 
		-- 	{dataType = DataPacker.BYTE ,dataName	='NextSeatId'    }, 
		-- 	{dataType = DataPacker.BYTE ,dataName	='WheelCount'    }, 
		-- },
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].GAME_ROUND_OVER		] = 
		function (byteArray)
			local ret = {} 
			ret.playInfoCount = byteArray:readByte()
			ret.PlayInfoList = {}
			for i=1,ret.playInfoCount do
				local t = {}
				t.seatID = byteArray:readByte()
				t.WinLossChip = byteArray:readLong()
				t.TotalChip = byteArray:readLong()
				t.CardTypeMulti = byteArray:readByte()
				table.insert(ret.PlayInfoList,t)
			end
			return ret
		end,
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].CHAT 				] = 
		{ 
			{dataType = DataPacker.INT ,dataName	='playerUID'    }, 
			{dataType = DataPacker.STRING ,dataName	='msg'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].EMOJI 				] = 
		{ 
			{dataType = DataPacker.INT ,dataName	='playerUID'    }, 
			{dataType = DataPacker.SHORT ,dataName	='msg'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].CONST_TEXT 			] = 
		{
			{dataType = DataPacker.INT ,dataName	='playerUID'    }, 
			{dataType = DataPacker.SHORT ,dataName	='msg'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].SENDGIFT			] = 
		{
			
			{dataType = DataPacker.INT ,dataName	='playerUID'    },  
			{dataType = DataPacker.INT ,dataName	='BePlayerUID'    },  
			{dataType = DataPacker.BYTE ,dataName	='giftID'    },  
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].KIKPLAYER			] = 
		{
			
			{dataType = DataPacker.INT ,dataName	='playerUID'    },  
			{dataType = DataPacker.INT ,dataName	='BePlayerUID'    }, 
		},
		-- [DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].FORBID 				] = 
		-- {
			
		-- 	{dataType = DataPacker.BYTE ,dataName	='seatID'    }, 
		-- },
		-- [DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].MULTIPLY_FIVE		] = 
		-- {
		-- 	{dataType = DataPacker.BYTE ,dataName	='seatID'    }, 
			
		-- },
		-- [DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].MULTIPLY_TEN		] = 
		-- {
		-- 	{dataType = DataPacker.BYTE ,dataName	='seatID'    }, 
			
		-- },
		-- [DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].CHANGE_CARD 		] = 
		-- {
			
		-- 	{dataType = DataPacker.BYTE ,dataName	='seatID'    }, 
		-- 	{dataType = DataPacker.UBYTE ,dataName	='card'    }, 
		-- },
		-- [DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].CHANGE_CARD_APPLY	] = 
		-- {
			
		-- 	{dataType = DataPacker.BYTE ,dataName	='seatID'    }, 
		-- 	{dataType = DataPacker.UBYTE ,dataName	='oldCard'    },
		-- 	{dataType = DataPacker.UBYTE ,dataName	='newCard'    },
		-- },
		-- [DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].ITEM_EXPIRED		] = 
		-- {
			
		-- 	{dataType = DataPacker.BYTE ,dataName	='seatID'    }, 
		-- 	{dataType = DataPacker.BYTE ,dataName	='itemID'    }, 
		-- },
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].SYS_INFO			] = 
		{
			
			{dataType = DataPacker.BYTE ,dataName	='infotype'    }, 
			{dataType = DataPacker.STRING ,dataName	='info'    }, 
			{dataType = DataPacker.BYTE ,dataName	='siteid'    }, 
		},
		-- [DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].MATCH_NEW_ROUND		] = 
		-- {
			
		-- 	{dataType = DataPacker.BYTE ,dataName	='currentRound'    }, 
		-- 	{dataType = DataPacker.INT ,dataName	='baseCoins'    }, 
		-- },
		-- [DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].MATCH_OVER			] = 
		-- {
			
		-- 	{dataType = DataPacker.BYTE ,dataName	='seatID'    }, 
		-- 	{dataType = DataPacker.INT ,dataName	='totalCoins'    }, 
		-- 	{dataType = DataPacker.INT ,dataName	='Score'    }, 
		-- 	{dataType = DataPacker.INT ,dataName	='Gem'    }, 
		-- 	{dataType = DataPacker.STRING ,dataName	='msg'    }, 
		-- },
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].NETWORK_BAD_TRAFFIC	] = 
		{
			
			{dataType = DataPacker.BYTE ,dataName	='seatID'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].FRIEND_REQUEST		] = 
		{
			
			{dataType = DataPacker.INT ,dataName	='PlayerId'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].FRIEND_REQUEST_RESULT] = 
		{
			
			{dataType = DataPacker.INT ,dataName	='fromId'    }, 
			{dataType = DataPacker.INT ,dataName	='toId'    }, 
			{dataType = DataPacker.BYTE ,dataName	='agree'    }, 
		},
		-- [DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['RCV'].TIMEOUT_ACTION_SUCC	] = 
		-- {
			
		-- },
	}


    DataUnpacker.unpackTable[DataUnpacker.Type.GAME_Sanzhang] =
    { 	 

    	[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].HEARTBEAT 			] = 
		{
			
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].RSPD_FAIL 			] = 
		{ 
			{dataType = DataPacker.BYTE ,dataName='actionId'}, 
			{dataType = DataPacker.BYTE ,dataName='failedType'}, 
			{dataType = DataPacker.STRING ,dataName='failedStr'}, 
			{dataType = DataPacker.BYTE ,dataName='siteid'}, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].LOGIN_SUCC 			] = 
		
			function(byteArray)
				local ret = {}
				ret.mySeatID = byteArray:readByte()
				ret.tableType = byteArray:readByte()
				ret.TableId = byteArray:readInt() 
				ret.TableName = byteArray:readString(byteArray:readShort() )
				ret.betTimeout = byteArray:readByte()
				ret.readyTimeout = byteArray:readByte()
				ret.baseChip = byteArray:readLong()
				ret.minBet = byteArray:readLong()
				ret.maxBet = byteArray:readLong()

				ret.minRound = byteArray:readByte()
				ret.maxRound = byteArray:readByte()
				ret.minChip = byteArray:readLong()
				ret.maxChip = byteArray:readLong()
				ret.users = {}
				ret.userCount = byteArray:readByte()
 
				for i=1,ret.userCount do
					local t = {}
					t.Uid            	= byteArray:readInt()
					t.seatID         	= byteArray:readByte()
					t.Coin           	= byteArray:readLong()
					t.Sex            	= byteArray:readByte()   
					t.Name           	= byteArray:readString(byteArray:readShort())
 
					t.PicUrl           	= byteArray:readString(byteArray:readShort())

					t.VLevel         	= byteArray:readUByte()
					t.VType          	= byteArray:readUByte()
					t.PlayerState    	= byteArray:readByte()
					print("t.PlayerState ：",t.PlayerState )
					if t.PlayerState == DataUnpacker.Config[DataUnpacker.Type.GAME_Sanzhang].PlayerStateWaitBet 
					or t.PlayerState == DataUnpacker.Config[DataUnpacker.Type.GAME_Sanzhang].PlayerStateBetOn 
					or t.PlayerState == DataUnpacker.Config[DataUnpacker.Type.GAME_Sanzhang].PlayerStateGiveUp then
 

						t.IsLookCard    	= byteArray:readByte()
						t.PropsType   		= byteArray:readByte() 
						t.BetTotal  		= byteArray:readLong()
						t.CardCount   		= byteArray:readByte()
						t.Cards 			= {} 
						for i=1,t.CardCount do
							table.insert(t.Cards,byteArray:readUByte()) 
						end 
					end 
 
					table.insert(ret.users,t)
				end 
				ret.TableOther 				= byteArray:readString(byteArray:readShort())
				ret.TableState 				= byteArray:readByte()
				ret.IsFirstPlaying = 1
				ret.CurrentWheel = 1
				ret.CurrentBet = ret.minBet
				if  DataUnpacker.Config[DataUnpacker.Type.GAME_Sanzhang].JINNIU_ROOM_STATE_PLAY  == ret.TableState  then 
					ret.DealerID 				= byteArray:readByte()
					ret.CurrentWheel 			= byteArray:readByte()
					-- ret.TableState 				= byteArray:readByte()
					ret.CurrentBet 				= byteArray:readLong()
					ret.CurrentTotalBet 		= byteArray:readLong()
					ret.CurrentBetSeatId 		= byteArray:readByte()
					ret.CurrentStateGoneTime 	= byteArray:readByte()
					ret.CurrentAllinSeatId 		= byteArray:readByte()
					ret.CurrentAllinMoney 		= byteArray:readLong()
					ret.IsFirstPlaying	 		= byteArray:readByte()-- 1 == 第一个下注
				end
				return ret
			end,
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].LOGOUT_SUCC			] = 
		{
			
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].LOGIN_CONFLICT		] = 
		{
			
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].UPDATE_PLAYER 		] = 
		{
			
			{dataType = DataPacker.INT ,dataName='playerUID'}, 
			{dataType = DataPacker.LONG ,dataName='coins'}, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].PLAYER_CONNECTED	] = 
		{
			
			{dataType = DataPacker.INT ,dataName	='Uid'    }, 
			{dataType = DataPacker.BYTE ,dataName	='seatID' }, 
			{dataType = DataPacker.LONG ,dataName	='Coin'   }, 
			{dataType = DataPacker.BYTE ,dataName	='Sex'    }, 
			{dataType = DataPacker.STRING ,dataName	='Name'    }, 
			{dataType = DataPacker.STRING ,dataName	='PicUrl'    },  
			{dataType = DataPacker.UBYTE ,dataName	='VLevel'    }, 
			{dataType = DataPacker.UBYTE ,dataName	='VType'    }, 
			{dataType = DataPacker.UBYTE ,dataName	='PlayerState'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].PLAYER_DISCONNECTED	] = 
		{
			
			{dataType = DataPacker.INT ,dataName	='Uid' },  
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].GAME_READY			] = 
		{
			
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].GAME_START 			] = 
		 
			function (byteArray)
				local ret = {}
				ret.EnterGameSeatId = {}
				local len = byteArray:readByte()
				for i=1,len do
					table.insert(ret.EnterGameSeatId,byteArray:readByte())
				end 
				ret.DealerSeatId = byteArray:readByte()
				ret.BetSeatId = byteArray:readByte()
				return ret
			end,
		 
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].PLAYER_READY		] = 
		{
			
			{dataType = DataPacker.BYTE ,dataName	='seatID'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].PLAYER_PEEK			] = 
		function ( byteArray )
			local ret = {}
			ret.seatID = byteArray:readByte()
			ret.cards = {}
			for i=1,byteArray:readByte() do
				table.insert(ret.cards,byteArray:readUByte())
			end
			return ret
		end,
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].PLAYER_FOLLOW		] = 
		{
			
			{dataType = DataPacker.BYTE ,dataName	='seatID'    }, 
			{dataType = DataPacker.LONG ,dataName	='followCoin'    }, 
			{dataType = DataPacker.BYTE ,dataName	='NextSeatId'    }, 
			{dataType = DataPacker.BYTE ,dataName	='WheelCount'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].PLAYER_ADD_BET		] = 
		{
			
			{dataType = DataPacker.BYTE ,dataName	='seatID'    }, 
			{dataType = DataPacker.LONG ,dataName	='addCoin'    }, 
			{dataType = DataPacker.BYTE ,dataName	='NextSeatId'    }, 
			{dataType = DataPacker.BYTE ,dataName	='WheelCount'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].FOUTH_CARD			] = 
		function ( byteArray )
			local ret = {}
			ret.CardCount = byteArray:readByte()
			ret.cards = {}
			for i=1,ret.cards do
				table.insert(ret.cards,byteArray:readByte())
			end
			return ret
		end,
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].LAST_CARD			] = 
		function (byteArray)
			local ret = {}
			ret.CardCount = byteArray:readByte()
			ret.cards = {}
			for i=1,ret.cards do
				table.insert(ret.cards,byteArray:readByte())
			end
			return ret
		end,
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].PLAYER_DROP_CARDS	] = 
		{
			
			{dataType = DataPacker.BYTE ,dataName	='seatID'    }, 
			{dataType = DataPacker.BYTE ,dataName	='NextSeatId'    }, 
			{dataType = DataPacker.BYTE ,dataName	='WheelCount'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].PLAYER_COMPARE		] = 
		{
			
			{dataType = DataPacker.BYTE ,dataName	='seatID'    }, 
			{dataType = DataPacker.LONG ,dataName	='FitCardChip'    }, 
			{dataType = DataPacker.BYTE ,dataName	='ToFitSeatId'    }, 
			{dataType = DataPacker.BYTE ,dataName	='IsWin'    }, 
			{dataType = DataPacker.BYTE ,dataName	='NextSeatId'    }, 
			{dataType = DataPacker.BYTE ,dataName	='WheelCount'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].PLAYER_ALLIN		] = 
		{
			
			{dataType = DataPacker.BYTE ,dataName	='seatID'    }, 
			{dataType = DataPacker.LONG ,dataName	='allinCoin'    }, 
			{dataType = DataPacker.BYTE ,dataName	='NextSeatId'    }, 
			{dataType = DataPacker.BYTE ,dataName	='WheelCount'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].GAME_ROUND_OVER		] = 
		function (byteArray)
			local ret = {}
			ret.WinSeatId = byteArray:readByte()
			ret.Score = byteArray:readByte()
			ret.HappyMoney = byteArray:readLong()
			ret.playInfoCount = byteArray:readByte()
			ret.PlayInfoList = {}
			for i=1,ret.playInfoCount do
				local t = {}
				t.seatID = byteArray:readByte()
				t.WinChip = byteArray:readLong()
				t.TotalChip = byteArray:readLong() 
				t.Cards = {} 
				table.insert(t.Cards,byteArray:readByte()) 
				table.insert(t.Cards,byteArray:readByte()) 
				table.insert(t.Cards,byteArray:readByte()) 
				table.insert(ret.PlayInfoList,t)
			end
			return ret
		end,
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].CHAT 				] = 
		{ 
			{dataType = DataPacker.INT ,dataName	='playerUID'    }, 
			{dataType = DataPacker.STRING ,dataName	='msg'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].EMOJI 				] = 
		{ 
			{dataType = DataPacker.INT ,dataName	='playerUID'    }, 
			{dataType = DataPacker.SHORT ,dataName	='msg'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].CONST_TEXT 			] = 
		{
			{dataType = DataPacker.INT ,dataName	='playerUID'    }, 
			{dataType = DataPacker.SHORT ,dataName	='msg'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].SENDGIFT			] = 
		{
			
			{dataType = DataPacker.INT ,dataName	='playerUID'    },  
			{dataType = DataPacker.INT ,dataName	='BePlayerUID'    },  
			{dataType = DataPacker.BYTE ,dataName	='giftID'    },  
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].KIKPLAYER			] = 
		{
			
			{dataType = DataPacker.INT ,dataName	='playerUID'    },  
			{dataType = DataPacker.INT ,dataName	='BePlayerUID'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].FORBID 				] = 
		{
			
			{dataType = DataPacker.BYTE ,dataName	='seatID'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].MULTIPLY_FIVE		] = 
		{
			{dataType = DataPacker.BYTE ,dataName	='seatID'    }, 
			
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].MULTIPLY_TEN		] = 
		{
			{dataType = DataPacker.BYTE ,dataName	='seatID'    }, 
			
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].CHANGE_CARD 		] = 
		{
			
			{dataType = DataPacker.BYTE ,dataName	='seatID'    }, 
			{dataType = DataPacker.UBYTE ,dataName	='card'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].CHANGE_CARD_APPLY	] = 
		{
			
			{dataType = DataPacker.BYTE ,dataName	='seatID'    }, 
			{dataType = DataPacker.UBYTE ,dataName	='oldCard'    },
			{dataType = DataPacker.UBYTE ,dataName	='newCard'    },
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].ITEM_EXPIRED		] = 
		{
			
			{dataType = DataPacker.BYTE ,dataName	='seatID'    }, 
			{dataType = DataPacker.BYTE ,dataName	='itemID'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].SYS_INFO			] = 
		{
			
			{dataType = DataPacker.BYTE ,dataName	='infotype'    }, 
			{dataType = DataPacker.STRING ,dataName	='info'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].MATCH_NEW_ROUND		] = 
		{
			
			{dataType = DataPacker.BYTE ,dataName	='currentRound'    }, 
			{dataType = DataPacker.LONG ,dataName	='baseCoins'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].MATCH_OVER			] = 
		{
			
			{dataType = DataPacker.BYTE ,dataName	='seatID'    }, 
			{dataType = DataPacker.LONG ,dataName	='totalCoins'    }, 
			{dataType = DataPacker.LONG ,dataName	='Score'    }, 
			{dataType = DataPacker.LONG ,dataName	='Gem'    }, 
			{dataType = DataPacker.STRING ,dataName	='msg'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].NETWORK_BAD_TRAFFIC	] = 
		{
			
			{dataType = DataPacker.BYTE ,dataName	='seatID'    }, 
			{dataType = DataPacker.BYTE ,dataName	='netState'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].FRIEND_REQUEST		] = 
		{
			
			{dataType = DataPacker.INT ,dataName	='PlayerId'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].FRIEND_REQUEST_RESULT] = 
		{
			
			{dataType = DataPacker.INT ,dataName	='fromId'    }, 
			{dataType = DataPacker.INT ,dataName	='toId'    }, 
			{dataType = DataPacker.BYTE ,dataName	='agree'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['RCV'].TIMEOUT_ACTION_SUCC	] = 
		{
			
		},
	}

    DataUnpacker.unpackTable[DataUnpacker.Type.GAME] =
	{ 



		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].TABLE_LOGIN_SUCESS 		] = 
		function(dp)
			local room = {}
			room.roomType = dp:readInt();
			room.roomId = dp:readInt();
			room.bpour = dp:readInt();
			room.waitTimeOut = dp:readByte();
			room.outTimeOut = dp:readByte();
			room.lordSeatID = dp:readByte(); 
			room.selfSeat = dp:readByte();
			room.roomState = dp:readByte();
			room.userNum = dp:readByte();
			room.userData = {}
			for i=1,room.userNum do
				local ret = {} 
				ret.seatID = dp:readByte()
				ret.UID    = dp:readInt() 
				local strLen = dp:readShort() 
				ret.nickName = dp:readString(strLen)
				ret.role  = dp:readByte() 
				ret.coins = dp:readUInt() 
				ret.sex   = dp:readByte()
				ret.vipLevel = dp:readByte()
				ret.vipType  = dp:readByte()
				ret.status = dp:readByte()
				strLen     = dp:readShort() 
				ret.iconUrl = dp:readString(strLen)
				ret.cardLen = dp:readByte()
				strLen = dp:readShort() 
				ret.ext= dp:readString(strLen)
				table.insert(room.userData ,ret)
			end
			if  room.roomState ~= DataUnpacker.ConfigTable.ROOM_STATE_WAIT  then
				room.autoPlayStatus = dp:readByte()
				room.doubleAmount = dp:readShort() 
				room.lordCardCount = dp:readByte()
				room.lordCards = {}
				for i=1,room.lordCardCount do
					table.insert(room.lordCards,dp:readByte())
				end
				room.currentSeat =  dp:readByte()
				room.userCardCount = dp:readByte()
				room.userCards = {}
				for i=1,room.userCardCount do
					table.insert(room.userCards,dp:readByte())
				end
				room.lastPlayerSeatID = dp:readByte()
				room.lastPlayerCardType = dp:readByte()
				room.lastPlayerCardCount = dp:readByte()
				room.lastPlayerCards = {}
				for i=1,room.lastPlayerCardCount do
					table.insert(room.lastPlayerCards,dp:readByte())
				end 
			end
			strLen =dp:readShort() 
			room.roomExtend = json.decode(dp:readString(strLen))

			return room
		end,
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].TABLE_LOGOUT_SUCESS 	] = 
		{
			{dataType = DataPacker.UINT ,dataName='userCurrentCoins'}, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].PLAYER_DISCONNECTED 	] = 
		{ 
			{dataType = DataPacker.BYTE ,dataName='seatID'}, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].PLAYER_CONNECTED 		] = 
		{ 
			{dataType = DataPacker.BYTE ,dataName='seatID'}, 
			{dataType = DataPacker.INT ,dataName='UID'}, 
			{dataType = DataPacker.STRING ,dataName='nickName'}, 
			{dataType = DataPacker.BYTE ,dataName='role'}, 
			{dataType = DataPacker.UINT ,dataName='coins'}, 
			{dataType = DataPacker.BYTE ,dataName='sex'}, 
			{dataType = DataPacker.BYTE ,dataName='vipLevel'}, 
			{dataType = DataPacker.BYTE ,dataName='vipType'}, 
			{dataType = DataPacker.BYTE ,dataName='status'}, 
			{dataType = DataPacker.STRING ,dataName='iconUrl'}, 
			{dataType = DataPacker.BYTE ,dataName='cardLen'}, 
			{dataType = DataPacker.STRING ,dataName='ext'}, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].PLAYER_READY 			] = 
		{ 
			{dataType = DataPacker.BYTE ,dataName='seatID'}, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].DEAL_CARDS 				] = 
		function(byteArray)
			local ret = {}
			ret.first = byteArray:readByte()
			ret.len = byteArray:readByte()
			ret.cards = {}
			for i=1,ret.len  do
				table.insert(ret.cards,byteArray:readByte())
			end
			return ret
		end,
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].PLAYER_PLAY_CARD 		] = 
		function(byteArray)
			local ret = {}
			ret.seatID = byteArray:readByte()
			ret.nextID = byteArray:readByte()
			ret.cardType = byteArray:readByte()
			ret.cardLen = byteArray:readByte()
			ret.cards = {}
			for i=1,ret.cardLen  do
				table.insert(ret.cards,byteArray:readByte())
			end
			return ret
		end,
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].PLAYER_PASS 			] = 
		{

			{dataType = DataPacker.BYTE ,dataName='seatID'}, 
			{dataType = DataPacker.BYTE ,dataName='nextID'}, 
			{dataType = DataPacker.BYTE ,dataName='isNewRound'}, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].ROUND_OVER 				] = 
		function(byteArray)
			local ret = {}
			ret.doubleAmount = byteArray:readShort()
			ret.playerCount = byteArray:readByte()
			ret.results = {}
			for i=1,ret.playerCount do
				local r = {}
				r.seatID = byteArray:readByte()
				r.totalCoins = byteArray:readUInt()
				r.currenWinAmount = byteArray:readInt()
				r.cardLen = byteArray:readByte()
				r.cards = {}
				for i=1,r.cardLen  do
					table.insert(r.cards,byteArray:readByte())
				end 
				table.insert(ret.results,r)
			end 
			ret.Extra = byteArray:readString(byteArray:readShort())
			if ret.Extra and ret.Extra ~= "" then 
				ret.Extra = json.decode(ret.Extra)
			end
			return ret
		end, 
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].PLAY_CARD_ERROR 		] = 
		 
		function(byteArray)
			local ret = {} 
			ret.cards = {}
			ret.cardLen = byteArray:readByte()
			for i=1,ret.cardLen  do
				table.insert(ret.cards,byteArray:readByte())
			end  
			return ret
		end
		 ,
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].CAMP_SIGNUP_RESULT 		] = 
		{ 
			{dataType = DataPacker.INT ,dataName='tableType'}, 
			{dataType = DataPacker.INT ,dataName='costs'}, 
			{dataType = DataPacker.INT ,dataName='remaining'}, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].CAMP_WITHDRAW_RESULT 	] = 
		{ 
			{dataType = DataPacker.INT ,dataName='tableType'}, 
			{dataType = DataPacker.INT ,dataName='costs'}, 
			{dataType = DataPacker.INT ,dataName='remaining'}, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].CAMP_INFO 				] = 
		{

			{dataType = DataPacker.STRING ,dataName='info'}, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].CAMP_RESULT 			] = 
		{

			{dataType = DataPacker.INT ,dataName='rank'}, 
			{dataType = DataPacker.INT ,dataName='tableType'}, 
			{dataType = DataPacker.INT ,dataName='costs'}, 
			{dataType = DataPacker.INT ,dataName='remaining'}, 
			{dataType = DataPacker.STRING ,dataName='desc'}, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].WHO_DECIDE_TO_BE_LORD	] = 
		{

			{dataType = DataPacker.BYTE ,dataName='seatID'}, 
			{dataType = DataPacker.BYTE ,dataName='nextID'}, 
			{dataType = DataPacker.BYTE ,dataName='forceAction'}, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].LORD_SATTLED_WHOS_DOUBLE ] = 
		function(byteArray)
			local ret = {} 
			ret.lordSeatID = byteArray:readByte()
			ret.cardLen = byteArray:readByte()
			ret.cards={}
			for i=1,ret.cardLen  do
				table.insert(ret.cards,byteArray:readByte())
			end  
			ret.firstDoubledSeatID = byteArray:readByte()
			ret.forceAction = byteArray:readByte()
			
			return ret
		end,
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].WHO_DOUBLED 			] = 
		{ 
			{dataType = DataPacker.BYTE ,dataName='seatID'}, 
			{dataType = DataPacker.BYTE ,dataName='isDoubled'}, 
			{dataType = DataPacker.BYTE ,dataName='nextID'}, 
			{dataType = DataPacker.BYTE ,dataName='forceAction'}, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].UPDATE_PLAYER 		] = 
		{ 
			{dataType = DataPacker.BYTE ,dataName='seatID'}, 
			{dataType = DataPacker.UINT ,dataName='coins'}, 
			{dataType = DataPacker.BYTE ,dataName='type'}, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].WHO_DECIDE_TO_CALL_LORD 	] = 
		{
			{dataType = DataPacker.BYTE ,dataName='seatID'}, 
			{dataType = DataPacker.BYTE ,dataName='prevSeatID'}, 
			{dataType = DataPacker.BYTE ,dataName='prevSeatStatus'},  
			{dataType = DataPacker.BYTE ,dataName='forceAction'}, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].WHO_DECIDE_TO_GRAB_LORD 	] = 
		{ 
			{dataType = DataPacker.BYTE ,dataName='seatID'}, 
			{dataType = DataPacker.BYTE ,dataName='prevSeatID'}, 
			{dataType = DataPacker.BYTE ,dataName='prevSeatStatus'},  
			{dataType = DataPacker.BYTE ,dataName='forceAction'}, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].CAMP_PLAYER_DATA 		] = 
		{
			{dataType = DataPacker.BYTE ,dataName='currRounds'}, 
			{dataType = DataPacker.BYTE ,dataName='totalRounds'}, 
			{dataType = DataPacker.INT ,dataName='currentScore'},
			{dataType = DataPacker.INT ,dataName='macScore'},  
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].HEARTBEAT 				] = 
		{

		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].FORCE_KICK 				] = 
		{

			{dataType = DataPacker.BYTE ,dataName='type'}, 
			{dataType = DataPacker.STRING ,dataName='msg'}, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].PLAYER_AUTOPLAY 		] = 
		{ 
			{dataType = DataPacker.BYTE ,dataName='seatID'}, 
			{dataType = DataPacker.BYTE ,dataName='autoplayStatus'}, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].PLAYER_CHAT_TEXT		] = 
		{ 
			{dataType = DataPacker.BYTE ,dataName='seatID'}, 
			{dataType = DataPacker.STRING ,dataName='msg'}, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].PLAYER_CHAT_TEXT_CONSTANCE] = 
		{ 
			{dataType = DataPacker.BYTE ,dataName='seatID'}, 
			{dataType = DataPacker.BYTE ,dataName='type'}, 
			{dataType = DataPacker.BYTE ,dataName='msgIdx'}, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].PLAYER_KICK 			] = 
		{ 
			{dataType = DataPacker.BYTE ,dataName='sentSeatID'}, 
			{dataType = DataPacker.BYTE ,dataName='receiveID'}, 
			{dataType = DataPacker.BYTE ,dataName='status'}, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].PLAYER_SENT_GIFT 		] = 
		{

			{dataType = DataPacker.BYTE ,dataName='giftType'}, 
			{dataType = DataPacker.BYTE ,dataName='sentSeatID'}, 
			{dataType = DataPacker.BYTE ,dataName='receiveID'}, 
			{dataType = DataPacker.BYTE ,dataName='status'},  
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].FRIEND_REQUEST 			] = 
		{ 
			{dataType = DataPacker.INT ,dataName='uid'},  
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].FRIEND_REQUEST_RESULT 	] = 
		{

		
			{dataType = DataPacker.INT ,dataName	='fromId'    }, 
			{dataType = DataPacker.INT ,dataName	='toId'    }, 
			{dataType = DataPacker.BYTE ,dataName	='agree'    }, 
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].CURRENT_TASKS 			] = 
		{

			{dataType = DataPacker.BYTE ,dataName='status'},  
			{dataType = DataPacker.INT ,dataName='taskID'},  
			{dataType = DataPacker.STRING ,dataName='desc'},  
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].CURRENT_TASKS_ACCOMPLISHED] = 
		{
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].CURRENT_TASKS_BONUS_RESULT] = 
		{ 
			{dataType = DataPacker.BYTE ,dataName='result'}, 
			{dataType = DataPacker.BYTE ,dataName='bonusType'},  
			{dataType = DataPacker.INT ,dataName='bonusCount'},  
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].MESSAGE_POPUP] = 
		{ 
			{dataType = DataPacker.BYTE ,dataName='msgType'}, 
			{dataType = DataPacker.STRING ,dataName='msg'},    
		},
		[DataUnpacker.CMD[DataUnpacker.Type.GAME]['RCV'].SERVER_FAIL] = 
		{ 
			{dataType = DataPacker.BYTE ,dataName='actionId'},
			{dataType = DataPacker.BYTE ,dataName='failedType'}, 
			{dataType = DataPacker.STRING ,dataName='failedStr'},    
		},

	}
  
	DataUnpacker.unpackTable[DataUnpacker.Type.HALL] =
	{

		[DataUnpacker.CMD[DataUnpacker.Type.HALL]['RCV'].HALLR_LOGIN_SUCC 				]		=
		{
			{dataType = DataPacker.STRING 	,dataName='Ports'},
			{dataType = DataPacker.INT 	,dataName='onlinePlayers'},
			{dataType = DataPacker.INT 	,dataName='lastGameUID'},
		},
		[DataUnpacker.CMD[DataUnpacker.Type.HALL]['RCV'].HALLR_GET_ONLINE_PLAYERS_COUNT ]		=
		{

			{dataType = DataPacker.INT 	,dataName='onlinePlayers'},
			{dataType = DataPacker.STRING 	,dataName='othersCount'},
		},
		[DataUnpacker.CMD[DataUnpacker.Type.HALL]['RCV'].HALLR_SYS_OLDBOARDCAST				]		=
		{

			{dataType = DataPacker.BYTE 	,dataName='msgType'},
            {dataType = DataPacker.STRING 	,dataName='msgContent'},
            {dataType = DataPacker.INT     ,dataName='uid'},
            {dataType = DataPacker.LONG     ,dataName='color'},
            {dataType = DataPacker.BYTE     ,dataName='gameType'},
            {dataType = DataPacker.SHORT    ,dataName='num'},
            {dataType = DataPacker.BYTE     ,dataName='type'},

		},
		[DataUnpacker.CMD[DataUnpacker.Type.HALL]['RCV'].HALLR_SYS_NEWBOARDCAST				]		=
		{

			{dataType = DataPacker.BYTE 	,dataName='msgType'},
            {dataType = DataPacker.STRING 	,dataName='msgContent'},
            {dataType = DataPacker.INT     ,dataName='uid'},
            {dataType = DataPacker.LONG     ,dataName='color'},
            {dataType = DataPacker.BYTE     ,dataName='gameType'},
            {dataType = DataPacker.STRING 	,dataName='name'},
            {dataType = DataPacker.BYTE     ,dataName='isBright'},
            {dataType = DataPacker.INT     ,dataName='altUid'},
            {dataType = DataPacker.STRING 	,dataName='altName'},
            {dataType = DataPacker.SHORT    ,dataName='num'},
            {dataType = DataPacker.BYTE     ,dataName='type'},


		},
		[DataUnpacker.CMD[DataUnpacker.Type.HALL]['RCV'].HALLR_FRIEND_MSG 				]		=
		{

			{dataType = DataPacker.INT 	,dataName='uid'},
			{dataType = DataPacker.STRING 	,dataName='msg'},
		},
		[DataUnpacker.CMD[DataUnpacker.Type.HALL]['RCV'].HALLR_SYS_INFO 					]		=
		{

			{dataType = DataPacker.BYTE 	,dataName='infotype'},
			{dataType = DataPacker.STRING 	,dataName='infoContent'},
		},
		[DataUnpacker.CMD[DataUnpacker.Type.HALL]['RCV'].HALLR_INVITE_FRIEND 			]		=
		{

			{dataType = DataPacker.INT 	,dataName='gameUid'},
			{dataType = DataPacker.INT 	,dataName='roomUid'},
			{dataType = DataPacker.INT 	,dataName='friendUid'},
			{dataType = DataPacker.STRING 	,dataName='friendNickname'},
		},
		[DataUnpacker.CMD[DataUnpacker.Type.HALL]['RCV'].HALLR_SERVICE_MSG 				]		=
		{

			{dataType = DataPacker.BYTE 	,dataName='infotype'},
			{dataType = DataPacker.STRING 	,dataName='infoContent'},
		},
		[DataUnpacker.CMD[DataUnpacker.Type.HALL]['RCV'].HALLR_SYNC_INFO 				]		=
		{

			{dataType = DataPacker.STRING 	,dataName='encodedjsonData'},
		},
		[DataUnpacker.CMD[DataUnpacker.Type.HALL]['RCV'].HALLR_OFFLINE_MSG 				]		=
		--{
			--gotta process manually

			 -- {dataType = DataPacker.INT 	,dataName='msgLength'},
			 -- {dataType = DataPacker.STRING 	,dataName='msgJsonEncoded'},

             function(byteArray)
            	local ret = {}
	            ret.msgLength = byteArray:readInt()
				ret.msgContent = {}
				for i=1,ret.msgLength do
					local strLen         = byteArray:readShort() 
			        ret.msgContent[i]    = byteArray:readString(strLen)
				end
				return ret 
            end, 

		--},
		[DataUnpacker.CMD[DataUnpacker.Type.HALL]['RCV'].HALLR_HEARTBEAT 				]		=
		{

		},
		[DataUnpacker.CMD[DataUnpacker.Type.HALL]['RCV'].HALLR_FORCE_OFFLINE 			]		=
		{
			{dataType = DataPacker.BYTE 	,dataName='errCode'},
			{dataType = DataPacker.STRING 	,dataName='errContent'},
		},
		[DataUnpacker.CMD[DataUnpacker.Type.HALL]['RCV'].HALLR_MISSION_ONCHANGE 			]		=
		{

			{dataType = DataPacker.STRING 	,dataName='data'},

		},
		[DataUnpacker.CMD[DataUnpacker.Type.HALL]['RCV'].HALLR_NEW_MAIL 			]		=
		{ 
			{dataType = DataPacker.BYTE 	,dataName='type'},
			{dataType = DataPacker.STRING 	,dataName='msg'},
		},
		
		[DataUnpacker.CMD[DataUnpacker.Type.HALL]['RCV'].HALLR_QUERY_NEWBIE 			]		=
		{ 
			{dataType = DataPacker.BYTE 	,dataName='newbieProgress'}, 
		},
		-- [DataUnpacker.CMD.HALL_SERVER_FRIEND_REQ 			]		=
		-- { 
		-- 	{dataType = DataPacker.INT 	,dataName='roomID'},
		-- 	{dataType = DataPacker.INT 	,dataName='friendID'},
		-- 	{dataType = DataPacker.STRING 	,dataName='friendName'},
		-- },    HALLR_TIP_MATCH_BEGIN
		[DataUnpacker.CMD[DataUnpacker.Type.HALL]['RCV'].HALLR_TIP_MATCH_BEGIN 			]		=
		{ 
			{dataType = DataPacker.INT 	,dataName='matchId'}, 
			{dataType = DataPacker.BYTE 	,dataName='matchType'},
			{dataType = DataPacker.STRING 	,dataName='extend'},

		},
		[DataUnpacker.CMD[DataUnpacker.Type.HALL]['RCV'].HALLR_GAME_COUNT 	]		=
		{

			{dataType = DataPacker.STRING 	,dataName='info'},

		},

	}
	
    DataUnpacker.unpackTable[DataUnpacker.Type.WEDDING] = {

    	[DataUnpacker.CMD[DataUnpacker.Type.WEDDING]['RCV'].LOGIN_SUCC] =		
		function(byteArray)
			local ret = {}
			ret.TableType    = byteArray:readByte()
			ret.TableId      = byteArray:readInt()
			local strLen     = byteArray:readShort() 
			ret.TableName    = byteArray:readString(strLen)
			ret.MarriageType = byteArray:readInt()       
			ret.isMerry      = byteArray:readInt() 
			strLen   		 = byteArray:readShort()  
			ret.TableOther	 = byteArray:readString(strLen)
			if ret.TableOther and #ret.TableOther >0 then
				ret.TableOther   = json.decode(ret.TableOther) 
			end
			ret.users = {}
			ret.playerCount  = byteArray:readUByte()
			for i=1,ret.playerCount do
				local tbl = {}
				tbl.uid   = byteArray:readInt()
				tbl.coin  = byteArray:readLong()
				tbl.sex   = byteArray:readByte() 			
				strLen    = byteArray:readShort() 
			    tbl.name  = byteArray:readString(strLen)
			    strLen    = byteArray:readShort() 
                tbl.picUrl = byteArray:readString(strLen)
				tbl.VLevel = byteArray:readUByte() 
				tbl.VType  = byteArray:readUByte() 
				tbl.IsInvited = byteArray:readByte() 
				tbl.IsWedding = byteArray:readByte() 
				table.insert(ret.users,tbl)
			end 
			return ret
		end, 
        [DataUnpacker.CMD[DataUnpacker.Type.WEDDING]['RCV'].HEARTBEAT  ] =	{
          
        },  

        [DataUnpacker.CMD[DataUnpacker.Type.WEDDING]['RCV'].LOGOUT_SUCC  ] =  {
          
        }, 

        [DataUnpacker.CMD[DataUnpacker.Type.WEDDING]['RCV'].LOGIN_CONFLICT] =  {
          
        }, 
        [DataUnpacker.CMD[DataUnpacker.Type.WEDDING]['RCV'].UPDATE_USERINFO] =  {       
				{dataType = DataPacker.INT 	,dataName='PlayerId'},
				{dataType = DataPacker.INT 	,dataName='chip'},
        }, 
        [DataUnpacker.CMD[DataUnpacker.Type.WEDDING]['RCV'].USER_ENTER] =  {
          		{dataType = DataPacker.INT 	,    dataName='uid'},
          		{dataType = DataPacker.LONG ,    dataName='coin'},
          		{dataType = DataPacker.BYTE ,    dataName='sex'},
          		{dataType = DataPacker.STRING,   dataName='name'},
          		{dataType = DataPacker.STRING,   dataName='picUrl'},
          		{dataType = DataPacker.UBYTE,    dataName='VLevel'},
          		{dataType = DataPacker.UBYTE,    dataName='VType'},
          		{dataType = DataPacker.BYTE,     dataName='IsInvited'},
          		{dataType = DataPacker.BYTE,     dataName='IsWedding'},
        }, 
        [DataUnpacker.CMD[DataUnpacker.Type.WEDDING]['RCV'].USER_LEFT] =  {
                {dataType = DataPacker.INT 	,    dataName='uid'},
        },
        [DataUnpacker.CMD[DataUnpacker.Type.WEDDING]['RCV'].CHAT] =  {
                {dataType = DataPacker.INT 	,    dataName='uid'},
                {dataType = DataPacker.STRING,   dataName='str'},
        },
        [DataUnpacker.CMD[DataUnpacker.Type.WEDDING]['RCV'].EMOJI] =  {
                {dataType = DataPacker.INT 	,    dataName='uid'},
                {dataType = DataPacker.SHORT,    dataName='ExpId'},          
        },
        [DataUnpacker.CMD[DataUnpacker.Type.WEDDING]['RCV'].CHATSTRID] =  {
                {dataType = DataPacker.INT 	,    dataName='uid'},
                {dataType = DataPacker.SHORT,    dataName='strId'},          
        },
        [DataUnpacker.CMD[DataUnpacker.Type.WEDDING]['RCV'].SENDGIFT] =  {
                {dataType = DataPacker.INT 	,    dataName='PlayerId'},
                {dataType = DataPacker.INT 	,    dataName='ToPlayerId'},
                {dataType = DataPacker.BYTE,     dataName='giftId'},           
                {dataType = DataPacker.SHORT,    dataName='num'},           
        },
        [DataUnpacker.CMD[DataUnpacker.Type.WEDDING]['RCV'].SENDREDPOCKET] =  {
                {dataType = DataPacker.INT 	,    dataName='PlayerId'},
                {dataType = DataPacker.INT,      dataName='num'},             
        },
        [DataUnpacker.CMD[DataUnpacker.Type.WEDDING]['RCV'].SENDMONEY] =  {
                {dataType = DataPacker.INT,      dataName='PlayerId'},
                {dataType = DataPacker.INT,      dataName='ToPlayerId'},
                {dataType = DataPacker.INT,      dataName='num'},            
        },
        [DataUnpacker.CMD[DataUnpacker.Type.WEDDING]['RCV'].SENDBALLOON] =  {
                {dataType = DataPacker.INT,      dataName='PlayerId'},
        },
        [DataUnpacker.CMD[DataUnpacker.Type.WEDDING]['RCV'].SENDFLOWERS  ] =  {
                {dataType = DataPacker.INT,      dataName='PlayerId'},
        },
        [DataUnpacker.CMD[DataUnpacker.Type.WEDDING]['RCV'].SINVITE_SUCC  ] =  {
                {dataType = DataPacker.INT,      dataName='PlayerId'},
        },
        [DataUnpacker.CMD[DataUnpacker.Type.WEDDING]['RCV'].BE_PROPOSALED  ] =  {
                {dataType = DataPacker.INT,      dataName='PlayerId'},
                {dataType = DataPacker.INT,      dataName='BePlayerId'},        
        },
        [DataUnpacker.CMD[DataUnpacker.Type.WEDDING]['RCV'].BE_PROPOSALED_ACCEPT  ] =  {
                {dataType = DataPacker.INT,      dataName='PlayerId'},
                {dataType = DataPacker.INT,      dataName='BePlayerId'},          
        },
        [DataUnpacker.CMD[DataUnpacker.Type.WEDDING]['RCV'].BE_PROPOSALED_DENY  ] =  {
                {dataType = DataPacker.INT,      dataName='PlayerId'},
                {dataType = DataPacker.INT,      dataName='BePlayerId'},          
        },
        [DataUnpacker.CMD[DataUnpacker.Type.WEDDING]['RCV'].BE_PROPOSALED_FAIL  ] =  {
                {dataType = DataPacker.INT,      dataName='BeMarryId'},
                {dataType = DataPacker.INT,      dataName='ref'}, 
                {dataType = DataPacker.STRING,   dataName='msg'}, 

        },
        [DataUnpacker.CMD[DataUnpacker.Type.WEDDING]['RCV'].KIK_PLAYER  ] =  {
                {dataType = DataPacker.INT,      dataName='PlayerId'},
                {dataType = DataPacker.INT,      dataName='BeKickPlayerId'},              
        },
        [DataUnpacker.CMD[DataUnpacker.Type.WEDDING]['RCV'].ERROR  ] =  {
                {dataType = DataPacker.BYTE,      dataName='actionId'}, 
                {dataType = DataPacker.BYTE,      dataName='failedType'}, 
                {dataType = DataPacker.STRING,    dataName='failedStr'},                                           
        },
        [DataUnpacker.CMD[DataUnpacker.Type.WEDDING]['RCV'].SYS_INFO ] =  {
                {dataType = DataPacker.BYTE,      dataName='tipCode'}, 
                {dataType = DataPacker.STRING,    dataName='tipStr'},            
        },
    }     

    DataUnpacker.unpackTable[DataUnpacker.Type.Texus]    = {
    	[DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].LOGIN_SUCC] =		
		function(byteArray)
			local ret = {}
			ret.SeatId       = byteArray:readByte() 
			ret.TableType    = byteArray:readInt()
			ret.SeatCount    = byteArray:readByte()
			ret.TableId      = byteArray:readInt()
			local strLen     = byteArray:readShort() 
			ret.TableName    = byteArray:readString(strLen)

			ret.BetOnTimeOut = byteArray:readByte()       
			ret.ReadyTimeOut = byteArray:readByte() 
            ret.BaseChip     = byteArray:readLong()
            ret.MinChip      = byteArray:readLong()
            ret.MaxChip      = byteArray:readLong()
            ret.ServiceFee   = byteArray:readLong()
 
			strLen   		 = byteArray:readShort()  
			ret.TableOther	 = byteArray:readString(strLen)
			if ret.TableOther and #ret.TableOther >0 then
				ret.TableOther   = json.decode(ret.TableOther) 
			end
			ret.TableState   = byteArray:readByte()      
			ret.Users = {}
			ret.playerCount  = byteArray:readUByte()
			for i=1,ret.playerCount do
				local tbl = {}
				tbl.Uid   = byteArray:readInt()
				tbl.SeatId  = byteArray:readByte()
				tbl.Chip   = byteArray:readLong() 			
			    tbl.Coin  = byteArray:readLong()
			    tbl.Sex   = byteArray:readByte()

			    strLen    =  byteArray:readShort() 
			    tbl.Name  =  byteArray:readString(strLen)
			    strLen    =  byteArray:readShort() 
                tbl.PicUrl = byteArray:readString(strLen)

				tbl.VLevel = byteArray:readUByte() 
				--tbl.VType  = byteArray:readUByte() 

				tbl.PlayerState = byteArray:readByte() 
				if tbl.PlayerState and tbl.PlayerState~= 0 then 
                   tbl.BetTotal   = byteArray:readLong() 
                   tbl.CardCount  = byteArray:readByte() 
                   tbl.Card  = {} 
                   if tbl.CardCount and tbl.CardCount>=1 then 
	                   for key =1,  tbl.CardCount do 
                           tbl.Card[key] =  byteArray:readUByte() 
	                   end     
	               end    
	               tbl.CardType =  byteArray:readByte() 
			    end 		
				table.insert(ret.Users,tbl)
			end 
			if ret.TableState > 1 and ret.TableState ~= 6  then 
               ret.CurrentDealerSeatId  = byteArray:readByte() 		
               ret.CurrentBet           = byteArray:readLong()
               ret.CurrentBetSeatId     = byteArray:readByte() 
               ret.CurrentStateGoneTime = byteArray:readByte() 
               local pool_num           = byteArray:readByte()  
               ret.Pools                =  {}
               if pool_num and pool_num>= 1 then 
	               for key = 1 ,pool_num do 
	                   local poolId = byteArray:readLong() 
	                   table.insert(ret.Pools,poolId)
	               end 	
               end 

               local common_card = byteArray:readByte() 
               ret.DeskCards   =  {}

               if common_card and common_card>=1 then 
                  for key=1,common_card do 
                  	  local card = byteArray:readUByte()  
                  	  table.insert(ret.DeskCards,card)
                  end  	  
               end 	

		    end 		
			return ret
		end, 

        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].ALL_LOSE  ] =	{
        	{dataType = DataPacker.BYTE ,dataName='actionId'}	,
			{dataType = DataPacker.BYTE ,dataName='failedType'}	,
			{dataType = DataPacker.STRING ,dataName='failedStr'},
			{dataType = DataPacker.BYTE ,dataName='SeatId'}	,

        }, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].LOGOUT_SUCC   ] =	{}, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].LOGIN_CONFLICT  ] =	{}, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].UPDATE_USERINFO  ] =	{
        	{dataType = DataPacker.INT ,dataName='PlayerId'}	,
			{dataType = DataPacker.LONG ,dataName='chip'}		,
			{dataType = DataPacker.LONG,dataName='coin'} 		,
        }, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].HEARTBEAT  ] =	{}, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].USER_ENTER   ] =	{

			{dataType = DataPacker.INT 		,dataName='Uid'}			,
			{dataType = DataPacker.BYTE 	,dataName='Sex'}			,
			{dataType = DataPacker.STRING 	,dataName='Name'} 			,
			{dataType = DataPacker.STRING 	,dataName='PicUrl'} 		,
			{dataType = DataPacker.UBYTE 	,dataName='VLevel'}			,
        }, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].USER_LEFT  ] =	{
            {dataType = DataPacker.INT,dataName = 'Uid'},
        }, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].USER_SIT  ] =	{

			{dataType = DataPacker.INT 		,dataName='Uid'}			,
			{dataType = DataPacker.BYTE 	,dataName='SeatId'}			,
			{dataType = DataPacker.LONG 	,dataName='Chip'}			,
			{dataType = DataPacker.LONG 	,dataName='Coin'}			,
			{dataType = DataPacker.BYTE 	,dataName='Sex'}			,
			{dataType = DataPacker.STRING	,dataName='Name'} 			,
			{dataType = DataPacker.STRING	,dataName='PicUrl'} 			,
			{dataType = DataPacker.UBYTE 	,dataName='VLevel'}			,
			{dataType = DataPacker.BYTE 	,dataName='PlayerState'}			,
        }, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].USER_STAND   ] =	{
            {dataType = DataPacker.BYTE,dataName = 'Uid'},
        }, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].GAME_START   ] =	
	        function(byteArray)
	        	local ret = {}
	        	ret.DealSeatId = byteArray:readByte()
				ret.CurrentSmallBlindsSeatId = byteArray:readByte()
				ret.CurrentBigBlindsSeatId = byteArray:readByte()
				ret.BetSeatId = byteArray:readByte()
				local len = byteArray:readUByte()
				ret.PCard = {}
				for i=1,len do
					ret.PCard[#ret.PCard+1]=byteArray:readUByte()
				end
				ret.CardType=byteArray:readByte()
				 len = byteArray:readUByte()
				ret.SeatID = {}
				for i=1,len do
				    local temp1 = {} 
	                temp1.SeatId = byteArray:readUByte() 
	                local strLen = byteArray:readShort()
	                temp1.Name   = byteArray:readString(strLen) 
	                temp1.Chip   = byteArray:readLong()
	                temp1.Sex    = byteArray:readByte()
	                strLen       = byteArray:readShort()
	                temp1.PicUrl = byteArray:readString(strLen)
	                temp1.VLevel = byteArray:readUByte()
	                temp1.Uid    = byteArray:readInt()
	                ret.SeatID[#ret.SeatID+1]= temp1		
				end
				return ret 
	        end, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].TURN_CARD  ] =	{
        	{dataType = DataPacker.BYTE 	,dataName='PSeatId'}			,
			{dataType = DataPacker.UBYTE 	,dataName='PCard1'}			,
			{dataType = DataPacker.UBYTE 	,dataName='PCard2'}			,
			{dataType = DataPacker.UBYTE 	,dataName='PCard3'}			,
			{dataType = DataPacker.BYTE 	,dataName='CardType'}			,
        }, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].OVER_CARD  ] =	{
        	{dataType = DataPacker.BYTE 	,dataName='PSeatId'}			,
			{dataType = DataPacker.UBYTE 	,dataName='PCard1'}			,
			{dataType = DataPacker.BYTE 	,dataName='CardType'}			,
        }, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].RIVER_CARD   ] =	{
			{dataType = DataPacker.BYTE 	,dataName='PSeatId'}			,
			{dataType = DataPacker.UBYTE 	,dataName='PCard1'}			,
			{dataType = DataPacker.BYTE 	,dataName='CardType'}			,
        }, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].SEE_CARD  ] =	{
        	{dataType = DataPacker.BYTE 	,dataName='SeatId'}			,
			{dataType = DataPacker.BYTE 	,dataName='NextSeatId'}			,
        }, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].FOLLOW_CHIP   ] =	{
        	{dataType = DataPacker.BYTE 	,dataName='SeatId'}			,
			{dataType = DataPacker.LONG 	,dataName='FollowChip'}			,
			{dataType = DataPacker.LONG 	,dataName='IncChip'}			,
			{dataType = DataPacker.BYTE 	,dataName='NextSeatId'}			,
        }, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].ADD_CHIP  ] =	{
			{dataType = DataPacker.BYTE 	,dataName='SeatId'}			,
			{dataType = DataPacker.LONG 	,dataName='AddChip'}			,
			{dataType = DataPacker.LONG 	,dataName='IncChip'}			,
			{dataType = DataPacker.BYTE 	,dataName='NextSeatId'}			,        
        }, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].ABANDON_CARD  ] =	{
			{dataType = DataPacker.BYTE 	,dataName='SeatId'}			,
			{dataType = DataPacker.BYTE 	,dataName='NextSeatId'}			,        
        }, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].ALL_IN  ] =	{
			{dataType = DataPacker.BYTE 	,dataName='SeatId'}			,
			{dataType = DataPacker.LONG 	,dataName='AllinChip'}			,
			{dataType = DataPacker.LONG 	,dataName='IncChip'}			,
			{dataType = DataPacker.BYTE 	,dataName='NextSeatId'}			,        
        }, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].ONE_ROUND_OVER  ] =	
	        function(byteArray) 
	        	local ret = {}
				ret.RoundBetTotal = byteArray:readLong()
				ret.newPoolCount = byteArray:readByte()
				ret.NewChipPoolList = {}
				for i=1,ret.newPoolCount do
					local tbl = {}
					tbl.PoolId = byteArray:readByte()
					tbl.Chip   = byteArray:readLong()
					ret.NewChipPoolList[#ret.NewChipPoolList+1] = tbl
				end
				return ret 
	        end, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].GAME_OVER  ] =	
            function(byteArray)
            	local ret = {}
	            ret.playerCount = byteArray:readByte()
				ret.PlayerInfoList = {}
				for i=1,ret.playerCount do
					local tbl = {}
					tbl.SeatId = byteArray:readByte()
					tbl.WinLossChip = byteArray:readLong()
					tbl.TotalChip = byteArray:readLong()
					tbl.TotalCoin = byteArray:readLong()
					local len = byteArray:readByte()

					tbl.HandCards={}

					for i=1,len do
						tbl.HandCards[#tbl.HandCards+1] = byteArray:readUByte()
					end

					tbl.CardType = byteArray:readByte()
					len = byteArray:readByte()

					print('MaxCards len:'..len)
					tbl.MaxCards={}
					for i=1,len do
						tbl.MaxCards[#tbl.MaxCards+1] = byteArray:readUByte()
					end

					len = byteArray:readByte()
					tbl.WinPoolIds={}
	                tbl.WinPoolChips={}
					for i=1,len do
						tbl.WinPoolIds[#tbl.WinPoolIds+1] = byteArray:readByte()
	                    tbl.WinPoolChips[#tbl.WinPoolChips+1] = byteArray:readLong()
					end
					ret.PlayerInfoList[#ret.PlayerInfoList+1]=tbl
				end
				return ret 
            end, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].CHAT_STR  ] =	{
			{dataType = DataPacker.INT 	,dataName='playerId'}			,
			{dataType = DataPacker.STRING 	,dataName='chatStr'}		,        
        }, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].FACE_ID  ] =	{
        	{dataType = DataPacker.INT 	,dataName='playerId'}			,
			{dataType = DataPacker.SHORT 	,dataName='chatExpId'}			,
        }, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].COMMON_ID  ] =	{
        	{dataType = DataPacker.INT 	,dataName='playerId'}			,
			{dataType = DataPacker.SHORT 	,dataName='chatStrId'}			,
        }, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].SENDGIFT  ] =	{
        	{dataType = DataPacker.INT 	,dataName='playerId'}			,
			{dataType = DataPacker.INT 	,dataName='BePlayerId'}			,
			{dataType = DataPacker.BYTE ,dataName='giftId'}			,
            {dataType = DataPacker.SHORT,dataName='giftNum'}         ,
        }, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].KICK_PEOPLE  ] =	{
        	{dataType = DataPacker.INT 	,dataName='PlayerId'}			,
			{dataType = DataPacker.INT 	,dataName='BeKickPlayerId'}			,
        }, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].SYS_INFOS  ] =	{
        	{dataType = DataPacker.BYTE ,dataName='tipCode'}			,
			{dataType = DataPacker.STRING 	,dataName='tipStr'}			,
        }, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].NET_PRO  ] =	{
            {dataType = DataPacker.BYTE ,dataName='SeatId'}			,
        }, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].ASK_FRIEND  ] =	{
            {dataType = DataPacker.INT 	,dataName='PlayerId'}			,
        }, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].RESQ_FRIEND  ] =	{
        	{dataType = DataPacker.INT 	,dataName='firePlayerId'}			,
			{dataType = DataPacker.INT 	,dataName='agreePlayerId'}			,
			{dataType = DataPacker.BYTE ,dataName='agree'}			,
        }, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].FORCE_STANDUP  ] =	{
            {dataType = DataPacker.STRING 	,dataName='ForceStandStr'}			,
        }, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].SHOW_CARD  ] =	{
        	{dataType = DataPacker.BYTE 	,dataName='SeatId'}			,
			{dataType = DataPacker.UBYTE 	,dataName='Card1'}			,
			{dataType = DataPacker.UBYTE 	,dataName='Card2'}			,
        }, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].GIVE_FEE  ] =	{
            {dataType = DataPacker.BYTE ,dataName='uid'}			,
        }, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].FIRST_BEGIN  ] =	{
            {dataType = DataPacker.BYTE ,dataName='seatId'}            ,
        }, 
        [DataUnpacker.CMD[DataUnpacker.Type.Texus]['RCV'].EXP_ADD  ] =	
            function(byteArray)
            	local ret = {}
	            ret.Popple = byteArray:readByte()
	            ret.info   = {} 
	            for key = 1,ret.Popple do 
	                local temp = {} 
	                temp.seatId = byteArray:readByte()
	                temp.addExp = byteArray:readByte()
	                temp.totalExp = byteArray:readLong()
	                table.insert(ret.info,temp)
	            end    
            	return ret
            end, 
    } 
 
    

DataUnpacker.CMD[DataUnpacker.Type.GAME_Paodekuai] = clone(DataUnpacker.CMD[DataUnpacker.Type.GAME] )
   DataUnpacker.unpackTable[DataUnpacker.Type.GAME_Paodekuai] = clone(DataUnpacker.unpackTable[DataUnpacker.Type.GAME])
    -- DataUnpacker.unpackTable[DataUnpacker.Type.GAME_Paodekuai][DataUnpacker.CMD[DataUnpacker.Type.GAME_Paodekuai]['RCV'].TABLE_LOGIN_SUCESS 		] = 


DataUnpacker.unpackTable[DataUnpacker.Type.GAME_Paodekuai]
[DataUnpacker.CMD[DataUnpacker.Type.GAME_Paodekuai]['RCV'].DEAL_CARDS 				] = 
		function(byteArray)
			local ret = {}
			ret.ingamePlayers = {}
			for i=1,byteArray:readByte() do
				ret.ingamePlayers[i]=byteArray:readByte()
			end 
			ret.len = byteArray:readByte()
			ret.cards = {}
			for i=1,ret.len  do
				table.insert(ret.cards,byteArray:readByte())
			end
			
			ret.first = byteArray:readByte()
			return ret
		end

DataUnpacker.unpackTable[DataUnpacker.Type.GAME_Paodekuai]
[DataUnpacker.CMD[DataUnpacker.Type.GAME_Paodekuai]['RCV'].UPDATE_PLAYER 		] = 
		{ 
			{dataType = DataPacker.BYTE ,dataName='seatID'}, 
			{dataType = DataPacker.LONG ,dataName='coins'},  
		}


DataUnpacker.unpackTable[DataUnpacker.Type.GAME_Paodekuai]
[DataUnpacker.CMD[DataUnpacker.Type.GAME_Paodekuai]['RCV'].MESSAGE_POPUP 		] = 
		{ 
			{dataType = DataPacker.BYTE ,dataName='seatID'}, 
			-- {dataType = DataPacker.ULONG ,dataName='coins'},  
		}


-- DataUnpacker.CMD[DataUnpacker.Type.GAME_Paodekuai]['RCV'].ROUND_OVER 

DataUnpacker.unpackTable[DataUnpacker.Type.GAME_Paodekuai]
[DataUnpacker.CMD[DataUnpacker.Type.GAME_Paodekuai]['RCV'].ROUND_OVER 				] = 
		 
		function(byteArray)
			local ret = {}
			ret.doubleAmount = byteArray:readShort()
			ret.playerCount = byteArray:readByte()
			ret.results = {}
			for i=1,ret.playerCount do
				local r = {}
				r.seatID = byteArray:readByte()
				r.totalCoins = byteArray:readLong()
				r.currenWinAmount = byteArray:readLong()
				r.cardLen = byteArray:readByte()
				r.cards = {}
				for i=1,r.cardLen  do
					table.insert(r.cards,byteArray:readByte())
				end 
				table.insert(ret.results,r)

				r.isSpring =  byteArray:readByte()
			end
			-- ret.isSpring =  byteArray:readByte()
			-- ret.Extra = byteArray:readString(byteArray:readShort())
			-- if ret.Extra and ret.Extra ~= "" then 
			-- 	ret.Extra = json.decode(ret.Extra)
			-- end
			return ret
		end

DataUnpacker.unpackTable[DataUnpacker.Type.GAME_Paodekuai]
[DataUnpacker.CMD[DataUnpacker.Type.GAME_Paodekuai]['RCV'].SERVER_FAIL] = 
		{ 
			{dataType = DataPacker.BYTE ,dataName='actionId'},
			{dataType = DataPacker.BYTE ,dataName='failedType'}, 
			{dataType = DataPacker.STRING ,dataName='failedStr'}, 
			{dataType = DataPacker.BYTE ,dataName='siteid'},    
		}

 
DataUnpacker.unpackTable[DataUnpacker.Type.GAME_Paodekuai]
[DataUnpacker.CMD[DataUnpacker.Type.GAME_Paodekuai]['RCV'].PLAYER_CONNECTED 		] = 
		{ 
			{dataType = DataPacker.BYTE ,dataName='seatID'}, 
			{dataType = DataPacker.INT ,dataName='UID'}, 
			{dataType = DataPacker.STRING ,dataName='nickName'}, 
			-- {dataType = DataPacker.BYTE ,dataName='role'}, 
			{dataType = DataPacker.LONG ,dataName='coins'}, 
			{dataType = DataPacker.BYTE ,dataName='sex'}, 
			{dataType = DataPacker.BYTE ,dataName='vipLevel'}, 
			{dataType = DataPacker.BYTE ,dataName='vipType'}, 
			{dataType = DataPacker.BYTE ,dataName='status'}, 
			{dataType = DataPacker.STRING ,dataName='iconUrl'}, 
			{dataType = DataPacker.BYTE ,dataName='cardLen'}, 
			{dataType = DataPacker.STRING ,dataName='ext'}, 
		}

   DataUnpacker.unpackTable[DataUnpacker.Type.GAME_Paodekuai][DataUnpacker.CMD[DataUnpacker.Type.GAME_Paodekuai]['RCV'].TABLE_LOGIN_SUCESS 		] = 
		function(dp)
			local room = {}
			room.roomType = dp:readInt();
			room.roomId = dp:readInt();
			room.bpour = dp:readInt();
			room.waitTimeOut = dp:readByte();
			room.outTimeOut = dp:readByte();
			room.lordSeatID = dp:readByte(); 
			room.selfSeat = dp:readByte();
			room.roomState = dp:readByte();
			room.userNum = dp:readByte();
			room.userData = {}
			for i=1,room.userNum do
				local ret = {} 
				ret.seatID = dp:readByte()
				ret.UID    = dp:readInt() 
				local strLen = dp:readShort() 
				ret.nickName = dp:readString(strLen)
				-- ret.role  = dp:readByte() 
				ret.coins = dp:readLong() 
				ret.sex   = dp:readByte()
				ret.vipLevel = dp:readByte()
				ret.vipType  = dp:readByte()
				ret.status = dp:readByte()
				strLen     = dp:readShort() 
				ret.iconUrl = dp:readString(strLen)
				ret.cardLen = dp:readByte()
				strLen = dp:readShort() 
				ret.ext= dp:readString(strLen)
				table.insert(room.userData ,ret)
			end
			dump(room,'当前的room信息')
			if  room.roomState == 2 then
				room.autoPlayStatus = dp:readByte()
				room.doubleAmount = dp:readShort() 
				-- room.lordCardCount = dp:readByte()
				-- room.lordCards = {}
				-- for i=1,room.lordCardCount do
				-- 	table.insert(room.lordCards,dp:readByte())
				-- end
				room.currentSeat =  dp:readByte()
				room.userCardCount = dp:readByte()
				room.userCards = {}
				for i=1,room.userCardCount do
					table.insert(room.userCards,dp:readByte())
				end
				room.lastPlayerSeatID = dp:readByte()
				room.lastPlayerCardType = dp:readByte()
				room.lastPlayerCardCount = dp:readByte()
				room.lastPlayerCards = {}
				for i=1,room.lastPlayerCardCount do
					table.insert(room.lastPlayerCards,dp:readByte())
				end 
			end
			strLen =dp:readShort() 
			room.roomExtend = json.decode(dp:readString(strLen))
			return room
		end
end

function DataUnpacker:unpackByCMD()

	local retForTrue = {}

	for i,v in ipairs(self.bufferList) do
	
		local ret = {}
	 
	    printf("START UNPACKING  cmd:0x%02X ",v.header.CMD) 
		local parameterTable = DataUnpacker.unpackTable[self.Type][v.header.CMD] 
	    -- printf("USING %s for unpacking.",type(parameterTable))   
	    if parameterTable then 
	    	if type(parameterTable) == 'function' then
	    		-- dump(v.decryptedByteArray,'这里出错了啊')
				ret = parameterTable(v.decryptedByteArray)
	    	else 
	        	for kk,vv in pairs(parameterTable) do
	        	    print('reading '..vv.dataType)
	        	    if vv.dataType == 'String' then
	        	        local strLen = v.decryptedByteArray:readShort()
	        	        ret[vv.dataName] = v.decryptedByteArray:readString(strLen)
	        	    else
	        	        ret[vv.dataName] = v.decryptedByteArray['read'..vv.dataType](v.decryptedByteArray)
	        	    end
	        	end
	        end
	    else 
	    	printf("UNPACKING  cmd:0x%02X FAILED! parameterTable is null.(does this CMD even exist?)",v.header.CMD) 
	        return  
	    end 
	
		printf("DONE UNPACKING  cmd:0x%02X ",v.header.CMD)
		table.insert(retForTrue,ret)
	
	
		ret.CMD = v.header.CMD
		ret[' HEXCMD '] = string.format("0x%02X",v.header.CMD) 
	end
	-- dump(retForTrue,"retForTrue")
	return retForTrue

end




function DataUnpacker:ctor(buffer,_type)
	self:initUnpackTable()
	self.Type = _type or DataUnpacker.Type.GAME

	self.byteArray = ByteArray.new(ByteArray.ENDIAN_BIG)
	self.byteArray:writeString(buffer)
	self.byteArray:setPos(1)

	local header = {}
	header.Len = self.byteArray:readShort()
	header.AppID = self.byteArray:readByte()
	header.CMD = self.byteArray:readByte()
	header.ProtocolVer = self.byteArray:readByte()
	header.CheckCode = self.byteArray:readByte()
	-- dump(header,"header")
	local pack = self.byteArray:readBuf(header.Len - DataPacker.HEADER_SIZE )
	-- print('pack:'..#pack)
	local checkCode , decryptedBuffer = BufferEncrypt.CrevasseBuffer(pack, 1 ,#pack, header.CheckCode, BufferEncrypt.recvMap)

	local splitedBuffer = ByteArray.new(ByteArray.ENDIAN_BIG)
	splitedBuffer:writeBuf(decryptedBuffer)
	splitedBuffer:setPos(1)
 -- printf("Encrypted Buffer LUA(SERVER LEN:%s,RCVD LEN:%d):%s",header.Len,self.byteArray:getLen(),self.byteArray:toString())

    --printf("Splitted Encrypted Buffer LUA(LEN:%s):%s",#pack,splitedBuffer:toString())
	self.bufferList = {}
	table.insert(self.bufferList,{header = header,decryptedByteArray=splitedBuffer})
	-- dump(self.bufferList,"self.bufferList")
	while (self.byteArray:getPos() < self.byteArray:getLen()) do
		--print('self.byteArray:getPos():'..self.byteArray:getPos()..",self.byteArray:getLen():"..self.byteArray:getLen())
		local header = {}
		header.Len = self.byteArray:readShort()
		header.AppID = self.byteArray:readByte()
		header.CMD = self.byteArray:readByte() 
		header.ProtocolVer = self.byteArray:readByte()
		header.CheckCode = self.byteArray:readByte()
		-- dump(header,"header inside loop")
		local pack = self.byteArray:readBuf(header.Len - DataPacker.HEADER_SIZE )
		-- print('pack:'..#pack)
		local checkCode , decryptedBuffer = BufferEncrypt.CrevasseBuffer(pack, 1 ,#pack, header.CheckCode, BufferEncrypt.recvMap)

		local splitedBuffer = ByteArray.new(ByteArray.ENDIAN_BIG)
		splitedBuffer:writeBuf(decryptedBuffer)
		splitedBuffer:setPos(1)
    	-- printf("Encrypted Buffer LUA(SERVER LEN:%s,RCVD LEN:%d):%s",header.Len,self.byteArray:getLen(),self.byteArray:toString())

    	-- printf("Splitted Encrypted Buffer LUA(LEN:%s):%s",#pack,splitedBuffer:toString())
		table.insert(self.bufferList,{header = header,decryptedByteArray=splitedBuffer})
	end
	-- dump(self.bufferList,"self.bufferList")
	-- while
	-- self.unpackedTable = {}
	-- self.byteArray:writeString(buffer)
	-- self.encryptedBuffer = buffer


	--dump(self.unpackedTable,"BUFFER HEAD")
	-- self.checkCode , self.decryptedBuffer = BufferEncrypt.CrevasseBuffer(buffer,  DataPacker.HEADER_SIZE + 1,  self.unpackedTable[1] , self.unpackedTable[5], BufferEncrypt.recvMap)

	--byte byte short string

	-- self.decryptedByteArray = ByteArray.new(ByteArray.ENDIAN_BIG)
	-- self.decryptedByteArray:writeString(self.decryptedBuffer)
	-- self.decryptedByteArray:setPos(DataPacker.HEADER_SIZE + 1)
	-- local CMD = self.unpackedTable[3]
	-- printf("CMD:0x%02X",CMD)
	-- self:unpackByCMD(CMD)

end

return DataUnpacker
