--
-- Author: Wayne Dimart (wjweini@gmail.com)
-- Date: 2015-10-28 10:49:02
--
 local socket = require("socket") 
local SOCKET_TICK_TIME = 0.1 			-- check socket data interval
local SOCKET_RECONNECT_TIME = 5			-- socket reconnect try interval
local SOCKET_CONNECT_FAIL_TIMEOUT = 3	-- socket failure timeout

local ByteArray = require('app.network.ByteArray')
local STATUS_CLOSED = "closed"
local STATUS_NOT_CONNECTED = "Socket is not connected"
local STATUS_ALREADY_CONNECTED = "already connected"
local STATUS_ALREADY_IN_PROGRESS = "Operation already in progress"
local STATUS_TIMEOUT = "timeout"

local scheduler = require("app.models.QScheduler")
-- local Event = require('cocos.framework.components.event').extend(self)
local socket = require "socket"

local SocketTCP = class("SocketTCP")

SocketTCP.EVENT_DATA = "SOCKET_TCP_DATA"
SocketTCP.EVENT_CLOSE = "SOCKET_TCP_CLOSE"
SocketTCP.EVENT_CLOSED = "SOCKET_TCP_CLOSED"
SocketTCP.EVENT_CONNECTED = "SOCKET_TCP_CONNECTED"
SocketTCP.EVENT_CONNECT_FAILURE = "SOCKET_TCP_CONNECT_FAILURE"
SocketTCP.EVENT_CONNECT_FAILURE_NO_DATA_RCVD = "SOCKET_TCP_CONNECT_FAILURE_NO_DATA_RCVD"
SocketTCP.EVENT_DATA_QUEUE = "SOCKET_TCP_DATA_QUEUE"

SocketTCP._VERSION = socket._VERSION
SocketTCP._DEBUG = socket._DEBUG

function SocketTCP.getTime()
	return socket.gettime()
end

function SocketTCP:ctor(__host, __port, __retryConnectWhenFailure,nodataTimeout) 
	-- self.eventDispatcher = cc.Event.new(self)
	 require('cocos.framework.components.EventProtocol').extend(self)
    self.host = __host
    self.port = __port
    self.noDataReceivedTimeout = nodataTimeout
	self.tickScheduler = nil			-- timer for data
	self.reconnectScheduler = nil		-- timer for reconnect
	self.connectTimeTickScheduler = nil	-- timer for connect timeout
	self.name = 'SocketTCP'
	self.tcp = nil
	self.isRetryConnect = __retryConnectWhenFailure
	self.isConnected = false
end 

function SocketTCP:setName( __name )
	self.name = __name
	return self
end

function SocketTCP:setTickTime(__time)
	SOCKET_TICK_TIME = __time
	return self
end

function SocketTCP:setReconnTime(__time)
	SOCKET_RECONNECT_TIME = __time
	return self
end

function SocketTCP:setConnFailTime(__time)
	SOCKET_CONNECT_FAIL_TIMEOUT = __time
	return self
end

function SocketTCP:getTcp(host)
	local isipv6_only = false
	local addrinfo, err = socket.dns.getaddrinfo(host);
	for i,v in ipairs(addrinfo) do
		if v.family == "inet6" then
			isipv6_only = true;
			break
		end
	end
	-- dump(socket.dns.getaddrinfo(host))
	print("isipv6_only", isipv6_only)
	if isipv6_only then
		return socket.tcp6()
	else
		return socket.tcp()
	end
end

function SocketTCP:connect(__host, __port, __retryConnectWhenFailure)
	if __host then self.host = __host end
	if __port then self.port = __port end
	if __retryConnectWhenFailure ~= nil then self.isRetryConnect = __retryConnectWhenFailure end
	assert(self.host or self.port, "Host and port are necessary!")
	----echoInfo("%s.connect(%s, %d)", self.name, self.host, self.port)
	-- self.tcp = socket.tcp()
	self.tcp = SocketTCP:getTcp(self.host)
	
	self.tcp:settimeout(0)
	self.tcp:setoption('keepalive',true) 
	self.tcp:setoption('reuseaddr',true) 
	self.tcp:setoption ("linger", {on = false, timeout = 0})
	self.tcp:setoption('tcp-nodelay',true)  

	local function __checkConnect()
		local __succ = self:_connect() 
		if __succ then
			self:_onConnected()
		end
		return __succ
	end

	
		-- check whether connection is success
		-- the connection is failure if socket isn't connected after SOCKET_CONNECT_FAIL_TIMEOUT seconds
		local __connectTimeTick = function ()
			-- printf("%s.connectTimeTick", self.name)
			if self.isConnected then return end
			self.waitConnect = self.waitConnect or 0
			self.waitConnect = self.waitConnect + SOCKET_TICK_TIME
			if self.waitConnect >= SOCKET_CONNECT_FAIL_TIMEOUT then
				self.waitConnect = nil

    			--printf("PRE SHUTTING DOWN self.connectTimeTickScheduler :%s",self.connectTimeTickScheduler )
				self:close()
				self:_connectFailure()
			end
			__checkConnect()
		end
		
	if not __checkConnect() then 
    	if self.connectTimeTickScheduler == nil then
			self.connectTimeTickScheduler = scheduler.scheduleGlobal(__connectTimeTick, SOCKET_TICK_TIME)
		end
	end
end

function SocketTCP:send(__data)
	assert(self.isConnected, self.name .. " is not connected.")
 --    local ba = ByteArray.new(ByteArray.ENDIAN_BIG)
 --    ba:writeBuf(__data)
    --print('SENDING DATA:'..ba:toString())
    --local dataFinal = clone(__data) 
	local r1,r2,r3 = self.tcp:send(__data)
	printf('SOCKET (%s) send result: %s,%s,%s',self.name,r1,r2,r3)
    --printf("SocketTCP::SocketTCP:>>>[[[send]]]<<< self＝%s,r1=%s,r2=%s,r3=%s len__data=%d",tostring(self),tostring(r1),tostring(r2), tostring(r3), string.len(__data))
end
 

function SocketTCP:close( ... )
	----echoInfo("%s.close", self.name)
    --printf("SocketTCP::%s:close self＝%s ",self.name,tostring(self) )
    local r1,r2,r3 = self.tcp:close();
    --echoInfo("::SocketTCP:close self＝%s,r1=%s,r2=%s,r3=%s ",tostring(self),tostring(r1),tostring(r2), tostring(r3))

    --printf("SHUTTING DOWN self.connectTimeTickScheduler :%s",self.connectTimeTickScheduler )
	if self.connectTimeTickScheduler then 
		scheduler.unscheduleGlobal(self.connectTimeTickScheduler) 
		self.connectTimeTickScheduler = nil
	end

    --printf("SHUT DOWN self.connectTimeTickScheduler :%s",self.connectTimeTickScheduler )

	if self.tickScheduler then 
		scheduler.unscheduleGlobal(self.tickScheduler) 
		self.tickScheduler = nil
	end
	--if self.connectTimeTickScheduler then scheduler.unscheduleGlobal(self.connectTimeTickScheduler) end
	self:dispatchEvent({name=SocketTCP.EVENT_CLOSE})
end

-- disconnect on user's own initiative.
function SocketTCP:disconnect()
    local r1,r2,r3 = self:_disconnect()
	self.isRetryConnect = false -- initiative to disconnect, no reconnect.
    --echoInfo("::SocketTCP:disconnect self＝%s,r1=%s,r2=%s,r3=%s ",tostring(self),tostring(r1),tostring(r2), tostring(r3))
end

--------------------
-- private
--------------------

--- When connect a connected socket server, it will return "already connected"
-- @see: http://lua-users.org/lists/lua-l/2009-10/msg00584.html
function SocketTCP:_connect()
	local __succ, __status = self.tcp:connect(self.host, self.port) 
	 --print(self.name,"SocketTCP._connect:", __succ, __status)
	return __succ == 1 or __status == STATUS_ALREADY_CONNECTED
end

function SocketTCP:_disconnect()
	self.isConnected = false
	self.tcp:shutdown()
	self:dispatchEvent({name=SocketTCP.EVENT_CLOSED})
end

function SocketTCP:_onDisconnect()
	--printf("%s._onDisConnect", self.name);
	self.isConnected = false
	self:dispatchEvent({name=SocketTCP.EVENT_CLOSED})
	self:_reconnect();
end

function SocketTCP:resetNoDataTimeout()
	if self.nodataRcvdScheduler then
		scheduler.unscheduleGlobal(self.nodataRcvdScheduler) 
		self.nodataRcvdScheduler = nil
	end
	self.nodataRcvdScheduler = scheduler.performWithDelayGlobal(function() 
		if self.nodataRcvdScheduler then
			scheduler.unscheduleGlobal(self.nodataRcvdScheduler) 
			self.nodataRcvdScheduler = nil
		end
		self:dispatchEvent({name=SocketTCP.EVENT_CONNECT_FAILURE_NO_DATA_RCVD})
	end, self.noDataReceivedTimeout )
	
	-- body
end

function SocketTCP:_recvCheckConnect(status)
	if status == STATUS_CLOSED or status == STATUS_NOT_CONNECTED then
    	self:close()
    	if self.isConnected then
    		self:_onDisconnect()
    	else
    		self:_connectFailure()
    	end
	end
end

function SocketTCP:validMsg(body, partial)
	--返回是否是有效消息结构
	if (body and string.len(body)==0) or
		(partial and string.len(partial)==0) then
		return nil
	else

		if not body or not partial then
			return body or partial
		elseif body and partial then
			return body .. partial
		end
	end
end

function SocketTCP:recvMsg()
	--1、fisrt read message length
	local __body, __status, __partial = self.tcp:receive(2)
	self:_recvCheckConnect(__status)

	local header = self:validMsg(__body, __partial)
	if not header then return end
	assert(#header == 2, 'SocketTCP recvMsg header length not 2!')

	local recved, total = 0
	total = string.byte(header, 1) * 256 + string.byte(header, 2)
	if total <= 0 then return end

	recved = 2
	--2、loop receive last message body
	self.msg = header
	while (recved < total) do

		local lastRecv = total - recved
		local __body, __status, __partial = self.tcp:receive(lastRecv)
		self:_recvCheckConnect(__status)

		local body = self:validMsg(__body, __partial)
		if not body then break end

		recved = recved + #body
		self.msg = self.msg .. body
	end

	self:dispatchEvent({name=SocketTCP.EVENT_DATA, data=self.msg})
	self.msg = ""
end

-- connecte success, cancel the connection timerout timer
function SocketTCP:_onConnected()
	--printf("%s._onConnectd", self.name)
	self.isConnected = true
	self:dispatchEvent({name=SocketTCP.EVENT_CONNECTED})
	if self.connectTimeTickScheduler then 
		scheduler.unscheduleGlobal(self.connectTimeTickScheduler)
		self.connectTimeTickScheduler = nil

	end

	local __tick = function()
		self:recvMsg()
	end

	-- start to read TCP data
	self.tickScheduler = scheduler.scheduleGlobal(__tick, SOCKET_TICK_TIME)
	-- self.tickScheduler =  cc.Director:getInstance():getScheduler():scheduleScriptFunc(__tick, SOCKET_TICK_TIME, false)
end

function SocketTCP:_connectFailure(status)
	--printf("%s._connectFailure", self.name);
	self:dispatchEvent({name=SocketTCP.EVENT_CONNECT_FAILURE}) 
	if self.isRetryConnect ~= true then return end
	self:_reconnect();
end

-- if connection is initiative, do not reconnect
function SocketTCP:_reconnect(__immediately) 
	--printf(" %s:_reconnect:=>>>%s._reconnect", self.name,self.name)
	if __immediately then self:connect() return end
	if self.reconnectScheduler then 
		scheduler.unscheduleGlobal(self.reconnectScheduler) 
		self.reconnectScheduler = nil
	end

	local __doReConnect = function ()
		self:connect()
	end
	self.reconnectScheduler = scheduler.performWithDelayGlobal(__doReConnect, SOCKET_RECONNECT_TIME)
end

return SocketTCP