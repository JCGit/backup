
local SDKHandler = class('SDKHandler')
SDKHandler.Type = {
  FACEBOOK = 'FACEBOOK',
  ALIPAY = 'ALIPAY',
  YIBAO = 'YIBAO',
  WEIXIN = 'WEIXIN',
  SHARE_WEIXIN ='SHARE_WEIXIN',
  BAIDU ='BAIDU'
}

--printWarning
SDKHandler.sdkPool = {}
--SDKHandler.SDKSetup(SDKHandler.Type.ALIPAY )
function SDKHandler:ctor(_SDKType,poolName) 
  --  printError('_SDKType')
    self.SDKType = _SDKType
    self.poolName = poolName
  if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) and LuaTools.CheckJavaMethod("SDKSetup") then
     local args = { _SDKType,poolName }
     local sigs = "(Ljava/lang/String;Ljava/lang/String;)V"
     local luaj = require "cocos.cocos2d.luaj"
     local className = "org/cocos2dx/lua/AppActivity"
     return  luaj.callStaticMethod(className,"SDKSetup",args,sigs) 
  end

end

function SDKHandler.getInstance(_SDKType,poolName)
    -- body
    if SDKHandler.sdkPool[poolName] then
        return SDKHandler.sdkPool[poolName] 
    else 
        SDKHandler.sdkPool[poolName] = SDKHandler.new(_SDKType,poolName) 
        return SDKHandler.sdkPool[poolName]
    end
end

--[=[
SDKHandler.SDKLogin({
            onSueccCallback = function() print('onSueccCallback') end,
            onCancelCallback = function() print('onCancelCallback') end,
            onErrorCallback = function() print('onErrorCallback') end, 
            })
]=]
function SDKHandler:SDKLogin(callbackTable)

  if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) and LuaTools.CheckJavaMethod("SDKLogin") then
     local args = { callbackTable.onSueccCallback, callbackTable.onCancelCallback, callbackTable.onErrorCallback,self.poolName}
     local sigs = "(IIILjava/lang/String;)V"
     local luaj = require "cocos.cocos2d.luaj"
     local className = "org/cocos2dx/lua/AppActivity"
     return luaj.callStaticMethod(className,"SDKLogin",args,sigs) 
  end
end

function SDKHandler.SDKDoAds()
    if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) and LuaTools.CheckJavaMethod("SDKDoAds") then
        local sigs = "(IIILjava/lang/String;Ljava/lang/String;)V"
        local luaj = require "cocos.cocos2d.luaj"
        local className = "org/cocos2dx/lua/AppActivity"
        luaj.callStaticMethod(className,"SDKDoAds") 
    end
end

--[=[ 
        SDKHandler.SDKPay({
            onSueccCallback = function() print('onSueccCallback') end,
            onPendingCallback = function() print('onPendingCallback') end,
            onErrorCallback = function() print('onErrorCallback') end, 
            },
            {
            subject = "subject",
            body = "subject",
            price  = "0.01"
            })

]=] 
function SDKHandler:SDKPay(callbackTable,args)
    -- 
            -- G_BASEAPP:removeView("UIWaiting", 65535)
       local scheduler = require("app.models.QScheduler")
       local delayTime = 0.5
       local callbackTableWrapper = 
       {
        onSueccCallback = function(arg) 
            scheduler.performWithDelayGlobal(function()
                if G_BASEAPP:getView('UIWaiting') then
                    G_BASEAPP:removeView("UIWaiting", 65535); 
                end
                callbackTable.onSueccCallback(arg) 
             end, delayTime)
        end,
        onPendingCallback = function(arg) 
            scheduler.performWithDelayGlobal(function()
                if G_BASEAPP:getView('UIWaiting') then
                    G_BASEAPP:removeView("UIWaiting", 65535); 
                end
                callbackTable.onPendingCallback(arg) 
             end, delayTime)
        end,
        onErrorCallback = function(arg) 
            scheduler.performWithDelayGlobal(function()
                if G_BASEAPP:getView('UIWaiting') then
                    G_BASEAPP:removeView("UIWaiting", 65535); 
                end 
                callbackTable.onErrorCallback(arg) 
             end, delayTime)
        end,
        -- onPendingCallback = function(args) G_BASEAPP:removeView("UIWaiting", 65535); callbackTable.onPendingCallback(args) end,
        -- onErrorCallback = function(args) G_BASEAPP:removeView("UIWaiting", 65535); callbackTable.onErrorCallback(args) end,
       }
    if SDKHandler['SDKPay_'..self.SDKType] then
        SDKHandler['SDKPay_'..self.SDKType](self,callbackTableWrapper,args)
    else
        printf("SDKPay_%s is not implemented",self.SDKType)
    end
end

function SDKHandler:execSDKPay(callbackTable,args)
    if G_BASEAPP:getView('UIWaiting') then
        G_BASEAPP:removeView("UIWaiting", 65535); 
    end

  if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) and LuaTools.CheckJavaMethod("SDKPay") then
     local args = { 
     callbackTable.onSueccCallback, 
     callbackTable.onPendingCallback, 
     callbackTable.onErrorCallback, 
     args,
     self.poolName}
     local sigs = "(IIILjava/lang/String;Ljava/lang/String;)V"
     local luaj = require "cocos.cocos2d.luaj"
     local className = "org/cocos2dx/lua/AppActivity"
     return luaj.callStaticMethod(className,"SDKPay",args,sigs) 
  end
end

function SDKHandler:execSDKExitGame()
    if G_BASEAPP:getView('UIWaiting') then
        G_BASEAPP:removeView("UIWaiting", 65535); 
    end

    if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) and LuaTools.CheckJavaMethod("SDKExitGame") then
        local sigs = "(IIILjava/lang/String;Ljava/lang/String;)V"
        local luaj = require "cocos.cocos2d.luaj"
        local className = "org/cocos2dx/lua/AppActivity"
        luaj.callStaticMethod(className,"SDKExitGame") 
    end
end



function SDKHandler:SDKPay_ALIPAY(callbackTable,args)

  local HttpHandler = require("app.network.HttpHandler")
    local tbl = 
    {
        ['uid'] = G_UID,
        ['token'] = G_TOKEN,
        ['fast'] = args.isFast,
        ['pid'] = args.productID,
        ['realAmount'] =args.realAmount*100, 
   --     ['realAmount'] =args.realAmount,              --test
        ['unionid'] = args.unionid,
        ['cmd'] = HttpHandler.CMDTABLE.PAY_ALIPAY
    }
    local function succ(args)
         local payTbl = {
            orderId      =args.orderId,
            orderInfo      =args.orderInfo,
            sign         = args.sign,
            }
        self:execSDKPay(callbackTable,json.encode(payTbl))
    end 

    local function fail(args) 
        
    end

    LuaTools.fastRequest(tbl,succ,fail,{ 
        disableAlert =true
        })
end



function SDKHandler:SDKPay_YIBAO(callbackTable,args)

  local HttpHandler = require("app.network.HttpHandler")
    local tbl2 = 
    {
        ['uid'] = G_UID,
        ['fast'] = args.isFast,
        ['imei'] = LuaTools.getAllInfomationYouNeeded().imei,
        ['unionid'] = args.unionid,
        ['pid'] = args.productID,
    }
    local tbl = 
    {
        ['buyer'] = G_UID,
        ['pid'] = args.productID,
        ['gameid'] = 'wp',
        ['goods'] = args.productName,
        ['money'] = args.realAmount*100,
    --    ['money'] = args.realAmount,              --test
        ['param'] = LuaTools.StringToBase64(json.encode(tbl2)),
        ['cmd']   = HttpHandler.CMDTABLE.PAY_YIBAO
    }
    local function process(args) 
       local dst = LuaTools.writeFileToCache(args,'yibaopay.html')
       print(args)
       if dst ~= false then
            self:execSDKPay(callbackTable,dst)
        end

    end 
 
    LuaTools.fastRequest(tbl,process,process,
        {
        baseUrl = G_SELECTED_SERVER_CONFIG.paySeverAddr,
        dontdecode   = true,
        dontencode   = true,
        dontdejson   = true,
        dontenjson   = true,
        disableAlert = true
        })
end

function SDKHandler:SDKPay_WEIXIN(callbackTable,args)
  local HttpHandler = require("app.network.HttpHandler")
  
  local pData = G_BASEAPP:getData('PlayerData')
  local tempADD = pData.defaultWeixinAddress == 0  and HttpHandler.CMDTABLE.PAY_WEIXIN_ORDER or HttpHandler.CMDTABLE.PAY_WEIXIN_ORDER1
  
  print('sssssssssss5555555555555='..pData.defaultWeixinAddress)
    local tbl = 
    { 
        ['uid'] = G_UID,
        ['token'] = G_TOKEN,
        ['fast'] = args.isFast,
        ['pid'] = args.productID,
        ['realAmount'] = args.realAmount*100,
       -- ['realAmount'] = args.realAmount,               -- test
        ['unionid'] = args.unionid,
        ['did'] = args.did,
        ['productName'] = args.productName,
        ['productDesc'] = args.productDesc,
        ['cmd']   = tempADD
    }

    local function succ(args)
        print("SDKPay_WEIXIN_succ")
        self:execSDKPay(callbackTable,json.encode(args))
    end 

    local function fail(args) 
         print("SDKPay_WEIXIN_fail")
        dump(args,"SDKPay_WEIXIN_fail")
    end

    LuaTools.fastRequest(tbl,succ,fail,
        {
           disableAlert =true
        })
end

function SDKHandler:SDKShare(callbackTable,args)
    -- 
            -- G_BASEAPP:removeView("UIWaiting", 65535)
       local scheduler = require("app.models.QScheduler")
       local delayTime = 0.5
       local callbackTableWrapper = 
       {
        onShareSueccCallback = function(arg) 
            scheduler.performWithDelayGlobal(function()
                if G_BASEAPP:getView('UIWaiting') then
                    G_BASEAPP:removeView("UIWaiting", 65535); 
                end
                callbackTable.onSueccCallback(arg) 
             end, delayTime)
        end,
        onSharePendingCallback = function(arg) 
            scheduler.performWithDelayGlobal(function()
                if G_BASEAPP:getView('UIWaiting') then
                    G_BASEAPP:removeView("UIWaiting", 65535); 
                end
                callbackTable.onPendingCallback(arg) 
             end, delayTime)
        end,
        onShareErrorCallback = function(arg) 
            scheduler.performWithDelayGlobal(function()
                if G_BASEAPP:getView('UIWaiting') then
                    G_BASEAPP:removeView("UIWaiting", 65535); 
                end 
                callbackTable.onErrorCallback(arg) 
             end, delayTime)
        end,
        -- onPendingCallback = function(args) G_BASEAPP:removeView("UIWaiting", 65535); callbackTable.onPendingCallback(args) end,
        -- onErrorCallback = function(args) G_BASEAPP:removeView("UIWaiting", 65535); callbackTable.onErrorCallback(args) end,
       }

      -- dump(self.SDKType,"WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW")
    if SDKHandler['SDKShare_'..self.SDKType] then
        SDKHandler['SDKShare_'..self.SDKType](self,callbackTableWrapper,args)
    else
        printf("SDKShare_%s is not implemented",self.SDKType)
    end
end

function SDKHandler:execSDKShare(callbackTable,args)
    if G_BASEAPP:getView('UIWaiting') then
        G_BASEAPP:removeView("UIWaiting", 65535); 
    end

  if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) and LuaTools.CheckJavaMethod("SDKShare") then
     local args = { 
     callbackTable.onShareSueccCallback, 
     callbackTable.onSharePendingCallback, 
     callbackTable.onShareErrorCallback, 
     args,
     self.poolName}
     local sigs = "(IIILjava/lang/String;Ljava/lang/String;)V"
     local luaj = require "cocos.cocos2d.luaj"
     local className = "org/cocos2dx/lua/AppActivity"
     return luaj.callStaticMethod(className,"SDKShare",args,sigs) 
  end
end


function SDKHandler:SDKShare_SHARE_WEIXIN(callbackTable,args)
        self:execSDKShare(callbackTable,args)
end
return SDKHandler