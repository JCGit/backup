TCPManager = class('TCPManager')
TCPManager.tcpPool = {}
local scheduler = require("app.models.QScheduler") 
local SocketTCP = require("app.network.SocketTCP")  
function TCPManager:ctor( paramTable )  
	self.name = paramTable.name or tostring(self)
	local name = string.format("TCPManager.tcpPool.receivedDataPool@%s",self.name)
	self.receivedDataPool = DataStructures.Stacqueue.new(name)
	self.receivedDataPool.supportDuplicatedElement=true

	name = string.format("TCPManager.tcpPool.sendDataPool@%s",self.name)
	self.sendDataPool = DataStructures.Stacqueue.new(name)
	self.sendDataPool.supportDuplicatedElement=true

	self.eventListenerTable = {}

	self.RcvdInt = 0.1
	self.SendInt = 0.1

	self.ip 					= 	paramTable.ip
	self.port 					= 	paramTable.port
	self.retryIfFailure 		= 	paramTable.retryConnectWhenFailure	
	self.failureRetryTime 		= 	paramTable.failureRetryTime	or 3
	self.failureRetryTimeout 	= 	paramTable.failureRetryTimeout	or 3
	self.failureRetryTimeTried 	= 	1
	self.noDataReceivedTimeout 	= 	30
	self.socket = SocketTCP.new(self.ip,self.port,nil,self.noDataReceivedTimeout)  
	self.socket:setName(self.name) 
    self:setupEventListeners()
    self:processDataForSending()
    self:processReceivedDataQueue()


	TCPManager.tcpPool[self.name]=self 
end
 

function TCPManager.getTcpByName( name ) 
	return TCPManager.tcpPool[name]
end
 

function TCPManager:enqueueDataForSending( data ) 
	self.sendDataPool:enqueue(data)
	-- print("data enqueued for sending. size:",self.sendDataPool:getSize())
end

function TCPManager:enqueueReceivedData( data ) 
	-- print("data enqueued for receiving.")
	self.receivedDataPool:enqueue(data) 
end

function TCPManager:processDataForSending()
	self.SendScheduler = scheduler.scheduleGlobal(function() 
		 if self.sendDataPool:getSize() > 0 and self.status == self.socket.EVENT_CONNECTED then  
			-- print("sending data....")
			self.socket:send(self.sendDataPool:dequeue())
		end
	end,self.SendInt or 0.1)
end

function TCPManager:setPauseReceiveDispatcher(pause)
	self.isRacaiveSchedulerPaused = pause
end


function TCPManager:processReceivedDataQueue()
	self.RecvScheduler = scheduler.scheduleGlobal(function() 
		if self.receivedDataPool:getSize() > 0 and self.isRacaiveSchedulerPaused ~= true then 
			for k,v in pairs(self.eventListenerTable) do
				if v.t == SocketTCP.EVENT_DATA_QUEUE   then   
					v.c(self.receivedDataPool:dequeue())
				end
			end
		end
	end,self.RcvdInt or 0.1)
end

function TCPManager:release()
	self:disconnect()
	self:close()
	self.socket:removeAllEventListeners()  
	if self.reconnectScheduler then
		scheduler.unscheduleGlobal(self.reconnectScheduler) 
	end

	if self.SendScheduler then
		scheduler.unscheduleGlobal(self.SendScheduler) 
	end

	if self.RecvScheduler then
		scheduler.unscheduleGlobal(self.RecvScheduler) 
	end
	TCPManager.tcpPool[self.name] = nil
	self = nil --???
end

function TCPManager:getStatus()
	return self.status
end

function TCPManager:connect()
	 self.socket:connect()
end

function TCPManager:close()
	self.socket:close()
end

function TCPManager:getSocket()
	return self.socket
end

function TCPManager:disconnect()
	print("DISCONNECTING.....")
	self.socket:disconnect()
	print("DISCONNECTED.")
end

function TCPManager:processReconnect()
	printf("TCPManager:%s self.failureRetryTime : %s,self.failureRetryTimeTried:%s,self.isReconnecting :%s",self.name,self.failureRetryTime,self.failureRetryTimeTried,self.isReconnecting )
	if (self.failureRetryTime == 0 or self.failureRetryTimeTried <= self.failureRetryTime) --[[and self.isReconnecting ~= true ]]then
		self.isReconnecting = true
		self.reconnectScheduler = scheduler.performWithDelayGlobal(function() 
			printf("TCPManager:%s trying to reconnect for %s/%s...",self.name,self.failureRetryTimeTried,self.failureRetryTime)
			self.socket:connect()
			self.failureRetryTimeTried=self.failureRetryTimeTried+1
		end,self.failureRetryTimeout)
	else 
		printf("TCPManager:%s reconnect attempt hit (%s/%s).You're on your own now.",self.name,self.failureRetryTimeTried,self.failureRetryTime)
		if self.reconnectScheduler then
			scheduler.unscheduleGlobal(self.reconnectScheduler)
			self.reconnectScheduler = nil
		end
		if self.onReconnectFail then
			self.onReconnectFail()
		end
	end
	-- body
end

function TCPManager:setConnectionRestoredAction(_callback)
	self.onConnectionRestoredAction = _callback
end

function TCPManager:setReconnectFailAction(_callback)
	self.onReconnectFail = _callback
end
function TCPManager:setNodataReceivedTimeout(_callback)
	self.onNoDataReceived = _callback
end

function TCPManager:onStatus(__event)
	self.status =__event.name 
	printf("TCPManager:%s change status to %s.",self.name,self.status)
--	dump(self.eventListenerTable,"self.eventListenerTable)")
	for i,v in ipairs(self.eventListenerTable) do
		if v.t == __event.name then
			v.c(__event.name)
		end
	end


	printf("TCPManager:%s self.retryIfFailure:",self.retryIfFailure)
	if __event.name == self.socket.EVENT_CONNECT_FAILURE and self.retryIfFailure == true then  
		printf("TCPManager:%s Connection Failure,preparing to reconnect.",self.name)
		self:processReconnect()
	end
	
	if __event.name == self.socket.EVENT_CONNECTED and self.isReconnecting == true then  
		self.isReconnecting = nil
		self.failureRetryTimeTried = 0
		if self.reconnectScheduler then
			scheduler.unscheduleGlobal(self.reconnectScheduler)
			self.reconnectScheduler = nil
		end
		if self.onConnectionRestoredAction then
			self.onConnectionRestoredAction()
		end
		printf("TCPManager:%s Connection Restored.",self.name) 
	end

 
	if __event.name == self.socket.EVENT_CONNECT_FAILURE_NO_DATA_RCVD and self.onNoDataReceived then
		self.onNoDataReceived()
	end


end

function TCPManager:setupEventListeners()
    self.socket:addEventListener(SocketTCP.EVENT_CONNECT_FAILURE_NO_DATA_RCVD, handler(self,self.onStatus))
    self.socket:addEventListener(SocketTCP.EVENT_CONNECTED, handler(self,self.onStatus))
    self.socket:addEventListener(SocketTCP.EVENT_CLOSE, handler(self,self.onStatus))
    self.socket:addEventListener(SocketTCP.EVENT_CLOSED, handler(self,self.onStatus))
    self.socket:addEventListener(SocketTCP.EVENT_CONNECT_FAILURE, handler(self,self.onStatus))
    self.socket:addEventListener(SocketTCP.EVENT_DATA, handler(self,self.onData))
end

function TCPManager:addEventListener(_type,callback)
	local t = {
		t = _type,
		c = callback
	} 	 
	--print('inserting ',_type)
	table.insert(self.eventListenerTable,t) 
end


function TCPManager:onData(__event) 
	self:enqueueReceivedData( __event.data )  
end