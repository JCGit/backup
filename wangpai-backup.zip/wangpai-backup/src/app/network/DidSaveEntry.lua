--
-- Author: Wayne Dimart (wjweini@gmail.com)
-- Date: 2015-10-27 10:54:14
--
local  luabit = require"bit"

local ByteArray = require('app.network.ByteArray')
 	DidSaveEntry = {}

	DidSaveEntry.sendMap =  {};
	DidSaveEntry.recvMap = {};

function  DidSaveEntry.init()
			DidSaveEntry.sendMap[0x0] =          0xdc
			DidSaveEntry.sendMap[0x1] =          0xe2
			DidSaveEntry.sendMap[0x2] =          0xfd
			DidSaveEntry.sendMap[0x3] =          0x7c
			DidSaveEntry.sendMap[0x4] =          0x56
			DidSaveEntry.sendMap[0x5] =          0x51
			DidSaveEntry.sendMap[0x6] =          0x6b
			DidSaveEntry.sendMap[0x7] =          0xff
			DidSaveEntry.sendMap[0x8] =          0xb
			DidSaveEntry.sendMap[0x9] =          0x7a
			DidSaveEntry.sendMap[0xa] =          0xbd
			DidSaveEntry.sendMap[0xb] =          0x99
			DidSaveEntry.sendMap[0xc] =          0x5f
			DidSaveEntry.sendMap[0xd] =          0xc4
			DidSaveEntry.sendMap[0xe] =          0x6c
			DidSaveEntry.sendMap[0xf] =          0x2
			DidSaveEntry.sendMap[0x10] =          0xd7
			DidSaveEntry.sendMap[0x11] =          0xeb
			DidSaveEntry.sendMap[0x12] =          0xcf
			DidSaveEntry.sendMap[0x13] =          0xc5
			DidSaveEntry.sendMap[0x14] =          0xb3
			DidSaveEntry.sendMap[0x15] =          0x97
			DidSaveEntry.sendMap[0x16] =          0x3b
			DidSaveEntry.sendMap[0x17] =          0x54
			DidSaveEntry.sendMap[0x18] =          0x36
			DidSaveEntry.sendMap[0x19] =          0x72
			DidSaveEntry.sendMap[0x1a] =          0x67
			DidSaveEntry.sendMap[0x1b] =          0xbb
			DidSaveEntry.sendMap[0x1c] =          0xfe
			DidSaveEntry.sendMap[0x1d] =          0x4c
			DidSaveEntry.sendMap[0x1e] =          0xf
			DidSaveEntry.sendMap[0x1f] =          0xe0
			DidSaveEntry.sendMap[0x20] =          0xc1
			DidSaveEntry.sendMap[0x21] =          0xe8
			DidSaveEntry.sendMap[0x22] =          0xa5
			DidSaveEntry.sendMap[0x23] =          0x58
			DidSaveEntry.sendMap[0x24] =          0x3e
			DidSaveEntry.sendMap[0x25] =          0xc9
			DidSaveEntry.sendMap[0x26] =          0xfc
			DidSaveEntry.sendMap[0x27] =          0xd
			DidSaveEntry.sendMap[0x28] =          0x79
			DidSaveEntry.sendMap[0x29] =          0x92
			DidSaveEntry.sendMap[0x2a] =          0xc7
			DidSaveEntry.sendMap[0x2b] =          0xd8
			DidSaveEntry.sendMap[0x2c] =          0xea
			DidSaveEntry.sendMap[0x2d] =          0x40
			DidSaveEntry.sendMap[0x2e] =          0x17
			DidSaveEntry.sendMap[0x2f] =          0x89
			DidSaveEntry.sendMap[0x30] =          0x2c
			DidSaveEntry.sendMap[0x31] =          0x65
			DidSaveEntry.sendMap[0x32] =          0x93
			DidSaveEntry.sendMap[0x33] =          0x29
			DidSaveEntry.sendMap[0x34] =          0xf4
			DidSaveEntry.sendMap[0x35] =          0x3f
			DidSaveEntry.sendMap[0x36] =          0xee
			DidSaveEntry.sendMap[0x37] =          0x96
			DidSaveEntry.sendMap[0x38] =          0x6a
			DidSaveEntry.sendMap[0x39] =          0xe1
			DidSaveEntry.sendMap[0x3a] =          0x60
			DidSaveEntry.sendMap[0x3b] =          0x74
			DidSaveEntry.sendMap[0x3c] =          0x4e
			DidSaveEntry.sendMap[0x3d] =          0x4d
			DidSaveEntry.sendMap[0x3e] =          0x95
			DidSaveEntry.sendMap[0x3f] =          0x10
			DidSaveEntry.sendMap[0x40] =          0xe9
			DidSaveEntry.sendMap[0x41] =          0x52
			DidSaveEntry.sendMap[0x42] =          0xb4
			DidSaveEntry.sendMap[0x43] =          0xf7
			DidSaveEntry.sendMap[0x44] =          0x9a
			DidSaveEntry.sendMap[0x45] =          0xd5
			DidSaveEntry.sendMap[0x46] =          0xdd
			DidSaveEntry.sendMap[0x47] =          0xd3
			DidSaveEntry.sendMap[0x48] =          0x9d
			DidSaveEntry.sendMap[0x49] =          0xd9
			DidSaveEntry.sendMap[0x4a] =          0xe7
			DidSaveEntry.sendMap[0x4b] =          0x53
			DidSaveEntry.sendMap[0x4c] =          0x3d
			DidSaveEntry.sendMap[0x4d] =          0x42
			DidSaveEntry.sendMap[0x4e] =          0xb8
			DidSaveEntry.sendMap[0x4f] =          0x8
			DidSaveEntry.sendMap[0x50] =          0xc3
			DidSaveEntry.sendMap[0x51] =          0xf8
			DidSaveEntry.sendMap[0x52] =          0x30
			DidSaveEntry.sendMap[0x53] =          0xa6
			DidSaveEntry.sendMap[0x54] =          0xcb
			DidSaveEntry.sendMap[0x55] =          0xfb
			DidSaveEntry.sendMap[0x56] =          0xaf
			DidSaveEntry.sendMap[0x57] =          0x5b
			DidSaveEntry.sendMap[0x58] =          0x61
			DidSaveEntry.sendMap[0x59] =          0x2f
			DidSaveEntry.sendMap[0x5a] =          0x77
			DidSaveEntry.sendMap[0x5b] =          0x94
			DidSaveEntry.sendMap[0x5c] =          0xba
			DidSaveEntry.sendMap[0x5d] =          0xb0
			DidSaveEntry.sendMap[0x5e] =          0x76
			DidSaveEntry.sendMap[0x5f] =          0xf6
			DidSaveEntry.sendMap[0x60] =          0x6
			DidSaveEntry.sendMap[0x61] =          0xdf
			DidSaveEntry.sendMap[0x62] =          0xb1
			DidSaveEntry.sendMap[0x63] =          0x15
			DidSaveEntry.sendMap[0x64] =          0xc0
			DidSaveEntry.sendMap[0x65] =          0x8f
			DidSaveEntry.sendMap[0x66] =          0xc2
			DidSaveEntry.sendMap[0x67] =          0xe4
			DidSaveEntry.sendMap[0x68] =          0x1f
			DidSaveEntry.sendMap[0x69] =          0xf3
			DidSaveEntry.sendMap[0x6a] =          0x8d
			DidSaveEntry.sendMap[0x6b] =          0x9
			DidSaveEntry.sendMap[0x6c] =          0x19
			DidSaveEntry.sendMap[0x6d] =          0x12
			DidSaveEntry.sendMap[0x6e] =          0x2a
			DidSaveEntry.sendMap[0x6f] =          0xa1
			DidSaveEntry.sendMap[0x70] =          0xb5
			DidSaveEntry.sendMap[0x71] =          0x7f
			DidSaveEntry.sendMap[0x72] =          0x13
			DidSaveEntry.sendMap[0x73] =          0xa3
			DidSaveEntry.sendMap[0x74] =          0x48
			DidSaveEntry.sendMap[0x75] =          0x71
			DidSaveEntry.sendMap[0x76] =          0x31
			DidSaveEntry.sendMap[0x77] =          0xd6
			DidSaveEntry.sendMap[0x78] =          0x32
			DidSaveEntry.sendMap[0x79] =          0x7d
			DidSaveEntry.sendMap[0x7a] =          0xbc
			DidSaveEntry.sendMap[0x7b] =          0xb2
			DidSaveEntry.sendMap[0x7c] =          0x0
			DidSaveEntry.sendMap[0x7d] =          0x37
			DidSaveEntry.sendMap[0x7e] =          0x45
			DidSaveEntry.sendMap[0x7f] =          0x66
			DidSaveEntry.sendMap[0x80] =          0x63
			DidSaveEntry.sendMap[0x81] =          0x1b
			DidSaveEntry.sendMap[0x82] =          0x21
			DidSaveEntry.sendMap[0x83] =          0xab
			DidSaveEntry.sendMap[0x84] =          0x75
			DidSaveEntry.sendMap[0x85] =          0xd2
			DidSaveEntry.sendMap[0x86] =          0x41
			DidSaveEntry.sendMap[0x87] =          0xa7
			DidSaveEntry.sendMap[0x88] =          0xb9
			DidSaveEntry.sendMap[0x89] =          0xdb
			DidSaveEntry.sendMap[0x8a] =          0xfa
			DidSaveEntry.sendMap[0x8b] =          0xd0
			DidSaveEntry.sendMap[0x8c] =          0x25
			DidSaveEntry.sendMap[0x8d] =          0x84
			DidSaveEntry.sendMap[0x8e] =          0xa8
			DidSaveEntry.sendMap[0x8f] =          0x87
			DidSaveEntry.sendMap[0x90] =          0x3c
			DidSaveEntry.sendMap[0x91] =          0xd4
			DidSaveEntry.sendMap[0x92] =          0xf2
			DidSaveEntry.sendMap[0x93] =          0x4f
			DidSaveEntry.sendMap[0x94] =          0x16
			DidSaveEntry.sendMap[0x95] =          0x14
			DidSaveEntry.sendMap[0x96] =          0x28
			DidSaveEntry.sendMap[0x97] =          0x5d
			DidSaveEntry.sendMap[0x98] =          0xbe
			DidSaveEntry.sendMap[0x99] =          0x44
			DidSaveEntry.sendMap[0x9a] =          0x6f
			DidSaveEntry.sendMap[0x9b] =          0x8a
			DidSaveEntry.sendMap[0x9c] =          0x2b
			DidSaveEntry.sendMap[0x9d] =          0x8b
			DidSaveEntry.sendMap[0x9e] =          0x6e
			DidSaveEntry.sendMap[0x9f] =          0xa0
			DidSaveEntry.sendMap[0xa0] =          0x46
			DidSaveEntry.sendMap[0xa1] =          0x50
			DidSaveEntry.sendMap[0xa2] =          0x9c
			DidSaveEntry.sendMap[0xa3] =          0xca
			DidSaveEntry.sendMap[0xa4] =          0xa4
			DidSaveEntry.sendMap[0xa5] =          0x38
			DidSaveEntry.sendMap[0xa6] =          0xe6
			DidSaveEntry.sendMap[0xa7] =          0x2d
			DidSaveEntry.sendMap[0xa8] =          0x8c
			DidSaveEntry.sendMap[0xa9] =          0xa
			DidSaveEntry.sendMap[0xaa] =          0x9b
			DidSaveEntry.sendMap[0xab] =          0x78
			DidSaveEntry.sendMap[0xac] =          0x80
			DidSaveEntry.sendMap[0xad] =          0x5c
			DidSaveEntry.sendMap[0xae] =          0xcc
			DidSaveEntry.sendMap[0xaf] =          0x4a
			DidSaveEntry.sendMap[0xb0] =          0x59
			DidSaveEntry.sendMap[0xb1] =          0x5
			DidSaveEntry.sendMap[0xb2] =          0x9e
			DidSaveEntry.sendMap[0xb3] =          0xc6
			DidSaveEntry.sendMap[0xb4] =          0xb6
			DidSaveEntry.sendMap[0xb5] =          0x9f
			DidSaveEntry.sendMap[0xb6] =          0x55
			DidSaveEntry.sendMap[0xb7] =          0x64
			DidSaveEntry.sendMap[0xb8] =          0xde
			DidSaveEntry.sendMap[0xb9] =          0x18
			DidSaveEntry.sendMap[0xba] =          0xac
			DidSaveEntry.sendMap[0xbb] =          0x34
			DidSaveEntry.sendMap[0xbc] =          0x69
			DidSaveEntry.sendMap[0xbd] =          0x3a
			DidSaveEntry.sendMap[0xbe] =          0xce
			DidSaveEntry.sendMap[0xbf] =          0x11
			DidSaveEntry.sendMap[0xc0] =          0xc8
			DidSaveEntry.sendMap[0xc1] =          0xe5
			DidSaveEntry.sendMap[0xc2] =          0xe
			DidSaveEntry.sendMap[0xc3] =          0xec
			DidSaveEntry.sendMap[0xc4] =          0xef
			DidSaveEntry.sendMap[0xc5] =          0x27
			DidSaveEntry.sendMap[0xc6] =          0x7e
			DidSaveEntry.sendMap[0xc7] =          0x8e
			DidSaveEntry.sendMap[0xc8] =          0x1a
			DidSaveEntry.sendMap[0xc9] =          0x6d
			DidSaveEntry.sendMap[0xca] =          0x1c
			DidSaveEntry.sendMap[0xcb] =          0x2e
			DidSaveEntry.sendMap[0xcc] =          0x35
			DidSaveEntry.sendMap[0xcd] =          0x86
			DidSaveEntry.sendMap[0xce] =          0xb7
			DidSaveEntry.sendMap[0xcf] =          0x4
			DidSaveEntry.sendMap[0xd0] =          0xf9
			DidSaveEntry.sendMap[0xd1] =          0x82
			DidSaveEntry.sendMap[0xd2] =          0x39
			DidSaveEntry.sendMap[0xd3] =          0xf5
			DidSaveEntry.sendMap[0xd4] =          0x90
			DidSaveEntry.sendMap[0xd5] =          0x83
			DidSaveEntry.sendMap[0xd6] =          0x5e
			DidSaveEntry.sendMap[0xd7] =          0x98
			DidSaveEntry.sendMap[0xd8] =          0x26
			DidSaveEntry.sendMap[0xd9] =          0x1d
			DidSaveEntry.sendMap[0xda] =          0x43
			DidSaveEntry.sendMap[0xdb] =          0x91
			DidSaveEntry.sendMap[0xdc] =          0x22
			DidSaveEntry.sendMap[0xdd] =          0x81
			DidSaveEntry.sendMap[0xde] =          0xae
			DidSaveEntry.sendMap[0xdf] =          0xd1
			DidSaveEntry.sendMap[0xe0] =          0xe3
			DidSaveEntry.sendMap[0xe1] =          0x23
			DidSaveEntry.sendMap[0xe2] =          0xa2
			DidSaveEntry.sendMap[0xe3] =          0x70
			DidSaveEntry.sendMap[0xe4] =          0x57
			DidSaveEntry.sendMap[0xe5] =          0x62
			DidSaveEntry.sendMap[0xe6] =          0x24
			DidSaveEntry.sendMap[0xe7] =          0xf0
			DidSaveEntry.sendMap[0xe8] =          0x5a
			DidSaveEntry.sendMap[0xe9] =          0xaa
			DidSaveEntry.sendMap[0xea] =          0xcd
			DidSaveEntry.sendMap[0xeb] =          0x1
			DidSaveEntry.sendMap[0xec] =          0x7
			DidSaveEntry.sendMap[0xed] =          0x20
			DidSaveEntry.sendMap[0xee] =          0xda
			DidSaveEntry.sendMap[0xef] =          0xf1
			DidSaveEntry.sendMap[0xf0] =          0x88
			DidSaveEntry.sendMap[0xf1] =          0xed
			DidSaveEntry.sendMap[0xf2] =          0xc
			DidSaveEntry.sendMap[0xf3] =          0x49
			DidSaveEntry.sendMap[0xf4] =          0x3
			DidSaveEntry.sendMap[0xf5] =          0x73
			DidSaveEntry.sendMap[0xf6] =          0x4b
			DidSaveEntry.sendMap[0xf7] =          0x47
			DidSaveEntry.sendMap[0xf8] =          0x7b
			DidSaveEntry.sendMap[0xf9] =          0x68
			DidSaveEntry.sendMap[0xfa] =          0xbf
			DidSaveEntry.sendMap[0xfb] =          0x85
			DidSaveEntry.sendMap[0xfc] =          0x33
			DidSaveEntry.sendMap[0xfd] =          0x1e
			DidSaveEntry.sendMap[0xfe] =          0xa9
			DidSaveEntry.sendMap[0xff] =          0xad		
                                                 
			DidSaveEntry.recvMap[0xdc] =          0x0
			DidSaveEntry.recvMap[0xe2] =          0x1
			DidSaveEntry.recvMap[0xfd] =          0x2
			DidSaveEntry.recvMap[0x7c] =          0x3
			DidSaveEntry.recvMap[0x56] =          0x4
			DidSaveEntry.recvMap[0x51] =          0x5
			DidSaveEntry.recvMap[0x6b] =          0x6
			DidSaveEntry.recvMap[0xff] =          0x7
			DidSaveEntry.recvMap[0xb] =          0x8
			DidSaveEntry.recvMap[0x7a] =          0x9
			DidSaveEntry.recvMap[0xbd] =          0xa
			DidSaveEntry.recvMap[0x99] =          0xb
			DidSaveEntry.recvMap[0x5f] =          0xc
			DidSaveEntry.recvMap[0xc4] =          0xd
			DidSaveEntry.recvMap[0x6c] =          0xe
			DidSaveEntry.recvMap[0x2] =          0xf
			DidSaveEntry.recvMap[0xd7] =          0x10
			DidSaveEntry.recvMap[0xeb] =          0x11
			DidSaveEntry.recvMap[0xcf] =          0x12
			DidSaveEntry.recvMap[0xc5] =          0x13
			DidSaveEntry.recvMap[0xb3] =          0x14
			DidSaveEntry.recvMap[0x97] =          0x15
			DidSaveEntry.recvMap[0x3b] =          0x16
			DidSaveEntry.recvMap[0x54] =          0x17
			DidSaveEntry.recvMap[0x36] =          0x18
			DidSaveEntry.recvMap[0x72] =          0x19
			DidSaveEntry.recvMap[0x67] =          0x1a
			DidSaveEntry.recvMap[0xbb] =          0x1b
			DidSaveEntry.recvMap[0xfe] =          0x1c
			DidSaveEntry.recvMap[0x4c] =          0x1d
			DidSaveEntry.recvMap[0xf] =          0x1e
			DidSaveEntry.recvMap[0xe0] =          0x1f
			DidSaveEntry.recvMap[0xc1] =          0x20
			DidSaveEntry.recvMap[0xe8] =          0x21
			DidSaveEntry.recvMap[0xa5] =          0x22
			DidSaveEntry.recvMap[0x58] =          0x23
			DidSaveEntry.recvMap[0x3e] =          0x24
			DidSaveEntry.recvMap[0xc9] =          0x25
			DidSaveEntry.recvMap[0xfc] =          0x26
			DidSaveEntry.recvMap[0xd] =          0x27
			DidSaveEntry.recvMap[0x79] =          0x28
			DidSaveEntry.recvMap[0x92] =          0x29
			DidSaveEntry.recvMap[0xc7] =          0x2a
			DidSaveEntry.recvMap[0xd8] =          0x2b
			DidSaveEntry.recvMap[0xea] =          0x2c
			DidSaveEntry.recvMap[0x40] =          0x2d
			DidSaveEntry.recvMap[0x17] =          0x2e
			DidSaveEntry.recvMap[0x89] =          0x2f
			DidSaveEntry.recvMap[0x2c] =          0x30
			DidSaveEntry.recvMap[0x65] =          0x31
			DidSaveEntry.recvMap[0x93] =          0x32
			DidSaveEntry.recvMap[0x29] =          0x33
			DidSaveEntry.recvMap[0xf4] =          0x34
			DidSaveEntry.recvMap[0x3f] =          0x35
			DidSaveEntry.recvMap[0xee] =          0x36
			DidSaveEntry.recvMap[0x96] =          0x37
			DidSaveEntry.recvMap[0x6a] =          0x38
			DidSaveEntry.recvMap[0xe1] =          0x39
			DidSaveEntry.recvMap[0x60] =          0x3a
			DidSaveEntry.recvMap[0x74] =          0x3b
			DidSaveEntry.recvMap[0x4e] =          0x3c
			DidSaveEntry.recvMap[0x4d] =          0x3d
			DidSaveEntry.recvMap[0x95] =          0x3e
			DidSaveEntry.recvMap[0x10] =          0x3f
			DidSaveEntry.recvMap[0xe9] =          0x40
			DidSaveEntry.recvMap[0x52] =          0x41
			DidSaveEntry.recvMap[0xb4] =          0x42
			DidSaveEntry.recvMap[0xf7] =          0x43
			DidSaveEntry.recvMap[0x9a] =          0x44
			DidSaveEntry.recvMap[0xd5] =          0x45
			DidSaveEntry.recvMap[0xdd] =          0x46
			DidSaveEntry.recvMap[0xd3] =          0x47
			DidSaveEntry.recvMap[0x9d] =          0x48
			DidSaveEntry.recvMap[0xd9] =          0x49
			DidSaveEntry.recvMap[0xe7] =          0x4a
			DidSaveEntry.recvMap[0x53] =          0x4b
			DidSaveEntry.recvMap[0x3d] =          0x4c
			DidSaveEntry.recvMap[0x42] =          0x4d
			DidSaveEntry.recvMap[0xb8] =          0x4e
			DidSaveEntry.recvMap[0x8] =          0x4f
			DidSaveEntry.recvMap[0xc3] =          0x50
			DidSaveEntry.recvMap[0xf8] =          0x51
			DidSaveEntry.recvMap[0x30] =          0x52
			DidSaveEntry.recvMap[0xa6] =          0x53
			DidSaveEntry.recvMap[0xcb] =          0x54
			DidSaveEntry.recvMap[0xfb] =          0x55
			DidSaveEntry.recvMap[0xaf] =          0x56
			DidSaveEntry.recvMap[0x5b] =          0x57
			DidSaveEntry.recvMap[0x61] =          0x58
			DidSaveEntry.recvMap[0x2f] =          0x59
			DidSaveEntry.recvMap[0x77] =          0x5a
			DidSaveEntry.recvMap[0x94] =          0x5b
			DidSaveEntry.recvMap[0xba] =          0x5c
			DidSaveEntry.recvMap[0xb0] =          0x5d
			DidSaveEntry.recvMap[0x76] =          0x5e
			DidSaveEntry.recvMap[0xf6] =          0x5f
			DidSaveEntry.recvMap[0x6] =          0x60
			DidSaveEntry.recvMap[0xdf] =          0x61
			DidSaveEntry.recvMap[0xb1] =          0x62
			DidSaveEntry.recvMap[0x15] =          0x63
			DidSaveEntry.recvMap[0xc0] =          0x64
			DidSaveEntry.recvMap[0x8f] =          0x65
			DidSaveEntry.recvMap[0xc2] =          0x66
			DidSaveEntry.recvMap[0xe4] =          0x67
			DidSaveEntry.recvMap[0x1f] =          0x68
			DidSaveEntry.recvMap[0xf3] =          0x69
			DidSaveEntry.recvMap[0x8d] =          0x6a
			DidSaveEntry.recvMap[0x9] =          0x6b
			DidSaveEntry.recvMap[0x19] =          0x6c
			DidSaveEntry.recvMap[0x12] =          0x6d
			DidSaveEntry.recvMap[0x2a] =          0x6e
			DidSaveEntry.recvMap[0xa1] =          0x6f
			DidSaveEntry.recvMap[0xb5] =          0x70
			DidSaveEntry.recvMap[0x7f] =          0x71
			DidSaveEntry.recvMap[0x13] =          0x72
			DidSaveEntry.recvMap[0xa3] =          0x73
			DidSaveEntry.recvMap[0x48] =          0x74
			DidSaveEntry.recvMap[0x71] =          0x75
			DidSaveEntry.recvMap[0x31] =          0x76
			DidSaveEntry.recvMap[0xd6] =          0x77
			DidSaveEntry.recvMap[0x32] =          0x78
			DidSaveEntry.recvMap[0x7d] =          0x79
			DidSaveEntry.recvMap[0xbc] =          0x7a
			DidSaveEntry.recvMap[0xb2] =          0x7b
			DidSaveEntry.recvMap[0x0] =          0x7c
			DidSaveEntry.recvMap[0x37] =          0x7d
			DidSaveEntry.recvMap[0x45] =          0x7e
			DidSaveEntry.recvMap[0x66] =          0x7f
			DidSaveEntry.recvMap[0x63] =          0x80
			DidSaveEntry.recvMap[0x1b] =          0x81
			DidSaveEntry.recvMap[0x21] =          0x82
			DidSaveEntry.recvMap[0xab] =          0x83
			DidSaveEntry.recvMap[0x75] =          0x84
			DidSaveEntry.recvMap[0xd2] =          0x85
			DidSaveEntry.recvMap[0x41] =          0x86
			DidSaveEntry.recvMap[0xa7] =          0x87
			DidSaveEntry.recvMap[0xb9] =          0x88
			DidSaveEntry.recvMap[0xdb] =          0x89
			DidSaveEntry.recvMap[0xfa] =          0x8a
			DidSaveEntry.recvMap[0xd0] =          0x8b
			DidSaveEntry.recvMap[0x25] =          0x8c
			DidSaveEntry.recvMap[0x84] =          0x8d
			DidSaveEntry.recvMap[0xa8] =          0x8e
			DidSaveEntry.recvMap[0x87] =          0x8f
			DidSaveEntry.recvMap[0x3c] =          0x90
			DidSaveEntry.recvMap[0xd4] =          0x91
			DidSaveEntry.recvMap[0xf2] =          0x92
			DidSaveEntry.recvMap[0x4f] =          0x93
			DidSaveEntry.recvMap[0x16] =          0x94
			DidSaveEntry.recvMap[0x14] =          0x95
			DidSaveEntry.recvMap[0x28] =          0x96
			DidSaveEntry.recvMap[0x5d] =          0x97
			DidSaveEntry.recvMap[0xbe] =          0x98
			DidSaveEntry.recvMap[0x44] =          0x99
			DidSaveEntry.recvMap[0x6f] =          0x9a
			DidSaveEntry.recvMap[0x8a] =          0x9b
			DidSaveEntry.recvMap[0x2b] =          0x9c
			DidSaveEntry.recvMap[0x8b] =          0x9d
			DidSaveEntry.recvMap[0x6e] =          0x9e
			DidSaveEntry.recvMap[0xa0] =          0x9f
			DidSaveEntry.recvMap[0x46] =          0xa0
			DidSaveEntry.recvMap[0x50] =          0xa1
			DidSaveEntry.recvMap[0x9c] =          0xa2
			DidSaveEntry.recvMap[0xca] =          0xa3
			DidSaveEntry.recvMap[0xa4] =          0xa4
			DidSaveEntry.recvMap[0x38] =          0xa5
			DidSaveEntry.recvMap[0xe6] =          0xa6
			DidSaveEntry.recvMap[0x2d] =          0xa7
			DidSaveEntry.recvMap[0x8c] =          0xa8
			DidSaveEntry.recvMap[0xa] =          0xa9
			DidSaveEntry.recvMap[0x9b] =          0xaa
			DidSaveEntry.recvMap[0x78] =          0xab
			DidSaveEntry.recvMap[0x80] =          0xac
			DidSaveEntry.recvMap[0x5c] =          0xad
			DidSaveEntry.recvMap[0xcc] =          0xae
			DidSaveEntry.recvMap[0x4a] =          0xaf
			DidSaveEntry.recvMap[0x59] =          0xb0
			DidSaveEntry.recvMap[0x5] =          0xb1
			DidSaveEntry.recvMap[0x9e] =          0xb2
			DidSaveEntry.recvMap[0xc6] =          0xb3
			DidSaveEntry.recvMap[0xb6] =          0xb4
			DidSaveEntry.recvMap[0x9f] =          0xb5
			DidSaveEntry.recvMap[0x55] =          0xb6
			DidSaveEntry.recvMap[0x64] =          0xb7
			DidSaveEntry.recvMap[0xde] =          0xb8
			DidSaveEntry.recvMap[0x18] =          0xb9
			DidSaveEntry.recvMap[0xac] =          0xba
			DidSaveEntry.recvMap[0x34] =          0xbb
			DidSaveEntry.recvMap[0x69] =          0xbc
			DidSaveEntry.recvMap[0x3a] =          0xbd
			DidSaveEntry.recvMap[0xce] =          0xbe
			DidSaveEntry.recvMap[0x11] =          0xbf
			DidSaveEntry.recvMap[0xc8] =          0xc0
			DidSaveEntry.recvMap[0xe5] =          0xc1
			DidSaveEntry.recvMap[0xe] =          0xc2
			DidSaveEntry.recvMap[0xec] =          0xc3
			DidSaveEntry.recvMap[0xef] =          0xc4
			DidSaveEntry.recvMap[0x27] =          0xc5
			DidSaveEntry.recvMap[0x7e] =          0xc6
			DidSaveEntry.recvMap[0x8e] =          0xc7
			DidSaveEntry.recvMap[0x1a] =          0xc8
			DidSaveEntry.recvMap[0x6d] =          0xc9
			DidSaveEntry.recvMap[0x1c] =          0xca
			DidSaveEntry.recvMap[0x2e] =          0xcb
			DidSaveEntry.recvMap[0x35] =          0xcc
			DidSaveEntry.recvMap[0x86] =          0xcd
			DidSaveEntry.recvMap[0xb7] =          0xce
			DidSaveEntry.recvMap[0x4] =          0xcf
			DidSaveEntry.recvMap[0xf9] =          0xd0
			DidSaveEntry.recvMap[0x82] =          0xd1
			DidSaveEntry.recvMap[0x39] =          0xd2
			DidSaveEntry.recvMap[0xf5] =          0xd3
			DidSaveEntry.recvMap[0x90] =          0xd4
			DidSaveEntry.recvMap[0x83] =          0xd5
			DidSaveEntry.recvMap[0x5e] =          0xd6
			DidSaveEntry.recvMap[0x98] =          0xd7
			DidSaveEntry.recvMap[0x26] =          0xd8
			DidSaveEntry.recvMap[0x1d] =          0xd9
			DidSaveEntry.recvMap[0x43] =          0xda
			DidSaveEntry.recvMap[0x91] =          0xdb
			DidSaveEntry.recvMap[0x22] =          0xdc
			DidSaveEntry.recvMap[0x81] =          0xdd
			DidSaveEntry.recvMap[0xae] =          0xde
			DidSaveEntry.recvMap[0xd1] =          0xdf
			DidSaveEntry.recvMap[0xe3] =          0xe0
			DidSaveEntry.recvMap[0x23] =          0xe1
			DidSaveEntry.recvMap[0xa2] =          0xe2
			DidSaveEntry.recvMap[0x70] =          0xe3
			DidSaveEntry.recvMap[0x57] =          0xe4
			DidSaveEntry.recvMap[0x62] =          0xe5
			DidSaveEntry.recvMap[0x24] =          0xe6
			DidSaveEntry.recvMap[0xf0] =          0xe7
			DidSaveEntry.recvMap[0x5a] =          0xe8
			DidSaveEntry.recvMap[0xaa] =          0xe9
			DidSaveEntry.recvMap[0xcd] =          0xea
			DidSaveEntry.recvMap[0x1] =          0xeb
			DidSaveEntry.recvMap[0x7] =          0xec
			DidSaveEntry.recvMap[0x20] =          0xed
			DidSaveEntry.recvMap[0xda] =          0xee
			DidSaveEntry.recvMap[0xf1] =          0xef
			DidSaveEntry.recvMap[0x88] =          0xf0
			DidSaveEntry.recvMap[0xed] =          0xf1
			DidSaveEntry.recvMap[0xc] =          0xf2
			DidSaveEntry.recvMap[0x49] =          0xf3
			DidSaveEntry.recvMap[0x3] =          0xf4
			DidSaveEntry.recvMap[0x73] =          0xf5
			DidSaveEntry.recvMap[0x4b] =          0xf6
			DidSaveEntry.recvMap[0x47] =          0xf7
			DidSaveEntry.recvMap[0x7b] =          0xf8
			DidSaveEntry.recvMap[0x68] =          0xf9
			DidSaveEntry.recvMap[0xbf] =          0xfa
			DidSaveEntry.recvMap[0x85] =          0xfb
			DidSaveEntry.recvMap[0x33] =          0xfc
			DidSaveEntry.recvMap[0x1e] =          0xfd
			DidSaveEntry.recvMap[0xa9] =          0xfe
			DidSaveEntry.recvMap[0xad] =          0xff
end

function DidSaveEntry.EncryptBufferNoCC(b,  nbegin,  dataSize)
	DidSaveEntry.init();

	local tStr = {}
	print('=========BEGIN DidSaveEntry EncryptBufferNoCC=============')
	for i=nbegin,dataSize do  
		tStr[i] = string.format("%02x", (DidSaveEntry.MapSendByte(b[i], DidSaveEntry.sendMap))) 
		printf("enOut[%d]:%s", i,tStr[i])
	end 
	print('=========END DidSaveEntry EncryptBufferNoCC=============')
    return  table.concat(tStr)
end

function DidSaveEntry.CrevasseBufferNoCC(b, nbegin,  wDataSize)
	--DidSaveEntry.init();
	DidSaveEntry.init();
	local tStr = {}

	print('=========BEGIN DidSaveEntry CrevasseBufferNoCC=============')
	for i=nbegin,wDataSize do
		-- ByteArray.toSignedByte(oldByte)
		local unsigned = (DidSaveEntry.recvMap[b[i]])
		tStr[i] = string.char(unsigned)--(DidSaveEntry.MapRecvByte(b[i], DidParseEntry.recvMap))
		printf('%s: [0x%02X]=> 0x%02X (%s)',i,b[i],DidSaveEntry.recvMap[b[i]],tStr[i])
		-- printf("enOut[%d]:%s", i,[b[i])
	end
	print('=========END DidSaveEntry CrevasseBufferNoCC=============')
	-- dump(tStr)

	return table.concat(tStr)
end

function DidSaveEntry.EncryptBuffer(b,  nbegin,  dataSize,  sendMap)
	DidSaveEntry.init();
	local cbCheckCode = 0; 
	--convert to table first


	local tStr = {}
	for i=nbegin,dataSize  do
	    tStr[i] = b:sub(i, i)
	end 

	for i=nbegin,dataSize do  
		cbCheckCode = cbCheckCode + DidSaveEntry.toUnsign(string.byte(tStr[i]))

		local before = string.byte(tStr[i])
		tStr[i] = string.char(DidSaveEntry.MapSendByte(string.byte(tStr[i]), sendMap)) 

		--printf("CLUA ENCODEING (%02X) => (%02X) ",before, string.byte(tStr[i]) );
	end 
	cbCheckCode=luabit.bnot(cbCheckCode)+1 
    return  DidSaveEntry.inttochar(cbCheckCode),table.concat(tStr)
end

function  DidSaveEntry.inttochar(int) 
	return luabit.band(int,0xFF)
end


function  DidSaveEntry.CrevasseBuffer(b,  nbegin,  wDataSize,  cbCheckCode,  recvMap)
	DidSaveEntry.init();

	local tStr = {}
	for i=1,wDataSize  do

	    tStr[i] = b:sub(i, i)
	    
		-- print(' pre:tStr['..i..']:'..tStr[i])
	end 

 
	for i=1,#tStr do
		tStr[i] = string.char(DidSaveEntry.MapRecvByte(string.byte(tStr[i]), recvMap))  
		cbCheckCode  =    cbCheckCode+DidSaveEntry.toUnsign( string.byte(tStr[i]) )   
		cbCheckCode = cbCheckCode/256;
		-- print('tStr['..i..']:'..tStr[i])
	end
	-- for (int i = nbegin; i < wDataSize; i++) {
	-- 	b[i] = (char) MapRecvByte(b[i], recvMap);
	-- 	cbCheckCode += toUnsign(b[i]);
	-- 	cbCheckCode /= 256;
	-- }
	return DidSaveEntry.inttochar(cbCheckCode),table.concat(tStr);
end

function  DidSaveEntry.toUnsign(oldByte) 
	local ret = 0
	local b = oldByte
	local c = 0
	c = luabit.band(b,0x7f)
	if b < 0 then
		ret = 128;
	end 
	-- printf("LUA toUnsign b:%02X,c:%02X,ret:%02X (returning oldByte directlly:%d)",b,c,ret + c,oldByte)
	return oldByte--ret + c;
end

function  DidSaveEntry.MapSendByte( cbData, sendMap)
	cbData = DidSaveEntry.toUnsign(cbData)
	return sendMap[cbData]
end
function  DidSaveEntry.MapRecvByte( cbData,  recvMap)
	cbData = DidSaveEntry.toUnsign(cbData);
	local oo = recvMap[cbData]
	--printf("cbData: %d", oo )
	return oo
end

