
local Widgets = class("Widgets")

function Widgets:ctor(app, name)
    self.app_ = app
    self.name_ = name

    self.widgets_ = {}
    
    self:addWidget("Item")
    self:addWidget("Entity")
    
    return self
end

function Widgets:getApp()
    return self.app_
end

function Widgets:getName()
    return self.name_
end

function Widgets:addWidget(name)
    self.widgets_[name] = require(("app.widgets.%s"):format(name))
    
    return self.widgets_[name]
end

function Widgets:getWidget(name)
    return self.widgets_[name]
end

return Widgets
