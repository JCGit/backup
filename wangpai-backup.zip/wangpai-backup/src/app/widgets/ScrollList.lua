local ScrollList = class("ScrollList", ccui.Layout)

--selectedIndex从1开始
function ScrollList:ctor(app, name, bgSize,itemList, selectedIndex, maxShowItemCount, scaleDValue, itemIntervalList, isloop, cutCall, touchCall)
    self:enableNodeEvents()
    
    self.Tools = app:getModel("Tools")
   
    --参数
    self.maxZOrder = 100
    self.touchBeganPos = {}
    self.itemXPosList = {}
    self.normalScale = 1.0
    self.itemScaleList = {}
    self.itemSkewList = {}
    self.cutDistance1 = 100
    self.maxShowItemCount = maxShowItemCount
    self.showingItemList = {}
    self.lastMovePos = {x = 0, y = 0}
    self.moveDistance = 0
    self.isLockTouchEvent = false
    self.tickMoveItem = nil
    self.tick = 0
    self.slideSpeed = 300
    self.rotationAngle = 0 --40
    self.isloop = isloop
    
    self.lastSelectedIndex = selectedIndex
    self.scaleDValue = scaleDValue
    self.itemIntervalList = itemIntervalList
    self.itemList = itemList
    self.maxItemCount = #itemList
    self.bgSize = bgSize
    self:initItemPosAndScaleData(self.bgSize.width/2)
    self.cutCall = cutCall
    self.touchCall = touchCall
    
    self:setContentSize(bgSize)
    self:setAnchorPoint(cc.p(0.5, 0.5))
    self:setEnabled(true)
    self:setTouchEnabled(true)

    --将tiems add到层上
    for key, var in ipairs(itemList) do
        var:setSwallowTouches(false)
        self:addChild(var)
    end
    
    --初始化item
    local leftItemCount_Now = 0
    local rightItemCount_Now = 0
    
    if self.isloop == true then
        leftItemCount_Now, rightItemCount_Now = self:getSideItemCount_loop(selectedIndex)
    else
        leftItemCount_Now, rightItemCount_Now = self:getSideItemCount(selectedIndex)
    end
    
    --中间item
    local centerItem = self.itemList[selectedIndex]
    centerItem:setPosition(cc.p(self.itemXPosList[0], self.bgSize.height/2))
    centerItem:setLocalZOrder(self.maxZOrder)
    --centerItem:getChildByName("Panel_1"):setRotation3D(cc.p(0, self.rotationAngle, 0))
    centerItem:setVisible(true)
    centerItem:setTag(0)
    centerItem:setScale(self.itemScaleList[0])
    self.cutCall(centerItem, "select")
    table.insert(self.showingItemList, centerItem)
    
    local index = 0
    
    --左侧item
    for i = 1, leftItemCount_Now do
        index = selectedIndex - i
        
        if self.isloop == true then
            if index < 1 then
                index = self.maxItemCount + index
            end
        end
        
        local leftItem = self.itemList[index]
        leftItem:setPosition(cc.p(self.itemXPosList[-1*i], self.bgSize.height/2))
        leftItem:setLocalZOrder(self.maxZOrder - i)
        --leftItem:getChildByName("Panel_1"):setRotation3D(cc.vec3(0, self.rotationAngle, 0))
        
        leftItem:setVisible(true)
        leftItem:setTag(-1 * i)
        leftItem:setScale(self.itemScaleList[-1*i])
        self.cutCall(leftItem, "unSelect")
        table.insert(self.showingItemList, 1, leftItem)
    end

    --右侧item
    for i = 1, rightItemCount_Now do
        
        index = selectedIndex + i
        
        if self.isloop == true then
            if index > self.maxItemCount then
                index = index - self.maxItemCount
            end
        end
        
        local posX = self.itemXPosList[i]
        
        local rightItem = self.itemList[index]
        rightItem:setPosition(cc.p(self.itemXPosList[i], self.bgSize.height/2))
        rightItem:setLocalZOrder(self.maxZOrder - i)
        --rightItem:getChildByName("Panel_1"):setRotation3D(cc.p(0, self.rotationAngle, 0))
        rightItem:setVisible(true)
        rightItem:setTag(i)
        rightItem:setScale(self.itemScaleList[i])
        self.cutCall(rightItem, "unSelect")
        table.insert(self.showingItemList, rightItem)
        
    end
    
    local function touchTest(event)
       
       if self.isLockTouchEvent == true then
           return
       end

        if event.name == "began" then
            local tmpPos = self:getTouchBeganPosition()
            tmpPos = self:convertToNodeSpace(tmpPos)
            self.touchBeganPos = tmpPos

            self.lastMovePos = {x = 0, y = 0}
            
            local rect = self:getChildByTag(0):getBoundingBox()
            if cc.rectContainsPoint(rect, tmpPos) then --self.Tools:containsPoint(rect, tmpPos) then
                self.beagnTouch = self:getChildByTag(0)
            end
            
        elseif event.name == "moved" then
            local tmpPos = self:getTouchMovePosition()
            tmpPos = self:convertToNodeSpace(tmpPos)
  
            local moveDValue = 0
            if self.lastMovePos.x ~= 0 then
                moveDValue = (tmpPos.x - self.lastMovePos.x)
                
                if self.isloop == true then
                    self:moveItems_loop(moveDValue)
                else
                    self:moveItems(moveDValue)
                end 
            end
            
            self.lastMovePos = tmpPos
            
        elseif event.name == "ended" then
            local tmpPos = self:getTouchEndPosition()
            tmpPos = self:convertToNodeSpace(tmpPos)
            
            local rect = self:getChildByTag(0):getBoundingBox()
            if cc.rectContainsPoint(rect, tmpPos) then --self.Tools:containsPoint(rect, tmpPos) then
                if self.beagnTouch and self.beagnTouch:getName() == self:getChildByTag(0):getName() and self.touchCall then
                    self.touchCall(self:getChildByTag(0))
                end
            end
            
            if self.lastMovePos.x ~= 0 then
                self:autoAdjustPos()
            end
            
            self.lastMovePos = {x = 0, y = 0}
            
        elseif event.name == "cancelled" then
            
            if self.lastMovePos.x ~= 0 then
                self:autoAdjustPos()
            end
            
            self.lastMovePos = {x = 0, y = 0}
        end
        
    end  

    self:onTouch(touchTest)
end

function ScrollList:getSideItemCount(selectedIndex)
    local centerNumber = math.ceil(self.maxShowItemCount/2)
    local leftCount_Normal = centerNumber - 1
    local rightCount_Normal = self.maxShowItemCount - centerNumber
    
    local leftItemCount_Now = 0
    local rightItemCount_Now = 0

    if selectedIndex <= leftCount_Normal then
        leftItemCount_Now = selectedIndex - 1
    else
        leftItemCount_Now = leftCount_Normal
    end

    if self.maxItemCount - selectedIndex <= rightCount_Normal then
        rightItemCount_Now = self.maxItemCount - selectedIndex
    else
        rightItemCount_Now = rightCount_Normal
    end
    
    if leftItemCount_Now < leftCount_Normal then
        rightItemCount_Now = rightCount_Normal + (leftCount_Normal - leftItemCount_Now)
    elseif rightItemCount_Now < rightCount_Normal then
        leftItemCount_Now = leftCount_Normal + (rightCount_Normal - rightItemCount_Now)
    end    

    return leftItemCount_Now, rightItemCount_Now
end

function ScrollList:getSideItemCount_loop(selectedIndex)
    local centerNumber = math.ceil(self.maxShowItemCount/2)
    local leftCount_Normal = centerNumber - 1
    local rightCount_Normal = self.maxShowItemCount - centerNumber
    
    local leftItemCount_Now = leftCount_Normal
    local rightItemCount_Now = rightCount_Normal

    return leftItemCount_Now, rightItemCount_Now
end

function ScrollList:initItemPosAndScaleData(centerXPos)
    local function getItemInterval(dvalue)
        local interval = 0

        for i = 1, dvalue do
            interval = interval + self.itemIntervalList[i]
        end

        return interval
    end

    for i = -1 * (self.maxShowItemCount), 0 do --i = -1 * (self.maxShowItemCount-1), 0 do
        self.itemXPosList[i] = centerXPos + (-1 * getItemInterval(i * -1))
        self.itemScaleList[i] = self.normalScale + i*self.scaleDValue
        self.itemSkewList[i] = self.normalScale + i*30
    end

    for i = 1, (self.maxShowItemCount) do --i = 1, (self.maxShowItemCount-1) do
        self.itemXPosList[i] = centerXPos + getItemInterval(i)
        self.itemScaleList[i] = self.normalScale - i*self.scaleDValue
        self.itemSkewList[i] = self.normalScale - i*30
    end   
end

--重设items的位置等参数
function ScrollList:updateItem(selectedIndex)
    
    local leftItemCount_Now = 0
    local rightItemCount_Now = 0
    
    --初始化item
    if self.isloop == true then
        leftItemCount_Now, rightItemCount_Now = self:getSideItemCount_loop(selectedIndex)
    else
        leftItemCount_Now, rightItemCount_Now = self:getSideItemCount(selectedIndex)
    end
    
    --中间item
    local centerItem = self.itemList[selectedIndex]
    centerItem:setPosition(cc.p(self.itemXPosList[0], self.bgSize.height/2))
    centerItem:setScale(self.itemScaleList[0])--(leftItem:getScale() - i*self.scaleDValue)
    --centerItem:getChildByName("Panel_1"):setRotation3D(cc.p(0, 0, 0))
    centerItem:setLocalZOrder(self.maxZOrder)
    centerItem:setVisible(true)
    centerItem:setTag(0)
    self.cutCall(centerItem, "select")
    table.insert(self.showingItemList, centerItem)
    
    for i = 1, self.maxShowItemCount do
        
        local index = 0
        index = selectedIndex - i
        
        if self.isloop == true then
            if index < 1 then
                index = self.maxItemCount + index
            end
        end
        
        local leftItem = self.itemList[index]
        
        if leftItem then
            if i <= leftItemCount_Now then
                leftItem:setPosition(cc.p(self.itemXPosList[-1*i], self.bgSize.height/2))
                leftItem:setScale(self.itemScaleList[-1*i])--(leftItem:getScale() - i*self.scaleDValue)
                --leftItem:getChildByName("Panel_1"):setRotation3D(cc.p(0, self.rotationAngle, 0))
                leftItem:setLocalZOrder(self.maxZOrder - i)
                leftItem:setTag(-1 * i)
                self.cutCall(leftItem, "unSelect")
                table.insert(self.showingItemList, 1, leftItem)

                leftItem:setVisible(true)
            else
                if self.isloop == false then --or index < self.maxItemCount - leftItemCount_Now then
                    leftItem:setVisible(false)
                end
            end
        end
    end

    for i = 1, self.maxShowItemCount do
        
        local index = 0
        index = selectedIndex + i
        
        if self.isloop == true then
            if index > self.maxItemCount then
                index = index - self.maxItemCount
            end
        end
        
        local rightItem = self.itemList[index]
        
        if rightItem then
            
            if i <= rightItemCount_Now then
                
                rightItem:setPosition(cc.p(self.itemXPosList[i], self.bgSize.height/2))
                rightItem:setScale(self.itemScaleList[i]) --(rightItem:getScale() - i*self.scaleDValue)
                --rightItem:getChildByName("Panel_1"):setRotation3D(cc.p(0, -1 * self.rotationAngle, 0))
                rightItem:setLocalZOrder(self.maxZOrder - i)
                rightItem:setTag(i)
                self.cutCall(rightItem, "unSelect")
                table.insert(self.showingItemList, rightItem)

                rightItem:setVisible(true)
            else
                if self.isloop == false then --or index > selectedIndex + rightItemCount_Now then
                    rightItem:setVisible(false)
                end
            end
        end
    end
end

function ScrollList:moveItems(moveDValue)
    local tempDistance = self.moveDistance + moveDValue

    if tempDistance > 0 and tempDistance > self.cutDistance1 then
        moveDValue = self.cutDistance1 - self.moveDistance
        self.moveDistance = self.cutDistance1

    elseif tempDistance < 0 and tempDistance < -1 * self.cutDistance1 then
        moveDValue =  -1 * self.cutDistance1 + math.abs(self.moveDistance)
        self.moveDistance = -1 * self.cutDistance1

    else
        self.moveDistance = self.moveDistance + moveDValue
    end
    
    --重设位置，缩放
    for key, var in ipairs(self.showingItemList) do
        local nowTag = var:getTag()
        local targetTag = nowTag - 1
        
        local xPosDValue = (self.itemXPosList[nowTag] - self.itemXPosList[targetTag])
        local offset_Pos = xPosDValue/self.cutDistance1 * moveDValue
        local offset_Scale = offset_Pos/xPosDValue * self.scaleDValue

        if offset_Pos == 0 then
            return
        end

        local posX = var:getPosition()
        var:setPositionX(posX + offset_Pos)

        local scale = var:getScale()
        if nowTag >0 then
            var:setScale(scale - offset_Scale)
        elseif nowTag == 0 then                      
            --if var:getPositionX() > self.itemXPosList[0] then
            --    var:setScale(scale - offset_Scale)
            --elseif var:getPositionX() < self.itemXPosList[0] then
                var:setScale(scale + offset_Scale)
            --end
        else
            var:setScale(scale + offset_Scale)
        end
    end
    
    --使反向移动边缘item时不产生切换
    if ( self.lastSelectedIndex == 1 and moveDValue > 0 and self.showingItemList[1]:getPositionX() >= self.itemXPosList[0] )
        or ( self.lastSelectedIndex == self.maxItemCount and moveDValue < 0 and self.showingItemList[self.maxShowItemCount]:getPositionX() <= self.itemXPosList[0] ) then
        
        self.needSlideLength = self.moveDistance
    else
    
        if math.abs(self.moveDistance) >= self.cutDistance1 then

            self.showingItemList = {}

            if self.moveDistance > 0 then
                if self.lastSelectedIndex == 1 then
                    return
                end

                self.lastSelectedIndex = self.lastSelectedIndex - 1 
                self:updateItem(self.lastSelectedIndex)
            else
                if self.lastSelectedIndex == self.maxItemCount then
                    return
                end

                self.lastSelectedIndex = self.lastSelectedIndex + 1
                self:updateItem(self.lastSelectedIndex)
            end
            
            self.moveDistance = 0          
        end
    end

end

function ScrollList:moveItems_loop(moveDValue)
    local tempDistance = self.moveDistance + moveDValue

    if tempDistance > 0 and tempDistance > self.cutDistance1 then
        moveDValue = self.cutDistance1 - self.moveDistance
        self.moveDistance = self.cutDistance1

    elseif tempDistance < 0 and tempDistance < -1 * self.cutDistance1 then
        moveDValue =  -1 * self.cutDistance1 + math.abs(self.moveDistance)
        self.moveDistance = -1 * self.cutDistance1

    else
        self.moveDistance = self.moveDistance + moveDValue
    end

    --重设位置，缩放
    for key, var in ipairs(self.showingItemList) do
        local nowTag = var:getTag()
        local targetTag = nowTag - 1
        

        local xPosDValue = (self.itemXPosList[nowTag] - self.itemXPosList[targetTag])
        local offset_Pos = xPosDValue/self.cutDistance1 * moveDValue
        local offset_Scale = offset_Pos/xPosDValue * self.scaleDValue

        if offset_Pos == 0 then
            return
        end

        local posX = var:getPosition()
        var:setPositionX(posX + offset_Pos)

        local scale = var:getScale()
        if nowTag >0 then
            var:setScale(scale - offset_Scale)
        elseif nowTag == 0 then                      
            --if var:getPositionX() > self.itemXPosList[0] then
            --    var:setScale(scale - offset_Scale)
            --elseif var:getPositionX() < self.itemXPosList[0] then
                var:setScale(scale + offset_Scale)
            --end
        else
            var:setScale(scale + offset_Scale)
        end
    end

    if math.abs(self.moveDistance) >= self.cutDistance1 then

        self.showingItemList = {}

        if self.moveDistance > 0 then
            if self.lastSelectedIndex == 1 then
                self.lastSelectedIndex = self.maxItemCount
            else
                self.lastSelectedIndex = self.lastSelectedIndex - 1 
                
            end
        else
            if self.lastSelectedIndex == self.maxItemCount then
                self.lastSelectedIndex = 1
            else
                self.lastSelectedIndex = self.lastSelectedIndex + 1
            end 
        end
        
        self:updateItem(self.lastSelectedIndex)    
        
        self.moveDistance = 0          
    end

end

function ScrollList:autoAdjustPos()
    --自动位置矫正
    if self.moveDistance ~= 0 then
        self.needSlideLength = self.moveDistance
    end

    local function moveItemCountDown(dt)
        local moveLength = dt * self.slideSpeed
        self.tick = self.tick + moveLength
        
        if self.needSlideLength > 0 then
            if self.isloop == true then
                self:moveItems_loop(-1 * moveLength)
            else
                self:moveItems(-1 * moveLength)
            end
        elseif self.needSlideLength < 0 then
            if self.isloop == true then
                self:moveItems_loop(moveLength)
            else
                self:moveItems(moveLength)
            end
        end

        if self.tick > math.abs(self.needSlideLength) then
            cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.tickMoveItem)
            self.tickMoveItem = nil
            self:setLockTouchEvent(false)
            self.tick = 0
        end

    end

    if self.tickMoveItem == nil and self.needSlideLength~= nil then
        self.tickMoveItem = cc.Director:getInstance():getScheduler():scheduleScriptFunc(moveItemCountDown, 0.006, false)
        self:setLockTouchEvent(true)
    end            
end

--滚动到目标card
function ScrollList:moveToTargetCard(targetCardIndex)
    local dvalue = targetCardIndex - self.lastSelectedIndex
    
    if dvalue > 0 then
        self.needSlideLength = 1
    elseif dvalue < 0 then
        self.needSlideLength = -1
    elseif dvalue == 0 then
        return
    end
    
    local function moveItemCountDown(dt)
        local moveLength = dt * 900 --self.slideSpeed
        self.tick = self.tick + moveLength

        if self.needSlideLength > 0 then
            if self.isloop == true then
                self:moveItems_loop(-1 * moveLength)
            else
                self:moveItems(-1 * moveLength)
            end
        elseif self.needSlideLength < 0 then
            if self.isloop == true then
                self:moveItems_loop(moveLength)
            else
                self:moveItems(moveLength)
            end
        end
        
        if self.lastSelectedIndex == targetCardIndex then
            cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.tickMoveItem)
            self.tickMoveItem = nil
            self:setLockTouchEvent(false)
            self.tick = 0
        end
    end

    if self.tickMoveItem == nil and self.needSlideLength~= nil then
        self.tickMoveItem = cc.Director:getInstance():getScheduler():scheduleScriptFunc(moveItemCountDown, 0.006, false)
        self:setLockTouchEvent(true)
    end            
end


--设置是否屏蔽触摸
function ScrollList:setLockTouchEvent(b)
    self.isLockTouchEvent = b
end

--item位置矫正时移动的速度——手指在屏幕的x方向划过的长度/每秒
function ScrollList:setAutoMoveSpeed(speed)
    self.slideSpeed = speed
end

function ScrollList:onCleanup()
    if self.tickMoveItem then
        cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.tickMoveItem)
        self.tickMoveItem = nil
        self:setLockTouchEvent(false)
        self.tick = 0
    end
end

return ScrollList









