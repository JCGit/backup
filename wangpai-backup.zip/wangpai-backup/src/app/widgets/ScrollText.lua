
local ScrollText = class("ScrollText", ccui.Layout)

function ScrollText:ctor(app, name, length, string, path)
    self.app_ = app
    self.name_ = name
    
    self.scrollSpeed = 0.1
    
    self.length = length
    self.number = tonumber(string)

    self.path = path
    
    self.char_size = {}
    self.max_size = cc.size(0,0)
    for var=0, 9 do
        local temp = ccui.TextBMFont:create(var, self.path)
        self.char_size[var] = temp:getContentSize()

        if self.max_size.width < self.char_size[var].width then
            self.max_size.width = self.char_size[var].width
        end

        if self.max_size.height < self.char_size[var].height then
            self.max_size.height = self.char_size[var].height
        end
    end

--    self:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
--    self:setBackGroundColor(cc.c3b(0,0,255))
    self:setAnchorPoint(cc.p(0.5, 0.5))
    self:setContentSize(cc.size(self.max_size.width * self.length,self.max_size.height))
    self:setTouchEnabled(false)

    local panel = ccui.Layout:create()
--    panel:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
--    panel:setBackGroundColor(cc.c3b(255,0,0))
    panel:setPositionType(ccui.PositionType.percent)
    panel:setContentSize(cc.size(self.max_size.width * self.length,self.max_size.height))
    panel:setPositionPercent(cc.p(0,0))
    panel:setClippingEnabled(true)
    panel:setTouchEnabled(false)
    self:addChild(panel)

    self.target = {}
    local item = nil
    for var=1, self.length do
        item = self:createDigit()
        item:setPosition(cc.p(self.max_size.width * (self.length - var),self.max_size.height))
        panel:addChild(item)

        self.target[var] = item
    end

    self:clearString(string)
end

function ScrollText:createDigit()
    local panel = ccui.Layout:create()
--    panel:setBackGroundColorType(ccui.LayoutBackGroundColorType.solid)
--    panel:setBackGroundColor(cc.c3b(0,255,0))
    panel:setLayoutType(ccui.LayoutType.VERTICAL)
    panel:setAnchorPoint(cc.p(0, 1))
    panel:setTouchEnabled(false)

    local centerHorizontal = ccui.LinearLayoutParameter:create()
    centerHorizontal:setGravity(ccui.LinearGravity.centerHorizontal)

    local height = 0
    for var=1, 20 do
        local digit = ccui.TextBMFont:create((var - 1) % 10, self.path)
        height = height + self.char_size[(var - 1) % 10].height
        digit:setAnchorPoint(cc.p(0, 1))
        digit:setLayoutParameter(centerHorizontal)
        panel:addChild(digit)
    end
    panel:setContentSize(cc.size(self.max_size.width,height))

    return panel
end

function ScrollText:setFlyWordEnabled(enable)
    self.flyWordEnabled = enable
end

function ScrollText:setScrollSpeed(interval)
    self.scrollSpeed = interval
end

function ScrollText:setAllScrollEnabled(enable)
    self.allScrollEnabled = enable
end

function ScrollText:setShortFormatEnabled(enable)
    self.shortFormatEnabled = enable
end

function ScrollText:setDisplayLength(length)
    if not self.shortFormatEnabled then
        return
    end

    for key, var in ipairs(self.target) do
        var:setVisible(length >= key)
    end
end

function ScrollText:clearString(string)
    local temp = tonumber(string)

    for key, var in ipairs(self.target) do
        var:setPosition(cc.p(var:getPositionX(), (temp % 10 + 1) * self.max_size.height))
        temp = math.floor(temp / 10)

        var:stopAllActions()
    end

    if self.flyWord then
        self.flyWord:removeFromParent()
        self.flyWord = nil
    end

    self.number = tonumber(string)
    self.whoFinish = nil
    self.scrollFinish = false
end

function ScrollText:setString(string)
    printInfo("[ScrollText:setString]string = %s",string)
    local delta = tonumber(string) - self.number
    if delta == 0 then
    	return
    end
    
    self:clearString(("%%0%dd"):format(self.length):format(self.number))
    self:setDisplayLength(#tostring(string))
    
    self.current_number = self.number
    self.number = tonumber(string)

    self.actionCount = 0

    if delta > 0 then
        self:scrollDigitUp(1, self.current_number, delta)
    else
        self:scrollDigitDown(1, self.current_number, delta)
    end

    if self.flyWordEnabled then
        local popupString = (delta > 0 and "+" .. delta or "-" .. -delta)

        if self.flyWord == nil then
            self.flyWord = ccui.TextBMFont:create("",self.path)
    
            self.flyWord:setAnchorPoint(cc.p(0.5, 0.5))
    
            self:addChild(self.flyWord)
        end
        self.flyWord:setPosition(cc.p(self.max_size.width * self.length / 2, self.max_size.height / 2))
        self.flyWord:setString(popupString)
    
        local move = cc.MoveBy:create(1, cc.p(0,100*(delta > 0 and 1 or -1)))
        local delay = cc.DelayTime:create(0.5)
        local callback = cc.CallFunc:create(function (sender)
            if self.whoFinish == "scroll" then
            else
                self.whoFinish = "flyWord"
            end

            sender:removeFromParent()
            self.flyWord = nil
        end)
    
        self.flyWord:runAction(cc.Sequence:create(move, delay, callback))
    end
end

function ScrollText:scrollDigitUp(begin, number, delta)
    if #self.target < begin then
        self.scrollFinish = true
        
    	return
    end
    
    delta = math.abs(delta)

    local step = delta % 10

    if step == 0 then
        if self.allScrollEnabled then
            step = 10
        else
            self:scrollDigitUp(begin + 1, math.floor(number / 10), math.floor(delta / 10))
    
        	return
        end
    end
    
    local point = cc.p(self.target[begin]:getPosition())
    if point.y > self.max_size.height * 10 then
        self.target[begin]:setPosition(cc.p(point.x, point.y - self.max_size.height * 10))
    end

    local from = number % 10
    
    local action = {}
    
    local temp = nil

    if from + step < 10 then
        temp = cc.MoveBy:create(step * self.scrollSpeed, cc.p(0, step * self.max_size.height))
        table.insert(action,temp)
    else
        temp = cc.MoveBy:create((10 - from) * self.scrollSpeed, cc.p(0, (10 - from) * self.max_size.height))
        table.insert(action,temp)

        self.high_number = ((from + delta % 10) >= 10) and 1 or nil
        if not self.allScrollEnabled then
            temp = function (sender)
                self:scrollDigitUp(begin + 1, math.floor(number / 10), 1)
            end
            table.insert(action,cc.CallFunc:create(temp))
        end

        temp = cc.MoveBy:create((step - (10 - from)) * self.scrollSpeed, cc.p(0, (step - (10 - from)) * self.max_size.height))
        table.insert(action,temp)
    end

    temp = function (sender)
        self.actionCount = self.actionCount - 1

--        self.current_number = number
        if self.allScrollEnabled and begin < #tostring(self.number) or begin < #tostring(math.abs(delta)) then
            self:scrollDigitUp(begin + 1, math.floor(number / 10), math.floor(delta / 10 + (self.high_number or 0)))
        elseif self.actionCount == 0 then
            if self.whoFinish == "flyWord" then
            else
                self.whoFinish = "scroll"
            end
        end
        
        self.high_number = nil
    end
    table.insert(action,cc.CallFunc:create(temp))

    self.actionCount = self.actionCount + 1
    self.target[begin]:runAction(cc.Sequence:create(action))
end

function ScrollText:scrollDigitDown(begin, number, delta)
    if #self.target < begin then
        self:setDisplayLength(#tostring(self.number))

        self.scrollFinish = true

        return
    end

    delta = math.abs(delta)

    local step = delta % 10

    if step == 0 then
        if self.allScrollEnabled then
            step = 10
        else
            self:scrollDigitDown(begin + 1, math.floor(number / 10), math.floor(delta / 10))
    
            return
        end
    end

    local point = cc.p(self.target[begin]:getPosition())
    if point.y <= self.max_size.height * 10 then
        self.target[begin]:setPosition(cc.p(point.x, point.y + self.max_size.height * 10))
    end

    local from = number % 10

    local action = {}

    local temp = nil

    if from - step >= 0 then
        temp = cc.MoveBy:create(step * self.scrollSpeed, cc.p(0, -step * self.max_size.height))
        table.insert(action,temp)
    else
        temp = cc.MoveBy:create(from * self.scrollSpeed, cc.p(0, -from * self.max_size.height))
        table.insert(action,temp)

        self.high_number = ((from - delta % 10) < 0) and -1 or nil
        if not self.allScrollEnabled then
            temp = function (sender)
                self:scrollDigitDown(begin + 1, math.floor(number / 10), 1)
            end
            table.insert(action,cc.CallFunc:create(temp))
        end

        temp = cc.MoveBy:create((step - from) * self.scrollSpeed, cc.p(0, -(step - from) * self.max_size.height))
        table.insert(action,temp)
    end

    temp = function (sender)
        self.actionCount = self.actionCount - 1

        if self.allScrollEnabled and begin < #tostring(self.number) or begin < #tostring(math.abs(delta)) then
            self:scrollDigitDown(begin + 1, math.floor(number / 10), math.floor(delta / 10 + (self.high_number or 0)))
        elseif self.actionCount == 0 then
            if self.whoFinish == "flyWord" then
            else
                self.whoFinish = "scroll"
            end
        end

        self.high_number = nil
    end
    table.insert(action,cc.CallFunc:create(temp))

    self.actionCount = self.actionCount + 1
    self.target[begin]:runAction(cc.Sequence:create(action))
end

return ScrollText

