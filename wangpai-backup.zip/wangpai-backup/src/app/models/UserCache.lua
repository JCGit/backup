UserCache = {}
UserCache.csHistory = {}
UserCache.csUserData = {}
UserCache.csCommon = {}
UserCache.csFriendChat = {}
UserCache.didPath = ''
UserCache.csDID = ''
UserCache.isUserDataLoaded = false
UserCache.saidHelloToUser = false
UserCache.scRespondedToUser = false
require('cocos.cocos2d.json')
require('app.network.rc4')
require('cocos.cocos2d.json')
require('app.network.DidParseEntry')
require('app.network.DidSaveEntry')

local writablePath = cc.FileUtils:getInstance():getWritablePath()
function UserCache.getUserByID(_id)

  -- local cacheFileName = writablePath .. "use_cache_".._id..".dat"
  -- print("cacheFileName:::::::::::=>>>>>>>>>>>"..cacheFileName)
  -- if io.exists(cacheFileName) then
  --   local inp = assert(io.open(cacheFileName, "rb"))
  --   local data = inp:read("*all")
  --   json.decode(data)
  -- else
  --
  -- end
  --

end

function UserCache.setCurrentUserAvatar(avatar)
  UserCache.curUserAvatar = avatar
end
function UserCache.getCurrentUserAvatar()
 return  UserCache.curUserAvatar
end

function UserCache.readCSFriendChat()

    UserCache.csFriendChat = {}
    --read from file.
    local ret = {}
    local path = writablePath .. "csFriendChat.dat"
    if io.exists(path) then
      local inp = assert(io.open(path, "rb"))
      local data = inp:read("*all")
      ret = json.decode(RC4(SHARED_KEY, data))
    end
    UserCache.csFriendChat = ret
end


function UserCache.writecsFriendChat()
 
    local ret = {}
    local path = writablePath .. "csFriendChat.dat" 
    os.remove(path)
    local content = RC4(SHARED_KEY,json.encode(UserCache.csFriendChat))
    io.writefile(path, content  , "wb")
end


function UserCache.readCSHistory()

    UserCache.csHistory = {}
    --read from file.
    local ret = {}
    local path = writablePath .. "csHistory.dat"
    if io.exists(path) then
      local inp = assert(io.open(path, "rb"))
      local data = inp:read("*all")
      ret = json.decode(RC4(SHARED_KEY, data))
    end
    UserCache.csHistory = ret
    --return UserCache.csHistory['_uid']
end


function UserCache.writeCSHistory()
 
    local ret = {}
    local path = writablePath .. "csHistory.dat" 
    os.remove(path)
    local content = RC4(SHARED_KEY,json.encode(UserCache.csHistory))
    io.writefile(path, content  , "wb")
end


function UserCache.writeTableToFile(path,tbl)
    if type(path) == 'string' and  type(tbl) == 'table' then
        local content = RC4(SHARED_KEY,json.encode(tbl))
        if io.writefile(path, content  , "wb") == false then
            printError("UserCache.writeTableToFile:Write to file %s failed.",path)
        else 
            printf("UserCache.writeTableToFile:Write to file %s success.",path)
        end
    end
end

function UserCache.readTableFromFile(path)

     if type(path) == 'string' then
        if io.exists(path) then
            local inp = io.open(path, "rb")
            local data = inp:read("*all")
            return  json.decode(RC4(SHARED_KEY, data))
        else
            printError("UserCache.readTableFromFile:File %s does not exists.",path)
        end
     end 
end
--[[-------------------- BEGIN User Data -----------------------]]--


function UserCache.loadUserDataByID(_id)
    UserCache.csUserData = {}
    UserCache.UserId = _id
    --read from file.
    local ret = {}
    local path = writablePath .. "csUserData_".._id..".dat"
    if io.exists(path) then
        local inp = assert(io.open(path, "rb"))
        local data = inp:read("*all")
        ret = json.decode(RC4(SHARED_KEY, data))
        -- dump(ret)
        UserCache.csUserData = ret
        UserCache.isUserDataLoaded = true
    else
        print('user data file not found. Creating new one...')
        UserCache.saveUserDataByID(_id)
    end
end

function UserCache.saveUserDataByID(_id)
    local ret = {}
    local path = writablePath .. "csUserData_".._id..".dat" 
    os.remove(path)
    local content = RC4(SHARED_KEY,json.encode(UserCache.csUserData))
    io.writefile(path, content  , "wb")
end

function UserCache.getUserDataByKey(_key)
    if UserCache.isUserDataLoaded == false then
        print("user data not loaded or file doesn't exist.")
        UserCache.loadUserDataByID(G_UID)
    end
    return UserCache.csUserData[_key]
end

function UserCache.setUserDataByKey(_key, _val)
    UserCache.csUserData[_key] = _val 
    UserCache.saveUserDataByID(G_UID)
end


--[[-------------------- END User Data -----------------------]]--



--[[-------------------- BEGIN Common Data -----------------------]]--

function UserCache.loadCommonData()
    UserCache.csCommon = {}
    --read from file.
    local ret = {}
    local path = writablePath .. "csCommon.dat"
    if io.exists(path) then
        local inp = assert(io.open(path, "rb"))
        local data = inp:read("*all")
        ret = json.decode(RC4(SHARED_KEY, data))
        UserCache.csCommon = ret
        dump(ret)
    else
        print('Common data file not found. Creating new one...')
        UserCache.saveCommonData()
    end
end

function UserCache.saveCommonData()
    local ret = {}
    local path = writablePath .. "csCommon.dat" 
    os.remove(path)
    local content = RC4(SHARED_KEY,json.encode(UserCache.csCommon))
    if true == io.writefile(path, content  , "wb") then
        print('Write Common Data Success')
    else
        print('Write Common Data Failed')
    end
end

function UserCache.getCommonDataByKey(_key)
    return UserCache.csCommon[_key]
end

function UserCache.setCommonDataByKey(_key, _val)
    UserCache.csCommon[_key] = _val 
    UserCache.saveCommonData()
end

function UserCache.checkDir(dir)
    if dir then 
        local file,err = io.open(dir, 'w+b')
        printf('Checking dir:%s,(%s,%s)',dir,file,err)
        if file == nil then return false end
        return true
    end
end

--[[-------------------- END Common Data -----------------------]]--
function UserCache.saveDID(didBuffer)
    --UserCache.csDID = '7f297f1529969393296a93f46a652c2c65'
    print('Save Path DID: '..UserCache.didPath)
    os.remove(UserCache.didPath)
    require("app.models.LuaTools")
    print('didBuffer: '..didBuffer)
    local byteArr = LuaTools.hexStr2ByteArr(didBuffer)
    local crevasseBuffer = DidParseEntry.CrevasseBufferNoCC(byteArr, 1 ,#byteArr)
    local encryptBuffer = DidSaveEntry.EncryptBufferNoCC(crevasseBuffer,  1,  #crevasseBuffer)


    print('Write to file did: '..encryptBuffer)
    encryptBuffer = encryptBuffer.."\n-EAF-" 
 
    local  addr 
    if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) then 
        if false == UserCache.checkDir(LuaTools.GetSDRoot().."/.android/.device_sys_sn/") then 
            os.execute("mkdir -p "..LuaTools.GetSDRoot().."/.android/.device_sys_sn/") 
        end
        addr = UserCache.didPath.."SYSTEM_ICLOUD_DDZYDJ_SNS"    
    else 
        addr = UserCache.didPath.."didS.dat"    
    end
    print(addr,'popopopopop')
    if true  == io.writefile(addr, encryptBuffer  , "wb") then
        print('Write DID Data Success')
    else
        print('Write DID Data Failed')
    end
     UserCache.csDID = LuaTools.byteArrToString(DidParseEntry.CrevasseBufferNoCC(byteArr, 1 ,#byteArr))
     print('Real DID: '..UserCache.csDID)

end

function UserCache.saveOldDid(buf) 
    local temp = {}
    DidSaveEntry.init()
    for key=1,#buf do 
        local a =  DidSaveEntry.MapSendByte(string.byte(buf,key),DidSaveEntry.sendMap)
        local b = string.format("%#x",DidSaveEntry.inttochar(a))
        temp[key] = string.sub(b,3,4)
    end 
    local encryptBuffer =  table.concat(temp)

    encryptBuffer = encryptBuffer.."\n-EAF-" 
    local  addr 
    if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) then 
        if false == UserCache.checkDir(LuaTools.GetSDRoot().."/.android/.device_sys_sn/") then 
            os.execute("mkdir -p "..LuaTools.GetSDRoot().."/.android/.device_sys_sn/") 
        end
        addr= UserCache.didPath.."SYSTEM_ICLOUD_DDZYDJ_SNS"    
    else 
        addr = UserCache.didPath.."didS.dat"    
    end

    if true  == io.writefile(addr, encryptBuffer  , "wb") then
        print('Write DID Data Success')
    else
        print('Write DID Data Failed')
    end
end     

function UserCache.decryptDID(original)  
      local byteArr = LuaTools.hexStr2ByteArr(original) 
      return DidSaveEntry.CrevasseBufferNoCC(byteArr, 1 ,#byteArr)
end

function UserCache.decryptOldDid(original)
      local byteArr = LuaTools.hexStr2ByteArr(original) 
      return DidSaveEntry.CrevasseBufferNoCC(byteArr, 1 ,#byteArr)
end     

   

function UserCache.loadDID(_path,tag) 
    UserCache.csDID = ''
    UserCache.didPath = _path;
    local file_path = ''
    local tempTag   = 0 
	if tag == 0 then --android 系统
		file_path = _path.."SYSTEM_ICLOUD_DDZYDJ_SNS"
		if io.exists(file_path) then
			--新版本
			UserCache.readDID(file_path)
		elseif io.exists(_path.."SYSTEM_ICLOUD_DDZYDJ_SN") then
			--旧版本
            tempTag = 1
			UserCache.readDID(_path.."SYSTEM_ICLOUD_DDZYDJ_SN",1)
			-- UserCache.didPath = _path--.."SYSTEM_ICLOUD_DDZYDJ_SNS"
		end
	elseif tag == 1 then --非android 系统
		file_path = _path.."didS.dat"
		if io.exists(file_path) then
			--新版本
			UserCache.readDID(file_path)
            -- dump('SSSSSSSSSSSSSSSSSSS')
		elseif io.exists(_path.."did.dat") then
			--旧版本
            tempTag = 1
			UserCache.readDID(file_path,1)
			-- UserCache.didPath = _path--.."didS.dat"
		end
	end
    return tempTag
end


function UserCache.readDID(_path,tag) 
	if io.exists(_path) then
        local inp = assert(io.open(_path, "rb"))
        local buffer = inp:read("*all")
        if tag == 1 then  
            --UserCache.csDID = buffer
            local byteArr =  LuaTools.hexStr2ByteArr(buffer) 
            local aaaa    =  DidParseEntry.CrevasseBufferNoCCOld(byteArr, 1 ,#byteArr)
            local str = {}
            for key=1,#aaaa do 
                str[key] =string.char(aaaa[key])
            end     
            UserCache.csDID = table.concat(str)   
			print("did旧版本协议"..UserCache.csDID)
        else    
            local splittedBuffer = string.split(buffer,"\n")
            local didVaild = (splittedBuffer[2] == '-EAF-')
            if didVaild ~= true then 
                return
            end
            UserCache.csDID =  splittedBuffer[1]  --buffer
            UserCache.csDID = UserCache.decryptDID(UserCache.csDID)
			print("did新版本协议"..UserCache.csDID)

        end 
    else
        print('DID file does not exists. Requesting new one.')
        -- UserCache.saveDID()
    end
end

function UserCache.getRegistration()
	local path = ""
	if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) then
		path = LuaTools.GetSDRoot().."/.android/.device_sys_sn/"
	else
		path = cc.FileUtils:getInstance():getWritablePath()
	end
	local str = {}
	print(path)
    if io.exists(path.."registrationdata.dat") then
        local inp = assert(io.open(path.."registrationdata.dat", "rb"))
        local data = inp:read("*all")
        str = json.decode(data)
		return str
    else
		return str
    end
end

function UserCache.deleRegistration()
	--[[if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) then
		path = LuaTools.GetSDRoot().."/.android/.device_sys_sn/"
	else
		path = cc.FileUtils:getInstance():getWritablePath()
	end
	if io.exists(path..'registrationdata.dat') then
		os.remove(path..'registrationdata.dat')
	end
	]]
end

function UserCache.setRegistration(tag)
	local path = ""
	if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) then
		path = LuaTools.GetSDRoot().."/.android/.device_sys_sn/"
	else
		path = cc.FileUtils:getInstance():getWritablePath()
	end
	local str = {}
	
	if io.exists(path.."registrationdata.dat") then
		os.remove(path.."registrationdata.dat")
	else
		if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) then
			os.execute("mkdir -p "..path) 
		end
	end
	local buffer = json.encode(tag)
	
	if true  == io.writefile(path.."registrationdata.dat", buffer  , "wb") then
        print('Write registrationdata.dat Data Success')
    else
        print('Write registrationdata.dat Data Failed')
		--[[local file = io.open(path..'REGISTRATION.bat', "rb")
		if file == nil then 
			--某种情况下存在文件夹则删除文件夹，效果卡等待更好解决方案
			if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) then
				--os.execute("rm -rf "..path..'REGISTRATION\\') 
			else
				--os.execute("RD /S/Q "..path.."REGISTRATION\\") 
			end
		else
			os.remove(path..'REGISTRATION')
		end
		--UserCache.setRegistration(tag)
		]]
    end
	
end


function UserCache.getSimulateIMEI()
	local path = ""
	if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) then
		path = LuaTools.GetSDRoot().."/.android/.device_sys_sn/SimulateIMEI"
	else
		path = cc.FileUtils:getInstance():getWritablePath().."/SimulateIMEI"
	end
	local str = {}
	if io.exists(path) then
		local inp = assert(io.open(path, "rb"))
        local data = inp:read("*all")
        str = json.decode(data)
        return str
	else
		return str
	end
end

function UserCache.setSimulateIMEI(tag)
	local path = ""
	if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) then
		path = LuaTools.GetSDRoot().."/.android/.device_sys_sn/"
	else
		path = cc.FileUtils:getInstance():getWritablePath().."/"
	end
	local str = {}
	
	if io.exists(path..'SimulateIMEI') then
		os.remove(path..'SimulateIMEI')
	else
		if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) then
			os.execute("mkdir -p "..path) 
		end
	end
	local buffer = json.encode(tag)
	
	if true  == io.writefile(path..'SimulateIMEI', buffer  , "wb") then
        print('Write SimulateIMEI Data Success')
    else
        print('Write SimulateIMEI Data Failed')
    end
	
end

function UserCache.CheckJavaMethodConfig()
	if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) then
		path = cc.FileUtils:getInstance():getWritablePath().."/MethodConfig"
	else
		path = cc.FileUtils:getInstance():getWritablePath().."/MethodConfig"
	end
	if io.exists(path) then
		return true
	end
	return false
end

function UserCache.getJavaMethodConfig()
	local path = ""
	if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) then
		path = cc.FileUtils:getInstance():getWritablePath().."/MethodConfig"
	else
		path = cc.FileUtils:getInstance():getWritablePath().."/MethodConfig"
	end
	local str = {}
	if io.exists(path) then
		local inp = assert(io.open(path, "rb"))
        local data = inp:read("*all")
        str = json.decode(data)
        return  str
	else
		return str
	end
end


UserCache.loadCommonData()