Cardutl = {}
local bit = require"bit" 
require("app.models.Laiziutl")
require("app.models.CardHints")

Cardutl.TYPE_CARD_ERROR = "TYPE_CARD_ERROR"
Cardutl.TYPE_SINGLE = "TYPE_SINGLE"
Cardutl.TYPE_BOMB_KING = "TYPE_BOMB_KING"
Cardutl.TYPE_DOUBLE = "TYPE_DOUBLE"
Cardutl.TYPE_THREE_0 = "TYPE_THREE_0"

Cardutl.TYPE_BOMB_4 = "TYPE_BOMB_4"
Cardutl.TYPE_THREE_1 = "TYPE_THREE_1"
Cardutl.TYPE_STRAIGHT = "TYPE_STRAIGHT"
Cardutl.TYPE_THREE_2 = "TYPE_THREE_2"

Cardutl.TYPE_FOUR_1 = "TYPE_FOUR_1"
Cardutl.TYPE_STRAIGHT = "TYPE_STRAIGHT"
Cardutl.TYPE_DOUBLES = "TYPE_DOUBLES"
Cardutl.TYPE_PLANE_0 = "TYPE_PLANE_0"

Cardutl.TYPE_FOUR_2 = "TYPE_FOUR_2"
Cardutl.TYPE_PLANE_1 = "TYPE_PLANE_1"   
Cardutl.TYPE_PLANE_2 = "TYPE_PLANE_2"  
Cardutl.TypeConvert = 
{
	[0x00] = 	'TYPE_CARD_ERROR', 	--牌型错误
	[0x01] = 	'TYPE_SINGLE',   	--单张 						Woman_
	[0x02] = 	'TYPE_DOUBLE',   	--对子 						Woman_dui
	[0x03] = 	'TYPE_THREE_0',  	--三张不带					Woman_sange.mp3
	[0x04] = 	'TYPE_THREE_1',  	--三张带一张				Woman_sandaiyi
	[0x05] = 	'TYPE_THREE_2',  	--三张带一对				Woman_sandaiyidui
	[0x06] = 	'TYPE_STRAIGHT',  	--顺子						Woman_shunzi
	[0x07] = 	'TYPE_DOUBLES',  	--连对						Woman_liandui
	[0x08] = 	'TYPE_PLANE_0',  	--飞机（333,444）			Woman_feiji
	[0x09] = 	'TYPE_PLANE_1',  	--飞机带一张（333,444,5，6） 	Woman_feiji
	[0x0A] = 	'TYPE_PLANE_2',  	--飞机带一对（333,444,55，66） 	Woman_feiji
	[0x0B] = 	'TYPE_FOUR_1',   	--四带一张					Woman_sidaier
	[0x0C] = 	'TYPE_FOUR_2',   	--四带二					Woman_sidaier
	[0x0D] = 	'TYPE_BOMB_4',   	--炸弹 						Woman_zhadan
	[0x0E] =	'TYPE_BOMB_KING', 	--火箭 						Woman_wangzha
}
	


Cardutl.CARD_SWT_TYPE = 0x5
Cardutl.CARD_KING_TYPE = 0x0

Cardutl.CARD_KING_B = 0x02;
Cardutl.CARD_KING_S = 0x01;
Cardutl.CARD_SWT = 0x50;

Cardutl.CardResourceTable = 
{
	--[[valueConvertTable = {
		[0xE] = 1,
		[0xF] = 2,
	},]]
	--原花色，错误
 --     typeTable = { 
 --        [0] = "king",
 --        [1] = "hearts",
 --        [2] = "spades",
 --        [3] = "diamonds", 
 --        [4] = "clubs",
 --        [5] = "flower",
	-- }
	--更改成新的，正确
	typeTable = { 
        [0] = "king",
        [1] = "diamonds", 
        [2] = "clubs",
        [3] = "hearts",
        [4] = "spades",
        [5] = "flower",
	}
}

--获得牌型，单张，对子，三张等
function Cardutl.getOriginalCardType( str )
 	for k,v in pairs(Cardutl.TypeConvert) do
 		if str == v then 
 			return k 
 		end
 	end
end 

function Cardutl.getDouniuCardPath(value)


end 	

function Cardutl.getPathForCard( card , isMini,checkLaizi,mode)
	local cardType = Cardutl.GetCardType(card)
	local cardValue = Cardutl.GetCardValue(card,mode )  

	local prefix = ""
	local suffix = ".png"
	if isMini then prefix="jx_" end

	local basePath = "newcard/"..prefix
	
	if card == 0 then 
		return basePath.."back"..suffix 
	end 
	if cardType == 0x5 then
		if checkLaizi then
			local blah = Cardutl.CardResourceTable.typeTable[math.random(1,4)]    
			if cardValue == 1 then   
				blah = "king"
			elseif cardValue ==2 then    
				blah = "king"
			elseif cardValue == 0 then --should not happen.
				return basePath.."flower"..suffix 
			end  
			return basePath..blah.."_"..cardValue..suffix,true  
		else
			return basePath.."flower"..suffix 
		end 
	end
	return basePath..Cardutl.CardResourceTable.typeTable[cardType].."_"..cardValue..suffix
	
end

--获取牌的value*/
function Cardutl.GetCardValue(card,mode )  
	local cardValue = bit.band(card,0x0F)--card & 0x0F
	if mode and mode == "Douniu" then
		if cardValue <= 2 then
			cardValue = cardValue + 13
		end 
	end

	return cardValue

end 

--获取牌的type*/花色
function Cardutl.GetCardType(card )   

	return bit.rshift(card , 4) --card >> 4
end

--拼牌值
function Cardutl.GetCardByTV(typeType , typeValue )  
	return  bit.bor(bit.lshift(typeType , 4),typeValue) --(typeType<<4) | typeValue
end  

--从小到大排列**/
function Cardutl.SortS2B(array)    
	for i=1,#array do  
		local j = 2
		while  (j < (#array)-i-1)   do 
			if array[j] > array[j+1] then
				array[j], array[j+1] = array[j+1], array[j]
			end 
			j=j+1
		end
	end
	return array
end


--从大到小排列**/ ---????
function Cardutl.SortB2S(array )   
	return Cardutl.SortS2B(array)   
 	-- for i := 0; i < len(array); i++ {
	-- 	for j := 0; j < len(array)-i-1; j++ {
	-- 		if array[j] > array[j+1] {
	-- 			array[j], array[j+1] = array[j+1], array[j]
	-- 		}
	-- 	}
	-- }
	-- return array
end

--洗牌*/ 
function Cardutl.ShuffleCards(cards ) 
	local t = 75 + math.random(1,31)
	for i=1,t do
		local r1 = math.random(1,56)
		local r2 = math.random(1,56)
		if r1 ~= r2 then
			cards[r1], cards[r2] = cards[r2], cards[r1]
		end

	end 
end

 
--私人房间洗牌*/
function Cardutl.ShufflePriRoomCards(cards )  
	local t = 50 + math.random(1,51)
	for i=1,t do
		local r1 = math.random(1,56)
		local r2 = math.random(1,56)
		if r1 ~= r2 then
			cards[r1], cards[r2] = cards[r2], cards[r1]
		end
	end 
end

--从大到小排列 start
 
function Cardutl.Less(lhs, rhs )  
	local flag = true
 
	local l_type =  Cardutl.GetCardType(lhs)
	local l_value  =  Cardutl.GetCardValue(lhs)

	local r_type =  Cardutl.GetCardType(rhs)
	local r_value =  Cardutl.GetCardValue(rhs)

	if  l_type == 0 then
		l_value =  l_value + 0x0F
	end

	if  r_type == 0 then
		r_value =  r_value + 0x0F
	end 
	if lhs == 0x50 or rhs == 0x50 then
		if  lhs == 0x50 then
			flag = true
		end
		if  rhs == 0x50 then
			flag = false
		end
	else
		if  l_value ~= r_value then
			flag = l_value > r_value
		else  
			flag = l_type > r_type
		end
	end 
	return flag
end

 
--从大到小排列 start

--从大到小,从多到少
function Cardutl.SortOutCards(outs)   

 	-- dump(outs,"start")
	table.sort( outs, Cardutl.Less)  
 	-- dump(outs,"before Num2Seq")
	Cardutl.Num2Seq(outs)  
 	-- dump(outs," after Num2Seq")
	local oLen = #outs
	if oLen == 10 then
		if Cardutl.GetCardValue(outs[1]) == Cardutl.GetCardValue(outs[4]) and Cardutl.GetCardValue(outs[5]) == Cardutl.GetCardValue(outs[7]) and Cardutl.GetCardValue(outs[8]) == Cardutl.GetCardValue(outs[10]) then
			local tmp = table.slice(outs,5,oLen) --outs[4:oLen] 
			tmp = table.appendArray(tmp,table.slice(outs,1,5)) --append(tmp, outs[0:4]...)
			for i=1,#tmp do
				outs[i] = tmp[i]
			end 
		end
	end

 	-- dump(outs," after for loop")
end

--由多到少 **/
function Cardutl.Num2Seq(outs )  
	local single = 1
	local oLen = #outs

	-- print("before loop single:",single)
	for i=1,oLen do
		-- print("i:",i)
		-- print("i:",i)
		if (i < oLen and Cardutl.GetCardValue(outs[i]) ~= Cardutl.GetCardValue(outs[i+1])) then
			single=single+1
		end
	end
	-- print("after loop single:",single)
	-- print("single:",single)
 -- 	print("oLen:",oLen)
	local num  = table.make(single)
	local value  = table.make(single)
	local nTmp = 1
	-- print("entering for loop")
	for i=1,oLen do 
		if (i < oLen and Cardutl.GetCardValue(outs[i]) ~= Cardutl.GetCardValue(outs[i+1])) then 
			-- print("if (i < oLen-1 and Cardutl.GetCardValue(outs[i]) ~= Cardutl.GetCardValue(outs[i+1])) then")
			value[nTmp] = Cardutl.GetCardValue(outs[i]) 
			-- printf("value[%s] = Cardutl.GetCardValue(outs[%d]) = %s",nTmp,i, Cardutl.GetCardValue(outs[i]))
			num[nTmp]=num[nTmp]+1;
			-- printf("num[%s] = %s",nTmp,num[nTmp])
			nTmp=nTmp+1  
			-- printf("nTmp = %s",nTmp)
		else   
			-- print("else")
			num[nTmp]=num[nTmp]+1;
			-- printf("num[%s] = %s",nTmp,num[nTmp])
		end
		if (i == oLen) then
			-- print("(i == oLen-1)")
			value[nTmp] = outs[i]; 
			-- printf("value[%s] = outs[%s] = %s",nTmp,i,outs[i])
		end
	end  
	-- print("single:",single)
	-- dump(num,"num")
	-- dump(value,"value")
	Cardutl.InsertSort(num, value);  
	local tmpArr  = {} 
	tmpArr = table.appendArray(tmpArr, outs) 
	-- dump(outs,"before outs")
	local tmp = 1;
	for i=1,single do
		for k,tmpV in pairs(tmpArr) do
			-- print("=================================")
			-- print("tmpV:",tmpV)
			-- print("Cardutl.GetCardValue(tmpV):",Cardutl.GetCardValue(tmpV))
			-- print("i:",i)
			-- print("value[i]:",value[i])
			-- print("Cardutl.GetCardValue(value[i]):",Cardutl.GetCardValue(value[i])) 
			-- print("tmp:",tmp)
			if (Cardutl.GetCardValue(tmpV) == Cardutl.GetCardValue(value[i])) then
				if (tmp > oLen) then
					return
				end
				outs[tmp] = tmpV
				tmp=tmp+1
			end
		end
	end 
	 
end

function Cardutl.SortHandCards(cards)  
	table.sort( cards, Cardutl.Less)  
end


 


 
function Cardutl.InsertSort(num  , value )  
	local nLen  = #num 
	for i=2,nLen do 
		for j=i,2,-1 do 
			if (num[j] > num[j-1]) then
				num[j], num[j-1] = num[j-1], num[j]
				value[j], value[j-1] = value[j-1], value[j]
			else  
				break
			end
		end 
	end 
end

--获得牌型
function Cardutl.getCardAssamblyType(cards)
	local vals = {}
	for i=1,#cards do  
		vals[i] = Cardutl.GetCardValue(cards[i]);
	end
	return  Cardutl.CheckOutCardType(cards, vals )
end


function Cardutl.CheckOutCardType(cards, cValues )   
	local cardType  = Cardutl.TYPE_CARD_ERROR
	if (cards ~= nil) then
		local case = #cards 
		if  case == 1 then-- 单张
			local v0Type = Cardutl.GetCardType(cards[1])
			if ( v0Type >= 0 and v0Type < 5) then
				cardType = Cardutl.TYPE_SINGLE
			end
		elseif case == 2 then -- 对子 - 王炸弹
			local v0Type  = Cardutl.GetCardType(cards[1])
			local v0Value  = Cardutl.GetCardValue(cards[1])
			local v1Type  = Cardutl.GetCardType(cards[2])
			local v1Value  = Cardutl.GetCardValue(cards[2])

			if ((v0Type ==  Cardutl.CARD_KING_TYPE or v0Type ==  Cardutl.CARD_SWT_TYPE) and (v1Type ==  Cardutl.CARD_KING_TYPE or v1Type ==  Cardutl.CARD_SWT_TYPE)) then
				cardType = Cardutl.TYPE_BOMB_KING
			elseif (v0Value == v1Value) then
				cardType = Cardutl.TYPE_DOUBLE
			end
		elseif case == 3 then --case 3:-- 三张不带
			local v0Value  = Cardutl.GetCardValue(cards[1])
			local v1Value  = Cardutl.GetCardValue(cards[2])
			local v2Value  = Cardutl.GetCardValue(cards[3])
			if (v0Value == v1Value and v0Value == v2Value) then
				cardType = Cardutl.TYPE_THREE_0
			end
		elseif case == 4 then--case 4:-- 四张炸弹 - 三带一
			local v0Value = Cardutl.GetCardValue(cards[1])
			local v1Value = Cardutl.GetCardValue(cards[2])
			local v2Value = Cardutl.GetCardValue(cards[3])
			local v3Value = Cardutl.GetCardValue(cards[4])
			if (v0Value == v1Value and v0Value == v2Value and v0Value == v3Value) then
				cardType = Cardutl.TYPE_BOMB_4
			elseif (v0Value == v1Value and v0Value == v2Value and v0Value ~= v3Value) then
				cardType = Cardutl.TYPE_THREE_1
			end
		elseif case == 5 then--case 5:-- 三带二 - 顺子
			local v0Value  = Cardutl.GetCardValue(cards[1])
			local v1Value  = Cardutl.GetCardValue(cards[2])
			local v2Value  = Cardutl.GetCardValue(cards[3])
			local v3Value  = Cardutl.GetCardValue(cards[4])
			local v4Value  = Cardutl.GetCardValue(cards[5])
			if (Cardutl.CheckStraight(cValues)) then
				cardType = Cardutl.TYPE_STRAIGHT
			elseif (v0Value == v1Value and v0Value == v2Value and v3Value == v4Value) then
				cardType = Cardutl.TYPE_THREE_2
			end
		elseif case == 6 then--case 6:-- 连对 - 顺子 - 飞机不带
			print('case == 6 ')
			 if(Cardutl.checkFour(cValues,1)) then 
				cardType = Cardutl.TYPE_FOUR_1
			 elseif (Cardutl.CheckStraight(cValues)) then
				cardType = Cardutl.TYPE_STRAIGHT
			  elseif (Cardutl.checkDoubles(cValues))then
				cardType = Cardutl.TYPE_DOUBLES
			  elseif (Cardutl.checkPlane(cValues, 2, 0))then 
				
				cardType = Cardutl.TYPE_PLANE_0
			end
		elseif case == 7 then--case 7:-- 顺子
			if (Cardutl.CheckStraight(cValues)) then
				cardType = Cardutl.TYPE_STRAIGHT
			end
		elseif case == 8 then--case 8:-- 顺子 - 连对 - 2飞机带单
			if(Cardutl.checkFour(cValues,2)) then
				cardType = Cardutl.TYPE_FOUR_2
			elseif (Cardutl.CheckStraight(cValues))then
				cardType = Cardutl.TYPE_STRAIGHT
			 elseif (Cardutl.checkDoubles(cValues))then
				cardType = Cardutl.TYPE_DOUBLES
			 elseif (Cardutl.checkPlane(cValues, 2, 1))then
				cardType = Cardutl.TYPE_PLANE_1
			end
		elseif case == 9 then--case 9:-- 飞机不带 - 顺子
			if (Cardutl.CheckStraight(cValues))then
				cardType = Cardutl.TYPE_STRAIGHT
			 elseif (Cardutl.checkPlane(cValues, 3, 0))then
				cardType = Cardutl.TYPE_PLANE_0
			end
		elseif case == 10 then--case 10:-- 连对 - 2飞机带对 -顺子
			if (Cardutl.CheckStraight(cValues))then
				cardType = Cardutl.TYPE_STRAIGHT
			  elseif (Cardutl.checkDoubles(cValues))then
				cardType = Cardutl.TYPE_DOUBLES
			  elseif (Cardutl.checkPlane(cValues, 2, 2))then
				cardType = Cardutl.TYPE_PLANE_2
			end
		elseif case == 11 then--case 11:-- 顺子
			if (Cardutl.CheckStraight(cValues))then
				cardType = Cardutl.TYPE_STRAIGHT
			end
		elseif case == 12 then--case 12:-- 最长顺子 - 连对 - 3飞机带单 - 4飞机不带
			if (Cardutl.CheckStraight(cValues))then
				cardType = Cardutl.TYPE_STRAIGHT
			 elseif (Cardutl.checkDoubles(cValues))then
				cardType = Cardutl.TYPE_DOUBLES
			 elseif (Cardutl.checkPlane(cValues, 4, 0))then
				cardType = Cardutl.TYPE_PLANE_0
			 elseif (Cardutl.checkPlane(cValues, 3, 1))then
				cardType = Cardutl.TYPE_PLANE_1
			end
		elseif case == 14 then--case 14:-- 连对
			if (Cardutl.checkDoubles(cValues))then
				cardType = Cardutl.TYPE_DOUBLES
			end
		elseif case == 15 then--case 15:-- 3飞机带对 - 5飞机不带
			if (Cardutl.checkPlane(cValues, 5, 0)) then 
				cardType = Cardutl.TYPE_PLANE_0
			  elseif (Cardutl.checkPlane(cValues, 3, 2))then
				cardType = Cardutl.TYPE_PLANE_2
			end
		elseif case == 16 then--case 16:-- 连对 - 四飞带四单
			if (Cardutl.checkDoubles(cValues)) then 
				cardType = Cardutl.TYPE_DOUBLES
			 elseif (Cardutl.checkPlane(cValues, 4, 1))then
				cardType = Cardutl.TYPE_PLANE_1
			end
		elseif case == 18 then--case 18:-- 连对
			if (Cardutl.checkDoubles(cValues)) then
				cardType = Cardutl.TYPE_DOUBLES
			end
		elseif case == 20 then--case 20:-- 最长连对
			if (Cardutl.checkDoubles(cValues))then
				cardType = Cardutl.TYPE_DOUBLES
			 elseif (Cardutl.checkPlane(cValues, 5, 1))then
				cardType = Cardutl.TYPE_PLANE_1
			 elseif (Cardutl.checkPlane(cValues, 4, 2))then
				cardType = Cardutl.TYPE_PLANE_2
			end
		--case 21:-- 最多21张牌
		end
	end
	return cardType
end 

--检查顺子
function Cardutl.CheckStraight(cValues )  
	dump(cValues,'CheckStraight ↓↓↓')
	local flag  = true
	local length = #cValues
	for i=1,length do 
		if (cValues[1] - (i - 1 )) ~= cValues[i] then
			printf('CheckStraight: (cValues[1] - (i)) ~= cValues[i] = FALSE')
			flag = false
		end
		if cValues[1] >= 0x0F then 
			printf('CheckStraight: cValues[1] >= 0x0F  = FALSE')
			flag = false
		end
	end 
	return flag
end

--检查对
function Cardutl.checkDoubles(_cValues )   
	local flag  = true
	local cLen  = #_cValues
	local length  = cLen - 2

	local cValues = Cardutl.makeIdxFromZero(_cValues) 
	if ((cLen%2) ~= 0) then
		flag = false
	 elseif (cValues[cLen-1] >= 0x0F)then
		flag = false
	 else  
	 	for i=0,length-1 do
	 		if (i%2 == 0)then
				if ((cValues[i]) ~= (cValues[i+1]) or (cValues[i]-(1) ~= cValues[i+2]))then
					flag = false
				end
			end
	 	end 
		if (cValues[length] ~= cValues[length+1])then
			flag = false
		end
		if (cValues[0] == 0x0F)then
			flag = false
		end
	end
	return flag
end

--移动索引
function Cardutl.makeIdxFromZero(srcTbl)
	local ret = {}
	for i=1,#srcTbl do
		ret[i-1]=srcTbl[i]
	end
	return ret
end

--检查飞机
function Cardutl.checkPlane(_cValues  , threeNum  , subNum )  
	local flag = true
	local cValues = Cardutl.makeIdxFromZero(_cValues) 
	for i=0,threeNum-1 do
		if (cValues[i*3] ~= cValues[i*3+1] or cValues[i*3] ~= cValues[i*3+2]) then
			flag = false
		end

		if (i>0 and (cValues[i*3]+1) ~= cValues[(i-1)*3])then
			flag = false
		end
	end
 
	if (flag)then
		if (threeNum >= 2 and cValues[1] >= 0x0F) then
			flag = false
		end
	end

	if (flag)then
		if (subNum == 1)then
		  elseif (subNum == 2)then
		  	for i=1,threeNum-1 do
				if (cValues[3*threeNum+i*2] ~= cValues[3*threeNum+i*2+1])then
					flag = false
				end
		  	end 
		end
	end
	return flag
end

--检查4张:四张都一样的牌
function Cardutl.checkFour(cValues , subNum ) 
	local ret = false
	if (cValues[1] == cValues[2] and cValues[1] == cValues[3] and cValues[1] == cValues[4])then
		if (subNum == 1)then
			ret = true
		 elseif (subNum == 2 and #cValues == 8)then
			ret = (cValues[6] == cValues[5] and cValues[7] == cValues[8])
		end
	end
	return ret
end





-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------

------------------------    C A R D     P L A Y A B L E     V A L I D A T E    F U N C T I O N S  ----------------------------


-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------
--把花色和牌值分开
function Cardutl.devideToTypeAndValueLists(cards)
	local types = {}
	local vals = {}
	if cards then
		for k,card in pairs(cards) do
			types[k] = Cardutl.GetCardType(card)
			vals[k] = Cardutl.GetCardValue(card)
		end
	end
	return types,vals
end

 
--能不能打上家的牌
function Cardutl.checkCardOut(srcCards , dstCards) 
		local outArr = srcCards--clone(srcCards)
		local flag = false
		local size = #outArr
		local _type = Cardutl.TYPE_CARD_ERROR
		if (size <= 0) then
			return false;
		end
 
		local c1 = outArr[1];  
		--/** 有癞子 **/
		if (Cardutl.GetCardType(c1) == Cardutl.CARD_SWT_TYPE) then 
			 Cardutl.SortHandCards(outArr)  
			 dump(outArr,"before laizi")

			Cardutl.dumpCardValues(outArr,"outArr val before laizi")
			LaiziUtil.getLaiziOut(outArr) 
			 dump(outArr,"after laizi")  

			Cardutl.dumpCardValues(outArr,"outArr val after laizi")
			if (outArr ~= nil and #outArr > 0) then
				printf('checkCardOutEX in progress.')
				flag,_type = Cardutl.checkCardOutEX(outArr, dstCards); 
			else   
				printf('(outArr ~= nil and #outArr > 0)  is FALSE.')
				flag = false;
			end
		else   
			Cardutl.SortOutCards(outArr)    
			Cardutl.SortOutCards(dstCards)    
			flag,_type = Cardutl.checkCardOutEX(outArr, dstCards); 
		end
		return flag,_type;
end

function Cardutl.dumpCardValues(cards,desc)
	-- body
	local t,v = Cardutl.devideToTypeAndValueLists(cards)
	dump(v,desc)
end

--处理是否能打上家的牌
function Cardutl.checkCardOutEX(outs, dstCards)  
		local _allTypes , preTypeValues = Cardutl.devideToTypeAndValueLists(dstCards)
		local preType =  Cardutl.CheckOutCardType(dstCards, preTypeValues)

		local  size = #outs 
		local types = {}
		local cards = {}
		for i=1,size do 
			types[i] = Cardutl.GetCardType(outs[i]);
			cards[i] = Cardutl.GetCardValue(outs[i]);
		end

		local _type =  Cardutl.CheckOutCardType(outs, cards )--Cardutl.checkCardType(types, cards); 
		print("Last Type:"..preType,"myType:".._type); 
		if (_type ~= Cardutl.TYPE_CARD_ERROR) then
			if (preType ~= Cardutl.TYPE_CARD_ERROR) then--// 上家有人出牌
				local case = preType --switch (preType) {
				if case == Cardutl.TYPE_SINGLE then
					return Cardutl.checkSingle(_type, types, cards, preType, _allTypes, preTypeValues);
				elseif case == Cardutl.TYPE_DOUBLE then
					return Cardutl.checkNormal(_type, types, cards, preType, preTypeValues);
				elseif case == Cardutl.TYPE_STRAIGHT then
					return Cardutl.checkNormal(_type, types, cards, preType, preTypeValues);
				elseif case == Cardutl.TYPE_DOUBLES then
					return Cardutl.checkNormal(_type, types, cards, preType, preTypeValues);
				elseif case == Cardutl.TYPE_THREE_0  
				or case == Cardutl.TYPE_THREE_1  
				or case == Cardutl.TYPE_THREE_2 then
					return Cardutl.checkNormal(_type, types, cards, preType, preTypeValues);
				elseif case == Cardutl.TYPE_PLANE_0  
				or case == Cardutl.TYPE_PLANE_1  
				or case == Cardutl.TYPE_PLANE_2 then
					return Cardutl.checkNormal(_type, types, cards, preType, preTypeValues);
				elseif case == Cardutl.TYPE_FOUR_1  
				or case == Cardutl.TYPE_FOUR_2 then
					return Cardutl.checkNormal(_type, types, cards, preType, preTypeValues);
				elseif case == Cardutl.TYPE_BOMB_4 then
					return Cardutl.checkBomb4(_type, types, cards, preType, preTypeValues);
				elseif case == Cardutl.TYPE_BOMB_KING then
					return false,_type; 
				end
			else--// 新一轮
				return true,_type;
			end
		end
		return false,_type;
end 
	-- 上家出牌单张 */
function Cardutl.checkSingle(  _type,   types,  cards,   preCardType, _allTypes, preTypeValues)  
		local flag = false;
		local _lastType = _allTypes[1]
		local lastValue = preTypeValues[1]
		if (_type == preCardType) then
			local value0 = cards[1];
			local type0 = types[1];
			if (type0 == 0) then
				value0  = value0 + 0x0F;
			end
			if(_lastType == 0) then
				lastValue = lastValue + 0x0F;
			end
			flag = (value0 > lastValue);
		elseif (Cardutl.isBomb(_type)) then
			flag = true;
		end
		if flag == true then
			print("flag true")
		else
			print("flag false")
		end
		return flag;
end

	-- 上家出牌对子 */
function Cardutl.checkNormal(  _type,   _types,   cards,   pre_type,   pre_typeValues)  
		local flag = false;
		if (_type == pre_type and #cards == #pre_typeValues) then
			local value0 = cards[1];
			flag = (value0 > pre_typeValues[1]);
		elseif (Cardutl.isBomb(_type)) then
			flag = true;
		end
		return flag;
end

	-- 上家出牌四张炸弹 */
function Cardutl.checkBomb4( _type,  _types, cards,  pre_type, pre_typeValues)  
	local flag = false;
	if (_type == pre_type and #cards == #pre_typeValues)then
		local value0 = cards[1];
		if (value0 > pre_typeValues[1]) then
			flag = true;
		end
	elseif (_type == Cardutl.TYPE_BOMB_KING) then
		flag = true;
	end
	return flag;
end

function Cardutl.isBomb( _type)  
	return (_type == Cardutl.TYPE_BOMB_4) or (_type == Cardutl.TYPE_BOMB_KING);
end 