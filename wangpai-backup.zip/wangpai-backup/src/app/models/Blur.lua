Blur = {}

function Blur.getVertFrag()
	return [[attribute vec4 a_position; attribute vec2 a_texCoord; attribute vec4 a_color; 
#ifdef GL_ES
 varying lowp vec4 v_fragmentColor; varying mediump vec2 v_texCoord; 
#else
 varying vec4 v_fragmentColor; varying vec2 v_texCoord; 
#endif
 void main() { gl_Position = CC_PMatrix * a_position; v_fragmentColor = a_color; v_texCoord = a_texCoord; }]]
end

function Blur.getPSFrag(radius,sampler,resolution)
	local ret = 
	[[
#ifdef GL_ES
    precision mediump float;
#endif

varying vec4 v_fragmentColor;
varying vec2 v_texCoord;

vec2 resolution;
float blurRadius;
float sampleNum; 
vec4 blur(vec2);

void main(void)
{
    blurRadius = %.2f;
    sampleNum = %.2f;
    resolution = vec2(%d,%d);
    vec4 col = blur(v_texCoord); //* v_fragmentColor.rgb;
    gl_FragColor = vec4(col) * v_fragmentColor;
}

vec4 blur(vec2 p)
{
    if (blurRadius > 0.0 && sampleNum > 1.0)
    {
        vec4 col = vec4(0);
        vec2 unit = 1.0 / resolution.xy;
        
        float r = blurRadius;
        float sampleStep = r / sampleNum;
        
        float count = 0.0;
        
        for(float x = -r; x < r; x += sampleStep)
        {
            for(float y = -r; y < r; y += sampleStep)
            {
                float weight = (r - abs(x)) * (r - abs(y));
                col += texture2D(CC_Texture0, p + vec2(x * unit.x, y * unit.y)) * weight;
                count += weight;
            }
        }
        
        return col / count;
    }
    
    return texture2D(CC_Texture0, p);
}
]]
return string.format(ret,radius,sampler,resolution.width,resolution.height)
end

function Blur.getShader(radius,sampler,resolution)
	local f = Blur.getPSFrag(radius,sampler,resolution)
	local v = Blur.getVertFrag() 
	local  glprogram = cc.GLProgram:createWithByteArrays( v,f);
    return cc.GLProgramState:getOrCreateWithGLProgram(glprogram) 
end

function Blur.getBlurredSceneSnapshot(radius,onSucc)
	LuaTools.getScreenSnapshot(function(spr)
		local state = Blur.getShader( radius,5,cc.size(64,64)) 
		spr:setGLProgramState(state)
        spr:setPosition(cc.p(spr:getContentSize().width * spr:getScaleX()/2,
        spr:getContentSize().height * spr:getScaleY()/2))
        local renderTexture = cc.RenderTexture:create(spr:getContentSize().width * spr:getScaleX(),
        spr:getContentSize().height* spr:getScaleY());
        renderTexture:begin()
        spr:visit() 
        renderTexture:endToLua() 
        local resSpr = cc.Sprite:createWithTexture(renderTexture:getSprite():getTexture())
        resSpr:setFlippedY(true)
		onSucc(resSpr)
	end)  
end


