local Account = class("Account", cc.load("mvc").ModelBase)

--初始化
function Account:onCreate()
    local app = self:getApp()
    self.app = app
    
    self.accMinLen = 6
    self.accMaxLen = 11
    self.pwdMinLen = 6
    self.pwdMaxLen = 10


    self.smsCodeError = '验证码错误'
    self.phoneError = '手机号码不正确请重新输入'
    self.phoneError1 = '请输入手机号码'
    self.pwdError = '您输入的密码存在非法字符，请重新输入'
    self.pwdNotMatched = '两次输入的密码不一致，请重新输入'
    self.pwdLenght = '密码长度不在6~10之内，请重新输入'
    self.pwdLenght4 = '密码长度不在4~10之内，请重新输入'
    
    self.accNotFind = '请输入您的账号！'
    self.accError = '您输入的账号存在非法字符，请重新输入'
    self.accLenght = '账号长度不在6~11之内，请重新输入'
end

--字符是否是数字或英文字母
function Account:isNumOrChar(byte)
    local ref = string.char(byte)
    if (ref >= '0' and ref <= '9') or         --0 ~ 9
        (ref >= 'A' and ref <= 'Z') or         --A ~ Z
        (ref >= 'a' and ref <= 'z')            --a ~ z
    then
        return true
    else
        return false
    end
end

--字符串是否只包含了数字
function Account:strContainOnlyNum(str)
    for i = 1, #str do
        local ref = string.char(string.byte(str, i))
        if (ref > '9' or ref < '0') then
            return false
        end
    end
    return true
end

--字符串内容是否只包含了数字和英文字母
function Account:strContainOnlyNumAndChar(str)
    str = tostring(str)
    for i = 1, #str do
        if false == self:isNumOrChar(string.byte(str, i)) then
            return false
        end
    end
    return true
end

--字符串内容是否只包含了数字,英文字母,和特殊字符
--@params: 1.字符串   2.特殊字符表
function Account:strContainOnlyNumCharAndExtraChars(str, extraChars)
    if extraChars == nil then extraChars = {} end
    local tabStr = LuaTools.UStr2Table(str)
    --dump(tabStr)
    for i = 1, #tabStr do
        local c = tabStr[i]
        if false == self:isNumOrChar(string.byte(c, 1)) then
            if #extraChars == 0 then return false end
            for j,v in ipairs(extraChars) do
                --print("VVVV: "..v.."  CCCC: "..tabStr[i])
                if tabStr[i] == v then

                    else
                    return false
                end
            end 
        end
    end
    return true 
end

--字符串内容是否只包含了特殊字符
--@params: 1.字符串   2.特殊字符表
function Account:strContainBannedChars(str, extraChars)
    if extraChars == nil then extraChars = {} end
    local tabStr = LuaTools.UStr2Table(str)
     for i = 1, #tabStr do
        for j,v in ipairs(extraChars) do
            --print("VVVV: "..v.."  CCCC: "..tabStr[i])
            if tabStr[i] ~= v then

                else
                return false
            end
        end
    end
    return true 
end

--输入框的控制, 可以屏蔽输入的某一些字符
--@params: 1.输入框  2.特殊字符表  3.禁止类型(num/numc/banc), 默认为numc
function Account:handleTxfControl(_txf, _extraChars, _type)
    local lastValidStr = _txf:getString()
    local function onSetTextfied(event)
        local str = _txf:getString()
        if event.name == "ATTACH_WITH_IME" then

        elseif event.name == "DETACH_WITH_IME" then
            
        elseif event.name == "INSERT_TEXT" then
            local result 
            if _type == nil then _type = 'numc' end
            if _type == 'num' then
                result = self:strContainOnlyNum(str)
            elseif _type == 'numc' then
                result = self:strContainOnlyNumCharAndExtraChars(str,_extraChars)
            elseif _type == 'banc' then
                result = self:strContainBannedChars(str,_extraChars)
            end
            if result == false then
                _txf:setString(lastValidStr)
            else
                lastValidStr = str
            end
        elseif event.name == "DELETE_BACKWARD" then
            lastValidStr = str
        end
    end
   _txf:onEvent(onSetTextfied)
end

return Account 