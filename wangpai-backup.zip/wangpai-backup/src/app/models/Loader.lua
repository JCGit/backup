local Loader = class("Loader", cc.load("mvc").ModelBase)

function Loader:onCreate(entity)
end
--------------------------------
-- @function [parent=#Loader] loadArmature 
-- @param self 
-- path = "res/animation/entity/"
-- "res/animation/entity/skill0001/skill00010.png"
function Loader:loadArmature(path,name,callback,param)
    --如果已经加载过了，直接调用callback返回
    if ccs.ArmatureDataManager:getInstance():getAnimationData(name) then
        if callback then
            callback(param)
        end
        return
    end
    
    --如果已经在加载中，将callback压入callbacks队列中
    --为了避免队列元素重复，使用callback自身作为健值
    local json_path = string.format(path..'%s/%s.ExportJson',name,name)
    Loader.loading = Loader.loading or {}
    local l = Loader.loading[json_path]
    if not l then
        l = {}
        l.full_path = json_path
        l.path = path
        l.name = name
        l.callbacks = {}
        l.callbacks[callback] = {callback = callback,param = param}
        Loader.loading[json_path] = l
        
        self:loadArmatureImages(l)
    else
        l.callbacks[callback] = {callback = callback,param = param}
    end
end
--------------------------------
-- 在发起加载动画后，加载还没有返回，但此时删除发起者，需要调用unbindLoadArmature,否则可能引起报错。
function Loader:unbindLoadArmature(path,name,callback)
    local json_path = string.format(path..'%s/%s.ExportJson',name,name)
    Loader.loading = Loader.loading or {}
    local l = Loader.loading[json_path]
    if l then
        l.callbacks[callback] = nil
        if table.isEmpty(l.callbacks) then
            Loader.loading[l.full_path] = nil 
        end
    end
end
--------------------------------
function Loader:loadArmatureImages(l)
    local index = 0
    local image_path = string.format(l.path.."%s/%s%d.png",l.name, l.name, index)
    local textureCache = cc.Director:getInstance():getTextureCache()
    local fileUtils = cc.FileUtils:getInstance()
    l.images = {}
    while fileUtils:isFileExist(image_path) do
        l.images[image_path] = true
        printInfo("[Loader:loadArmatureImages]image_path = %s", image_path)
        textureCache:addImageAsync(image_path, self:genLoadImagesCallback(l,image_path))
        index = index + 1
        image_path = string.format(l.path.."%s/%s%d.png",l.name, l.name, index)
    end
end
--------------------------------
function Loader:genLoadImagesCallback(l,image_path)
    local armatureDataManager = ccs.ArmatureDataManager:getInstance()
    return function(texture)
        --如果所有图片都加载完，开始加载骨骼动画文件
        l.images[image_path] = nil
        armatureDataManager:addSpriteFrameFromFile(image_path:gsub(".png", ".plist"), image_path, l.full_path)
        if table.isEmpty(l.images) then
            local json_path = string.format(l.path.."%s/%s.ExportJson",l.name, l.name)
            printInfo("[Loader:genLoadImagesCallback]json_path = %s", json_path)
            armatureDataManager:addArmatureFileInfoAsync(json_path, self:genLoadArmatureCallback(json_path))
        end
    end
end
--------------------------------
function Loader:genLoadArmatureCallback(json_path)
    return function(percent)
        local l = Loader.loading[json_path]
        if l then
        
            if not ccs.ArmatureDataManager:getInstance():getAnimationData(l.name) then
                printError('genLoadArmatureCallback,can not getAnimationData,json_path:%s',json_path)
                return
            end
            --骨骼动画加载完后回调所有callback
            for k,v in pairs(l.callbacks) do
                if v then
                    v.callback(v.param)
                end
            end
        end
        Loader.loading[json_path] = nil
    end
end

--------------------------------
-- path = "res/animation/entity/"
-- "res/animation/entity/skill0001/skill00010.png"
function Loader:loadNode(path,name,callback,param)
    --如果已经在加载中，将callback压入callbacks队列中
    --为了避免队列元素重复，使用callback自身作为健值
    local csb_path = string.format(path..'%s/%s.csb',name,name)
    Loader.loading_node = Loader.loading_node or {}
    local l = Loader.loading_node[csb_path]
    if not l then
        l = {}
        l.full_path = csb_path
        l.path = path
        l.name = name
        l.callbacks = {}
        l.callbacks[callback] = {callback = callback,param = param}
        Loader.loading_node[csb_path] = l

        --printError('loadNode new:%s,%s',csb_path,tostring(callback))
        self:loadNodeImages(l)
    else
        l.callbacks[callback] = {callback = callback,param = param}
        --printError('loadNode exist:%s,%s',csb_path,tostring(callback))
    end
end
--------------------------------
-- 在发起加载动画后，加载还没有返回，但此时删除发起者，unbindLoadNode,否则可能引起报错。
function Loader:unbindLoadNode(path,name,callback)
    local csb_path = string.format(path..'%s/%s.csb',name,name)
    Loader.loading_node = Loader.loading_node or {}
    local l = Loader.loading_node[csb_path]
    if l then
        l.callbacks[callback] = nil
        --printError('unbindLoadNode:%s,%s',csb_path,tostring(callback))
        if table.isEmpty(l.callbacks) then
            Loader.loading_node[l.full_path] = nil 
        end
    end
end
--------------------------------
function Loader:loadNodeImages(l)
    local image_path = string.format(l.path.."%s/%s.png",l.name, l.name)
    local textureCache = cc.Director:getInstance():getTextureCache()
    local fileUtils = cc.FileUtils:getInstance()
    l.images = {}
    
    local callback =  function(texture)
        if texture then
            cc.SpriteFrameCache:getInstance():addSpriteFrames(image_path:gsub(".png", ".plist"), image_path)--texture)  
        end
        for k,v in pairs(l.callbacks) do
            if v then
                v.callback(v.param)
            end
        end
        Loader.loading_node[l.full_path] = nil      
    end
    
    if fileUtils:isFileExist(image_path) then
        textureCache:addImageAsync(image_path, callback)
    else
        callback(nil)
    end
end
return Loader