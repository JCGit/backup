LaiziUtil = {}
 
	--* 设置癞子牌值, 并排序(多 - 少 , 大 - 小) **/
function LaiziUtil.getLaiziOut(outArr)  
		local tmp = {}

		for i=2,#outArr do
			tmp[i-1] = outArr[i]
		end
		local len = #tmp  
		Cardutl.SortOutCards(tmp) 
		Cardutl.dumpCardValues(tmp,"tmpdumpCardValuesdumpCardValues")
		local case = #outArr
		if case == 1 then -- 单张
			return nil
		elseif case == 2  then-- 对子 - 王炸弹
			if (LaiziUtil.getTypeValue(tmp[1]) == 0x01)then --小王
				outArr[1] = LaiziUtil.getCardValue(0x05, LaiziUtil.getTypeValue(0x02));
			elseif (LaiziUtil.getTypeValue(tmp[1]) == 0x02) then-- 大王
				outArr[1] = LaiziUtil.getCardValue(0x05, LaiziUtil.getTypeValue(0x01));
			else
				outArr[1] = LaiziUtil.getCardValue(0x05, LaiziUtil.getTypeValue(tmp[1]));
			end 
		elseif case == 3  then-- 三张不带
			outArr[1] = LaiziUtil.getCardValue(0x05, LaiziUtil.getTypeValue(tmp[2])); 
		elseif case == 4  then-- 四张炸弹 - 三带一
			outArr[1] = LaiziUtil.getCardValue(0x05, LaiziUtil.getTypeValue(tmp[2]));-- 2+1 或者 3 
		elseif case == 5  then-- 三带二 - 顺子
			if (LaiziUtil.getTypeValue(tmp[1]) == LaiziUtil.getTypeValue(tmp[3])) then-- 3+1
				outArr[1] = LaiziUtil.getCardValue(0x05, LaiziUtil.getTypeValue(tmp[4]));
			elseif (LaiziUtil.getTypeValue(tmp[1]) == LaiziUtil.getTypeValue(tmp[2])
					and LaiziUtil.getTypeValue(tmp[3]) == LaiziUtil.getTypeValue(tmp[4])) then-- 2+2
				outArr[1] = LaiziUtil.getCardValue(0x05, LaiziUtil.getTypeValue(tmp[1]));
			else
				LaiziUtil.tmpStraight(tmp, outArr);
			end 
		elseif case == 6  then-- 连对 - 顺子 - 飞机不带 - 四带二
			print("laizi:case == 6 ") 
			if(LaiziUtil.getTypeValue(tmp[1]) == LaiziUtil.getTypeValue(tmp[4]))then--4+1 
				outArr[1] = LaiziUtil.getCardValue(0x05, LaiziUtil.getTypeValue(tmp[5]));
			elseif (LaiziUtil.getTypeValue(tmp[1]) == LaiziUtil.getTypeValue(tmp[3])) then-- 3+2
				outArr[1] = LaiziUtil.getCardValue(0x05, LaiziUtil.getTypeValue(tmp[1]));
			elseif (LaiziUtil.getTypeValue(tmp[1]) == LaiziUtil.getTypeValue(tmp[2])) then
				LaiziUtil.tmpDoubles(tmp, outArr);
			else
				LaiziUtil.tmpStraight(tmp, outArr);
			end
		elseif case == 7  then-- 顺子
			LaiziUtil.tmpStraight(tmp, outArr); 
		elseif case == 8  then-- 顺子 - 连对 - 2飞机带单  - 四带两队
			if(LaiziUtil.getTypeValue(tmp[1]) == LaiziUtil.getTypeValue(tmp[4]))then--4+2+1
				if(LaiziUtil.getTypeValue(tmp[5]) == LaiziUtil.getTypeValue(tmp[6]))then
					outArr[1] = LaiziUtil.getCardValue(0x05, LaiziUtil.getTypeValue(tmp[7]));
				end
			elseif (LaiziUtil.getTypeValue(tmp[1]) == LaiziUtil.getTypeValue(tmp[3])) then--3+2+2 | 3+3+1 | 3+2+1+1
				if (LaiziUtil.getTypeValue(tmp[4]) == LaiziUtil.getTypeValue(tmp[5]) and LaiziUtil.getTypeValue(tmp[6]) == LaiziUtil.getTypeValue(tmp[7]))then
					outArr[1] = LaiziUtil.getCardValue(0x05, LaiziUtil.getTypeValue(tmp[1]));
				else
					LaiziUtil.tmpPlane(tmp, outArr, 2, 1);
				end
			elseif (LaiziUtil.getTypeValue(tmp[1]) == LaiziUtil.getTypeValue(tmp[2])) then
				LaiziUtil.tmpDoubles(tmp, outArr);
			else
				LaiziUtil.tmpStraight(tmp, outArr);
			end
		elseif case == 9  then-- 3飞机不带 - 顺子
			if (LaiziUtil.getTypeValue(tmp[1]) == LaiziUtil.getTypeValue(tmp[3])) then
				LaiziUtil.tmpPlane(tmp, outArr, 3, 0);
			else
				LaiziUtil.tmpStraight(tmp, outArr);
			end
		elseif case == 10 then -- 连对 - 2飞机带对 -顺子
			if (LaiziUtil.getTypeValue(tmp[1]) == LaiziUtil.getTypeValue(tmp[3])) then
				if(LaiziUtil.getTypeValue(tmp[1]) == LaiziUtil.getTypeValue(tmp[4]))then
					if (LaiziUtil.getTypeValue(tmp[5]) == LaiziUtil.getTypeValue(tmp[6]))then
						outArr[1] = LaiziUtil.getCardValue(0x05, LaiziUtil.getTypeValue(tmp[8]));
					else
						outArr[1] = LaiziUtil.getCardValue(0x05, LaiziUtil.getTypeValue(tmp[5]));
					end
				else
					LaiziUtil.tmpPlane(tmp, outArr, 2, 2);
				end
			elseif (LaiziUtil.getTypeValue(tmp[1]) == LaiziUtil.getTypeValue(tmp[2])) then
				LaiziUtil.tmpDoubles(tmp, outArr);
			else
				LaiziUtil.tmpStraight(tmp, outArr);
			end
		elseif case == 11 then -- 顺子
			LaiziUtil.tmpStraight(tmp, outArr); 
		elseif case == 12 then -- 最长顺子 - 连对 - 3飞机带单 - 4飞机不带
			if (LaiziUtil.getTypeValue(tmp[1]) == LaiziUtil.getTypeValue(tmp[3])) then
				if (LaiziUtil.getTypeValue(tmp[len - 1]) ~= LaiziUtil.getTypeValue(tmp[len - 2])) then
					LaiziUtil.tmpPlane(tmp, outArr, 3, 1);
				else
					LaiziUtil.tmpPlane(tmp, outArr, 4, 0);
				end
			elseif (LaiziUtil.getTypeValue(tmp[1]) == LaiziUtil.getTypeValue(tmp[2])) then
				LaiziUtil.tmpDoubles(tmp, outArr);
			else
				LaiziUtil.tmpStraight(tmp, outArr);
			end
		elseif case == 14 then -- 连对
			LaiziUtil.tmpDoubles(tmp, outArr); 
		elseif case == 15 then -- 3飞机带对 - 5飞机不带
			if (LaiziUtil.getTypeValue(tmp[12]) == LaiziUtil.getTypeValue(tmp[10])) then
				LaiziUtil.tmpPlane(tmp, outArr, 5, 0);
			else
				LaiziUtil.tmpPlane(tmp, outArr, 3, 2);
			end
		elseif case == 16 then -- 连对 - 四飞带四单
			if(LaiziUtil.getTypeValue(tmp[1]) == LaiziUtil.getTypeValue(tmp[3]) or LaiziUtil.getTypeValue(tmp[3]) == LaiziUtil.getTypeValue(tmp[5])) then
				LaiziUtil.tmpPlane(tmp, outArr, 4, 1);
			else 
				LaiziUtil.tmpDoubles(tmp, outArr);
			end
		elseif case == 18 then -- 连对
			LaiziUtil.tmpDoubles(tmp, outArr); 
		elseif case == 20 then -- 最长连对 - 五飞带五单, 四飞带四对
			if(LaiziUtil.getTypeValue(tmp[1]) == LaiziUtil.getTypeValue(tmp[3]) or LaiziUtil.getTypeValue(tmp[3]) == LaiziUtil.getTypeValue(tmp[5])) then
				--TODO
				LaiziUtil.tmpPlane(tmp, outArr, 5, 1);
			else 
				LaiziUtil.tmpDoubles(tmp, outArr);
			end
		elseif case == 21 then -- 最多21张牌 - 飞机不带
			LaiziUtil.tmpPlane(tmp, outArr, 7, 0); 
		end

		Cardutl.SortOutCards(outArr)  
		return outArr;
end
	
function LaiziUtil.getTypeValue( value) 
	return Cardutl.GetCardValue(value)
end

function LaiziUtil.getCardValue( typeType,  typeValue) 
	return Cardutl.GetCardByTV(typeType , typeValue ) 
end

function LaiziUtil.tmpStraight(  tmp,  outArr)  
		print("LaiziUtil.tmpStraight start");
		local len = #tmp;
		local flag = false;
		for i=1,(len-1) do --for (int i = 0; i < len; i++) {
			if (LaiziUtil.getTypeValue(tmp[i]) - 1 ~= LaiziUtil.getTypeValue(tmp[i + 1])) then
				flag = true;
				print("tmp straight true " , i);
				outArr[1] = LaiziUtil.getCardValue(0x05, LaiziUtil.getTypeValue(tmp[i]) - 1);
				break;
			end
		end
		if (not flag) then
			if (LaiziUtil.getTypeValue(tmp[1]) < 0x0E) then
				print("tmp straight false 1");
				outArr[1] = LaiziUtil.getCardValue(0x05, LaiziUtil.getTypeValue(tmp[1]) + 1);
			else
				print("tmp straight false 2");
				outArr[1] = LaiziUtil.getCardValue(0x05, LaiziUtil.getTypeValue(tmp[len]) - 1);
			end
		end
		print("LaiziUtil.tmpStraight end");
end

function LaiziUtil.tmpDoubles( tmp,  outArr)  
	print("LaiziUtil.tmpDoubles start");
	local len = #tmp;
	local val = LaiziUtil.getTypeValue(tmp[len])
	print("tmpDoubles val:",val)
	Cardutl.dumpCardValues(tmp,"tmpDoubles tmp")
	outArr[1] = LaiziUtil.getCardValue(0x05, LaiziUtil.getTypeValue(tmp[len]));
	print("LaiziUtil.tmpDoubles end");
end

	--* threeNum-几飞机 subNum-带单或对或不带 **/
function LaiziUtil.tmpPlane(tmp,  outArr,   threeNum,  subNum) 
		local len = #tmp;
		local noThree = threeNum * subNum;
		if (LaiziUtil.getTypeValue(tmp[len - noThree]) == LaiziUtil.getTypeValue(tmp[len - 2 - noThree])) then-- 3个齐全
			if (subNum == 1) then
				outArr[1] = LaiziUtil.getCardValue(0x05, 0x03);
			elseif (subNum == 2) then
				outArr[1] = LaiziUtil.getCardValue(0x05, LaiziUtil.getTypeValue(tmp[len]));
			end
		else
			if(subNum == 2) then
				local tValue = LaiziUtil.getTypeValue(tmp[1])  
				for i=1,len do-- for(int i=0; i<len ;i++) 
					local iValue = LaiziUtil.getTypeValue(tmp[i]) ;
					if((tValue == iValue + 1 or tValue+1 == iValue) and iValue<0x0F)then
						outArr[1] = LaiziUtil.getCardValue(0x05, iValue);
					end
				end
			else 
				outArr[1] = LaiziUtil.getCardValue(0x05, LaiziUtil.getTypeValue(tmp[len - noThree]));
			end
		end
end  