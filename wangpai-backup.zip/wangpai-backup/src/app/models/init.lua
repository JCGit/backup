
local Models = class("Models", cc.load("mvc").ModelBase)

function Models:onCreate()
    self.models_ = {}
    self.app = self:getApp()

    self:addModel("Tools")
    self:addModel("Loader")
    self:addModel("Schedule")
    -- self:addModel("Sound")
    self:addModel("Account")
    return self
end
function Models:addModel(name, ...)
    self.models_[name] = self.app:createModel(name, ...)
        
    return self.models_[name]
end

function Models:getModel(name)
    return self.models_[name]
end

function Models:removeModel(name)
    self.models_[name] = nil

    name = "app.models." .. (name:match("(.+)%.lua$") or name)
    package.loaded[name] = nil
end

--[[
function Models:getModelsSize(name)
    local model = self.models_[name]
    if model then
        model:size()
    end
end

function Models:getModelsValue(name, key, default)
    local model = self.models_[name]
    return model and model:getValue(key, default) or nil
end

function Models:setModelsValue(name, key, value)
    local model = self.models_[name]
    if model then
        model:setValue(key, value)
    end
end
--]]

return Models
