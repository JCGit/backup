CardHints = class('CardHints')
if not Cardutl then 
	require("app.models.cardutl")
end
--出牌提示
function CardHints:ctor(argTable)
	-- dump(argTable,"CardHints:ctor argTable")
	self.hasSwt = false
	self.lastPlayedCardsType 	= argTable.lastPlayedCardsType
	self.lastPlayedCardValues 	= argTable.lastPlayedCardValues
	self.handCardTable 			= argTable.handCardTable
	_,self.lastPlayedCardValues = Cardutl.devideToTypeAndValueLists(self.lastPlayedCardValues) 


	self.bigger 		= {} 
	self.bigIndex 		= 0;
	self.preTypeValues 	= {}
	self.preTypeTypes 	= {}

	self.allSingle 		={}
	self.allDoubles 	={}
	
	self.onlySingle 	={}
	self.onlyDoubles 	={}
	self.onlyThrees 	={}
	self.fours			={}
	self:init()

end

function CardHints:init()  
		local uCards = self.handCardTable
		--花不存在着里面
		self.allSingle = {}--记录所有牌值，会出现大王和小王
		self.onlyDoubles = {}--只有对子
		self.allDoubles = {}--所有两张以上，比如对子，三张，四张
		self.onlyThrees = {}--只有三张
		self.onlySingle = {}--只有一张，会出现大王和小王
		self.fours = {}--炸弹，大王小王和花都不在这里面
-- Cardutl.GetCardType(card);
-- Cardutl.GetCardValue(card);
		local size = #uCards   
		local i = 1
		while i <= size do 
			local continue = false
			local value =  uCards[i]  
			local _type = Cardutl.GetCardType(uCards[i]) 
			if (_type == Cardutl.CARD_SWT_TYPE) then
				i=i+1;
				self.hasSwt = true
				continue = true
			end
			if continue == false then
				local deltla = 1;
				table.insert(self.allSingle,value)
				table.insert(self.onlySingle,value) 
	
				if (_type == Cardutl.CARD_KING_TYPE ) then
					i=i+1;
					continue = true
				end
				if continue == false then
					if (i <= size - 1) then
						if (Cardutl.GetCardValue(uCards[i]) == Cardutl.GetCardValue(uCards[i+1])) then
							table.insert(self.onlyDoubles,value)
							table.insert(self.allDoubles,value)
							self.onlySingle[#self.onlySingle]=nil 
							deltla = 2;
							if (i <= size - 2) then
								if (Cardutl.GetCardValue(uCards[i]) == Cardutl.GetCardValue(uCards[i + 2])) then
									table.insert(self.onlyThrees,value)
									self.onlyDoubles[#self.onlyDoubles]=nil   
									deltla = 3;
									if (i <= size - 3) then
										if (Cardutl.GetCardValue(uCards[i]) == Cardutl.GetCardValue(uCards[i + 3])) then 
											table.insert(self.fours,value)
											self.onlyThrees[#self.onlyThrees]=nil    
											deltla = 4;
										end
									end
								end
							end
						end
					end 
					i  = i + deltla;
				end--continue == false
			end--continue == false
		end

		-- LogUtil.e("selfTurnInit", allSingle.size() + " s* " + onlyDoubles.size() + " d* " + onlyThrees.size() + " t* "
		-- 		+ fours.size());

end

function CardHints:tip(isMustOut)  
		if (self.lastPlayedCardsType ~= Cardutl.TYPE_CARD_ERROR and self.lastPlayedCardValues ~= nil and #self.lastPlayedCardValues > 0) then
			if (#self.bigger == 0) then
				if (self.lastPlayedCardsType == Cardutl.TYPE_SINGLE or self.lastPlayedCardsType == Cardutl.TYPE_DOUBLE
						or self.lastPlayedCardsType == Cardutl.TYPE_BOMB_4 or self.lastPlayedCardsType == Cardutl.TYPE_BOMB_KING) then
					return false;
				elseif (not self.hasSwt) then
					-- if (self.lastPlayedCardsType == TYPE_DOUBLES or self.lastPlayedCardsType == TYPE_THREE_0 or
					-- self.lastPlayedCardsType == TYPE_THREE_1
					-- or self.lastPlayedCardsType == TYPE_THREE_2) {
					-- }
					return false;
				end
				return true;
			else
				-- self:showTip(isMustOut);
				return true;
			end
		else
			--return tipNewTurnOut();
		end
end
	

function CardHints:hasBigger()  
		if (self.lastPlayedCardsType > 0 and self.lastPlayedCardValues ~= nil and #self.lastPlayedCardValues > 0) then
			if (#self.bigger == 0)  then
				if (self.lastPlayedCardsType == Cardutl.TYPE_SINGLE or self.lastPlayedCardsType == Cardutl.TYPE_DOUBLE
						or self.lastPlayedCardsType == Cardutl.TYPE_BOMB_4 or self.lastPlayedCardsType == Cardutl.TYPE_BOMB_KING) then
					return false;
				elseif (not self.hasSwt) then
					-- if (self.lastPlayedCardsType == TYPE_DOUBLES or self.lastPlayedCardsType == TYPE_THREE_0 or
					-- self.lastPlayedCardsType == TYPE_THREE_1
					-- or self.lastPlayedCardsType == TYPE_THREE_2) {
					-- }
					return false;
				end
				return true;
			end
		end
		return true;
	end

 
--
function CardHints:getBigger() 
	self.bigger = {}
	self.bigIndex = 1;
	local case = self.lastPlayedCardsType
	if case ==	Cardutl.TYPE_SINGLE then
			self:bigSingle(); 
	elseif case	== Cardutl.TYPE_DOUBLE then
			self:bigDouble(); 
	elseif case	== Cardutl.TYPE_STRAIGHT then
			self:bigStraight(); 
	elseif case	== Cardutl.TYPE_DOUBLES then
			self:bigDoubles(); 
	elseif case	== Cardutl.TYPE_THREE_0 then
			self:bigThree(0); 
	elseif case	== Cardutl.TYPE_THREE_1 then
			self:bigThree(1); 
	elseif case	== Cardutl.TYPE_THREE_2 then
			self:bigThree(2); 
	elseif case	== Cardutl.TYPE_PLANE_0 then
			self:bigPlane0(self.lastPlayedCardValues); 
	elseif case	== Cardutl.TYPE_PLANE_1 then
			self:bigPlane1(self.lastPlayedCardValues); 
	elseif case	== Cardutl.TYPE_PLANE_2 then
			self:bigPlane2(self.lastPlayedCardValues); 
	elseif case	== Cardutl.TYPE_FOUR_1 then
			self:bigFour1() ; 
	elseif case	== Cardutl.TYPE_FOUR_2 then
			self:bigFour2() ; 
	elseif case	== Cardutl.TYPE_BOMB_4 then
			self:bigBomb4(self.lastPlayedCardValues[1]); 
	elseif case	== Cardutl.TYPE_BOMB_KING then
	end
 
	print("self.bigger", "last type " .. self.lastPlayedCardsType.. " self.bigger size " .. #self.bigger);
end
 

	--/** 上家单张,提示 **/
function CardHints:bigSingle()  
	print('bigSingle')
	local lastValue = self.lastPlayedCardValues[1];
	printf("lastValue:%s",lastValue)
	printf("using self.onlySingle...")
	self:addBiggerSingle(self.onlySingle, lastValue) ;
	printf("using self.onlyDoubles...")
	self:addBiggerSingle(self.onlyDoubles, lastValue) ;
	printf("using self.onlyThrees...")
	self:addBiggerSingle(self.onlyThrees, lastValue) ;
	--/** 炸弹 */
	self:bigBomb4(-1);
end

function CardHints:addBiggerSingle(  cards,   lastValue ) 
		print('addBiggerSingle')
		printf('lastValue:%s',lastValue)
		dump(cards,'scanning...')
		local cLen = #cards 
		--/** 单张 **/
		-- printf("cLen:%s",cLen)
		for i=cLen,1,-1 do
			-- print("i:",i)
			local card = cards[i]
			local typeT = Cardutl.GetCardType(card);
			local typeV = Cardutl.GetCardValue(card);
 

			if (typeT == 0) then
				typeV  = typeV+ 0x0F;
			end 
			if (lastValue < 3) then
				lastValue  = lastValue + 0x0F;
			end
			printf("typeV:%s,lastValue:%s",typeV,lastValue)
			if (typeV > lastValue) and  lastValue > 2  then
				local big = {}
				table.insert(big,card)
				table.insert(self.bigger,big) 
			end
			--大小王判断。
			if lastValue <= 2 then 
				if typeT <= 0 and (typeV > lastValue) then  
					local big = {}
					table.insert(big,card)
					table.insert(self.bigger,big) 
				end
			end

		end
		 
end
	
	--/** 上家对子,提示 **/
function CardHints:bigDouble()  
		local lastValue = self.lastPlayedCardValues[1];

		local len = #self.onlyDoubles
		--/** 对子 **/
		if (#self.onlyDoubles > 0) then
			for i=len,1,-1 do
				local typeValue = Cardutl.GetCardValue(self.onlyDoubles[i]);
				if (typeValue > lastValue) then
					local big = {}
					self:addBigCards(big, 2, typeValue);
					table.insert(self.bigger,big) 
				end
			end 

		end
		
		if (#self.onlyThrees > 0) then
			for i=#self.onlyThrees,1,-1 do 
				local typeValue = Cardutl.GetCardValue(self.onlyThrees[i]);
				if (typeValue > lastValue) then
					local big = {}
					self:addBigCards(big, 2, typeValue);
					table.insert(self.bigger,big)
				end
			end
		end

		if (self.hasSwt) then
			if (#self.allSingle > 0) then
				local singleLen = #self.allSingle; 
				for i=singleLen,1,-1 do 
					local typeValue = Cardutl.GetCardValue(self.allSingle[i]);
					if (typeValue > lastValue) then
						local big = {}
						table.insert(big,self.handCardTable[1]) 
						self:addBigCards(big, 1, typeValue);
						table.insert(self.bigger,big)
					end
				end
			end
		end

		self:bigBomb4(-1);
end

function CardHints:sortBigger()
	local function sortF(a, b)
		if a[1] == 0x50 then
			if b[1] ~= 0x50 then
				return false
			else
				return Cardutl.GetCardValue(a[2]) < Cardutl.GetCardValue(b[2])
			end
		end 

		if a[1] ~= 0x50 then
			if b[1] == 0x50 then
				return true
			else
				return Cardutl.GetCardValue(a[1]) < Cardutl.GetCardValue(b[1])
			end
		end

		return true
	end 
	table.sort(self.bigger, sortF)
end

	--/** 上家顺子,提示 */
function CardHints:bigStraight() 
		local len = #self.lastPlayedCardValues

		-- if (self.lastPlayedCardValues[1] >= 0x0E) then
		-- 	return
		-- end
		-- if self.hasSwt == false and (#self.allSingle < len) then
		-- 	return
		-- end
		-- if self.hasSwt and ((#self.allSingle+1) < len) then
		-- 	return
		-- end
		local singleLen = #self.allSingle;

		for i=(self.lastPlayedCardValues[#self.lastPlayedCardValues]+1), 0x0E-len+1 do
			self:checkBigStraight(i, len)
		end
		
		self:sortBigger();
 
		self:bigBomb4(-1);
end

function CardHints:checkBigStraight(start, num)
	local big = {}
	local lostNum, _ = self:getCardsLostNum(self.allSingle, start, num)
	if lostNum == 0 then
		for i=start,start+num-1 do 
			self:addBigCards(big, 1, i) 
		end
	end
	if self.hasSwt and lostNum == 1 then
		table.insert(big,self.handCardTable[1])
		for i=start,start+num-1 do 
			self:addBigCards(big, 1, i) 
		end
	end
	if #big == num then
		table.insert(self.bigger, big)
	end
end

function CardHints:getCardsLostNum(cards, start, num)  
	local lostNum = 0
	local lostTable = {}
	for i=start,start+num-1 do 
		if self:findCardsHave(cards, i) == false then
			lostNum = lostNum + 1
			table.insert(lostTable, i)
		end
	end

	return lostNum, lostTable
end

function CardHints:findCardsHave(cards, value)  
	local len = #cards;
	for i=1,len do 
		local temp = Cardutl.GetCardValue(cards[i])
		if temp == value then
			return true
		end
	end
	return false
end

	--/** 上家连对,提示 */1
function CardHints:bigDoubles()  
	local len = #self.lastPlayedCardValues / 2 ;
	local dLen = #self.allDoubles;
	--申翰兴暂时屏蔽连对提示
	-- if (self.lastPlayedCardValues[1] < 0x0E and dLen >= len) then 
	-- 	-- printf("entrting for loop")
	-- 	for i=1,dLen do  
	-- 		local typeV = Cardutl.GetCardValue(self.allDoubles[i]);
	-- 		-- printf("i:%s,typeV:%s,self.lastPlayedCardValues[1]:%s,(i+len - 1):%s,dLen:%s",i,typeV,self.lastPlayedCardValues[1],(i+len - 1),dLen)
	-- 		if (typeV > self.lastPlayedCardValues[1] and typeV <= 0x0E and (i+len - 1)<=dLen) then 
	-- 				-- printf("i:%s + len%s - 1 = %s",i , len,(i + len - 1))
	-- 				-- dump(self.allDoubles,"self.allDoubles")
	-- 			if ((typeV - (len -1 )) == Cardutl.GetCardValue(self.allDoubles[i + (len -1  )])) then
	-- 				local big = {}
	-- 				for j=i,i + len - 1 do 
	-- 					-- print("j:",j)
	-- 					self:addBigCards(big, 2, Cardutl.GetCardValue(self.allDoubles[j]));
	-- 				end
	-- 				table.insert(self.bigger,big)
	-- 			end
	-- 		end
	-- 	end
	-- end

	for i=(self.lastPlayedCardValues[#self.lastPlayedCardValues]+1), 0x0E-len+1 do
		self:checkBigDoubles(i, len)
	end
	self:sortBigger()

	self:bigBomb4(-1);
end

function CardHints:checkBigDoubles(start, num)  
	local big = {}
	local lostNum, lostTable = self:getCardsLostNum(self.allDoubles, start, num)
	if lostNum == 0 then
		for i=start,start+num-1 do 
			self:addBigCards(big, 2, i) 
		end
	end
	if self.hasSwt and lostNum == 1 then
		if self:findCardsHave(self.allSingle, lostTable[1]) then
			table.insert(big,self.handCardTable[1])
			for i=start,start+num-1 do 
				self:addBigCards(big, 2, i) 
			end
		end
	end
	if (#big / 2) == num then
		table.insert(self.bigger, big)
	end
end

	--/** 上家三张,提示 */
function CardHints:bigThree(subNum)  
	local startValue = self.lastPlayedCardValues[1]
	for i=startValue+1, 0x0F do
		self:checkBigThree(i, subNum)
	end
	self:sortBigger()

	self:bigBomb4(-1);

	dump(self.bigger, "self.bigger")
end

function CardHints:checkBigThree(value, subNum) 
	local onlySLen = #self.onlySingle ;
	local allSLen = #self.allSingle ;
	local lostNum, lostTable = self:getCardsLostNum(self.onlyThrees, value, 1)
	if lostNum == 0 then ----判断三张有压过的情况
		if subNum == 0 then
			local big = {}
			self:addBigCards(big, 3, value)
			table.insert(self.bigger,big)
			return
		elseif subNum == 1 then
			if #self.onlySingle > 0 then
				local big = {}
				self:addBigCards(big, 3, value) 
				self:addBigCards(big, 1, Cardutl.GetCardValue(self.onlySingle[onlySLen]))
				table.insert(self.bigger,big)
				return
			else  
				for j=allSLen,1,-1 do
					local sv = Cardutl.GetCardValue(self.allSingle[j])
					if (sv ~= value) then
						local big = {}
						self:addBigCards(big, 3, value) 
						self:addBigCards(big, 1, sv)
						table.insert(self.bigger,big)
						return
					end
				end
			end
		elseif subNum == 2 then
			if #self.onlyDoubles > 0 then
				local big = {}
				self:addBigCards(big, 3, value) 
				self:addBigCards(big, 2, Cardutl.GetCardValue(self.onlyDoubles[#self.onlyDoubles]))
				table.insert(self.bigger,big)
				return
			else
				for j=#self.allDoubles,1,-1 do 
					if(Cardutl.GetCardValue(self.allDoubles[j]) ~= value)then
						local big = {}
						self:addBigCards(big, 3, value);
						self:addBigCards(big, 2, Cardutl.GetCardValue(self.allDoubles[j]));
						table.insert(self.bigger,big)
						return
					end
				end
			end
		end
	else
		----判断两张有压过的情况加上花
		local lostNum2, lostTable2 = self:getCardsLostNum(self.onlyDoubles, value, 1)
		if self.hasSwt and lostNum2 == 0 then
			if subNum == 0 then
				local big2 = {}
				table.insert(big2, self.handCardTable[1])
				self:addBigCards(big2, 2, value);
				table.insert(self.bigger,big2)
				return
			elseif subNum == 1 then
				if #self.onlySingle > 0 then
					local big2 = {}
					table.insert(big2, self.handCardTable[1])
					self:addBigCards(big2, 2, value);
					self:addBigCards(big2, 1, Cardutl.GetCardValue(self.onlySingle[onlySLen]))
					table.insert(self.bigger,big2)
					return
				else  
					for j=allSLen,1,-1 do
						local sv = Cardutl.GetCardValue(self.allSingle[j])
						if (sv ~= value) then
							local big2 = {}
							table.insert(big2, self.handCardTable[1])
							self:addBigCards(big2, 2, value);
							self:addBigCards(big2, 1, sv)
							table.insert(self.bigger,big2)
							return
						end
					end
				end
			elseif subNum == 2 then
				if #self.onlyDoubles > 0 then
					local big2 = {}
					table.insert(big2, self.handCardTable[1])
					self:addBigCards(big2, 2, value);
					self:addBigCards(big2, 2, Cardutl.GetCardValue(self.onlyDoubles[#self.onlyDoubles]))
					table.insert(self.bigger,big2)
					return
				else
					for j=#self.allDoubles,1,-1 do 
						if(Cardutl.GetCardValue(self.allDoubles[j]) ~= value)then
							local big2 = {}
							table.insert(big2, self.handCardTable[1])
							self:addBigCards(big2, 2, value);
							self:addBigCards(big2, 2, Cardutl.GetCardValue(self.allDoubles[j]));
							table.insert(self.bigger,big2)
							return
						end
					end
				end
			end
		end
	end
end

function CardHints:bigPlane0( lastThree)  
	local tLen = #self.onlyThrees;
	local lastTLen = #lastThree / 3;
	local lastMinValue = lastThree[lastTLen * 3]
	----申翰兴注释掉大飞机提示
	-- if (tLen >= lastTLen) then 
	-- 	for i=tLen,1,-1 do 
	-- 		local continue = false
	-- 		local tValue = Cardutl.GetCardValue(self.onlyThrees[i]);
	-- 		if (tValue <= lastThree[1]) then
	-- 			continue = true
	-- 		end
	-- 		if continue == false then
	-- 			local tmp = (lastTLen - 1) ;
	-- 			printf("lastTLen:%s,i:%s,tmp:%s (i - tmp):%s ",lastTLen,i,tmp,(i - tmp))
	-- 			if ((i - tmp>= 1) and (tValue + tmp < 0x0F)
	-- 					and (tValue + tmp == Cardutl.GetCardValue(self.onlyThrees[i - tmp]))) then
	-- 				local big = {} 
	-- 				for j=i,i - lastTLen + 1,-1 do
	-- 					printf("j:%s",j)
	-- 					self:addBigCards(big, 3, Cardutl.GetCardValue(self.onlyThrees[j]));
	-- 				end
	-- 				table.insert(self.bigger,big)
	-- 			end
	-- 		end--continue == false
	-- 	end
	-- end

	for i=lastMinValue+lastTLen, 0x0E-lastTLen+1 do
		self:checkBigPlane(i, lastTLen, 0)
	end
	self:sortBigger()

	self:bigBomb4(-1);
end

function CardHints:checkBigPlane(start, num, subNum)  
	local big = {}
	local lostNum, lostTable = self:getCardsLostNum(self.onlyThrees, start, num)
	if lostNum == 0 then
		for i=start,start+num-1 do 
			self:addBigCards(big, 3, i) 
		end
		local isOk = self:addBigPlaneSubCards(big, start, num, subNum)
		if isOk then
			table.insert(self.bigger,big)
		end
	end

	if self.hasSwt and lostNum == 1 then
		local lostNum2, lostTable2 = self:getCardsLostNum(self.onlyDoubles, lostTable[1], 1)
		if lostNum2 == 0 then
			table.insert(big, self.handCardTable[1])
			for i=start,start+num-1 do 
				self:addBigCards(big, 3, i) 
			end
			local isOk = self:addBigPlaneSubCards(big, start, num, subNum)
			if isOk then
				table.insert(self.bigger,big)
			end
		end
	end
end

function CardHints:addBigPlaneSubCards(big, start, num, subNum)
	local onlySLen = #self.onlySingle
	local allSLen = #self.allSingle
	local onlyDLen = #self.onlyDoubles
	local allDLen = #self.allDoubles
	local onlyTLen = #self.onlyThrees
	if subNum == 0 then
		return true
	elseif subNum == 1 then
		if #self.onlySingle >= num then
			for i=1,num do
				self:addBigCards(big, 1, Cardutl.GetCardValue(self.onlySingle[onlySLen-i+1]))
			end
			return true
		else  
			local singleCards = self:getExceptCards(start, num)
			if #singleCards >= num then
				local leftNum = num
				for j=#singleCards,1,-1 do
					if leftNum > 0 then
						local card = singleCards[j]
						table.insert(big,card)
						leftNum = leftNum - 1
					end
				end
				return true
			end
		end
	elseif subNum == 2 then
		local doubleCards = self:getExceptOnlyDoubleCards(start, num)
		local threeCards = self:getExceptOnlyThreeCards(start, num)
		if #doubleCards + #threeCards >= num then
			local leftNum = num
			for j=#doubleCards,1,-1 do
				if leftNum > 0 then
					self:addBigCards(big, 2, doubleCards[j])
					leftNum = leftNum - 1
				end
			end
			for j=#threeCards,1,-1 do
				if leftNum > 0 then
					self:addBigCards(big, 2, threeCards[j])
					leftNum = leftNum - 1
				end
			end
			return true
		end
	end
end

--从onlyDoubles中取对，在satrt到start+num范围
function CardHints:getExceptOnlyDoubleCards(start, num)
	local result = {}
	for i=1, #self.onlyDoubles do
		local value = Cardutl.GetCardValue(self.onlyDoubles[i])
		if value < start or value >= start+num then
			table.insert(result, value)
		end
	end
	Cardutl.SortOutCards(result)
	return result
end
--从OnlyThree中取三张，在satrt到start+num范围
function CardHints:getExceptOnlyThreeCards(start, num)
	local result = {}
	for i=1, #self.onlyThrees do
		local value = Cardutl.GetCardValue(self.onlyThrees[i])
		if value < start or value >= start+num then
			table.insert(result, value)
		end
	end
	Cardutl.SortOutCards(result)
	return result
end

function CardHints:getExceptCards(start, num)  
	local result = {}
	for i=1, #self.handCardTable do
		local cardType = Cardutl.GetCardType(self.handCardTable[i])
		local value = Cardutl.GetCardValue(self.handCardTable[i])
		if cardType ~= Cardutl.CARD_SWT_TYPE then
			if value < start or value >= start+num then
				table.insert(result, self.handCardTable[i])
			end
		end
	end
	Cardutl.SortOutCards(result)
	return result
end

--两个三带一
function CardHints:bigPlane1(lastThree)  
	local tLen = #self.onlyThrees;
	local lastTLen = #lastThree / 4;
	local lastMinValue = lastThree[lastTLen * 3]

	for i=lastMinValue+lastTLen, 0x0E-lastTLen+1 do
		self:checkBigPlane(i, lastTLen, 1)
	end
	self:sortBigger()

	self:bigBomb4(-1);
end
--两个三带二
function CardHints:bigPlane2(lastThree) 
	local tLen = #self.onlyThrees;
	local lastTLen = #lastThree / 5;
	local lastMinValue = lastThree[lastTLen * 3]

	for i=lastMinValue+lastTLen, 0x0E-lastTLen+1 do
		self:checkBigPlane(i, lastTLen, 2)
	end
	self:sortBigger()

	self:bigBomb4(-1);
end
	
	--/**四带两单*/
function CardHints:bigFour1() 
		
		self:bigBomb4(-1);
end
	
	--/**四带两队*/
function CardHints:bigFour2() 
		
		self:bigBomb4(-1);
end

	--/** 上家四张炸弹,提示 */
function CardHints:bigBomb4(last)   
		local fSize = #self.fours;

		if (fSize > 0) then
			-- for (local i = fSize - 1; i >= 0; i--) {
			for i=fSize,1,-1 do
				local typeValue = Cardutl.GetCardValue(self.fours[i]);
				if (typeValue > last) then
					local big = {}
					self:addBigCards(big, 4, typeValue);
					table.insert(self.bigger,big)
				end
			end
		end

		if (self.hasSwt) then
			local tSize = #self.onlyThrees;

			if (tSize > 0) then
				for i=tSize,1,-1 do
					local typeValue = Cardutl.GetCardValue(self.onlyThrees[i]);
					if (typeValue > last) then
						local big = {} 
						table.insert(big,self.handCardTable[1])
						self:addBigCards(big, 3, typeValue);
						table.insert(self.bigger,big)
					end
				end
			end
		end

		self:addKingBomb();
end

	--/** 添加王炸 */
function CardHints:addKingBomb()  
		local size = #self.handCardTable
		if (size < 2) then
			return 
		end

		local delta = 0;
		for i=1,3 do  

			if (i <=size) then 
				local card = self.handCardTable[i];
				local cardType = Cardutl.GetCardType(card) 
				if ( cardType == Cardutl.CARD_KING_TYPE or  cardType == Cardutl.CARD_SWT_TYPE) then
					delta=delta+1 
				end
			end
		end

		if (delta == 2) then
			local big = {}
			table.insert(big,self.handCardTable[1])
			table.insert(big,self.handCardTable[2]) 
			table.insert(self.bigger,big)
		elseif (delta == 3) then
			local big = {}
			if (size == 3) then
				table.insert(big,self.handCardTable[1])
				table.insert(big,self.handCardTable[2])  
			else
				table.insert(big,self.handCardTable[2])
				table.insert(big,self.handCardTable[3]) 
			end
			table.insert(self.bigger,big)
		end
end

	--/** 普通牌添加 **/
function CardHints:addBigCards( big,   num,   _typeValue)  
		local cards = self.handCardTable
		local tempNum = 0;
		for k,card in pairs(cards) do 
			local typeType = Cardutl.GetCardType(card)
			local typeValue = Cardutl.GetCardValue(card)
			if (typeType >= 0 and typeValue == _typeValue) then 
				table.insert(big,card)
				tempNum=tempNum+1
				if (tempNum >= num)then
					break;
				end
			end
		end  
end