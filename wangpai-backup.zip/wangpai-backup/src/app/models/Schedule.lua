
local Schedule = class("Schedule", cc.load("mvc").ModelBase)
local scheduler = cc.Director:getInstance():getScheduler()

function Schedule:onCreate()
    self.schedules_ = {}

    return self
end

function Schedule:genCallback(hold, name, handler, scheduler)
    return function(dt)
        scheduler["elapsed"] = scheduler["elapsed"] + dt
        scheduler["count"] = scheduler["count"] + 1
--        printInfo("[Schedule:genCallback]dt = %f, elapsed = %f, count = %d", dt, scheduler["elapsed"], scheduler["count"])

        if scheduler["duration"] and scheduler["elapsed"] >= scheduler["duration"] then
            scheduler["elapsed"] = scheduler["duration"]
            scheduler["complete"] = true
            self:stopSchedule(hold, name or scheduler["scheduler"])
        end

        if handler then
            handler(dt, scheduler)
        end
    end
end

function Schedule:addSchedule(hold, name, handler, interval, duration)
    self.schedules_[hold] = self.schedules_[hold] or {}
    if name and self.schedules_[hold][name] then
        return self.schedules_[hold][name]["scheduler"]
    end

    local slot = {}
    local scheduler = scheduler:scheduleScriptFunc(self:genCallback(hold, name, handler, slot), interval, false)

    if name then
        self.schedules_[hold][name] = slot
    else
        self.schedules_[hold][scheduler] = slot
    end

    slot["duration"] = duration
    slot["elapsed"] = 0
    slot["count"] = 0
    slot["complete"] = false
    slot["scheduler"] = scheduler

    return scheduler
end

function Schedule:getSchedule(hold, name)
    return self.schedules_[hold] and self.schedules_[hold][name] or nil
end

function Schedule:stopSchedule(hold, name)
    if self.schedules_[hold] == nil then
    	return
    end

    -- printInfo("[Schedule:stopSchedule]hold.name = %s, name = %s", hold:getName(), name or "nil")

    if name == nil then
        for key, var in pairs(self.schedules_[hold]) do
            scheduler:unscheduleScriptEntry(var["scheduler"])
    	end
        self.schedules_[hold] = nil
    elseif self.schedules_[hold][name] then
        scheduler:unscheduleScriptEntry(self.schedules_[hold][name]["scheduler"])
        self.schedules_[hold][name] = nil
        
        if table.isEmpty(self.schedules_[hold]) then
        	self.schedules_[hold] = nil
        end
    end
end

return Schedule
