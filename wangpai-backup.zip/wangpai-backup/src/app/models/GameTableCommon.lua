 local GameTableCommon = class("GameTableCommon")
 
local DataPacker = require('app.network.DataPacker')
local HttpHandler = require("app.network.HttpHandler")
local DataUnpacker = require('app.network.DataUnpacker')
local scheduler = require("app.models.QScheduler")
GameTableCommon.NotifyToast       = 1
GameTableCommon.NotifyPopWindow   = 2
GameTableCommon.NotifyClose       = 3


GameTableCommon.TIP_NORMAL_PLAYER_TOAST     = 0x30
GameTableCommon.TIP_NORMAL_PLAYER_POP       = 0x31

GameTableCommon.SEX_MALE        = 0x00  -- 男
GameTableCommon.SEX_FEMALE      = 0x01  -- 女



GameTableCommon.ARRANGE_MIDDLE = 1
GameTableCommon.ARRANGE_LEFT = 2
GameTableCommon.ARRANGE_RIGHT = 3
GameTableCommon.bt_LotteryNode=nil
GameTableCommon.preLoadResources = 
{
    'ddzeffect.plist',
    'ddzfonts.plist',
    'ddzImage.plist',
    'ddzprops.plist',
    'bonb.plist',
    'shake.plist',
    'newcard.plist', 
}


GameTableCommon.selectRoomNameTable = 
{
    'UIMatchRoomDDZBooms',
    'UIMatchRoomDDZClassic',
    'UIMatchRoomDouniuZJH',
    'UIMatchRoomPoker',
    'UIMatchRoomRunFast',
    'UIMatchRoomShengJi', 
}
--更新金币，元宝
function GameTableCommon.REQ_UPDATE_PLAYER(delegate)
    local bufferHnd = DataPacker.new(delegate.CMD['UPDATE_PLAYER'])  
    delegate.tcpGear:sendData(bufferHnd:doPack())
end

function GameTableCommon.getPortByTableID(tableID)
    -- dump(TCPGearbox.serverConfig) 
    for k,v in pairs(TCPGearbox.serverConfig.config.sites.site) do 
        if tonumber(v.siteid) == tonumber(tableID) then 
            return v 
        end
    end
    -- body
end





GameTableCommon.DoniuTypeTable = 
{
     "nn0.png",-- "没牛",
     "nn1.png",-- "牛丁",
     "nn2.png",-- "牛2",
     "nn3.png",-- "牛3",
     "nn4.png",-- "牛4",
     "nn5.png",-- "牛5",
     "nn6.png",-- "牛6",
     "nn7.png",-- "牛7",
     "nn8.png",-- "牛8",
     "nn9.png",-- "牛9", 
     "nnn.png",-- "牛牛",
     "n4z.png",-- "四炸",
     "nwhn.png",-- "五花牛",
     "nwxn.png",-- "五小牛",

}
--发送好友请求
function GameTableCommon.sendFriendRequest(delegate, toUID )
    if delegate then 
        delegate:REQ_FRIENDREQUEST(toUID)
    end
end
--读取好友请求数据
function GameTableCommon.req_friendRequestRusult(delegate, toUID,agree )
    --agree 1, 同意 0 不同意 
    -- print('走到了这里')
    -- print(toUID)
    -- print(agree)
    if delegate and delegate.REQ_FRIENDREQUEST_RESULT then 
        delegate:REQ_FRIENDREQUEST_RESULT(toUID,agree )
    end
end 

--注册好友请求
function GameTableCommon.registerFriendRequest(delegate,reqCallback,resultCallback) 
    delegate['TCP_FRIEND_REQUEST'] = function(delegate,data)
        if reqCallback and delegate then 
            reqCallback(data)
        end
    end
    delegate['TCP_FRIEND_REQUEST_RESULT'] = function(delegate,data)
        if resultCallback and delegate then 
            resultCallback(data)
        end
    end
end

--更新金币，元宝
function GameTableCommon.updateGems(delegate, Gems ) 
    if delegate and delegate['AtlasLabel_myDimonds'] then 
        delegate['AtlasLabel_myDimonds']:setString(LuaTools.convertAmountChinese(Gems,10000))
    end
end
 
-- GameTableCommon.TIP_NORMAL_PLAYER_TOAST
-- GameTableCommon.TIP_NORMAL_PLAYER_POP  
function GameTableCommon.showMsgByMsgType(delegate,msgType,msg,data)
    LuaTools.stopWaiting()
    -- local isBankrupted = false
    if msg and ( string.find(msg,'金币不足') or string.find(msg,'金币低于') )then -- yeah, I am fuckn lazy, bite me!
        GameTableCommon.bankruptcyHelpEXEC(delegate ) 
        -- isBankrupted = true
        -- return
    end
    if data and data.siteid and data.siteid >0 then
        GameTableCommon.ForceToGoPreGame(delegate,data.siteid)
        return 
    end
    local blah = ""..cc.Director:getInstance():getTotalFrames()
    if msgType == GameTableCommon.NotifyToast or msgType == GameTableCommon.TIP_NORMAL_PLAYER_TOAST then
        G_BASEAPP:addView({
           uiName =  'UIAlert',
           uiInstanceName = blah
            },5000)
        :setupDialog('Infomation',msg) 
    else

        local b = G_BASEAPP:addView({
           uiName =  'UIDialog',
           uiInstanceName = ""..cc.Director:getInstance():getTotalFrames()
            }, 5200,1)

        if msgType == GameTableCommon.NotifyClose then
            delegate.tcpGear:closeAndRelease() 
            -- b['Button_Close']:setVisible(false)
        end
        local func  = function() 
            
            if  msgType == 17 and (delegate.taskGameType == 1 or delegate.taskGameType == 4 ) then 
                if delegate['Button_readyup']  then
                    delegate['Button_readyup']:setEnabled(true)
                end
                if delegate['Image_status_1'] then 
                    delegate['Image_status_1']:setVisible(false)
                end
            end
            

        end   
        if msgType == GameTableCommon.NotifyClose  then 
            GameTableCommon.quitComfirm(delegate,true)
        end
        b:setupDialog("信息",msg,func) 
 
    end
end

--登录成功显示准备和换桌
function GameTableCommon.handleLoginSuccess( delegate,data )
    -- body
    -- roomType
    local tableID = nil
    if delegate.taskGameType == 1 then 
        if data.roomType == 7 then  
            delegate['Button_changeTable']:setPositionX(-99999)
            delegate['Button_readyup']:setPositionX(display.center.x)
        end
    elseif delegate.taskGameType == 3 then 
        if data.tableType == 66 then  
            delegate['Button_changeTable']:setPositionX(-99999)
            delegate['Button_readyup']:setPositionX(display.center.x)
        end
    end 
    
end

--处理异常信息
function GameTableCommon.handleExceptionMsg(delegate,data)
    -- body
-- 金币低于
    LuaTools.stopWaiting()
    -- dump(data,"handleExceptionMsg")
    local isBankrupted = false
    local tempAAA = data.actionId or 0 
    if data 
    and data.failedStr 
    and not string.find(data.failedStr,'抢庄失败')  
    and ( string.find(data.failedStr,'金币不足') 
        or string.find(data.failedStr,'金币低于') )
    
    then -- yeah, I am fuckn lazy, bite me!  and tempAAA ~= 0x0A and tempAAA ~= 0x09
        GameTableCommon.bankruptcyHelpEXEC(delegate, tempAAA) 
        isBankrupted = true
        -- return
    end
    
    -- if  data.actionId == 0x07 and data.failedType == 1 then 
    --     G_BASEAPP:addView('UICommitment',99999999)
    -- end  

    -- if  data.actionId == 0x04 and data.failedType == 2 then 
    --     G_BASEAPP:addView('UICommitment',99999999)
    -- end  


    if data.siteid and data.siteid >0 then
        GameTableCommon.ForceToGoPreGame(delegate,data.siteid)
        return 
    end
    print('GameTableCommon.handleExceptionMsg')
    -- dump(delegate.CMD)
     local blah = ""..cc.Director:getInstance():getTotalFrames()
 

    if data.actionId == delegate.CMD['TABLE_LOGIN'] then
        print()
        delegate.tcpGear:closeAndRelease() 
        local blah = ""..cc.Director:getInstance():getTotalFrames()
        local b = G_BASEAPP:addView({
           uiName =  'UIDialog',
           uiInstanceName = ""..cc.Director:getInstance():getTotalFrames()
            }, 999999,1)

            -- b['Button_Close']:setVisible(false)
        local func  = function()
            GameTableCommon.quitComfirm(delegate,true)
        end   
        b:setupDialog("信息",data.failedStr,func)   
        return 
    else
        if data.actionId == delegate.CMD['READY'] or data.actionId == delegate.CMD['USER_READY'] then
            if delegate['Button_readyup']  then
                delegate['Button_readyup']:setEnabled(true)
            end
            if delegate['Image_status_1'] then 
                delegate['Image_status_1']:setVisible(false)
            end
            if isBankrupted then return end
        end
        local blah = ""..cc.Director:getInstance():getTotalFrames()
        local b = G_BASEAPP:addView({
           uiName =  'UIDialog',
           uiInstanceName = ""..cc.Director:getInstance():getTotalFrames()
            }, 5400,1) 
        local func  = function()

        end   
        b:setupDialog("信息",data.failedStr,func)   

    end

 
end

--强制踢人
function GameTableCommon.forceKickHandler(delegate,data)
    -- body 
    if delegate == nil then return end
    LuaTools.stopWaiting()
    delegate.tcpGear:closeAndRelease()  
    GameTableCommon.quitComfirm(delegate,true) 
    local b = G_BASEAPP:addView({
           uiName =  'UIDialog',
           uiInstanceName = ""..cc.Director:getInstance():getTotalFrames()
            }, 5200,1) 
            -- b['Button_Close']:setVisible(false)
        local func  = function() 
        end   
        b:setupDialog("注意",data.msg,func) 
 
end


--function GameTableCommon.
--获取奖励
function GameTableCommon.getBonus(tab,_callback)
     LuaTools.fastRequest(tab,_callback)
end

 -- " HEXCMD "    = "0x57"
 -- "BePlayerUID" = 61156365
 -- "CMD"         = 87
 -- "playerUID"   = 61434709

 --根据uid获取用户信息
function GameTableCommon.getPlayerByUid(delegate, uid )
  for k,v in pairs(delegate.playerData) do
      if v.Uid == uid or  v.UID == uid then
          return v  
      end
  end
end


function GameTableCommon.kickPlayer(delegate, data )
    if delegate == nil then return end
    local player = GameTableCommon.getPlayerByUid(delegate, data.playerUID )
    local bePlayer = GameTableCommon.getPlayerByUid(delegate, data.BePlayerUID )

    audio.playSound(Sound.SoundTable['sfx']['Kickout'] , false)
    local startKickPlayerNick = player.Name or player.nickName
    local beKickPlayerNick = bePlayer.Name or bePlayer.nickName

    if bePlayer.seatID == delegate.mySeatID then 
        GameTableCommon.quitComfirm(delegate,true) 
        local b = G_BASEAPP:addView({
           uiName =  'UIDialog',
           uiInstanceName = ""..cc.Director:getInstance():getTotalFrames()
            }, 5200,1) 
            -- b['Button_Close']:setVisible(false)
        local func  = function() 
        end   
        b:setupDialog("注意",string.format("您已被玩家 %s 踢出房间",startKickPlayerNick),func) 

    else 
        LuaTools.showAlert(string.format("%s已被玩家 %s 踢出房间",beKickPlayerNick,startKickPlayerNick))
        delegate:TCP_PLAYER_DISCONNECTED({Uid = data.BePlayerUID,seatID = bePlayer.seatID  })
    end
end

--玩家断网
function GameTableCommon.disconnectPlayer( delegate,seatID ) 
    local self = delegate
    local _player = delegate.playerData[seatID]
    local dealer =self.playerData[seatID].dealerLogo
    if dealer then
        dealer:removeFromParent()
        self.playerData[seatID].dealerLogo = nil
    end

    local cards = self.playerData[seatID].displayedCards
    if cards then 
        self.playerData[seatID].displayedCards:removeFromParent()
        self.playerData[seatID].displayedCards = nil
    end 
    -- body
end

--清桌
function  GameTableCommon.clearTable( delegate ) 
    local self = delegate
     for k,v in pairs(self.playerData) do 
        local dealer =self.playerData[k].dealerLogo
        if dealer then
            dealer:removeFromParent()
            self.playerData[k].dealerLogo = nil
        end
        if self.playerData[k].displayedCards ~= nil then
            self.playerData[k].displayedCards:removeFromParent()
            self.playerData[k].displayedCards = nil
        end 
    end
end

--设置地主
function GameTableCommon.setupDealer(delegate,seatID)
     -- bodyD:\celebritypoker\YZDDZ\cocosstudio\zjh\dealer.png
     dump(delegate,"GameTableCommon:setupDealer")
    local self = delegate
     for k,v in pairs(self.playerData) do
        if seatID == v.seatID then
            self.playerData[k].isDealer = true
            local dealer =self.playerData[k].dealerLogo
            if dealer then
                dealer:removeFromParent()
                self.playerData[k].dealerLogo = nil
            end

            dealer =  cc.Sprite:createWithSpriteFrameName('common/dealer.png')
            self.playerData[k].dealerLogo = dealer
            dealer:setName('dealer')
            self:addChild(dealer)
            local Pos =  self['Panel_player_'..v.displayID]:getChildByName('Image_avatar'):convertToWorldSpaceAR(cc.p(0,0))
            local posX = Pos.x
            local posY = Pos.y
            local offset = 15
            posX = posX - self['Panel_player_'..v.displayID]:getChildByName('Image_avatar'):getContentSize().width / 2 +offset
            posY = posY + self['Panel_player_'..v.displayID]:getChildByName('Image_avatar'):getContentSize().height / 2 - offset


            dealer:setPositionX(posX)
            dealer:setPositionY(posY)
        else

            local dealer =self.playerData[k].dealerLogo
            if dealer then
                dealer:removeFromParent()
                self.playerData[k].dealerLogo = nil
            end
        end
     end 
    
end 

function GameTableCommon.setVIP(delegate, viplvl,viptype,displayID )

    local self = delegate
    local vipNode = self['Panel_player_'..displayID]:getChildByName("Image_vip") 
    vipNode:setVisible(false)
    if viptype > 0 and viplvl > 0 then 
        vipNode:setVisible(true)
        local vipBG = 'common/icon_vip_bg_'..(viptype - 1 )..'.png'
        local viplv = "V"..viplvl
        printf('vipBG:%s,viplv:%s',vipBG,viplv)
        vipNode:loadTexture(vipBG,ccui.TextureResType.plistType)
        vipNode:getChildByName("BitmapFontLabel_lvl"):setString(viplv) 
    end
end

--设置头像
function GameTableCommon.setAvatar(delegate,avatarURL,displayID,_sex)
    local self = delegate
    if avatarURL and avatarURL~="" then
        if self['Panel_player_'..displayID].avatarChild then 
            self['Panel_player_'..displayID].avatarChild:removeFromParent()
            self['Panel_player_'..displayID].avatarChild = nil
        end
        local iconUrl = self['Panel_player_'..displayID]:getChildByName("Image_avatar")  
        local newName = self.icon
        local function onFinishTable(status,downloadedSize,dst) 
            if status == "success" then
                -- iconUrl:loadTexture(dst,ccui.TextureResType.localType)

                local newSprite = cc.Sprite:create(dst)
                local maskSprite = cc.Sprite:createWithSpriteFrameName('common/circle.png') 
                local spriteItem = LuaTools.createMaskedSprite(newSprite, maskSprite) 
                -- self:addChild(spriteItem) 
                spriteItem:setScaleX(iconUrl:getContentSize().width / spriteItem:getContentSize().width)
                spriteItem:setScaleY(iconUrl:getContentSize().height / spriteItem:getContentSize().height)
                spriteItem:setAnchorPoint(0,0)
                iconUrl:addChild(spriteItem) 
                self['Panel_player_'..displayID].avatarChild  = spriteItem
            else 
                print('获取好友头像失败')
            end
        end 
        LuaTools.getFileFromUrl({
            url =  avatarURL,
            destFile = ( avatarURL:gsub("/","_")),
            onFinishTable = onFinishTable
            }) 
    else
        local sex = self['Panel_player_'..displayID]:getChildByName("Image_avatar")
        local sexPath = "common/default_avater_man.png"
    
        if _sex== GameTableCommon.SEX_FEMALE then 
            sexPath = "common/default_avater_woman.png"
            -- local sex = self['Panel_player_'..v.displayID]:getChildByName("Image_avatar") 
            -- sex:loadTexture("common/Room_female_head.png",ccui.TextureResType.plistType) 
        end
    
        local newSprite = cc.Sprite:createWithSpriteFrameName(sexPath)
        local maskSprite = cc.Sprite:createWithSpriteFrameName('common/circle.png') 
        local spriteItem = LuaTools.createMaskedSprite(newSprite, maskSprite) 
    
        spriteItem:setScaleX(sex:getContentSize().width / spriteItem:getContentSize().width)
        spriteItem:setScaleY(sex:getContentSize().height / spriteItem:getContentSize().height)
        spriteItem:setAnchorPoint(0,0)
        sex:addChild(spriteItem)
        self['Panel_player_'..displayID].avatarChild  = spriteItem
    
        -- sex:loadTexture(spriteItem) 
    
    end
end


--领取奖励倒计时
function GameTableCommon.startOrEndTime(delegate,kind) 
    -- local pData = G_BASEAPP:getData('PlayerData')
    -- --kind=1表示开始计时，kind =2 表示结束计时     宝箱按钮的名称需改为‘Button_rewardBox’ ，倒计时文本名：'Text_rewardBox_time'
    -- local total_time = {60,180,300,600,1200,1800} 

    -- local function countTime(time)
    --     local function  callback()       
    --             local minute = math.floor(time/60)
    --             local second = time - minute*60
    --             local temp = string.format("%02d:%02d",minute,second) 
    --             if  delegate['Text_rewardBox_time'] then 
    --                 delegate['Text_rewardBox_time']:setString(time >=1 and temp or '领取奖励')  
    --             else 
    --                 return     
    --             end
    --             --delegate['Button_rewardBox']:setEnabled(time<=0)
    --             time = time -1
    --             if time < 0 then 
    --                 if delegate['Panel_boxReward'] then 
    --                     if not delegate['Panel_boxReward']:getChildByName('newBoxLight') then 
    --                         GameTableCommon.bt_LotteryNode = cc.CSLoader:createNode('Animation_box.csb') 
    --                         GameTableCommon.bt_LotteryNode:setPosition(cc.p(delegate['Panel_boxReward']:getContentSize().width/2-4,delegate['Panel_boxReward']:getContentSize().height/2+1))
    --                         local action = cc.CSLoader:createTimeline('Animation_box.csb')
    --                         GameTableCommon.bt_LotteryNode:runAction(action)
    --                         GameTableCommon.bt_LotteryNode:setName('newBoxLight')
    --                         action:gotoFrameAndPlay(0,true)
    --                         delegate['Panel_boxReward']:addChild(GameTableCommon.bt_LotteryNode,10)  
    --                     end     
    --                     delegate['Panel_boxReward']:setVisible(true)
    --                     --delegate['Panel_boxReward']:getChildByName('Image_rotate'):runAction(cc.RepeatForever:create(cc.RotateBy:create(3,180)))
    --                     delegate['Button_rewardBox']:setVisible(false)

    --                 end     
    --                 if delegate and delegate.stopSchedule then
    --                     delegate:stopSchedule('BoxRewardScheduler')
    --                 else
    --                     printError("ERROR! BoxRewardScheduler stopSchedule") 
    --                     dump(delegate,"delegate")
    --                 end       
    --             end  
    --     end 
    --     delegate:createSchedule("BoxRewardScheduler", callback, 1)  
    -- end 


    -- if kind == 2 and delegate['Text_rewardBox_time'] then --结束计时
    --    time  = pData.getReward
    --    if not delegate['Text_rewardBox_time'] then 
    --       return 
    --    end  
    --    local s = delegate['Text_rewardBox_time']:getString()
    --    delegate:stopSchedule('BoxRewardScheduler')
       
    --    if not s or s=='' then return  end   

    --    if s == '领取奖励' then 
    --       clock = total_time[time]
    --    else 
    --       local a,b = tonumber(string.sub(s,1,2))*60,tonumber(string.sub(s,4,5))
    --       clock =total_time[time] - (a+b)
    --    end    
    -- end 
    
    -- local tab = {
    --     ['uid']    = pData.uid, 
    --     ['token']  = pData.token,
    --     ['type']   = kind, 
    --     ['time']   = time,
    --     ['clock']  = clock,
    --     ['cmd']    = HttpHandler.CMDTABLE.GET_ONLINE_TIME,
    -- }    
    -- delegate.bonusCount = 0
    -- local function  cbSuccess(arg)
    --      if kind == 1 and delegate['Button_rewardBox'] then 
    --         delegate.bonusCount = (arg.time == false and 1 or tonumber(arg.time))
    --         if delegate.bonusCount > 6 then 
    --            delegate['Button_rewardBox']:setVisible(false)
    --            return  
    --         end 
    --         pData.getReward =  delegate.bonusCount 
    --         local go_time = (arg.clock == false and 0 or tonumber(arg.clock))

    --         local left = total_time[ delegate.bonusCount]- go_time     
    --         countTime(left)  
    --      end    

    --      if delegate['Button_rewardBox'] and delegate.rewardBoxCallback == nil then  
    --              delegate.rewardBoxCallback = 
    --              function(event) 
    --                     if event.name == 'ended' then
    --                         local paTable =     {
    --                             ['uid']       = pData.uid, 
    --                             ['token']     = pData.token,
    --                             ['time']      =  delegate.bonusCount or 1,
    --                             ['cmd']       = HttpHandler.CMDTABLE.GET_ONLINE_REWARD,
    --                         }

    --                         printf('delegate.rewardBoxCallback ')
    --                         if delegate['Text_rewardBox_time']:getString() == '领取奖励' then 
    --                             delegate['Text_rewardBox_time']:setString('')
    --                             if delegate['Panel_boxReward'] then 
    --                                delegate['Panel_boxReward']:setVisible(false)
    --                                --delegate['Panel_boxReward']:getChildByName('Image_rotate'):stopAllActions()
    --                                delegate['Button_rewardBox']:setVisible(true)
    --                                audio.playSound(Sound.SoundTable['sfx']['Task'] , false)

    --                                --LuaTools.coinRain(delegate)
    --                             end   
    --                         else 
    --                             LuaTools.showAlert('领奖时间未到')
    --                             return
    --                         end     

    --                         printf('delegate.rewardBoxCallback ')
    --                         GameTableCommon.getBonus(paTable,function(arg)
    --                             dump(arg,"GameTableCommon") 
    --                             delegate.bonusCount =  delegate.bonusCount + 1 
    --                             pData.getReward =  delegate.bonusCount  
    --                             if delegate and delegate.bonusCount > 6 then 
    --                                 delegate['Button_rewardBox']:setVisible(false)
    --                                 delegate['Text_rewardBox_time']:setString('')
    --                                 return  
    --                             end  
    --                             countTime(total_time[ delegate.bonusCount]) 
    --                             if arg.coin then
    --                                 GameTableCommon.updatePlayerCoins(delegate, delegate.mySeatID,tonumber(arg.coin) ) 
    --                                 GameTableCommon.REQ_UPDATE_PLAYER(delegate)
    --                             end 
    --                             LuaTools.showAlert(tostring( arg.msg) )
    --                         end)
    --                     end
    --                  end
    --             delegate['Button_rewardBox']:onTouch(delegate.rewardBoxCallback)
    --             if delegate['Panel_boxReward'] then 
    --                 delegate['Panel_boxReward']:onTouch(delegate.rewardBoxCallback) 
    --             end     
    --       end       
    -- end    
    -- LuaTools.fastRequest(tab,cbSuccess)
end 


function GameTableCommon.getInfoByDisplayID(delegate,displayID)
    -- body
    if delegate.playerData then
        for k,v in pairs(delegate.playerData) do
            if displayID == v.displayID then
                return v
            end
        end
    end
end

function GameTableCommon.toggleHelp(delegate,visible)
    delegate.helpPanelVisible = visible or not delegate.helpPanelVisible 
    if delegate['Panel_help']then
        delegate['Panel_help']:setVisible(delegate.helpPanelVisible)
    end
end

function GameTableCommon.setupHelpPanel( baseDelegate,delegate )
        -- Panel_help
    if baseDelegate['Panel_help'] then 
        delegate['Panel_help'] = baseDelegate['Panel_help']:clone()
        delegate:addChild(delegate['Panel_help'],1500,1500)
        -- delegate['Panel_help']:setVisible(true)
        delegate['Panel_help']:onTouch(function ( event )
            if event.name == 'ended' then
                GameTableCommon.toggleHelp(delegate,false)
            end
        end)
    end
    delegate.helpPanelVisible = false
end

--玩家发送聊天信息
function GameTableCommon.handleChat(delegate,tbl)
    if tbl.msgType == 1 then -- emoji
        if delegate.REQ_EMOJI then
            delegate:REQ_EMOJI(tbl.msg)
        elseif delegate.REQ_CHAT_TEXT_CONSTANCE then
            delegate:REQ_CHAT_TEXT_CONSTANCE(tbl)
        end
    elseif tbl.msgType == 2 then --static text
        if delegate.REQ_CONST_TEXT then
            delegate:REQ_CONST_TEXT(tbl.msg)
        elseif delegate.REQ_CHAT_TEXT_CONSTANCE then
            delegate:REQ_CHAT_TEXT_CONSTANCE(tbl)
        end
    else -- string 
        if delegate.REQ_CHAT then
            delegate:REQ_CHAT(tbl.msg) 
        end
    end
end

function GameTableCommon.playSound(delegate,seatID, str )
    if delegate.playerData[seatID] then 
        local sex = delegate.playerData[seatID].Sex or delegate.playerData[seatID].sex 
        local sexstr = 'male' 
        if sex == GameTableCommon.SEX_FEMALE then 
            sexstr = 'female' 
        end
        local prefix = Sound.SoundTable['prefix'][sexstr]
        local snd = Sound.SoundTable['voice'][sexstr][prefix..str] 
        printf('GameTableCommon.playSound ==> sex:(%s),playing:%s',sex,snd)  
        -- dump(delegate.playerData[seatID])
        audio.playSound(snd , false) 
    end
end

--生成排列的牌
function GameTableCommon.orbitCard(cardNode)
    cardNode:setVisible(true)
    local orbitTime = 0.5
    local backSprite = cc.Sprite:createWithSpriteFrameName('newcard/back.png')
    cardNode:addChild(backSprite)
    backSprite:setPositionX(cardNode:getContentSize().width * 0.5)
    backSprite:setPositionY(cardNode:getContentSize().height * 0.5)

    local arcX = cardNode:getAnchorPoint().x
    local arcY = cardNode:getAnchorPoint().y

    local originalScaleX = cardNode:getScaleX()
    local originalScaleY = cardNode:getScaleY()

    local originalPosX = cardNode:getPositionX()
    local originalPosY = cardNode:getPositionY()
    local function callback2()
        -- cardNode:loadTexture(image,ccui.TextureResType.plistType)

        cardNode:setAnchorPoint(cc.p(0.5,0.5))
        backSprite:removeFromParent()
    end

    local function callback3() 
        cardNode:setAnchorPoint(cc.p(arcX,arcY))  
        cardNode:setPositionX(originalPosX)
    end 
    cardNode:setAnchorPoint(cc.p(0.5,0.5))
    local newPosX = cardNode:getPositionX() - cardNode:getBoundingBox().width * (arcX - 0.5)
    cardNode:setPositionX(newPosX)
    -- cardNode:setPositionY()
   local orbit1 = cc.EaseExponentialOut:create(cc.ScaleTo:create(orbitTime * 0.5, 0.001, originalScaleY))
   local orbit2 = cc.EaseExponentialOut:create(cc.ScaleTo:create(orbitTime * 0.5, originalScaleX, originalScaleY) ) 
    cardNode:runAction(cc.Sequence:create(orbit1 ,cc.CallFunc:create(callback2),orbit2,cc.CallFunc:create(callback3)))
end

--用户信息插入桌
function GameTableCommon.insertPlayerToDisplayTable(delegate,data)
    local idx =   ( data.seatID  - delegate.mySeatID   ) + 1
    if idx <= 0 then 
        idx = #delegate.displayIDTable + idx
    end 
    if data.seatID == delegate.mySeatID then 
        delegate.displayIDTable[1] = true
        data.displayID = 1  
        data.I_am_Self = true;
        return 1 
    end   
    local v = delegate.displayIDTable[idx] 
    if v == false then 
        delegate.displayIDTable[idx] = true
        data.displayID = idx  
        return idx
    end 
end

--提示玩家返回上一次场
function GameTableCommon.ForceToGoPreGame(delegate,seatId)
    printf('ForceToGoPreGame')  
    delegate.tcpGear:closeAndRelease() 
    local info = G_BASEAPP:getData('Config').gameSeatIdInfo 
    dump(info)
    printf("seatId:%s",seatId)
    local text 
    for key,var in pairs(info) do 
        if tostring(seatId) == key then 
            text = var 
            break 
        end 
    end  
    if text then 
        text = '您正在'..text..'游戏,无法进入其他场次,点击确定自动进入该场。'  
             local d = G_BASEAPP:addView({
           uiName =  'UIDialog',
           uiInstanceName = ""..cc.Director:getInstance():getTotalFrames()
            }, 5200,1)
            d:setupDialog('', text, 
            function()   
                -- quit() 
                GameTableCommon.quitComfirm( delegate ,true)    
                G_BASEAPP:removeView({uiName = 'UIBroadcast', uiInstanceName = "forSanzhangUse"})
                if      string.find(text,'地主') then  
                    G_BASEAPP:callMethod('UIMainBottom','quickEnterWPDZ')               
                elseif   string.find(text,'斗牛') then  
                    G_BASEAPP:callMethod('UIMainBottom','setQuickStart', 'dn') 
                    G_BASEAPP:callMethod('UIMainBottom','quickStart')
                elseif   string.find(text,'三张') then   
                    G_BASEAPP:callMethod('UIMainBottom','setQuickStart', 'zjh') 
                    G_BASEAPP:callMethod('UIMainBottom','quickStart')

                elseif   string.find(text,'德州') then  
                    G_BASEAPP:callMethod('UIMainBottom','quickEnterPokerRoom', seatId)
                elseif   string.find(text,'炸翻天') then  
                    G_BASEAPP:callMethod('UIMainBottom','setQuickStart', 'ddz') 
                    G_BASEAPP:callMethod('UIMainBottom','quickStart')
                elseif   string.find(text,'升级') then  
                    G_BASEAPP:callMethod('UIMainBottom','quickEnterRunFast', seatId)
                elseif  string.find(text,'比赛') then   
                    G_BASEAPP:addView('UIAwards',999)    
                else 
                    return     
                end   
            end) 
    end 
end 


--处理卡牌动画
function GameTableCommon.dealCardAnimation( cardTable,onFinish )

    for k,cardNode in pairs(cardTable or {}) do
        cardNode:setVisible(false)
    end
    scheduler.performWithDelayGlobal(function()  

        local dealTime  =    0.5
        local Delay = 0.05
        for k,cardNode in pairs(cardTable or {}) do

        -- audio.playSound(Sound.SoundTable['sfx']['Fapai'] , false)
            cardNode.originalPos = cc.p(cardNode:getPosition()) 
            local nodeSpace = cardNode:getParent():convertToNodeSpace(display.center)
            cardNode:setPosition(nodeSpace)
            -- cardNode:setVisible(false) 
            local mvt = cc.EaseExponentialOut:create(cc.MoveTo:create(dealTime,cardNode.originalPos))
            local act = cc.Sequence:create(cc.DelayTime:create(tonumber(k) * Delay),cc.CallFunc:create(function()
                    audio.playSound(Sound.SoundTable['sfx']['Fapai'] , false)
                end) ,cc.Show:create(), mvt) 
            -- printf('START DEALING CARDS k:%s,#cardTable:%s',k,#cardTable)
            if k == #cardTable then
                act = cc.Sequence:create(cc.DelayTime:create(tonumber(k) * Delay),cc.Show:create(),mvt,cc.CallFunc:create(function()
                    -- printf('FINISH DEALING CARDS,onFinish:%s',onFinish)
                    if onFinish then
                        onFinish()
                    end
                end))            
            end
            cardNode:runAction(act)
        end 
    end,0.1)
end

--设置聊天返回信息
function GameTableCommon.setupChatCallbacks( delegate , _callback)
    delegate.TCP_PLAYER_CHAT_TEXT   = function(delegate,arg)
        dump(arg，'22222222222222222222222222')
        local ret = {}
        local d = delegate.playerData[arg.seatID].displayID
        ret.parentNode = delegate['Panel_player_'..d]:getChildByName('Image_avatar')
        ret.msgType = 3
        ret.msg = arg.msg
        ret.sex =  delegate.playerData[arg.seatID].sex or delegate.playerData[arg.seatID].Sex
        ret.name = delegate.playerData[arg.seatID].nickName or delegate.playerData[arg.seatID].Name
        if arg.seatID == delegate.mySeatID then
            ret.name = '我'
        end
        ret.isRight = (d == 2 or d == 3)
        if delegate.taskGameType == 1 or delegate.taskGameType == 4 then 
            ret.isRight = (d == 2 )
        end
        _callback(ret)  
    end

    delegate.TCP_PLAYER_CHAT_TEXT_CONSTANCE = function(delegate,arg)
        dump(arg,'TCP_PLAYER_CHAT_TEXT_CONSTANCE')
        local ret = {}
        local d = delegate.playerData[arg.seatID].displayID
        ret.parentNode = delegate['Panel_player_'..d]:getChildByName('Image_avatar')
        ret.msgType =  arg.type
        ret.msg =  arg.msgIdx 
        ret.name = delegate.playerData[arg.seatID].nickName or delegate.playerData[arg.seatID].Name
        ret.sex =  delegate.playerData[arg.seatID].sex or delegate.playerData[arg.seatID].Sex
        if arg.seatID == delegate.mySeatID then
            ret.name = '我'
        end
        ret.isRight = (d == 2 or d == 3)
        if delegate.taskGameType == 1 or delegate.taskGameType == 4 then 
            ret.isRight = (d == 2 )
        end
        _callback(ret)  
    end

    delegate.TCP_CHAT   = function(delegate,arg)
        dump(arg)
        -- playerUID
        local ret = {}
        local d = GameTableCommon.getPlayerByUid(delegate,arg.playerUID).displayID 
        local _player = GameTableCommon.getPlayerByUid(delegate,arg.playerUID)
        ret.sex =  _player.sex or _player.Sex
        ret.parentNode = delegate['Panel_player_'..d]:getChildByName('Image_avatar')
        ret.msgType =  3
        ret.msg =  arg.msg 
        ret.name = _player.nickName or _player.Name

        if _player.seatID == delegate.mySeatID then
            ret.name = '我'
        end
        ret.isRight = (d == 2 or d == 3)
        if delegate.taskGameType == 1 or delegate.taskGameType == 4 then 
            ret.isRight = (d == 2 )
        end
        _callback(ret)  
    end

    delegate.TCP_EMOJI  = function(delegate,arg)
        dump(arg)
        local ret = {} 
        local d = GameTableCommon.getPlayerByUid(delegate,arg.playerUID).displayID 
        local _player = GameTableCommon.getPlayerByUid(delegate,arg.playerUID)
        ret.parentNode = delegate['Panel_player_'..d]:getChildByName('Image_avatar')
        ret.msgType =  1
        ret.msg =  arg.msg 
        ret.sex =  _player.sex or _player.Sex
        ret.name = _player.nickName or _player.Name
        if _player.seatID == delegate.mySeatID then
            ret.name = '我'
        end
        ret.isRight = (d == 2 or d == 3)
        if delegate.taskGameType == 1 or delegate.taskGameType == 4 then  
            ret.isRight = (d == 2 )
        end
        _callback(ret)  
    end

    delegate.TCP_CONST_TEXT = function(delegate,arg)
        dump(arg)
        local ret = {}
        local d = GameTableCommon.getPlayerByUid(delegate,arg.playerUID).displayID 
        local _player = GameTableCommon.getPlayerByUid(delegate,arg.playerUID)
        ret.parentNode = delegate['Panel_player_'..d]:getChildByName('Image_avatar')
        ret.msgType =  2
        ret.msg =  arg.msg 
        ret.sex =  _player.sex or _player.Sex
        ret.name = _player.nickName or _player.Name
        if _player.seatID == delegate.mySeatID then
            ret.name = '我'
        end
        ret.isRight = (d == 2 or d == 3)
        if delegate.taskGameType == 1 or delegate.taskGameType == 4 then  
            ret.isRight = (d == 2 )
        end
        _callback(ret)  
    end

end

--翻牌自己的牌
function GameTableCommon.setupPOVCards(delegate, cards,extraArgs,cardNums )
    local self = delegate
    for i=1,cardNums do
        self['Button_card_'..i]:setVisible(true)
        self['Button_card_'..i]:loadTextures('newcard/back.png','newcard/back.png','newcard/back.png',ccui.TextureResType.plistType)
    end
    self.playerData[self.mySeatID].Cards = cards
    for k,v in pairs(cards) do
        --print(k,v)
        self['Button_card_'..k]:setVisible(true) 
        self['Button_card_'..k].val = v  
        local path = Cardutl.getPathForCard( v,nil,nil,"Douniu" )
        --print(path)
        self['Button_card_'..k]:loadTextures(path,path,path,ccui.TextureResType.plistType)
    end

    if extraArgs and extraArgs.useAnimation == true then 
        if extraArgs.animationType == 'deal' then
            local tbl = {}
            for i=1,cardNums do
                table.insert(tbl, self['Button_card_'..i])
            end
            GameTableCommon.dealCardAnimation( tbl, extraArgs.onFinishCallback)
        elseif extraArgs.animationType == 'orbit' then
            for k,v in pairs(extraArgs.animationOrbitIdxTable or {}) do 
                GameTableCommon.orbitCard(self['Button_card_'..v])
            end
        end
    end
end

--显示卡牌自己和别人
function GameTableCommon.showCards(delegate,seatID,cards,showType,_type,extraArgs)
    local self = delegate
    local arrangeType = GameTableCommon.ARRANGE_MIDDLE
    local displayID = self.playerData[seatID].displayID
    self.playerData[seatID].Cards = cards
    if self.playerData[seatID].displayedCards ~= nil then
       self.playerData[seatID].displayedCards:removeFromParent()
       self.playerData[seatID].displayedCards = nil
    end


    if displayID == 2 or displayID == 3 then
        arrangeType = GameTableCommon.ARRANGE_RIGHT
    elseif displayID == 4 or displayID == 5 then 
        arrangeType = GameTableCommon.ARRANGE_LEFT
    end
    local cards = self:arrangeCards(arrangeType,cards,nil,extraArgs)
    self.playerData[seatID].displayedCards = cards 
    local cardNode = self['Panel_player_'..displayID]:getChildByName('Image_card')
    cards:setPositionX(cardNode:getPositionX())
    cards:setPositionY(cardNode:getPositionY())

    cards:setScaleX(cardNode:getScaleX())
    cards:setScaleY(cardNode:getScaleY())
    cards:setLocalZOrder(cardNode:getLocalZOrder()-1)
    -- cards:setGlobalZOrder(cardNode:getGlobalZOrder())


    cardNode:getParent():addChild(cards)
end

--把牌居中排列起来
function GameTableCommon.alignItemsHorizontallyWithPadding(padding,childredTable) 
    local width = -padding; 
    for k,child in pairs(childredTable) do
        width  = width + child:getContentSize().width * child:getScaleX() + padding;
    end

    local x = -width / 2.0 ;
    
    for k,child in pairs(childredTable) do
        child:setPosition(x + child:getContentSize().width * child:getScaleX() / 2.0 , 0);
        x  = x+ child:getContentSize().width * child:getScaleX() + padding;
    end 
end

--卡牌的整理分类
function GameTableCommon.arrangeCards(delegate,arrangeType,cardCalueTable,_padding,extraArgs)

    local self = delegate
    local parent = display.newNode() 
    local spritePath = Cardutl.getPathForCard( cardCalueTable[1],nil,nil,'Douniu')  
    -- print("arrangeCards spritePath：",spritePath)
    local card = cc.Sprite:createWithSpriteFrameName(spritePath)
    local padding = card:getContentSize().width * 0.5
    local width =   padding * #cardCalueTable + card:getContentSize().width * card:getScaleX() 
    local aPoint = cc.p(0,0.5) 
    if arrangeType == GameTableCommon.ARRANGE_RIGHT then 
        aPoint = cc.p(0,0.5)
    elseif  arrangeType == GameTableCommon.ARRANGE_MIDDLE then 
        aPoint = cc.p(0.5,0.5)
    end

    local cardInstanceTable = {}
    -- dump(cardCalueTable,"cardCalueTable")
    for k=1, #cardCalueTable do
        local v = cardCalueTable[k]
        local spritePath = Cardutl.getPathForCard(v,nil,nil,'Douniu' ) 
        local card = cc.Sprite:createWithSpriteFrameName(spritePath)
        parent:addChild(card)  
        card:setAnchorPoint(aPoint)
        card:setTag(tonumber(k))   
        if arrangeType == GameTableCommon.ARRANGE_LEFT then
            card:setPosition(tonumber(k) * padding  - padding, 0); 
        elseif  arrangeType == GameTableCommon.ARRANGE_RIGHT  then  
            card:setPosition((tonumber(k)) * padding - width , 0); 
        end
        table.insert(cardInstanceTable,card)
        local p = card:convertToWorldSpaceAR(cc.p(0,0))
        -- printf('arrangeCards(%s):(%s,%s)',k,p.x,p.y )
    end
    if arrangeType == GameTableCommon.ARRANGE_MIDDLE then 
        GameTableCommon.alignItemsHorizontallyWithPadding(_padding or -80,cardInstanceTable)
    end

    -- dump(extraArgs,"extraArgs")

    if extraArgs == nil then 
        -- printError('extraArgs is nil')
    end

    if extraArgs and extraArgs.useAnimation == true then
        if extraArgs.animationType == 'deal' then 
            GameTableCommon.dealCardAnimation( cardInstanceTable,extraArgs.onFinishCallback )
        elseif extraArgs.animationType == 'orbit' then
            for k,v in pairs(extraArgs.animationOrbitIdxTable or {}) do
                -- printf('cardCalueTable[%s] = %s',v,cardCalueTable[v])
                GameTableCommon.orbitCard(cardInstanceTable[v])
            end
        end
    end

    return parent 
end

--更新用户金币
function GameTableCommon.updatePlayerCoinsByPlayerUID(delegate, uid,curCoin,isDelta )
    local seatID = GameTableCommon.getPlayerByUid(delegate,uid).seatID
    return GameTableCommon.updatePlayerCoins(delegate, seatID,curCoin,isDelta  )
end
 
--更新用户金币
function GameTableCommon.updatePlayerCoins(delegate, seatID,curCoin,isDelta,dontShowBankcrupt ,aaaaa )
    local self = delegate
    --printError('calling GameTableCommon.updatePlayerCoins')
    printf("updatePlayerCoins:isDelta:%s",isDelta) 
    printf('updatePlayerCoins:seatID:%s,curCoin:%s',seatID,curCoin) 
    printf('updatePlayerCoins:seatID:%s,displayID:%s, curCoin:%s',seatID,self.playerData[seatID].displayID ,curCoin)
    if isDelta then 
        self.playerData[seatID].totalCoins = self.playerData[seatID].totalCoins  + curCoin 
    else 
        self.playerData[seatID].totalCoins = curCoin 
    end
    local coin = self['Panel_player_'..self.playerData[seatID].displayID]:getChildByName("Text_coins")
    if seatID == self.mySeatID then
        self.PlayerData.coin = self.playerData[seatID].totalCoins
        for _,name in pairs(GameTableCommon.selectRoomNameTable) do
            local view =  G_BASEAPP:getView(name)
            if view and view['updatePlayerCoin'] then 
                view:updatePlayerCoin()
            end
        end
        coin = self['AtlasLabel_myCoins']
        printf('self.PlayerData.coin :%s',self.PlayerData.coin )
        printf("updatePlayerCoins:DONT SHOW BANKCRUPT :%s",dontShowBankcrupt)
        if self.playerData[seatID].totalCoins <= 0 and dontShowBankcrupt ~= true  and aaaaa ~= 1 then 
            GameTableCommon.bankruptcyHelp(function (data)
                local val = data.coin 
                printf("bankruptcyHelp val:%s",val)
                self.playerData[seatID].totalCoins = val + self.playerData[seatID].totalCoins
                self.PlayerData.coin = self.playerData[seatID].totalCoins  
                if data.gem then 
                    self.PlayerData.gem = data.gem 
                    GameTableCommon.updateGems(delegate,data.gem)
                end
                if coin then
                    coin:setString(LuaTools.convertAmountChinese(self.playerData[seatID].totalCoins,10000)) 
                end
                GameTableCommon.REQ_UPDATE_PLAYER(delegate)
            end)
             
        end
    end
    if coin then
        coin:setString(LuaTools.convertAmountChinese(self.playerData[seatID].totalCoins,10000)) 
    end
end

function GameTableCommon.getLastDelegate() 
    return  GameTableCommon.lastDelegate
end

--设置基础信息
function GameTableCommon.setupBasics( delegate ) 
    GameTableCommon.IS_IN_TABLE = true
    GameTableCommon.lastDelegate = delegate
    local spriteFrameCache = cc.SpriteFrameCache:getInstance()
    spriteFrameCache:addSpriteFrames("common.plist")
    spriteFrameCache:addSpriteFrames("res_chat.plist")

	--spriteFrameCache:addSpriteFrames("res_friendBrief.plist") 
    for k,v in pairs(GameTableCommon.preLoadResources) do 
        spriteFrameCache:addSpriteFrames(v)
    end
    
    if delegate['Button_jijin'] then
		delegate['Button_jijin']:setVisible(false)
		delegate['Button_jijin']:setTouchEnabled(false)
    end
    if delegate.taskGameType == 1 and  delegate['Button_getPackets'] and  not delegate.isGameMatch then 
        local function csb1(coin) 
            GameTableCommon.updatePlayerCoinsByPlayerUID(delegate,G_UID,tab)
        end   
        G_BASEAPP:addView('UIActivityList',delegate:getLocalZOrder()+2,csb1)  
    end 


    audio.preloadSound(Sound.SoundTable['sfx']['Fapai'])
    if delegate['Image_tackNotification'] then 
       delegate['Image_tackNotification']:setVisible(false)
    end
    audio.stopAllSounds()
    audio.stopMusic(true)
    local bgmTable =
    {
        'MusicEx_Doudizhu' ,
        'MusicEx_Bullfight' ,
        'MusicEx_Sanzhang' ,
        'MusicEx_Pdk',
    } 
    local bgmPath = Sound.SoundTable['bgm'][bgmTable[delegate.taskGameType]]
    printf('bgmPath:%s',bgmPath)
    audio.playMusic(bgmPath,true)

    -------------------------------------------------------------------
    delegate['TCP_UPDATE_PLAYER'] = function(self,data)
        dump(data,'TCP_UPDATE_PLAYER')
        local seatID = 0 
        if self.taskGameType == 1 or self.taskGameType == 4 then 
            seatID = data.seatID
        else 
            seatID = GameTableCommon.getPlayerByUid(delegate,data.playerUID).seatID 
        end
        GameTableCommon.updatePlayerCoins(delegate, seatID,data.coins ) 
    end

    -- delegate:createSchedule("delayLoadMenu",function()
    --     delegate:stopSchedule('delayLoadMenu')
    --     local menuView = G_BASEAPP:addView('UIGameTableMenu', 1100,delegate)
    --     GameTableCommon.overrideBack( menuView , function()
    --         GameTableCommon.quitComfirm( delegate ) 
    --     end)

    --     LuaTools.beginWaiting(true)
    -- end,0.2)
    local menuView = G_BASEAPP:addView('UIGameTableMenu', 99999,delegate)
    GameTableCommon.overrideBack( menuView , function()
        GameTableCommon.quitComfirm( delegate ) 
    end)


    --setup Chats
    GameTableCommon.setupChatCallbacks( delegate , function(arg)
        -- if delegate:getChildByName('chat_record_new') then  
        --     arg.parentNode:stopAllActions()
        --     delegate:removeChildByName('chat_record_new')
        -- end  
        local size = arg.parentNode:getContentSize()
        local wPointPar =  arg.parentNode:convertToWorldSpace(cc.p(0,0))
        local logCount  = G_BASEAPP:getData('PlayerData').chatLogCount 
        logCount = logCount + 1 
        local chat_bg  
        if arg.msgType == 1 then  --表情 
            -- if delegate:getChildByName('chat_record_new') then 
            --     delegate:removeChildByName('chat_record_new') 
            -- end      
            chat_bg = ccui.ImageView:create(string.format('res_chat/faceicon%d.png',arg.msg),ccui.TextureResType.plistType)
            delegate:addChild(chat_bg,10086)

            chat_bg:setName('chat_record_new'..logCount) 
            chat_bg:setPosition(wPointPar.x+size.width/2,wPointPar.y+size.height/2) 
            --face:setLocalZOrder(199)
            local act1 = cc.ScaleTo:create(0.5,1.6)
            local act2 = cc.ScaleTo:create(0.5,1.2)  
            local act3 = act1:clone() 
            local act4 = act2:clone()
            chat_bg:runAction(cc.Sequence:create(act1,act2,act1:clone(),act2:clone(),act3,act4))
 
        else 
            local text_table = {'快点吧~我等得花儿都谢了',
                                '投降输一半，速度投降吧',
                                '你的牌打得太好了',
                                '吐了个槽的，整个一个杯具啊',
                                '天灵灵，地灵灵，给手好牌行不行',
                                '大清早的，鸡还没叫呢，慌什么嘛',
                                '不要走，决战到天亮',
                                '大家好，很高兴见到各位！',
                                '出来混，迟早要还的',
                                '再见了，我会想念大家的'} 
            local str = (arg.msgType ==2 and text_table[tonumber(arg.msg)] or arg.msg) 
            if arg.msgType ==2 then 
               local a = tonumber(arg.sex) == 1 and 'female' or 'male' 
               local b = tonumber(arg.sex) == 1 and 'Woman_Chat_' or 'Man_Chat_'
               audio.playSound(Sound.SoundTable['voice'][a][b..arg.msg],false)
            end    
            -- print('weny发送的左右位置=') 
            -- print(arg.isRight)
            local hisStr = arg.name..':'..str
            table.insert( G_BASEAPP:getData('PlayerData').faceIconRecord,hisStr)

            local chat_bg = ccui.ImageView:create(arg.isRight and 'room/Roomchatnormal1.png' or 'room/Roomchatnormal2.png',ccui.TextureResType.plistType) 
            delegate:addChild(chat_bg,10086) 

            chat_bg:setScale9Enabled(true)
            chat_bg:setCapInsets(cc.rect(31, 50, 32, 11))--(cc.rect(31, 31, 50, 21))
            
            chat_bg:setName('chat_record_new'..logCount) 
            
            local posX,posY = (arg.isRight==true and 0 or size.width) , size.height
            chat_bg:setPosition(wPointPar.x+posX/2+45,wPointPar.y+posY/2) 

            local text2 =  ccui.Text:create()
            text2:setFontSize(30)
            text2:setString(str) 
            val1 = text2:getVirtualRendererSize().width
            local bg_width = (val1>=500 and 500 or val1)
            local b = math.ceil(val1/500)+1 
            local textArea = ccui.Text:create()
            textArea:ignoreContentAdaptWithSize(false)
            textArea:setContentSize(cc.size(bg_width, b*30+10))
            textArea:setAnchorPoint(0,0.5)
            textArea:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT)
            textArea:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
            chat_bg:setContentSize(cc.size(bg_width+50, b*30+20))

            textArea:setString(str)
            textArea:setFontSize(30)
            textArea:setColor(cc.c3b(255,255,255))
            local myPosX = (arg.isRight and  (bg_width+20) or 30)
            textArea:setPosition(myPosX,chat_bg:getContentSize().height/2)
            if arg.isRight then
                textArea:setAnchorPoint(1,0.5)
                chat_bg:setAnchorPoint(1,0)
            else     
                textArea:setAnchorPoint(0,0.5)
                chat_bg:setAnchorPoint(0,0)
            end     
            chat_bg:addChild(textArea)
        end  
        local function  fadeAction()
             if delegate:getChildByName('chat_record_new'..logCount) then 
                delegate:removeChildByName('chat_record_new'..logCount)
             end    
             --chat_bg:removeFromParent()
        end     
        arg.parentNode:runAction(cc.Sequence:create(cc.DelayTime:create(3),cc.CallFunc:create(fadeAction)))

        --dump(arg,'setupChatCallbacks')
    end)

    -----------------------------------------------请求每日任务列表更新红点
    if delegate['Image_tackNotification']  then 
        local tab = {
            ['uid']      = G_UID, 
            ['token']    = G_TOKEN,
            ['gameType'] = 9, 
            ['version']  = UserCache.getUserDataByKey("task_version9") or '',
            ['cmd']      = HttpHandler.CMDTABLE.GET_TASK  
        }    
        if delegate['Image_tackNotification'] then 
           delegate['Image_tackNotification']:setVisible(false)
        end 
        local temp_gameType = delegate.taskGameType
        local function  cbSuccess(arg)
            dump(arg,'请求每日任务列表更新红')
            UserCache.setUserDataByKey("task_version9",arg.version)
            if #arg.desc > 0 then 
               UserCache.setUserDataByKey("task_desc_get9",arg.desc)
            end        
                for key,var in pairs(arg.state) do 
                if tonumber(var.State) == -1 and delegate['Image_tackNotification'] then 
                   delegate['Image_tackNotification']:setVisible(true)
                   break 
                end 
            end           
        end    
        LuaTools.fastRequest(tab,cbSuccess)
    end     
    -------------------------------------------------
    --赠送礼物 
    GameTableCommon.receiveGiftListener(delegate , function(arg)  
        print('tttttttttttttttttttttttttttttttttttttttttt0')
        if not arg.giftID then arg.giftID = 1 end  
        if arg.status == 1 then 
           local gift_imageTab = {'common/gift1.png','common/gift2.png','common/gift3.png','common/gift4.png',
                  'common/gift5.png','common/gift6.png','common/gift7.png'} 
           local animationTab = {'Animation_gift_flower.csb','Animation_gift_egg.csb','Animation_gift_car.csb',
           'Animation_gift_boat.csb','Animation_gift_aircraft.csb','Animation_gift_villa.csb','Animation_gift_beach.csb'}

           if arg.isSelfSent then 
               local price_tab = {3000,3000,60000,300000,500000,800000,5000000} 
               GameTableCommon.updatePlayerCoinsByPlayerUID(delegate, G_UID, -price_tab[arg.giftID],true)
               -- GameTableCommon.REQ_UPDATE_PLAYER(delegate) 
           end 
           GameTableCommon.REQ_UPDATE_PLAYER(delegate)
           local image = ccui.ImageView:create(gift_imageTab[arg.giftID],ccui.TextureResType.plistType)
           if arg.fromNode and arg.toNode  and delegate  and  arg.fromNode ~= arg.toNode then  
               local worldPointFrom =  arg.fromNode:convertToWorldSpace(cc.p(0,0))
               local worldPointTo   =  arg.toNode:convertToWorldSpace(cc.p(0,0))
               delegate:addChild(image)
               image:setPosition(cc.p(worldPointFrom.x+60,worldPointFrom.y+60))

               local act --= cc.MoveTo:create(0.4,cc.p(worldPointTo.x+60,worldPointTo.y+60))  
               if arg.giftID ~= 2 then 
                  act = cc.MoveTo:create(1,cc.p(worldPointTo.x+60,worldPointTo.y+60))  
               else 
                  act = cc.Spawn:create(cc.MoveTo:create(1,cc.p(worldPointTo.x+60,worldPointTo.y+60)),
                        cc.RotateBy:create(1,1080))
               end  
               local function bbbb()
                    image:removeFromParent(true)
                    --image:setVisible(false)
                    if arg.giftID ~= 2 then 
                        audio.playSound(Sound.SoundTable['sfx']['SendGift'],false)
                    else 
                        audio.playSound(Sound.SoundTable['sfx']['Market_egg'],false)
                    end 
                    local giftSendNode = cc.CSLoader:createNode(animationTab[arg.giftID]) 
                    giftSendNode:setPosition(cc.p(worldPointTo.x+50,worldPointTo.y+50))
                    local action = cc.CSLoader:createTimeline(animationTab[arg.giftID])
                    giftSendNode:runAction(action)
                    action:gotoFrameAndPlay(0,false)
                    local function cb1() 
                        giftSendNode:removeFromParent(true)
						giftSendNode = nil
                    end     
                    delegate:addChild(giftSendNode)  
                    delegate:runAction(cc.Sequence:create(cc.DelayTime:create(2.5),cc.CallFunc:create(cb1)))
               end  
               image:runAction(cc.Sequence:create(act,cc.CallFunc:create(bbbb)))      
           end                         
        end 
    end) 


    ---------------------------------------------------------请求添加好友 
    GameTableCommon.registerFriendRequest(delegate,function(data) 
           print('testFriendRequest1')
           dump(data)
                local d = G_BASEAPP:addView('UIDialog',999999)
                local uid = data.PlayerId or data.uid
                dump(delegate.playerData,"FROM INSIDE ")
                local player = GameTableCommon.getPlayerByUid(delegate,uid)
                local name = player.nickName or player.Name
                local title = '玩家'..name..'请求添加您为好友',
                print('   ')
                print(name) 
                print(title) 
                d:setupDialog('',title,
                    function() 
                        GameTableCommon.req_friendRequestRusult(delegate,uid,1)
                        d:removeSelf()
                    end,
                    function() 
                        GameTableCommon.req_friendRequestRusult(delegate,uid,0)
                        d:removeSelf()
                    end)
        end,
        function(data)
           print('testFriendRequest2')
           dump(data)
            local str = data.agree == 1 and '接受' or '拒绝' 
            if data.toId == G_UID then 

                local player = GameTableCommon.getPlayerByUid(delegate,data.fromId) 
                local name = player.nickName or player.Name 
                if data.agree == 0 then 
                   LuaTools.showAlert('您'..str..'了玩家'..name..'的好友邀请')
                end 
            elseif data.fromId == G_UID then 
                local player = GameTableCommon.getPlayerByUid(delegate,data.toId) 
                local name = player.nickName or player.Name 

                LuaTools.showAlert('玩家'..name..str..'了您'..'的好友邀请')

                if  data.agree == 1 then 
                    local dataTable =     {
                        ['uid']   = G_UID,
                        ['token'] = G_TOKEN,
                        ['cmd']   = HttpHandler.CMDTABLE.ADD_FRIEND,
                        ['fuid']  = data.toId,
                        ['giftid']= -1,
                        ['type']  = 0,--0 表示离线 1表示在线
                        ['ftype'] = 0,--0 表示普通好友 1 表示结婚
                        ['from']  = 'room',
                    }
                    local function succ(arg)
                    end
                    LuaTools.fastRequest(dataTable,succ)


                    local pData = G_BASEAPP:getData('PlayerData')
                    table.insert(pData.friendUidList,tonumber(data.toId))
                end 
            end    
        end)
 


    ---------------------------------------------------------
    if delegate['Text_rewardBox_time'] then 
       delegate['Text_rewardBox_time']:setVisible(false) 
       GameTableCommon.startOrEndTime(delegate,1) 
    end


    if delegate['Button_tasks'] then
        delegate['Button_tasks']:onTouch(function(event)
            if event.name == 'ended' then 
                G_BASEAPP:addView('UITask', 1200,9,function(b)
                    if delegate['Image_tackNotification'] then 
                       delegate['Image_tackNotification']:setVisible(b) 
                    end    
                end,
                function(arg) 
                if delegate['AtlasLabel_myCoins'] and arg.coin then 
                    delegate['AtlasLabel_myCoins']:setString(LuaTools.convertAmountChinese(arg.coin,10000))
                end 
                if delegate['AtlasLabel_myDimonds'] and arg.gem then 
                    delegate['AtlasLabel_myDimonds']:setString(LuaTools.convertAmountChinese(arg.gem,10000))
                end  

                GameTableCommon.updatePlayerCoins(delegate, delegate.mySeatID,tonumber(arg.coin) ) 
                GameTableCommon.REQ_UPDATE_PLAYER(delegate)
                end)
            end
        end)
    end

    if delegate['Button_chat'] then
        delegate['Button_chat']:onTouch(function(event)
            if event.name == 'ended' then 
                G_BASEAPP:addView('UIFaceicon', 1200,function(arg)
                    GameTableCommon.handleChat(delegate,arg)
                end) 
            end
        end)
    end    
    
    local function qbuy(event)
        -- printf('qbuy')
        if event.name == 'ended' then 
            if delegate.isGameStarted == true then 
                LuaTools.showAlert('对局中无法购买金币')
                return 
            end
            G_BASEAPP:addView('UIQuickBuy', 1200,function(arg) 
                dump(arg,"qbuy arg")
                if delegate['AtlasLabel_myCoins'] and arg.coin then 
                    delegate['AtlasLabel_myCoins']:setString(LuaTools.convertAmountChinese(arg.coin,10000))
                    GameTableCommon.updatePlayerCoins(delegate, delegate.mySeatID,tonumber(arg.coin) ) 
                end 
                if delegate['AtlasLabel_myDimonds'] and arg.gem then 
                    delegate['AtlasLabel_myDimonds']:setString(LuaTools.convertAmountChinese(arg.gem,10000))
                end  

                GameTableCommon.REQ_UPDATE_PLAYER(delegate)
            end) 
        end
    end
    local function openShop(event)  
        if event.name == 'ended' then 
            G_BASEAPP:addView('UIShopDiamond',1200, function()
                --更新金币，元宝。。。
             end)
        end
    end
    

    if delegate['Button_pay'] then
        delegate['Button_pay']:onTouch(qbuy) 
    end
    if delegate['Button_qbuyCoin'] then
        delegate['Button_qbuyCoin']:onTouch(qbuy) 
    end
    if delegate['Button_openShop'] then
        delegate['Button_openShop']:onTouch(openShop) 
    end

    if  delegate['Text_rewardBox_time'] then 
        for i=1,5 do
            if  delegate['Panel_player_'..i] and delegate['Panel_player_'..i]:getChildByName('Image_avatar')  then
                printf("SETTING UP AVATAR ON TOUCH(%s)",delegate['Panel_player_'..i]:getChildByName('Image_avatar'))
                delegate['Panel_player_'..i]:getChildByName('Image_avatar'):setTouchEnabled(true)
                
                delegate['Panel_player_'..i]:getChildByName('Image_avatar'):onTouch(function(event)
                    if event.name == 'ended' then
                        local info = GameTableCommon.getInfoByDisplayID(delegate,i)
                        info.Uid = info.Uid or info.UID
                        if info and info.Uid then
                            local tab_temp = {} 
                            tab_temp.uid = info.Uid
                            tab_temp.tag = 2
                            tab_temp.cbKick =  function()
                                if delegate.REQ_KICK_PLAYER then 
                                   delegate.REQ_KICK_PLAYER(delegate,info.Uid)
                                   delegate.PlayerData.prop[1]=delegate.PlayerData.prop[1]-1
                                end
                            end 
                            tab_temp.cbSendGift = function(playerUID,giftID) 
                                GameTableCommon.sendGift(delegate, playerUID,giftID)  
                                -- GameTableCommon.REQ_UPDATE_PLAYER(delegate)
                            end
                            tab_temp.cbAskFriend = function(uid) 
                                GameTableCommon.sendFriendRequest(delegate, uid)
                            end 
                            tab_temp.cbSellGift = function(coin) 
                                GameTableCommon.updatePlayerCoinsByPlayerUID(delegate, G_UID,coin)
                                GameTableCommon.REQ_UPDATE_PLAYER(delegate)
                            end
                            G_BASEAPP:addView('UIFriendBrief', 1200,tab_temp)
                        end
                    end
                end)
            end
        end
    end
 

    if delegate['Panel_boardcast'] then 
        delegate.Broadcast = G_BASEAPP:addView({uiName = 'UIBroadcast', uiInstanceName = "forSanzhangUse"},1100)
        delegate.Broadcast:setPositionX(delegate['Panel_boardcast']:getPositionX())
        delegate.Broadcast:setPositionY(delegate['Panel_boardcast']:getPositionY())
    end

     
end

--任务完成的小红点
function GameTableCommon.showTastRedPoint(delegate)
    if delegate['Image_tackNotification'] then 
       delegate['Image_tackNotification']:setVisible(true)
    end 
end 

--处理金币不足的情况
function GameTableCommon.bankruptcyHelpEXEC(delegate ,tags)  
    if not tags then tags = 1 end 
    local self = delegate
    local coin = self['AtlasLabel_myCoins']
    local seatID = delegate.mySeatID
    self.PlayerData.coin = self.playerData[seatID].totalCoins 
    GameTableCommon.bankruptcyHelp(function (data)
         dump(data,"data bankruptcyHelp")
        local val = data.coin 
        printf("bankruptcyHelp val:%s",val)
        self.playerData[seatID].totalCoins = val
        self.PlayerData.coin = val
        if data.gem then
            self.PlayerData.gem = data.gem 
            GameTableCommon.updateGems(delegate,data.gem)
        end
        if coin then
            coin:setString(LuaTools.convertAmountChinese(self.playerData[seatID].totalCoins,10000)) 
        end
        GameTableCommon.REQ_UPDATE_PLAYER(delegate)
    end,tags) 
end



--破产补助  弹出银行
function GameTableCommon.bankruptcyHelp(callback,tags) 
    local function exec()
        local zorder = 1200
        -- printf('GameTableCommon.bankruptcyHelp exec')
        local pData = G_BASEAPP:getData('PlayerData')
        if pData.bank and tonumber(pData.bank)> 0 then 
            G_BASEAPP:addView('UISupplyMoney',zorder,callback)
             -- print('进入弹出银行')
        elseif pData.gem > 0 then 
            G_BASEAPP:addView('UIQuickBuy',zorder,callback)
        else  
            if  tags ~= 0x09 and tags ~= 0x0A and tonumber(pData.coin) <= 2000 then    
            -- print('进入破产补助')
                local paTable =     {
                    ['uid']   = G_UID,
                    ['token'] = G_TOKEN,
                    ['cmd']   = HttpHandler.CMDTABLE.GET_FREE_COIN  }  
                local function succ(arg) 
                    if callback and arg then 
                        callback(arg)
                        LuaTools.showAlert(arg.msg)
                    end        
                end    
                local function cb(coin) 
                    GameTableCommon.updatePlayerCoinsByPlayerUID(delegate,G_UID,tab)
                end     

                local function fail(arg)
                    -- dump(arg,'失败了啊')
                    LuaTools.showAlert('金币不足')
                    if pData.gpackFlag <4 then      
                        G_BASEAPP:addView('UISpree',zorder,cb)
                    else 
                        G_BASEAPP:addView('UIShopDiamond',zorder)
                    end     
                end     
                LuaTools.fastRequest(paTable,succ,fail)
            elseif  tonumber(pData.coin) > 2000 then    
                LuaTools.showAlert('金币不足')
                G_BASEAPP:addView('UIShopDiamond',zorder)       
            end        
        end   
    end
    -- exec()
    local status, msg = xpcall(exec(), function(m)
        print('bankruptcyHelp error:'..m)
    end)
    -- if not status then
    --     print(msg)
    -- end

          
end     

 -- arg.giftID 
 -- arg.status 1 收到礼物成功 2 失败
 -- arg.fromNode 
 -- arg.toNode    赠送礼物 

function GameTableCommon.receiveGiftListener(delegate,callback)

    if delegate then 
        if delegate.taskGameType == 1 or delegate.taskGameType == 4  then   
            delegate['TCP_PLAYER_SENT_GIFT'] = function(self,data )
                dump(data,'TCP_PLAYER_SENT_GIFT') 
                local arg = {} 
                local fromPlayerDID = delegate.playerData[data.sentSeatID].displayID
                local toPlayerDID =   delegate.playerData[data.receiveID].displayID
                local fromUID = delegate.playerData[data.receiveID].displayID
                arg.isSelfSent = (data.sentSeatID == delegate.mySeatID)
                arg.giftID = data.giftType
                arg.status = data.status   --1
                arg.fromNode = delegate['Panel_player_'..fromPlayerDID]:getChildByName('Image_avatar')
                arg.toNode = delegate['Panel_player_'..toPlayerDID]:getChildByName('Image_avatar')
                if callback then  
                    callback(arg)
                end  
            end 
        else  
            delegate['TCP_SENDGIFT'] = function(self,data )
                dump(data,'TCP_SENDGIFT')
                local arg = {} 
                local fromPlayer = GameTableCommon.getPlayerByUid(delegate,data.playerUID)
                local toPlayer = GameTableCommon.getPlayerByUid(delegate,data.BePlayerUID)
                arg.fromNode = delegate['Panel_player_'..fromPlayer.displayID]:getChildByName('Image_avatar')
                arg.toNode = delegate['Panel_player_'..toPlayer.displayID]:getChildByName('Image_avatar')
                arg.giftID = data.giftID 
                arg.isSelfSent = (fromPlayer.seatID == delegate.mySeatID)
                arg.status = 1
                if callback then 
                    callback(arg)
                end
            end
        end
    end
end

function GameTableCommon.sendGift(delegate, playerUID,giftID ) 
    if delegate then 
        local id = playerUID
        if delegate.taskGameType == 1 or delegate.taskGameType == 4 then  
            id = GameTableCommon.getPlayerByUid(delegate,playerUID).seatID
        end
        delegate:REQ_SENDGIFT( id,giftID )
                print(playerUID)
                print(id)
                print(giftID)
                print('send gift  success wwwwwwwwwwwwwwwwwwwww')
    end
end

--创建动画节点
function GameTableCommon.createAnimationNode(nodeName,onFinish,loop,delay)
        local node = cc.CSLoader:createNode(nodeName)
        node:setVisible(false)
        scheduler.performWithDelayGlobal(function()
            local action = cc.CSLoader:createTimeline(nodeName)
            node:runAction(action)
            action:gotoFrameAndPlay(0,loop or false)  
            node:setVisible(true)
            local function onFrameEvent(frame)
                if nil == frame then
                    return
                end
        
                local str = frame:getEvent()
                printf('onFrameEvent:%s',str)
                if str == "onFinish" then
                    node:removeFromParent()
                    node = nil
                    if onFinish then 
                        onFinish()
                    end
                end
            end
            action:setFrameEventCallFunc(onFrameEvent)  
        end,delay or 0.01)
        return node
    end

 --UI中间文字提示：观战中，请等待下局开始
function GameTableCommon.setStaticMsg(delegate, str )
    if delegate['Image_tookpart'] then 
        if str == nil then 
            delegate['Image_tookpart']:setVisible(false)
            return 
        end
        printf('####### setStaticMsg:%s ',str)
        delegate['Image_tookpart']:setVisible(true)
        delegate['Image_tookpart']:getChildByName('Text_time'):setString(str)
    end 
end

--退出场内游戏
function GameTableCommon.quitComfirm(delegate,forceClose)
    -- body 
    local function quit()
        --if GameTableCommon.bt_LotteryNode then
			--GameTableCommon.bt_LotteryNode:removeFromParent()
			--GameTableCommon.bt_LotteryNode = nil
		--end
        if delegate.Broadcast then
            print("REMOVING BROADCAST UI")
            local pData = G_BASEAPP:getData('PlayerData')
            table.remove(pData.braodCastObject, #pData.braodCastObject)
            if delegate.Broadcast.removeSelf then
                delegate.Broadcast:removeSelf()
            end
        end 
        local tableMenu = G_BASEAPP:getView('UIGameTableMenu')
        if tableMenu then
            tableMenu:removeSelf()
        end 

        local tableResult = G_BASEAPP:getView('UIGameTableResult')
        if tableResult then
            tableResult:removeSelf()
        end 
        
        if G_BASEAPP:getView('UIMainTop') then 
          G_BASEAPP:callMethod('UIMainTop','updateWealth')
        end 
       
        -- showExitMainActions(_cb)

        audio.stopAllSounds()
        audio.stopMusic(true)  
        if G_BASEAPP:getView('UIMain') then 
          G_BASEAPP:callMethod('UIMain','playBgdSound')
        end  
        if G_BASEAPP:getView('UIActivityList') then 
           G_BASEAPP:removeView('UIActivityList')
        end  
        audio.stopAllSounds() 

        local spriteFrameCache = cc.SpriteFrameCache:getInstance()
        for k,v in pairs(GameTableCommon.preLoadResources) do 
            spriteFrameCache:removeSpriteFramesFromFile(v)
        end
		--释放plist
		--spriteFrameCache:removeSpriteFramesFromFile("common.plist")
		--spriteFrameCache:removeSpriteFramesFromFile("res_chat.plist")
        if delegate then 
            if delegate['Text_rewardBox_time'] then 
               GameTableCommon.startOrEndTime(delegate,2) 
            end
            delegate:REQ_TABLE_DISCONNECT() 
            delegate.tcpGear:closeAndRelease()
            delegate:removeSelf()

            GameTableCommon.IS_IN_TABLE = nil
            GameTableCommon.lastDelegate = nil
            delegate = nil
        end
        local found = false
        for _,name in pairs(GameTableCommon.selectRoomNameTable) do
            local view =  G_BASEAPP:getView(name)
            if view and view.onCreate --[[and name == 'UIMatchRoomDDZBooms']] then 
                local arg = view.keyGame
                view:onCreate(arg)  
                found = true
            end
        end
        if found == false then 
            G_BASEAPP:callMethod('UIMain','showEnterMainActions')
        end

    end

    if forceClose == true then
        quit()
        return
    end

    local d = G_BASEAPP:addView('UIDialog', 65530)
    d:setupDialog('', '是否确定退出房间？', 
    function()   
    	quit()
    end) 

end
 
--点击返回按钮
function GameTableCommon.overrideBack( delegate , overridedCallback)

        print('setting overrideBack:',delegate.name_) 
	local function recruFunc() 
        print('overrideBack:',delegate.name_)
        if overridedCallback then
            overridedCallback()
        end
        delegate:addGobackEventAction(function() recruFunc() end)
    end
    delegate:addGobackEventAction(function()
        
        print('addGobackEventAction overrideBack:',delegate.name_) 
        recruFunc() 
    end)

end
 

return GameTableCommon