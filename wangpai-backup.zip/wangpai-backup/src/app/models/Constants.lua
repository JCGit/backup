Constants = {}

Constants.KEY_DDZ = 'ddz'           --斗地主炸翻天
Constants.KEY_DN = 'dn'				--斗牛
Constants.KEY_ZJH = 'zjh'			--三张牌
Constants.KEY_POKER = 'poker'		--德州扑克
Constants.KEY_RUNFAST = 'pdk'		--跑得快
Constants.KEY_SHENGJI = 'sj'		--升级
Constants.KEY_DDZNOR = 'ddzNor'		--全民斗地主
Constants.KEY_WANREN = 'wrdn'     --万人斗地主
Constants.KEY_MATCH = 'match'     --比赛场


--德州扑克场次
Constants.POKER_ROOMS_DATA = {
   beginner = {
        {maxChips = 2000, minBlind = 5, tType_6 = 89, tType_9 = 71},
        {maxChips = 4000, minBlind = 10, tType_6 = 90, tType_9 = 72},
        {maxChips = 8000, minBlind = 20, tType_6 = 91, tType_9 = 73},
        {maxChips = 20000, minBlind = 50, tType_6 = 92, tType_9 = 74},
        {maxChips = 40000, minBlind = 100, tType_6 = 93, tType_9 = 75},
        {maxChips = 80000, minBlind = 200, tType_6 = 94, tType_9 = 76},
   },
   pro = {
        {maxChips = 200000, minBlind = 500, tType_6 = 101, tType_9 = 83},
        {maxChips = 400000, minBlind = 1000, tType_6 = 102, tType_9 = 84},
        {maxChips = 600000, minBlind = 1500, tType_6 = 103, tType_9 = 85},
        {maxChips = 800000, minBlind = 2000, tType_6 = 104, tType_9 = 86},
        {maxChips = 1200000, minBlind = 3000, tType_6 = 105, tType_9 = 87},
        {maxChips = 2000000, minBlind = 5000, tType_6 = 106, tType_9 = 88},
   },
   speedup = {
        {maxChips = 20000, minBlind = 50, tType_6 = 95, tType_9 = 77},
        {maxChips = 40000, minBlind = 100, tType_6 = 96, tType_9 = 78},
        {maxChips = 200000, minBlind = 500, tType_6 = 97, tType_9 = 79},
        {maxChips = 400000, minBlind = 1000, tType_6 = 98, tType_9 = 80},
        {maxChips = 800000, minBlind = 2000, tType_6 = 99, tType_9 = 81},
        {maxChips = 2000000, minBlind = 5000, tType_6 = 100, tType_9 = 82},
   },
}

--升级场次
Constants.SHENGJI_ROOMS_DATA = {
    {name = '新手场', difen = 800, max = 50000, min = 1000, tType = 107},
    {name = '初级场', difen = 1500, max = 200000, min = 3000, tType = 108},
    {name = '中级场', difen = 3000, max = 0, min = 10000, tType = 109},
    {name = '高级场', difen = 10000, max = 0, min = 50000, tType = 110},
}

--王牌斗地主场次
Constants.WPDZ_ROOMS_DATA = {
    {difen = 200, max = 0, min = 0, tType = 122, roomId = 0,showBox = true,showPromotion = true,showHot = true},
    {difen = 1500, max = 0, min = 20000, tType = 122, roomId = 1,showBox = true,showPromotion = false,showHot = false},
    {difen = 3000, max = 0, min = 50000, tType = 122, roomId = 2,showBox = false,showPromotion = false,showHot = true},
    {difen = 6000, max = 0, min = 100000, tType = 122, roomId = 3,showBox = true,showPromotion = true,showHot = true},
}

--跑得快场次
    --  tableType = 107, -- 初级场
    --  tableType = 108, -- 中级场
    --  tableType = 109, -- 高级场
    --  tableType = 110, -- 至尊场
    --  tableType = 111, -- 血战场
    --  tableType = 112, -- 巅峰场
    --  tableType = 113, -- 帝王场
Constants.PDK_ROOMS_DATA = {
    {difen = 100,max = 0, min = 0, tType = 107},
    {difen = 10000,max = 1000000, min = 100000, tType = 108},
    {difen = 50000,max = 5000000, min = 500000, tType = 109},
    {difen = 100000,max = 0, min = 1500000, tType = 110},
}

Constants.STRING_NO_MONEY = "金币不足，请前往商城购买！"
