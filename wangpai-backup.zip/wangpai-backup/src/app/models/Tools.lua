local Tools = class("Tools", cc.load("mvc").ModelBase)
local HttpHandler = require("app.network.HttpHandler")
require("cocos.cocos2d.OpenglConstants")
--require("cocos.cocos2d.Opengl")
--require("cocos.cocos2d.Cocos2dConstants")
--printWarning
function Tools.performWithDelayGlobal(listener, time)
    local sharedScheduler = cc.Director:sharedDirector():getScheduler()
    local handle
    handle = sharedScheduler:scheduleScriptFunc(function()
        scheduler.unscheduleGlobal(handle)
        listener()
    end, time, false)
    return handle
end 

function Tools:onCreate()
    local app = self:getApp()
    self.app = app
end

function Tools:splitString(str, split_char)  
    return LuaTools.splitString(str, split_char)
end

--获得格式化的时间
function Tools:getFormatTimeBySecond(time, type)  
    return LuaTools.getFormatTimeBySecond(time, type)
end
 
function Tools:showTips(str)
    --self:getApp():addView("UITips", 65534,str)
    self:showAlert(str)
end

--图片载切成圆形
--@params: 新创建的精灵, 模板Node, 父亲节点
function Tools:makeSpriteRounded(_newSprite, _tmpSprite, _maskSpr) 
    return LuaTools.makeSpriteRounded(_newSprite, _tmpSprite, _maskSpr)
end

function Tools:myheadChange(_newSprite, _tmpSprite, _parent,uid,last)
   return LuaTools.myheadChange(_newSprite, _tmpSprite, _parent,uid,last) 
end 

--禁用
--@目标，禁用时间
function Tools:freezeWidget(target, delay)
   return LuaTools.freezeWidget(target, delay)
end

--快速请求HTTP
--@params:请求表, 请求成功回调，请求失败回调
function Tools:fastRequest(table, cbSuccess, csFailed, showWaiting)
    local extraParam = {
        disableWaiting = showWaiting
    }
    return LuaTools.fastRequest(table,cbSuccess,csFailed,extraParam)
     
    -- local onRespond = function(arg)
    --     dump(arg)
    --     if showWaiting == nil then
    --         self:stopWaiting()
    --     end
    --     if  tonumber(arg.result) == 0 then
    --         cbSuccess(arg)
    --     else
    --         if csFailed then
    --             csFailed(arg)
    --         end
    --         self:showAlert(arg.msg)
    --     end
    -- end
    -- dump(table)
    -- table.callback = onRespond
    -- local http = HttpHandler.new(table)
    -- if showWaiting == nil then
    --     self:beginWaiting()
    -- end
end

function Tools:showAlert(msg)
    return  LuaTools.showAlert(msg)
end

--将数字100800，转换为100,08K格式
--@param: 任意数字
function Tools:convertAmount(val)
    return LuaTools.convertAmount(val)
end

--将数字100800，转换为10,08万 格式
--@param: 任意数字
function Tools:convertAmountChinese(val)
    return LuaTools.convertAmountChinese(val)
end

--将数字100000，转换为100,000格式
--@param: 任意数字
function Tools:convertToText(val)
   return LuaTools.convertToText(val)
end

function Tools:beginWaiting()
    return LuaTools.beginWaiting()
end

function Tools:stopWaiting()
    return LuaTools.stopWaiting()
end

function Tools:getUIScale()
    return LuaTools.getUIScale()
end

--解析字符串中的_    ,
--@params  eg: str = abc_def
--return   person= {[1]='abc',[2]=def}
function Tools:getStringTab(str) 
    return LuaTools.getStringTab(str)
end

--牌翻转动作
--@params： 执行动作的节点    要替换的纹理
function Tools:rotateCard(par,image)
   return  LuaTools.rotateCard(par,image)
end

--获取等级信息
--@param:总经验值, 经验值对应的表
--@returns:等级，当前经验，最大经验
function Tools:expInfos(exp, listExp) 
    return LuaTools.expInfos(exp, listExp)
end

function Tools:addParticles(path,aaaa,time,see)
    return LuaTools.addParticles(path,aaaa,time,see)
end 
 

--是否是新的一天
--@param: 对比时间
function Tools:isNewDay(lasttime, newtime) 
    return LuaTools.isNewDay(lasttime, newtime)
end
return Tools
