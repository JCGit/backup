LuaTools = {}
local socket = require("socket")
  require "cocos.cocos2d.json" 
-- local HttpHandler = require("app.network.HttpHandler")
local scheduler = require("app.models.QScheduler")
-- local Playsound  = require("app.models.Sound") 
require("cocos.cocos2d.OpenglConstants")
function LuaTools.SubUTF8String(s, n)
  local dropping = string.byte(s, n+1)
  if not dropping then return s end
  if dropping >= 128 and dropping < 192 then
    return SubUTF8String(s, n-1)
  end
  return string.sub(s, 1, n)
end
local showAlertCount = 0

function LuaTools.setUmeng(agr) 
	local ThirdSDKHandler = require('app.network.ThirdSDKHandler')
	ThirdSDKHandler.doUmengMethod(function()end,function() end,function()end,agr)
end

function LuaTools.getScreenSnapshot(onSuccCallback) 
  cc.utils:captureScreenRaw(function(succeed, sp)
    printf("====================")
    printf("====================")
    printf("====================")
    printf("====================")
    printf("====================")
    printf("===captureScreenRaw===")
    printf("====================")
    printf("====================")
    printf("====================")
    printf("====================")
        if succeed then 
          sp:retain()
          scheduler.performWithDelayGlobal(function() 
            onSuccCallback(sp) 
          end,0.01)
        else
            printError("Capture screen failed.")
        end
    end) 
end

function LuaTools.setUmeng(sendumeng)

end 

function LuaTools.getShaderState(fsh,vsh)
  fsh = fsh or 'shaders/Default.fsh'
  vsh = vsh or "shaders/Default.vsh"
  -- printf('using fsh:(%s), vsh:(%s)',fsh,vsh)
  local program = cc.GLProgram:create(vsh,fsh)
  program:bindAttribLocation(cc.ATTRIBUTE_NAME_POSITION, cc.VERTEX_ATTRIB_POSITION) 
  program:bindAttribLocation(cc.ATTRIBUTE_NAME_TEX_COORD, cc.VERTEX_ATTRIB_TEX_COORD)
  program:link()
  program:updateUniforms()
  return  cc.GLProgramState:getOrCreateWithGLProgram(program)
end


function LuaTools.enumerateChildren( node,callback )
  local children = node:getChildren() 
  for k,v in pairs(children) do
      local c = node:getChildren()
      callback(v)  
      LuaTools.enumerateChildren(v,callback) 
  end
end

function LuaTools.getFinalNameStr(str,n,start)  --,fontSize,totalWidth)
    -- local temp 
    -- if string.len(str) > length then 
    --     temp = string.sub(str,1,length)
    -- else 
    --     temp = str 
    -- end         
    if not str then return end 
    if not start then start = 1 end 
    local firstResult = ""
    local strResult = ""
    local maxLen = string.len(str)
    start = start - 1
    --找到起始位置
    local preSite = 1
    if start > 0 then
        for i = 1, maxLen do
            local s_dropping = string.byte(str, i)
            if not s_dropping then
                local s_str = string.sub(str, preSite, i - 1)
                preSite = i + 1
                break
            end


            if s_dropping < 128 or (i + 1 - preSite) == 3 then
                local s_str = string.sub(str, preSite, i)
                preSite = i + 1
                firstResult = firstResult..s_str
                local curLen = LuaTools.utfstrlen(firstResult)
                if (curLen == start) then
                    break
                end
            end
        end
    end
    
    
    --截取字符串
    preSite = string.len(firstResult) + 1
    local startC = preSite
    for i = startC, maxLen do
        local s_dropping = string.byte(str, i)
        if not s_dropping then
            local s_str = string.sub(str, preSite, i - 1)
            preSite = i
            strResult = strResult..s_str
            return strResult
        end


        if s_dropping < 128 or (i + 1 - preSite) == 3 then
            local s_str = string.sub(str, preSite, i)
            preSite = i + 1
            strResult = strResult..s_str
            local curLen = LuaTools.utfstrlen(strResult)
            if (curLen == len) then
                return strResult
            end
        end
    end
    
    return strResult

    -- local dropping = string.byte(str, n+1)    
    -- if not dropping then return s end    
    -- if dropping >= 128 and dropping < 192 then    
    --   return LuaTools.getFinalNameStr(str, n-1)    
    -- end    
    -- return string.sub(str, 1, n)    


    -- local lenInByte = #str
    -- local width = 0
    -- local tag   = 0  
       
    -- for i=1,lenInByte do
    --       local curByte = string.byte(str, i)
    --       local byteCount = 1;
    --       if curByte>0 and curByte<=127 then
    --           byteCount = 1
    --       elseif curByte>=192 and curByte<223 then
    --           byteCount = 2
    --       elseif curByte>=224 and curByte<239 then
    --           byteCount = 3
    --       elseif curByte>=240 and curByte<=247 then
    --           byteCount = 4
    --       end 

    --       if i == 4 then 
    --          tag =     
    --       end   
           
    --       local char = string.sub(str, i, i+byteCount-1)
    --       i = i + byteCount -1
           
    --       if byteCount == 1 then
    --           width = width + fontSize * 0.5
    --       else
    --           width = width + fontSize
    --           print(char)
    --       end
    -- end

    -- return temp
end  


function LuaTools.setShaderOnUIWiget( uinode , shaderState )   

    -- printf('########################enumerating node:%s',uinode:getName())
  LuaTools.enumerateChildren(uinode,function(node) 
    -- printf('########################enumerateChildren uinode name:%s',node:getName())
      if  node.getSprite then 
            -- printf('########################setting state for node.getSprite(%s)',node:getName()) 
          node:getSprite():setGLProgramState(shaderState:clone()) 
      else 
          node:setGLProgramState(shaderState:clone())
            -- printf('########################setting state for node(%s)',node:getName())  
      end 
      if node.getVirtualRenderer then 
          local r = node:getVirtualRenderer()
          if r.getSprite then 
              r:getSprite():setGLProgramState(shaderState:clone())
              -- printf('########################setting state for getVirtualRenderer.getSprite(%s)',node:getName()) 
          else 
            r:setGLProgramState(shaderState:clone())
            -- printf('########################setting state for getVirtualRenderer(%s)',node:getName()) 
          end 
      end
      
  end)  
end

function LuaTools.vibrateScreen( time,offset)
  if LuaTools.vibScrn then
    scheduler.unscheduleGlobal(LuaTools.vibScrn)
    LuaTools.vibScrn = nil
  end

  if LuaTools.vibstop then
    scheduler.unscheduleGlobal(LuaTools.vibstop)
    LuaTools.vibstop = nil
  end

  local runningScene = display.getRunningScene()
  LuaTools.vibScrn = scheduler.scheduleGlobal(function()
    runningScene:setPosition(cc.p(math.random(-offset,offset),math.random(-offset,offset)))
  end,0.01)
  LuaTools.vibstop = scheduler.performWithDelayGlobal(function()
    if LuaTools.vibScrn then
      scheduler.unscheduleGlobal(LuaTools.vibScrn)
      LuaTools.vibScrn = nil
    end
    runningScene:setPosition(cc.p(0,0))
  end,time)
end

function LuaTools.softMasterReset()
  for k,v in pairs( TCPGearbox.pool ) do
    v:closeAndRelease(0)
  end
  TCPGearbox.pool  = {}
  TCPGearbox.connFailureCount = 0
  G_BASEAPP.lastAddedView:iterator( function(k,v)
              if v.removeSelf then
                v:removeSelf()
              end
  end )
  G_BASEAPP.lastAddedView:clear()
  if G_CHANNEL_CONFIG.isOurOnlyAutoLogin then
    G_BASEAPP:addView("UIAutoLogin", 1, true)
  else
    G_BASEAPP:addView("UILogin", 1, true)
  end
  -- body
end

function LuaTools.enterActionScaledWithMask(panel,cb)
  local msk = cc.LayerColor:create(cc.c4b(0,0,0,0))
  local size = cc.Director:getInstance():getWinSize()
  msk:setContentSize(size.width, size.height)
  msk:setPosition(cc.p(0, 0))
  panel:getParent():addChild(msk, -1)
  msk:runAction(cc.FadeTo:create(0.3,150))
  LuaTools.viewAction1(panel,cb)
end

function LuaTools.viewAction1(panel,cb)    --scale
   --panel:setAnchorPoint(0.5,0.5)
   -- if not panel then return end 
   panel:setScale(0)
   local scale  = cc.ScaleTo:create(0.2,1.1)
   local scale1 = cc.ScaleTo:create(0.2,1)
   if cb then 
      panel:runAction(cc.Sequence:create(scale,scale1,cc.CallFunc:create(cb))) 
   else 
      panel:runAction(cc.Sequence:create(scale,scale1))
   end  
end 

function LuaTools.viewAction2(panel,cb, extraViews)
   -- if not panel then return end 
   local winSize = cc.Director:getInstance():getWinSize()
   local x2,y2 = panel:getPosition()

   panel:setPosition(cc.p(x2+winSize.width,y2))
   local move1 = cc.MoveBy:create(0.4,cc.p(-winSize.width,0))
   local move2 = cc.MoveBy:create(0.3,cc.p(30,0))
   --panel:runAction(move1)--cc.Sequence:create(move1,move2)) 
   if cb then 
      panel:runAction(cc.Sequence:create(move1,cc.CallFunc:create(cb))) 
   else 
      panel:runAction(move1)
   end   
   if extraViews then
    for i,v in ipairs(extraViews) do
      print('ACTIONS FOR VIEWS: '..v)
     G_BASEAPP:callMethod(v, 'transitionViewAction', move1)
    end
  end
end   

function LuaTools.viewAction1Over(panel,ui,cb,instance)
   if not panel then G_BASEAPP:removeView(ui) return end 
   local scale  = cc.ScaleTo:create(0.1,1.1)
   local  act  = cc.ScaleTo:create(0.2,0)

   --act = cc.FadeOut:create(1)
   local function callback()
    if cb then 
       cb() 
    end    
      if instance then 
        instance:removeSelf()
        return
      end
      if ui then
        G_BASEAPP:removeView(ui)
      end
   end  
   panel:runAction(cc.Sequence:create(scale,act,cc.CallFunc:create(callback)))
end 


function LuaTools.viewAction2Over(panel,ui, remove, extraViews)
   if not panel then  G_BASEAPP:removeView(ui) return end 
   local winSize = cc.Director:getInstance():getWinSize()

   local move1 = cc.MoveBy:create(0.4,cc.p(winSize.width,0))
   local move2 = cc.MoveBy:create(0.1,cc.p(-35,0))
   local function callback()
      if remove == nil then
         G_BASEAPP:removeView(ui)
      end
   end  
   panel:runAction(cc.Sequence:create(move1,cc.CallFunc:create(callback)))
  if extraViews then
    for i,v in ipairs(extraViews) do
     G_BASEAPP:callMethod(v, 'transitionViewAction', move1)
    end
  end
end   

function LuaTools.getFormatTimeBySecond(time, type)
    local second = 0
    local minute = 0
    local hour = 0

    --转换
    --to hour
    hour = math.floor(time/3600)
    --to minute
    minute = math.floor( (time - hour * 3600)/60 )
    --to second
    second = time%60

    --格式化输出
    local formatTime = nil
    if type == 1 or type == nil then
        formatTime = string.format("%02d小时%02d分%02d秒", hour, minute, second)
    elseif type == 2 then
        formatTime = string.format("%02d:%02d:%02d", hour, minute, second)
    elseif type == 3 then
        formatTime = string.format("%02d:%02d", minute, second)
    end

    return formatTime
end

function LuaTools.splitString(str, split_char)
    local sub_str_tab = {};
    while (true) do
        local pos = string.find(str, split_char);
        if (not pos) then
            sub_str_tab[#sub_str_tab + 1] = str;
            break;
        end
        local sub_str = string.sub(str, 1, pos - 1);
        sub_str_tab[#sub_str_tab + 1] = sub_str;
        str = string.sub(str, pos + 1, #str);
    end

    return sub_str_tab;
end

--never,EVER try to print the result, or will crash your app!
function LuaTools.FileToBase64(file)
  require("app.models.base64")
  local path = cc.FileUtils:getInstance():fullPathForFilename(file)
  local inp = assert(io.open(path, "rb"))
  local data = inp:read("*all")
  -- return data
  return ZZBase64.encode(data)
end

function LuaTools.StringToBase64(_str)
  require("app.models.base64")
  -- return data
  return ZZBase64.encode(_str)
end
-- scheduler.performWithDelayGlobal(function()

LuaTools.goBackCDed = true
LuaTools.goBackCDedSehcduler = nil
function LuaTools.bindBackCallback(obj,app) 
  if true then --experimental manage views with android back button system.
        local function onKeyReleased(keyCode, event) 
          local load = G_BASEAPP:getView('UILoading')
          if load ~= nil  then
              return
          end
          if LuaTools.goBackCDedSehcdulere == nil then
            LuaTools.goBackCDedSehcdulere = scheduler.performWithDelayGlobal(function() 
              LuaTools.goBackCDed = true
              LuaTools.goBackCDedSehcdulere = nil
            end,0.3)
          end

           
          if keyCode == cc.KeyCode.KEY_BACK and LuaTools.goBackCDed == true  then 
            LuaTools.goBackCDed = false
            print("---------------------------keyCode："..keyCode.."---------------------------")
            printf("keyCode:%s,app:%s,app.lastAddedView:%s,size:%s",keyCode,app,app.lastAddedView,app.lastAddedView:getSize())
            -- app.lastAddedView:dump()
            app.lastAddedView:iterator( function(k,v)
                printf("k:%s,v:%s,(%s)",k,v,v.name_)
            end )
            local lastView = app.lastAddedView:getItemAt(app.lastAddedView:getSize())
            if G_CHANNEL_CONFIG.isSdkExitGame and (lastView:getName() == "UIMain" or lastView:getName() == "UILogin") then
                LuaTools.playBtSound()
                local ThirdSDKHandler = require('app.network.ThirdSDKHandler')
                ThirdSDKHandler.doSDKExitGame()
                return
            end
            
            local goBackActionQueue =  lastView:getGoBackActionQueue()
            printf("Current view for releasing:%s, number of callbacks:%s",lastView.name_,goBackActionQueue:getSize() )
            -- local lastViewQueue =  app.lastAddedView:getItemAt(app.lastAddedView:getSize()):getApp():getGoBackActionQueue()
            if goBackActionQueue and goBackActionQueue:getSize() > 0 then  
              goBackActionQueue:dump()
              -- printf('goBackActionQueue and lastViewQueue:getSize() > 0 ')
              printf("Now calling %s GoBackAction..",lastView.name_)
              goBackActionQueue:pop()()
              return
            elseif app.lastAddedView:getSize() > 1 then
              if lastView.isLockGoback == true then
                printf("%s is locked.",lastView.name_)
                return
              end
              print('app.lastAddedView:getSize() > 1 ')
              -- if keyCode == cc.KeyCode.KEY_BACK or keyCode == 7 then 
              local view = app.lastAddedView:pop()
              while view:getSkipGoBack() do 
                 printf("View #########=>>>>[%s]<<<<=###### should be removed by now.",view:getName())
                 view:removeSelf()
                 view = app.lastAddedView:pop()
              end
              printf("View #########=>>>>[%s]<<<<=###### should be removed by now.",view:getName())

               local goBackActionQueue =  view:getGoBackActionQueue()
                printf("Current view for releasing:%s, number of callbacks:%s",view.name_,goBackActionQueue:getSize() )
                -- local lastViewQueue =  app.lastAddedView:getItemAt(app.lastAddedView:getSize()):getApp():getGoBackActionQueue()
                if goBackActionQueue and goBackActionQueue:getSize() > 0 then  
                  goBackActionQueue:dump() 
                  printf("Now calling %s GoBackAction..",view.name_)
                  goBackActionQueue:pop()()
                  return
                end


              view:removeSelf() 
              return
              -- end
            else  
              printf("LAST VIEW!")
              G_BASEAPP:addView('UIDialog', 65530)
              G_BASEAPP:callMethod('UIDialog','setupDialog', '', '是否确定退出游戏？', 
              function() 
                  cc.Director:getInstance():endToLua()
              end) 
              return
            end



          end--if keyCode == cc.KeyCode.KEY_BACK or keyCode == 7 then
        end 

        local listener = cc.EventListenerKeyboard:create()
        listener:registerScriptHandler(onKeyReleased, cc.Handler.EVENT_KEYBOARD_RELEASED ) 
        local eventDispatcher = obj:getEventDispatcher()
        eventDispatcher:addEventListenerWithSceneGraphPriority(listener, obj)

  end
end


function LuaTools.Lookat(from,to) 

   local o = to.x - from.x;
      local a = to.y - from.y;

      local at =  math.atan(o/a)* 57.29577951;


      if  a < 0 then
          
         if   o < 0 then
            at = 180 + math.abs(at);
         else
            at = 180 - math.abs(at);  
            end  
      end
      return at;
end

function LuaTools.getGiftTable()
    return {
    '鲜花',
    '鸡蛋',
    '跑车',
    '游艇',
    '直升机' ,
    '别墅' ,
    '神秘岛' ,
    'PLACE_HOLDER' ,
    'PLACE_HOLDER' ,
    'PLACE_HOLDER' ,
    'PLACE_HOLDER' ,
    'PLACE_HOLDER' ,
    'PLACE_HOLDER' ,
    'PLACE_HOLDER' ,
    'PLACE_HOLDER' ,
    'PLACE_HOLDER' ,
  }
end


function LuaTools.getGiftImageTable()
    return {
        "common/gift1.png",
        "common/gift2.png",
        "common/gift3.png",
        "common/gift4.png",
        "common/gift5.png",
        "common/gift6.png",
        "common/gift7.png",
  }
end


function LuaTools.getItemTable()
    return {
    '小喇叭' ,
    '踢人卡' ,
    'PLACE_HOLDER' ,
    'PLACE_HOLDER' ,
    'PLACE_HOLDER' ,
    'PLACE_HOLDER' ,
    'PLACE_HOLDER' ,
    'PLACE_HOLDER' ,
    'PLACE_HOLDER' ,
    'PLACE_HOLDER' ,
    'PLACE_HOLDER' ,
    'PLACE_HOLDER' ,
    'PLACE_HOLDER' ,
    'PLACE_HOLDER' ,
  }
end


function LuaTools.loadAllTextureCaches()
  -- body
  local tbl = {
    'background/game_bg.png', 
    'background/game_tables.png', 
    'background/login_bg.png', 
    'background/login_girl.png', 
    'background/login_tables.png', 
    'background/main_bg2.png', 
    'background/main_spree_bg.png', 
    'background/main_bg.png', 
    'card.png',
    'egg.png',
    'faceicon.png',
    'friendrank.png',
    'game.png',
    'loading.png',
    'login.png',
    'main.png',
    'match.png',
    'fonts/num_vip_12x20.png',
    'fonts/num_rank_19x26.png',
    'Default/Button_Disable.png'


  }

  for k,v in pairs(tbl) do
   cc.Director:getInstance():getTextureCache():addImage(v)
  end

  -- for k,v in pairs(string.split(cc.Director:getInstance():getTextureCache():getCachedTextureInfo(),"\n")) do
  --   print(k,v)
  -- end 
end

function LuaTools.expInfos(_val, _listExp, _X)
    local length = tonumber(#_listExp)
    _val = tonumber(_val)
    for i=1, length do
      if i == length and _val >= _listExp[i]*_X then
        return length,  _listExp[length]*_X , _listExp[length]*_X
      end
      if (_val >= _listExp[i]*_X and _val < _listExp[i+1]*_X) then
        return i,_val, _listExp[i+1]*_X
      end
    end
    return length, _listExp[length]*_X, _listExp[length]*_X
end


function LuaTools.isNewDay(lasttime, newtime)
    local listDate = {}     --1.oldDate, 2.newDate
    local timeformat = {"%Y", "%m", "%d"} --{year, month, day}
    local timeList = {lasttime, newtime}
    for i = 1, #timeList do
        local date = {}
        for j = 1, #timeformat do 
            date[j] = os.date(timeformat[j], timeList[i])
        end
        table.insert(listDate, date)
    end
    dump(listDate)
    local valid = false
    if (listDate[2][1]==listDate[1][1])then--same year   
        if(listDate[2][2]==listDate[1][2])then --same month        
            if(listDate[2][3]>listDate[1][3])then --same day
                valid = true
            else 
                print("Today is the same day as the last signed day.")
                valid = false
            end
        elseif(listDate[2][2]>listDate[1][2])then --12 > 11
            valid = true
        else  
            print("Today's month is inferior than last signed month.")
            valid = false  
        end
        elseif (listDate[2][1]>listDate[1][1])then -- 2016 > 2015 
            valid = true
        else
            print("Today's year is inferior than last signed year.")
            valid = false
        end 
        return valid
end

function LuaTools.addParticles(path,aaaa,time,see)
    if  not see then see = false end 
    local emitter=cc.ParticleSystemQuad:create(path) 
    emitter:setAutoRemoveOnFinish(true)
    emitter:setName('emitter_action')
    local size_emi=aaaa:getContentSize()
    aaaa:setVisible(true)
    aaaa:addChild(emitter,1) 
    emitter:setPosition(size_emi.width/2,size_emi.height/2) 
    local function delayHide()
        aaaa:setVisible(see)
        if aaaa:getChildByName('emitter_action') then 
           aaaa:removeChildByName('emitter_action')
        end   
    end  
    aaaa:runAction(cc.Sequence:create(cc.DelayTime:create(time),cc.CallFunc:create(delayHide)))

end 

function LuaTools.setNodeWorldPosition( Node,Pos )
  -- body
end

function LuaTools.rotateCard(par,image)
    par:setVisible(true)
    local function callback2()
        par:loadTexture(image,ccui.TextureResType.plistType)
    end
    local orbit1 = cc.OrbitCamera:create(0.1,1, 0, 0, 90, 0, 0)
    local move = cc.OrbitCamera:create(0.25,1, 0, 0, 0, 0, 0)
    par:runAction(cc.Sequence:create(cc.DelayTime:create(0.8),orbit1,cc.CallFunc:create(callback2),move))
end

function LuaTools.getStringTab(str)
    if not str then return end
    local str1 = str..'_'
    local person = {}
    for a in  string.gmatch(str1, "([^_]+)_*") do
        person[#person+1]=a
    end
    return person
end

function LuaTools.getUIScale()
    local scaleX, scaleY
    local winSize = cc.Director:getInstance():getWinSize()

    scaleX = winSize.width/1224.0
    scaleY = winSize.height/720.0

    return scaleX, scaleY
end

function LuaTools.stopWaiting()
    local waiting = G_BASEAPP:getView('UIWaiting')
    if waiting ~= nil  then
        waiting:removeSelf()
    end
end

function LuaTools.beginWaiting(immMode)
    LuaTools.stopWaiting()
    if  G_BASEAPP:getView('UIWaiting') == nil then
        G_BASEAPP:addView("UIWaiting", 999999,nil,nil,nil,immMode)
    end
end

function LuaTools.convertToText(val)
    if val == nil then
      return ''
    end
    local isNeg = false
    if tonumber(val) < 0 then
        val = math.abs(val)
        isNeg = true
    end
    val = string.reverse(string.format(val))
    local tableVal = {}
    for i = 1, #val do
        table.insert(tableVal, string.char(string.byte(val, i)))
        if (i%3 == 0) and (i < #val) then
            table.insert(tableVal, '.')
        end
    end
    val = ''
    for k, v in ipairs(tableVal) do
      val = val..v
    end
    if isNeg == true then
        return '-'..string.reverse(val)
        else
        return string.reverse(val)
    end
   
end

function LuaTools.convertAmountChinese(val,limit)
    if  val  and  limit  and tonumber(val) < tonumber(limit) then 
      return val 
    end 
    local isNeg = false
    val = tonumber(val)
    if val == nil then return end
    if val < 0 then
      print("VAL IS NEG")
        val = math.abs(val)
        isNeg = true
    end
    local function getFormat(_val, _str)
        local floorSum = math.floor(val/_val)
        local sum = val/_val
        --print("SUM: "..sum.. "  FLOOR SUM: "..floorSum)
        --print("AAAA: "..(sum-floorSum))
        local zformat = string.format("%0.3f",(sum-floorSum))
        zformat = math.floor(tonumber(zformat)*100)
        --print("ZFORMAT: "..zformat)
        if zformat == 0 then
            zformat = ''
        elseif zformat < 10 then
              zformat = '.0'..zformat
        else
            zformat = '.'..zformat
        end
        --local res = LuaTools.convertToText(floorSum)..j.._str     --1,100.89
        local res = floorSum..zformat.._str    --1100.89
        if isNeg == true then
            return '-'..res
        end
        return res
    end
    if 1000 <= val and val < 10000 then
        --return getFormat(1000, '千')
    elseif (10000 <= val and  val< 100000000) then
        return getFormat(10000, '万')
    elseif (100000000 <= val) then
        return getFormat(100000000, '亿')
    end
    if isNeg == true then
      return -val
    else
      return val
    end
end

function LuaTools.convertAmount(val)
    local isNeg = false
    if tonumber(val) < 0 then
        val = math.abs(val)
        isNeg = true
    end
    local function getFormat(_val, _str)
        local floorSum = math.floor(val/_val)
        local sum = val/_val
        local j = string.sub(string.format("%0.2f",(sum-floorSum)),2)
        if j == '.00' then
            j = ''
        end
        local res = LuaTools.convertToText(floorSum)..j.._str
        if isNeg == true then
            return '-'..res
        end
        return res
    end
    if val < 10000 then
        if isNeg == true then
           return '-'..LuaTools.convertToText(val)
        end
           return LuaTools.convertToText(val)
    end
    if (10000 <= val and  val< 1000000) then
        return getFormat(1000, 'K')
    end 
    if (100000000 <= val) then
        return getFormat(1000000, 'M')
    end
end


function LuaTools.showAlert(msg)
    if msg then
        showAlertCount = showAlertCount + 1
       G_BASEAPP:addView({
        uiName = 'UIAlert',
        uiInstanceName = ''..showAlertCount},999999)
            :setupDialog('Infomation',msg)
    end
end

function LuaTools.fastRequest(_table,succ,fail,extraParam)
  local HttpHandler = require("app.network.HttpHandler")
    local rootScene = G_BASEAPP
    local disableAlert = nil
    local disableWaiting = nil
    -- local waiting = nil
    if extraParam then
      disableAlert = extraParam.disableAlert  
      disableWaiting = extraParam.disableWaiting  
    end 
    if disableWaiting == nil then
      -- waiting = rootScene:addView("UIWaiting", 65535)x
      LuaTools.beginWaiting()
	    -- local scheduler = require("app.models.QScheduler")
	    -- scheduler.performWithDelayGlobal(LuaTools.beginWaiting(),3)
    end

    local onRespond = function(arg) 
    		LuaTools.stopWaiting() 
        if  tonumber(arg.result) == 0 then -- success 
            if succ then
                succ(arg)
            end
        else--fail 
            if fail then
                fail(arg)
            end

      			if ISINIT == false then
      				if disableAlert ~= true then
      				  rootScene:addView('UIAlert',65535)
      				  :setupDialog('Infomation',arg.msg)
      				end
			       end
        end
    end 
        
    _table.callback = onRespond
    dump(extraParam,"extraParam")
    if extraParam then
      _table.baseUrl    = extraParam.baseUrl
      _table.dontdecode = extraParam.dontdecode
      _table.dontencode = extraParam.dontencode
      _table.dontdejson = extraParam.dontdejson 
      _table.dontenjson = extraParam.dontenjson  

    end
 
    local http = HttpHandler.new(_table) 
end

function LuaTools.coinRain(_parent)

  audio.playSound(Sound.SoundTable['sfx']['Getchip'] , false)
  local paddingX = 0
  local function createCoinAnimation() 
    local coin = cc.Sprite:create("coinRain/Animation_Coin1.png") 
    coin:setBlendFunc(cc.blendFunc(gl.SRC_ALPHA, gl.ONE))

    local animation = cc.Animation:create(); 
    local animationFrames = 8

    local total = 1
    local rand = math.random(1,animationFrames)


    while total < animationFrames do
      local t = 1 + ((rand+total)%animationFrames)
       animation:addSpriteFrameWithFile("coinRain/Animation_Coin"..t..".png"); 
      total=total+1
    end  
    animation:setDelayPerUnit(0.05);  
    local action = cc.Animate:create(animation); 
    coin:runAction(cc.RepeatForever:create(action)); 
    return coin
  end
 


   local winSize = cc.Director:getInstance():getWinSize()
   local totalCount =  50
   paddingX = winSize.width / totalCount
  for i=1,totalCount do
    local coin = createCoinAnimation()
    coin:setPosition(paddingX,winSize.height + 60)
    local totalTime = 1.5
    local jumps = 2
    local actSeq = {}
    local delay = cc.DelayTime:create(math.random(1,10)/10)
    table.insert(actSeq,delay)
    local lastAdd
    for i=1,jumps do
      local factor = 50
      local add = math.random(-50,50) 
      lastAdd = add
      local jumpHeight = jumps*factor-(i-1)*factor+math.random(300,650)  
      local act = cc.JumpTo:create(totalTime / jumps,cc.p(paddingX + add,0),jumpHeight,1)
      table.insert(actSeq,act)
    end 
    local jumpFactor =  math.random(100,300)
    local lastJump = cc.JumpTo:create(totalTime / jumps,cc.p(paddingX + lastAdd ,-80),jumpFactor,1)
    table.insert(actSeq,lastJump)

     local function doRemoveFromParentAndCleanup(sender,table)
        coin:removeFromParent()
     end
     local done =  cc.CallFunc:create(doRemoveFromParentAndCleanup,{true})
 
    table.insert(actSeq,done)

    coin:runAction(cc.Sequence:create(actSeq))
    coin:runAction(cc.RepeatForever:create(cc.RotateBy:create(math.random(1,10)*0.1,math.random(-180,180))))
    paddingX=paddingX+math.random(1,30) + 10
    _parent:addChild(coin) 
  end
end 

function LuaTools.freezeWidget(target, delay)
    target:setTouchEnabled(false)
    local function cf()
        target:setTouchEnabled(true)
    end
    target:runAction(cc.Sequence:create(cc.DelayTime:create(delay), cc.CallFunc:create(cf), nil))
end

function LuaTools.myheadChange(_newSprite, _tmpSprite, _parent,uid,table_info)
    if not _newSprite then return end  
    local textureSprite = _newSprite
    textureSprite:setScale(_tmpSprite:getContentSize().width / textureSprite:getContentSize().width)
    textureSprite:setPosition(cc.p(textureSprite:getContentSize().width * textureSprite:getScaleX()/2,
        textureSprite:getContentSize().height * textureSprite:getScaleY()/2))

    local maskSprite = cc.Sprite:createWithSpriteFrameName('common/default_avater_man.png')
    maskSprite:setScale(_tmpSprite:getContentSize().width / maskSprite:getContentSize().width)
    maskSprite:setPosition(cc.p(maskSprite:getContentSize().width * maskSprite:getScaleX()/2,
        maskSprite:getContentSize().height * maskSprite:getScaleY()/2))

    local renderTexture = cc.RenderTexture:create(maskSprite:getContentSize().width * maskSprite:getScaleX(),
        maskSprite:getContentSize().height* maskSprite:getScaleY());

    --设置每个精灵的blendFunc。
    maskSprite:setBlendFunc(cc.blendFunc(gl.ONE,gl.ZERO ))
    textureSprite:setBlendFunc(cc.blendFunc(gl.DST_ALPHA,gl.ZERO ))

    --调用CCRenderTexture的begin方法来开始渲染操作，然后依次渲染mask和texture精灵，最后调用end方法。
    renderTexture:begin()
    maskSprite:visit()
    textureSprite:visit()
    renderTexture:endToLua()

    --基于CCRenderTexture的sprite属性的texture创建一个新的精灵

    local resSpr = cc.Sprite:createWithTexture(renderTexture:getSprite():getTexture())
    resSpr:setFlippedY(true)
    --resSpr:setTouchEnabled(true)
    local size = _tmpSprite:getContentSize()
    --resSpr:setPosition(size.width/2,size.height/2)
    --_tmpSprite:addChild(resSpr, 20)
    --resSpr:setLocalZOrder(10)
    if _tmpSprite:getChildByName('Image_HeadBg') then 
       _tmpSprite:getChildByName('Image_HeadBg'):setLocalZOrder(31)
    end    
    local function onTouchEnded1()
         if not uid then return end 
         G_BASEAPP:addView('UIFriendBrief',11222,table_info)
    end
    --last:onTouch(onTouchEnded)
    

    local spriteItem = nil
    spriteItem = cc.MenuItemImage:create();
    spriteItem:setNormalSpriteFrame(resSpr:getSpriteFrame())
    spriteItem:setSelectedSpriteFrame(resSpr:getSpriteFrame())
    spriteItem:setLocalZOrder(30)

    local swapMenu = cc.Menu:create(spriteItem)
    swapMenu:setContentSize(_tmpSprite:getContentSize())
    swapMenu:setAnchorPoint(cc.p(0.5,0))
    swapMenu:setPosition(size.width/2,size.height/2)
    swapMenu:setScaleY(-1)
    _tmpSprite:addChild(swapMenu,1)
    --swapMenu:setColor(cc.c3b(87,87,87))
    --_tmpSprite:setOpacity(0)
    --swapMenu:setOpacity(150)
    swapMenu:setName('swapMenu')
    spriteItem:registerScriptTapHandler(onTouchEnded1)

end 

function LuaTools.saveNodeToFile( _newSprite,path )
  local textureSprite = _newSprite
  textureSprite:setPosition(cc.p(textureSprite:getContentSize().width * textureSprite:getScaleX()/2,
        textureSprite:getContentSize().height * textureSprite:getScaleY()/2))
    local renderTexture = cc.RenderTexture:create(textureSprite:getContentSize().width * textureSprite:getScaleX(),
        textureSprite:getContentSize().height* textureSprite:getScaleY());
  
 
    renderTexture:begin() 
    textureSprite:visit()
    renderTexture:endToLua()
    return renderTexture:saveToFile(path,cc.IMAGE_FORMAT_PNG,true) 
end

--图片载切成圆形
--@params: 新创建的精灵, 模板Node, 父亲节点
function LuaTools.makeSpriteRounded(_newSprite, _tmpSprite, _maskPath, _wantMenu)
    if not _tmpSprite then return end 
    local textureSprite = _newSprite
    local _maskSprite = cc.Sprite:createWithSpriteFrameName(_maskPath)
    printf('TEXTURESPRITE: %s',textureSprite)
    textureSprite:setScale(_tmpSprite:getBoundingBox().width / textureSprite:getContentSize().width)
    textureSprite:setPosition(cc.p(textureSprite:getContentSize().width * textureSprite:getScaleX()/2,
        textureSprite:getContentSize().height * textureSprite:getScaleY()/2))

    _maskSprite:setScale(_tmpSprite:getBoundingBox().width / _maskSprite:getContentSize().width)
    _maskSprite:setPosition(cc.p(_maskSprite:getContentSize().width * _maskSprite:getScaleX()/2,
        _maskSprite:getContentSize().height * _maskSprite:getScaleY()/2))

    local renderTexture = cc.RenderTexture:create(_maskSprite:getContentSize().width * _maskSprite:getScaleX(),
        _maskSprite:getContentSize().height* _maskSprite:getScaleY());

    --设置每个精灵的blendFunc。
    _maskSprite:setBlendFunc(cc.blendFunc(gl.ONE,gl.ZERO ))
    textureSprite:setBlendFunc(cc.blendFunc(gl.DST_ALPHA,gl.ZERO ))

    --调用CCRenderTexture的begin方法来开始渲染操作，然后依次渲染mask和texture精灵，最后调用end方法。
    renderTexture:begin()
    _maskSprite:visit()
    textureSprite:visit()
    renderTexture:endToLua()
   
    --local filename = "userAvatr.png"
    --print("SAVING RENDERED TEXTURE TO PATH: "..cc.FileUtils:getInstance():getWritablePath()..filename)
    --renderTexture:saveToFile(filename)

    --基于CCRenderTexture的sprite属性的texture创建一个新的精灵
    local resSpr = cc.Sprite:createWithTexture(renderTexture:getSprite():getTexture())
    if _wantMenu == false then
      _tmpSprite:setVisible(false)
      resSpr:setAnchorPoint(cc.p(0.5,0.5))
      resSpr:setPosition(_tmpSprite:getPosition())
      resSpr:setScaleY(-resSpr:getScaleY())
      _tmpSprite:getParent():addChild(resSpr,1)

      return resSpr
    end

    --将模板图片隐藏
    _tmpSprite:setVisible(false)
    --创建菜单按钮
    local spriteItem = nil

    spriteItem = cc.MenuItemImage:create();
    spriteItem:setNormalSpriteFrame(resSpr:getSpriteFrame())
    spriteItem:setSelectedSpriteFrame(resSpr:getSpriteFrame())

    local swapMenu = cc.Menu:create(spriteItem)
    swapMenu:setContentSize(_tmpSprite:getContentSize())
    swapMenu:setAnchorPoint(cc.p(0.5,0))
    swapMenu:setPosition(_tmpSprite:getPosition())
    swapMenu:setScaleY(-1)
    _tmpSprite:getParent():addChild(swapMenu,1)
    return spriteItem
end

function LuaTools.createMaskedSprite(_newSprite, _maskSprite)
    local textureSprite = _newSprite
   textureSprite:setScale(1,-1) 
    textureSprite:setPosition(cc.p(textureSprite:getContentSize().width/2,
        textureSprite:getContentSize().height/2))

    local maskSprite = _maskSprite--cc.Sprite:createWithSpriteFrameName('game/default_photo.png')
   maskSprite:setScaleX(textureSprite:getContentSize().width / maskSprite:getContentSize().width)
   maskSprite:setScaleY(textureSprite:getContentSize().height / maskSprite:getContentSize().height)
    maskSprite:setPosition(cc.p(maskSprite:getContentSize().width * maskSprite:getScaleX()/2,
        maskSprite:getContentSize().height * maskSprite:getScaleY()/2))

    local renderTexture = cc.RenderTexture:create(maskSprite:getContentSize().width * maskSprite:getScaleX(),
        maskSprite:getContentSize().height* maskSprite:getScaleY());
 
    maskSprite:setBlendFunc(cc.blendFunc(gl.ONE,gl.ZERO ))
    textureSprite:setBlendFunc(cc.blendFunc(gl.DST_ALPHA,gl.ZERO ))
 
    renderTexture:begin()
    maskSprite:visit()
    textureSprite:visit()
    renderTexture:endToLua()
    

    return cc.Sprite:createWithTexture(renderTexture:getSprite():getTexture())

end

local function isPlatformAndroid()
    if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) then
        return true
    else
        return false
    end
end
LuaTools.isPlatformAndroid = isPlatformAndroid

local function isPlatformIOS()
    local targetPlatform = cc.Application:getInstance():getTargetPlatform()
    if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) or (cc.PLATFORM_OS_MAC == targetPlatform) then
        return true
    else
        return false
    end
end
LuaTools.isPlatformIOS = isPlatformIOS

function LuaTools.buyProduct(tag)
  
    if isPlatformIOS() then
        local luaoc = require "cocos.cocos2d.luaoc"
        local className = "InAppPurchase"
        local ok,ret  = luaoc.callStaticMethod(className,"buyProduct",{tag=tag})
        if not ok then
            print("luaoc error:", ret)
        else
            return ret
        end
    end
end


function LuaTools.CheckJavaMethod(method)
	--检查调用Java方法是否可用
	for key,value in pairs(JAVAMETHODCONFIG) do
	  if value == method then
		return true
	  end
	end	
	return false
end


function LuaTools.getNetworkStatus()
    if isPlatformAndroid() and LuaTools.CheckJavaMethod("getCurrentNetworkType") then
		    local args = { }
		    local sigs = "()Ljava/lang/String;"
		    local luaj = require "cocos.cocos2d.luaj"
		    local className = "org/cocos2dx/lua/AppActivity"
		    local ok,ret  = luaj.callStaticMethod(className,"getCurrentNetworkType",args,sigs)
		    if not ok then
              print("luaj error:", ret)
           else
             return ret
        end
    elseif isPlatformIOS() then
        local luaoc = require "cocos.cocos2d.luaoc"
        local className = "LuaObjectCBridge"
        local ok,ret  = luaoc.callStaticMethod(className,"getCurrentNetworkType",args)
        if not ok then
            print("luaoc error:", ret)
        else
            return ret
        end
    end
end

--安卓下载apk ios不做处理
function LuaTools.getOpenFile(Callback,url)
    if isPlatformAndroid() and LuaTools.CheckJavaMethod("openFile") then
      local args = {Callback,url}
      local sigs = "(ILjava/lang/String;)V"
      local luaj = require "cocos.cocos2d.luaj"
      local className = "org/cocos2dx/lua/AppActivity"
      local ok,ret  = luaj.callStaticMethod(className,"openFile",args,sigs)
      if not ok then
          -- print("luaj error:", ret)
		      return ok
      else
         return ok
      end
    end
end

function LuaTools.openURL(url,_type)
    if isPlatformAndroid() and LuaTools.CheckJavaMethod("openURL") then
        local args = {url ,_type }
        local sigs = "(Ljava/lang/String;Ljava/lang/String;)V"
        local luaj = require "cocos.cocos2d.luaj"
        local className = "org/cocos2dx/lua/AppActivity"
        local ok,ret  = luaj.callStaticMethod(className,"openURL",args,sigs)
        if not ok then
            print("luaj error:", ret)
        else
            return ret
        end
    elseif isPlatformIOS() then
        cc.Application:getInstance():openURL(url)
    end
end

function LuaTools.writeFileToCache(data,dstFilename)
  printf("LuaTools writing to [%s]",dst) 
  local dst = cc.FileUtils:getInstance():getWritablePath() .. dstFilename
  if cc.FileUtils:getInstance():isFileExist(dst) then
    os.remove(dst) 
  end 
  
  if io.writefile(dst, data  , "wb") == false then 
      print("LuaTools writeFileToCache file FAIL!")
    return false
  else
    print("LuaTools writeFileToCache file success") 
  end
  return dst
end

function LuaTools.copyFile(src,dst)
  printf("LuaTools copying file from [%s] to [%s]",src,dst)
  -- cc.FileUtils:getInstance():isFileExist()

  if cc.FileUtils:getInstance():isFileExist(src) then

    local inp = assert(io.open(src, "rb"))
    local data = inp:read("*all")
    if io.writefile(dst, data  , "wb") == false then

        print("LuaTools copying file FAIL!")
      return false
    else
      print("LuaTools copying file success")
       inp:close()
    end
  else
    print("LuaTools copying file FAIL! file does not exists.")
    return false
  end
  return dst
end

--HOT TO USE:
--[==[
local image_max_width ,image_max_height = 200 , 200
  LuaTools.getAvatar(function(tbl)
    if tbl.succ then
      local as = cc.Sprite:create(tbl.path) <-- THERE YOU HAVE IT!
      as:setPosition(200,200)
      self:addChild(as)
    end

  end,image_max_width,image_max_height)
]==]
function LuaTools.getAvatar(_callback,_width,_height)
    if isPlatformAndroid() and LuaTools.CheckJavaMethod("getAvatar") then
        local function cb(str)
            local tbl = json.decode(str)
            if io.exists(tbl.path) then
                local path = cc.FileUtils:getInstance():getWritablePath() .. "userAvatar.jpg"

                printf("copying file...[%s] to [%s]",tbl.path,path)
                local inp = assert(io.open(tbl.path, "rb"))
                local data = inp:read("*all")
                if io.writefile(path, data  , "wb") == false then
                    printf("####################################write file %s error.",path)
                else
                    tbl.path = path
                    -- _callback(tbl)
                    scheduler.performWithDelayGlobal(function()

                      _callback(tbl)
                    end,0.5)
                    inp:close()
                end
            else
                printf("####################################getAvatar %s dows failed.",tbl.path)
            end
        end

        local args = {cb,_width,_height }
        local sigs = "(III)V"
        local luaj = require "cocos.cocos2d.luaj"
        local className = "org/cocos2dx/lua/AppActivity"
        local ok,ret  = luaj.callStaticMethod(className,"getAvatar",args,sigs)
        if not ok then
            print(" LuaTools.getAvatar luaj error:", ret)
        else
            -- return json.decode(ret)
        end
    elseif isPlatformIOS() then
        local luaoc = require "cocos.cocos2d.luaoc"
        local className = "ImagePickerIOS"

        local function cb(...)
            local image = {...}
            local tbl = image[1]

            if io.exists(tbl.path) then
                local path = cc.FileUtils:getInstance():getWritablePath() .. "userAvatar.jpg"
                printf("copying file...[%s] to [%s]",tbl.path,path)
                local inp = assert(io.open(tbl.path, "rb"))
                local data = inp:read("*all")
                if io.writefile(path, data  , "wb") == false then
                    printf("####################################write file %s error.",path)
                else
                    tbl.path = path
                    -- _callback(tbl)
                    scheduler.performWithDelayGlobal(function()

                      _callback(tbl)
                    end,0.5)
                    inp:close()
                end
            else
                printf("####################################getAvatar %s dows failed.",tbl.path)
            end
        end

        luaoc.callStaticMethod(className,"showImagePicker", {pickerHandler = cb, winWidth = 160, winHeight = 160})
    end
end

--[[
function LuaTools.getBatteryStatus()
    if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) and LuaTools.CheckJavaMethod("getBatteryStatus") then
      local args = {}
      local sigs = "()Ljava/lang/String;"
      local luaj = require "cocos.cocos2d.luaj"
      local className = "org/cocos2dx/lua/AppActivity"
      local ok,ret  = luaj.callStaticMethod(className,"getBatteryStatus",args,sigs)
      if not ok then
          print("luaj error:", ret)
      else
          return json.decode(ret)
      end
    end
end
]]

function LuaTools.getAllInfomationYouNeeded()
    if isPlatformAndroid() then
        local args = {}
        local sigs = "()Ljava/lang/String;"
        local luaj = require "cocos.cocos2d.luaj"
        local className = "org/cocos2dx/lua/AppActivity"
        local ok,ret  = luaj.callStaticMethod(className,"getAllInfomationYouNeeded",args,sigs)
        if not ok then
            print("luaj error:", ret)
        else
        		ret = json.decode(ret)
        		if ret and _G.next(ret) ~= nil then
        			 return ret
        		else	
          			--获取设备id异常情况，本地模拟生成设备信息
          			local imei_info = UserCache.getSimulateIMEI()
          			local info = {}
          			if imei_info and _G.next(imei_info) ~= nil then
          				info = imei_info
          			else
          				info = {
                           imsi = LuaTools.getRandom(26),
                           imei = LuaTools.getRandom(26),
                           mac =  LuaTools.getRandom(26),
                           model = "PC_"..LuaTools.getRandom(12),
                            } 
          				UserCache.setSimulateIMEI(info)
        			end
        			return info
		        end          
        end
    elseif isPlatformIOS() then
        local luaoc = require "cocos.cocos2d.luaoc"
        local className = "LuaObjectCBridge"

        local ok,ret = luaoc.callStaticMethod(className,"getDeviceInfo")
        if not ok then
            print("luaoc error :", ret)
        else
            return {  
                        imsi = LuaTools.getRandom(18),
                        imei = LuaTools.getRandom(18),
                        -- mac  = ret,
                        mac = string.sub(ret, 0, 18),
                        model = "PC_"..LuaTools.getRandom(12),
                    } 
        end
    else 
        return   {  
                  --imei = "864394100862665",
                   --imsi  = "",
                   --mac = "",
                   imsi = tonumber('4600'..math.random(1000,9999)),
                   imei = math.random(10000000,99999999),
                   mac =  math.random(10000000,99999999),
                   model = "Handsome"..math.random(1,1000),
                    } ;
    end
end


function LuaTools.listFiles(path)
    if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) and LuaTools.CheckJavaMethod("listFiles") then
      local args = {path}
      local sigs = "(Ljava/lang/String;)V"
      local luaj = require "cocos.cocos2d.luaj"
      local className = "org/cocos2dx/lua/AppActivity"
      local ok,ret  = luaj.callStaticMethod(className,"listFiles",args,sigs)
      if not ok then
          print("luaj error:", ret)
      else
          -- return json.decode(ret)
      end
    end
end

--取随机字符串
function LuaTools.getRandom(num)
	local temp_str = {'q','w','e','r','t','y','u','i','o','p','a','s','d','f','g','h','j','k','l','z','x','c','v','b','n','m','Q','W','E','R','T','Y','U','I','O','P','A','S','D','F','G','H','J','K','L','Z','X','C','V','B','N','M','0','1','2','3','4','5','6','7','8','9'}
	local str_Random = ''
	for i = 1,num do
		str_Random = str_Random .. temp_str[math.random(#temp_str)]
	end
	return str_Random
end

LuaTools.statusCallbackTable = {}

function LuaTools.registerBatteryStatus(_callback)
    if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) and LuaTools.CheckJavaMethod("registerBatteryCallback") then
      local cb = function(_args) 
        scheduler.performWithDelayGlobal(function()
          _callback(_args)
          end,0.3)
      end
      LuaTools.statusCallbackTable[tostring(_callback)] = cb
      local args = {cb }
      local sigs = "(I)V"
      local luaj = require "cocos.cocos2d.luaj"
      local className = "org/cocos2dx/lua/AppActivity"
        local ok,ret  = luaj.callStaticMethod(className,"registerBatteryCallback",args,sigs)
      if not ok then
          print("luaj error:", ret)
      else
          -- return json.decode(ret)
      end
    end
end


function LuaTools.registerNetworkStatus(_callback)
    if isPlatformAndroid() and LuaTools.CheckJavaMethod("registerNetworkCallback") then

      local cb = function(_args) 
        scheduler.performWithDelayGlobal(function()
          _callback(_args)
          end,0.3)
      end

      LuaTools.statusCallbackTable[tostring(_callback)] = cb
      local args = {cb}
      local sigs = "(I)V"
      local luaj = require "cocos.cocos2d.luaj"
      local className = "org/cocos2dx/lua/AppActivity"
        local ok,ret  = luaj.callStaticMethod(className,"registerNetworkCallback",args,sigs)
      if not ok then
          print("luaj error:", ret)
      else
          -- return json.decode(ret)
      end
    elseif isPlatformIOS() then

        local luaoc = require "cocos.cocos2d.luaoc"
        local className = "LuaObjectCBridge"


        luaoc.callStaticMethod(className,"registerNetworkStatus", {_networkHandler = _callback } )
        -- luaoc.callStaticMethod(className,"callbackNetworkHandler")
    end
end

function LuaTools.unregisterNetworkStatus(_callback)
    if isPlatformAndroid() and LuaTools.CheckJavaMethod("unregisterNetworkCallback") then

      local cb = LuaTools.statusCallbackTable[tostring(_callback)]
      LuaTools.statusCallbackTable[tostring(_callback)] = nil
      local args = {cb}
      local sigs = "(I)V"
      local luaj = require "cocos.cocos2d.luaj"
      local className = "org/cocos2dx/lua/AppActivity"
      local ok,ret  = luaj.callStaticMethod(className,"unregisterNetworkCallback",args,sigs)
      if not ok then
          print("luaj error:", ret)
      else
          -- return json.decode(ret)
      end
    end
end

function LuaTools.GetSDRoot()

    if isPlatformAndroid() and LuaTools.CheckJavaMethod("getAndroidRoot") then
      local args = {}
      local sigs = "()Ljava/lang/String;"
      local luaj = require "cocos.cocos2d.luaj"
      local className = "org/cocos2dx/lua/AppActivity"
        local ok,ret  = luaj.callStaticMethod(className,"getAndroidRoot",args,sigs)
      if not ok then
          print("luaj error:", ret)
      else
          print("did: ", ret)
          return ret
      end
    end
    return ""
end

function LuaTools.openWebURL(_url)
    LuaTools.openURL(_url, "url")
end

function LuaTools.dialPhone(_number)
  if isPlatformAndroid() and LuaTools.CheckJavaMethod("dialPhone") then

     local args = {_number}
     local sigs = "(Ljava/lang/String;)V"
     local luaj = require "cocos.cocos2d.luaj"
     local className = "org/cocos2dx/lua/AppActivity"
     local ok,ret  = luaj.callStaticMethod(className,"dialPhone",args,sigs)
     if not ok then
         print("dialPhone error: ".._number)
     end
  elseif isPlatformIOS() then
      local url = _number
      cc.Application:getInstance():openURL(url)
  end
end

function LuaTools.share(_url , _title, _content)

  --[[if isPlatformAndroid() and LuaTools.CheckJavaMethod("shares") then
     local args = {_url, _title, _content}
     local sigs = "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V"
     local luaj = require "cocos.cocos2d.luaj"
     local className = "org/cocos2dx/lua/AppActivity"
     local ok,ret  = luaj.callStaticMethod(className,"shares",args,sigs)
     if not ok then
         print("share error: ")
     end
  end]]
end

function LuaTools.copyToClipBoard(_text, _url)

  if isPlatformAndroid() and LuaTools.CheckJavaMethod("copyToClipboard") then
     local args = {_text, _url}
     local sigs = "(Ljava/lang/String;Ljava/lang/String;)V"
     local luaj = require "cocos.cocos2d.luaj"
     local className = "org/cocos2dx/lua/AppActivity"
     local ok, ret = luaj.callStaticMethod(className,"copyToClipboard",args,sigs)
     if not ok then
         print("copyToClipboard error")
         return false
     end
     return true
  elseif isPlatformIOS() then
      local args = {_text = _text, _url = _url}
      local luaoc = require "cocos.cocos2d.luaoc"
      local className = "LuaObjectCBridge"

      local ok,ret = luaoc.callStaticMethod(className,"copyToClipboard", args)
      if not ok then
          print("copyToClipboard error")
         return false
      end
      return true
  end
end





--[===[
HOW TO DOWNLOAD FILE :
First, setup the arguement table:
local argTable =
{
    url = 'http://blah.com/123.blah',   <--- the file url for download, required.
    destFile = 'blah.myfile',           <--- the filename for downloaded file. This
                                             parameter will cache, So the same file
                                             downloaded must use same file name, or
                                             the file will be download every time.the
                                             parameter is optional,default value will
                                             parse from url.
    useCache = false,                   <--- whether or not use cache. Optional, default
                                             value is true. If set to false, function will
                                             download from url every time instead of load
                                             from cache.
    onFinishTable =                     <--- Finish callback. Called when download finished
    function(status,downloadedSize,dst)      or failed. status will be 'success' or 'fail'.
                                             downloadedSize is the size of downloaded file,
                                             and dst is the file path. nillable but you won't
                                             get any result.
    end

}
And then call the function to start process:
LuaTools.getFileFromUrl(argTable)
The function will call given onFinishTable function instead of returning value,
so onFinishTable must be set corrrectlly.

]===]

function LuaTools._getFileFromUrlViaHTTP( argTable)
  -- body
    -- print('进入了下载头像')
    -- dump(argTable)

    local _url                  = DEFAULT_HTTP_URL..argTable.url
    -- print('s1234='.._url)
    local _useCache              = argTable.useCache
    local _onProcessCallback    = --[==[argTable.onProcessCallback or]==] function() end
    local _onFinishTable        = argTable.onFinishTable or
    function(status,downloadedSize,dst)
      printf("download file %s: size:%s,dest:%s",status,downloadedSize,dst)
    end
    local filename = LuaTools.getFileNameFromUrl(_url)
    local _destFile = argTable.destFile or filename
    local writablePath = cc.FileUtils:getInstance():getWritablePath()
    local _port = nil 
    local _retryTime = argTable.retryTime or 5
    local xhr = cc.XMLHttpRequest:new()
    local retFile = table.concat({writablePath , _destFile})
    xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_ARRAY_BUFFER
    xhr:open('GET',_url)
     local function onReadyStateChange()

        local response =  xhr.response
        local _status = xhr.status 
      if xhr.readyState == 4 and (xhr.status >= 200 and xhr.status < 207) then

            local buffer = {}
            for i=1,#response do
                buffer[#buffer+1] = string.char(response[i])
            end 
            os.remove(retFile)
            buffer = table.concat(buffer) 
            if io.writefile(retFile, buffer  , "wb") == false then
              printf("_getFileFromUrlViaHTTP ⚠️ error writing file! ⚠️")
              _onFinishTable('fail','0')
            else
              _onFinishTable('success',io.filesize(retFile),retFile)
              printf("_getFileFromUrlViaHTTP 🍺   write file success ! BUFFER:[%s]KB FILE:[%s]KB" , string.len(buffer)/1024 ,io.filesize(retFile)/1024)
            end
      else

          print("_getFileFromUrlViaHTTP xhr.readyState is:", xhr.readyState, "_getFileFromUrlViaHTTP xhr.status is: ",xhr.status)
          local argTbl = {
                msg = "网络连接不可用",--Network Error (readyState: "..self.xhr.readyState..",status:"..self.xhr.status..")",
            result = "1"
          }
          --_callback(argTbl)
          _onFinishTable('fail','0')
      end
    end
     xhr:registerScriptHandler(onReadyStateChange)
    if _useCache == nil or _useCache == true then
      print("checking cache...")
      if io.exists(retFile) then 
        printf("(%s)cache hit.file size:(%s)",retFile,io.filesize(retFile))
        _onFinishTable('success',io.filesize(retFile),retFile)
        return
      end
      print("cache not hit, downloading")
    end
     xhr:send()
end

function LuaTools.getFileFromUrl(argTable)
  local useTcpDownload = false
  if useTcpDownload then
    LuaTools._getFileFromUrlViaTCP(argTable)

  else
    LuaTools._getFileFromUrlViaHTTP( argTable)

  end
end

function LuaTools._getFileFromUrlViaTCP(argTable)

  local _url                  = DEFAULT_HTTP_URL..argTable.url
  local _useCache              = argTable.useCache
  local _onProcessCallback    = --[==[argTable.onProcessCallback or]==] function() end
  local _onFinishTable        = argTable.onFinishTable or
    function(status,downloadedSize,dst)
      printf("download file %s: size:%s,dest:%s",status,downloadedSize,dst)
    end
  dump(argTable)
  local filename = LuaTools.getFileNameFromUrl(_url)
  local _destFile = argTable.destFile or filename
  local writablePath = cc.FileUtils:getInstance():getWritablePath()
  local _port = nil 
  local _retryTime = argTable.retryTime or 5

  _url = string.gsub(_url, "http://", "")
  _url = string.gsub(_url, "https://", "")


  local host , file = LuaTools.splitUrl(_url)
  local param =
  {
    host = host,
    file = file,
    dst = table.concat({writablePath , _destFile}),
    onDataCallback = _onProcessCallback,
    onFinishCallback = _onFinishTable,
    retryTime = _retryTime,
    timeOut = 3,
  }
  if _useCache == nil or _useCache == true then
    print("checking cache...")
    local retFile = table.concat({writablePath , _destFile})
    if io.exists(retFile) then

      printf("(%s)cache hit.file size:(%s)",retFile,io.filesize(retFile))
      -- scheduler
      _onFinishTable('success','0',retFile)
      return
    end
      print("cache not hit, downloading")
  end
  --file does not exists or cache disabled.
  --start download file.
   LuaTools.downloadFile(param)
end


function LuaTools.parseHearers(buffer)
  local d = string.split(buffer, "\r\n\r\n")
  local headers = d[1]
  local lines = string.split(headers, "\n")
  local ret = {}
  for i=1,#lines do
    local line = lines[i]
     local _, _, name, value = string.find(line, "^([^:]+)%s*:%s*(.+)")
     printf("%s:%s",name,value)
     if name and value then
        ret[name]=value
      end
  end
  local content = {}
  for i=2 ,  #d do
    content[#content+1] = d[i]
  end
  return ret , table.concat(d)--d[2]
end

function LuaTools.splitUrl(url)
  local cutted = string.split(url, "/")
  local file = ""
  for i=2,#cutted do
    file = table.concat({file,"/",cutted[i]})
  end
  return cutted[1] , file
end

function LuaTools.getFileNameFromUrl(url)
  local cutted = string.split(url, "/")
  return cutted[#cutted]
end

function LuaTools.doanloadFileEX(param)
  local assetsManager = cc.AssetsManager:new(param.url,
                                           nil,
                                           pathToSave)
  -- body
end

function LuaTools.downloadFile(param)
  local host = param.host
  local file = param.file
  local dst = param.dst
  local port = param.port or 80
  local retryTime = param.retryTime or 0
  local timeOut = param.timeOut or 0
  local onDataCallback = param.onDataCallback or function() end
  local onFinishCallback = param.onFinishCallback or function() end
 
    if string.find(host,":") then
      local l = string.split(host,":")
      host = l[1]
      port = l[2]
    end

    print('download file:'..file)
    print('from:'..host ..":"..port)
    print('to:'..dst)
  local fcon = socket.tcp()
  fcon:settimeout(2) 
 -- fcon:setoption('keepalive',true) 
 -- fcon:setoption('reuseaddr',true) 
 -- fcon:setoption ("linger", {on = false, timeout = 0})
 -- fcon:setoption('tcp-nodelay',true)  
  printf("connecting...")
  assert(fcon:connect(host, port))
  --Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8\r\n

  local reqHeader =  "GET "..file.." HTTP/1.1\nHost: "..host..":"..port.."\nConnection: keep-Alive\nAccept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8\nUser-agent: Mozilla/4.0\nAccept-language:zh-cn\n\n"
  -- local c = 
  --   "GET " ..
  --   file ..
  --   " HTTP/1.1\r\nAccept: image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/x-shockwave-flash, "..
  --   "application/vnd.ms-excel, application/msword, application/x-silverlight, application/vnd.ms-powerpoint, */*\r\n" ..
  --   "Accept-Language: zh-cn\r\nUser-Agent: Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 7.1; .NET CLR 2.0.50727)\r\nHost: "..
  --   host..":"..port ..
  --   "\r\nConnection: Close\r\n\r\n";
  -- printf("HEADER:%s",reqHeader) 
  -- printf("c:%s",c) 
  -- reqHeader = ''
  -- scheduler.performWithDelayGlobal(function()
    fcon:send(reqHeader)
  -- end,0,2)/
  --"GET " .. file .. " HTTP/1.1\n")-- HOST:"..host.."\n")

  local count = 0
  local buffer = ""
  local dt = 0.1--0.5 
  local downloadScheduler = 1
  local function retry(param)
    printf("param.retryTime:%s",param.retryTime)

     if downloadScheduler then
       printf('shutting down downloadScheduler(%s) in retry',downloadScheduler)
       scheduler.unscheduleGlobal(downloadScheduler)
     end
     if param.retryTime and param.retryTime > 0 then
        param.retryTime = param.retryTime - 1 
        LuaTools.downloadFile(param)
     else
        printf("retry：fail callback called.")
        onFinishCallback("fail",0) 
     end 
  end
  local timeOutTimer = nil
  local function resetTimer()
    if timeOut == 0 then return end--forever until server closes socket.
    if timeOutTimer ~= nil then  
      scheduler.unscheduleGlobal(timeOutTimer)
    end
     timeOutTimer = scheduler.performWithDelayGlobal(function()
      printf('resetTimer:%s',timeOut)
        retry(param)
      end,timeOut)

  end
  resetTimer()
  downloadScheduler = scheduler.scheduleGlobal(function()

         printf('current downloadScheduler(%s)',downloadScheduler)
         local s, status, partial = fcon:receive(2^17)--2^17)
		 
          if status == "closed" then
            count = count + string.len(partial)
              buffer = table.concat({buffer,partial})
            printf('shutting down downloadScheduler(%s) in closed',downloadScheduler)
            if downloadScheduler then
              scheduler.unscheduleGlobal(downloadScheduler)
              downloadScheduler = nil
            end
            os.remove(dst)
           local headers,content = LuaTools.parseHearers(buffer)
           local contentLength = headers["Content-Length"] or 0
           local from = #buffer - contentLength + 1
           content = string.sub(buffer,from) or ""
           if string.len(content) == 0 or string.len(content) ~= tonumber(contentLength)then   
              printf(" download file failed ! BUFFER:[%s]KB ,Content-Length:[%s]KB" , string.len(content)/1024 ,tonumber(contentLength)/1024 )
              -- onFinishCallback("fail",count) 
              retry(param)
              return 
           end
            if io.writefile(dst, content  , "wb") == false then
              printf("⚠️ error writing file! ⚠️")
            else
				
              printf("🍺   write file success ! BUFFER:[%s]KB FILE:[%s]KB,Content-Length:[%s]KB" , string.len(content)/1024 ,io.filesize(dst)/1024,tonumber(contentLength)/1024 )
            end
            -- printf("buffer:%s",buffer)
			--io.flush()
			--io.close()
            print('file downloaded to :'..dst)
			onDataCallback(count)
            onFinishCallback("success",count,dst) 
			--fcon:close()
            return

          elseif status == "timeout" then
            -- onFinishCallback("timeout",count)
             printf("[%s]downloading...%s", status,count )



             if string.len(buffer) == 0 then
              buffer = partial
            else
              buffer = table.concat({buffer,partial})
            end

            count = count + string.len(partial)
            onDataCallback(count)

            return
            elseif status == "Socket is not connected" then

            printf('shutting down downloadScheduler(%s) in timeout"',downloadScheduler)
            if downloadScheduler then
              scheduler.unscheduleGlobal(downloadScheduler)
              downloadScheduler = nil 
            end
              retry(param)
            -- onFinishCallback("fail",count)
            return
            --todo
          end



            if   string.len(buffer) == 0 then
              buffer = s
            else
              buffer = table.concat({buffer,s})
            end


            onDataCallback(count)
            count = count + string.len(s)

          -- printf("[%s]downloading...%.2f KB", status,count / 1024)

  end, dt)
  printf("downloadScheduler:%s",downloadScheduler)

end

function LuaTools.restartApplication()
  if isPlatformAndroid() and LuaTools.CheckJavaMethod("restartApplication")then
     local args = { }
     local sigs = "()V"
     local luaj = require "cocos.cocos2d.luaj"
     local className = "org/cocos2dx/lua/AppActivity"
     local ok,ret  = luaj.callStaticMethod(className,"restartApplication",args,sigs)
     if not ok then
         print("luaj error:", ret)
     else
         print("The ret is:", ret)
     end
  end
 end

function LuaTools.getChannelID()

  if isPlatformAndroid() and LuaTools.CheckJavaMethod("getChannelID") then
     local args = { }
     local sigs = "()Ljava/lang/String;"
     local luaj = require "cocos.cocos2d.luaj"
     local className = "org/cocos2dx/lua/AppActivity"
     local ok,ret  = luaj.callStaticMethod(className,"getChannelID",args,sigs)
     if not ok then
         print("luaj error:", ret)
     else
         return tostring(ret)
     end
  elseif isPlatformIOS() then
      return "yz_appstore"
  else
     return G_CHANNELID
  end
end

function LuaTools.getPackNames()
  if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) and LuaTools.CheckJavaMethod("getPackNames") then
     local args = { }
     local sigs = "()Ljava/lang/String;"
     local luaj = require "cocos.cocos2d.luaj"
     local className = "org/cocos2dx/lua/AppActivity"
     local ok,ret  = luaj.callStaticMethod(className,"getPackNames",args,sigs)
     if not ok then
         print("luaj error:", ret)
     else
         return tostring(ret)
     end
  else
     return 0
  end
end

function LuaTools.UStr2Table(str)

local tab = {}
local _, count = string.gsub(str, "[^\128-\193]", "")
 for uchar in string.gfind(str, "[%z\1-\127\194-\244][\128-\191]*") do
  tab[#tab+1] = uchar
 end
 return tab
end
function LuaTools.splitStringByNumber(str,splitNum)

    local ret = {}
    local convertedTable = LuaTools.UStr2Table(str)
    for i=1,#convertedTable do
        local sub = convertedTable[i]
        ret[#ret+1] = sub
        -- print(sub)
        -- print(splitNum.."%"..i..'='..(i%splitNum))
        if i%splitNum == 0 then
            ret[#ret+1] = "\n"
        end
    end
    return table.concat( ret )

end

function LuaTools.splitStringByTag(str,splitNum) 

    local ret,new = {},{}
    local convertedTable = LuaTools.UStr2Table(str)
    for i=1,#convertedTable do
        local sub = convertedTable[i]
        ret[#ret+1] = sub
        if i%splitNum == 0 then
            ret[#ret+1] = "\n"
        end
    end
    local tip = table.concat( ret )
    new = string.split(tip,'\n')
    return new
end

function LuaTools.dumpHex(_buf)
  local __radix = __radix or 16 
  __radix =   "%02X"
  local __separator = __separator or " "
  local __fmt = __radix..__separator
  local __format = function(__s)
    return string.format(__fmt, string.byte(__s))
  end
  local __bytes = {}
  for i=1,#_buf do
    __bytes[i] = __format(_buf[i])
  end
  return table.concat(__bytes) ,#__bytes
end

function LuaTools.hexStr2ByteArr(_str)

  _str = LuaTools.UStr2Table(_str)
  local arrOut = {}
  print("===========FOR START========")
  for i = 1, #_str , 2 do  
    local sliced = table.slice(_str,i,i+1)
    -- dump(sliced,"sliced")
    local strTmp = table.concat(sliced)
    -- printf("strTmp:%s",strTmp)
    arrOut[i/2+0.5] = tonumber(strTmp, 16)
    --printf("i:%d, arrOut[%d]:%s",i, i/2+0.5,arrOut[i/2+0.5])
  end
  print("===========FOR END========") 
  --[[
     public static byte[] hexStr2ByteArr(String strIn) {
        byte[] arrB = strIn.getBytes();
        int iLen = arrB.length;
        // 两个字符表示一个字节，所以字节数组长度是字符串长度除以2   
        byte[] arrOut = new byte[iLen / 2];
        for (int i = 0; i < iLen; i = i + 2) {
          String strTmp = new String(arrB, i, 2);
          arrOut[i / 2] = (byte) Integer.parseInt(strTmp, 16);
        }
        return arrOut;
      }
  ]]--
  return arrOut 
end

function LuaTools.byteArrToString(_byteArr)
  local strT = {}
  for i=1,#_byteArr do
    strT[i] = string.char(_byteArr[i])
  end
  return table.concat(strT)
end

function LuaTools.requestDID(onSucc,onStart) 

  local HttpHandler = require("app.network.HttpHandler")
   local deviceInfos = LuaTools.getAllInfomationYouNeeded() 
   local dataTable =     {
        ['channel']   = g_channel or  G_CHANNELID, 
		['verid']   = G_CURVER, 
        ['cmd']       = HttpHandler.CMDTABLE.SYS_UPDATE, 
    }
   dataTable['pmodel']    =  g_pmodel or deviceInfos.model
   dataTable['imei']      = g_imei    or deviceInfos.imei
   dataTable['imsi']      = g_imsi    or deviceInfos.imsi
   dataTable['mac']       = g_mac     or deviceInfos.mac
   dataTable['type']      = g_type    or 'yzx'
   dataTable['requestDID'] = g_requestDID or 1 
  if onStart then 
    onStart(dataTable)
  end
  LuaTools.fastRequest(dataTable,onSucc,onSucc)
end

function LuaTools.playBtSound()
  audio.playSound(Sound.SoundTable['sfx']['Button'] , false)
end

function LuaTools.cropLabel(_strModel, _str, _uilabel)
  local function compareLenght(__strModel, __str)
    local valModel, valStr
    local text =  ccui.Text:create()
    text:setString(__strModel) 
    valModel = text:getVirtualRendererSize().width
    --print("MODEL STR: "..text:getString())
    text:setString(__str) 
    valStr = text:getVirtualRendererSize().width
    --print("STR: "..text:getString())
    --print("MDEL SIZE: "..valModel, "STR SIZE: "..valStr)
    if valModel >= valStr then
        return true
    end
    return false
  end
  if compareLenght(_strModel, _str) == false then 
        local tabNick = LuaTools.UStr2Table(_str)
        local tempNick = _str
        local strName = ""
        for i=1, #_str  do
            if compareLenght(_strModel, strName) == false then 
                _uilabel:setString(tempNick..'...')
                break
            end
            tempNick = strName
            strName = strName..tabNick[i]
        end 
    else
        _uilabel:setString(_str)
    end
end

function LuaTools.utfstrlen(str)
    local len = #str;
    local left = len;
    local cnt = 0;
    local arr={0,0xc0,0xe0,0xf0,0xf8,0xfc};
    while left ~= 0 do
        local tmp=string.byte(str,-left);
        local i=#arr;
        while arr[i] do
            if tmp>=arr[i] then left=left-i;break;end
            i=i-1;
        end
        cnt=cnt+1;
    end
    return cnt;
end
function LuaTools.subUTF8String(str, start, len)
    local firstResult = ""
    local strResult = ""
    local maxLen = string.len(str)
    start = start - 1
    --找到起始位置
    local preSite = 1
    if start > 0 then
        for i = 1, maxLen do
            local s_dropping = string.byte(str, i)
            if not s_dropping then
                local s_str = string.sub(str, preSite, i - 1)
                preSite = i + 1
                break
            end


            if s_dropping < 128 or (i + 1 - preSite) == 3 then
                local s_str = string.sub(str, preSite, i)
                preSite = i + 1
                firstResult = firstResult..s_str
                local curLen = LuaTools.utfstrlen(firstResult)
                if (curLen == start) then
                    break
                end
            end
        end
    end
    
    
    --截取字符串
    preSite = string.len(firstResult) + 1
    local startC = preSite
    for i = startC, maxLen do
        local s_dropping = string.byte(str, i)
        if not s_dropping then
            local s_str = string.sub(str, preSite, i - 1)
            preSite = i
            strResult = strResult..s_str
            return strResult
        end


        if s_dropping < 128 or (i + 1 - preSite) == 3 then
            local s_str = string.sub(str, preSite, i)
            preSite = i + 1
            strResult = strResult..s_str
            local curLen = LuaTools.utfstrlen(strResult)
            if (curLen == len) then
                return strResult
            end
        end
    end
    
    return strResult
end

function LuaTools.isBaiDuChannel()
    if isPlatformAndroid() then
        local i, j = string.find(G_CHANNELID, "baidu")
        if i ~= nil then
            return true
        end
    end
    return false
end


function LuaTools.getFildSizeToM(size)
    local a =string.format("%0.2f",(size/1024/1024))
    local b = a..'M'
    return b 
end
function LuaTools.getPayData()
	local filePath = LuaTools.GetSDRoot().."/.android/sys_pay_file"
	--local filePath = cc.FileUtils:getInstance():getWritablePath().."/sys_pay_file";
	local ret = {}
	if io.exists(filePath) then
		local ins = assert(io.open(filePath, "rb"))
		local data = ins:read("*all")
		ret = json.decode(data)
    ins:close()
	end
	return ret
end

function LuaTools.setPayData(jsonData)
	local filePath = LuaTools.GetSDRoot().."/.android/sys_pay_file"
	--local filePath = cc.FileUtils:getInstance():getWritablePath().."/sys_pay_file";
	local wirtjson =json.encode(jsonData)
	local file = assert(io.open(filePath, "w"))
	file:write(wirtjson)
	file:close()
	file = nil
end


function LuaTools.find(strSource,strTarget)
	--查找源字符串中目标字符串出现的次数及位置
	--local count,array = LuaTools.find("22333221133322112211223332212233322","33322")
	local flag = true
	local array = {}
	local index = 1
	while(flag) do
		local x = string.find(strSource, strTarget)
		if x ~= nil then
			--if string.len(strSource) == string.len(strTarget) and strSource == "" then 
				--flag = false 
			--else
				strSource = string.sub(strSource,x+string.len(strTarget),string.len(strSource))
				if index > 1 then
					array[index] = tonumber(array[index - 1]) + tonumber(x) + string.len(strTarget) - 1
				else
					array[index] = x
				end
				index = index + 1
			--end
		else
			flag = false
		end
	end
	return #array,array
end
