
local mvc = cc.load("mvc")
local ModelBase = mvc.ModelBase
local AppBase = mvc.AppBase

local MyApp = class("MyApp", AppBase)

--local new_view = {"UITips"}  --,"UIWaiting"
--local pop_view = {"UITips"}
local order_view = {}
local winSize = cc.Director:getInstance():getWinSize()

local TCPConnector = require('app.network.TCPConnector')
local DataPacker = require('app.network.DataPacker')
local DataUnpacker = require('app.network.DataUnpacker')
local PlayerData = require('app.data.PlayerData')
local display = require('cocos.framework.display')
function MyApp:onSuccess(arg)
 if arg.networkSucc == true then

 else

 end
end
function MyApp:onCreate()
 -- cc.GLView:setDesignResolutionSize(1224,720)
 printf('====================================')
 printf('====================================')
 printf('====================================')
 printf('===============VERSION==============')
 printf('===============[%s]==============',G_VERSION)
 printf('====================================')
 printf('====================================')
 printf('====================================')
 printf('====================================')

 math.randomseed(os.time())

 local spriteFrameCache = cc.SpriteFrameCache:getInstance()
 --spriteFrameCache:addSpriteFrames("faceicon.plist")
 --spriteFrameCache:addSpriteFrames("card.plist")
 --spriteFrameCache:addSpriteFrames("login.plist")
 --spriteFrameCache:addSpriteFrames("faceicon.plist")
 --spriteFrameCache:addSpriteFrames("newcard.plist") 
-- spriteFrameCache:addSpriteFrames("common.plist") 
-- spriteFrameCache:addSpriteFrames("res_profile.plist") 
-- spriteFrameCache:addSpriteFrames("res_friendBrief.plist") 


 --spriteFrameCache:addSpriteFrames("body/main_animation/landlord_textures.plist")


 --spriteFrameCache:addSpriteFrames("hall.plist")

--    local armatureDataManager = ccs.ArmatureDataManager:getInstance()
--    armatureDataManager:addArmatureFileInfo("res/effect/equip/equip.csb")

------------------------------------------------------------------------
 self:temporaryEnableGlobal()

 appInstance = self
 self.data_ = require("app.data.init"):create(self, "Data")

 self:restoreGlobalSetting()
---------------------------------------------------------------------------

 self.models_ = require("app.models.init"):create(self, "Models")
--    self.widgets_ = require("app.widgets.init"):create(self, "Widgets")
 self.schedule_ = self:getModel("Schedule")


 self.order_view = {}
end

function MyApp:temporaryEnableGlobal()
 self.metatable = getmetatable(_G)

 setmetatable(_G, nil)
end

function MyApp:restoreGlobalSetting()
 if self.metatable then
     setmetatable(_G, self.metatable)
 end
end

function MyApp:addModel(name, ...)
 local model = self.models_:getModel(name)
 if model == nil then
     model = self.models_:addModel(name, ...)
 end

 return model
end

function MyApp:getModel(name)
 return self.models_:getModel(name)
end

function MyApp:removeModel(name)
 self.models_:removeModel(name)
end
function MyApp:getData(name)
 return self.data_:getData(name)
end
function MyApp:getSchedule(name)
 return self.schedule_:getSchedule(self, name)
end

function MyApp:createSchedule(name, handler, interval, duration)
 return self.schedule_:addSchedule(self, name, handler, interval, duration)
end

function MyApp:stopSchedule(name)
 self.schedule_:stopSchedule(self, name)
end
--[====[
-- function MyApp:addView(name, zOrder, ...)
--  local result
--  if order_view[name] then
--      for key, var in pairs(order_view) do
--      if self:getView(key) then
--        result = true
--      end
--    end

--    if result then
--          self.order_view[name] = {zOrder = zOrder, arg = {...}}
--    end
--  end

--  if not result then
--      local view = AppBase.addView(self, name, zOrder, ...)
--      return view

--  end
-- end

function MyApp:removeView(name)
 AppBase.removeView(self, name)

 if order_view[name] then
     local key, var = next(self.order_view)
     if var then
         self:addView(key, var.zOrder, unpack(var.arg))
         self.order_view[key] = nil
     end
 end
end

function MyApp:enterScene(name, --[[transition, time, more, --]]...)
 --local views = self:getPersistentViews(new_view)

 --printf("MyApp -->>scene:%s,view:%s",name,view )
 local scene,view = AppBase.enterScene(self, name, ...)

 --printf("MyApp ====>>>>>>>scene:%s,view:%s",scene,view )
 --self:setPersistentViews(views)

 return scene,view
end

function MyApp:pushScene(name,params)
 --local views = self:getPersistentViews(new_view)

 local scene ,view = AppBase.pushScene(self, name,params)
 --self:setPersistentViews(views)


 return scene,view 
end

function MyApp:getPersistentViews(views)
 local scene = display.getRunningScene()
 if not scene then
   return
 end

 local views = {}

 if self.views_[scene] then
     for key, var in ipairs(views) do
         var:retain()
         var:removeFromParent(false)
         views[var] = self.views_[scene][var]
     end
 end

 return views
end

function MyApp:setPersistentViews(views)
 for key, var in pairs(views) do
     self:addView(var, var:getLocalZOrder())
     var:release()
 end

--    if views["UIWaiting"] then
--        views["UIWaiting"]:setCountAndTotal(0, 0)
--    end
end

function MyApp:popScene()
 --local views = self:getPersistentViews(pop_view)

 local scene = AppBase.popScene(self)

 --self:setPersistentViews(views)

 return scene
end

function MyApp:getWinSize()
 return winSize
end

function MyApp:enterMain()
 --self:enterScene("UIMain")
 --self:setMainMusic()
end

function MyApp:setMainMusic()
 --[[if not self.audio_main then
     self.audio_main = ccexp.AudioEngine:play2d('res/sound/main.mp3',true)
 else
     ccexp.AudioEngine:resume(self.audio_main)
 end--]]


-- cc.SimpleAudioEngine:getInstance():playMusic('res/sound/main.mp3',true)

end

]====]
return MyApp
