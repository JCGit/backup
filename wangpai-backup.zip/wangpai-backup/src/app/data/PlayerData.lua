local PlayerData = class("PlayerData", cc.load("mvc").ModelBase)

function PlayerData:onCreate()

--登录返回字段
    self.uid = 0
    self.nick = 0
    self.sex  = 0           --0男  1女
    self.uuid  = 0
    self.contact = 0
    self.area = ''
    self.icon   = ''        --用户头像地址默认为空 
    self.type  = 0 
    self.modify_pw = 0      --是否为游客 0.游客
    self.status   = 0       --帐号状态
    self.coin   = 0         --用户金币数
    self.gem  = 0           --用户宝石
    self.charm   = 0        --魅力值
    self.level  = 0
    self.accu  = 0          --积分
    self.telfee   = 0       --话费
    self.bank = 0
    self.wins = 0 
    self.m_accu   = 0
    self.m_level  = 0
    self.m_round   = 0
    self.vip_type   = 0
    self.vip_day   = 0      --Vip剩下天数
    self.vip_level   = 0    --Vip等级
    self.vip_time = ""
    self.vip_reward = 0     --vip 工资
    self.vipvalid = 0 
    self.faileds    = 0
    self.paytotal  = 0   --充值
    self.gpackFlag = 0   --购买礼包的标志
    self.chatLogCount = 0
    self.bag   = 0
    self.token   = 0
    self.did   = 0
    self.dids   = 0
    self.didTag  = 0 
    self.clan  = 0
    self.couple  = ""
    self.payed   = 0
    self.scode  = 0
    self.nsr   = 0
    self.smsg   = 0
    self.userinfo = ''
    self.announcement  = 0
    self.updatePacks =  {}  --各种礼包
    
    self.signStadus =   0   --签到状态
    self.ifGetTaxOpen = 0   --私人场收税打开关闭
    self.matchFirstOneInfo = {} 

    self.pmul  = 0
    self.qhid   = 0
    self.filterck  = 0  --1:禁用大转盘  0：启用
    self.gift   = {0,0,0,0,0,0,0}   --1.鲜花 2.鸡蛋 3.汽车 4.轮船 5.直升机 6.摩托车 7.别墅
    self.prop  = {0,0,0}      --['4']=1.踢人卡    ['7']=2.小喇叭  ['1']=3.门票  
    self.firstpay = {} --eg:{"6":1,"10":1,"20":1,"30":1,"50":1,"100":1,"300":1,"500":1}
    self.mms_seq = {}
    self.API_VER = 0
    self.divorceCost = 0
    self.gameFilter = {}         --开放的游戏场
    self.gameFilterNumber = 0    --开放游戏场的个数
    
    self.limitedProduct = 0     --限时礼包

    self.onlinePlayerNumber = 0 --在线人数
    self.playGuidingMusic = false 

    self.lotteryForFree  = 0   --大转盘是否免费
    --个人信息游戏信息
    self.infoDDZ = {}
    self.infoDN = {}
    self.infoZJH = {}
    self.infoPOKER = {}
    self.infoPDK = {}
    self.infoSJ = {}
    self.infoDD = {}  --54斗地主

    self.scoreActive = 0 --积分兑换
    --新增判断标志位
    self.bitcheck = 0  
    self.bitcheckCaiNiao = 0   --是否是菜鸟
    self.bitcheckFund    = 0   --是否购买了基金 
    self.bitFundFinish   = 0   --基金任务是否已全部完成

    self.newbieProgress    = 0   --是否购买了基金 
    self.defaultWeixinAddress = 0  --0: yz地址  1：广点通地址

    self.isFirstLoginGame = 0 
    self.isfirstLoginShow = 0 
    self.gamePorts = {}

    self.bankPwd =  ""--存储已输入的取钱密码
    --extraAccount 里的字段
    self.isBindPhone = 0
    
    self.isBankProtect = 0
    self.bankQuestion = 0
    self.nickChanged = 0

    self.pdkGameInfo  = {}  --跑得快信息
    self.wpdzGameInfo = {} --王牌斗地主信息

    self.forbid  = 0    --禁用功能选项
    
    self.condays= 0     --连续登录天数
    
    self.signDays = 0   --已签到天数
    
    self.firstLogin  = 0   --是否首次登陆   
    
    self.growth = 0     --vip 经验值
    
    self.vipSigned = 0       --是否已领取VIP每日礼包
    
    self.newUser = 0        --是否是新玩家
    
    self.totalTime = 0 

    self.gameRedPackets = {
     ['1']   = {0,0,0,0},   --55斗地主
     ['122'] = {0,0,0,0}   --54斗地主
    }
        
    self.iconPath = '' --头像绝对路径
    
    self.dailyProduct = 0 --每日礼包1开放 ， 0：关闭  
    self.friend = 0     --好友
    self.friendUidList = {}  

    self.getReward = 1 
    
    self.firstCharge = 0 

    self.isShowSpreeView = true
    
    self.update= 0      --是否有新版本 1表示有新版本 0表示没有 2:表示强制更新
    
    self.nsr= 0         --0：没有奖励 ,1：每日签到奖励,2：vip奖励,3：每日奖励和vip奖励

    self.broadcastColor = 0
    
    self.stime = 0      --server time in sec

    self.isBindAccountDlgShowed = false
    
    self.newPlrReward = 0
    self.dayReward = 0
    self.listRewards = {}
    
    --[[ others game variables ]]--
    self.smsCodeTimeEnable = 0

    self.avatarLoaded = false               --是否加载过用户的头像
    self.lastTimeRefreshNewPlayers = 0      --保存上一次刷新新人旁列表时间
    self.defaultNickPosition = nil          --保存大厅用户昵称默认的位置
    
    --[[ 支付句柄 ]]--
    self.AlipayHandler = nil
    self.YibaoHandler = nil

    self.maxFriend = 0
    self.weddingVoice = true 


    -- self.packageNameNumber =  0   --渠道编号
    --设置的信息
    self.settings = {
       background_volume = 0.5,    --background volume 
       effect_volume = 0.7,    --effect volume
       vibration = 1,    --vibration
       notification = 1,    --notification
    }
    self.GameTypes = {
        GameType_DDZ = {},
        GameType_QDZ = {},
        GameType_DN = {},
        GameType_ZJH = {},
        GameType_WRDN = {},
        GameType_PDK = {},
        GameType_DDZNOR = {},
        GameType_MATCH = {}, 
    }   
    self.MainRanks = {{}, {}}

    self.braodCastObject = {}   --广播UI实例
       
    --商城购买金币列表
    self.shopChips = {}
    self.showChipsQuick = {}
    
    --商城购买砖石列表
    self.shopDiamonds = {}
    
    --商城购买VIP列表
    self.shopVip = {}
    
    --商城购买道具列表
    self.shopItems = {}
    
    --商城积分兑换列表
    self.shopAccu = {}
    
    self.UIMainSocketTable = {}
    
    self.listBroadcastMsg = {}  --广播信息列表
    self.broadcastRecord = {}
    self.chatRecord    = {}
    self.chatLogNumber = 0 
    self.chatLogTable  = {}
    self.faceIconRecord = {}    --房间内聊天记录
    
    self.newMailCount = 0       --新邮件数量

    self.warningId  = 0 
    
    self.friendUid = {}
    self.rankInfo  = {0,0,0,0}

    self.core  =  0    --核心成员 
    self.fmb   =  ''    --是否是家族成员
    self.idBindingPhone = false   --是否绑定了手机 

    self.showOneGame   =  0    --显示1个游戏

    self.matchOpen = 0   --比赛场开关   

    self.showWinMoreMoney = false  --30w提示

    self.iosPayOpen = 0    --ios支付开关
    --------------------------------------------------------------


    self.cardType = {       
        {'高牌','一对','两对','三条','顺子','同花','葫芦','金刚','同花顺','皇家同花顺'}, 
        {'High Card','One Pair','Two Pairs','Three of a kind','Straight','Flush'
        ,'Full House','Four of a kind','Straight Flush','Royal Flush'}}   
    --------------------------------------------------------------
                                                      
------------------------------------------------------------------------------------

end

function PlayerData:getCard(info)
    local image 
    if type(info) ~= number then 
       info = tonumber(info)
    end    
    if not info or info==0 then  return end 
    if info > 17 and info <= 30 then           --方块
       image = self:getDiamonds(info)
       
    elseif  info >= 34 and info <= 46   then   --梅花    
        image = self:getClubs(info)   
        
    elseif  info >= 50 and info <= 62   then   --红桃   
        image = self:getHearts(info)
        
    elseif  info >= 66 and info <= 78   then   --黑桃
        image = self:getSpades(info)                 
    end
    
    return image
end 

function PlayerData:getDiamonds(info)
    local image 
    if info == 0x12      then 
        image = 'card/card_diamonds_2.png'
    elseif info ==0x13  then 
        image = 'card/card_diamonds_3.png'
    elseif info ==0x14   then 
        image = 'card/card_diamonds_4.png'
    elseif info ==0x15   then 
        image = 'card/card_diamonds_5.png'
    elseif info ==0x16   then 
        image = 'card/card_diamonds_6.png'
    elseif info ==0x17   then 
        image = 'card/card_diamonds_7.png' 
    elseif info ==0x18   then 
        image = 'card/card_diamonds_8.png'
    elseif info ==0x19   then
        image = 'card/card_diamonds_9.png'
    elseif info ==0x1a   then 
        image = 'card/card_diamonds_10.png'
    elseif info ==0x1b   then 
        image = 'card/card_diamonds_11.png'
    elseif info ==0x1c   then 
        image = 'card/card_diamonds_12.png'
    elseif info ==0x1d   then 
        image = 'card/card_diamonds_13.png'
    elseif info ==0x1e   then 
        image = 'card/card_diamonds_1.png'
    end 
    return image
end 


function PlayerData:getClubs(info)
    local image 
    if info == 0x22      then 
        image = 'card/card_clubs_2.png'
    elseif info ==0x23   then
        image = 'card/card_clubs_3.png'
    elseif info ==0x24   then 
        image = 'card/card_clubs_4.png'
    elseif info ==0x25   then 
        image = 'card/card_clubs_5.png'
    elseif info ==0x26   then 
        image = 'card/card_clubs_6.png'
    elseif info ==0x27   then 
        image = 'card/card_clubs_7.png'
    elseif info ==0x28   then 
        image = 'card/card_clubs_8.png'
    elseif info ==0x29   then 
        image = 'card/card_clubs_9.png'
    elseif info ==0x2a   then 
        image = 'card/card_clubs_10.png'
    elseif info ==0x2b   then 
        image = 'card/card_clubs_11.png'
    elseif info ==0x2c   then 
        image = 'card/card_clubs_12.png'
    elseif info ==0x2d   then 
        image = 'card/card_clubs_13.png'
    elseif info ==0x2e   then 
        image = 'card/card_clubs_1.png'
    end     
                                                                                
    return image
end 

function PlayerData:getHearts(info)
    local image 
    if info == 0x32      then 
        image = 'card/card_hearts_2.png'
    elseif info ==0x33  then 
        image = 'card/card_hearts_3.png'
    elseif info ==0x34   then 
        image = 'card/card_hearts_4.png'
    elseif info ==0x35   then 
        image = 'card/card_hearts_5.png'
    elseif info ==0x36   then 
        image = 'card/card_hearts_6.png'
    elseif info ==0x37   then 
        image = 'card/card_hearts_7.png'
    elseif info ==0x38   then 
        image = 'card/card_hearts_8.png'
    elseif info ==0x39   then 
        image = 'card/card_hearts_9.png'
    elseif info ==0x3a   then 
        image = 'card/card_hearts_10.png'
    elseif info ==0x3b   then 
        image = 'card/card_hearts_11.png'
    elseif info ==0x3c   then 
        image = 'card/card_hearts_12.png'
    elseif info ==0x3d   then 
        image = 'card/card_hearts_13.png'
    elseif info ==0x3e   then 
        image = 'card/card_hearts_1.png'
    end 
    return image
end 

function PlayerData:getSpades(info)
    local image 
    if info == 0x42      then 
        image = 'card/card_spades_2.png'
    elseif info ==0x43  then 
        image = 'card/card_spades_3.png'
    elseif info ==0x44   then 
        image = 'card/card_spades_4.png'
    elseif info ==0x45   then 
        image = 'card/card_spades_5.png'
    elseif info ==0x46   then 
        image = 'card/card_spades_6.png'
    elseif info ==0x47   then 
        image = 'card/card_spades_7.png' 
    elseif info ==0x48   then 
        image = 'card/card_spades_8.png'
    elseif info ==0x49   then 
        image = 'card/card_spades_9.png'
    elseif info ==0x4a   then 
        image = 'card/card_spades_10.png'
    elseif info ==0x4b   then 
        image = 'card/card_spades_11.png'
    elseif info ==0x4c   then 
        image = 'card/card_spades_12.png'
    elseif info ==0x4d   then 
        image = 'card/card_spades_13.png'
    elseif info ==0x4e   then 
        image = 'card/card_spades_1.png'
    end 
    return image
end 

--筹码
function PlayerData:getChips(value)
    local image 
    value = tonumber(value)
    if value == 1 then 
       image = 'card/chip_1_bet.png' 
    elseif value == 5    then 
       image = 'card/chip_5_bet.png'
    elseif value == 25   then 
       image = 'card/chip_25_bet.png'
    elseif value == 100  then 
       image = 'card/chip_100_bet.png'  
    elseif value == 1000 then 
       image = 'card/chip_1k_bet.png'             
    elseif value == 5000 then 
       image = 'card/chip_5k_bet.png' 
    elseif value == 500  then 
       image = 'card/chip_500_bet.png' 
    elseif value == 25000 then 
       image = 'card/chip_25k_bet.png' 
    elseif value == 100000 then 
       image = 'card/chip_100k_bet.png' 
    elseif value == 500000  then 
       image = 'card/chip_500k_bet.png' 
    elseif value == 1000000 then 
       image = 'card/chip_1m_bet.png' 
    elseif value == 5000000 then 
       image = 'card/chip_5m_bet.png' 
    end                              
    
    return image       
end  

--牌型
function PlayerData:getCardType(info)
    local tag = tonumber(info)
    if  tag == 0 then  --无效牌
    elseif tag == 1 then   --高牌

    elseif tag == 2 then   --对子

    elseif tag == 3 then   --两队

    elseif tag == 4 then   --三条

    elseif tag == 5 then   --顺子

    elseif tag == 6 then   --同花

    elseif tag == 7 then   --葫芦

    elseif tag == 8 then   --金刚

    elseif tag == 8 then   --同花顺

    end
end


function PlayerData:getCardValue(info) 
    info = tonumber(info)
    local value  
    if info ==0x12 or info ==0x22 or info ==0x32 or info ==0x42 then 
       value = 2 
    elseif info ==0x13  or info ==0x23 or info ==0x33 or info ==0x43 then 
       value = 3
    elseif info ==0x14  or info ==0x24 or info ==0x34 or info ==0x44 then 
       value = 4  
    elseif info ==0x15  or info ==0x25 or info ==0x35 or info ==0x45 then 
       value = 5
    elseif info ==0x16  or info ==0x26 or info ==0x36 or info ==0x46 then 
       value = 6 
    elseif info ==0x17  or info ==0x27 or info ==0x37 or info ==0x47 then 
       value = 7   
    elseif info ==0x18  or info ==0x28 or info ==0x38 or info ==0x48 then 
       value = 8    
    elseif info ==0x19  or info ==0x29 or info ==0x39 or info ==0x49 then 
       value = 9    
    elseif info ==0x1a  or info ==0x2a or info ==0x3a or info ==0x4a then
       value = 10     
    elseif info ==0x1b  or info ==0x2b or info ==0x3b or info ==0x4b then 
       value = 11
    elseif info ==0x1c  or info ==0x2c or info ==0x3c or info ==0x4c then
       value = 12  
    elseif info ==0x1d  or info ==0x2d or info ==0x3d or info ==0x4d then
       value = 13    
    elseif info ==0x1e  or info ==0x2e or info ==0x3e or info ==0x4e then 
       value = 14   
    end
    return  value        
end 

function PlayerData:giveChips(money,bigBlind)
    local b,c = math.modf(tonumber(money)/bigBlind)
    local chips = {}
    local temp1 = {1*bigBlind,3*bigBlind,5*bigBlind,20*bigBlind,50*bigBlind,100*bigBlind}
    local temp2 = {1,3,5,20,50,100}
    local image = {'card/chip_1_bet.png','card/chip_2_bet.png','card/chip_3_bet.png','card/chip_4_bet.png','card/chip_5_bet.png','card/chip_6_bet.png',}
    if money<=bigBlind then 
       chips.parent = image[1] 
    else 
        local function compare(num)
            if  not num  then return end 
            for key,var in pairs(temp2) do 
                if num< temp2[1] then 
                    return 1
                elseif num>=temp2[6] then  
                    return 6
                elseif num >= temp2[key] and num< temp2[key+1] then 
                    return key
                end   
            end         
        end 

        if c == 0 then  --大盲注的整数倍 
            chips.parent =  image[compare(b)] 
        else
            chips.parent =  image[compare(b)] 
            local left   =  b- temp2[compare(b)]
            local point = {} 

            if b > 100 then 
                local d,e = math.modf(b/100) 
                local f   = b - d*100 + 1  
                while f >= 1 do 
                    local g = compare(f)      
                    table.insert(point,image[g])
                    f = f- temp2[g]
                end     
            else 
                local h  = b + 1
                while h >= 1 do 
                    local i = compare(h)    
                    table.insert(point,image[i])  
                    h  = h - temp2[i]
                end     
            end 
            chips.child = point
        end    
    end
    return chips 
end 

function PlayerData:getGamePort(_siteId)
    -- dump(self.gamePorts, "GAME PORTS")
    local port = self.gamePorts[tostring(_siteId)]
    if port then
        print("PORT FOUND: "..port)
        return tonumber(string.sub(port,2))
    end
    return -1
end

return PlayerData
