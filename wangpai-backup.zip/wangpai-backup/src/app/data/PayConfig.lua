local PayConfig={
	['ljf_baidu_01'] = {
		['uid'] = G_UID,
        ['token'] = G_TOKEN,
        ['fast'] = 0,
        ['pid'] = '',
        ['realAmount'] =0, 
        ['unionid'] = '',
        ['cmd'] = 'pay/wp_bdzsOrder'
	},
        --------------------------------
	['ljf_baidu_02'] = {
		['uid'] = G_UID,
        ['token'] = G_TOKEN,
        ['fast'] = 0,
        ['pid'] = '',
        ['realAmount'] =0, 
        ['unionid'] = '',
        ['cmd'] = 'pay/wp_bdzsOrder'
	},
        --------------------------------
	['ljf_baidu_03'] = {
		['uid'] = G_UID,
        ['token'] = G_TOKEN,
        ['fast'] = 0,
        ['pid'] = '',
        ['realAmount'] =0, 
        ['unionid'] = '',
        ['cmd'] = 'pay/wp_bdzsOrder'
	},
        --------------------------------
	['ljf_baidu_04'] = {
		['uid'] = G_UID,
        ['token'] = G_TOKEN,
        ['fast'] = 0,
        ['pid'] = '',
        ['realAmount'] =0, 
        ['unionid'] = '',
        ['cmd'] = 'pay/wp_bdzsOrder'
	},
        --------------------------------
	['vivo_02'] = {
		['uid'] = G_UID,
        ['token'] = G_TOKEN,
        ['fast'] = 0,
        ['pid'] = '',
        ['realAmount'] =0, 
        ['unionid'] = '',
        ['cmd'] = 'pay/wp_vivoOrder'
	},
        --------------------------------
	['sl-oppo'] = {
		['uid'] = G_UID,
        ['token'] = G_TOKEN,
        ['fast'] = 0,
        ['pid'] = '',
        ['realAmount'] =0, 
        ['unionid'] = '',
        ['cmd'] = 'pay/wp_oppoOrder'
	},
        --------------------------------
	['dch_tx_02'] = {
		['uid'] = G_UID,
        ['token'] = G_TOKEN,
        ['fast'] = 0,
        ['pid'] = '',
        ['realAmount'] =0, 
        ['unionid'] = '',
        ['cmd'] = 'pay/wp_qqOrder',
        ['cmd_pay'] = 'pay/wp_qqPay',
        ['openid'] = '',
        ['pay_token'] = '',
        ['pf'] = '',
        ['pfkey'] = '',
        ['type'] = '',
        ['openkey'] = ''
	},
        --------------------------------
	['hyl_mz_02'] = {
		['uid'] = G_UID,
        ['token'] = G_TOKEN,
        ['fast'] = 0,
        ['pid'] = '',
        ['realAmount'] =0, 
        ['unionid'] = '',
        ['cmd'] = 'pay/wp_flymeOrder'
	},
        --------------------------------
	['hyl_hw_01'] = {
		['uid'] = G_UID,
        ['token'] = G_TOKEN,
        ['fast'] = 0,
        ['pid'] = '',
        ['realAmount'] =0, 
        ['unionid'] = '',
        ['cmd'] = 'pay/wp_huaweiOrder'
	},
        --------------------------------
	['hyl_jy_01'] = {
		['uid'] = G_UID,
        ['token'] = G_TOKEN,
        ['fast'] = 0,
        ['pid'] = '',
        ['realAmount'] =0, 
        ['unionid'] = '',
        ['cmd'] = 'pay/wp_vivoOrder'
	},
        --------------------------------
	['hyl_xm_02'] = {
		['uid'] = G_UID,
        ['token'] = G_TOKEN,
        ['fast'] = 0,
        ['pid'] = '',
        ['realAmount'] =0, 
        ['unionid'] = '',
        ['cmd'] = 'pay/wp_xiaomiOrder'
	},
        --------------------------------
	['xyy_xmly_wpddz'] = {
		['uid'] = G_UID,
        ['token'] = G_TOKEN,
        ['fast'] = 0,
        ['pid'] = '',
        ['realAmount'] =0, 
        ['unionid'] = '',
        ['cmd'] = 'pay/wp_xmlyOrder'
	},
        --------------------------------
	['lzw_nbyly_01'] = {
		['uid'] = G_UID,
        ['token'] = G_TOKEN,
        ['fast'] = 0,
        ['pid'] = '',
        ['realAmount'] =0, 
        ['unionid'] = '',
        ['cmd'] = 'pay/wp_vivoOrder'
	},
        --------------------------------
	['dch_360_01'] = {
		['uid'] = G_UID,
        ['token'] = G_TOKEN,
        ['fast'] = 0,
        ['pid'] = '',
        ['realAmount'] =0, 
        ['unionid'] = '',
        ['cmd'] = 'pay/wp_qihooOrder'
	},
        --------------------------------
	['ljf_360_01'] = {
		['uid'] = G_UID,
        ['token'] = G_TOKEN,
        ['fast'] = 0,
        ['pid'] = '',
        ['realAmount'] =0, 
        ['unionid'] = '',
        ['cmd'] = 'pay/wp_qihooOrder'
	},     
        --------------------------------
        ['qh360'] = {
                ['uid'] = G_UID,
        ['token'] = G_TOKEN,
        ['fast'] = 0,
        ['pid'] = '',
        ['realAmount'] =0, 
        ['unionid'] = '',
        ['cmd'] = 'pay/wp_qihooOrder'
        },          
        --------------------------------
        ['qh360_01'] = {
                ['uid'] = G_UID,
        ['token'] = G_TOKEN,
        ['fast'] = 0,
        ['pid'] = '',
        ['realAmount'] =0, 
        ['unionid'] = '',
        ['cmd'] = 'pay/wp_qihooOrder'
        },          
        --------------------------------
        ['qcl_360_01'] = {
                ['uid'] = G_UID,
        ['token'] = G_TOKEN,
        ['fast'] = 0,
        ['pid'] = '',
        ['realAmount'] =0, 
        ['unionid'] = '',
        ['cmd'] = 'pay/wp_qihooOrder'
        },     
        --------------------------------
        ['yz_appstore'] = {
                ['uid'] = G_UID,
                ['token'] = G_TOKEN,
                ['fast'] = 0,
                ['pid'] = '',
                ['realAmount'] =0, 
                ['unionid'] = '',
                ['cmd'] = 'pay/wp_iosOrder'
        }
}
return PayConfig