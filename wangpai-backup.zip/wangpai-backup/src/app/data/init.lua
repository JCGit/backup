
local Data = class("Data", cc.load("mvc").ModelBase)

function Data:onCreate()
    self.data_ = {}
    self.app = self:getApp()

    self.data_["PlayerData"] = self.app:createData("PlayerData")
    self.data_["Config"] = self.app:createData("Config")
    return self
end

function Data:extendData(name, location, writable)
    self.data_[name] = self:extend(self.app, name, location, writable)
    return self.data_[name]
end

function Data:addData(name)
    self.data_[name] = self.app:createData(name)
end

function Data:getData(name)
    return self.data_[name]
end


return Data
