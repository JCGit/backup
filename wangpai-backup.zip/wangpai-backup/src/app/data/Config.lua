local Config = class("Config", cc.load("mvc").ModelBase)

function Config:onCreate()
    local app = self:getApp()
    self.app = app  
    
    --游戏重要信息
    self.verName = VERNAME                      --游戏版本名
    self.verCode = 161129                       --游戏版本号
    self.unionID = G_CHANNELID --'icloud'       --游戏渠道号
    self.textVersion = 'Ver:'..G_VERSION        --显示的版本号
    self.loginType = 'yzx'

    --其它配置信息
    self.getSmsDelayTime = 60
    self.timePanelLoginAction = 1               --显示登录UI移动时间
    self.timeMiniHOFPanelAction = 0.2           --大厅mini名人堂移动时间
    self.timeHOFPanelAction = 0.2               --名人堂UI移动时间
    self.timeRefreshNewPlayers = 5*60           --刷新新人堂时间
    self.broadcastTime = 5                      --广播时间
    self.profileHeadwidth = 185                 --个人信息头像大小
    self.changeNickCost = 10                    --修改昵称价格  
    self.refreshPlayerCountsDelay = 5           --每30秒更新一次玩家人数
    self.blurRadius = 2--8

    self.DefaultBroadColor = {255,255,255}      --发送小喇叭默认颜色
 
    self.ColorEyeOpen = cc.c3b(127,127,127)     --输入密码隐藏密码图片颜色
    self.ColorEyeClose = cc.c3b(26,26,26)       
    
    self.ColorTextUnselect = cc.c3b(172,147,128)     --文本未选中颜色
    self.ColorTextSelect = cc.c3b(255,255,255)       --文本选中颜色
    --self.Txf_textColor = cc.c4b(76,44,31,255) 
    self.Txf_textColor = cc.c4b(255,255,255,255)   
    self.Txf_textColorLogin = cc.c4b(32,32,32,255)    
    
    self.ColorTextButtonSelect = cc.c3b(221, 148, 255) --设置按钮文本未选中颜色
    self.ColorTextButtonUnselect = cc.c3b(255,255,255) --设置按钮文本选中颜色

    self.maskSprite = 'common/circle.png'

    --向服务器请求的游戏场次5：万人斗牛 6：跑得快 7：54张斗地主 8：王牌比赛场　9：婚礼场
    self.keyDataGames = {
        ddz = {dataName   = 'GameType_DDZ', viewName = "UIGameTable" ,requestServerKey = '1'},
        qdz = {dataName   = 'GameType_QDZ', viewName = "UIGameTable", requestServerKey = '2'},
        dn  = {dataName   = 'GameType_DN',  viewName = "UIGameTableDouniu", requestServerKey = '3'},
        zjh = {dataName   = 'GameType_ZJH', viewName = "UIGameTableSanzhang", requestServerKey = '4'},
        wrdn = {dataName  = 'GameType_WRDN', viewName = "UIGameTableWanren", requestServerKey = '5'},
        pdk = {dataName   = 'GameType_PDK', viewName = "UIGameTablePaodekuai", requestServerKey = '6'},
        ddzNor= {dataName = 'GameType_DDZNOR', viewName = "UIGameTableClassic", requestServerKey = '7'},
        match = {dataName = 'GameType_MATCH', viewName = "UIGameTableMatch", requestServerKey = '8'},
    }
    
    --注册，设置保险箱密保问题
    self.listQuestions = {
        '您身份证的后六位？',
        '您最喜欢的歌曲名字？',
        '您的出生地是？',
        '您最爱吃的零食是？',
        '您最喜欢的颜色是？',
        '您最好的朋友是？'
    }
    

    self.gameSeatIdInfo = { ["1"] = "炸翻天", --{ name = "斗地主初级场", viewName = 'UIGameTable', }
                            ["2"] = "炸翻天",
                            ["3"] = "炸翻天",
                            ["4"] = "炸翻天",
                            ["5"] = "炸翻天",
                            ["7"] = "炸翻天",
                            ["9"] = "斗牛场",
                            ["17"] = "抢地主",
                            ["18"] = "抢地主",
                            ["33"] = "大奖赛场",
                            ["48"] = "五人斗牛",      
                            ["49"] = "五人斗牛",
                            ["50"] = "五人斗牛",
                            ["51"] = "五人斗牛",
                            ["60"] = "欢乐赢三张",
                            ["61"] = "欢乐赢三张",
                            ["62"] = "欢乐赢三张",
                            ["63"] = "欢乐赢三张",
                            ["64"] = "欢乐赢三张",
                            ["65"] = "欢乐赢三张",
                            ['66'] = '欢乐赢三张',
                            ["14"] = "婚礼场",
                            --德州
                            ['71'] = '德州九人',
                            ['72'] = '德州九人',
                            ['73'] = '德州九人',
                            ['74'] = '德州九人',
                            ['75'] = '德州九人',
                            ['76'] = '德州九人',
                            ['77'] = '德州九人',
                            ['78'] = '德州九人',
                            ['79'] = '德州九人',
                            ['80'] = '德州九人',
                            ['81'] = '德州九人',
                            ['82'] = '德州九人',
                            ['83'] = '德州九人',
                            ['84'] = '德州九人',
                            ['85'] = '德州九人',
                            ['86'] = '德州九人',
                            ['87'] = '德州九人',
                            ['88'] = '德州九人',
                            ['89'] = '德州六人',
                            ['90'] = '德州六人',
                            ['91'] = '德州六人',
                            ['92'] = '德州六人',
                            ['93'] = '德州六人',
                            ['94'] = '德州六人',
                            ['95'] = '德州六人',
                            ['96'] = '德州六人',
                            ['97'] = '德州六人',
                            ['98'] = '德州六人',
                            ['99'] = '德州六人',
                            ['100'] = '德州六人',
                            ['101'] = '德州六人',
                            ['102'] = '德州六人',
                            ['103'] = '德州六人',
                            ['104'] = '德州六人',
                            ['105'] = '德州六人',
                            ['106'] = '德州六人',
                            ['107'] = '跑得快',
                            ['108'] = '跑得快',
                            ['109'] = '跑得快',
                            ['110'] = '跑得快',  
                            ['122'] = '王牌斗地主',        
                             ['123'] = '比赛场',} 

    --比赛场
    self.costType = {
        {1, "match/match_chip.png"},    --免费
        {2, "match/match_chip.png"},    --金币
        {3, "game/diamond.png"},        --元宝
        {4, "game/huafjuan.png"},       --积分
        {5, "match/match_chip.png"},    --参赛券
    }
    self.dayNames = {'今天','周一','周二','周三','周四','周五','周六','周日'}
    
    --默认性别文理
    self.defaultSexTexture = {'res_profile/img_sex_male.png' ,'res_profile/img_sex_female.png'}
    --默认头像文理
    self.defaultHeadTexture = {'common/default_avater_man.png','common/default_avater_woman.png'}
    
    self.bt_updown = {'res_shop/btn_down.png', 'res_shop/btn_up.png'}

    self.vipBorder = {
        bronze = "common/icon_vip_bg_0.png",
        silver = "common/icon_vip_bg_1.png",
        gold = "common/icon_vip_bg_2.png",
    }

    --VIP 特权
    self.vipRights = {
        --level, expGain, chipsGain, chipsRaise, limitBank, limitFriends
        {1, 7, 2000, 20000, 2000000, 12},
        {2, 31, 6000, 40000, 4000000, 13},
        {3, 81, 10000, 60000, 6000000, 15},
        {4, 201, 14000, 80000, 8000000, 16},
        {5, 601, 18000, 100000, 20000000, 18},
        {6, 1501, 25000, 120000, 100000000, 20},
        {7, 2501, 30000, 140000, 200000000, 22},
        {8, 3501, 35000, 160000, 300000000, 24},
        {9, 5001, 50000, 180000, 400000000, 26},
        {10, 6501, 65000, 200000, 500000000, 28},
        {11, 10000, 75000, 220000, 500000000, 30},
        {12, 16000, 80000, 240000, 600000000, 32},
        {13, 25000, 88000, 260000, 0, 35},
        {14, 36000, 96000, 280000, 0, 40},
        {15, 50000, 105000, 300000, 0, 50},
        {16, 65536, 112000, 320000, 0, 50},
        {17, 131072, 120000, 340000, 0, 50},
        {18, 262144, 125000, 360000, 0, 50},
        {19, 524288, 136000, 380000, 0, 50},
        {20, 1048576, 150000, 400000, 0, 50},
    }
    
    --卖礼物价格
    self.listSellGifts = {60000, 300000, 500000,800000,5000000}
    
    --等级经验值
    self.levelExp = {
        0,1,5,10,20,55,135,280,515,
        870,1385,2100,3060,4320,5935,7960,10465,13520,17200,
        21580,26755,32805,39825,47920,
        57190,67740,79690,93155,108260,125130,143900
    }

    local ONE = 10000
    --财富经验值
    self.fortuneExp = {
        0, 2 * ONE, 4 * ONE, 6 * ONE, 10 * ONE,
        30 * ONE, 100 * ONE, 200 * ONE, 350 * ONE, 600 * ONE, 1000 * ONE, 2000 * ONE, 3500 * ONE,
        6000 * ONE, 1 * ONE * ONE, 2 * ONE * ONE, 5 * ONE * ONE, 10 * ONE * ONE, 18 * ONE * ONE,
        20 * ONE * ONE
    }

    self.fortuneName = {
        "包身工", "短工", "长工", "佃户", "贫农", "渔夫", "猎人", "中农", "富农",
        "掌柜", "商人", "衙役", "小财主", "大财主", "知县", "知府", "巡抚", "总督", "丞相", "帝王"
    }
end

return Config  