DataStructures = {}
DataStructures.Stacqueue = class('Stacqueue') 
 
function DataStructures.Stacqueue:ctor(_name,_forceType,_supportDuplicatedElement) 
	self._dataPool = {}
	self.name = _name
	self.itemType = _forceType
	self.supportDuplicatedElement = _supportDuplicatedElement or false
	self.size = 0
end

function DataStructures.Stacqueue:isExists(T) 
    for k,v in pairs(self._dataPool) do 
    	if v == T then  
    		return true
    	end
    end
    return false
end

function DataStructures.Stacqueue:enqueue(T) 
	if self.itemType and type(T) ~= self.itemType then
		printError("Only type of ".. self.itemType .." can be put in this queue instance.")
		return self
	end
	if self.supportDuplicatedElement == false then
		if not self:isExists(T) then
			self.size = self.size + 1
			table.insert(self._dataPool,T) 
		else
			printError("Putting same data instance is not supported for now.") -- i'll make it support now.
		end
	else 
		self.size = self.size + 1
		table.insert(self._dataPool,T) 
	end

	return self
end
 
function DataStructures.Stacqueue:iterator( _callback )
    for k,v in pairs(self._dataPool) do
        _callback(k,v)
    end
end

function DataStructures.Stacqueue:push( ... )
	return self:enqueue(...)
end

function DataStructures.Stacqueue:pop() 
	if self.size <= 0 then return false end
	local ret = self._dataPool[#self._dataPool]
	self._dataPool[#self._dataPool] = nil 
	self.size = self.size - 1
	return ret
end

function DataStructures.Stacqueue:dequeue() 
	if self.size <= 0 then return false end
	local ret = self._dataPool[1]
	self._dataPool[1] = nil
	self.size = self.size - 1
	self:reArrangeViewPool()
	return ret
end

function DataStructures.Stacqueue:reArrangeViewPool()
    local ret = {}
    for k,v in pairs(self._dataPool) do
        ret[#ret+1]=v
    end
    self._dataPool = ret
    return self
end

function DataStructures.Stacqueue:removeAt(_idx,_NoRearrange)
	local ret = self._dataPool[_idx]
	self._dataPool[_idx] = nil
	if _NoRearrange == nil or _NoRearrange == false then
		self:reArrangeViewPool() 
		self.size = self.size - 1
	end
	return ret  
end


 

function DataStructures.Stacqueue:getItemIndexies(T )
	local ret = {}
	for k,v in pairs(self._dataPool) do
		if v == T then
			table.insert(ret,k) 
		end
	end
	return ret

end


 

function DataStructures.Stacqueue:getItemAt(_idx )
	if _idx > self.size then
		printError("getItemAt Error: Index(%s) is larger than Size(%s)",_idx,self.size)
	end
	return self._dataPool[_idx]
end

function DataStructures.Stacqueue:setItemAt(_idx ,T) 
	 self._dataPool[_idx] = T
	 return self
end

function DataStructures.Stacqueue:insertAt(_idx,T) 
	if self._dataPool[_idx] == nil then self._dataPool[_idx] = T else
		local ret = {}
    	for k,v in pairs(self._dataPool) do
    		if k == _idx then
    		 table.insert(ret,T)
    		end
    		 table.insert(ret,v)
    	end
    	self._dataPool = ret
	end

	self.size = self.size + 1
	return self
end

function DataStructures.Stacqueue:clear()
	local ret = self._dataPool
	self._dataPool = {}

	self.size = 0
	return ret
end

function DataStructures.Stacqueue:dump() 
	printf("Dumping Stacqueue:%s",self._dataPool)
	dump(self._dataPool,self.name)
	return self
end

function DataStructures.Stacqueue:setName(_name) 
	self.name = _name
	return self
end
function DataStructures.Stacqueue:getName() 
	return self.name 
end

function DataStructures.Stacqueue:getSize()   
	return self.size
end
