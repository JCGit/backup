local CommonConfig={
	['sl-oppo'] = {
		--是否使用第三方登录
		isSdkLogin = true,
		--是否使用我们的自动登录
		isOurOnlyAutoLogin = false,
		--是否使用第三方支付
		isSdkPay = true,
		--是否使用第三方退出游戏
		isSdkExitGame = true,
		--是否使用第三方广告
		isSdkShowAdv = false,
		--游戏中是否添加登录按钮
		isAddBtnLogin = false
	},
	['ljf_baidu_01'] = {
		isSdkLogin = false,
		isOurOnlyAutoLogin = true,
		isSdkPay = true,
		isSdkExitGame = true,
		isSdkShowAdv = true,
		isAddBtnLogin = false
	},
	['ljf_baidu_02'] = {
		isSdkLogin = false,
		isOurOnlyAutoLogin = true,
		isSdkPay = true,
		isSdkExitGame = true,
		isSdkShowAdv = true,
		isAddBtnLogin = false
	},
	['ljf_baidu_03'] = {
		isSdkLogin = false,
		isOurOnlyAutoLogin = true,
		isSdkPay = true,
		isSdkExitGame = true,
		isSdkShowAdv = true,
		isAddBtnLogin = false
	},
	['ljf_baidu_04'] = {
		isSdkLogin = false,
		isOurOnlyAutoLogin = true,
		isSdkPay = true,
		isSdkExitGame = true,
		isSdkShowAdv = true,
		isAddBtnLogin = false
	},
	['vivo_02'] = {
		isSdkLogin = false,
		isOurOnlyAutoLogin = true,
		isSdkPay = true,
		isSdkExitGame = false,
		isSdkShowAdv = false,
		isAddBtnLogin = false
	},
	['dch_tx_02'] = {
		isSdkLogin = true,
		isOurOnlyAutoLogin = false,
		isSdkPay = true,
		isSdkExitGame = false,
		isSdkShowAdv = false,
		isAddBtnLogin = true
	},
	['hyl_mz_02'] = {
		isSdkLogin = false,
		isOurOnlyAutoLogin = true,
		isSdkPay = true,
		isSdkExitGame = false,
		isSdkShowAdv = false,
		isAddBtnLogin = false
	},
	['hyl_hw_01'] = {
		isSdkLogin = true,
		isOurOnlyAutoLogin = false,
		isSdkPay = true,
		isSdkExitGame = false,
		isSdkShowAdv = false,
		isAddBtnLogin = false
	}
	,
	['hyl_jy_01'] = {
		isSdkLogin = false,
		isOurOnlyAutoLogin = true,
		isSdkPay = true,
		isSdkExitGame = true,
		isSdkShowAdv = false,
		isAddBtnLogin = false
	},
	['hyl_xm_02'] = {
		isSdkLogin = true,
		isOurOnlyAutoLogin = false,
		isSdkPay = true,
		isSdkExitGame = true,
		isSdkShowAdv = true,
		isAddBtnLogin = false
	},
	['xyy_xmly_wpddz'] = {
		isSdkLogin = true,
		isOurOnlyAutoLogin = false,
		isSdkPay = true,
		isSdkExitGame = false,
		isSdkShowAdv = false,
		isAddBtnLogin = false
	},
	['lzw_nbyly_01'] = {
		isSdkLogin = true,
		isOurOnlyAutoLogin = false,
		isSdkPay = true,
		isSdkExitGame = false,
		isSdkShowAdv = false,
		isAddBtnLogin = false
	},
	['dch_360_01'] = {
		isSdkLogin = true,
		isOurOnlyAutoLogin = false,
		isSdkPay = true,
		isSdkExitGame = true,
		isSdkShowAdv = false,
		isAddBtnLogin = false
	},
	['ljf_360_01'] = {
		isSdkLogin = true,
		isOurOnlyAutoLogin = false,
		isSdkPay = true,
		isSdkExitGame = true,
		isSdkShowAdv = false,
		isAddBtnLogin = false
	},
	['qcl_360_01'] = {
		isSdkLogin = true,
		isOurOnlyAutoLogin = false,
		isSdkPay = true,
		isSdkExitGame = true,
		isSdkShowAdv = false,
		isAddBtnLogin = false
	},
	['qh360'] = {
		isSdkLogin = true,
		isOurOnlyAutoLogin = false,
		isSdkPay = true,
		isSdkExitGame = true,
		isSdkShowAdv = false,
		isAddBtnLogin = false
	},
	['qh360_01'] = {
		isSdkLogin = true,
		isOurOnlyAutoLogin = false,
		isSdkPay = true,
		isSdkExitGame = true,
		isSdkShowAdv = false,
		isAddBtnLogin = false
	},

	['yz_appstore'] = {
		isSdkLogin = false,
		isOurOnlyAutoLogin = true,
		isSdkPay = true,
		isSdkExitGame = false,
		isSdkShowAdv = false,
		isAddBtnLogin = false
	}
}
return CommonConfig