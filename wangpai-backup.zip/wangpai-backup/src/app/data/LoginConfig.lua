local PayConfig={
	['sl-oppo'] = {
		['password'] = '',--token
        ['uuid'] = '',--ssoid
        ['type'] = 'oppo',
	},
	['dch_tx_02'] = {
		['password'] = '',--token
        ['uuid'] = '',--ssoid
        ['type'] = 'xmly',
	},
	['hyl_hw_01'] = {
		['password'] = '',--token
        ['uuid'] = '',--ssoid
        ['type'] = 'huawei',
	},
	['hyl_xm_02'] = {
		['password'] = '',--token
        ['uuid'] = '',--ssoid
        ['type'] = 'mi',
	},
	['xyy_xmly_wpddz'] = {
		['password'] = '',--token
        ['uuid'] = '',--ssoid
        ['type'] = 'xmly',
	},
	['lzw_nbyly_01'] = {
		['password'] = '',--token
        ['uuid'] = '',--ssoid
        ['type'] = 'xmly',
	},
	['dch_360_01'] = {
		['password'] = '',--token
        ['uuid'] = '',--ssoid
        ['type'] = '360',
	},
	['ljf_360_01'] = {
		['password'] = '',--token
        ['uuid'] = '',--ssoid
        ['type'] = '360',
	},

	['qcl_360_01'] = {
		['password'] = '',--token
        ['uuid'] = '',--ssoid
        ['type'] = '360',
	},
	['qh360'] = {
		['password'] = '',--token
        ['uuid'] = '',--ssoid
        ['type'] = '360',
	},
	['qh360_01'] = {
		['password'] = '',--token
        ['uuid'] = '',--ssoid
        ['type'] = '360',
	},
}
return PayConfig