local UIHelpDouniu= class("UIHelpDouniu", cc.load("mvc").ViewBase)
UIHelpDouniu.RESOURCE_FILENAME = "UIHelpDouniu.csb"
local HttpHandler = require("app.network.HttpHandler")

UIHelpDouniu.RESOURCE_BINDING = { 
      ["Panel_main"] = {["ended"] = "hideAll"}, 

}

function UIHelpDouniu:onCreate()
    local app = self:getApp()
    self.app = app
    self.config = app:getData('Config')
    self.tool = app:getModel('Tools')
    self.pData = app:getData('PlayerData') 
    
    self.sizes = self['Panel_root']:getContentSize()
    local move = cc.MoveBy:create(0.3,cc.p(self.sizes.width,0))
    self['Panel_root']:runAction(move)

end

function UIHelpDouniu:hideAll()
    self.app:removeView('UIHelpDouniu')
end     

return UIHelpDouniu








