local UILoginBindAccount = class("UILoginBindAccount", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
--printWarning

UILoginBindAccount.RESOURCE_FILENAME = "UILoginBindAccount.csb"
--UILoginBindAccount.RESOURCE_PRELOADING = {"main.png"}
--UILoginBindAccount.RESOURCE_LOADING  = {["res/background/login_bg.png"] = {names = {"Image_bg"}} }

UILoginBindAccount.RESOURCE_BINDING = {
    ["Button_cancel"]  = {["ended"] = "remView"},
    ["Button_confirm"] = {["ended"] = "confirm"},
    ["Button_GetSms"]  = {["ended"] = "onGetSms"},
}

function  UILoginBindAccount:remView()
    
    self:stopSchedule('updateCount')
    self.app:removeView('UILoginBindAccount')
end


function UILoginBindAccount:confirm() 
    
    local account =  self['TextField_account']:getString()
    local newPwd    =  self['TextField_psw']:getString()
    local confPwd    =  self['TextField_conPsw']:getString()
    local phone = self['TextField_phone']:getString()
    local smsCode = self['TextField_smsCode']:getString()
    
    --检测账号长度是否合格
    if #account< self.account.accMinLen or #account > self.account.accMaxLen then
        self.tool:showTips(self.account.accLenght)
        return
    end
    --检测账号内容是否合格
    if false == self.account:strContainOnlyNumAndChar(account) then
        self.tool:showTips(self.account.accError)
        return
    end
    --检测密码长度是否合格
    if #newPwd< self.account.pwdMinLen or #newPwd > self.account.pwdMaxLen then
        self.tool:showTips(self.account.pwdLenght)
        return
    end
    --检测密码内容是否合格
    if false == self.account:strContainOnlyNumAndChar(newPwd) then
        self.tool:showTips(self.account.pwdError)
        return
    end
    --检测两次输入的密码是否一致
    if newPwd ~= confPwd then
        self.tool:showTips(self.account.pwdNotMatched)
        return
    end
    --检测填的电话号码是否正确
    if  #phone == 0 then    self.tool:showTips(self.account.phoneError1)   
        return
    elseif #phone > 0 and (false == self.account:strContainOnlyNum(phone) or #phone ~= 11) then
         self.tool:showTips(self.account.phoneError)
        return
    end
    --检测输入的验证码是否正确
    if #phone > 0 and (false == self.account:strContainOnlyNum(smsCode) or #smsCode == 0) then
        self.tool:showTips(self.account.smsCodeError)
        return
    end
    
    local dataTable =     {
        ['account']  = account,
        ['pwd'] = newPwd,
        ['uid']      = self.pData.uid,
        ['token']      = self.pData.token,
        ['phone']      = phone,
        ['msgCode']      = smsCode,
        ['cmd']      = HttpHandler.CMDTABLE.BINDING,
    }

    local function succ(arg)
        UserCache.setCommonDataByKey("account", account)
        UserCache.setCommonDataByKey("password", newPwd)
        UserCache.setCommonDataByKey("isBindAccount", 1)
        self.tool:showAlert(arg.msg)
        self.pData.modify_pw = 1
        
        if #phone > 0 then
            self.pData.isBindPhone = 1
        end

        if arg.coin then 
            self.pData.coin = arg.coin 
            self.app:callMethod('UIMainTop','updateWealth') 
        end     

        local function cb() 
            self.app:callMethod('UISetting','updateUserView')
            self.app:callMethod('UISettingSetting','saveConfigs')
            self:stopSchedule('updateCount')
            self:removeSelf()
        end

        local tips = self.app:addView("UITips", 65534,1)
        tips:setupDialog("提示",arg.msg, cb, cb)
       -- self:runAction(cc.Sequence:create(cc.DelayTime:create(1.5), cc.CallFunc:create(cb),nil))
    end
    
    local function fail(arg)
        if arg.msg then
        	self.tool:showTips(arg.msg)
        end
    end
    self.tool:fastRequest(dataTable,succ, fail)
end

function UILoginBindAccount:initTextField(_txf)
    _txf:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    _txf:setTextColor(self.config.Txf_textColorLogin)
end

function UILoginBindAccount:onCreate()
    local app = self:getApp()
    self.app = app
    self.tool = app:getModel('Tools') 
    self.account = app:getModel('Account')
    self.config = app:getData('Config')
    self.pData = app:getData('PlayerData')

    self:initTextField(self['TextField_account'])
    self:initTextField(self['TextField_psw'])
    self:initTextField(self['TextField_conPsw'])
    self:initTextField(self['TextField_phone'])
    self:initTextField(self['TextField_smsCode'])

    self.account:handleTxfControl(self['TextField_account'],{"@"})
    self.account:handleTxfControl(self['TextField_psw'])
    self.account:handleTxfControl(self['TextField_conPsw'])
    self.account:handleTxfControl(self['TextField_phone'],nil, 'num')
    self.account:handleTxfControl(self['TextField_smsCode'], nil, 'num')
    
    self:setTextfieldPwdControl(self['Image_eye1'], self['TextField_psw'])
    self:setTextfieldPwdControl(self['Image_eye2'], self['TextField_conPsw'])

   --init Get Sms code Enable time
    if self.pData.smsCodeTimeEnable > 0 then
        self.timeLast = self.config.getSmsDelayTime - (os.time() - self.pData.smsCodeTimeEnable)
        if self.timeLast > 0 then
            self['Button_GetSms']:setEnabled(false)
            self['Button_GetSms']:setTitleText('('..self.timeLast..')获取')
            self:createSchedule('updateCount', function()  
                self.timeLast = self.timeLast - 1
                self['Button_GetSms']:setTitleText('('..self.timeLast..')获取')
                if self.timeLast == 0 then
                    self:stopSchedule('updateCount')
                    self['Button_GetSms']:setEnabled(true)
                    self['Button_GetSms']:setTitleText('获取')
                end
            end,1)
        else
            self['Button_GetSms']:setEnabled(true)
            self['Button_GetSms']:setTitleText('获取')
        end
    end
   
end

function UILoginBindAccount:onGetSms()
    
    self:requestGetSmsCode()
end

function UILoginBindAccount:requestGetSmsCode()
    local phone = self['TextField_phone']:getString()

    if #phone == 0 then 
         self.tool:showTips(self.account.phoneError1)
         return
    elseif (false == self.account:strContainOnlyNum(phone)) or #phone ~= 11 then
         self.tool:showTips(self.account.phoneError)
         return
    end

    local dataTable =     {
        ['type']   = 1,
        ['account']   = "",
        ['uid']   = '',
        ['phone']   = phone,
        ['cmd']       = HttpHandler.CMDTABLE.GET_SMS,
    }
    local function succ(arg)
        self.tool:showTips(arg.msg)
        self.pData.smsCodeTimeEnable = os.time()
        self.timeLast = self.config.getSmsDelayTime
        self['Button_GetSms']:setEnabled(false)
        self:createSchedule('updateCount', function()  
        self.timeLast = self.timeLast - 1
        self['Button_GetSms']:setTitleText('('..self.timeLast..')获取')
        if self.timeLast == 0 then
            self:stopSchedule('updateCount')
            self['Button_GetSms']:setEnabled(true)
            self['Button_GetSms']:setTitleText('获取')
        end
        end,1)
    end

    local function fail(arg)
        self.tool:showTips(arg.msg)
    end
    self.tool:fastRequest(dataTable,succ, fail)
end


function UILoginBindAccount:setTextfieldPwdControl(widget, textf)
    local isShowPwd = false
    local function onEyeSwitchState(event)
        if event.name == 'ended' then
            if isShowPwd then
                event.target:setColor(self.config.ColorEyeOpen)
            else
                event.target:setColor(self.config.ColorEyeClose)
            end
            textf:setPasswordEnabled(isShowPwd)
            textf:setString(textf:getString())
            isShowPwd = not isShowPwd
        end
    end
    widget:setColor(self.config.ColorEyeOpen)
    widget:onTouch(onEyeSwitchState)
    widget:setTouchEnabled(true)
end
return UILoginBindAccount
