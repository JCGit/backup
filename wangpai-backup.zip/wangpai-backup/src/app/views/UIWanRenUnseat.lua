local UIWanRenUnseat = class("UIWanRenUnseat", cc.load("mvc").ViewBase)

UIWanRenUnseat.RESOURCE_FILENAME = "UIWanRenUnseat.csb"

UIWanRenUnseat.RESOURCE_BINDING = { 
    ["Panel_30"]   = {["ended"] = "PlayerCtrl_Touch"}, 
    } 

local SHOW_DIS_TIME = 0.3

function UIWanRenUnseat:PlayerCtrl_Touch()
    local function cb()
        self.app:removeView("UIWanRenUnseat")
    end
    local closeAction = cc.MoveTo:create(SHOW_DIS_TIME,cc.p(1650,self["Panel_root"]:getPositionY()))
    local seq = cc.Sequence:create(closeAction,cc.CallFunc:create(cb),nil)
    self["Panel_root"]:runAction(seq)
end



function UIWanRenUnseat:setItemByData(item,oneData)
    local headImage = item:getChildByName("Image_19")
    local nameText = item:getChildByName("Text_12")
    local moneyText = item:getChildByName("Text_12_0")
    nameText:setString(oneData.nick)--(LuaTools.getFinalNameStr(oneData.nick,6))   
    moneyText:setString(LuaTools.convertAmountChinese(oneData.coin,10000))

    local newHeadSpr
    if oneData.icon and oneData.icon ~= ""  then  --庄家头像
       local function onFinishTable(status,downloadedSize,dst)
          if status == "success" then
             newHeadSpr = cc.Sprite:create(dst)
          else 
             newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[oneData.sex+1])   
          end
          LuaTools.makeSpriteRounded(newHeadSpr,headImage , self.config.maskSprite, false)
       end
       local newName = oneData.icon
       LuaTools.getFileFromUrl({url = oneData.icon, destFile =(newName:gsub("/","_")), onFinishTable = onFinishTable })
    else 
       newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[oneData.sex+1])
       LuaTools.makeSpriteRounded(newHeadSpr, headImage, self.config.maskSprite, false)   
    end 
end

function UIWanRenUnseat:onCreate(data)
    local app = self:getApp()
    self.app = app
    self.config  = app:getData('Config')

    local playerData = G_BASEAPP:getData('PlayerData') 
    -- dump(data,'无座玩家列表')

    self["Text_1"]:setString(#data.."人")

    local listView = self["ListView_1"]
    listView:setItemModel(self["Panel_4"])
    if #data == 0 then
        listView:removeAllItems()
    else
        for i=1,#data do
            local oneData = data[i]
            local item = nil
            if i > 1 then
                listView:pushBackDefaultItem()
            end
            local item = listView:getItem(i-1)
            self:setItemByData(item, oneData)
        end
    end

    local moveRight = cc.MoveTo:create(SHOW_DIS_TIME, cc.p(1280,self["Panel_root"]:getPositionY()))
    self["Panel_root"]:runAction(moveRight)
end

return UIWanRenUnseat
