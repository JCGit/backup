local UIHelpFeedback= class("UIHelpFeedback", cc.load("mvc").ViewBase)
UIHelpFeedback.RESOURCE_FILENAME = "UIHelpFeedback.csb"
local HttpHandler = require("app.network.HttpHandler")

UIHelpFeedback.RESOURCE_BINDING = { 
}

--初始化用户反馈
function UIHelpFeedback:onCreate()
    local app = self:getApp()
    self.app = app
    self.config = app:getData('Config')
    self.tool = app:getModel('Tools')
    self.pData = app:getData('PlayerData')
    self.account = app:getModel('Account')
	self:setSkipGoBack(true ) 
    self.pContentSel = self['Panel_5']
    self:initFeedbackView()
	
end

function UIHelpFeedback:getPanelMain()
    return self['Panel_main']
end

function UIHelpFeedback:transitionViewAction(_action)
   self:runAction(_action:clone())
end

function UIHelpFeedback:initFeedbackView()
    self.imagePath = ""
    local txf_contact, txf_msg
    local function onUploadImg(event)
        if event.name == 'ended' then
            LuaTools.getAvatar(function(tbl)
                if tbl.succ then
                    print("IMAGE PATH: "..tbl.path)
                    self.imagePath = tbl.path
                    cc.Director:getInstance():getTextureCache():reloadTexture(tbl.path)
                    self.pContentSel:getChildByName('Image_ScreenShot'):loadTexture(tbl.path,ccui.TextureResType.localType)
                    self.pContentSel:getChildByName('Image_ScreenShot'):setVisible(true)
                    self.pContentSel:getChildByName('Image_temp'):setVisible(false)
                    self.pContentSel:getChildByName('Text_descImg'):setVisible(false)
                end
            end,160,160)
        end
    end
    local imgTouch = self.pContentSel:getChildByName('Image_bgdScreenShot')
    imgTouch:setTouchEnabled(true)
    imgTouch:onTouch(onUploadImg)

     local function onSendFeedBack(event)        --发送反馈
        if event.name == 'began' then
        elseif event.name == 'ended' then
            local msg = txf_msg:getString()
            local contact = txf_contact:getString()
            if #msg == 0 then
                self.tool:showTips('反馈内容不能为空')
                return
            end
            self.pContentSel:getChildByName('TextField_desc'):setString('')
            self:requestSendFeedBack(msg, contact)
        end
    end
    local function onEnterGroup(event)          --加入群
        if event.name == 'began' then
        elseif event.name == 'ended' then
            LuaTools.openWebURL("http://jq.qq.com/?_wv=1027&k=U4enEZ")
        end
    end
    local function onCallService(event)         --拨号联系客服
        if event.name == 'began' then
        elseif event.name == 'ended' then
            LuaTools.dialPhone("tel://4008362606")
        end
    end
    local function onChatService(event)         --客服聊天
        if event.name == 'began' then
        elseif event.name == 'ended' then
            --调用聊天接口
        end
    end
    local function onCheckMyAnswers(event)      --我的答案
        if event.name == 'began' then
        elseif event.name == 'ended' then
            local encodedUID = LuaTools.StringToBase64(self.pData.uid)
            LuaTools.openWebURL("http://ddz.217play.com:17179/get_feedback/index/"..encodedUID.."/feed_url")
        end
    end
    local function onThanksFriend(event)        --答谢好友
        if event.name == 'began' then
        elseif event.name == 'ended' then
            self.app:addView('UIFriendThanks',8805)
        end
    end
    self.pContentSel:getChildByName('Button_upload'):onTouch(onSendFeedBack)
    self.pContentSel:getChildByName('Button_chatService'):onTouch(onChatService)
    self.pContentSel:getChildByName('Button_myAnswers'):onTouch(onCheckMyAnswers):setVisible(false)
    self.pContentSel:getChildByName('Button_thanksFriend'):onTouch(onThanksFriend):setVisible(false)
    self.pContentSel:getChildByName('Button_openQQ'):onTouch(onEnterGroup)
    self.pContentSel:getChildByName('Button_callService'):onTouch(onCallService)

    self.pContentSel:getChildByName('Image_ScreenShot'):setVisible(false)
    self.pContentSel:getChildByName('Image_temp'):setVisible(false)
    self.pContentSel:getChildByName('Text_descImg'):setVisible(false)

    txf_msg = self.pContentSel:getChildByName('TextField_desc')
    txf_contact = self.pContentSel:getChildByName('TextField_contact')
    txf_contact:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    self.account:handleTxfControl(txf_contact,{"@"})
	if G_CHANNELID == "sl-oppo" then
		self.pContentSel:getChildByName('Text_contact2'):setVisible(false)
		self.pContentSel:getChildByName('Button_openQQ'):setVisible(false)
	end
end


function UIHelpFeedback:requestSendFeedBack(msg, contact)
    --LuaTools.showAlert('反馈成功')
    -- local function onSucc(arg)
    --     -- self.tool:showTips('反馈成功')
    --     LuaTools.showAlert('反馈成功')
    -- end  
    -- local function fail(arg)
    --     dump(arg,'提交反馈失败了')
    -- end 
    -- local imgData
    -- if #self.imagePath > 0 then
    --     --printWarning
    --     imgData = LuaTools.FileToBase64(self.imagePath)
    -- end
    -- local info = ''--self.pData.localVerson..'-'..self.pData.serverVerson

    -- local dataTable =     {
    --     ['uid']   = self.pData.uid,
    --     ['token']  = self.pData.token,
    --     ['contact']      = contact,
    --     ['image']       = imgData,
    --     ['content']    = msg,
    --     ['cmd']       = HttpHandler.CMDTABLE.FEEDBACK,
    --     ['debugInfo'] = LuaTools.StringToBase64(info),
    -- }
    -- self.tool:fastRequest(dataTable, onSucc,fail)
end

return UIHelpFeedback








