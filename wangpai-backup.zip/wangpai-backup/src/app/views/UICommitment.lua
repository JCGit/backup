local UICommitment = class("UICommitment", cc.load("mvc").ViewBase)

UICommitment.RESOURCE_FILENAME = "UICommitment.csb"
--UIAlert.RESOURCE_PRELOADING = {"main.png"}
--UIAlert.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UICommitment.RESOURCE_BINDING = { 
    ["Button_close"] = {["ended"] = "close"}, 
    ["Button_go"] = {["ended"] = "confirm"}, 
    } 

function UICommitment:close()
    self.app:removeView('UICommitment')
end     
 

function UICommitment:onCreate()
    local app = self:getApp()
    self.app = app
    self.pData = self.app:getData('PlayerData')
    self.tool = app:getModel('Tools')
    self.config = app:getData('Config')

	 self['TextField_name']:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
	 self['TextField_number']:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
	 self['TextField_phone']:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
end


function UICommitment:confirm() 
    local name  = self['TextField_name']:getString() 
    local id    = self['TextField_number']:getString() 
    local phone = self['TextField_phone']:getString()  

    if name=='' then 
    	LuaTools.showAlert('姓名不能为空')
        return 
    elseif  id == '' or #id ~= 18 then 
    	LuaTools.showAlert('您输入的身份证格式有误，请重新输入')
        return     	
    elseif  phone== '' then 
    	LuaTools.showAlert('手机号不能为空')
        return   
    end 
        
    local dataTable =     {
        ['uid']    = self.pData.uid,
        ['token']  = self.pData.token,
        ['acceptor']   = name,
        ['idNumber']   = id,
        ['contact']    = phone,
        ['cmd']    = HttpHandler.CMDTABLE.selfPromise,
     }
    local function succ(arg)    
    	LuaTools.showAlert('信息提交成功')
        G_BASEAPP:removeView('UICommitment')
    end
    local function fail(arg)
    	dump(arg,'当前的反馈信息')
    	if arg.msg then 
      	  self.tool:showTips(arg.msg)
   		 end
    end
    self.tool:fastRequest(dataTable,succ, fail,true)
end 	

return UICommitment
