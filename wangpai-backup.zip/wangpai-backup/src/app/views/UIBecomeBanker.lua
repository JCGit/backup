local UIBecomeBanker = class("UIBecomeBanker", cc.load("mvc").ViewBase)

UIBecomeBanker.RESOURCE_FILENAME = "UIBecomeBanker.csb"
--UIBecomeBanker.RESOURCE_PRELOADING = {"main.png"}
--UIBecomeBanker.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIBecomeBanker.RESOURCE_BINDING = { 
    ["Button_close"]     = {["ended"] =  "close"},
    ["Button_apply"]     = {["ended"] =  "applyDealer"},

    } 

function UIBecomeBanker:onCreate(tab,cb)
    local app = self:getApp()
    self.app = app
    self.cb = cb 
    self.config  = app:getData('Config')
    
    self['Text_number']:setString(#tab.nowList .. '人')


    local str = LuaTools.convertAmountChinese(tab.money)
    self['Text_condition']:setString('金币'..str)
    self["Button_apply"]:setTitleText(tab.word)
    self["Text_name"]:setString(tab.nowInfo.nick)--(LuaTools.getFinalNameStr(tab.nowInfo.nick,6))  


    local str2 = LuaTools.convertAmountChinese(tab.nowInfo.coin)
    self["Text_chips"]:setString(str2)

    local headImage = self['Image_avatar']
    local oneData = tab.nowInfo
    local newHeadSpr
    if oneData.icon and oneData.icon ~= ""  then  --庄家头像
       local function onFinishTable(status,downloadedSize,dst)
          if status == "success" then
             newHeadSpr = cc.Sprite:create(dst)
          else 
             newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[oneData.sex+1])   
          end
          LuaTools.makeSpriteRounded(newHeadSpr,headImage , self.config.maskSprite, false)
       end
       local newName = oneData.icon
       LuaTools.getFileFromUrl({url = oneData.icon, destFile =(newName:gsub("/","_")), onFinishTable = onFinishTable })
    else 
       newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[oneData.sex+1])
       LuaTools.makeSpriteRounded(newHeadSpr, headImage, self.config.maskSprite, false)   
    end 

    self:setListView(tab.nowList)

    LuaTools.enterActionScaledWithMask(self['Panel_root'])
end


function UIBecomeBanker:setItemByData(item, oneData, index)
    local headImage = item:getChildByName("Image_avatar")
    local nameText = item:getChildByName("Text_p_name")
    local moneyText = item:getChildByName("Text_p_chips")
    local numberText = item:getChildByName("Text_p_number")

    nameText:setString(oneData.nick)--(LuaTools.getFinalNameStr(oneData.nick,6))  
    moneyText:setString(LuaTools.convertAmountChinese(oneData.coin,10000))
    local str = nil
    if index < 10 then
        str = "0"+index
    else
        str = ""+index
    end
    numberText:setString(str)

    local newHeadSpr
    if oneData.icon and oneData.icon ~= ""  then  --庄家头像
       local function onFinishTable(status,downloadedSize,dst)
          if status == "success" then
             newHeadSpr = cc.Sprite:create(dst)
          else 
             newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[oneData.sex+1])   
          end
          LuaTools.makeSpriteRounded(newHeadSpr,headImage , self.config.maskSprite, false)
       end
       local newName = oneData.icon
       LuaTools.getFileFromUrl({url = oneData.icon, destFile =(newName:gsub("/","_")), onFinishTable = onFinishTable })
    else 
       newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[oneData.sex+1])
       LuaTools.makeSpriteRounded(newHeadSpr, headImage, self.config.maskSprite, false)   
    end
end

function UIBecomeBanker:setListView(data)
    local listView = self['ListView_palyer']
    listView:setItemModel(self["Panel_player"])
    if #data == 0 then
        listView:removeAllItems()
    end
    for i=1,#data do
        local oneData = data[i]
        if i > 1 then
            listView:pushBackDefaultItem()
        end
        local item = listView:getItem(i-1)
        self:setItemByData(item, oneData, i)
    end
end

function UIBecomeBanker:close()
    self.app:removeView('UIBecomeBanker') 
end

function UIBecomeBanker:applyDealer()  
    if self.cb then 
    	self.cb()
    end  	
    self["Button_apply"]:setTouchEnabled(false)
    G_BASEAPP:removeView('UIBecomeBanker')
end

return UIBecomeBanker
