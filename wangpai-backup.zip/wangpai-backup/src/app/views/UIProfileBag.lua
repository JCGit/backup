local UIProfileBag= class("UIProfileBag", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
UIProfileBag.RESOURCE_FILENAME = "UIProfileBag.csb"


UIProfileBag.RESOURCE_BINDING = { 
    ["Button_changeBankPwd"] = {["ended"] = "onChangePwd"},
    ["Button_findBankPwd"] = {["ended"] = "onForgetPwd"},
    ["Button_setBankPwd"] = {["ended"] = "onSetBankPwd"},
    ["Button_ClearEgg"] = {["ended"] = "onClearEgg"},
    ["Button_SellGift"] = {["ended"] = "onSellGift"},
}


--初始化
function UIProfileBag:onCreate()
    local app = self:getApp()
    self.app = app
    self.config = app:getData('Config')
    self.tool = app:getModel('Tools')
    self.pData = self.app:getData('PlayerData')
    self:setSkipGoBack(true)

    self['Panel_content']:setBackGroundColorOpacity(0)

    self:initBankInfos()
    self:initToolsInfos()
    self:initGiftsInfos()

    self:updateMoney()
end

function UIProfileBag:getPanelMain()
  return self['Panel_main']
end

--显示/隐藏外边的UI 
function UIProfileBag:showOutBoundaryItems(_show)
    self['Image_toolBubble']:setVisible(_show)
    self['Image_giftBubble']:setVisible(_show)
end

--初始化宝箱信息
function UIProfileBag:initBankInfos()
	self['Text_bankChips']:setString(self.tool:convertAmountChinese(self.pData.bank))
    self.diffValue = 10000
    self.lastValidValue = 1
    self.txfVal = self['TextField_bankChooseVal']
    self.txfVal:setString(self.lastValidValue)
      --上一次有效的道具个数
    local MAXNUMBER = 9999

    --增加+
    local function onAdd(event)
        if event.name == 'ended' then

            local num = tonumber(self.txfVal:getString())
            if num < MAXNUMBER then 
                self.lastValidValue = self.lastValidValue + 1
                self.txfVal:setString(self.lastValidValue)
                
            end 
        end
    end

    --减-
    local function onMinus(event)
        if event.name == 'ended' then
           local num = tonumber(self.txfVal:getString())
           if num > 1 then 
              self.lastValidValue = self.lastValidValue -1
              self.txfVal:setString(self.lastValidValue)
           end
        end
    end

    --手动输入数字
    local function onSetNumber(event)
        local str = tonumber(event.target:getString())
        if event.name == "ATTACH_WITH_IME" then
             event.target:setString("")
        elseif event.name == "DETACH_WITH_IME" then
            if event.target:getString() == "" or str == nil then
                self.lastValidValue = 1
                event.target:setString(self.lastValidValue)
            end
        elseif event.name == "INSERT_TEXT" then
           if str == nil then
                event.target:setString(self.lastValidValue)
            elseif str >= MAXNUMBER then 
                event.target:setString(MAXNUMBER)
                self.lastValidValue = MAXNUMBER
            else 
                event.target:setString(str)
                self.lastValidValue = str
            end
        elseif event.name == "DELETE_BACKWARD" then
            if event.target:getString() == "" then
                self.lastValidValue = 1
                event.target:setString(self.lastValidValue)
            else
                event.target:setString(str)
                self.lastValidValue = str
            end
        end
    end

    --存储
    local function onDeposit(event)
        if event.name == 'ended' then
            if self.txfVal:getString() == "" then return end
            local val = self.lastValidValue*self.diffValue
            if val > self.pData.coin then
                self.tool:showTips("金币数量不足。存钱失败！")
                return
            else if self.lastValidValue == 0 then
                return
            end
            end
            self:requestDeposit(val)
        end
    end

    --取
    local function onWithdraw(event)
        if event.name == 'ended' then
            if self.txfVal:getString() == "" then return end
            local val = self.lastValidValue*self.diffValue
            if val > self.pData.bank then
                self.tool:showTips("金币数量大于保险箱的金币。取钱失败！")
                return
            else if self.lastValidValue == 0 then
                return
            end
            end
            if self.pData.isBankProtect == 1 and #self.pData.bankPwd == 0 then
                self.app:addView('UIProfileSubViews', self:getLocalZOrder() +1, 2, val)
                else
                self:requestWithdraw(val)
            end
        end
    end

    --初始化
    self['Button_bankDeposit']:onTouch(onDeposit)
    self['Button_bankPlus']:onTouch(onAdd)
    self['Button_bankMinus']:onTouch(onMinus)
    self['Button_bankWithdraw']:onTouch(onWithdraw)
    self.txfVal:onEvent(onSetNumber)
    self.txfVal:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    self.txfVal:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    self:switchBankState()
end

--切换宝箱状态
function UIProfileBag:switchBankState()
    local isSetPwd = false
    if self.pData.isBankProtect == 1 then
        isSetPwd = true
    end
    self['Button_setBankPwd']:setVisible(not isSetPwd)
    self['Button_changeBankPwd']:setVisible(isSetPwd)
    self['Button_findBankPwd']:setVisible(isSetPwd)
end

--初始化道具
function UIProfileBag:initToolsInfos()
	local listview = self['ListView_tools']
	local itemModel = self['Panel_Item_tool']
	listview:setItemModel(itemModel)
	listview:setBounceEnabled(false)
	listview:setScrollBarEnabled(false)
	listview:setBackGroundColorOpacity(0)
	itemModel:setBackGroundColorOpacity(0)
    self.innerToolPosX = 0

    --滚动道具的Listview
    local function onScrollList(event)
        if self.lastToolBubble then
                self.lastToolBubble:stopAllActions()
                self.lastToolBubble:removeFromParent()
                self.lastToolBubble = nil
            end
        self.innerToolPosX = event.target:getInnerContainerPosition().x
    end

    listview:onScroll(onScrollList)
    
    local toolDesc = {
        --name, desc
        {"踢人卡", "可以将VIP等级比您低的玩家，在私人场除外，踢出房间。"},
        {"小喇叭", "可以发广播给所有人，每次使用消耗1个喇叭。"},
        {"门票", "可以用来参加大奖赛,不同的比赛场可能消耗数量不同"},
        {"话费券", "一定数量的话费券可以在商城兑换话费或礼品。"},
    }
    
    --点击道具时，显示浮框
    local function onTouchTool(event)
        if event.name == "ended" then
            local index = event.target:getTag()
            if self.lastToolBubble then
                self.lastToolBubble:stopAllActions()
                self.lastToolBubble:removeFromParent()
                self.lastToolBubble = nil
            end
            if self.lastGiftBubble then
                self.lastGiftBubble:stopAllActions()
                self.lastGiftBubble:removeFromParent()
                self.lastGiftBubble = nil
            end
            local toolBubble = self['Image_toolBubble']:clone()
            toolBubble:setVisible(true)
            
            --浮详细对话框
            local pos = listview:convertToWorldSpace(cc.p(event.target:getPosition()))
            pos = listview:getParent():convertToNodeSpace(pos)
            toolBubble:setPositionX(pos.x + self.innerToolPosX) 
            self['Image_toolBubble']:getParent():addChild(toolBubble,1)

            local fadeAction = cc.Sequence:create(
                cc.DelayTime:create(1),
                cc.FadeTo:create(3,0),
                cc.CallFunc:create(function() toolBubble:setVisible(false) end))

            toolBubble:runAction(fadeAction)
            for i,child in ipairs(toolBubble:getChildren()) do
                child:runAction(fadeAction:clone())
            end

            toolBubble:getChildByName("Text_name"):setString(toolDesc[index][1])
            toolBubble:getChildByName("Text_desc"):setString(toolDesc[index][2])
            self.lastToolBubble = toolBubble
        end
    end

	local itemTab = {
        "res_shop/img_kick.png",
	    "res_shop/img_horn.png",
        "res_shop/new9.png",
        "res_shop/img_hf.png",
	 }
    for key ,var in pairs(itemTab) do
    	listview:pushBackDefaultItem()
        local item = listview:getItem(key-1) 
        if var~="res_shop/img_hf.png" then 
            item:getChildByName('Text_count'):setString(self.pData.prop[key])
        else
            item:getChildByName('Text_count'):setString(self.pData.telfee)
        end 
        item:getChildByName('Image_item'):loadTexture(var, ccui.TextureResType.plistType)
        item:setTag(key)
        item:setTouchEnabled(true)
        item:onTouch(onTouchTool)
    end 

    itemModel:setVisible(false)
end

--初始化礼物
function UIProfileBag:initGiftsInfos()
	local listview = self['ListView_gifts']
	local itemModel = self['Panel_Item_gift']
	listview:setItemModel(itemModel)
	listview:setScrollBarEnabled(false)
	listview:setBounceEnabled(false)
	listview:setBackGroundColorOpacity(0)
	itemModel:setBackGroundColorOpacity(0)
    self.innerGiftPosX = 0

    local function onScrollList(event)
        if self.lastGiftBubble then
            self.lastGiftBubble:stopAllActions()
            self.lastGiftBubble:removeFromParent()
            self.lastGiftBubble = nil
        end
        self.innerGiftPosX = event.target:getInnerContainerPosition().x
    end

    listview:onScroll(onScrollList)

	local giftDesc = {
        --name, chips, charm
        {"鲜花（每朵）",0, 3000},
        {"鸡蛋（每个）",0, -10000},
        {"豪车（每辆）",60000, 60000},
        {"轮船（每艘）",300000, 300000},
        {"飞机（每架）",500000, 500000}, 
        {"别墅（每个）",800000, 800000},
        {"神秘岛（每座）",5000000, 5000000},  
    }
    
    --点击礼物会显示礼物描述
    local function onTouchGift(event)
        if event.name == "ended" then
        	local index = event.target:getTag()
            if self.lastGiftBubble then
                self.lastGiftBubble:stopAllActions()
                self.lastGiftBubble:removeFromParent()
                self.lastGiftBubble = nil
            end
            if self.lastToolBubble then
                self.lastToolBubble:stopAllActions()
                self.lastToolBubble:removeFromParent()
                self.lastToolBubble = nil
            end
            local giftBubble = self['Image_giftBubble']:clone()
            giftBubble:setVisible(true)
            
            --浮详细对话框
            local pos = listview:convertToWorldSpace(cc.p(event.target:getPosition()))
            pos = listview:getParent():convertToNodeSpace(pos)
            giftBubble:setPositionX(pos.x + self.innerGiftPosX) 
            self['Image_giftBubble']:getParent():addChild(giftBubble,1)

            local fadeAction = cc.Sequence:create(
                cc.DelayTime:create(1),
                cc.FadeTo:create(3,0),
                cc.CallFunc:create(function() giftBubble:setVisible(false) end))
             giftBubble:runAction(fadeAction)
             
             for i,child in ipairs(giftBubble:getChildren()) do
                child:runAction(fadeAction:clone())
            end
            
            giftBubble:getChildByName("Text_name"):setString(giftDesc[index][1])
            local txtChips = giftBubble:getChildByName("Text_chips")
            local txtcharm = giftBubble:getChildByName("Text_charm")
            if giftDesc[index][2] and giftDesc[index][2] > 0 then
                txtChips:setString("游戏币："..self.tool:convertAmountChinese(giftDesc[index][2]))
                txtcharm:setString("魅力值："..self.tool:convertAmountChinese(giftDesc[index][3]))
                else
                txtChips:setVisible(false)
                txtcharm:setPositionY((txtChips:getPositionY() + txtcharm:getPositionY())/2)
                txtcharm:setString("魅力值："..self.tool:convertAmountChinese(giftDesc[index][3]))
            end
            self.lastGiftBubble = giftBubble
        end
    end

	local itemTab = {
	 "common/gift1.png",
	 "common/gift2.png",
	 "common/gift3.png",
	 "common/gift4.png",
	 "common/gift5.png",
     "common/gift6.png",
     "common/gift7.png",
	 }
    for key ,var in ipairs(itemTab) do
    	listview:pushBackDefaultItem()
        local item = listview:getItem(key-1) 
        item:getChildByName('Text_count'):setString(self.pData.gift[key])
        item:getChildByName('Image_item'):loadTexture(var, ccui.TextureResType.plistType)
        item:setTag(key)
        item:setTouchEnabled(true)
        item:onTouch(onTouchGift)
    end 

    itemModel:setVisible(false)
end

--更新礼物个数
function UIProfileBag:updateGiftsCount()
    local listview = self['ListView_gifts']
    for key, item in ipairs(listview:getChildren()) do
        item:getChildByName('Text_count'):setString(self.pData.gift[key])
    end 
end

--更新道具个数
function UIProfileBag:updateToolsCount()
    local listview = self['ListView_tools']
    for key, item in ipairs(listview:getChildren()) do
        if key~= 3 then 
          item:getChildByName('Text_count'):setString(self.pData.prop[key])
        else 
          item:getChildByName('Text_count'):setString(self.pData.telfee)
        end  
    end 
end

--点击修改宝箱密码
function UIProfileBag:onChangePwd()
    
    self.app:addView('UIProfileSubViews', self:getLocalZOrder() + 1, 5)
end

--点击找回宝箱密码
function UIProfileBag:onForgetPwd()
    
    self.app:addView('UIProfileSubViews', self:getLocalZOrder() + 1, 4)
end

--点击设置银行密码
function UIProfileBag:onSetBankPwd()
    
    self.app:addView('UIProfileSubViews', self:getLocalZOrder() + 1, 6)
end

--点击清理鸡蛋
function UIProfileBag:onClearEgg()
    
   self.app:addView('UIProfileSubViews', self:getLocalZOrder() + 1, 1)
end

--点击卖礼物
function UIProfileBag:onSellGift()
    self.app:addView('UIProfileSubViews', self:getLocalZOrder() + 1, 3)
end

--更新宝箱信息
function UIProfileBag:updateMoney()
    self['Text_bankMyChips']:setString(self.tool:convertAmountChinese(self.pData.coin))
    self['Text_bankChips']:setString(self.tool:convertAmountChinese(self.pData.bank))
    self.app:callMethod('UIProfileInfos', 'updateProgressInfos')
    self.app:callMethod('UIMainTop','updateWealth')
    self.lastValidValue = tonumber(self.txfVal:getString())
    self.txfVal:setString(self.lastValidValue) 
end

--更新VIP信息，在商场里购买VIP卡使用到
function UIProfileBag:updateOnVipChange()
    self['Text_bankMyChips']:setString(self.tool:convertAmountChinese(self.pData.coin))
    self:updateToolsCount()
end

--更新宝箱金币
function UIProfileBag:updateBankMoney()
    self['Text_bankMyChips']:setString(self.tool:convertAmountChinese(self.pData.coin))
end

--请求存储金币
function UIProfileBag:requestDeposit(sum)
    local function onSucc(arg)
        self.tool:showTips('存钱成功 ！')
        self.pData.coin = arg.coin
        self.pData.bank = arg.bank
        self:updateMoney()
    end
    local function fail(arg)
        if arg.msg then
            self.tool:showAlert(arg.msg)
        end
    end
    local dataTable =     {
    ['uid']   = self.pData.uid,
    ['token']  = self.pData.token,
    ['money']      = sum,
    ['bankPwd']    = "",
    ['cmd']       = HttpHandler.CMDTABLE.BANK_SAVEMONEY,
    }
    self.tool:fastRequest(dataTable, onSucc, fail)
end

--请求取金币
function UIProfileBag:requestWithdraw(sum)
    local function onSucc(arg)
        self.tool:showTips('取钱成功 ！')
        self.pData.coin = arg.coin
        self.pData.bank = arg.bank
        self:updateMoney()
    end
    local function fail(arg)
        if arg.msg then
            self.tool:showAlert(arg.msg)
        end
    end
    local dataTable =     {
        ['uid']   = self.pData.uid,
        ['token']  = self.pData.token,
        ['money']      = sum,
        ['bankPwd']    = self.pData.bankPwd,
        ['cmd']       = HttpHandler.CMDTABLE.BANK_DRAWMONEY,
    }
    self.tool:fastRequest(dataTable, onSucc, fail)
end

return UIProfileBag