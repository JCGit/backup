
local UIFriendWeddingRoom = class("UIFriendWeddingRoom", cc.load("mvc").ViewBase)
local TCPConnector = require('app.network.TCPConnector')
local DataPacker = require('app.network.DataPacker')
local DataUnpacker = require('app.network.DataUnpacker')
local HttpHandler = require("app.network.HttpHandler")
local scheduler = require("app.models.QScheduler")
UIFriendWeddingRoom.RESOURCE_FILENAME = "UIFriendWeddingRoom.csb"
UIFriendWeddingRoom.RESOURCE_PRELOADING = {"res_friend.png"}
--UIFriendWeddingRoom.RESOURCE_LOADING  = {["res/background/mohuBg.png"] = {names = {"Image_bgAll"}}}
UIFriendWeddingRoom.RESOURCE_BINDING = {  
    ["Button_exit"]          = {["ended"] = "exitRoom"},
    ["Button_help"]          = {["ended"] = "help"},
    ["Button_flower"]        = {["ended"] = "reqSock_SendFlowers"},
    ["Button_balloon"]       = {["ended"] = "reqSock_SendBolloon"},
    ["Button_inviteFriend"]  = {["ended"] = "inviteFriend"},
    ["Panel_friendList"]     = {["ended"] = "hideFriendList"},
    ['Button_inviteMerry']   = {["ended"] = "reqSock_Propose"}, --求婚
    ["Button_send"]          = {["ended"] = "reqSock_Chat"},     --聊天
    --['Button_voice']         = {["ended"] = "btn_voice"}        --声音
    
}
UIFriendWeddingRoom.WEDDINGCMD = DataUnpacker.CMD[DataUnpacker.Type.WEDDING]['REQ'] 

function UIFriendWeddingRoom:inviteFriend()
    
    local paTable =     {
        ['uid']   = tonumber(self.pData.uid),
        ['token'] = G_TOKEN, 
        ['cmd']   = HttpHandler.CMDTABLE.GET_FRIEND_LIST }  
    local function succ(arg) 
        self:initFriendList(arg.items)
    end     
    self.tool:fastRequest(paTable,succ)
end

function UIFriendWeddingRoom:hideFriendList()
    
    self['Panel_friendList']:setVisible(false)
    self['Panel_friendList']:setPosition(self.posX,self.posY)
end 

function UIFriendWeddingRoom:exitRoom()
    --local app = self.app
    
    self:closeWeddingTcp()
   G_BASEAPP:removeView('UIFriendWeddingRoom')
    --LuaTools.viewAction2Over(self["Panel_main"],"UIFriendWeddingRoom", nil)
end 

function UIFriendWeddingRoom:initFriendList(info)
    self['Panel_friendList']:setVisible(true)
    local size = self['Panel_friendList']:getContentSize() 
    self['Panel_friendList']:runAction(cc.MoveBy:create(0.1,cc.p(-size.width,0)))

    local model = self['Button_modelFriend']          
    self['ListView_friend']:setItemModel(model) 
    self['ListView_friend']:removeAllItems()
    local tag = 0  
    for key,var in pairs(info) do 
        self.tempName[var.uid] = {} 
        self.tempName[var.uid].nick = var.nick
        self.tempName[var.uid].sex  = var.sex 
        local function touchItem(event)
           if event.name == 'ended' then 
              local uid = event.target:getParent():getTag() 
              local str = event.target:getParent():getChildByName('Text_online'):getString()
              self['Panel_friendList']:setVisible(false)
              self['Panel_friendList']:setPosition(self.posX,self.posY)
              if str ~= '在线' then 
                  self.tool:showTips('您的好友不在线，无法邀请婚礼')
              else   
                  self.tagUid = uid 
                  self:reqSock_inVitePerson(uid)
              end 
           end    
        end     

        self['ListView_friend']:pushBackDefaultItem()
        local item = self['ListView_friend']:getItem(tag)
        item:setVisible(true)
        item:setTag(var.uid)
        item:setColor(var.siteid == '-1'  and cc.c3b(127,127,127) or cc.c3b(255,255,255))
        local textName = item:getChildByName('Text_name')
        local textModel =  "一二三四五三四"
        LuaTools.cropLabel(textModel, var.nick, textName)

        item:getChildByName('Text_online'):setString(var.siteid == '-1' and '离线' or '在线')

        -- item:getChildByName('Image_avatar'):getChildByName('Image_vipframe'):setVisible(var.vip > 0)
        -- item:getChildByName('Image_avatar'):getChildByName('Image_vipframe'):getChildByName('Text_viplevel'):setString(var.vip)
        item:getChildByName('Image_men'):setVisible(tonumber(var.sex) == 1)
        item:getChildByName('Image_women'):setVisible(tonumber(var.sex) == 0)
        if tonumber(var.sex) == 1 then 
            item:getChildByName('Image_avatar'):loadTexture("common/default_avater_woman.png",ccui.TextureResType.plistType)
        end
        self.tempName[var.uid].head = tonumber(var.sex) ==1 and 'common/default_avater_woman.png' or 'common/default_avater_man.png'

        local newHeadSpr
        if var.icon and  var.icon ~= "" then
           local function onFinishTable(status,downloadedSize,dst)
                if status == "success" then
                   newHeadSpr = cc.Sprite:create(dst)
                else 
                   newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[var.sex+1])   
                end
                LuaTools.makeSpriteRounded(newHeadSpr, item:getChildByName('Image_avatar'), self.config.maskSprite, false)
           end
           local newName = info.picUrl
           LuaTools.getFileFromUrl({url = info.picUrl, destFile =(newName:gsub("/","_")), onFinishTable = onFinishTable })
        else 
            newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[var.sex+1])   
            LuaTools.makeSpriteRounded(newHeadSpr, item:getChildByName('Image_avatar'), self.config.maskSprite, false)
        end  

        item:getChildByName('Button_invite'):onTouch(touchItem)
        tag = tag + 1  
    end  
end 

function UIFriendWeddingRoom:btn_voice()
    
    if  not self.pData.weddingVoice then 
        self['Button_voice']:loadTextures('res_friend/voice_yes.png','res_friend/voice_yes.png','res_friend/voice_yes.png',ccui.TextureResType.plistType)
        self.pData.weddingVoice = true 
    else 
        self['Button_voice']:loadTextures('res_friend/voice_no.png','res_friend/voice_no.png','res_friend/voice_no.png',ccui.TextureResType.plistType)
        self.pData.weddingVoice = false 
    end  
end 

function UIFriendWeddingRoom:updateRight(uid)
    -- if not uid then return end 
    -- for key, var in pairs(self.tempName) do 
    --     if  tostring(uid) == tostring(key) then 
    --         self['Image_rightHead']:loadTexture(var.head,ccui.TextureResType.plistType)
    --         self['Image_rightHead']:setVisible(true)
    --         self['Button_inviteFriend']:getChildByName('Text_35'):setVisible(false)
    --         self['Text_herName']:setString(var.nick)
    --     end 
    -- end         
end 

function UIFriendWeddingRoom:onCreate(ruid,name)
    local app = self:getApp()
    self.app = app
    self.pData = self.app:getData('PlayerData') 
    self.tool = app:getModel('Tools')
    self.config = app:getData('Config')
    --LuaTools.viewAction2(self["Panel_main"], nil, false)
    self.posX,self.posY = self['Panel_friendList']:getPosition() 
    self['Panel_marry']:setVisible(false)
    self.AllUserInfo = {} 
    self["Button_flower"]:setPressedActionEnabled(true) 
    self["Button_balloon"]:setPressedActionEnabled(true) 
    self.ruid  = ruid
    self.rname = name 
    self.tempName = {} 
    self.isOwner  = (tonumber(ruid) == tonumber(self.pData.uid) )

    self['TextField_chat']:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    
    if  not self.pData.weddingVoice then 
        self['Button_voice']:loadTextures('res_friend/voice_no.png','res_friend/voice_no.png','res_friend/voice_no.png',ccui.TextureResType.plistType)
    end     
    local model = self['Panel_model']
    self['ListView_chatavatar']:setItemModel(model)
    self['Button_inviteMerry']:setPressedActionEnabled(true)

    self:setupWeddingTCP()

end 


function UIFriendWeddingRoom:sendHeartbeat()
    self:stopSchedule('heartbeat')
    self:createSchedule('heartbeat', function()   
        self:reqSock_HeartBeat() 
    end,30)  
end
 
function  UIFriendWeddingRoom:RespCMD_onConnected()
    UIFriendWeddingRoom.hallTcpInstance:sendData(self:reqSock_Login(self.ruid))
    self:sendHeartbeat()     
end
 
function  UIFriendWeddingRoom:setupWeddingTCP(ruid,name) 
      if ruid then 
        self.ruid  = ruid 
        self.rname = name 
        self.tempName = {} 
      end 
      UIFriendWeddingRoom.hallTcpInstance = TCPGearbox.buildInstance({
            unpackerType = DataUnpacker.Type.WEDDING, 
            delegate = self,  
            callbackPrefix = "RespCMD_",
            name = 'WeddingTCP'
        })
end

function UIFriendWeddingRoom:closeWeddingTcp()
        self:reqSock_Logout()           --登出
        self:stopSchedule('heartbeat') 
end

--心跳
function UIFriendWeddingRoom:reqSock_HeartBeat() 
    local bufferHnd = DataPacker.new(UIFriendWeddingRoom.WEDDINGCMD['HEARTBEAT'])
    local buffer = bufferHnd:doPack()
    UIFriendWeddingRoom.hallTcpInstance:sendData(buffer)
end 

--登入
function UIFriendWeddingRoom:reqSock_Login(ruid) 
    local bufferHnd = DataPacker.new(UIFriendWeddingRoom.WEDDINGCMD['LOGIN'])
    bufferHnd:writeData(self.pData.uid,DataPacker.INT)
    bufferHnd:writeData(self.pData.token,DataPacker.STRING)
    bufferHnd:writeData(14,DataPacker.BYTE)     
    bufferHnd:writeData(0,DataPacker.INT)  
    bufferHnd:writeData(ruid,DataPacker.INT)       
    local  buffer = bufferHnd:doPack()
    return buffer
end 
--登出
function UIFriendWeddingRoom:reqSock_Logout() 
    local bufferHnd = DataPacker.new(UIFriendWeddingRoom.WEDDINGCMD['LOGOUT'])
    local buffer = bufferHnd:doPack()
    UIFriendWeddingRoom.hallTcpInstance:sendData(buffer)
    UIFriendWeddingRoom.hallTcpInstance:closeAndRelease()
end

--送红包
function UIFriendWeddingRoom:reqSock_SendRedPocket() 
    local bufferHnd = DataPacker.new(UIFriendWeddingRoom.WEDDINGCMD['SENDREDPOCKET'])
    bufferHnd:writeData(1,DataPacker.INT)
    local buffer = bufferHnd:doPack()
    UIFriendWeddingRoom.hallTcpInstance:sendData(buffer)
end 

--送礼金
function UIFriendWeddingRoom:reqSock_SendCoin(uid) 
    local bufferHnd = DataPacker.new(UIFriendWeddingRoom.WEDDINGCMD['SENDCOIN'])
    bufferHnd:writeData(uid,DataPacker.INT)
    bufferHnd:writeData(1,DataPacker.INT)
    local buffer = bufferHnd:doPack()
    UIFriendWeddingRoom.hallTcpInstance:sendData(buffer)
end 

--送气球 
function UIFriendWeddingRoom:reqSock_SendBolloon()
    
    local bufferHnd = DataPacker.new(UIFriendWeddingRoom.WEDDINGCMD['SENDBALLOON'])
    local buffer = bufferHnd:doPack()
    UIFriendWeddingRoom.hallTcpInstance:sendData(buffer)

end

--送鲜花  reqSock_
function UIFriendWeddingRoom:reqSock_SendFlowers() 
    
    local bufferHnd = DataPacker.new(UIFriendWeddingRoom.WEDDINGCMD['SENDFLOWERS'])
    local buffer    = bufferHnd:doPack()
    UIFriendWeddingRoom.hallTcpInstance:sendData(buffer)
    
end 

--邀请被求婚者
function UIFriendWeddingRoom:reqSock_inVitePerson(uid)
    --调用婚礼房间邀请
    local bufferHnd = DataPacker.new(UIFriendWeddingRoom.WEDDINGCMD['INVITE_OTHER'])
    bufferHnd:writeData(uid,DataPacker.INT)
    local buffer = bufferHnd:doPack()
    UIFriendWeddingRoom.hallTcpInstance:sendData(buffer)
    -----------------------------
    --调用大厅邀请
    local  function callback() 
            if  G_BASEAPP:getView('UIMain') then 
                 G_BASEAPP:getView('UIMain'):reqSock_inviteFriend(self.tagUid,self.TableType,self.TableId)
            end   
    end    
    self['Panel_main']:runAction(cc.Sequence:create(cc.DelayTime:create(0.1),cc.CallFunc:create(callback)))
end 

--求婚
function UIFriendWeddingRoom:reqSock_Propose()
    if not self.tagUid then  return end 
    local bufferHnd = DataPacker.new(UIFriendWeddingRoom.WEDDINGCMD['PROPOSAL'])
    bufferHnd:writeData(self.tagUid,DataPacker.INT)
    local buffer = bufferHnd:doPack()
    UIFriendWeddingRoom.hallTcpInstance:sendData(buffer)
    LuaTools.showAlert('求婚邀请已发送')
    
end 

--同意求婚 
function UIFriendWeddingRoom:reqSock_ProposeAccept(uid)
    local bufferHnd = DataPacker.new(UIFriendWeddingRoom.WEDDINGCMD['PROPOSAL_ACCEPT'])
    bufferHnd:writeData(uid,DataPacker.INT)
    local buffer = bufferHnd:doPack()
    UIFriendWeddingRoom.hallTcpInstance:sendData(buffer)
    self['Panel_propose']:setVisible(false)
    self['Panel_marry']:setVisible(true)
end

--拒绝求婚
function UIFriendWeddingRoom:reqSock_ProposeDeny(uid)
    
    local bufferHnd = DataPacker.new(UIFriendWeddingRoom.WEDDINGCMD['PROPOSAL_DENY'])
    bufferHnd:writeData(uid,DataPacker.INT)
    local buffer = bufferHnd:doPack()
    UIFriendWeddingRoom.hallTcpInstance:sendData(buffer)
end 

--聊天 CHATSTRING
function UIFriendWeddingRoom:reqSock_Chat()
    
    local str = self['TextField_chat']:getString() 
    if #str < 1 then 
       self.tool:showTips('聊天内容不能为空')
       return 
    end    
    local bufferHnd = DataPacker.new(UIFriendWeddingRoom.WEDDINGCMD['CHATSTRING'])
    bufferHnd:writeData(str,DataPacker.STRING)
    local buffer = bufferHnd:doPack()
    UIFriendWeddingRoom.hallTcpInstance:sendData(buffer)
    self['TextField_chat']:setString('')
end

function UIFriendWeddingRoom:reqSock_SENDGIFT(uid,giftId,num)
    local bufferHnd = DataPacker.new(UIFriendWeddingRoom.WEDDINGCMD['SENDGIFT'])
    bufferHnd:writeData(uid,DataPacker.INT)
    bufferHnd:writeData(giftId,DataPacker.BYTE)
    bufferHnd:writeData(num,DataPacker.SHORT)
    local buffer = bufferHnd:doPack()
    UIFriendWeddingRoom.hallTcpInstance:sendData(buffer)
end

------------------------------------------------------------

function UIFriendWeddingRoom:addCellOfPeople(info,fact,abc)
    if  abc and  abc == 1 then 
        self['ListView_chatavatar']:insertDefaultItem(0)
    else     
        self['ListView_chatavatar']:pushBackDefaultItem()
    end     
    local function sendGiftBut(event) 
       if event.name == 'ended' then 
           local tag = event.target:getTag()
           self.app:addView('UISendGift',333,string.sub(tag,1,-2),2)
           --self:reqSock_SendCoin(string.sub(tag,1,-2)) 
       end 
    end  

    local function checkInfo(event)
       if event.name == 'ended' then 
           local tag = event.target:getTag()
           local tab = {} 
           tab.uid = tag 
           tab.tag = 5
           self.app:addView('UIFriendBrief',333,tab)
       end
    end
  
    local temp  
    if abc and abc == 1 then  
        temp = self['ListView_chatavatar']:getItem(0)
    else    
        temp = self['ListView_chatavatar']:getItem(#(self['ListView_chatavatar']:getItems())-1) 
    end     
    temp:setTag(info.uid)
    local textName = temp:getChildByName('Text_name')
    local textModel =  "一二三四五三四五"
    LuaTools.cropLabel(textModel, info.name, textName)
    temp:onTouch(checkInfo)
    
    temp:getChildByName('Text_coin'):setString(fact == false and  ('')  or ('金币:'..LuaTools.convertAmountChinese(self.pData.coin)))
    temp:getChildByName('Text_gem'):setString(fact == false and ('')  or ('元宝:'..LuaTools.convertAmountChinese(self.pData.gem)))
    temp:getChildByName('Button_sendGift'):setTag(info.uid..'2')
    temp:getChildByName('Button_sendGift'):setPressedActionEnabled(true)
    temp:getChildByName('Button_sendGift'):setVisible(not fact)
    temp:getChildByName('Button_sendGift'):onTouch(sendGiftBut)
    local newHeadSpr
    if info.picUrl and  info.picUrl ~= '' then 
       local function onFinishTable(status,downloadedSize,dst)
            if status == "success" then
               newHeadSpr = cc.Sprite:create(dst)
            else 
               newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[info.sex+1])   
            end
            LuaTools.makeSpriteRounded(newHeadSpr, temp:getChildByName('Image_head'), self.config.maskSprite, false)
       end
       local newName = info.picUrl
       LuaTools.getFileFromUrl({url = info.picUrl, destFile =(newName:gsub("/","_")), onFinishTable = onFinishTable })
    else 
        newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[info.sex+1])   
        LuaTools.makeSpriteRounded(newHeadSpr, temp:getChildByName('Image_head'), self.config.maskSprite, false)
    end  
end 


function UIFriendWeddingRoom:removeCellOfPeople(uid) 
    if not uid then return end 
    local length = #(self['ListView_chatavatar']:getItems())-1 
    for key = 0, length do 
        local tag = self['ListView_chatavatar']:getItem(key):getTag() 
        if  tonumber(tag) == tonumber(uid) then 
             self['ListView_chatavatar']:removeItem(key) 
             break
        end 
    end          
end


function UIFriendWeddingRoom:addCellOfChat(msg) 
    local model = self['Panel_chatModel']:clone() 
    model:setVisible(true)

    local text =  ccui.Text:create()
    text:setFontSize(20)
    text:setString(msg) 
    val1 = text:getVirtualRendererSize().width
    local b = math.ceil(val1/(model:getContentSize().width-40))+1


    local textArea = ccui.Text:create()
    textArea:ignoreContentAdaptWithSize(false)
    textArea:setContentSize(cc.size(model:getContentSize().width-40, b*22+6))
    textArea:setAnchorPoint(0,0.35)
    textArea:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT)
    textArea:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    textArea:setString(msg)
    textArea:setFontSize(20)
    textArea:setPosition(20,model:getContentSize().height/2)
    model:setContentSize(cc.size(model:getContentSize().width, b*22+20))

    model:addChild(textArea)

    self['ListView_chat']:pushBackCustomItem(model)

    self['ListView_chat']:scrollToBottom(0.5, true) 
end 

--更新婚礼两人头像
function UIFriendWeddingRoom:updateHead(urls,pos1,pos2,sex)
    pos1:setVisible(true)
    pos2:setVisible(true)
    pos1:setLocalZOrder(99)
    pos2:setLocalZOrder(99)
    self['Panel_marry']:getChildByName('Image_77_0'):setLocalZOrder(199)
    self['Panel_marry']:getChildByName('Image_77_0_0'):setLocalZOrder(199)
    self['Panel_propose']:getChildByName('Image_77'):setLocalZOrder(199)
    self['Button_inviteFriend']:setLocalZOrder(199)
    local newHeadSpr, newHeadSpr1
    if urls and  urls ~= "" then
        local function onFinishTable(status,downloadedSize,dst)
            if status == "success" then
               newHeadSpr = cc.Sprite:create(dst)
            else 
               newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[sex+1])   
            end
            LuaTools.makeSpriteRounded(newHeadSpr, pos1, self.config.maskSprite, false)
            newHeadSpr1 = newHeadSpr
            LuaTools.makeSpriteRounded(newHeadSpr1, pos2, self.config.maskSprite, false)
        end
        local newName = urls
        LuaTools.getFileFromUrl({
           url = urls,
           destFile = (newName:gsub("/","_")),
           onFinishTable = onFinishTable
           })
    else 
        newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[sex+1])   
        newHeadSpr1 = newHeadSpr
        LuaTools.makeSpriteRounded(newHeadSpr, pos1, self.config.maskSprite, false)
        LuaTools.makeSpriteRounded(newHeadSpr1, pos2, self.config.maskSprite, false)
    end

end
------------------------------------------------------------
--response 
function  UIFriendWeddingRoom:RespCMD_HEARTBEAT()

end 


function UIFriendWeddingRoom:RespCMD_LOGIN_SUCC(data)
    dump(data,'登录婚礼房间成功')
    self.TableId   = data.TableId
    self['Button_inviteMerry']:setVisible(tonumber(self.pData.uid) == tonumber(self.ruid))
    self['Button_inviteFriend']:setTouchEnabled(tonumber(self.pData.uid) == tonumber(self.ruid))
    self['Button_inviteFriend']:getChildByName('Text_35'):setString(tonumber(self.pData.uid) == tonumber(self.ruid) and '邀请好友' or '') 
    self.ownerUid = data.TableId 
    self.TableType = data.TableType
    self['Panel_propose']:setVisible(data.isMerry == 0)
    self['Panel_marry']:setVisible(data.isMerry ~= 0) 
    self['Button_flower']:setVisible(data.MarriageType ~= 99)  
    self['Button_balloon']:setVisible(data.MarriageType ~= 99)  


    if G_BASEAPP:getView('UIFriendWeddingCreate') then 
            G_BASEAPP:removeView('UIFriendWeddingCreate')
    end  
    if G_BASEAPP:getView('UIFriend') then 
       G_BASEAPP:getView('UIFriend'):refreshWedding()
    end 
    if  data.users and #data.users > 0  then 
        for key,var in pairs(data.users) do 
            
            local new_tab =  {}
            new_tab.name    = var.name 
            new_tab.uid    = var.uid
            new_tab.flower  = 0 
            new_tab.balloon = 0
            -- new_tab.xijin   = 0 
            -- new_tab.hongbao = 0 
            table.insert(self.AllUserInfo,new_tab)

            if var.IsInvited  == 1 then 
                self:updateHead(var.picUrl,self['Image_rightHead'],self['Image_right_merry'],var.sex)
                self['Text_herName']:setString(var.name)
                self['Text_right_name']:setString(var.name)
                self['Button_inviteFriend']:getChildByName('Text_35'):setString('')
                self.tagUid = var.uid
            end

            if var.IsWedding  == 1 then 
                self:updateHead(var.picUrl,self['Image_leftHead'],self['Image_left_merry'],var.sex)
                self['Text_myName']:setString(var.name)
                self['Text_left_name']:setString(var.name)
            end     
            if  not self.isOwner and tonumber(var.uid) == tonumber(self.ownerUid) then 
                self:addCellOfPeople(var,false)
            end     
        end 

        for key,var in pairs(data.users) do  
            if  tonumber(var.uid) == tonumber(self.pData.uid) then 
                self:addCellOfPeople(var,true)     
            end 
        end      

        for  key,var in pairs(data.users) do  
             if  tonumber(var.uid) ~= tonumber(self.pData.uid) and tonumber(var.uid) ~= tonumber(self.ownerUid)  then 
                 self:addCellOfPeople(var,false)     
             end 
        end            
    end         

end 

function UIFriendWeddingRoom:RespCMD_LOGOUT_SUCC()

end 
 
--异地登陆冲突响应 
function UIFriendWeddingRoom:RespCMD_LOGIN_CONFLICT()

end 

--更新用户信息响应
function UIFriendWeddingRoom:RespCMD_UPDATE_USERINFO()

end 



--用户进入
function UIFriendWeddingRoom:RespCMD_USER_ENTER(data)
    -- print('新人进入')
    -- dump(data)
    local new_tab = {} 

    new_tab.name    = data.name 
    new_tab.uid    = data.uid
    new_tab.flower  = 0 
    new_tab.balloon = 0
    -- new_tab.xijin   = 0 
    -- new_tab.hongbao = 0 
    local str = '玩家'..data.name..'进入房间' 
    self:addCellOfChat(str)
    table.insert(self.AllUserInfo,new_tab)
    if data.IsInvited  == 1 then 
        self:updateHead(data.picUrl,self['Image_rightHead'],self['Image_right_merry'],data.sex)
        self['Text_herName']:setString(data.name)
        self['Text_right_name']:setString(data.name)
        self['Button_inviteFriend']:getChildByName('Text_35'):setString('')
        self:addCellOfPeople(data,false,1)        
        return 
    end

    if data.IsWedding  == 1 then 
        self:updateHead(data.picUrl,self['Image_leftHead'],self['Image_left_merry'],data.sex)
        self['Text_myName']:setString(data.name)
        self['Text_left_name']:setString(data.name)
    end 
    self:addCellOfPeople(data,false)
end 

--用户离开
function UIFriendWeddingRoom:RespCMD_USER_LEFT(data)
    print('用户离开')    
    self:removeCellOfPeople(data.uid)
    for key,var in pairs(self.AllUserInfo) do 
        if tonumber(var.uid) == tonumber(data.uid) then 
           local str = '玩家'..var.name..'离开房间' 
           self:addCellOfChat(str)
           table.remove(self.AllUserInfo,key)
           break 
        end 
    end        
end 

--文字聊天
function UIFriendWeddingRoom:RespCMD_CHAT(data)
    if  self.AllUserInfo and #self.AllUserInfo > 0 then 
        for key ,var in pairs(self.AllUserInfo) do 
            if tonumber(data.uid) == tonumber(var.uid) then 
                local str = '玩家'..var.name..': '..data.str
                self:addCellOfChat(str)
            end 
        end 
    end            
end 

--表情聊天
function UIFriendWeddingRoom:RespCMD_EMOJI()
end 

--常用语聊天
function UIFriendWeddingRoom:RespCMD_CHATSTRID()

end 

--送礼物  PlayerId  ToPlayerId giftId   num
function UIFriendWeddingRoom:RespCMD_SENDGIFT(data)  
   local giftTab = {'朵鲜花','个鸡蛋','辆摩托车','辆跑车','艘轮船','架飞机'}
   local nameA ,nameB  
   for key ,var in pairs(self.AllUserInfo) do 
       if tonumber(data.PlayerId) ==  tonumber(var.uid) then  
          nameA = var.name 
       end 
       
       if tonumber(data.ToPlayerId) ==  tonumber(var.uid) then  
           nameB = var.name 
       end     
    end 
    if tonumber(self.pData.uid) == tonumber(data.PlayerId)  then 
        nameA = '您'
    elseif tonumber(self.pData.uid) == tonumber(data.ToPlayerId) then    
        nameB = '您'
    end 
    
    if nameA and nameB then 
       local str = nameA..'赠送给玩家'..nameB..'  '..data.num..giftTab[data.giftId]    
       self.tool:showTips(str)
       self:addCellOfChat(str)
    end    
end 

-- 送红包 1
function UIFriendWeddingRoom:RespCMD_SENDREDPOCKET()

end 

--送喜金 2
function UIFriendWeddingRoom:RespCMD_SENDREDPOCKET()

end 

--送气球 3 
function UIFriendWeddingRoom:RespCMD_SENDBALLOON(data)
    print('送气球')
    dump(data)
    local image_tab = {'icon/balloons.png','icon/balloons1.png','icon/balloons2.png'}
    local num  = math.random(3,5)
    local temp = math.random(1,3)
    for key=1 ,num do 
        local image = ccui.ImageView:create(image_tab[temp])
        --image:setScale(0.4)
        self['Panel_main']:addChild(image,10086)
        local posX ,posY= math.random(0,1200),math.random(-100,400)
        local winSize = cc.Director:getInstance():getWinSize() 
        image:setPosition(posX,posY)
        local function cb() 
            image:removeFromParent()
        end     
        local act = cc.MoveBy:create(20,cc.p(0,winSize.height-posY))
        image:runAction(cc.Sequence:create(act,cc.CallFunc:create(cb)))--(cc.Spawn:create(cc.FadeOut:create(20),cc.MoveBy:create(20,cc.p(0,winSize.height-posY))))
    end 

    if  self.AllUserInfo and #self.AllUserInfo > 0 then 
        for key ,var in pairs(self.AllUserInfo) do 
            if tonumber(data.PlayerId) == tonumber(var.uid) then 
               var.balloon = var.balloon + 1 
               local str = '玩家'..var.name..'放了个爱心气球'--..var.balloon 
               --local tag =  var.uid..'3'
               self:addCellOfChat(str)
            end 
        end 
    end             
end 

--送鲜花 4 
function UIFriendWeddingRoom:RespCMD_SENDFLOWERS(data)
    print('送鲜花')
    dump(data)
    LuaTools.addParticles('icon/flower.plist',self['Panel_main'],10,true)
    if  self.AllUserInfo and #self.AllUserInfo > 0 then 
        for key ,var in pairs(self.AllUserInfo) do 
            if tonumber(data.PlayerId) == tonumber(var.uid) then 
              var.flower = var.flower + 1 
               local str = '玩家'..var.name..'撒了一把花瓣'--..var.flower
               --local tag = var.uid..'4' 
               self:addCellOfChat(str)
            end 
        end 
    end
end 

--邀请成功
function UIFriendWeddingRoom:RespCMD_SINVITE_SUCC(data)
    --self:updateRight(data.PlayerId)
end 

--被求婚
function UIFriendWeddingRoom:RespCMD_BE_PROPOSALED(data)
    if tonumber(self.pData.uid) == tonumber(data.BePlayerId) then 
        --self.weddingRequest  = data.PlayerId
        if  not self.app:getView('UIFriendWeddingRequest') then 
            self.app:addView('UIFriendWeddingRequest',135,data.PlayerId,self.rname)
        end 
    end       
end 

--求婚被同意
function UIFriendWeddingRoom:RespCMD_BE_PROPOSALED_ACCEPT(data)
         dump(data,'求婚被同意')

    if self.tempName[data.BePlayerId] and self.tempName[data.PlayerId]  then 
        self.tool:showTips('恭喜玩家:'..self.tempName[data.BePlayerId].nick..'与玩家:'..self.tempName[data.PlayerId].nick..'喜结连理')
    end
    self['Panel_propose']:setVisible(false)
    self['Panel_marry']:setVisible(true)   
end 

--求婚被拒绝 PlayerId
function UIFriendWeddingRoom:RespCMD_BE_PROPOSALED_DENY(data)
     dump(data,'求婚被拒绝')
    if tonumber(data.PlayerId) ==  tonumber(self.pData.uid)  then 
        -- if self.tempName[data.BePlayerId] then 
        --     self.tool:showTips(self.tempName[data.BePlayerId].nick..'拒绝了您的求婚')
        -- end
        LuaTools.showAlert('您的求婚被拒绝了~')
    end     
end 

--求婚失败
function UIFriendWeddingRoom:RespCMD_BE_PROPOSALED_FAIL(data)
    self.tool:showTips(data.msg)      
end

--踢人卡
function UIFriendWeddingRoom:RespCMD_KIK_PLAYER()

end

--所有失败响应
function UIFriendWeddingRoom:RespCMD_ERROR()

end

--系统通知
function UIFriendWeddingRoom:RespCMD_SYS_INFO()
       print('系统通知')
end

return UIFriendWeddingRoom
 