local UILogin = class("UILogin", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
UILogin.RESOURCE_FILENAME = "UILogin.csb"
require "cocos.cocos2d.json"
UILogin.RESOURCE_PRELOADING = {"res/background/login_bg.png"}
--UILogin.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}} }
UILogin.RESOURCE_BINDING = {
    ["Button_findPsw"]  = {["ended"] = "enterFind"},
    ["Button_register"] = {["ended"] = "enterReg"},
    ["Button_login"]    = {["ended"] = "onUserLogin"},
    ['Button_guest']  = {["ended"] = "onGuestLogin"},
    
    ["Button_facebook"]     = {["ended"] = "facebookLogin"},


    ["Button_dev"]     = {["ended"] =  "debug_enabledev"},
    ["Button_enablelive"]     = {["ended"] = "debug_enablelive"},
    ["Button_done"]     = {["ended"] = "debug_done"},
    ["Button_exec"]     = {["ended"] = "debug_exec"},
    ["Button_DEBUG"]     = {["ended"] = "debug_open"},
    ["Button_didreq"]     = {["ended"] = "debug_did"},
    ["Button_goFind"]     = {["ended"] = "geiInfoS"},

}

function UILogin:geiInfoS()
    local info = 'version='..G_CURVER..',name='..self.deviceInfos.model..',imsi='..self.deviceInfos.imsi..
    ',imei='..self.deviceInfos.imei..',mac='..self.deviceInfos.mac..',did='..UserCache.csDID..',channel='..self.channelIds
    local dataTable =     {
        ['infos']     = info, 
        ['cmd']       = HttpHandler.CMDTABLE.NEW_FEEDBACK, 
    }
    local function succ(arg) 

       if arg.msg then 
          LuaTools.showAlert(arg.msg)
       end  
    end     
    local function fail(arg) 
       if arg.msg then 
          LuaTools.showAlert(arg.msg)
       end  
    end  
    LuaTools.fastRequest(dataTable,succ, fail)    

end    


function UILogin:debug_did()
    -- self['Panel_debug']:setVisible(true)
   self:pushStatus('------commencing request DID-----')
    LuaTools.requestDID(function(arg)
        self:pushStatus('------request DID completed------')
        for k,v in pairs(arg) do
            self:pushStatus(string.format("[%s]=%s",k,v))
        end
    end,
    function ( arg )
        self:pushStatus('request data sheet:')
        for k,v in pairs(arg) do
            self:pushStatus(string.format("[%s]=%s",k,v))
        end
    end
    ) 
end



function UILogin:debug_open()
    self['Panel_debug']:setVisible(true)
end


function UILogin:debug_enabledev()
    printf('debug_enabledev')
    G_SELECTED_SERVER_CONFIG = G_SERVER_CONFIG['DEV_SERVER_ADDR']
    DEFAULT_HTTP_URL = G_SELECTED_SERVER_CONFIG.addr 
    self:pushStatus('DEVELOPMENT ADDRESS ASSIGNED.') 
end

function UILogin:debug_enablelive()
    printf('debug_enablelive')
    G_SELECTED_SERVER_CONFIG = G_SERVER_CONFIG['ONLINE_SERVER_ADDR']
    DEFAULT_HTTP_URL = G_SELECTED_SERVER_CONFIG.addr 
    self:pushStatus('LIVE ADDRESS ASSIGNED.') 
end


function UILogin:pushStatus(_str)
    -- body
    local cloned = self['Text_debugstats']:clone()  
    local str = LuaTools.splitStringByNumber(_str,40)
    cloned:setString(str) 
    self['ListView_status']:pushBackCustomItem(cloned) 
    self['ListView_status']:scrollToBottom(0.5, true) 
end
 
function UILogin:debug_exec()
    local str = self['TextField_console']:getString()
    self['TextField_console']:setString('') 
    self:pushStatus('exec:\n"'..str..'"')
    local status,result=xpcall(loadstring(str),function(x)

        self:pushStatus('ERROR: '..x)
    end)
    self:pushStatus(string.format('>>status:%s\n>>result:%s',status,result))
end

function UILogin:debug_done() 
    self['Panel_debug']:setVisible(false)
end
 

function UILogin:facebookLogin()
     -- local SDKHandler = require('app.network.SDKHandler')
     --    local a1,a2 = SDKHandler.new(SDKHandler.Type.FACEBOOK,"facebook")
     --    local a3,a4 = SDKHandler.SDKLogin({
     --        onSueccCallback = function() print('onSueccCallback') end,
     --        onCancelCallback = function() print('onCancelCallback') end,
     --        onErrorCallback = function() print('onErrorCallback') end, 
     --        })

     --    printf("a1:%s,a2:%s,a3:%s,a4:%s",a1,a2,a3,a4)
        
end

--初始化
function UILogin:onCreate(isSwitchAccount)
	local pay_conf = LuaTools.getPayData()
    self['Button_DEBUG']:setVisible(false)
    if G_USE_DEBUG_PANEL == true then 
        self['Button_DEBUG']:setVisible(true)
    end
    self:setLockGoback(true)
    local app = G_BASEAPP--self:getApp()
    self.app  = app
    self.tool = app:getModel('Tools') 
    self.pData = self.app:getData('PlayerData') 
    self.config = app:getData('Config')
    self.account = app:getModel('Account')
    self.user= {} 

    self['Panel_Control']:setTouchEnabled(false) 
    self:initPanelView()
    self.Text_version:setString(self.config.textVersion)

    self["Button_login"]:setTouchEnabled(true)
    self['Button_guest']:setTouchEnabled(true)

    --printWarning
    self.deviceInfos = LuaTools.getAllInfomationYouNeeded()

    self.channelIds = LuaTools.getChannelID()
    --dump(self.deviceInfos) 

    if G_LOADINGVIEW then
        G_BASEAPP:removeView('UILoading')
        G_LOADINGVIEW = nil
    end
    if G_CHANNEL_CONFIG.isSdkLogin then
        isSwitchAccount = true
    end
    self:showViewActions(isSwitchAccount) 

    if G_CHANNEL_CONFIG.isSdkLogin and G_CHANNEL_CONFIG.isAddBtnLogin == false then
        self['Image_bg']:loadTexture("background/login_girl.png",ccui.TextureResType.localType)
        self['Panel_main']:setVisible(false)
        self:commeToLogin("")
	elseif G_CHANNEL_CONFIG.isAddBtnLogin then
		self['Image_bg']:loadTexture("background/login_girl.png",ccui.TextureResType.localType)
        self['Panel_main']:setVisible(false)
		--添加按钮
		if G_CHANNELID == "dch_tx_02" then
			--腾讯sdk
			local weixin_Login = ccui.Button:create("res/login_WeChat.png", "res/login_WeChat.png")
			weixin_Login:setAnchorPoint(cc.p(0.5,0.5))
			weixin_Login:setPosition(cc.p(430, 100))
		   
			local function callback(ref, type)
				if type == ccui.TouchEventType.ended then
					self:commeToLogin("Yweixin")
				end
			end
			weixin_Login:addTouchEventListener(callback)
			self:addChild(weixin_Login)
			
			local QQ_Login = ccui.Button:create("res/login_QQ.png", "res/login_QQ.png")
			QQ_Login:setAnchorPoint(cc.p(0.5,0.5))
			QQ_Login:setPosition(cc.p(930, 100))
		   
			local function callback(ref, type)
				if type == ccui.TouchEventType.ended then
					self:commeToLogin("Yqq")
				end
			end
			QQ_Login:addTouchEventListener(callback)
			self:addChild(QQ_Login)
		end
		
    end
end

function UILogin:commeToLogin(login_type) 
	local ThirdSDKHandler = require('app.network.ThirdSDKHandler')
	local function success(str)
		local tb1 = json.decode(str)
		local LoginConfig = require("app.data.LoginConfig") 
		local conf = {};
		local temp = LoginConfig[G_CHANNELID];--根据渠道获取对象sdk配置参数
		for key, value in pairs(temp) do      
			if temp[key] ~= nil then
				conf[key] = temp[key];
			end
		end  
		
		if G_CHANNELID == "dch_tx_02" then
			--特殊情况,type单独赋值
			conf['type'] = login_type
			
		end
		
		for key, value in pairs(conf) do      
			if tb1[key] ~= nil then
				conf[key] = tb1[key];
			end
		end
		--兼容处理
		if tb1['状态'] ~= nil then
			if tb1['状态'] ~= 1 then return end;
		end
		
		if tb1['会员编号'] ~= nil then 
			conf['uuid'] = tb1['会员编号'];
		end
		
		if tb1['session'] ~= nil then 
			conf['password'] = tb1['session'];
			conf['type'] = G_CHANNELID;
		end
		if G_CHANNELID == "dch_tx_02" then
			G_TXLOGININFO = tb1
		end
		self:requestThirdSDKLogin(conf,function()
			
		end)
		
	end
	local function canel()
		print("ssssssssssssss  canel")
	end
	local function failed()
		print("ssssssssssssss  failed")
	end
	ThirdSDKHandler.doSDKLogin(success, canel, failed, login_type)
end

--进入动作
function UILogin:showViewActions(isSwitchAccount)
    -- self['Panel_girl']:runAction(cc.MoveBy:create(self.config.timePanelLoginAction,cc.p(self['Panel_girl']:getContentSize().width,0)))
    self.isAutoLogin = false
    if isSwitchAccount ~= nil then  --是否从设置里切换账号
        else
        --当没有选中记住密码是，可以自动登录
        local autologin = UserCache.getCommonDataByKey("autologin")
        --local remember = UserCache.getCommonDataByKey("remember")
        --print("autologin: "..autologin)
        if autologin ~= 2 then
            local viewAutoLogin = self.app:addView('UIAutoLogin', 111)
            viewAutoLogin:setupDialog(function() self:autoLogin() end,nil)
        end 
    end
end

function UILogin:initTextField(_txf)
    _txf:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    _txf:setTextColor(self.config.Txf_textColorLogin)
end

--更新账号信息显示
function UILogin:updateAccountInfos(_acc, _pwd)
    self['TextField_account']:setString(_acc)
    self['TextField_psw']:setString(_pwd)
end

--根据以保存的数据更新勾选框
function UILogin:updateCheckBox()
     --选中记住密码
    local tag = UserCache.getCommonDataByKey("remember")
    if tag == nil then
        self['CheckBox_remember']:setSelected(true)
        else if tag == 1 then
        self['CheckBox_remember']:setSelected(true)
        else
        self['CheckBox_remember']:setSelected(false)
        end
    end

    tag = UserCache.getCommonDataByKey("autologin")
    if tag == nil then
        self['CheckBox_autoLogin']:setSelected(true)
        else if tag == 1 then
        self['CheckBox_autoLogin']:setSelected(true)
        else
        self['CheckBox_autoLogin']:setSelected(false)
        end
    end
end

--保存新的勾选框数据
function UILogin:saveCheckBoxState()
    if self['CheckBox_remember']:isSelected() == true then 
        UserCache.setCommonDataByKey("remember", 1)
    else
        UserCache.setCommonDataByKey("remember", 2)
    end

     if self['CheckBox_autoLogin']:isSelected() == true then 
        UserCache.setCommonDataByKey("autologin", 1)
    else
        UserCache.setCommonDataByKey("autologin", 2)
    end
end

--初始化UI
function UILogin:initPanelView()
    local account=UserCache.getCommonDataByKey("account")
    local psw =UserCache.getCommonDataByKey("password")
    local isBindAccount = UserCache.getCommonDataByKey("isBindAccount")
    
    if isBindAccount and isBindAccount == 1 then
    	self['Button_guest']:setVisible(false)
    end
    local txf_account = self['TextField_account']
    local txf_pwd = self['TextField_psw']

    self:initTextField(txf_account)
    self:initTextField(txf_pwd)

    self.account:handleTxfControl(txf_account,{"@"})
    self.account:handleTxfControl(txf_pwd)

    txf_account:setString(account)
    txf_pwd:setString(psw)
    
    self:updateCheckBox()

    self:setTextfieldPwdControl(self['Image_eye'], self['TextField_psw'])
end

--眼睛显示
function UILogin:setTextfieldPwdControl(widget, textf)
    local isShowPwd = false
    local function onEyeSwitchState(event)
        if event.name == 'ended' then
            if isShowPwd then
                event.target:setColor(self.config.ColorEyeOpen)
            else
                event.target:setColor(self.config.ColorEyeClose)
            end
            textf:setPasswordEnabled(isShowPwd)
            textf:setString(textf:getString())
            isShowPwd = not isShowPwd
        end
    end
    widget:setColor(self.config.ColorEyeOpen)
    widget:onTouch(onEyeSwitchState)
    widget:setTouchEnabled(true)
end

--初始化设置信息
function UILogin:initSettings()
    for k, v in pairs(self.pData.settings) do
        local settingTable = UserCache.getUserDataByKey("Settings")
        if settingTable == nil then
            UserCache.setUserDataByKey("Settings", self.pData.settings)
        else
            self.pData.settings = settingTable
        end
    end
    audio.setMusicVolume(self.pData.settings.background_volume)
    audio.setSoundsVolume(self.pData.settings.effect_volume)
    --添加设置震动功能
    -- dump( UserCache.csUserData) 
end

--进入找回密码
function  UILogin:enterFind() 
    self.app:addView('UILoginFindPwd',105,self['TextField_account']:getString())
end

--进入注册
function  UILogin:enterReg()
    self.app:addView('UILoginRegister',105)
end

--更新账号信息显示
function  UILogin:updateInfo(text1,text2) 
    self['TextField_account']:setString(text1)
    self['TextField_psw']:setString(text2)
end

--更新密码
function UILogin:updatePwd(pwd,acc)
    --self['TextField_psw']:setPasswordEnabled(false)
    UserCache.setCommonDataByKey("password", pwd)
    self['TextField_psw']:setString(pwd)
    self['TextField_account']:setString(acc) 
end

--自动登录
function UILogin:autoLogin()
    self.user.account=UserCache.getCommonDataByKey("account")
    self.user.pwd  =UserCache.getCommonDataByKey("password")
    self.isAutoLogin = true

    if self.user.account ~= nil and self.user.pwd ~= nil and #self.user.pwd > 0 then
        self:requestLogin(self.user.account, self.user.pwd)        --本地有账号，登录
    else
    	self:onGuestLogin()        --本地未有账号，注册游客账号并登录
    end
end

--手动登录
function  UILogin:onUserLogin(event)
    self.user.account = self['TextField_account']:getString()
    self.user.pwd    = self['TextField_psw']:getString()
    self.tool:freezeWidget(event.target, 2)
    if  #self.user.account <=0 then 
        self.tool:showTips('请输入玩家帐号')
        return       
    elseif #self.user.pwd <= 0 then 
        self.tool:showTips('请输入密码')
        return
    else       
  
    end
	
    self.isGuestTryingLogin = false
    self:requestLogin(self.user.account, self.user.pwd)
    self["Button_login"]:setTouchEnabled(false)

end

--重新请求did
function UILogin:reqDid(tag)
    self.pData.didTag = 0
     local dataTable =     {
        ['channel']   = self.channelIds , 
		['verid']   = G_CURVER, 
        ['cmd']       = HttpHandler.CMDTABLE.SYS_UPDATE, 
    }
    self.isAutoLogin = true
    dataTable['pmodel']   = self.deviceInfos.model
    dataTable['imei']      = self.deviceInfos.imei
    dataTable['imsi']      = self.deviceInfos.imsi
    dataTable['mac']       = self.deviceInfos.mac
    dataTable['type']      = self.config.loginType
    dataTable['requestDID'] = 1 
    local function succ(arg) 
        if arg.did then 
            UserCache.saveDID(arg.did)  
            UserCache.csDID =  UserCache.decryptDID(arg.did ) 
            if tag == 1 then  --普通登录
               if self.user.account ~= nil and self.user.pwd ~= nil and #self.user.pwd > 0 then
                  self:requestLogin(self.user.account, self.user.pwd)  
               end    
            else     --游客登录 
               self:onGuestLogin()  
            end     
        end 
    end 
    local function fail(arg)
        
    end     
    LuaTools.fastRequest(dataTable,succ,fail)
end 

--请求登录        普通账号和游客账号
function UILogin:requestLogin(acc, pwd)
    local pData = G_BASEAPP:getData('PlayerData') 
    self:stopSchedule('updateCSDidNal')
        local table =     {
                ['account']   = acc,
                ['password']  = pwd,
                ['nick']      = self.deviceInfos.model,
                ['pmodel']    = self.deviceInfos.model,
                ['netmode']   = '5',
                --['pv']        = '4',
                ['imsi']      = self.deviceInfos.imsi,
                ['imei']      = self.deviceInfos.imei,
                ['mac']       = self.deviceInfos.mac,
                ['system']    = '1',
                ['did']       = UserCache.csDID,
                ['channel']   = self.channelIds,
                --['verName']   = '1.1',
                --['verCode']   = '1.1',
                ['cmd']       = HttpHandler.CMDTABLE.LOGIN,
                ['version']   = json.encode({['code']= self.config.verCode,['name'] = self.config.verName}),
                ['sign']      = '',
                ['type']      = 'reg',
                ['unionid']   = self.config.unionID,
                 }
    if (self.isGuestTryingLogin == true) then
        table['uuid'] = acc
        table['account'] = ''
        table['type'] = 'yzx'
    end
    local function succ(arg)
        G_IMIP = arg.imip 
		--友盟登录用户记录事件
        local sendumeng = {}
		sendumeng['type'] = 'login'
		sendumeng['uid'] = arg.uuid
		LuaTools.setUmeng(sendumeng)
		
        local app = self.app  
        if self.isGuestTryingLogin then
            self:saveCheckBoxState ()
        else
            if self['CheckBox_remember']:isSelected() == true then   
                UserCache.setCommonDataByKey("password", self.user.pwd)
            else
                UserCache.setCommonDataByKey("password", "")   
            end 
            UserCache.setCommonDataByKey("account", arg.account)
            self:saveCheckBoxState()
        end
        self:updatePlayerData(arg)
        self:initSettings()
        
        self['Panel_Control']:setTouchEnabled(true)     --不允许用户点击任何按钮
        
         if self.isAutoLogin == true then 
            local view = self.app:getView("UIAutoLogin")
            if view then view:removeSelf() end
        end
        G_BASEAPP:addView('UIPreLoading',9999999)
        G_BASEAPP:removeView('UILogin') 
    end
    
    local function fail(arg)
        dump(arg,'普通登录失败') 
        if arg.msg and pData.didTag ~= 1 then 
           self.tool:showTips(arg.msg)
        end    
        
        if pData.didTag == 1 then 
            self:reqDid(1)
        end        

        local view = self.app:getView("UIAutoLogin")
        if view then view:removeSelf() end
    end
    if pData.didTag == 1 then 
        self.isAutoLogin = true
    end  

    if self.isAutoLogin == true then
        LuaTools.fastRequest(table,succ, fail, {['disableAlert']=true,['disableWaiting']=true })       --不显示加载中UI
    else
        --self.tool:fastRequest(table, succ, fail)   
        LuaTools.fastRequest(table,succ, fail, {['disableAlert']=true})
    end
end

--请求登录        普通账号和游客账号
function UILogin:requestThirdSDKLogin(conf,logincallback)
	local table =     {
			['account']   = "",
			['password']  = '',
			['nick']      = self.deviceInfos.model,
			['pmodel']    = self.deviceInfos.model,
			['netmode']   = '5',
			['uuid']        = '',
			['imsi']      = self.deviceInfos.imsi,
			['imei']      = self.deviceInfos.imei,
			['mac']       = self.deviceInfos.mac,
			['system']    = '1',
			['did']       = UserCache.csDID,
			['channel']   = self.channelIds,
			--['verName']   = '1.1',
			--['verCode']   = '1.1',
			['cmd']       = HttpHandler.CMDTABLE.LOGIN,
			['version']   = json.encode({['code']= self.config.verCode,['name'] = self.config.verName}),
			['sign']      = '',
			['type']      = '',
			['unionid']   = self.config.unionID,
			 }
			 
	--参数赋值
	for key, value in pairs(table) do      
		if conf[key] ~= nil then
			table[key] = conf[key];
		end
	end
	
	--检索conf中参数，table不存在该参数则插入conf参数
	for key, value in pairs(conf) do      
		if table[key] == nil then
			table[key] = conf[key];
		end
	end
	
    local function succ(arg)
		
        if self.pData.didTag ==  1 then 
           UserCache.saveOldDid(UserCache.csDID)  
        end 
        -- if cc.UserDefault:getInstance():getStringForKey("NewDidFileSuccess") ~= 'success' then 
        --    cc.UserDefault:getInstance():setStringForKey("NewDidFileSuccess",'success')
        -- end   

        G_IMIP = arg.imip 
        local sendumeng = {}
		sendumeng['type'] = 'login'
		sendumeng['uid'] = arg.uuid
		LuaTools.setUmeng(sendumeng)
        local app = self.app  
        if self.isGuestTryingLogin then
            --self.pData.guest = 1
            self:saveCheckBoxState ()
        else
            if self['CheckBox_remember']:isSelected() == true then   
                UserCache.setCommonDataByKey("password", self.user.pwd)
            else
                UserCache.setCommonDataByKey("password", "")   
            end 
            UserCache.setCommonDataByKey("account", arg.account)
            
            self:saveCheckBoxState()
			
			--
        end
        self:updatePlayerData(arg)
        self:initSettings()

        self['Panel_Control']:setTouchEnabled(true)     --不允许用户点击任何按钮
        
         if self.isAutoLogin == true then 
            local view = self.app:getView("UIAutoLogin")
            if view then view:removeSelf() end
			
        end
		logincallback()
        -- local load = G_BASEAPP:addView("UILoading")  
        -- G_LOADINGVIEW = load
        -- load:setLoadingType(true)
        -- load:setFastLoad(true)
        -- load:setNextAction(function()
        --     -- G_BASEAPP:addView('UIMain',-100, true)
        --     G_BASEAPP:addView('UIPreLoading',9999999)
        --     G_BASEAPP:removeView('UILogin') 
        -- end)
        -- load:startProgress() 
        G_BASEAPP:addView('UIPreLoading',9999999)
        G_BASEAPP:removeView('UILogin') 
		
    end
    
    local function fail(arg)
        dump(arg,'普通登录失败') 
        if arg.msg and self.pData.didTag ~= 1 then 
           self.tool:showTips(arg.msg)
        end        
        local view = self.app:getView("UIAutoLogin")
        if view then view:removeSelf() end
    end

    LuaTools.fastRequest(table,succ, fail, {['disableAlert']=true,['disableWaiting']=true })       --不显示加载中UI
end

--登录成功后更新用户数据
function UILogin:updatePlayerData(info) 


    self.pData.uid  = info.uid or ""
    self.pData.nick = info.nick or ""
    self.pData.sex  = info.sex or 0
    self.pData.uuid = info.uuid or ""
    self.pData.contact = info.contact or ""
    self.pData.icon    = info.icon     or ""
    self.pData.type    = info.type    or 0
    self.pData.modify_pw  = tonumber(info.modify_pw) or 0
    self.pData.status    = info.status   or 0
    self.pData.coin    = tonumber(info.coin   ) or 0
    self.pData.gem    = tonumber(info.gem   ) or 0
    self.pData.charm    = tonumber(info.charm   ) or 0
    self.pData.level    = info.level    or 0
    self.pData.accu    = tonumber(info.accu   ) or 0
    self.pData.telfee    = tonumber(info.telfee   ) or 0
    self.pData.bank    = info.bank   or 0
    self.pData.m_accu    = info.m_accu   or 0
    self.pData.m_level    = info.m_level   or 0
    self.pData.m_round    = info.m_round   or 0
    self.pData.vip_type    = info.vip_type   or 0
    self.pData.vip_day    = info.vip_day   or ""
    self.pData.vipvalid =  info.vipvalid  or 0
    self.pData.vip_level    = tonumber(info.vip_level)  or 0
    self.pData.wins    = tonumber(info.totalwins) or 0
    self.pData.faileds    = tonumber(info.totalfails) or 0
    self.pData.paytotal    = info.paytotal   or 0
    self.pData.gpackFlag   = info.gpackFlag  or 0 

    self.pData.bitcheck   = tonumber(info.bitcheck)  or 0   

    self.pData.fmb    = info.clan  or '' 
    self.pData.core   = (info.core == false and 0 or 1 )
    if self.pData.bitcheck then  
        self.pData.bitcheckCaiNiao = (bit._and(self.pData.bitcheck,1) == 1) and  0 or  1 
        self.pData.bitcheckFund    = (bit._and(self.pData.bitcheck,2) == 2) and  1  or 0 
        self.pData.bitFundFinish   = (bit._and(self.pData.bitcheck,4) == 4) and  1  or 0   -- 1隐藏基金
    end 

    self.pData.bag    = tonumber(info.bag   )
    self.pData.token    = info.token    or ""
    self.pData.did    = info.did or ""
    self.pData.clan    = info.clan   or ""
    self.pData.couple    = info.partner   or {}
    self.pData.payed    = info.payed   or 0
    self.pData.scode    = info.scode   
    self.pData.userinfo = info.userinfo   or ''
    self.pData.nsr    = info.nsr   
    self.pData.smsg    = info.smsg   
    self.pData.announcement    = info.announcement   
    self.pData.pmul    = info.pmul   
    self.pData.qhid    = info.qhid   
    self.pData.filterck    = info.filterck or 0    --隐藏大转盘  1是隐藏

    self.pData.iosPayOpen  = info.iospay or 1  --ios支付开关，1：开 ，0：关 
    local CommonConfig = require("app.data.CommonConfig")
    if LuaTools.isPlatformIOS() then  
        if self.pData.iosPayOpen == 1 then 
           G_CHANNEL_CONFIG.isSdkPay = true 
        else 
           G_CHANNEL_CONFIG.isSdkPay = false         
        end     
    end     

    self.pData.firstpay = info.firstpay   --eg:{"6":1,"10":1,"20":1,"30":1,"50":1,"100":1,"300":1,"500":1}
    self.pData.mms_seq = info.mms_seq   
    self.pData.lotteryForFree = info.zpfree 
    self.pData.friendUidList  = info.friends or {}
    self.pData.divorceCost = info.divorceCost or 0
    self.pData.API_VER = tonumber(info.API_VER) or 0
    self.pData.firstLogin  = info.firstLogin  or 0 
    if info.multiSwitch then 
       self.pData.scoreActive    = info.multiSwitch.scoreActive or  0    --积分兑换 0关闭  1开启 
       self.pData.defaultWeixinAddress  = info.multiSwitch.payTag or 0    --0:yz渠道微信地址  1：广点通地址
       self.pData.ifGetTaxOpen = info.multiSwitch.isProomCost or 1   --私人场收税打开关闭  0 关闭 1 开启
       self.pData.dailyProduct = info.multiSwitch.dailyProduct or 0  --每日礼包
       if info.multiSwitch.active and info.multiSwitch.active['10'] then  
          self.pData.updatePacks = info.multiSwitch.active['10']   --各种礼包
       end  
    end    
    self.pData.limitedProduct = info.limitedProduct or 0             --限时礼包 
    self.pData.gameFilter=   info.filterr or {}  --{['dd']=1,['ddz']=0,['dn']= 0, ['dz']=0,['pdk']=0,['zjh']=0 ,['wrdn']=0}--
    
    ----------------------------------------------------
    -- 关闭德州
    self.pData.gameFilter.dz = 0
    ----------------------------------------------------
    self.pData.matchOpen = info.match or  0    --比赛场开关  0 关闭  1  开启
    -------------------------------------
    self.pData.gameFilterNumber = 0

    self.pData.signStadus = info.signStatus or {}  --签到状态
    self.pData.showOneGame = info.onemenu or 0  --1 为只显示一个游戏
    for key,var in pairs(self.pData.gameFilter) do 
        if var == 1 then 
            self.pData.gameFilterNumber = self.pData.gameFilterNumber + 1       
        end 
    end                 

    self.pData.isBankProtect = info.bankProtect or 0
    self.pData.bankQuestion = info.question or 0
    if info.extra then 
        self.pData.nickChanged = info.extra.isNickChanged or 0
        self.pData.isBindPhone = info.extra.isCheckPhone or 0
    end 
    -- if info.bind and info.bind == 1 then
    --     UserCache.setCommonDataByKey("isBindAccount", 1)
    -- end

    if info.gift then 
        for k, v in pairs(info.gift) do
            self.pData.gift[tonumber(k)] = v
        end
    else
        for k = 1, #self.pData.gift do
            self.pData.gift[k] = 0
        end
    end 
        --dump(self.pData.gift)
        if info.prop  then 
            if info.prop['1'] then --门票
               self.pData.prop[3] = info.prop['1']
            end     
            if info.prop['4'] then --踢人卡
               self.pData.prop[1] = info.prop['4']
            end   
            if info.prop['7'] then --喇叭卡
               self.pData.prop[2] = info.prop['7']
            end            
        end 
        -- dump(self.pData.prop,'玩家道具数量')
    G_TOKEN = self.pData.token 
    G_UID = info.uid
    --cc.UserDefault:getInstance():setStringForKey("uid", info.uid)      
    if self.pData.icon == nil then
    	self.pData.icon = ""
    end
    UserCache.loadUserDataByID(info.uid)
    UserCache.setUserDataByKey("uid", info.uid)
    
end

--点击游客登录按钮
function UILogin:onGuestLogin(event)
    self.isGuestTryingLogin = true
    self:requestGuestRegister()
    -- self["Button_guest"]:setTouchEnabled(false)
    LuaTools.freezeWidget(self["Button_guest"], 3)

end 

--请求游客注册
function UILogin:requestGuestRegister()
    local function callback() 
        if UserCache.csDID and UserCache.csDID ~= '' then 
            self:stopSchedule('updateCSDid')
            local dataTable =     {
                ['pmodel']   = self.deviceInfos.model,
                ['imei']  = self.deviceInfos.imei,
                ['imsi']      = self.deviceInfos.imsi,
                ['mac']       = self.deviceInfos.mac,
                ['did']       = UserCache.csDID,
                ['pv']        = 3,
                ['nick']      = self.deviceInfos.model,
                ['netmode']   = '5',
                ['system']    = '1',
                ['unionid']   = self.config.unionID,
                ['type']      = self.config.loginType, 
                ['cmd']       = HttpHandler.CMDTABLE.QUICK_LOGIN, 
            } 
            -- dump(dataTable,'游客登录发送的table') 
            local function succ(arg)    
                -- dump(arg,'游客登录成功')
                self.isGuestTryingLogin = true
                self:requestLogin(arg.uuid,arg.password)   
                if self.pData.didTag ==  1 then 
                   UserCache.saveOldDid(UserCache.csDID)                         
                end 
            end
            local function fail(arg)
                dump(arg,'游客登录失败') 
                -- print(self.pData.didTag)
                if arg.msg and  self.pData.didTag ~= 1  then
                    self.tool:showTips(arg.msg)
                end
                
                if arg.result == 9 then 
                    if G_BASEAPP:getView('UIAutoLogin') then 
                       G_BASEAPP:removeView('UIAutoLogin') 
                       if arg.msg then 
                          self.tool:showTips(arg.msg)
                       end    
                    end    
                    if arg.bindAccount then 
                       self['TextField_account']:setString(arg.bindAccount) 
                       self['TextField_psw']:setString('')
                    end 
                    return
                end 

                if self.pData.didTag == 1 then 
                   self:reqDid(2)
                end    
            end
            LuaTools.fastRequest(dataTable,succ, fail, {['disableAlert']=true,['disableWaiting']=true }) 
        end 
    end 
    self:createSchedule('updateCSDid',callback,0.1) 
end


return UILogin
