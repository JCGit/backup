local UIAddFriendTcp = class("UIAddFriendTcp", cc.load("mvc").ViewBase)
UIAddFriendTcp.RESOURCE_FILENAME = "UIDialog.csb"
--UIAddFriendTcp.RESOURCE_PRELOADING = {"hall.png"}

UIAddFriendTcp.RESOURCE_BINDING = {
    ["Button_cancel"]      = {["ended"] = "refuse"},
    ["Button_confirm"]     = {["ended"] = "agree"},
}

function UIAddFriendTcp:backEvent(event) 
    self.app:removeView("UIAddFriendTcp")
end
function UIAddFriendTcp:agree(event) 
    local app = self.app    
    app:callMethod('UIGameHall','butIfAddFriend',self.uid,1) 
    app:removeView("UIAddFriendTcp")
end

function UIAddFriendTcp:refuse(event)
    local app = self.app
    app:callMethod('UIGameHall','butIfAddFriend',self.uid,0) 
    app:removeView("UIAddFriendTcp")
end 

function UIAddFriendTcp:onCreate(uid)
    local app = self:getApp()
    self.app = app
    self.PlayerData =app:getData('PlayerData')
    self.uid = uid 
    self["Button_cancel"]:setTitleText('拒 绝')
    self["Button_confirm"]:setTitleText('同 意')
    self['Image_bg1']:setVisible(false)
    self['Image_bg2']:setVisible(true)
    self['Text_string']:setString('Uid:'..uid..'的玩家请求加您为好友')
end

return UIAddFriendTcp

