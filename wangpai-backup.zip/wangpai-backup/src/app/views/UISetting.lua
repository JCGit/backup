local UISetting = class("UISetting", cc.load("mvc").ViewBase)

UISetting.RESOURCE_FILENAME = "UISetting.csb"
--UISetting.RESOURCE_PRELOADING = {"main.png"}
--UISetting.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UISetting.RESOURCE_BINDING = {
    ["Button_Close"] = {["ended"] = "onClose"},
   -- ["Button_ExitGame"] = {["ended"] = "onExitGame"},
    ["Button_ChangePwd"] = {["ended"] = "onChangePwd"},
    ["Button_bindAccount"] = {["ended"] = "onBindAccount"},
    ["Button_switchAccount"] = {["ended"] = "onSwitchAccount"},
    }
local DURATION_SWITCH_MOVE = 0.2    --按钮切换速度
function UISetting:onCreate()
    local app = self:getApp()
    self.app = app 
    self.config = app:getData('Config')
    self.pData = app:getData('PlayerData')
    --self.sound = app:getModel('Sound')

    LuaTools.enterActionScaledWithMask(self['Panel_Main'])
    
    dump(self.pData.settings)
    self:initUI()
    self:updateUserView()

    if G_CHANNEL_CONFIG.isSdkLogin or G_CHANNEL_CONFIG.isOurOnlyAutoLogin then
        self["Button_ChangePwd"]:setVisible(false)
        self["Button_ChangePwd"]:setTouchEnabled(false)
        self["Button_bindAccount"]:setVisible(false)
        self["Button_bindAccount"]:setTouchEnabled(false)
        self["Button_switchAccount"]:setVisible(false)
        self["Button_switchAccount"]:setTouchEnabled(false)
    end
end

--初始化UI
function UISetting:initUI()
    self['Text_version']:setString(G_VERSION)
    self['Text_uid']:setString(self.pData.uid)

    self:initSwitches()
    self:initSliders()
end

--初始化Sliders
function UISetting:initSliders()
    local panels = {
        {'Slider_musicVolume', 'Image_soundMusic'},

        {'Slider_effectVolume', 'Image_soundEffect'}
    }
    local keyNames = {'background_volume','effect_volume'}
    

    local textureSound = {'res_profile/btn_sound_on.png', 'res_profile/btn_sound_off.png'}

    local function onTouchSlider(event)
        if event.name == 'began' then
        elseif event.name == 'ended' then
            local tag = event.target:getTag()
            local keyname = keyNames[tag]
            local percent = event.target:getPercent()
            local imgSound = self[panels[tag][2]]
            if percent == 0 then
                imgSound:loadTexture(textureSound[2] ,ccui.TextureResType.plistType)
            else
                imgSound:loadTexture(textureSound[1] ,ccui.TextureResType.plistType)
            end
            self:updateSettingData(keyname, percent/100)
        end
    end
    for i,var in ipairs(panels) do
        local panel = self[var[1]]
        panel:onTouch(onTouchSlider)
        panel:setTag(i)
        local percent = self:getSettingData(keyNames[i])*100
        print("PERCENT: "..percent)
        panel:setPercent(percent)

        if percent == 0 then
            local imgSound = self[panels[i][2]]
            imgSound:loadTexture(textureSound[2] ,ccui.TextureResType.plistType)
        end
    end
end

--初始化Switches
function UISetting:initSwitches()
    local panels = {'Panel_Vibration', 'Panel_Notification'}
    local keyNames = {'vibration','notification'}

    local function move(_target, _toOn)
        local parent = _target:getParent()
        local move
        if _toOn == true then 
            move = cc.MoveTo:create(DURATION_SWITCH_MOVE,cc.p(parent:getContentSize().width, _target:getPositionY()))
        else
            move = cc.MoveTo:create(DURATION_SWITCH_MOVE,cc.p(_target:getContentSize().width, _target:getPositionY()))
        end
        _target:runAction(move)
    end
    local function changeImageBack(target, on)
        target:getChildByName('Image_bgd_on'):setVisible(on)
        target:getChildByName('Image_bgd_off'):setVisible(not on)
    end
    local function onSwitchState(event)
        if event.name == 'began' then
        elseif event.name == 'ended' then
            local tag = event.target:getTag()
            local keyname = keyNames[tag]
            if self:getSettingData(keyname) == 1 then
                move(event.target:getChildByName('Image_circle'), false)
                self:updateSettingData(keyname, 2)  --off
                changeImageBack(event.target,false)
            else
                move(event.target:getChildByName('Image_circle'), true)
                self:updateSettingData(keyname, 1)  --on
                changeImageBack(event.target,true)
            end
            LuaTools.freezeWidget(event.target, DURATION_SWITCH_MOVE)
        end
    end
    

   for i,name in ipairs(panels) do
    local panel = self[name]
    panel:onTouch(onSwitchState)
    panel:setBackGroundColorOpacity(0)
    panel:setTouchEnabled(true)
    panel:setTag(i)
    local img_circle = panel:getChildByName('Image_circle')
    if self:getSettingData(keyNames[i]) == 1 then
        img_circle:runAction(cc.MoveTo:create(0.01,cc.p(panel:getContentSize().width,img_circle:getPositionY())))
        changeImageBack(panel, true)
    else
        img_circle:runAction(cc.MoveTo:create(0.01,cc.p(img_circle:getContentSize().width,img_circle:getPositionY())))
        changeImageBack(panel, false)
    end
   end
end

--关闭此界面
function UISetting:onClose()
    --self.app:removeView('UISetting')
    LuaTools.viewAction1Over(self['Panel_Main'],"UISetting")
end

--退出游戏事件
function UISetting:onExitGame()
    self.app:addView('UIDialog', self:getLocalZOrder() + 1)
    self.app:callMethod('UIDialog','setupDialog', '', '确定要退出游戏？', 
    function()
        cc.Director:getInstance():endToLua()
		--友盟退出游戏记录
		local sendumeng = {}
		sendumeng['type'] = 'signoff'
		LuaTools.setUmeng(sendumeng)
    end, function()  end) 

end

--修改账号密码事件
function UISetting:onChangePwd()
    
    self.app:addView('UILoginChangePwd',self:getLocalZOrder() + 1) 
end

--切换账号事件
function UISetting:onSwitchAccount() 
    
    LuaTools.softMasterReset()
end

--绑定账号事件
function UISetting:onBindAccount()
    
    self.app:addView('UILoginBindAccount',self:getLocalZOrder() + 1, 1)
end
 
 --更新按钮状态 
function UISetting:updateUserView()
    if self.pData.modify_pw == 0 then
        self["Button_ChangePwd"]:setVisible(false)
    else
        self["Button_bindAccount"]:setVisible(false)
        self["Button_ChangePwd"]:setVisible(true)
    end
end

function UISetting:getSettingData(key)
    return self.pData.settings[key]
end

--更新设置数据
function UISetting:updateSettingData(keyname, _val)
    if keyname == 'background_volume' then
        --self.sound:setMusicVolume(_val)
        audio.setMusicVolume(_val)
    elseif keyname == 'effect_volume' then
        --self.sound:setEffectsVolume(_val)
        audio.setSoundsVolume(_val)
    elseif keyname == 'vibration' then
        --
    elseif keyname == 'notification' then
        --
    end

    print("Music Vol: "..audio.getMusicVolume())
    print("Sound Vol: "..audio.getSoundsVolume())

    self.pData.settings[keyname] = _val
    UserCache.setUserDataByKey("Settings", self.pData.settings)
    dump(self.pData.settings)
end

return UISetting
