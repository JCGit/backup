local UIMainTop = class("UIMainTop", cc.load("mvc").ViewBase)

UIMainTop.RESOURCE_FILENAME = "UIMainTop.csb"
--UIMainTop.RESOURCE_PRELOADING = {"main.png"}
--UIMainTop.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}  

UIMainTop.RESOURCE_BINDING = { 
    ["Button_lottery"]   = {["ended"] = "enterLottery"},
    ["Button_chargeGem"]     = {["ended"] = "enterChargeDiamond"},
    ["Button_chargeCoin"]     = {["ended"] = "enterChargeChips"},
    ["Button_package"]  = {["ended"] = "enterPackage"},
    ["Button_weixin"]  = {["ended"] = "enterQECode"}, 
    ["Button_fund"]  = {["ended"] = "enterFund"},
    ["Button_pointGet"]  = {["ended"] = "enterRedeemPoints"},
    ["Button_dailyTask"]  = {["ended"] = "enterDailyTask"},
    ["Button_dailyPacks"] = {["ended"] = "enterDailyPacks"},


    ["Button_help"]  = {["ended"] = "enterHelpFeedback"},
    ["Button_limitSpree"]  = {["ended"] = "enterSpreeLimit"},

    } 
local HttpHandler = require("app.network.HttpHandler")

--初始化

function UIMainTop:onCreate()
    local app = self:getApp()
    self.app = app
    self.pData = app:getData('PlayerData')
    self.tool = app:getModel('Tools')
    self.config = app:getData('Config')
    --self.sound = app:getModel('Sound')
    self.sx, self.sy = self.app:getModel('Tools'):getUIScale()
    self.LuaTools = LuaTools
    self.avatar = nil
	self.panelLottery = nil
	self.bt_LotteryNode = nil
    self.outOfViewPositionY = self["Panel_Top"]:getPositionY()
    --  self.pData.defaultNickPosition = cc.p(self['Text_Name']:getPosition())
    self['Image_border']:setLocalZOrder(2)
    self['Image_UserVipBgd']:setLocalZOrder(2)
    self['Text_viplevel']:setLocalZOrder(2)
    self['Panel_main']:setBackGroundColorOpacity(0)

    --Active ListView Test
    self['ListView_active']:setScrollBarEnabled(false)
    self['ListView_active1']:setScrollBarEnabled(false)

    -- self['ListView_active']:setFlippedX(true)

    self['Button_dailyTask']:removeFromParent()
    self['ListView_active1']:addChild(self['Button_dailyTask'])  

    self['Button_pointGet']:removeFromParent() 
    if self.pData.scoreActive == 1 then --开启
       self['ListView_active']:addChild(self['Button_pointGet'])
    end    



    self['Button_dailyPacks']:removeFromParent()
    if self.pData.dailyProduct == 1 then --开启
       self['ListView_active']:addChild(self['Button_dailyPacks'])
    end   
    
    if self.pData.limitedProduct > 0 then 
       self['Button_limitSpree']:removeFromParent()
       self['ListView_active']:addChild(self['Button_limitSpree'])
       local time = tonumber(self.pData.limitedProduct)
       self['Button_limitSpree']:setVisible(true)
        local function  callback()    
            local hour   = math.floor(time/3600)   
            local minute = math.floor( (time-hour*3600)/60)
            local second = time - minute*60 - 3600*hour
            local temp = string.format("%02d:%02d:%02d",hour,minute,second) 
            self['Button_limitSpree']:getChildByName('Text_1'):setString(temp)
            --delegate['Button_rewardBox']:setEnabled(time<=0)
            time = time -1
            self.limitSpreeTimeLeft = time 
            if time <= 0 then 
               self['Button_limitSpree']:setVisible(false)
               self:stopSchedule('limitSpreeTime')
            end  
        end 
        self:createSchedule("limitSpreeTime", callback, 1)  
    else 
        self['Button_limitSpree']:removeFromParent(true)
    end 

    if self.pData.bitFundFinish == 0 then
        self['Button_fund']:removeFromParent()
        self['ListView_active1']:addChild(self['Button_fund'])
    else
         --从父节点移除并释放
         self['Button_fund']:removeFromParent(true)                       
    end  
    
    self:handleUpdatePacks()

    --self['Button_weixin']:removeFromParent()
    --self['ListView_active']:addChild(self['Button_weixin'])
    self['Button_help']:removeFromParent()
    self['ListView_active1']:addChild(self['Button_help'])
    self:initAnimations()
    self:updateGpack()  --更新小额礼包
    self:updatePlayerInfos()
    self:updateVipStatus()
end


-----------------------------
-----------------------------
--客服红点
function UIMainTop:showOrHideChatDot(tag)
   self['Image_chatOnlineDot']:setVisible(tag)
end     

function UIMainTop:getChatDotStatus()
   local tag = false 
   if self['Image_chatOnlineDot']:isVisible() then 
      tag = true 
   end 
   return tag    
end 
-----------------------------
-----------------------------
--各种礼包
function UIMainTop:handleUpdatePacks()
   local tagId  
   local image = {'res_icon/newbie_icon.png','res_icon/holiday_icon.png','res_icon/update_icon.png','res_icon/return_icon.png',}
   for k,v in pairs(self.pData.updatePacks) do 
       if v== 1 then 
           tagId = tonumber(k)
           self['Button_updatePacks']:removeFromParent()
           if image[tagId] then 
              self['ListView_active']:addChild(self['Button_updatePacks'])
              self['Button_updatePacks']:loadTextures(image[tagId],image[tagId],image[tagId],ccui.TextureResType.plistType)
           end 
           break
       end  
   end  
   if tagId then 
       local function touch1(event)
          if event.name == 'ended' then 
              self.app:addView('UIUpdatePacks',110,tagId)
          end 
       end
       self['Button_updatePacks']:onTouch(touch1)   
   else 
       self['Button_updatePacks']:removeFromParent()  
   end  
end     
-----------------------------
-----------------------------
function UIMainTop:HideLimitSpree()
    self['Button_limitSpree']:setVisible(false)
    self['ListView_active']:removeChildByName('Button_limitSpree')
end

function UIMainTop:hideDailyPacks() 
    self['Button_dailyPacks']:setVisible(false)
    self['ListView_active']:removeChildByName('Button_dailyPacks')
end     


function UIMainTop:updateGpack()
   
    self['Panel_package']:setVisible(self.pData.gpackFlag<4)
    if self.pData.gpackFlag <4 then 
        local image_tab = {'res_lobby/bt_player_gift.png','res_lobby/bt_player_gift1.png','res_lobby/bt_player_gift2.png','res_newFunction/bt_player_gift3.png'}
        self['Button_package']:loadTextures(image_tab[self.pData.gpackFlag+1],image_tab[self.pData.gpackFlag+1],image_tab[self.pData.gpackFlag+1],ccui.TextureResType.plistType)
    end    
   --更新基金是否隐藏
   if (self.pData.bitFundFinish and  self.pData.bitFundFinish ~=0) then
       self['ListView_active1']:removeChild(self['Button_fund'],true)
   end
   --更新转盘是否隐藏
   if (self.pData.filterck  and self.pData.filterck ~= 0 ) then
        self['ListView_active1']:removeChild(self['Panel_lottery'],true)
   end
 end     

function UIMainTop:enterQECode()
    self.app:addView('UIQRCode',110)
end

--进入大厅需要执行的动作
function UIMainTop:showEnterActions()
    local moveTop = cc.MoveTo:create(0.4, cc.p(0,cc.Director:getInstance():getWinSize().height))
    self["Panel_Top"]:runAction(moveTop)

    local panelLot = self['ListView_active']
    local moveLottery = cc.MoveTo:create(0.4, cc.p(20,panelLot:getPositionY()))
    panelLot:runAction(moveLottery)
    local move = cc.MoveTo:create(0.4, cc.p(20,self['ListView_active1']:getPositionY()))
    self['ListView_active1']:runAction(move)
end

--退出大厅需要执行的动作
function UIMainTop:showExitActions()
    local moveTop = cc.MoveTo:create(0.4, cc.p(0,self.outOfViewPositionY))
    self["Panel_Top"]:runAction(moveTop)

    local panelLot = self['ListView_active']
    local moveLottery = cc.MoveTo:create(0.4, cc.p(-620,panelLot:getPositionY()))
    panelLot:runAction(moveLottery)
    local move = cc.MoveTo:create(0.4, cc.p(-620,self['ListView_active1']:getPositionY()))
    self['ListView_active1']:runAction(move)
end

--进入限时礼包
function UIMainTop:enterSpreeLimit() 
    G_BASEAPP:addView('UISpreeLimit',110,self.limitSpreeTimeLeft)
end     
   

--初始化动画
function UIMainTop:initAnimations()
    self.panelLottery = self['Panel_lottery']
    self.panelLottery:setTouchEnabled(self.pData.filterck == 0)
    self.panelLottery:onTouch(function(event) if event.name == 'ended' then self:enterLottery() end end)
	self.bt_LotteryNode = cc.CSLoader:createNode('Animation_luckgame.csb') 
	self.bt_LotteryNode:setPosition(cc.p(self.panelLottery:getContentSize().width/2,self.panelLottery:getContentSize().height/2))
	
	local action = cc.CSLoader:createTimeline('Animation_luckgame.csb')
	self.bt_LotteryNode:runAction(action)
	action:gotoFrameAndPlay(0,true)
	self.panelLottery:addChild(self.bt_LotteryNode,1)
	self.bt_LotteryNode:setName('lotteryLogo')
	self.panelLottery:getChildByName('lotteryLogo'):setVisible(self.pData.filterck == 0)
	
	self['Image_LotteryDot']:setVisible(self.pData.filterck == 0 and  self.pData.lotteryForFree == 1)
end

--更新用户信息部分
function UIMainTop:updateWealth()
    printf("updating self.pData.coin:%s , self.pData.gem:%s",self.pData.coin,self.pData.gem)
    self['Text_money']:setString(self.tool:convertAmountChinese(self.pData.coin))
    self['Text_gem']:setString(self.tool:convertAmountChinese(self.pData.gem))
    self:updateVipStatus()
    self:updateGpack() 
end


--更新UI色彩
function UIMainTop:updateFrameColor(_color)
    self['Image_bg']:setColor(_color)
    self['Image_border']:setColor(_color)
    self['Button_chargeCoin']:setColor(_color)
    self['Button_chargeGem']:setColor(_color)
end

--更新用户信息
function UIMainTop:updatePlayerInfos()
    self['Text_money']:setString(self.tool:convertAmountChinese(self.pData.coin))
    self['Text_gem']:setString(self.tool:convertAmountChinese(self.pData.gem))
    local textName = self['Text_Name']
    textName:setString(self.pData.nick)
    -- print("AAADWADAWD: "..textName:getString())
    -- print("self.pData.nick: "..self.pData.nick)
    local textModel =  "一二三四五"
    LuaTools.cropLabel(textModel, self.pData.nick, textName)
    -- print("POAWKDPOAWJDA: "..textName:getString())
    local lev, expA, expN = LuaTools.expInfos(self.pData.wins + self.pData.faileds, self.config.levelExp, 1)
    self['Text_level']:setString('Lv. '..lev)
    self['Text_exp']:setString(expA..'/'..expN)
    self['LoadingBar_exp']:setPercent(expA/expN*100)
end

--更新VIP信息
function UIMainTop:updateVipStatus()
    if tonumber(self.pData.vipvalid) <= 0 then
        --self['Text_Name']:runAction(cc.MoveTo:create(0.01, cc.p(self['Image_UserVIP']:getPosition())))
        self['Text_viplevel']:setVisible(false)
        self['Image_UserVipBgd']:setVisible(false)
        self['Image_border']:setVisible(true)
    else
        --self['Text_Name']:runAction(cc.MoveTo:create(0.01, self.pData.defaultNickPosition))
        self['Image_border']:setVisible(false)
        self['Image_UserVipBgd']:setVisible(true)
        self['Text_viplevel']:setVisible(true)
        self['Text_viplevel']:setString("V"..self.pData.vip_level)
        self:updateVipBorder()
    end
end

--更新VIP框边
function UIMainTop:updateVipBorder()
    local texture
    local vday = tonumber(self.pData.vipvalid)
    if vday <= 7 then
        texture = self.config.vipBorder.bronze
    elseif vday > 7 and vday <= 31 then 
        texture = self.config.vipBorder.silver
    else
        texture = self.config.vipBorder.gold
    end
    self['Image_UserVipBgd']:loadTexture(texture,ccui.TextureResType.plistType)
end

--显示首次充值界面
function UIMainTop:showFirstCharge(b) 
        self['Button_package']:setVisible(b)
        self['Panel_package']:getChildByName('Particle_1'):setVisible(b)
        self['Panel_package']:getChildByName('Particle_2'):setVisible(b) 
end

--加载头像
function UIMainTop:loadAvatar()
    local newName = self.pData.icon
    self:updateHead(UserCache.getUserDataByKey('icon'))
        if #self.pData.icon > 1  then
            local argTable = {
                url = self.pData.icon,
                destFile = (newName:gsub("/","_")),
                --useCache = false,
                onFinishTable = function(status,downloadedSize,dst)
                    if status == 'success' then
                        self:updateHead(dst)
                        UserCache.setCurrentUserAvatar(dst)
                    else
                        print('获取头像失败1 !')
                        --self:updateHead()
                    end
                    end
            }
            print('url: '..argTable.url) 
            self.LuaTools.getFileFromUrl(argTable)  
      end
end

--更新头像
function UIMainTop:updateHead(iconPath)
    --点击进入用户个人信息
    local function onEnterProfile(tag, pMenuItem)
        LuaTools.playBtSound()
        self.app:addView('UIProfileMain',110)
    end
    local spr
    if self.avatar then
        self.avatar:removeFromParent()
    end
    if iconPath and #iconPath > 0 then
        spr = cc.Sprite:create(iconPath)
    if spr then
        self.pData.iconPath = iconPath
        UserCache.setUserDataByKey('icon', iconPath)
        end
    else
     --创建默认头像
        spr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[self.pData.sex+1])
        
    end
    
     if spr == nil then
        local oldAvatar = UserCache.getUserDataByKey('icon')
        if oldAvatar and #oldAvatar > 0 then
            spr = cc.Sprite:create(oldAvatar)
        else
            spr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[self.pData.sex+1])
        end 
    end
    self.avatar = LuaTools.makeSpriteRounded(spr, self['Image_UserHead'], self.config.maskSprite, true)
    self.avatar:registerScriptTapHandler(onEnterProfile)
end

--进入大转盘
function UIMainTop:enterLottery()
    self.app:addView('UILottery',110,function()  self['Image_LotteryDot']:setVisible(false) end )
end

function UIMainTop:updateFundRedPoint(tag)
    if tag == true and self.pData.bitcheckFund == 0 then 
        return 
    end     
    self['Image_jiJinDot']:setVisible(tag)
end     

--更新任务红点
function UIMainTop:updateTaskRedPoint(tag)
    self['Image_dailyTaskDot']:setVisible(tag)
end

--进入充值砖石
function UIMainTop:enterChargeDiamond(event)
    local sendumeng = {}
	sendumeng['type'] = 'event'
	sendumeng['eventId'] = 'clickgem'
	LuaTools.setUmeng(sendumeng)
    self.app:addView('UIShopDiamond',200, function() 
        self:updateWealth()
        end)
end

--进入充值金币
function UIMainTop:enterChargeChips(event)
    self.app:addView('UIShop',110,2)
	local sendumeng = {}
	sendumeng['type'] = 'event'
	sendumeng['eventId'] = 'clickgold'
	LuaTools.setUmeng(sendumeng)
end


--进入基金
function UIMainTop:enterFund()
   self.app:addView('UIFund',110)
end  

--进入积分兑换
function UIMainTop:enterRedeemPoints()
   self.app:addView('UIRedeemPoints',110)
end  

--进入每日任务
function UIMainTop:enterDailyTask()
   self.app:addView('UITask',110)
end

--进入每日礼包
function UIMainTop:enterDailyPacks()
   self.app:addView('UIDailypacks',110)
end

--进入领奖
function UIMainTop:enterPackage() 
    
    self.app:addView('UISpree', 200)  --UISpree
end 

--进入问题反馈
function UIMainTop:enterHelpFeedback()
   -- G_BASEAPP:addView('UIHelps',110,5)
   G_BASEAPP:addView('UIChatOnline',110)
end  

--[[加载指定项]]
function UIMainTop:loadTarget()
	local scheduler = require("app.models.QScheduler")
	local scheduler_hand = nil
    local function settime()
		if self.pData ~= nil and self.panelLottery ~= nil and self['Image_LotteryDot'] ~= nil and self.bt_LotteryNode == nil then
			scheduler.unscheduleGlobal(scheduler_hand)
			
			
		end		
	end
	scheduler_hand = scheduler.scheduleGlobal(settime,0.01)
	
end

--[[释放指定项]]
function UIMainTop:clearTarget()
	--if self.bt_LotteryNode ~= nil then
		--self.bt_LotteryNode:removeFromParent()
		--self.bt_LotteryNode = nil
	--end
end


return UIMainTop
