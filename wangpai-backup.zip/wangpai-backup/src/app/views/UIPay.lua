local UIPay = class("UIPay", cc.load("mvc").ViewBase)

UIPay.RESOURCE_FILENAME = "UIPay.csb"
--UIPay.RESOURCE_PRELOADING = {"main.png"}
--UIPay.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIPay.RESOURCE_BINDING = {
    ["Button_close"] = {["ended"] = "backEvent"},
    ['Panel_bg']     = {["ended"] = "backEvent"},
    }


function UIPay:onCreate(key,value)
    local app = self:getApp()
    self.app = app
    if not key then return end 
    if not value then return end
    
    local temp= {'30元宝 +另赠：3元宝','6元宝','50元宝 +另赠：7元宝','100元宝+另赠:30元宝+VIP周卡+价值26元礼包',
        '300元宝+另赠:120元宝+VIP月卡+价值60元礼包','500元宝+另赠:250元宝+VIP半年卡+价值100元礼包','1000元宝+另赠:500元宝+VIP半年卡+价值100元礼包'}
    self['Text_details']:setString(temp[key])
    self['Text_money']:setString('￥' ..value..'.00')
end


function UIPay:backEvent(event)
    self.app:removeView('UIPay')
end

return UIPay
