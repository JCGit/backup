local UIActivity = class("UIActivity", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
UIActivity.RESOURCE_FILENAME = "UIActivity.csb"
--UIActivity.RESOURCE_PRELOADING = {"main.png"}
--UIActivity.RESOURCE_LOADING  = { ["res/background/mohuBg.png"] = {names = {"Image_bgAll"}} }

UIActivity.RESOURCE_BINDING = { 
    ["Button_goAway"]  = {["ended"] = "onClose"},
    --["ListView_Activities"]     = {["ON_SELECTED_ITEM_END"] = "selectEvent"},   

    }
-- BWG7X-J98B3-W34RT-33B3R-JVYW9   XDM3T-W3T3V-MGJWK-8BFVD-GVPKY   Node::UI/GUI Dynamic Create Test/UIWebViewTest。   666666612    24375475711 111111
--已知问题: 457577777 111111


function UIActivity:onClose(event)

    if LuaTools.isPlatformAndroid() then

        if webview:canGoBack()  then 
           webview:goBack()
        else 
           --LuaTools.viewAction2Over(self['Panel_tottt'],'UIActivity')
           self.app:removeView('UIActivity')
        end    
    elseif LuaTools.isPlatformIOS() then

        self.app:removeView('UIActivity')
    end
end

function UIActivity:onCreate()
    local function recruFunc()  
        print("======UIActivity:onCreate()======overrided==========================")  
        self:addGobackEventAction(function() recruFunc() end) 
    end
    self:addGobackEventAction(function()
        recruFunc() 
    end)

    local app = self:getApp()
    self.app = app
    self.config = app:getData('Config')
    self.tool  = app:getModel('Tools')
    self.pData = self.app:getData('PlayerData')
    print('G_IMIP='..G_IMIP)
    
    local webview = ccexp.WebView:create()
    self['Panel_new_web']:addChild(webview)
    local size = self['Panel_new_web']:getContentSize()
    webview:setVisible(false)
    webview:setScalesPageToFit(true)
    local winSize = cc.Director:getInstance():getVisibleSize()

    local temp = 'uid='..self.pData.uid..'&token='..self.pData.token..'&unionid='..G_CHANNELID
    local new = RC4(SHARED_KEY, temp)
    new = LuaTools.StringToBase64(new)
    local ur = string.sub(G_IMIP,1,-6)
    new ='http://'..ur..'17179/activity/activeList'..'?p='..new
    webview:loadURL(new)--("http://183.61.183.197:17179/activity/activeViews")
    webview:setContentSize(cc.size(size.width,size.height))
    webview:reload()
    webview:setPosition(size.width/2,size.height/2)
    

    local function succ()
         webview:setVisible(true)
    end    
    local function fail()
         self.tool:showTips('活动页面加载失败')
    end  
    webview:setOnDidFinishLoading(succ)
    webview:setOnDidFailLoading(fail)

end     


-- function UIActivity:onCreate()
--     local app = self:getApp()
--     self.app = app
--     self.config = app:getData('Config')
--     self.tool  = app:getModel('Tools')
--     self.pData = self.app:getData('PlayerData')
--     self.length = 0
--     self.TagRequest = {}
--     self.tempTag = {}
--     self.lastSelectedIndex = 1
--     self['ListView_Activities']:setItemModel(self['Panel_left_model'])
--     local function cb()
--         local dataTable =     {
--         ['uid']       = self.pData.uid,
--         ['token']     = self.pData.token,
--         ['cmd']       = HttpHandler.CMDTABLE.ACTIVITY_WEBLIST,
--         }
--         local function succ(arg)    
--             print('获取活动列表成功')
--             if arg.items and #arg.items > 0 then 
--                 self.length  =  #arg.items            
--                 self.TagRequest = arg.items           
--                 for key,var in ipairs(arg.items) do 
--                    table.insert(self.tempTag,0)
--                    if #var.ActiveIcon > 1  then     
--                       self['ListView_Activities']:pushBackDefaultItem()
--                       local model = self['ListView_Activities']:getItem(key-1)
--                       model:setVisible(true)
--                       if key == 1 then 
--                          model:getChildByName('Image_big'):setVisible(true)
--                       end    
--                       local function onFinishTable(status,downloadedSize,dst)
--                         if status == "success" then
--                             local tem1 = ccui.ImageView:create(dst)
--                             local a= tem1:getContentSize()
--                             model:getChildByName('Image_bg'):loadTexture(dst,ccui.TextureResType.localType)
--                         end
--                       end
--                       local newName = var.ActiveIcon 
--                       LuaTools.getFileFromUrl({url = var.ActiveIcon ,  destFile = (newName:gsub("/","_")),  onFinishTable = onFinishTable })
--                    end    
--                 end
--                 self:reqActivity(arg.items[1].ActiveType,arg.items[1].ActiveId)   
--             end     
--         end
--         local function fail(arg)
--         end
--         LuaTools.fastRequest(dataTable,succ, fail,false)
--         self['Panel_blackBg']:setVisible(true)
--     end     
--     LuaTools.viewAction1(self['Panel_tottt'],cb())

-- end

-- function UIActivity:webviewAdd()
--     if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) then
--         local webview = ccexp.WebView:create()
--         self['Panel_new']:addChild(webview)
--         webview:setName('newView'..self.lastSelectedIndex)
--         local size = self['Panel_new']:getContentSize()
--         webview:setVisible(false)
--         webview:setScalesPageToFit(true)
--         if  self.tempTag[self.lastSelectedIndex] then  
--             self.tempTag[self.lastSelectedIndex] = 1 
--         end     
--         local temp = 'uid='..self.pData.uid.."&type="..self.TagRequest[self.lastSelectedIndex].ActiveType..
--                 "&id="..self.TagRequest[self.lastSelectedIndex].ActiveId..'&token='..self.pData.token
--         local new = RC4(SHARED_KEY, temp)
--         new = LuaTools.StringToBase64(new)

--         --'http://183.61.183.197:17179/activity/activeViews'..'?p='..new
--         -- 'http://183.61.183.197:17179/test'..'?p='..new
--         new = 'http://183.61.183.197:17179/activity/activeViews'..'?p='..new
--         webview:loadURL(new)--("http://183.61.183.197:17179/activity/activeViews")
--         webview:setContentSize(cc.size(size.width,size.height))
--         webview:reload()
--         webview:setPosition(size.width/2,size.height/2)
--         webview:loadURL(new)--("http://183.61.183.197:17179/activity/activeViews")
--         webview:setContentSize(cc.size(size.width,size.height))
--         webview:reload()
--         webview:setPosition(size.width/2,size.height/2)

--         local function succ()
--              webview:setVisible(true)
--         end  
--         local function fail()
--              self.tool:showTips('活动页面加载失败')
--         end  
--         webview:setOnDidFinishLoading(succ)
--         webview:setOnDidFailLoading(fail)
--     end 
-- end   


-- function UIActivity:selectEvent(event)
--     if self['Panel_new']:getChildByName('newView'..self.lastSelectedIndex) then 
--        self['Panel_new']:getChildByName('newView'..self.lastSelectedIndex):setVisible(false)
--     end    

--     self['ListView_Activities']:getItem(self.lastSelectedIndex-1):getChildByName('Image_big'):setVisible(false)
--     local index = event.target:getCurSelectedIndex()+1
--     local type,id = self.TagRequest[index].ActiveType,self.TagRequest[index].ActiveId
--     self.lastSelectedIndex = index 
--     self['ListView_Activities']:getItem(index-1):getChildByName('Image_big'):setVisible(true)
--     self:reqActivity()  
-- end

-- --获取活动详情
-- function UIActivity:reqActivity()
--     if self['Panel_new']:getChildByName('newView'..self.lastSelectedIndex) then  
--        self['Panel_new']:getChildByName('newView'..self.lastSelectedIndex):setVisible(true)
--     else 
--        self:webviewAdd()  
--     end 
-- end     



return UIActivity
