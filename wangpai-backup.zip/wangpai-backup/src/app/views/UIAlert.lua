local UIAlert = class("UIAlert", cc.load("mvc").ViewBase)

UIAlert.RESOURCE_FILENAME = "UIAlert.csb"
--UIAlert.RESOURCE_PRELOADING = {"main.png"}
--UIAlert.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIAlert.RESOURCE_BINDING = { 

    } 

function UIAlert:onCreate()
    local app = self:getApp()
    self.app = app

end



function UIAlert:setupDialog(title,msg,callback)

  -- msg = tostring(msg)

  if type(msg) ~= "string" then msg = "" end
  self.Text_string:setString(msg)

  if msg and msg ~= '' and msg ~= ' ' then 
     self.Panel_main:setVisible(true)
  else 
     self.app:removeView(self)
  end  
  
  --self.Text_string:setString(msg)  
  -- msg =string.gsub(msg, "^%s*(.-)%s*$", "%1")
  if self.Text_string:getContentSize().width >= 210 then 
     self.Panel_main:setContentSize(cc.size(self.Text_string:getContentSize().width + 80,130))
  end 

  self.Text_string:setPositionX(self.Panel_main:getContentSize().width/2)
  self.Panel_main:runAction( 
     cc.Sequence:create(cc.DelayTime:create(2),cc.FadeOut:create(1),cc.CallFunc:create(function() 
       self.app:removeView(self)
       end
       ))
     )

end

return UIAlert
