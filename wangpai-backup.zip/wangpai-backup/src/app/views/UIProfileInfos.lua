local UIProfileInfos= class("UIProfileInfos", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
UIProfileInfos.RESOURCE_FILENAME = "UIProfileInfos.csb"


UIProfileInfos.RESOURCE_BINDING = { 
	["Button_bindPhone"] = {["ended"] = "onBindPhone"},
    ["Button_divorce"] = {["ended"] = "onDivorce"},
    ["Button_changePhone"] = {["ended"] = "onChangePhone"},
}

--初始化
function UIProfileInfos:onCreate()
    local app = self:getApp()
    self.app = app
    self.config = app:getData('Config')
    self.tool = app:getModel('Tools')
    self.pData = self.app:getData('PlayerData')
    self.account = app:getModel('Account')
    self:setSkipGoBack(true )
    self.userProgressInfos = self['Panel_progressInfos']
    self.userLivingInfos = self['Panel_livingInfos']
    self.userHeadInfos = self['Panel_headInfos']

    self.loverHeadInfos = self['Panel_loverHead']
    self.loverProgressInfos = self['Panel_loverProgress']
    self.loverLivingInfos = self['Panel_loverLiving']

    self.pControl = self['Panel_TouchControl']
    self.txfUserName = self.userProgressInfos:getChildByName('TextField_Name')

    self['Panel_content']:setBackGroundColorOpacity(0)
    self.userProgressInfos:setBackGroundColorOpacity(0)
    self.userLivingInfos:setBackGroundColorOpacity(0)
    self.userHeadInfos:setBackGroundColorOpacity(0)
    self.loverHeadInfos:setBackGroundColorOpacity(0)
    self.loverProgressInfos:setBackGroundColorOpacity(0)
    self.loverLivingInfos:setBackGroundColorOpacity(0)
    

    --self.userName = self.pData.nick
    self.sexType = self.pData.sex
    self:setLoverVisible(false)
    self:initTouchControl()
    self:initUserDataDefault()
end

--初始化点击修改昵称时，点击事件。此事件只要在修改昵称过程中才会有效
function UIProfileInfos:initTouchControl()
  --点击此时间后，执行以下代码
  local function onTouchControl(event)
    if event.name == 'ended' then
      if self.pData.nick ~= self.txfUserName:getString() then
          self:onShowDlgConfirmChange()
      end
      self.pControl:setTouchEnabled(false)
    end
  end
  self.pControl:setTouchEnabled(false)
  self.pControl:onTouch(onTouchControl)
end

function UIProfileInfos:showOutBoundaryItems(_show)

end

function UIProfileInfos:getPanelMain()
  return self['Panel_main']
end

--初始化
function UIProfileInfos:init()
	self:initUserProgressInfos()
    self:initUserLivingInfos()
    self:initUserHeadInfos()
   -- self:initLoverHeadInfos()
    if self.pData.couple == nil or self.pData.couple.uid == nil then
      self:setLoverVisible(false)
    else
        self:setLoverVisible(true)
    	self:initLoverProgressInfos()
    	self:initLoverLivingInfos()
        self:initLoverHeadInfos()
    end

    self:updateUserView()
end

--更新自己的信息
function UIProfileInfos:updateProgressInfos()
   -- self.userProgressInfos:getChildByName('Text_ChipsValue'):setString(self.tool:convertAmountChinese(self.pData.coin))
   -- self.userProgressInfos:getChildByName('Text_DiamondValue'):setString(self.tool:convertAmountChinese(self.pData.gem))
    self.userProgressInfos:getChildByName('Text_CharismaValue'):setString(self.tool:convertAmountChinese(self.pData.charm))
end

--更新按钮的状态
function UIProfileInfos:updateUserView()
    if self.pData.modify_pw == 0 then
        self["Button_bindPhone"]:setVisible(false)
        self["Button_changePhone"]:setVisible(false)  
    else 
        if self.pData.isBindPhone == 1 then
            self["Button_bindPhone"]:setVisible(false)    
            self["Button_changePhone"]:setVisible(true)   
            else
            self["Button_bindPhone"]:setVisible(true)
            self["Button_changePhone"]:setVisible(false)   
        end
    end

    if G_CHANNEL_CONFIG.isSdkLogin or G_CHANNEL_CONFIG.isOurOnlyAutoLogin then
        self["Button_bindPhone"]:setVisible(false)
        self["Button_bindPhone"]:setTouchEnabled(false)
    end
end

--首次进入场次
function UIProfileInfos:initUserDataDefault()
  ---self.userProgressInfos:getChildByName('Text_ChipsValue'):setString("")
  --self.userProgressInfos:getChildByName('Text_DiamondValue'):setString("")
  self.userProgressInfos:getChildByName('Text_CharismaValue'):setString("")
  self.userProgressInfos:getChildByName('TextField_Name'):setString("")
  self.userProgressInfos:getChildByName('Text_level'):setString("")
  self.userProgressInfos:getChildByName('Text_exp'):setString("")
  self.userProgressInfos:getChildByName('LoadingBar_exp'):setPercent(0)
  self.userProgressInfos:getChildByName('Text_fortune'):setString("")
  self.userLivingInfos:getChildByName('Text_comeFrom'):setString("")
  self.userLivingInfos:getChildByName('TextField_Contact'):setString("")
  self.userLivingInfos:getChildByName('TextField_Signature'):setString("")
  self.userHeadInfos:getChildByName('Text_ID'):setString("")
  self.userHeadInfos:getChildByName('Image_border'):setVisible(false)
  self.userHeadInfos:getChildByName('Text_UserVIP'):setVisible(false)
  self.userHeadInfos:getChildByName('Image_vipbg'):setVisible(false)
  self["Button_bindPhone"]:setVisible(false)
  self["Button_changePhone"]:setVisible(false) 
end

--初始化自己进度信息
function UIProfileInfos:initUserProgressInfos()
  local img_sex = self.userProgressInfos:getChildByName('Image_Sex')
	self.txfUserName:setString(self.pData.nick)
	self.txfUserName:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
	--self.userProgressInfos:getChildByName('Text_ChipsValue'):setString(self.tool:convertAmountChinese(self.pData.coin))
	--self.userProgressInfos:getChildByName('Text_DiamondValue'):setString(self.tool:convertAmountChinese(self.pData.gem))
	self.userProgressInfos:getChildByName('Text_CharismaValue'):setString(self.tool:convertAmountChinese(self.pData.charm))
	img_sex:loadTexture(self.config.defaultSexTexture[self.pData.sex+1],ccui.TextureResType.plistType)

    --Level bar
	local lev, expA, expN = LuaTools.expInfos(self.pData.wins + self.pData.faileds, self.config.levelExp,1)
	self.userProgressInfos:getChildByName('Text_level'):setString('Lv.'..lev)
    self.userProgressInfos:getChildByName('Text_exp'):setString(expA..'/'..expN)
    self.userProgressInfos:getChildByName('LoadingBar_exp'):setPercent(expA/expN*100)

    --fortune level
    dump(self.config.fortuneName)
    dump(self.config.fortuneExp)
    local money = self.pData.coin
    local lev, expA, expN = LuaTools.expInfos(money, self.config.fortuneExp,1)
    local fortuneName = self.config.fortuneName[lev]
    self.userProgressInfos:getChildByName('Text_fortune'):setString(fortuneName)
    print("FORTUNE LEVEL: "..lev.."   FORTUNE NAME: "..fortuneName.."   MONEY: "..money)
    --print(LuaTools.convertAmountChinese(100000000))
    
    self:handleTextFieldName(self.txfUserName)
    self:handleTextFieldContact(self.userLivingInfos:getChildByName('TextField_Contact'))
    self:handleTextFieldSignature(self.userLivingInfos:getChildByName('TextField_Signature'))

    --切换性别
    local function onChangeSex(event)
        if event.name == 'began' then
        elseif event.name == 'ended' then
            
            img_sex:loadTexture(self.config.defaultSexTexture[2-self.sexType],ccui.TextureResType.plistType)
            self.sexType = math.abs(-1 + self.sexType)
            if #self.pData.iconPath > 1 then
                else    
                local imgSex = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[self.sexType+1])
                local imgSexRounded = LuaTools.makeSpriteRounded(imgSex, self.sprHead, self.config.maskSprite, false)
                self.sprHead:removeFromParent()
                self.sprHead = imgSexRounded
            end
            
            print('sextype: '..self.sexType)
        end
    end
    img_sex:onTouch(onChangeSex)
    img_sex:setTouchEnabled(true)

end

function UIProfileInfos:compareStrSize(_str, _strModel)
    local val1, val2
    local text =  ccui.Text:create()
    text:setString(_str) 
    val1 = text:getVirtualRendererSize().width
    text:setString(_strModel) 
    val2 = text:getVirtualRendererSize().width
    
    if val1 > val2 then
        print("model: "..val2.."   str: "..val1)
        return false
    end

    return true
end

function UIProfileInfos:cropStringToSize( _str, _strModel)
    local tabStr = LuaTools.UStr2Table(_str)
    local strName = ""
    for i=1, #tabStr do 
        table.remove(tabStr, #tabStr-1)
        print("CORRECT SIZE STR: "..table.concat(tabStr))
        strName = table.concat(tabStr)
        if self:compareStrSize(strName, _strModel) == true then 
            return strName
        end
    end 
end

--昵称输入框安全性处理
function UIProfileInfos:handleTextFieldName(_txf)
    local limitSize = "一二三四五六七八"
    local lastValidStr
    local function onSetTextfied(event)
        local txf = event.target
        local str = txf:getString()
        if event.name == "ATTACH_WITH_IME" then
          self.pControl:setTouchEnabled(true)
        elseif event.name == "DETACH_WITH_IME" then
            
        elseif event.name == "INSERT_TEXT" then
           -- print("INSERT TEXT")
           if self.account:strContainBannedChars(str,{' ', ' '}) == false then
              print("BANNED CHAR!")
              txf:setString(lastValidStr)
              return 
           end
            if self:compareStrSize(txf:getString(), limitSize, true) == false then
               local cropStr = self:cropStringToSize(txf:getString(),limitSize)
                txf:setString(cropStr)
                lastValidStr = cropStr
                return
            end
            lastValidStr = str
        elseif event.name == "DELETE_BACKWARD" then
            --print('DELETE_BACKWARD')
            lastValidStr = str
        end
    end
   _txf:onEvent(onSetTextfied)
end

--联系方式输入框安全性处理
function UIProfileInfos:handleTextFieldContact(_txf)
  local limitSize = "一二三四五六七八九"
    local function onSetTextfied(event)
        local txf = event.target
        if event.name == "ATTACH_WITH_IME" then
        elseif event.name == "DETACH_WITH_IME" then
        elseif event.name == "INSERT_TEXT" then
           -- print("INSERT TEXT")
            if self:compareStrSize(txf:getString(), limitSize, true) == false then
                txf:setString(self:cropStringToSize(txf:getString(), limitSize))
                return
            end
        elseif event.name == "DELETE_BACKWARD" then
        end
    end
   _txf:onEvent(onSetTextfied)
end

--个人签名输入框安全性处理
function UIProfileInfos:handleTextFieldSignature(_txf)
  local limitSize = "一二三四五六七八九十一二三四五六七八九"
    local function onSetTextfied(event)
        local txf = event.target
        if event.name == "ATTACH_WITH_IME" then
        elseif event.name == "DETACH_WITH_IME" then
        elseif event.name == "INSERT_TEXT" then
           -- print("INSERT TEXT")
            if self:compareStrSize(txf:getString(), limitSize, true) == false then
                txf:setString(self:cropStringToSize(txf:getString(),limitSize))
                return
            end
        elseif event.name == "DELETE_BACKWARD" then
        end
    end
   _txf:onEvent(onSetTextfied)
end

--初始化自己的信息
function UIProfileInfos:initUserLivingInfos()
	self.userLivingInfos:getChildByName('Text_comeFrom'):setString(self.pData.area)
	self.userLivingInfos:getChildByName('TextField_Contact'):setString(self.pData.contact)
	self.userLivingInfos:getChildByName('TextField_Signature'):setString(self.pData.userinfo)
end

--更新自己VIP信息
function UIProfileInfos:updateUserVip()
   local img_vip = self.userHeadInfos:getChildByName('Text_UserVIP')
   local img_vipbg = self.userHeadInfos:getChildByName('Image_vipbg')
   if self.pData.vip_level > 0 then
      img_vip:setString("V"..self.pData.vip_level)
      img_vipbg:loadTexture('res_profile/img_vipbg.png',ccui.TextureResType.plistType)
      img_vipbg:setVisible(true)
    else
      img_vip:setVisible(false)
      img_vipbg:setVisible(false)
    end

    if tonumber(self.pData.vipvalid) <=0 then 
       img_vip:setColor(cc.c3b(77,77,77))
       img_vipbg:setColor(cc.c3b(77,77,77))
    end    
end

--更新自己头像信息
function UIProfileInfos:initUserHeadInfos()
	  local img_head = self.userHeadInfos:getChildByName('Image_User')
    local img_border = self.userHeadInfos:getChildByName('Image_border')
    local img_vip = self.userHeadInfos:getChildByName('Text_UserVIP')
    local img_vipbg = self.userHeadInfos:getChildByName('Image_vipbg')
    img_border:setVisible(true)
    img_vip:setVisible(true)
    img_border:setLocalZOrder(2)
    img_vipbg:setLocalZOrder(2)
    img_vip:setLocalZOrder(2)

    self.userHeadInfos:getChildByName('Text_ID'):setString("ID:"..self.pData.uid)
    self:updateUserVip()

     --换头像
    local function onChangeHead(event)
        if event.name == 'began' then
        elseif event.name == 'ended' then
            print('STOP CLICKING MY HEAD !!')
            
            LuaTools.getAvatar(function(tbl)
                if tbl.succ then
                    print("IMAGE PATH: "..tbl.path)
                    --cc.Director:getInstance():getTextureCache():reloadTexture(tbl.path)
                    self:requestChangeAvatar(tbl.path)
                end
            end,self.config.profileHeadwidth,self.config.profileHeadwidth)
        end
    end
    local panel_touchHead = self.userHeadInfos:getChildByName('Panel_TouchUserHead')
    panel_touchHead:onTouch(onChangeHead)
    panel_touchHead:setTouchEnabled(true)

      local newHeadSpr = nil
      self.sprHead = nil
      local newName = self.pData.icon
      if #self.pData.icon > 1  then
          local argTable = {
              url = self.pData.icon,
              destFile = (newName:gsub("/","_")),
              --useCache = false,
              onFinishTable = function(status,downloadedSize,dst)
              if status == 'success' then
                  print('Avartar Found: '..dst)
                  newHeadSpr = cc.Sprite:create(dst)
              else
                  print('获取头像失败1 !')
                  newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[self.pData.sex+1])
              end
              self.sprHead = LuaTools.makeSpriteRounded(newHeadSpr, img_head, self.config.maskSprite, false)
               --self.sprHead:setScale(self.sprHead:getScale()+0.1)
              end
          }
          print('url: '..argTable.url)
          LuaTools.getFileFromUrl(argTable)  
      else
          newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[self.pData.sex+1])
          self.sprHead = LuaTools.makeSpriteRounded(newHeadSpr, img_head, self.config.maskSprite, false)
           --self.sprHead:setScale(self.sprHead:getScale()+0.1)
      end
end

--初始化对象信息
function UIProfileInfos:initLoverProgressInfos()
    dump(self.pData.couple)
    local partner = self.pData.couple
    if partner and partner.totalwins and  partner.totalfails then 
       	self.loverProgressInfos:getChildByName('Text_name'):setString(partner.nick)
       -- self.loverProgressInfos:getChildByName('Text_ChipsValue'):setString(self.tool:convertAmountChinese(tonumber(partner.coin)))
       -- self.loverProgressInfos:getChildByName('Text_DiamondValue'):setString(self.tool:convertAmountChinese(tonumber(partner.gem or 0)))
        self.loverProgressInfos:getChildByName('Text_charm'):setString(self.tool:convertAmountChinese(tonumber(partner.charm or 0)))
        self.loverProgressInfos:getChildByName('Image_Sex'):loadTexture(self.config.defaultSexTexture[tonumber(partner.sex)+1],ccui.TextureResType.plistType)

        local lev, expA, expN = LuaTools.expInfos(partner.totalwins + partner.totalfails, self.config.levelExp,1)
        self.loverProgressInfos:getChildByName('Text_level'):setString('Lv.'..lev)
        --self.loverProgressInfos:getChildByName('Text_exp'):setString(expA..'/'..expN)
        --self.loverProgressInfos:getChildByName('LoadingBar_exp'):setPercent(expA/expN*100)

        local money = tonumber(partner.coin)
        local lev, expA, expN = LuaTools.expInfos(money, self.config.fortuneExp,1)
        local fortuneName = self.config.fortuneName[lev]
        self.loverProgressInfos:getChildByName('Text_fortune'):setString(fortuneName)
    end 
end

--初始化对象信息
function UIProfileInfos:initLoverLivingInfos()
    local partner = self.pData.couple
    self['Text_loversignature']:setString(partner.userinfo)
    self['Text_lovercontact']:setString(partner.contact)
	self['Text_lovercomeFrom']:setString(partner.area)
end

--初始化对象头像信息
function UIProfileInfos:initLoverHeadInfos()
    local partner = self.pData.couple
	local img_head = self.loverHeadInfos:getChildByName('Image_loverHead')
    local img_border = self.loverHeadInfos:getChildByName('Image_border')
    local img_vip = self.loverHeadInfos:getChildByName('Text_loverVIP')
    local img_vipbg = self.loverHeadInfos:getChildByName('Image_vipbg')
    img_border:setLocalZOrder(2)
    img_vipbg:setLocalZOrder(2)
    img_vip:setLocalZOrder(2)

   -- self.loverHeadInfos:getChildByName('Text_ID'):setString("ID:"..self.pData.uid)

   if partner.vip > 0 then
      img_vip:setString("V"..partner.vip)
      img_vipbg:loadTexture('res_profile/img_vipbg.png',ccui.TextureResType.plistType)
    else
      img_vip:setVisible(false)
      img_vipbg:setVisible(false)
    end

    if tonumber(partner.vipvalid) <=0 then 
       img_vip:setColor(cc.c3b(77,77,77))
       img_vipbg:setColor(cc.c3b(77,77,77))
    end    

    local newHeadSpr = nil
    local spr = nil
      local newName = partner.icon
      if #partner.icon > 1  then
          local argTable = {
              url = partner.icon,
              destFile = (newName:gsub("/","_")),
              --useCache = false,
              onFinishTable = function(status,downloadedSize,dst)
              if status == 'success' then
                  print('Avartar Found: '..dst)
                  newHeadSpr = cc.Sprite:create(dst)
              else
                  print('获取头像失败1 !')
                  newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[partner.sex+1])
              end
              spr = LuaTools.makeSpriteRounded(newHeadSpr, img_head,self.config.maskSprite, false)
              --spr:setScale(spr:getScale()+0.1)
              end
          }
          print('url: '..argTable.url)
          LuaTools.getFileFromUrl(argTable)  
      else
          newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[partner.sex+1])
          spr = LuaTools.makeSpriteRounded(newHeadSpr, img_head,self.config.maskSprite, false)
         -- spr:setScale(spr:getScale()+0.1)
      end
end

--是否显示对象界面
function UIProfileInfos:setLoverVisible(_bool)
    self.loverHeadInfos:setVisible(_bool)
    self.loverLivingInfos:setVisible(_bool)
    self.loverProgressInfos:setVisible(_bool)
    self['Image_noLover']:setVisible(not _bool)
end

--绑定电话事件
function UIProfileInfos:onBindPhone()
    
    self.app:addView('UILoginBindPhone',self:getLocalZOrder()+1, 1)
end

--修改电话事件
function UIProfileInfos:onChangePhone()
    
    self.app:addView('UILoginChangePhone',self:getLocalZOrder()+1, 1)
 end

--离婚事件
function UIProfileInfos:onDivorce()
    
    local function onConfirm()
        self:requestDivorce()
    end
    local tips = self.app:addView('UIDialog', self:getLocalZOrder() + 1, nil, true)
    tips:setupDialog('', "确定与'"..self.pData.couple.nick.."'离婚吗？离婚后扣你本人"..self.tool:convertAmountChinese(self.pData.divorceCost).."金币", onConfirm, nil, false)
end

--获取自己信息
function UIProfileInfos:getUserInfos()
    local tabInfos = {}
    tabInfos.name = self.txfUserName:getString()
    tabInfos.contact = self.userLivingInfos:getChildByName('TextField_Contact'):getString()
    tabInfos.signature = self.userLivingInfos:getChildByName('TextField_Signature'):getString()
    tabInfos.sex = self.sexType
    return tabInfos
end

--确定修改昵称提示框
function UIProfileInfos:onShowDlgConfirmChange(cb)
    self.dialogChangename = nil
    self.autoRemove = false
    local function onConfirm()
        --
        --self.app:removeView('UIDialog')
        local function onEnterShop()
            self.dialogNoCoin:removeSelf()
            self.dialogChangename:setVisible(true)
            self.app:addView('UIShopDiamond', self:getLocalZOrder() + 2, function() 
              
              end)
        end
        local function onDontGoShop()
            --self.dialogNoCoin:removeSelf()
            self.txfUserName:setString(self.pData.nick)
            self.dialogChangename:setVisible(true)
        end
 
        if self.pData.nickChanged == 1 and tonumber(self.pData.gem) < self.config.changeNickCost then 
            self.dialogChangename:setVisible(false)
            self.dialogNoCoin = self.app:addView({
                uiName = 'UIDialog',
                uiInstanceName = 'UIDialogNoCoin'}, self:getLocalZOrder() + 1, nil, false)
            self.dialogNoCoin:setupDialog( '元宝不足', '您的元宝数量不足，是否进入商城购买？',onEnterShop, onDontGoShop, false)
            return 
        end   
        self:requestModifyNick()
        
    end
    local function onCancel()
        self.txfUserName:setString(self.pData.nick)
        if cb then
            cb()
        end
        --self.dialogChangename:removeSelf()
    end

    local text

    print(self.pData.nickChanged)
    if self.pData.nickChanged == 0 then

        text = '第一次修改昵称是免费的。'
        self.autoRemove = true
    else
        text = '是否花费 '..self.config.changeNickCost..' 元宝修改昵称 ?'
    end
    self.dialogChangename = self.app:addView({
    uiName = 'UIDialog',
    uiInstanceName = 'UIDialogChangeName'}, self:getLocalZOrder() + 1, nil, self.autoRemove)
    self.dialogChangename:setupDialog('修改昵称', text, onConfirm, onCancel, false)
--    self.app:callMethod('UIDialog','setupDialog', '修改昵称', text, onConfirm, onCancel)
end

--请求修改昵称
function UIProfileInfos:requestModifyNick()
    local dataTable =     {
        ['uid']   = self.pData.uid,
        ['token']  = self.pData.token,
        ['nick']      = self.txfUserName:getString(),
        ['cmd']       = HttpHandler.CMDTABLE.MODIFY_NICK,
    }

    local function succ(arg)
        self.pData.nickChanged = 1
        self.pData.nick = arg.nick
        self.pData.gem = tonumber(arg.gem) or 0
        self.tool:showTips("修改昵称成功！")
        if self.autoRemove == false then
          self.dialogChangename:removeSelf()
        end
        -- if self.dialogChangename and not tolua.isnull(self.dialogChangename) then
        --     self.dialogChangename:removeSelf()
        -- end
       -- self.userProgressInfos:getChildByName('Text_DiamondValue'):setString(self.tool:convertAmountChinese(arg.gem))
        self.app:callMethod('UIMainTop','updatePlayerInfos')
        self.app:callMethod('UIProfileMain', 'updateUserName')
        self.txfUserName:setString(arg.nick)
    end
    local function fail(arg)
        self.tool:showTips(arg.msg)
        --self.app:removeView('UIProfile')
    end
    self.tool:fastRequest(dataTable,succ,fail)
end

--请求修改用户信息
function UIProfileInfos:requestModifyUserInfos(cb)
    local txf_contact = self.userLivingInfos:getChildByName('TextField_Contact')
    local txf_signature = self.userLivingInfos:getChildByName('TextField_Signature')
    local dataTable =     {
        ['uid']   = self.pData.uid,
        ['token']  = self.pData.token, 
        ['nick']      = self.txfUserName:getString(),
        ['sex']    = self.sexType,
        ['userinfo']   = txf_signature:getString(),
        ['contact']        = txf_contact:getString(),
        ['cmd']       = HttpHandler.CMDTABLE.MODIFY_INFO,
    }

    local function succ(arg)
        self.pData.userinfo = txf_signature:getString()
        self.pData.contact = txf_contact:getString()
        self.pData.sex = self.sexType
        self.tool:showAlert(arg.msg)
        self.app:callMethod('UIMain', 'updateHead', self.pData.iconPath)
        if cb then
            cb()
        end
    end
    local function fail(arg)
        self.tool:showTips(arg.msg)
    end
    self.tool:fastRequest(dataTable,succ,fail)
end

--请求修改头像
function UIProfileInfos:requestChangeAvatar(icon)
    --printWarning

    local data = LuaTools.FileToBase64(icon)

    local function onSucc(arg)
        --self['Image_User']:reloadTexture(icon)
        if arg.msg then
            self.tool:showAlert(arg.msg)
        end
        --print('New avatar: '..icon)
        --self.pData.icon = icon
        --self.pData.iconPath = icon
        --UserCache.setUserDataByKey('icon', icon)
        --print('Setting new Texture: '..icon)
        
    end
    local function fail(arg)
        if arg.msg then
            self.tool:showAlert(arg.msg)
        end
    end
    local dataTable =     {
        ['uid']   = self.pData.uid,
        ['token']  = self.pData.token,
        ['icon']      = data,
        ['cmd']       = HttpHandler.CMDTABLE.MODIFY_ICON,
    }
    self.tool:fastRequest(dataTable, onSucc, fail)
end

--请求离婚
function UIProfileInfos:requestDivorce()
    local dataTable =     {
        ['uid']   = self.pData.uid,
        ['token']  = self.pData.token,
        ['couple']  = self.pData.couple.uid or '',
        ['cmd']  = HttpHandler.CMDTABLE.DIVORCE,
    }

    local function succ(arg) 
        if arg.msg then
            self.tool:showAlert(arg.msg)
        end
        self.pData.coin = arg.coin or ''
        self:updateProgressInfos()
        self:setLoverVisible(false)
    end 
    local function fail(arg)
        if arg.msg then
            self.tool:showAlert(arg.msg)
        end  
    end
    self.tool:fastRequest(dataTable, succ, fail)
end

return UIProfileInfos