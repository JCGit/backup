local UIProfileGames= class("UIProfileGames", cc.load("mvc").ViewBase)
UIProfileGames.RESOURCE_FILENAME = "UIProfileGames.csb"
require "cocos.cocos2d.json"

UIProfileGames.RESOURCE_BINDING = { 
        ["ListView_left"]     = {["ON_SELECTED_ITEM_END"] = "selectEvent"},   
}

--初始化
function UIProfileGames:onCreate()
    local app = self:getApp()
    self.app = app
    self.config = app:getData('Config')
    self.tool = app:getModel('Tools')
    self.pData = self.app:getData('PlayerData')
    --self.indexViewSel = 0
    --self:setSkipGoBack(true )
    self.lastSelectedIndex = 1 
    cc.SpriteFrameCache:getInstance():addSpriteFrames("newcard.plist")
    self:setSkipGoBack(true )
    for i=1,5 do
        self['Panel_model1']:getChildByName('Panel_right'):getChildByName('Image_card'..i):setVisible(false)
    end
    -- self['ListView_left']:setScrollBarEnabled(false)
    --self['Panel_content']:setBackGroundColorOpacity(0)
    self.infoSkill = {['王牌斗地主']=self.pData.infoDD,['全民炸翻天']=self.pData.infoDDZ,['王牌斗牛']= self.pData.infoDN,['名人德州']=self.pData.infoPOKER,
    ['王牌跑得快']=self.pData.infoPDK,['欢乐赢三张']=self.pData.infoZJH}
    self:initButtons()
    self:swithchPage(0,1)
 --    self:showView(1)
end

function UIProfileGames:selectEvent(event)
    local index = event.target:getCurSelectedIndex()+1
    self:swithchPage(self.lastSelectedIndex,index)  
end

function UIProfileGames:swithchPage(from,to)
    if not to or to == 0 then return end 
    local function getModelType(tex) 
        local num 
        if tex == '欢乐赢三张' or tex == '名人德州' or tex =='王牌斗牛' then 
            num = 1 
        else 
            num = 2 
        end 
        return num      
    end     

    if from and from ~= 0 then 
       self['ListView_left']:getItem(from-1):loadTextures('res_profile/btn_label1.png','res_profile/btn_label1.png','res_profile/btn_label1.png',ccui.TextureResType.plistType)
       self['ListView_left']:getItem(from-1):setTitleColor(cc.c3b(255,233,178))
       local text1 = self['ListView_left']:getItem(from-1):getTitleText() 
       self['Panel_model'..(getModelType(text1))]:setVisible(false)
    end 

    self['ListView_left']:getItem(to-1):loadTextures('res_profile/btn_label.png','res_profile/btn_label.png','res_profile/btn_label.png',ccui.TextureResType.plistType)
    self.lastSelectedIndex = to 
    self['ListView_left']:getItem(to-1):setTitleColor(cc.c3b(255,255,255))
    if  to then 
        local text = self['ListView_left']:getItem(to-1):getTitleText() 
        local tag  = getModelType(text)
        self['Panel_model'..tag]:setVisible(true)  
        local infos = self.infoSkill[text]
        local lev, expA, expN = LuaTools.expInfos(infos.wins + infos.fails, self.config.levelExp,1)
        local lev1, expA1, expN1 = LuaTools.expInfos(infos.wins, self.config.levelExp,2)
        local totalTime ,winTime ,rate = (infos.wins + infos.fails),infos.wins, 0
        if (infos.wins + infos.fails) > 0 then 
            rate = math.ceil(infos.wins/(infos.wins + infos.fails)*100)
        end     

        self['Panel_model'..tag]:getChildByName('Panel_left'):getChildByName('Text_gameLevel'):setString(lev)
        self['Panel_model'..tag]:getChildByName('Panel_left'):getChildByName('Text_gameSkill'):setString(lev1)
        self['Panel_model'..tag]:getChildByName('Panel_bot'):getChildByName('Text_gameplayed'):setString(totalTime)
        self['Panel_model'..tag]:getChildByName('Panel_bot'):getChildByName('Text_wins'):setString(winTime)
        self['Panel_model'..tag]:getChildByName('Panel_bot'):getChildByName('Text_winPercent'):setString(rate..'%') 
        if tag == 1 then 
            local cardNum = text=='欢乐赢三张' and 3 or 5 
            self:showcard(cardNum, infos.besthand) 
        else 
            self['Panel_model'..tag]:getChildByName('Panel_left'):getChildByName('Text_gameRaise'):setString((infos.mx_ddz or infos.mx_dd or infos.mx_pdk or 0)..'倍')
            self['Panel_model'..tag]:getChildByName('Panel_left'):getChildByName('Text_gameChips'):setString(infos.mc_ddz or infos.mc_dd or infos.mc_pdk or 0)
        end     
    end    
end 

function UIProfileGames:showOutBoundaryItems(_show)
    --添加在外部需要隐藏的UI
end

function UIProfileGames:getPanelMain()
  return self['Panel_main']
end

--初始化游戏类型按钮
function UIProfileGames:initButtons()
    self['ListView_left']:removeAllChildren()
    self['ListView_left']:setItemModel(self['Button_modelLeft']) 
    local temp_keyWord = {['dd']='王牌斗地主',['ddz']='全民炸翻天',['dn']= '王牌斗牛',
                          ['pdk']='王牌跑得快',['zjh']='欢乐赢三张'} 
    for key,var in pairs(self.pData.gameFilter) do 
        if var == 1 and key ~= 'wrdn'  and key~='match' then 
            self['ListView_left']:pushBackDefaultItem() 
            local model = self['ListView_left']:getItem(#(self['ListView_left']:getItems())-1)
            model:setVisible(true)
            model:setTitleText(temp_keyWord[key])
        end 
    end                        
end


--显示最佳手牌
function UIProfileGames:showcard( _count, _tablHand )
    self['Panel_model1']:getChildByName('Panel_right'):getChildByName('Image_card1'):setVisible(false)
    self['Panel_model1']:getChildByName('Panel_right'):getChildByName('Image_card5'):setVisible(false)

    if _tablHand and _tablHand ~= false and _tablHand ~= "" then 
        _tablHand= json.decode(_tablHand)
        for i=1,_count do
            local card 
            if _count == 3 then 
                card = self['Panel_model1']:getChildByName('Panel_right'):getChildByName('Image_card'..i+1)
            else 
                card = self['Panel_model1']:getChildByName('Panel_right'):getChildByName('Image_card'..i)
            end     
            if next(_tablHand)then 
                card:setVisible(true)
                local path = Cardutl.getPathForCard(_tablHand[i], nil, nil, 'Douniu')
                card:loadTexture(path,ccui.TextureResType.plistType)
            end
        end
    else
        for i=1,5 do
            self['Panel_model1']:getChildByName('Panel_right'):getChildByName('Image_card'..i):setVisible(false)
        end
    end
end

return UIProfileGames