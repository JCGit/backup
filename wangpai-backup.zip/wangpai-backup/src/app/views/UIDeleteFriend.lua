local UIDeleteFriend = class("UIDeleteFriend", cc.load("mvc").ViewBase)

UIDeleteFriend.RESOURCE_FILENAME = "UIDialog.csb"
--UIDeleteFriend.RESOURCE_PRELOADING = {"main.png"}
--UIDeleteFriend.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIDeleteFriend.RESOURCE_BINDING = {
    ["Button_cancel"]  = {["ended"] = "cancel"},
    ["Button_confirm"] = {["ended"] = "confirm"},

    }


function UIDeleteFriend:onCreate()
    local app = self:getApp()
    self.app = app
    self['Text_string']:setString('确认要删除该好友？')
    self['Image_bg1']:setVisible(false)
    self['Image_bg2']:setVisible(true)
    
end


function UIDeleteFriend:cancel()
    self.app:removeView('UIDeleteFriend')

end 

function UIDeleteFriend:confirm()

end 


return UIDeleteFriend
