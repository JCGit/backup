local UIProfileMain = class("UIProfileMain", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
UIProfileMain.RESOURCE_FILENAME = "UIProfileMain.csb"
require('cocos.cocos2d.json')
--UIShop.RESOURCE_PRELOADING = {"shop.png"}
--UIShop.RESOURCE_LOADING  = {    ["res/background/mohuBg.png"] = {names = {"Image_bgAll"}}}
UIProfileMain.RESOURCE_BINDING = {
    ["Button_Close"] = {["ended"] = "onClose"},

    --View Information binding
}

--初始化
function UIProfileMain:onCreate()
    local app = self:getApp()
    self.app = app
    self.config = app:getData('Config')
    self.tool = app:getModel('Tools')
    self.pData = self.app:getData('PlayerData')

    self.panelMain = self['Panel_main']
    self.panelCenter = self['Panel_Center']
    self.panelMain:setVisible(false)
    self.subviews = {
        --1.view name     2.objet
        {"UIProfileInfos", nil},
        {"UIProfileGames", nil},
        {"UIProfileBag", nil},
        {"UIProfileVip", nil},
    }
    self.objetViewSel = nil
    self.indexViewSelected = 0
    self.userInfos = {}

    self:initUIViews()
end

--打开商场的时候需要执行的动作
function UIProfileMain:transitionViewAction(_action)
   self:runAction(_action:clone())
   self.objetViewSel:runAction(_action:clone())
end

--退出此界面回调
function UIProfileMain:onExit()
    -- body
    for i,view in ipairs(self.subviews) do
        local object = view[2]
        if object then
            G_BASEAPP:removeView(object)  
        end
    end
end

--更新用户昵称
function UIProfileMain:updateUserName()
    self.userInfos.name = self.pData.nick
end

--检测用户昵称是否有了变化
function UIProfileMain:checkNameChanged()
    local tabInfos = self.subviews[1][2]:getUserInfos()
    -- dump(tabInfos)
    -- dump(self.userInfos)
    if tabInfos == nil then return false end
    if tabInfos.name ~= self.userInfos.name then
        return true
    end
    return false
end

--检测用户信息是否有了变化
function UIProfileMain:checkInfosChanged()
    local tabInfos = self.subviews[1][2]:getUserInfos()
    --dump(tabInfos)
    --dump(self.userInfos)
    if tabInfos == nil then return false end
    if tabInfos.contact ~= self.userInfos.contact or
        tabInfos.signature ~= self.userInfos.signature or
         tabInfos.sex ~= self.userInfos.sex then
        return true
    end
    return false
end

--关闭个人信息事件
function UIProfileMain:onClose() 
    local function checkInfos()
        if self:checkInfosChanged() == true then
            self.subviews[1][2]:requestModifyUserInfos(function() 
                self:closeView()
                end)
        else
            self:closeView()
        end
    end
    if self:checkNameChanged() == true then
        self.subviews[1][2]:onShowDlgConfirmChange(checkInfos)
    else
        checkInfos()
    end
end

--关闭处理
function UIProfileMain:closeView()
    if self.objetViewSel and self.objetViewSel.removeSelf then 
        self.objetViewSel:showOutBoundaryItems(false)
        LuaTools.viewAction1Over(self.objetViewSel:getPanelMain(),self.subviews[self.indexViewSelected][1])
    end
    LuaTools.viewAction1Over(self['Panel_main'],'UIProfileMain')
end

--切换按钮显示界面
function UIProfileMain:showView(index, _show)
    if index < 1 or index > #self.subviews then return end
    
    if self.indexViewSelected == 0 then 
        self.objetViewSel = self.app:addView(self.subviews[index][1],205)
        self.subviews[index][2] = self.objetViewSel
    else
        local oldpanel = self['Panel_Type_'..self.indexViewSelected]
        oldpanel:getChildByName('Text_title'):setColor(self.config.ColorTextUnselect)
        oldpanel:getChildByName('Image_blur'):setVisible(false)
        
        self.objetViewSel:setVisible(false)
        if self.subviews[index][2] == nil then 
            self.objetViewSel = self.app:addView(self.subviews[index][1],205)
            self.subviews[index][2] = self.objetViewSel
        else
            self.objetViewSel = self.subviews[index][2]
        end
    end
    local newpanel = self['Panel_Type_'..index]
    newpanel:getChildByName('Text_title'):setColor(self.config.ColorTextSelect)
    newpanel:getChildByName('Image_blur'):setVisible(true)
    newpanel:setVisible(true)
    if _show then 
        self.objetViewSel:setVisible(_show)
    else
        self.objetViewSel:setVisible(true)
    end
    
    self.indexViewSelected = index
end

--初始化界面
function UIProfileMain:initUIViews() 
    local function onSwitchView(event)
        if event.name == 'began' then
            local tag = event.target:getTag()
            if tag ==  self.indexViewSelected  then
                return
            end
            self:showView(tag)
            for i, var in pairs(self.subviews) do
                --self.tool:freezeWidget(self['Panel_Type_'..i], 0.3)
            end
        end
    end
    
    for key,var in pairs(self.subviews) do
        local panel = self['Panel_Type_'..key]
        panel:setTag(key)
        panel:onTouch(onSwitchView)
        panel:getChildByName('Image_blur'):setVisible(false)
        panel:getChildByName('Text_title'):setColor(self.config.ColorTextUnselect)
    end

    self:showView(1, false)

     LuaTools.enterActionScaledWithMask(self['Panel_main'],function() self:requestGetInfos() end)
     LuaTools.viewAction1(self.objetViewSel:getPanelMain())
    
    self.panelMain:setVisible(true)
    self.objetViewSel:setVisible(true)
end

--请求获取用户数据
function UIProfileMain:requestGetInfos()
    local dataTable =     {
        ['uid']   = self.pData.uid,
        ['token']  = self.pData.token,
        ['tuid']      = self.pData.uid,
        ['cmd']       = HttpHandler.CMDTABLE.GET_USERINFOS,
    }
    local function succ(arg)
        self.pData.nick = arg.nick  or ""
        self.pData.uid = arg.uid or ""
        self.pData.coin = tonumber(arg.coin) or 0
        self.pData.gem = tonumber(arg.gem) or 0
        self.pData.charm = tonumber(arg.charm) or 0
        self.pData.level = arg.level or 0
        self.pData.sex = arg.sex or 0
        self.pData.contact = arg.contact or ""
        self.pData.area = arg.area or ''
        self.pData.wins = arg.totalwins or 0
        self.pData.faileds = arg.totalfails or 0
        self.pData.accu = tonumber(arg.accu) or 0
        self.pData.telfee = tonumber(arg.telfee) or 0
        self.pData.icon = arg.icon or ""
        self.pData.debut = arg.createtime or ""
        self.pData.vip_time = arg.viptime or ""
        self.pData.vip_type = arg.vt or 0
        self.pData.vip_level = arg.vip or 0
        self.pData.vip_day = arg.vipday or ""
        self.pData.vipvalid =  arg.vipvalid  or 0
        self.pData.clan = arg.clan or ""
        self.pData.userinfo = arg.userinfo or ''
        self.pData.couple = arg.partner or {}
        self.pData.infoDDZ = arg.gameddz or {}
        self.pData.infoDN = arg.gamedn or {}
        self.pData.infoZJH = arg.gamezjh or {}
        self.pData.infoPOKER = arg.gamedz or {}
        self.pData.infoPDK = arg.gamepdk or {}
        self.pData.infoSJ = arg.gamesj or {}
        self.pData.infoDD = arg.gamedd or {}

        
        if arg.gift then 
            for k, v in pairs(arg.gift) do
                self.pData.gift[tonumber(k)] = v  or 0
            end
        else
            for k = 1, #self.pData.gift do
                self.pData.gift[k] = 0
            end
        end 
        --dump(self.pData.gift)
        self.pData.prop[1] = arg.prop['4'] or self.pData.prop[1] 
        self.pData.prop[2] = arg.prop['7'] or self.pData.prop[1] 
        self.pData.prop[3] = arg.prop['1'] or self.pData.prop[1] 
        --dump(self.pData.prop)
       -- dump(arg)

        self.userInfos.name = self.pData.nick
        self.userInfos.contact = self.pData.contact
        self.userInfos.signature = self.pData.userinfo
        self.userInfos.sex = self.pData.sex

        --self:initUIViews()
        self.objetViewSel:init()
    end
    local function fail()
        self:closeView()
    end
    self.tool:fastRequest(dataTable,succ,fail)
end

return UIProfileMain