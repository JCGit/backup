local UIProfileVip= class("UIProfileVip", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
UIProfileVip.RESOURCE_FILENAME = "UIProfileVip.csb"


UIProfileVip.RESOURCE_BINDING = { 
	["Button_openUrlVip"] = {["ended"] = "onOpenVipUrl"},
	["Button_becomeVip"] = {["ended"] = "onBecomeVip"},
    ["Button_become"] = {["ended"] = "onBecomeVip"},
    ["Button_left"] = {["ended"] = "LeftChange"},
    ["Button_right"] = {["ended"] = "RightChange"},

}


function UIProfileVip:onCreate()
    local app = self:getApp()
    self.app = app
    self.config = app:getData('Config')
    self.tool = app:getModel('Tools')
    self.pData = self.app:getData('PlayerData')
    self:setSkipGoBack(true )
    self['Panel_content']:setBackGroundColorOpacity(0)

    self:initUI()
    
end



function UIProfileVip:getPanelMain()
  return self['Panel_main']
end

--初始化UI
function UIProfileVip:initUI()
    self:updateVipView()        

    self['Button_become']:setVisible(self.pData.vip_level <1)
    self['Panel_vipLevel']:setVisible(self.pData.vip_level  > 0)
    if self.pData.vip_level  > 0 then 
       self:changeVipInfo(self.pData.vip_level)
       self.nowTag = self.pData.vip_level     
    end     
end

function UIProfileVip:LeftChange() 
    if self.nowTag >= 1 then 
        self.nowTag = self.nowTag -1 
        self['Button_left']:setVisible(not (self.nowTag < 2))    
        self:changeVipInfo(self.nowTag)       
        self['Button_right']:setVisible(true)
    end 
end 


function UIProfileVip:RightChange() 
    if self.nowTag < 20 then 
        self.nowTag = self.nowTag + 1 
        self['Button_right']:setVisible(self.nowTag < 20)    
        self:changeVipInfo(self.nowTag)
        self['Button_left']:setVisible(true)    
    end 
end     

function UIProfileVip:changeVipInfo(vip)
   if vip < 1 then return end 
   self['Text_vipPLevel']:setString('VIP'..vip)
   self['Text_vipPReward']:setString('('..LuaTools.convertAmountChinese(self.config.vipRights[vip][3])..')')
   local str = (self.config.vipRights[vip][5] == 0 and '(无限制)' or 
  ('('..LuaTools.convertAmountChinese(self.config.vipRights[vip][5])..')')  )
   self['Text_vipPBank']:setString(str)
   self['Text_vipPFriend']:setString('('..self.config.vipRights[vip][6]..')')
   self['Text_vipPGroth']:setString('('..self.config.vipRights[vip][2]..')')
   if vip  < 10 then 
       self['Text_vipPWordColor']:setColor(cc.c3b(127,127,127)) 
   else 
       self['Text_vipPWordColor']:setColor(cc.c3b(255,255,255))     
   end 
end     


--更新箱子个数
function UIProfileVip:updateChestView()
    local btChest = self['Button_openChest']
    if self.pData.bag == 0 then 
        btChest:setEnabled(false)
    else
        btChest:setEnabled(true)
    end
    self['Text_chestCount']:setString(self.pData.bag)
end


--更新VIP UI
function UIProfileVip:updateVipView()
    --VIP 经验条
    local expVip = {}
    for k = 1, #self.config.vipRights do
        expVip[k] = self.config.vipRights[k][2]
    end

    --dump(expVip)
    if self.pData.vip_level == 0 then
        self['LoadingBar_vipExp']:setPercent(0)
        self['Text_vipExp']:setString('0/'..self.config.vipRights[1][2])
        self['Button_becomeVip']:loadTextureNormal("res_profile/btn_becomevip.png", ccui.TextureResType.plistType)
        self['Button_becomeVip']:loadTexturePressed("res_profile/btn_becomevip.png", ccui.TextureResType.plistType)
        self['Text_labelExpire']:setVisible(false)
        self['Text_VipExpired']:setString("")
    else
        local lev, expA, expN = LuaTools.expInfos(self.pData.vip_day, expVip,1)
        self['Text_vipExp']:setString(expA..'/'..expN)
        self['LoadingBar_vipExp']:setPercent(expA/expN*100)
        self['Button_becomeVip']:loadTextureNormal("res_profile/btn_upgradeVip.png", ccui.TextureResType.plistType)
        self['Button_becomeVip']:loadTexturePressed("res_profile/btn_upgradeVip.png", ccui.TextureResType.plistType)
        self['Text_VipExpired']:setString(self.pData.vip_time)
        if tonumber(self.pData.vipvalid) <= 0 then 
            self['Text_labelExpire']:setString("已到期:")
        else
            self['Text_labelExpire']:setString("到期:")
        end
        self['Text_labelExpire']:setVisible(true)
    end

    --self['Text_VipLevel']:setString('LV: '..self.pData.vip_level)
    if self.pData.vip_level > 0 then
        self['Text_viplevel']:setString("V"..self.pData.vip_level)
        self['Image_vipbg']:loadTexture('res_profile/img_vipbg.png',ccui.TextureResType.plistType)
    else
        self['Text_viplevel']:setVisible(false)
        self['Image_vipbg']:loadTexture('res_profile/img_vip0.png',ccui.TextureResType.plistType)
    end

    if tonumber(self.pData.vipvalid) <=0 then 
       self['Text_viplevel']:setColor(cc.c3b(77,77,77))
       self['Image_vipbg']:setColor(cc.c3b(77,77,77))
    end    

end

function UIProfileVip:showOutBoundaryItems(tag)

end     

--打开VIP特权网页
function UIProfileVip:onOpenVipUrl()
    
	LuaTools.openWebURL("http://ddz.217play.com:17179/vip_guide/vip_guide")
end

--充值VIP
function UIProfileVip:onBecomeVip()
    
	self.app:addView('UIShop',220, 3,'profile')
end

--打开箱子
function UIProfileVip:onOpenChest()
    
	self:requestOpenChest()
end


--请求打开宝箱
function UIProfileVip:requestOpenChest()
    local function onSucc(arg)
        self.tool:showTips(arg.msg)

        if arg.type == "coin" then
            self.pData.coin = self.pData.coin + arg.value
        elseif arg.type == "gem" then
            self.pData.gem = self.pData.gem + arg.value
        elseif arg.type == "prop" then
            local i = 0
            if arg.value == 4 then
                i = 1
                elseif arg.value == 7 then
                i = 2
            end
            self.pData.prop[i] = self.pData.prop[i] +1 
        elseif arg.type == "charge" then
            
        elseif arg.type == "vip" then

        elseif arg.type == "other" then

        end
        self.pData.bag = arg.bag
        self['Text_chestCount']:setString(self.pData.bag)
        self.app:callMethod('UIProfileInfos', 'updateProgressInfos')
        self:updateChestView()
    end
    local dataTable =     {
        ['uid']   = self.pData.uid,
        ['token']  = self.pData.token,
        ['cmd']       = HttpHandler.CMDTABLE.OPEN_CHEST,
    }
    local function fail(arg)
        if arg.msg then
            self.tool:showAlert(arg.msg)
        end
    end
    self.tool:fastRequest(dataTable, onSucc, fail)
end

return UIProfileVip