local UIMail = class("UIMail", cc.load("mvc").ViewBase)

UIMail.RESOURCE_FILENAME = "UIMail.csb"
--UIMail.RESOURCE_PRELOADING = {"main.png"}
--UIMail.RESOURCE_LOADING  = {["res/background/mohuBg.png"] = {names = {"Image_bgAll"}} }

UIMail.RESOURCE_BINDING = {
    ["Button_Close"] = {["ended"] = "onClose"},
    ["Button_DeleteMail"] = {["ended"] = "onDeleteMail"},
    ["ListView_top"]       = {["ON_SELECTED_ITEM_END"] = "selectEvent"},   

    }
require "cocos.cocos2d.json"
local HttpHandler = require("app.network.HttpHandler")
function UIMail:onCreate()
    local app = self:getApp()
    self.app = app
    self.pData = app:getData('PlayerData')
    self.tool = app:getModel('Tools')
    self.config = app:getData('Config')

    self.lastSelectedIndex  = 1 
    self.indexPage = {1,1,1,1} 
    self.allData = {0,0,0,0}
    self.totalMail = {0,0,0,0}
    self.listViewMails = self['ListView_mails']
    self.sx, self.sy = app:getModel('Tools'):getUIScale()
    for  key =1,4 do 
      self['Button_top'..key]:setPressedActionEnabled(false)
    end   
    self.tool = app:getModel('Tools')
    self.mailTypeSel = 1 
    self.mailIndexSel = -1     
    self.gotFullTable = {false,false,false,false}
    self["ListView_top"]:setScrollBarEnabled(false)
    self:showOutBoundaryItems(false)
    local function cb()
        self:swithchPage(0,1)
        self:expendPageForView()
        self['Panel_Item_2']:setScale(1,1)
    end 
    self['Panel_Item_2']:setScale(0)

    LuaTools.enterActionScaledWithMask(self['Panel_Layer'],cb)

end

function UIMail:showOutBoundaryItems(_show)
  self['Panel_Item_2']:setVisible(_show)
end
function UIMail:selectEvent(event)
    LuaTools.playBtSound()
    local index = event.target:getCurSelectedIndex()+1
    self:swithchPage(self.lastSelectedIndex,index)  
end  

function UIMail:swithchPage(from,to)
    if not to or to== 0 then return end 
    local butTab  = {self['Button_top1'],self['Button_top2'],self['Button_top3'],self['Button_top4']} 
    local image1 = {'res_profile/btn_head_z1.png','res_profile/btn_head_zhong1.png','res_profile/btn_head_zhong1.png','res_profile/btn_head_y1.png'}
    local image2 = {'res_profile/btn_head_z.png','res_profile/btn_head_zhong.png','res_profile/btn_head_zhong.png','res_profile/btn_head_y.png'}
    if from and from ~= 0 then 
       --butTab[from]:setOpacity(0)
       butTab[from]:loadTextures(image2[from],image2[from],image2[from],ccui.TextureResType.plistType)
       butTab[from]:setTitleColor(cc.c3b(172,147,128))
    end 
    butTab[to]:loadTextures(image1[to],image1[to],image1[to],ccui.TextureResType.plistType)
    butTab[to]:setTitleColor(cc.c3b(255,255,255))
    --textTab[to]:setColor(cc.c3b(92,229,254))

    self.lastSelectedIndex = to 
    if from ~= to then 
       --self:updateList(self.allData[to])
       self:requestMail(to,1)
       self.pData.newMailCount = self.pData.newMailCount - self.totalMail[to]
       self.totalMail[to]   = 0 
    end    
end  

function UIMail:SetRedPoint(_type,tag) 
    if not tag then  tag = true  end 
    self['Image_red'.._type]:setVisible(tag)
    self.allData[_type] = 0 
end   

function UIMail:requestMail(_type,page,tag)
      local function  callback()  
          local paTable ={
                 ['uid']   = tonumber(self.pData.uid),
                 ['token'] = self.pData.token,
                 ['cmd']   = HttpHandler.CMDTABLE.MAIL_GET,
                 ['mtype'] = _type,
                 ['page']  = page,  } 
          local function succ(arg)      
              self.totalMail[_type] = arg.count  
              self.pData.newMailCount = 0 
              for key,var in pairs(arg.unread) do 
                  self.pData.newMailCount = self.pData.newMailCount + tonumber(var)
                  self['Image_red'..key]:setVisible(tonumber(var) ~= 0)
                  self.totalMail[_type] = tonumber(var)
              end  
              self.allData[_type] = arg.list
              self:updateList(arg.list)
          end      
          self.tool:fastRequest(paTable,succ) 
      end 
      if  tag == 1 then  
          callback() 
          return  
      end 
      if type(self.allData[_type]) ~= 'table' then 
         callback() 
      else 
         self:updateList(self.allData[_type])
      end   
          
end 

function UIMail:updateList(list) 
     self.listViewMails:removeAllItems()
   if type(list) ~= 'table'  or #list == 0 then 
      self:onShowNoMailImg(true)
      return 
   end 
   for key,var in pairs(list)  do  
       if not var.isDeleted then 
          self:appendSingleCell(var,key) 
       end  
   end  
   self:onShowNoMailImg(false)
end 

function UIMail:onDeleteMail()
    
    local function collectData()
        local ret = {}
           for i, var in pairs(self.listViewMails:getChildren()) do
            if var:getChildByName('CheckBox_select'):isSelected() then
                local mid = var:getTag()
                for j,v in pairs(self.allData[self.lastSelectedIndex]) do 
                    if tonumber(v.mid) == tonumber(mid) then
                        table.insert(ret,mid)
                        break
                    end
                end  
            end
        end 
        return ret
    end
    self.app:addView('UIDialog', 200)
    self.app:callMethod('UIDialog','setupDialog', '', '确定要删除？', 
    function()  
        local paTable =     {
               ['uid']   = tonumber(self.pData .uid),
               ['token'] = self.pData.token,
               ['cmd']   = HttpHandler.CMDTABLE.MAIL_DEL,
               ['mtype'] = self.lastSelectedIndex,
               ['mids']  = json.encode(collectData())
           } 
        local function succ(arg)   
         self:requestMail(self.lastSelectedIndex,1,1)
         self.app:addView('UIAlert',1000)
         :setupDialog('Infomation',arg.msg)
        end 

        local function fail(arg)    
         self.app:addView('UIAlert',1000)
         :setupDialog('Infomation',arg.msg)
        end 
        self.tool:fastRequest(paTable,succ,fail) 
    end) 
end

function UIMail:onShowNoMailImg(bShow)
    self['Image_noEmail']:setVisible(bShow)
    self['Button_DeleteMail']:setVisible(not bShow)
end

function UIMail:onClose()
    
    G_BASEAPP:callMethod('UIMainBottom','updateMailDot')
    self:showOutBoundaryItems(false)
    LuaTools.viewAction1Over(self['Panel_Layer'],'UIMail')

    --G_BASEAPP:removeView('UIMail')
end

function UIMail:verfyFriend(result,mid,onsucc)
  local paTable =     {
         ['uid']    = G_UID,
         ['token']  = G_TOKEN,
         ['cmd']    = HttpHandler.CMDTABLE.MAIL_VERFY,
         ['mtype']  = self.lastSelectedIndex,
         ['mid']    = mid,
         ['option'] = result
       }
    local function succ(arg)   
         self:getApp():addView('UIAlert',1000)
         :setupDialog('Infomation',arg.msg)
         onsucc()
    end 

    local function fail(arg)    
         self:getApp():addView('UIAlert',1000)
         :setupDialog('Infomation',arg.msg) 
    end 
    self.tool:fastRequest(paTable,succ)  
end


function UIMail:mailRewardReq(mid,iGotMyGift,msg)
   local paTable =     {
         ['uid']   = G_UID,
         ['token'] = G_TOKEN,
         ['cmd']   = HttpHandler.CMDTABLE.MAIL_REWARD,
         ['mtype'] = self.lastSelectedIndex,
         ['mid'] = mid, 
       }
    local function succ(arg)   
         self:getApp():addView('UIAlert',1000)
         :setupDialog('Infomation',arg.msg..","..msg) 
         iGotMyGift()
    end 

    local function fail(arg)    
         self:getApp():addView('UIAlert',1000)
         :setupDialog('Infomation',arg.msg)
    end 
  self.tool:fastRequest(paTable,succ)  
end

function UIMail:assembleGiftInfomation( giftTable )
  local ret = ""
  local strTable = {}

  if giftTable then
    ret = ':'
    if giftTable.coin and tonumber(giftTable.coin) > 0 then  
      table.insert(strTable,"金币x"..giftTable.coin)
    end
    if giftTable.gem and tonumber(giftTable.gem) > 0 then 
      table.insert(strTable,"元宝x"..giftTable.gem)
    end
    if giftTable.honor and tonumber(giftTable.honor) > 0 then 
      table.insert(strTable,"魅力值x"..giftTable.honor)
    end

    if  giftTable.gift and type(giftTable.gift) == 'table' then  
        local gTable = LuaTools.getGiftTable()--getItemTable()
        for k,v in pairs(giftTable.gift) do 
            local gid = tonumber((k:gsub("gid", "")))
            if tonumber(v) > 0 then
              table.insert(strTable,gTable[gid].."x"..v)
            end 
        end 
    end 
  
    if  giftTable.tool and type(giftTable.tool) == 'table' then  
        local itemTable = LuaTools.getItemTable()--getItemTable()
        for k,v in pairs(giftTable.tool) do 
            local tid = tonumber((k:gsub("tid", "")))
            if tonumber(v) > 0 then
              table.insert(strTable,itemTable[tid].."x"..v)
            end 
        end 
    end
    for i=1,#strTable - 1 do
        ret = ret..strTable[i]..","
    end
    ret = ret..strTable[#strTable].."。"
  end 
  return ret
end

function UIMail:appendSingleCell(var,tag)
    local temp_tag = self.lastSelectedIndex
    if self.lastSelectedIndex == 1 then
        temp_tag = 3
    end 
    local item = self['Panel_Item_'..temp_tag]:clone()
    self.listViewMails:pushBackCustomItem(item)
    item:setVisible(true) 
    item:getChildByName('Text_desc'):setString(var['mtext'])
    local time = string.sub(var.mdatetime,6,10)
    item:getChildByName('Text_date'):setString(time)

    item:getChildByName('CheckBox_select'):setSelected(false)
    item:getChildByName('Panel_OpenMail'):setTag(tag or -999)
    item:setTag(var['mid']) 

    local giftTable = LuaTools.getGiftImageTable() 

    if temp_tag == 1 then -- never hit 
        --dump(var,"varrrrrr 1")
    elseif temp_tag == 3 then
        --dump(var,"varrrrrr 3")
    elseif temp_tag == 4 then -- gift
        --dump(var,"varrrrrr 4") 
        local function give_me_my_gift_now(event)
            if event.name == 'ended' then 
                self:mailRewardReq(var['mid'],
                    function() 
                      item:getChildByName('Button_ack'):setVisible(false)  
                      item:getChildByName('Image_gift'):setVisible(false)  
                      var.addtion["status"] = 1
                    end,
                    self:assembleGiftInfomation(var.addtion))
            end
        end

        item:getChildByName('Button_ack'):onTouch(give_me_my_gift_now) 
        if var.addtion and next(var.addtion ) then 
            if var.addtion["status"] == 1 then--gift taken
                item:getChildByName('Button_ack'):setVisible(false) 
                item:getChildByName('Image_gift'):setVisible(false) 
            end
        end

    elseif temp_tag == 2 then -- friend request
        local function accept(event) 
            if event.name == 'ended' then 
                self:verfyFriend(1,var['mid'],function() 
                   item:getChildByName('Button_reject'):setVisible(false) 
                   item:getChildByName('Button_agree'):setVisible(false) 
                   item:getChildByName('Image_mail'):loadTexture('res_profile/mail_img_mail.png',ccui.TextureResType.plistType)
                   item:getChildByName('Text_status'):setString('已接受')
                   var.addtion.status = 1
                end)
            end
        end 
        local function deny(event) 
            if event.name == 'ended' then  
                self:verfyFriend(2,var['mid'],function() 
                   item:getChildByName('Button_reject'):setVisible(false) 
                   item:getChildByName('Button_agree'):setVisible(false) 
                   item:getChildByName('Text_status'):setString('已拒绝')
                   item:getChildByName('Image_mail'):loadTexture('res_profile/mail_img_mail.png',ccui.TextureResType.plistType)

                   var.addtion.status = 2
                end)
            end 
        end 

        item:getChildByName('Button_reject'):onTouch(deny) 
        item:getChildByName('Button_agree'):onTouch(accept)  
        if var.addtion and next(var.addtion ) then 
            item:getChildByName('Image_frame'):setVisible(false)
            item:getChildByName('Image_frame'):getChildByName('Image_gift'):ignoreContentAdaptWithSize(true)
            item:getChildByName('Image_frame'):getChildByName('Image_gift'):loadTexture(giftTable[ var.addtion.giftid ],ccui.TextureResType.plistType)--localType
            item:getChildByName('Button_reject'):setVisible(var.addtion.status~= 1 and var.addtion.status~= 2 ) 
            item:getChildByName('Button_agree'):setVisible(var.addtion.status~= 1 and var.addtion.status~= 2 ) 
            

            if var.addtion.status == 1 then
                   item:getChildByName('Text_status'):setString('已接受')
                   item:getChildByName('Image_mail'):loadTexture('res_profile/mail_img_mail.png',ccui.TextureResType.plistType)

            elseif var.addtion.status == 2 then
                   item:getChildByName('Text_status'):setString('已拒绝')
                   item:getChildByName('Image_mail'):loadTexture('res_profile/mail_img_mail.png',ccui.TextureResType.plistType)
            end
        end
    end
end

function UIMail:appendCells(dataTable) 
    for i = 1,#dataTable do
        self:appendSingleCell( dataTable[i],i ) 
    end
end

function UIMail:requestGetProduct()
    if self.gotFullTable[self.lastSelectedIndex] == true then return end
    local paTable =     {
           ['uid']   = tonumber(self.pData .uid),
           ['token'] = self.pData.token,
           ['cmd']   = HttpHandler.CMDTABLE.MAIL_GET,
           ['mtype'] = self.lastSelectedIndex,
           ['page']  = self.indexPage[self.lastSelectedIndex]
       } 
    local function succ(arg) 
        for i=1,#arg.list do
            table.insert(self.allData[self.lastSelectedIndex],arg.list[i])
        end 
        self.gotFullTable[self.lastSelectedIndex] = true
        if next(arg.list) and #arg.list >= 10 then --table not empty and has >= 10 elements
            self.gotFullTable[self.lastSelectedIndex] = false
        end
        self:appendCells(arg.list)
    end 
    self.tool:fastRequest(paTable,succ) 
end

function UIMail:expendPageForView()
    local function onScrolled(event)
        if event.name == "BOUNCE_BOTTOM" then
            if #self.allData[self.lastSelectedIndex] < 10*self.indexPage[self.lastSelectedIndex] then
                return
            end
            self.indexPage[self.lastSelectedIndex] = self.indexPage[self.lastSelectedIndex] + 1
            self:requestGetProduct()
        end
    end
    self.listViewMails:onScroll(onScrolled)
end

function UIMail:dayToString(day)
    if day == 0 then
        return 'Today'
    else
       	return day..' Days ago'
    end
end
return UIMail
