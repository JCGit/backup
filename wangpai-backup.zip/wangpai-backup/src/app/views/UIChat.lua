local UIChat = class("UIChat", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
--printWarning

UIChat.RESOURCE_FILENAME = "UIChat.csb"
--UIChat.RESOURCE_PRELOADING = {"main.png"}
--UIChat.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIChat.RESOURCE_BINDING = {
    ["Button_hide"]  = {["ended"] = "backEvent"},
    ["ListView_select"] = {["ON_SELECTED_ITEM_END"] = "selectEvent"},      
    ["ListView_left"]   = {["ON_SELECTED_ITEM_END"] = "selectChat"},  
      
    ["Button_send"]      = {["ended"] = "worldChat"},
    ["Button_chat"]      = {["ended"] = "butChat"}, 
    ["Button_send2"]     = {["ended"] = "worldChat2"}, 
    ["Button_sendHelp"]  = {["ended"] = "showAdHelp"} 

    }

function UIChat:backEvent(event)
    -- print('UIChat backEvent')
    -- self:removeSelf()
    
    self:showOutBoundaryItems(false)
    LuaTools.viewAction1Over(self["Panel_layer_all"],"UIChat")
end

function UIChat:showAdHelp(event) 
    if event.name == 'ended' then 
       self['Panel_adHelp']:setVisible(true)
       self.tool:freezeWidget(self['Button_sendHelp'], 3) 
       self['Panel_adHelp']:runAction(cc.Sequence:create(cc.DelayTime:create(2.8),cc.CallFunc:create(function() self['Panel_adHelp']:setVisible(false) end )))
    end
end     

function UIChat:showOutBoundaryItems(_show)
    self['Panel_model2']:setVisible(_show)
    self['Panel_model']:setVisible(_show)
end

function UIChat:butChat()
    
    local text = self['TextField_FriendChat']:getString() 
    if #text < 1 then  
        self.tool:showTips('聊天内容不能为空')
        return 
    end 
    local t = os.date("%Y-%m-%d %H:%M:%S")  
    self.app:callMethod('UIMain','reqSock_SEND_MSG_FRIEND',self.sendUID,text)
       
    self:copyChat(self['Panel_model2'],{time= t,msg = text ,who ='me'})
    --self['ListView_right']:refreshView()
    self["ListView_right"]:scrollToBottom(1, true) 

    self:fullChatTable(self.sendUID,{time= t,msg = text ,who ='me'}) 
    self['TextField_FriendChat']:setString('')
end 

function UIChat:transitionViewAction(_action)
   self:runAction(_action:clone())
end

function UIChat:fullChatTable(uid,tab)
    local function compare(tag)
        for key , var in pairs(UserCache.csFriendChat) do 
            if  key == tostring(tag) then 
                return true 
            end 
        end 
    end 
    local temp = compare(uid)
    if temp then  
        table.insert(UserCache.csFriendChat[tostring(uid)],tab)        
    else 
        UserCache.csFriendChat[tostring(uid)] = {}   
        table.insert(UserCache.csFriendChat[tostring(uid)],tab)        
    end 
    UserCache.writecsFriendChat() 
end 

function UIChat:copyChat(model,tab)
    local text = tab.msg 
    local time = tab.time
    if not time then 
       time = os.date("%Y-%m-%d %H:%M:%S")  
    end 
    self['ListView_right']:setItemModel(model) 
    self['ListView_right']:pushBackDefaultItem() 
    local child =self['ListView_right']:getItem(#(self['ListView_right']:getItems())-1)   
    child:setVisible(true)
    child:getChildByName('Text_chat'):setString(text)
    child:getChildByName('Text_time'):setString(time)

    local cell = child
    local msg = text or " "
      msg = LuaTools.splitStringByNumber(msg,22)
      local heightDiff = cell:getChildByName('Text_chat'):getContentSize().height
      cell:getChildByName('Text_chat'):setString(msg)
      heightDiff = cell:getChildByName('Text_chat'):getContentSize().height - heightDiff  
      cell:setContentSize(cell:getContentSize().width,cell:getContentSize().height+heightDiff)
           
      cell:getChildByName('Text_time'):setPositionY(cell:getChildByName('Text_time'):getPositionY()+ heightDiff)
      --cell:getChildByName('Image_head'):setPositionY(cell:getChildByName('Image_head'):getPositionY()+ heightDiff)
      cell:getChildByName('Image_bg'):setPositionY(cell:getChildByName('Image_bg'):getPositionY()+ heightDiff)
      cell:getChildByName('Text_chat'):setPositionY(cell:getChildByName('Text_chat'):getPositionY()+ heightDiff)

      local chatBGheight = cell:getChildByName('Image_bg'):getContentSize().height+heightDiff
      local chatBGWidth = cell:getChildByName('Image_bg'):getContentSize().width

      if cell:getChildByName('Image_bg'):getContentSize().width < cell:getChildByName('Text_chat'):getContentSize().width+40 then
        chatBGWidth = cell:getChildByName('Text_chat'):getContentSize().width + 60
      end

      cell:getChildByName('Image_bg'):setContentSize(chatBGWidth,chatBGheight)
      if model == self['Panel_model2'] then
         cell:getChildByName('Text_chat'):setPositionX(cell:getChildByName('Image_bg'):getPositionX() - chatBGWidth + 25)
         local newHeadSpr 
          if self.pData.iconPath and self.pData.iconPath ~= '' then 
              local spr
              local oldAvatar = UserCache.getUserDataByKey('icon')
              if oldAvatar and #oldAvatar > 0 then
                  spr = cc.Sprite:create(oldAvatar)
              else
                  spr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[self.pData.sex+1])
              end 
              LuaTools.makeSpriteRounded(spr, cell:getChildByName('Image_head'), self.config.maskSprite, true)

          else 
              newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[self.pData.sex+1])   
              LuaTools.makeSpriteRounded(newHeadSpr, cell:getChildByName('Image_head'), self.config.maskSprite, false)
          end
      end
end 

function UIChat:onCreate(num,uid)
    local app = self:getApp()
    self.app = app
    self.config = app:getData('Config')
    self.lastSelectedIndex = 1
    self.lastFriendIndex = 1
    self.initSelect  = uid  

    LuaTools.enterActionScaledWithMask(self['Panel_layer_all'])
    self.allowedMove = true 
    self["ListView_left"]:setScrollBarEnabled(false)
    self["ListView_select"]:setScrollBarEnabled(false)

    self['Button_touch1']:setPressedActionEnabled(false)  
    self['Button_touch2']:setPressedActionEnabled(false)   

    self.tool = app:getModel('Tools') 
    self.playerData = app:getData('PlayerData')
    self.pData      = self.playerData 
    self.myChatTag  = '_:_uid:'..self.playerData.uid
    
    self:initColorBox()

    self['TextField_word']:setTextColor(cc.c3b(0,0,0))
    self['TextField_word']:setPlaceHolderColor(cc.c3b(179,101,43)) 

    local lev, expA, expN = LuaTools.expInfos(self.pData.wins + self.pData.faileds, self.config.levelExp, 1)
    self.labaLimit = lev 
    if  num  then 
        self:swithchPage(1,2)
    else
        self:swithchPage(2,1)
    end
    self['Text_num']:setString(self.playerData.prop[2])

    self['TextField_word']:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    --self['TextField_word']:setDimensions(0,160)
    self['TextField_FriendChat']:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)

    self.showOrHideFriend =  false  
    if G_BASEAPP:getView('UIGameTable') or G_BASEAPP:getView('UIGameTableDouniu') or 
       G_BASEAPP:getView('UIGameTableClassic') or  G_BASEAPP:getView('UIGameTablePaodekuai') or 
       G_BASEAPP:getView('UIGameTableSanzhang') or G_BASEAPP:getView('UIGameTableWanren') then 
       self.showOrHideFriend =  true 
    end 

    local function onScrolled(event)
       local num = #(self['ListView_show']:getItems())
       if num >= 5 then 
            if  event.name == 'SCROLLING'  then 
                 self.allowedMove = false
            elseif event.name == "SCROLL_TO_BOTTOM" then
                 self.allowedMove = true
                 print('num='..num)
                 print('record='..#self.playerData.broadcastRecord)
                 if num < #self.playerData.broadcastRecord then 
                    for key= num+1  ,#self.playerData.broadcastRecord  do 
                        local var = self.playerData.broadcastRecord[key]
                        self:updateWorld(var.str,var.color,var.uid,var.name)
                    end 
                 end
            end 
       end      
    end
    self['ListView_show']:setBounceEnabled(true)
    self['ListView_show']:setInertiaScrollEnabled(true)
    self['ListView_show']:onScroll(onScrolled)
    
end

function UIChat:selectEvent(event)
    LuaTools.playBtSound()
    local index = event.target:getCurSelectedIndex()+1
    self:swithchPage(self.lastSelectedIndex,index)  
end

function UIChat:selectChat(event)
    LuaTools.playBtSound()
    local index = event.target:getCurSelectedIndex()+1
    local uid =  self['ListView_left']:getItem(index-1):getTag()--string.sub(self['ListView_left']:getItem(index-1):getChildByName('Text_uid'):getString(),5)
    self:swithchHead(self.lastFriendIndex,index,tonumber(uid))  
end


function UIChat:swithchHead(from,to,uid)
    --self['ListView_right']:setVisible(false)
    self.sendUID  = uid
    local item 
    if from >= 1 then 
        item = self['ListView_left']:getItem(from-1)
        item:getChildByName('Image_bg'):setVisible(false)
    end    
    item = self['ListView_left']:getItem(to-1)
    item:getChildByName('Image_bg'):setVisible(true)
    self.lastFriendIndex = to 
    local name = self['ListView_left']:getItem(to-1):getChildByName('Text_name'):getString()
    self['ListView_left']:getItem(to-1):getChildByName('Image_redPoint'):setVisible(false)
    if not  self.playerData.chatLogTable[tostring(uid)]  then  self.playerData.chatLogTable[tostring(uid)]  = 0 end 
    self.playerData.chatLogNumber = self.playerData.chatLogNumber - self.playerData.chatLogTable[tostring(uid)]    
    self.playerData.chatLogTable[tostring(uid)] = 0        

    local model ,child =0,nil
    if from~= to  then 
        self['ListView_right']:removeAllItems() 
        for key,var in pairs(UserCache.csFriendChat) do  
            if key and uid == tonumber(key) then  
                for k,v in pairs(var) do 
                    if not v.who then 
                        self:copyChat(self['Panel_model'],v)                    
                    else 
                        self:copyChat(self['Panel_model2'],v)                     
                    end    
                end     
            end 
        end 
    end 
    self.app:callMethod('UIMain','HideRedPoint')
    --self['ListView_right']:refreshView()
    self["ListView_right"]:scrollToBottom(2, true) 
    -- local function cb()
    --   self["ListView_right"]:setVisible(true)
    -- end     
    -- self["ListView_right"]:runAction(cc.Sequence:create(cc.DelayTime:create(0.5),cc.CallFunc:create(cb)))
end 

function UIChat:AddRecord(data)
    local time = os.date("%Y-%m-%d %H:%M:%S")  
    local  uid = self['ListView_left']:getItem(self.lastFriendIndex-1):getTag()--string.sub(self['ListView_left']:getItem(self.lastFriendIndex-1):getChildByName('Text_uid'):getString(),5)
    if  tonumber(uid) == tonumber(data.uid) then 
        local name = self['ListView_left']:getItem(self.lastFriendIndex-1):getChildByName('Text_name'):getString()
        self:copyChat(self['Panel_model'],data) 
        --self['ListView_right']:refreshView()
        self["ListView_right"]:scrollToBottom(2, true) 
        self.playerData.chatLogTable[tostring(data.uid)] = 0 

    else 
        for key= 0 ,#(self['ListView_left']:getItems())-1,1 do 
            local  temp = self['ListView_left']:getItem(key):getTag() --string.sub(self['ListView_left']:getItem(key):getChildByName('Text_uid'):getString(),5)
            if  tonumber(temp) == tonumber(data.uid) then 
                self['ListView_left']:getItem(key):getChildByName('Image_redPoint'):setVisible(true)
            end     
        end 
    end 
    local msg = time.."_"..data.msg

end 

function UIChat:updateFriendList(info)
    self['Image_empty']:setVisible(#info ==0 and true or false)

    if not info or #info == 0 then           
       return  
    end
   
    self["Button_chat"]:setTouchEnabled(#info > 0)  
   
    self['ListView_left']:removeAllChildren()       
    self['Panel_headItem']:getChildByName('Image_bg'):setVisible(false)  
    local item = self['Panel_headItem']
    self['ListView_left']:setItemModel(item)
    
    local model,count,num1 =nil,0,1  
    for key ,var in pairs(info) do 
       self['ListView_left']:pushBackDefaultItem()
       model = self['ListView_left']:getItem(count)
       model:setTag(var.uid)
       local  aaaa = model:getTag()
       model:setVisible(true)
       model:getChildByName('Text_uid'):setString(var.siteid == -1 and '离线' or '在线')
       if var.siteid ~= -1 then 
          model:getChildByName('Text_uid'):setColor(cc.c3b(0,255,0))
       end   
        model:getChildByName('Image_offLine'):setVisible(var.siteid == -1) 
       --model:getChildByName('Text_name'):setString(var.nick)  
       local textName =  model:getChildByName('Text_name')
       local textModel =  "一二三四五"
       LuaTools.cropLabel(textModel, var.nick, textName)

        local newHeadSpr 
        if var.icon and  var.icon ~= "" then
            local function onFinishTable(status,downloadedSize,dst)
                if status == "success" then
                   newHeadSpr = cc.Sprite:create(dst)
                else 
                   newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[var.sex+1])   
                end
                LuaTools.makeSpriteRounded(newHeadSpr, model:getChildByName('Image_head'), self.config.maskSprite, false)
            end
            local newName = var.icon
            LuaTools.getFileFromUrl({
               url = var.icon,
               destFile = (newName:gsub("/","_")),
               onFinishTable = onFinishTable
               })
        else 
            newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[var.sex+1])   
            LuaTools.makeSpriteRounded(newHeadSpr, model:getChildByName('Image_head'), self.config.maskSprite, false)
        end

        model:getChildByName('Image_head'):setLocalZOrder(9)
        model:getChildByName('Image_bg'):setLocalZOrder(15)
        model:getChildByName('Image_redPoint'):setLocalZOrder(11)
        model:getChildByName('Image_di'):setLocalZOrder(10)
        model:getChildByName('Text_uid'):setLocalZOrder(11)
        model:getChildByName('Image_offLine'):setLocalZOrder(13)

       
       if self.initSelect == var.uid then 
          num1 = key 
          --self.playerData.chatLogTable[tostring(var.uid)] = 0 

       else 
          if self.playerData.chatLogTable[tostring(var.uid)] and self.playerData.chatLogTable[tostring(var.uid)] > 0 then 
             model:getChildByName('Image_redPoint'):setVisible(true)
          end 
       end    
       count = count + 1
    end
    --item:removeFromParent()
    self:swithchHead(0,num1,info[num1].uid)
end

function UIChat:giveName(uid)
    for key,var in pairs(self.playerInfo) do 
        if  var.uid == uid then 
            return var.nick 
        end 
    end         
end 

function UIChat:swithchPage(from,to)
    local image1_tab = {'res_profile/btn_head_z1.png','res_profile/btn_head_y1.png'}
    local image2_tab = {'res_profile/btn_head_z.png','res_profile/btn_head_y.png'}
    local temp = {self['Button_touch1'],self['Button_touch2']}
    local temp1 = {self['Panel_world'],self['Panel_friends']}
    if from ~= 0 then 
        temp[from]:loadTextures(image2_tab[from],image2_tab[from],image2_tab[from],ccui.TextureResType.plistType)
        temp1[from]:setVisible(false)
        temp[from]:setTitleColor(cc.c3b(172,147,128))
    end    
    temp[to]:loadTextures(image1_tab[to],image1_tab[to],image1_tab[to],ccui.TextureResType.plistType)
    temp1[to]:setVisible(true)
    temp[to]:setTitleColor(cc.c3b(255,255,255))
    self.lastSelectedIndex = to 
    
    if to == 1 and #self.playerData.broadcastRecord > 0 and from~= to  then 
        if #self['ListView_show']:getItems()  == 0 then 
        --self['ListView_show']:removeAllChildren()
            for key= 1  ,#self.playerData.broadcastRecord  do 
                local var = self.playerData.broadcastRecord[key]
                self:updateWorld(var.str,var.color,var.uid,var.name)
            end 
            self['ListView_show']:scrollToBottom(1, true) 
        else
            return 
        end   
    end  

    if to == 2  and from~= to  then 
        local paTable =     {
            ['uid']   = tonumber(self.playerData.uid),
            ['token'] = self.playerData.token,
            ['cmd']   = HttpHandler.CMDTABLE.GET_FRIEND_LIST
        } 
        local function succ(arg)
            self:updateFriendList(arg.items)
            self.playerInfo = arg.items
        end 
        self.tool:fastRequest(paTable,succ)
    end 
end 

function UIChat:updateWorld(info,color,uid,name)
    if  self.allowedMove == true then 
        self['ListView_show']:setItemModel(self['Panel_modelChat'])
        local cell = self['Panel_modelChat']:clone()
        cell:setVisible(true)

        local msg 
        if name ~= '' then 
           msg = name..':'..info  
        else 
           msg = info 
        end  
        local text =  ccui.Text:create()
        text:setFontSize(32)
        text:setString(msg) 
        val1 = text:getVirtualRendererSize().width
        local b = math.floor(val1/(cell:getContentSize().width-45))+1 
        local textArea = ccui.Text:create()
        textArea:ignoreContentAdaptWithSize(false)
        textArea:setContentSize(cc.size(cell:getContentSize().width-45, b*32+15))
        textArea:setAnchorPoint(0,0.47)
        textArea:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT)
        textArea:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
        cell:setContentSize(cc.size(cell:getContentSize().width, b*32+30))

        textArea:setString(msg)
        textArea:setFontSize(32)

          
        textArea:setColor(color)
        textArea:setName('newTextAdd')
        textArea:setPosition(40,cell:getContentSize().height/2)
        cell:addChild(textArea)
        cell:getChildByName('Text_word'):setString('')

        self['ListView_show']:pushBackCustomItem(cell)

        --self.pData.prop[2] = self.pData.prop[2]-1 
        self['ListView_show']:scrollToBottom(0.2, true)  
        if uid and uid~= 0 then 
            cell:onTouch(function (event)
                if event.name == 'ended' then 
                    local tab = {} 
                    tab.uid =uid 
                    tab.tag = 3 
                    tab.hideFriednBtn = self.showOrHideFriend  
                    G_BASEAPP:addView('UIFriendBrief', self:getLocalZOrder() + 20,tab)  
                end
            end) 
        end 

        self:updateHornCount()
    end     
end 

function  UIChat:worldChat(event) 
    local wordTemp = {'出售','元宝','卖分','卖币','信誉','微信','诚信',
    '加好友','大量','金币','私聊','亿','求购','出币'}

    local content = self['TextField_word']:getString()
    if #content <= 0 then  
       self.tool:showTips('请输入喇叭内容')
       return  
    end 
    
    if self.labaLimit  < 3 then  
       self.tool:showTips('游戏等级三级以上玩家才可发言')
       return  
    end 
    
    local function onEnterShop()
        self.app:addView('UIShop',23333 ,2, 'chat') 
        self.app:removeView('UIDialog')
    end
    if tonumber(self.playerData.prop[2]) < 1 then 
        self.playerData.prop[2] = 0 
        self['Text_num']:setString(self.playerData.prop[2])
        self.app:addView('UIDialog', 2000)
        self.app:callMethod('UIDialog','setupDialog', '', '您的喇叭已用完，是否进入商城购买？',onEnterShop) 
       return 
    end   
    local word = content
    for key,var in pairs(wordTemp) do 
        local a,b = string.find(content,var) 
        if a and b then 
            LuaTools.showAlert('您发送的喇叭有广告嫌疑,请从广告喇叭来进行信息发送')
            return 
        end     
    end     

    self['TextField_word']:setString('')
    -- self.tool:showTips('小喇叭发送成功！')
    -- self.pData.prop[2] = self.pData.prop[2]-1 
    -- self['Text_num']:setString(self.playerData.prop[2])
        self.allowedMove = true 

    self.app:callMethod('UIMain','reqSock_speakerBroadcast',word,nil,1)
end 

function UIChat:worldChat2(event) 
    local content = self['TextField_word']:getString()
    if #content <= 0 then  
       self.tool:showTips('请输入喇叭内容')
       return  
    end 
    if self.labaLimit  < 3 then  
       self.tool:showTips('游戏等级三级以上玩家才可发言')
       return  
    end 
    
    local function onEnterShop()
        self.app:addView('UIShop',23333 ,2, 'chat') 
        self.app:removeView('UIDialog')
    end
    if tonumber(self.playerData.prop[2]) < 1 then 
        self.playerData.prop[2] = 0 
        self['Text_num']:setString(self.playerData.prop[2])
        self.app:addView('UIDialog', 2000)
        self.app:callMethod('UIDialog','setupDialog', '', '您的喇叭已用完，是否进入商城购买？',onEnterShop) 
        return 
    end   
    local word = content
    self['TextField_word']:setString('')
    -- self.pData.prop[2] = self.pData.prop[2]-1 
    -- self['Text_num']:setString(self.playerData.prop[2])
    self.allowedMove = true 

    self.app:callMethod('UIMain','reqSock_speakerBroadcast',word,nil,2)
end     



function UIChat:updateHornCount()
    self['Text_num']:setString(self.pData.prop[2])
end

function UIChat:initColorBox()
    local function onSelectColor(event)
        if event.name == 'ended' then
            
            if self.isColorInit == false then
                local arrColors = {
                {"玫瑰红", {255,45,45}},
                {"贵族紫", {255,0,255}},
                {"阳光橙", {255,154,0}},
                {"柠檬黄", {255,255,0}},
                {"象牙白", {255,255,255}},
                {"烟灰黑", {136,136,136}},
                {"小草绿", {140,254,128}},
                {"薄荷青", {0,255,255}},
                {"宝石蓝", {70,163,255}},
            }
                local function onChooseColor(event)
                    if event.name == 'ended' then
                        
                        if self.pData.vip_level < 10 then 
                            self.tool:showAlert("该功能为VIP10特权")
                            self['Panel_ColorTouchControl']:setTouchEnabled(false)
                            self['Panel_ColorBox']:setVisible(false)
                            return 
                        end
                        self.pData.broadcastColor = arrColors[event.target:getTag()][2]
                        dump(self.pData.broadcastColor)
                        --print("BROADCAST COLOR SELECTED: "..arrColors[event.target:getTag()][1])
                        self['Panel_ColorTouchControl']:setTouchEnabled(false)
                        self['Panel_ColorBox']:setVisible(false)
                    end
                end 
                local defaultItem = self['Panel_ItemColor']
                for i,v in ipairs(arrColors) do
                    local newItem = defaultItem:clone()
                    local text = newItem:getChildByName("Text_color")
                    newItem:setTouchEnabled(true)
                    newItem:onTouch(onChooseColor)
                    newItem:setTag(i)
                    text:setString(v[1])
                    text:setColor(cc.c3b(v[2][1],v[2][2],v[2][3]))
                    self['ListView_ColorBox']:pushBackCustomItem(newItem)
                end

                local function onCloseColorBox(event)
                    if event.name == 'ended' then
                        
                        self['Panel_ColorTouchControl']:setTouchEnabled(false)
                        self['Panel_ColorBox']:setVisible(false)
                    end
                end 
                self['ListView_ColorBox']:setScrollBarEnabled(false)
                self['Panel_ColorTouchControl']:onTouch(onCloseColorBox)
                self.isColorInit = true
            end

            self['Panel_ColorTouchControl']:setTouchEnabled(true)
            self['Panel_ColorBox']:setVisible(true)
        end  
    end 

    self['Panel_ColorTouchControl']:setTouchEnabled(false)
    self['Panel_ColorBox']:setVisible(false)
    self['Button_color']:onTouch(onSelectColor)
    self['Button_ColorBox']:onTouch(onSelectColor)
    self.isColorInit = false
    self.pData.broadcastColor = self.config.DefaultBroadColor
end

return UIChat
