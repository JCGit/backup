local UIShopSubviews = class("UIShopSubviews", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
require "cocos.cocos2d.json"
UIShopSubviews.RESOURCE_FILENAME = "UIShopSubviews.csb"
--UIShopProp.RESOURCE_PRELOADING = {"main.png"}
--UIShopProp.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIShopSubviews.RESOURCE_BINDING = {
   
}

--初始化
function UIShopSubviews:onCreate(_type, _tInfo)
    local app = self:getApp()
    self.app = app
    self.tool = app:getModel('Tools')
    self.config = app:getData('Config')
    self.account = app:getModel('Account')
    self.pData = self.app:getData('PlayerData')

    self.pContent = nil
    self.type = _type
    self.tInfo = _tInfo
    dump(self.tInfo)
    self.panelFunc = {'initBuyTool', 'initTelExchange', 'initSellChips'}
    self.pMain = self['Panel_main']
    LuaTools.enterActionScaledWithMask(self.pMain)
    self.pMain:onTouch(function( event)self:onClose(event)end)
    for i, v in ipairs(self.pMain:getChildren()) do
    	if _type == i then 
    		self.pContent = v
    		self[self.panelFunc[i]](self)  --call the init function 
    		v:getChildByName('Button_Close'):onTouch(function( event)self:onClose(event)end)
    		v:setVisible(true)
    	else
    		v:setVisible(false)
    	end	
    end
end

--关闭此界面
function UIShopSubviews:onClose(event)
	if event.name == 'ended' then 
        LuaTools.viewAction1Over(self.pMain,"UIShopSubviews")
	end
end

--初始化购买道具
function UIShopSubviews:initBuyTool()
	local txtNum = nil
	local lastValidString = '1'  --上一次有效的道具个数
	local MAXNUMBER = 10000
    --更新总价
	local function updateTotal()
		lastValidString = txtNum:getString()
		local totalPrice = tonumber(lastValidString) * self.tInfo.price
		self.pContent:getChildByName('Text_total'):setString('总价：'..totalPrice..'元宝')
	end
    --增加个数
	local function onAdd(event)
        if event.name == 'ended' then
            
        	local num = tonumber(txtNum:getString())
        	if num < MAXNUMBER then 
	            txtNum:setString( txtNum:getString() + 1)
	            updateTotal()
        	end 
        end
    end
    --增减个数
    local function onMinus(event)
        if event.name == 'ended' then
           
           local num = tonumber(txtNum:getString())
           if num > 1 then 
			  txtNum:setString(num - 1)
			  updateTotal()
           end
        end
    end
    --输入个数
    local function onSetNumber(event)
    	print(event.target:getString())
        if event.name == "ATTACH_WITH_IME" then
             
        elseif event.name == "DETACH_WITH_IME" then
            if event.target:getString() == "" or tonumber(event.target:getString()) == nil then
                event.target:setString(1)
                updateTotal()
            end
        elseif event.name == "INSERT_TEXT" then
        	local str = tonumber(event.target:getString())
           if str == nil then
                event.target:setString(lastValidString)
            elseif str >= MAXNUMBER then 
            	event.target:setString(MAXNUMBER)
            	lastValidString = MAXNUMBER
            	updateTotal()
            else 
            	updateTotal()
            end
        elseif event.name == "DELETE_BACKWARD" then
        	if event.target:getString() == "" then
        		event.target:setString(1)
            end
       		updateTotal()
        end
    end

    --【 事件的初始化 】--

    local pCountControl = self.pContent:getChildByName('Panel_countControl')
    txtNum = pCountControl:getChildByName('TextField_count')
    txtNum:onEvent(onSetNumber)
    txtNum:setString(1)
    txtNum:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    txtNum:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    pCountControl:getChildByName('Button_Add'):onTouch(onAdd)
    pCountControl:getChildByName('Button_Minus'):onTouch(onMinus)
    local item = self.pContent:getChildByName('Panel_item')
    item:getChildByName('Text_price'):setString(self.tInfo.price..'元宝/个')
    item:getChildByName('Image_item'):loadTexture(self.tInfo.imgPath ,ccui.TextureResType.plistType)
    updateTotal()

    --点击确定事件
    local function onConfirm(event)
		if event.name == 'ended' then 
            
			self:requestBuyItem(self.tInfo.pid, txtNum:getString())
		end
	end

    self.pContent:getChildByName('Button_confirm'):onTouch(onConfirm)
end


--初始化话费兑换界面
function UIShopSubviews:initTelExchange()
    local txfTel = self.pContent:getChildByName('TextField_tel')
    local txfConf = self.pContent:getChildByName('TextField_telconf')
    --点击确定事件
	local function onConfirm(event)
        if event.name == 'ended' then 
            
            local telStr = txfTel:getString()
            local telConf = txfConf:getString()
             --检测密码内容是否合格
            if  #telStr ~= 11 or nil == tonumber(telStr) then
                self.tool:showTips("电话号码不正确请重新输入。")
                return
            end
            --检测两次输入的密码是否一致
            if telStr ~= telConf then
                self.tool:showTips("两次输入的电话号码不一致，请重新输入。")
                return
            end

            if self.pData.telfee < self.tInfo.price then
                self.tool:showTips("话费券不足...")
                return
            end

            self:requestTelExchange(self.tInfo.pid, self.tInfo.price, telStr)
        end
    end

    --【 事件的初始化 】--

    local item = self.pContent:getChildByName('Panel_item')
    item:getChildByName('Text_price'):setString('10话费卷=1元')
    item:getChildByName('Image_item'):loadTexture(self.tInfo.imgPath ,ccui.TextureResType.plistType)

    txfTel:setTextColor(cc.c4b(255,255,255,255))
    txfConf:setTextColor(cc.c4b(255,255,255,255))
    txfTel:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    txfTel:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    txfConf:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    txfConf:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    self.pContent:getChildByName('Button_confirm'):onTouch(onConfirm)
end

--初始化售卖金币
function UIShopSubviews:initSellChips()
	local txtNum = nil
    local lastValidString = '1'  --上一次有效的道具个数
    local MAXNUMBER = 10000000
    local function updateTotal()
        lastValidString = txtNum:getString()
        print("ADADA      lastValidString: "..lastValidString)
        --local totalPrice = tonumber(lastValidString) * self.tInfo.price
        --self.pContent:getChildByName('Text_total'):setString('总价：'..totalPrice..'元宝')
    end
    --增加
    local function onAdd(event)
        if event.name == 'ended' then
            
            local num = tonumber(txtNum:getString())
            print('NUM: '..num)
            if num < MAXNUMBER then 
                txtNum:setString( num + 1)
                print('NUMUPDATE: '..num)
                updateTotal()
            end 
        end
    end
    --增减
    local function onMinus(event)
        if event.name == 'ended' then
           local num = tonumber(txtNum:getString())
           if num > 1 then 
              txtNum:setString(num - 1)
              updateTotal()
           end
        end
    end

    --【 事件的初始化 】--

    local pCountControl = self.pContent:getChildByName('Panel_countControl')
    txtNum = pCountControl:getChildByName('TextField_countPrice')
    txtNum:setString(2)
    txtNum:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    txtNum:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    self.account:handleTxfControl(txtNum,nil, 'num')
    pCountControl:getChildByName('Button_Add'):onTouch(onAdd)
    pCountControl:getChildByName('Button_Minus'):onTouch(onMinus)

    local panelSelectItem = self.pContent:getChildByName('Panel_SelectItems')
    local listView = panelSelectItem:getChildByName('ListView_question')
    local panelItem = panelSelectItem:getChildByName('Panel_Question')
    local btArrow = self.pContent:getChildByName('Button_openSel')
    panelItem:setVisible(false)
    listView:setItemModel(panelItem)
    listView:setScrollBarEnabled(false)
    panelSelectItem:setVisible(false)
    local indexListAmountSel = 1
    local listAmount = {
        100000,
        500000,
        3000000,
        50000000,
        100000000,
        500000000,
    }

    --选择售卖金币个数
    local function onClickListviewAmount(event) 
        if event.name == 'ON_SELECTED_ITEM_END' then
            
            local indexSel = event.target:getCurSelectedIndex()+1
            self.pContent:getChildByName('Text_price'):setString(self.tool:convertAmountChinese(listAmount[indexSel]))
            indexListAmountSel = indexSel
            panelSelectItem:setVisible(not  panelSelectItem:isVisible())
            txtNum:setString(listAmount[indexSel]/50000)
            lastValidString = listAmount[indexSel]/50000
            btArrow:loadTextureNormal(self.config.bt_updown[1] ,ccui.TextureResType.plistType)
            btArrow:loadTexturePressed(self.config.bt_updown[1] ,ccui.TextureResType.plistType)
        end
    end
    listView:onEvent(onClickListviewAmount)

    --显示金币售卖列表
    local function onShowListAmount(event)
        if event.name == 'ended' then
            
            panelSelectItem:setVisible(not  panelSelectItem:isVisible())
            if panelSelectItem:isVisible() == true then 
                btArrow:loadTextureNormal(self.config.bt_updown[2] ,ccui.TextureResType.plistType)
                btArrow:loadTexturePressed(self.config.bt_updown[2] ,ccui.TextureResType.plistType)
            else
                btArrow:loadTextureNormal(self.config.bt_updown[1] ,ccui.TextureResType.plistType)
                btArrow:loadTexturePressed(self.config.bt_updown[1] ,ccui.TextureResType.plistType)
            end
        end
    end

    --初始化售卖金币列表
    local panel
    for key, var in ipairs(listAmount) do
        listView:pushBackDefaultItem()
        panel = listView:getItem(key-1)
        panel:getChildByName('Text_Question'):setString(self.tool:convertAmountChinese(var))
        if key == #listAmount then
            panel:getChildByName('Image_botborder'):setVisible(false)
        end
        panel:setVisible(true)
    end 

    btArrow:onTouch(onShowListAmount)

    --点击确定事件
    local function onConfirm(event)
        if event.name == 'ended' then 
            
            self:requestSellCoins(listAmount[indexListAmountSel], tonumber(txtNum:getString()), 5)
        end
    end

    self.pContent:getChildByName('Button_confirm'):onTouch(onConfirm)
end


--请求购买产品

function UIShopSubviews:requestBuyItem(pid, num)
    local dataTable =     {
        ['uid']   = self.pData.uid,
        ['token']  = self.pData.token,
        ['pid']      = pid,
        ['number']    = num,
        ['cmd']       = HttpHandler.CMDTABLE.BUY_PRODUCT,
    }
    local function succ(arg)
        self.pData.coin = tonumber(arg.coin) or 0
        self.pData.gem = tonumber(arg.gem) or 0
        --local value = json.decode(arg.tool)
        self.pData.prop[1] = arg.prop['4']
        self.pData.prop[2] = arg.prop['7']
        dump(self.pData.prop)
        self.tool:showAlert(arg.msg)
        self.app:callMethod('UIShop','updateContent')
        self:removeSelf()
    end
    local function fail(arg)
        if arg.msg then
            self.tool:showAlert(arg.msg)
            -- if string.find(arg.msg,'不足') then 
            --    G_BASEAPP:addView('UIShopDiamond',self:getLocalZOrder()+1)
            -- end  
        end
    end
    self.tool:fastRequest(dataTable,succ, fail)
end

--请求话费兑换产品
function UIShopSubviews:requestTelExchange(_tid, _price, _tel)

    local dataTable =     {
        ['uid']   = self.pData.uid,
        ['token']  = self.pData.token,
        ['telphone']  = _tel,
        ['tid']      = _tid,
        ['cmd']       = HttpHandler.CMDTABLE.TELFEE_EXCHANGE,
    }
    local function succ(arg)
        self.pData.telfee = tonumber(arg.telfee) or 0
        self.tool:showAlert("兑换成功！")
        self.app:callMethod('UIShop','updateContent')
        self:updateDescContent()
        self:removeSelf()
       -- local function cb() 
       --     self.app:callMethod('UIShop','updateContent')
       --     self:updateDescContent()
       -- end
       -- local tips = self.app:addView("UITips", 65534,str)
        --tips:setupDialog("提示","兑换成功！我们会在5个工作日内充值到对应的手机号码。祝您游戏愉快！", cb, cb)
    end
    local function fail(arg)
        if arg.msg then
            self.tool:showAlert(arg.msg)
        end
    end
    self.tool:fastRequest(dataTable,succ, fail)
end

--请求售卖金币
function UIShopSubviews:requestSellCoins(amount, price, fee)
    local dataTable =     {
        ['uid']   = self.pData.uid,
        ['token']  = self.pData.token,
        ['coin']      = amount,
        ['gem']    = price,
        ['fee']     = fee,
        ['cmd']       = HttpHandler.CMDTABLE.SELL_COINS,
    }
    local function succ(arg)
        self.pData.coin = tonumber(arg.coin) or 0
        self.pData.gem = tonumber(arg.gem) or 0
        --self.tool:showAlert(amount.."金币发布成功，扣除金币和手续费共"..amount+amount*5/100)
        self.app:callMethod('UIShop','updateContent')
        self.app:callMethod('UIShopTradeMarket','onRefresh')
        self:removeSelf()
    end
    local function fail(arg)
        if arg.msg then
            self.tool:showAlert(arg.msg)
        end
    end
    self.tool:fastRequest(dataTable,succ, fail)
end


return UIShopSubviews