local UIGameTableDouniu = class("UIGameTableDouniu", cc.load("mvc").ViewBase)

UIGameTableDouniu.RESOURCE_FILENAME = "UIGameTableDouniu.csb" 

local GameTableCommon = require("app.models.GameTableCommon")
local TCPConnector = require('app.network.TCPConnector')
local DataPacker = require('app.network.DataPacker')
local DataUnpacker = require('app.network.DataUnpacker')
local HttpHandler = require("app.network.HttpHandler")
 
require("app.models.cardutl")
UIGameTableDouniu.RESOURCE_BINDING = { 

    ["Button_dont_grab"]   = {["ended"] = "PlayerCtrl_dont_grab"}, 
    ["Button_readyup"]   = {["ended"] = "REQ_READY"}, 
    ["Button_changeTable"]   = {["ended"] = "PlayerCtrl_changeTable"},  
    ["Button_back"]   = {["ended"] = "PlayerCtrl_back"},  

    ["Button_card_1"]   = {["ended"] = "getCardClickCallback"},  
    ["Button_card_2"]   = {["ended"] = "getCardClickCallback"},  
    ["Button_card_3"]   = {["ended"] = "getCardClickCallback"},  
    ["Button_card_4"]   = {["ended"] = "getCardClickCallback"},  
    ["Button_card_5"]   = {["ended"] = "getCardClickCallback"},  
 
}

UIGameTableDouniu.multipleTable = 
{
    5,
    10,
    15,
    25,
    50
}

--当前牌桌游戏状态 
UIGameTableDouniu.TableStateWait    = 0 --等待状态
UIGameTableDouniu.TableStateReady   = 1--准备状态
UIGameTableDouniu.TableStateGrab    = 2 --抢庄状态
UIGameTableDouniu.TableStateMulti   = 3--翻倍状态
UIGameTableDouniu.TableStateTurn    = 4 --亮牌状态


UIGameTableDouniu.CDText = { 
    [UIGameTableDouniu.TableStateGrab ] = "等待玩家抢庄",
    [UIGameTableDouniu.TableStateMulti] = "等待玩家翻倍",
    [UIGameTableDouniu.TableStateTurn ] = "等待玩家亮牌",
}

UIGameTableDouniu.PlayerStateWait   = 0
   -- /**
   --  * 已经准备
   --  * */
UIGameTableDouniu.PlayerStateReady   = 1
-- /**
--  *尚未抢庄
--  * */
UIGameTableDouniu.PlayerStateUnGrab   = 2
-- /**
--  *已经抢庄
--  * */
UIGameTableDouniu.PlayerStateGrab   = 3
-- /**
--  * 尚未翻倍
--  * */
UIGameTableDouniu.PlayerStateUnMulti   = 4
-- /**
--  * 已经翻倍
--  * */
UIGameTableDouniu.PlayerStateMulti   = 5
-- /**
--  * 尚未亮牌
--  * */
UIGameTableDouniu.PlayerStateUnTurn   = 6
-- /**
--  * 已经亮牌
--  * */
UIGameTableDouniu.PlayerStateTurn   = 7




UIGameTableDouniu.ARRANGE_MIDDLE = 1
UIGameTableDouniu.ARRANGE_LEFT = 2
UIGameTableDouniu.ARRANGE_RIGHT = 3


UIGameTableDouniu.TypeTable = 
{
     "没牛",
     "牛一",
     "牛2",
     "牛3",
     "牛4",
     "牛5",
     "牛6",
     "牛7",
     "牛8",
     "牛9", 
     "牛牛",
     "四炸",
     "五小牛",
     "五花牛",

}

UIGameTableDouniu.TypsndeTable = 
{
    '_ox_no',
    '_ox1',
    '_ox2',
    '_ox3',
    '_ox4',
    '_ox5',
    '_ox6',
    '_ox7',
    '_ox8',
    '_ox9',
    '_ox10',
    '_ox_bomb',
    '_ox_little',
    '_ox_super',
     

}


UIGameTableDouniu.TIP_NORMAL_PLAYER_TOAST = 0x01;-- // 客户端Toast弹窗
UIGameTableDouniu.TIP_NORMAL_PLAYER_POP = 0x02;--// 客户端Pop弹窗
UIGameTableDouniu.TIP_NORMAL_PLAYER_CloseConn = 0x03;--// 关闭连接,触摸退出房间
UIGameTableDouniu.TIP_NORMAL_READY_COIN_NO_ENOUGH = 0x04;--// 关闭连接,触摸退出房间


UIGameTableDouniu.ImageStatusTable = {
    'RoomPlayerSatus_1_ex.png',
    'RoomPlayerSatus_5_ex.png',
}
UIGameTableDouniu.ButtonStatusTable = {
    [UIGameTableDouniu.TableStateWait] = 
    {
        {name = 'Button_readyup',       enabled = true},
        {name = 'Button_changeTable',   enabled = true},
    },
    [UIGameTableDouniu.TableStateReady] = 
    {
        {name = 'Button_readyup',       enabled = true},
        {name = 'Button_changeTable',   enabled = true},
    }, 
    [UIGameTableDouniu.TableStateGrab] = 
    {
        {name = 'Button_dont_grab',       enabled = true},
        {name = 'Panel_multiply',   enabled = true},
    },
    [UIGameTableDouniu.TableStateMulti] = 
    { 
        {name = 'Panel_multiply',   enabled = true},
    },--Button_dont_grab
    [UIGameTableDouniu.TableStateTurn] = 
    {
        {name = 'Button_have_bull',       enabled = true},
        {name = 'Panel_calc',   enabled = true},
    },
}

UIGameTableDouniu.displayIDTable = 
{
    true,
    false,
    false,
    false,
    false,
}
UIGameTableDouniu.CMD = DataUnpacker.CMD[DataUnpacker.Type.GAME_Douniu]['REQ']

------------------------- button callbacks ---------------------------

function UIGameTableDouniu:PlayerCtrl_back()
    -- body
 
   
   GameTableCommon.quitComfirm(self)
end

function UIGameTableDouniu:PlayerCtrl_dont_grab() 
    self:REQ_GRAB_HOST_OR_MULTIPLY(0,"GRAB_HOST")
end

function UIGameTableDouniu:PlayerCtrl_changeTable() 
    if self.isChangeTableLockDown == true then 
        local blah = ""..cc.Director:getInstance():getTotalFrames()
        G_BASEAPP:addView({
           uiName =  'UIAlert',
           uiInstanceName = blah
            },1000)
        :setupDialog('Infomation',"更换平率过快，低于1秒限制。")
        return
    end
    self.isChangeTableLockDown = true
    self:createSchedule("changeTableLockDown",function()
        self:stopSchedule("changeTableLockDown")
        self.isChangeTableLockDown = nil
    end,1)  
    self:REQ_CHANGE_TABLE()
    LuaTools.beginWaiting(true)  
end




---------------------------- REQUESTS ------------------------------
function UIGameTableDouniu:REQ_FRIENDREQUEST_RESULT(uid,res )  
    local bufferHnd = DataPacker.new(self.CMD['FRIEND_REQUEST_RESULT'])   
    bufferHnd:writeData(uid,DataPacker.INT) 
    bufferHnd:writeData(res,DataPacker.BYTE) 
    self.tcpGear:sendData(bufferHnd:doPack()) 
end

function UIGameTableDouniu:REQ_KICK_PLAYER( uid ) 
    local bufferHnd = DataPacker.new(self.CMD['KIKPLAYER'])   
    bufferHnd:writeData(uid,DataPacker.INT) 
    self.tcpGear:sendData(bufferHnd:doPack()) 
end

function UIGameTableDouniu:REQ_FRIENDREQUEST(toUID )  
    local bufferHnd = DataPacker.new(self.CMD['FRIEND_REQUEST'])   
    bufferHnd:writeData(toUID,DataPacker.INT) 
    self.tcpGear:sendData(bufferHnd:doPack()) 
end



function UIGameTableDouniu:REQ_SENDGIFT( playerUID,giftID ) 
    local bufferHnd = DataPacker.new(self.CMD['SENDGIFT'])   
    bufferHnd:writeData(playerUID,DataPacker.INT)
    bufferHnd:writeData(giftID,DataPacker.BYTE)
    self.tcpGear:sendData(bufferHnd:doPack()) 

end

function UIGameTableDouniu:REQ_CHAT(str)   
    local bufferHnd = DataPacker.new(UIGameTableDouniu.CMD['CHAT'])   
    bufferHnd:writeData(str,DataPacker.STRING)
    self.tcpGear:sendData(bufferHnd:doPack())
end


function UIGameTableDouniu:REQ_EMOJI(id) 
    local bufferHnd = DataPacker.new(UIGameTableDouniu.CMD['EMOJI'])   
    bufferHnd:writeData(id,DataPacker.SHORT)
    self.tcpGear:sendData(bufferHnd:doPack())
end


function UIGameTableDouniu:REQ_CONST_TEXT(id) 
    local bufferHnd = DataPacker.new(UIGameTableDouniu.CMD['CONST_TEXT'])   
    bufferHnd:writeData(id,DataPacker.SHORT)
    self.tcpGear:sendData(bufferHnd:doPack())
end

function UIGameTableDouniu:REQ_CHANGE_TABLE()  
    local bufferHnd = DataPacker.new(UIGameTableDouniu.CMD['CHANGE_TABLE'])  
    local buffer = bufferHnd:doPack() 
    self.tcpGear:sendData(buffer) 
end


function UIGameTableDouniu:REQ_READY()  
    self['Button_readyup']:setEnabled(false)
    local bufferHnd = DataPacker.new(UIGameTableDouniu.CMD['READY'])  
    local buffer = bufferHnd:doPack() 
    self.tcpGear:sendData(buffer) 
end

function UIGameTableDouniu:REQ_SHOW_CARDS( cards )
    dump(cards,"cards on REQ_SHOW_CARDS")
    local bufferHnd = DataPacker.new(UIGameTableDouniu.CMD['SHOW_CARDS']) 
    for k,v in pairs(cards) do 
        bufferHnd:writeData(v,DataPacker.BYTE)   
    end
    local buffer = bufferHnd:doPack() 
    self.tcpGear:sendData(buffer) 
 end 

function UIGameTableDouniu:REQ_GRAB_HOST_OR_MULTIPLY(m,_type)
    -- printf("REQ_GRAB_HOST_OR_MULTIPLY m:%s,_type:%s",m,_type)
    local bufferHnd = DataPacker.new(UIGameTableDouniu.CMD[_type]) 
    bufferHnd:writeData(m,DataPacker.INT)  
    local buffer = bufferHnd:doPack() 
    self.tcpGear:sendData(buffer)  
    self['Button_dont_grab']:setVisible(false)
    self['Panel_multiply']:setVisible(false)
end

function UIGameTableDouniu:REQ_TABLE_DISCONNECT() 
    local bufferHnd = DataPacker.new(self.CMD['TABLE_DISCONNECT'])   
    self.tcpGear:sendData(bufferHnd:doPack())
end


 
----------------------- DISPLAY FUNCTIONS --------------------------
function UIGameTableDouniu:quitComfirm()
    -- body 
    local d = G_BASEAPP:addView('UIDialog', 65530)
    d:setupDialog('', '是否确定退出房间？', 
    function()   
        self:quitTable()
    end) 

end

function UIGameTableDouniu:getShowcardCallback()
    return function(event)
        -- printf("self.hasBull :%s",self.hasBull)
        if event.name == 'ended' then
            local cards = {}
            if self.hasBull then
                 for i=1,5 do 
                    if self['Button_card_'..i].isPicked then  
                        table.insert(cards,self['Button_card_'..i].val)
                    end
                 end

                if #cards < 3 then 
                    for i=1,3 do 
                        table.insert(cards,self['Button_card_'..i].val) 
                    end
                end
            else 
                for i=1,5 do
                    table.insert(cards,self['Button_card_'..i].val)
                    if #cards == 3 then
                        break
                    end 
                end
            end

            self:REQ_SHOW_CARDS( cards )
            self['Button_have_bull']:setVisible(false) 
            self['Panel_calc']:setVisible(false)
        end
    end
    
end

function UIGameTableDouniu:calcBulls()
    -- body
    local sum = 0
    for i=1,3 do
        self['Text_calc_'..i]:setString("0")
    end
    local j = 1
    for i=1,5 do  
       if self['Button_card_'..i].isPicked and j <= 3 then 
        local val = Cardutl.GetCardValue(self['Button_card_'..i].val )
        print("val:",val)
        if val >10 then
            val = 10
        end
            self['Text_calc_'..j]:setString(""..val)
            j=j+1
            sum=sum+val
       end
    end
    self['Text_calc_sum']:setString(sum.."")
    local path = 'room/room_btn_green.png'
    self.hasBull = false
    if self.pickedCardsCount == 3 and sum % 10 == 0 then 
        -- self['Button_have_bull']:setTitleText("有牛")
        self['Button_have_bull']:getChildByName('Image_text'):loadTexture('room/Douniu_txt_yes.png',ccui.TextureResType.plistType)
        
        path = 'room/room_btn_yellow.png'
        self.hasBull = true
    else  
        -- self['Button_have_bull']:setTitleText("没牛") 
        self['Button_have_bull']:getChildByName('Image_text'):loadTexture('room/Douniu_txt_no.png',ccui.TextureResType.plistType)
    end
    
    self['Button_have_bull']:loadTextures(path,path,path,ccui.TextureResType.plistType)

    -- self['Button_have_bull']:onTouch(self:getShowcardCallback())
end

function UIGameTableDouniu:getCardClickCallback(event)
    -- printf("tag:%s",event.target:getTag())
    local height = 20
    if event.target.originalY == nil then
        event.target.originalY = event.target:getPositionY()
    end


    event.target.isPicked = not event.target.isPicked 

    printf('self.pickedCardsCount:%s,isPicked:%s',self.pickedCardsCount,event.target.isPicked )
    if self.pickedCardsCount >= 3 and  event.target.isPicked == true then -- 
        event.target.isPicked = false
        return
    end

    if event.target.isPicked == false then
        event.target:setPositionY(event.target.originalY)
        self.pickedCardsCount=self.pickedCardsCount-1
    else 
        event.target:setPositionY(event.target.originalY+height)
        self.pickedCardsCount=self.pickedCardsCount+1
    end
    self:calcBulls()
        
    -- end
end

function UIGameTableDouniu:initMyCards()
    -- for i=1,5 do
    --     self:
    -- end
    -- body
end

function UIGameTableDouniu:quitTable()
        self.Broadcast:removeSelf()
        local bufferHnd = DataPacker.new(UIGameTableDouniu.CMD['TABLE_DISCONNECT'])   
        self.tcpGear:sendData(bufferHnd:doPack()) 
        self.tcpGear:closeAndRelease() 
        self:removeSelf()
end
function UIGameTableDouniu:setButtonsByStatus(_status)
    printf("mySeatID:%s,playerData:%s",self.mySeatID ,self.playerData)
    dump(self.playerData,"self.playerData")
    if  self.mySeatID 
    and self.playerData 
    and self.playerData[self.mySeatID]
    and self.playerData[self.mySeatID].isSat ~= true then 
        if self.currentRoomState >= UIGameTableDouniu.TableStateGrab  then
            self['Button_readyup']:setVisible(false)
            self['Button_changeTable']:setVisible(false)
        else

            self['Button_readyup']:setVisible(true)
            self['Button_changeTable']:setVisible(true)
            if self.readyMoneyTag then 
               self['Button_changeTable']:setEnabled(self.PlayerData.coin>=self.readyMoneyTag)
            end 
        end
        return 
    end
   
    _status = _status or self.currentRoomState 
    self.currentRoomState  = _status
    for _,v in pairs(UIGameTableDouniu.ButtonStatusTable) do
        for _,v2 in pairs(v) do
            self[v2.name]:setVisible(false)
            if self[v2.name].setEnabled then
                self[v2.name]:setEnabled(false) 
            end
        end
    end 
    for k,v in pairs(UIGameTableDouniu.ButtonStatusTable[self.currentRoomState] or {}) do
        printf("setting %s to visible.",v.name)
        self[v.name]:setVisible(true)
        if self[v.name].setEnabled then
            self[v.name]:setEnabled(v.enabled) 
        end 
        if self.readyMoneyTag then 
           self['Button_changeTable']:setEnabled(self.PlayerData.coin>=self.readyMoneyTag)
        end 
    end

    -- printError("who called me???")
end



function UIGameTableDouniu:REQ_heartbeat()  
     if self.heartBeatBuffer == nil then 
        local bufferHnd = DataPacker.new(UIGameTableDouniu.CMD['HEARTBEAT'])
        self.heartBeatBuffer = bufferHnd:doPack()
     end
    print(' UIGameTableDouniu:REQ_heartbeat() ')
    self.tcpGear:sendData(self.heartBeatBuffer) 
end

function UIGameTableDouniu:getLoginBuffer(tableType,friendID,RoomId) 
    local bufferHnd = DataPacker.new(UIGameTableDouniu.CMD['TABLE_LOGIN_EX'],{protocalVersion = 1})
    bufferHnd:writeData(G_UID,DataPacker.INT)
    bufferHnd:writeData(G_TOKEN,DataPacker.STRING)
    bufferHnd:writeData(tableType,DataPacker.BYTE)  
    bufferHnd:writeData(friendID,DataPacker.INT) 
    bufferHnd:writeData(RoomId,DataPacker.INT)  
    bufferHnd:writeData(self.RoomLevel,DataPacker.INT)  

    return bufferHnd:doPack()
end


function UIGameTableDouniu:showMsgByMsgType(msgType,msg)
    LuaTools.stopWaiting()
    local blah = ""..cc.Director:getInstance():getTotalFrames()
    if msgType == UIGameTableDouniu.TIP_NORMAL_PLAYER_TOAST then
        G_BASEAPP:addView({
           uiName =  'UIAlert',
           uiInstanceName = blah
            },1000)
        :setupDialog('Infomation',msg)
    else
        local b = G_BASEAPP:addView({
           uiName =  'UIDialog',
           uiInstanceName = blah
            }, 200)
        local func = nil
        if msgType == UIGameTableDouniu.TIP_NORMAL_PLAYER_CloseConn 
            or msgType == UIGameTableDouniu.TIP_NORMAL_READY_COIN_NO_ENOUGH then
            func = function()
                self:quitTable()
            end 
        end 

        b:setupDialog("信息",msg,func,func)  
    end
end


 function UIGameTableDouniu:getPlayerByUid( uid )
    for k,v in pairs(self.playerData) do
        if v.Uid == uid then
            return v 
        end
    end
 end
function UIGameTableDouniu:setupPlayer(data)
    local v = data 
    self.playerData[v.seatID] = v
    -- self:insertPlayerToDisplayTable(self.playerData[v.seatID]) 
    if v.seatID ~= self.mySeatID then
        self:insertPlayerToDisplayTable(self.playerData[v.seatID]) 
    else
        self.playerData[v.seatID].displayID = 1
    end

    --显示该玩家相关组件
    print('setting displayID%s to visible',v.displayID)
    self['Panel_player_'..v.displayID]:setVisible(true)
 

    GameTableCommon.setVIP(self, v.VLevel,v.VType,v.displayID )
    --设置性别 
    GameTableCommon.setAvatar(self,v.PicUrl,v.displayID,v.Sex )
    -- local sex = self['Panel_player_'..v.displayID]:getChildByName("Image_avatar") 
    -- sex:loadTexture("common/Room_male_head.png",ccui.TextureResType.plistType) 
    -- if v.Sex == UIGameTableDouniu.SEX_FEMALE then 
    --     local sex = self['Panel_player_'..v.displayID]:getChildByName("Image_avatar") 
    --     sex:loadTexture("common/Room_female_head.png",ccui.TextureResType.plistType) 
    -- end
    -- --设置头像
    -- if v.PicUrl and v.PicUrl~="" then
    --     local iconUrl = self['Panel_player_'..v.displayID]:getChildByName("Image_avatar")  
    --     local newName = self.icon
    --     local function onFinishTable(status,downloadedSize,dst)
    --         if status == "success" then
    --             iconUrl:loadTexture(dst,ccui.TextureResType.localType)
    --         else 
    --             print('获取好友头像失败')
    --         end
    --     end 
    --     LuaTools.getFileFromUrl({
    --         url =  v.PicUrl,
    --         destFile = ( v.PicUrl:gsub("/","_")),
    --         onFinishTable = nFinishTable
    --         }) 
    -- end
    --设置昵称
    if v.Name then
        local nick = self['Panel_player_'..v.displayID]:getChildByName("Text_nickname")
        if nick then
            nick:setString( v.Name) 
        end
    end
    --设置金币
    if v.Coin then
        local coin = self['Panel_player_'..v.displayID]:getChildByName("Text_coins")
        if coin then

            coin:setString(LuaTools.convertAmountChinese(v.Coin,10000)) 
        end
    end

end 

function UIGameTableDouniu:scheduleHeartbeat()
    self:stopSchedule('heartbeat')
    self:createSchedule('heartbeat', function()   
        self:REQ_heartbeat() 
    end,20)  
end 

function UIGameTableDouniu:clearAllStatus()
    print('clearAllStatus')
    for k,v in pairs(self.playerData) do
        local suffix = v.displayID    
        self['Image_status_' .. suffix]:setVisible(false) 
    end 
end

function UIGameTableDouniu:updatePlayerStatus(seatID,status,clear,dontAssign)
    printf("updatePlayerStatus ==> player %s updated status to %s",seatID,status)
    -- printError("")
    for k,v in pairs(self.playerData) do
        local suffix = v.displayID   
        if v.seatID ~= seatID then   
            if clear then

                print('clear setting '..'Image_status_' .. suffix.." to invisible, @ seatid:"..seatID)
                self['Image_status_' .. suffix]:setVisible(false)
            end
        else
            if dontAssign == nil or dontAssign == false then
                self.playerData[seatID].PlayerState = status
            end
            if status == UIGameTableDouniu.TableStateWait then
                print('setting '..'Image_status_' .. suffix.." to invisible, @ seatid:"..seatID)
                
                self['Image_status_' .. suffix]:setVisible(false)
                return
            end
            if UIGameTableDouniu.ImageStatusTable[status] then
                print('setting '..'Image_status_' .. suffix.." to visible, @ seatid:"..seatID,UIGameTableDouniu.ImageStatusTable[status])
                self['Image_status_' .. suffix]:setVisible(true)
                -- dump(UIGameTableDouniu.ImageStatusTable,"UIGameTableDouniu.ImageStatusTable")
                -- printf("status:%s,UIGameTableDouniu.ImageStatusTable[status]:%s",status,UIGameTableDouniu.ImageStatusTable[status])
                self['Image_status_' .. suffix]:loadTexture("room/"..UIGameTableDouniu.ImageStatusTable[status],ccui.TextureResType.plistType) 
            end
        end
    end 
end 


-- function setPlayerState(seatID,state)
--     if state == 0 then
--         self['Image_status_'..self.playerData[v.seatID].displayID]:setVisible(true)
--     end
-- end

function UIGameTableDouniu:insertPlayerToDisplayTable(data)
    -- dump(UIGameTableDouniu.displayIDTable,"UIGameTableDouniu.displayIDTable")
    for k,v in pairs(UIGameTableDouniu.displayIDTable) do
        if v == false then
            -- dump(data,"before display inserted table") 
            UIGameTableDouniu.displayIDTable[k] = true
            data.displayID = k 
            -- dump(data,"after display inserted table")
            -- printf("^^^ the %s has been inserted to table ^^^",k)
            -- dump(UIGameTableDouniu.displayIDTable,"UIGameTableDouniu.displayIDTable AFTER")
            return k
        end
    end 
    -- printError("insertPlayerToDisplayTable: seats are full!")
end

function UIGameTableDouniu:resetTable()
    self:clearTable()
    for i=2,5 do
        UIGameTableDouniu.displayIDTable[i] = false
        self['Panel_player_'..i]:setVisible(false) 
    end
    UIGameTableDouniu.displayIDTable[1] = true
    self.playerData = {}
end

function UIGameTableDouniu:alignItemsHorizontallyWithPadding(padding,childredTable) 
    local width = -padding; 
    for k,child in pairs(childredTable) do
        width  = width + child:getContentSize().width * child:getScaleX() + padding;
    end

    local x = -width / 2.0 ;
    
    for k,child in pairs(childredTable) do
        child:setPosition(x + child:getContentSize().width * child:getScaleX() / 2.0 , 0);
        x  = x+ child:getContentSize().width * child:getScaleX() + padding;
    end 
end

function UIGameTableDouniu:arrangeCards(arrangeType,cardCalueTable,_padding,extraArgs)

    return GameTableCommon.arrangeCards(self,arrangeType,cardCalueTable,_padding,extraArgs)

    -- local parent = display.newNode() 
    -- local spritePath = Cardutl.getPathForCard( cardCalueTable[1],nil,nil,'Douniu')  
    -- print("arrangeCards spritePath：",spritePath)
    -- local card = cc.Sprite:createWithSpriteFrameName(spritePath)
    -- local padding = card:getContentSize().width * 0.3
    -- local width =   padding * #cardCalueTable + card:getContentSize().width * card:getScaleX() 
    -- local aPoint = cc.p(0,0.5) 
    -- if arrangeType == UIGameTableDouniu.ARRANGE_RIGHT then 
    --     aPoint = cc.p(0,0.5)
    -- elseif  arrangeType == UIGameTableDouniu.ARRANGE_MIDDLE then 
    --     aPoint = cc.p(0.5,0.5)
    -- end

    -- local cardInstanceTable = {}
    -- -- dump(cardCalueTable,"cardCalueTable")
    -- for k,v in pairs(cardCalueTable) do
    --     print("cardCalueTable=>",k,v)
    --     local spritePath = Cardutl.getPathForCard(v,nil,nil,'Douniu' ) 
    --     print("spritePath=>",spritePath)
    --     local card = cc.Sprite:createWithSpriteFrameName(spritePath)
    --     parent:addChild(card)  
    --     card:setAnchorPoint(aPoint)    
    --     if arrangeType == UIGameTableDouniu.ARRANGE_LEFT then
    --         card:setPosition(tonumber(k) * padding  - padding, 0); 
    --     elseif  arrangeType == UIGameTableDouniu.ARRANGE_RIGHT  then  
    --         card:setPosition((tonumber(k)) * padding - width , 0); 
    --     end
    --     table.insert(cardInstanceTable,card)
    -- end
    -- if arrangeType == UIGameTableDouniu.ARRANGE_MIDDLE then
    --     self:alignItemsHorizontallyWithPadding(-80,cardInstanceTable)
    -- end

    -- return parent 
end

function UIGameTableDouniu:playCardTypeAnimation(displayID,_type)
    self['Panel_player_'..displayID]:getChildByName('Image_bulltype'):setVisible(true)
    self['Panel_player_'..displayID]:getChildByName('Image_bulltype'):getChildByName('Image_text'):loadTexture('tableresult/'..GameTableCommon.DoniuTypeTable[_type+1],ccui.TextureResType.plistType)
    
    local startScale = 2
    local bullImage = self['Panel_player_'..displayID]:getChildByName('Image_bulltype')
    bullImage.originalScale = bullImage:getScale()
    bullImage:setScale(startScale)
    bullImage:setOpacity(0)
    local txtActTime = 0.3
    local txtSclDown = cc.EaseExponentialOut:create(cc.ScaleTo:create(txtActTime,bullImage.originalScale))
    local txttnt = cc.FadeTo:create(txtActTime,255)
    bullImage:runAction(cc.Spawn:create(txtSclDown,txttnt))

    local bullText = self['Panel_player_'..displayID]:getChildByName('Image_bulltype'):getChildByName('Image_text')
    bullText.originalScale = bullText:getScale()
    bullText:setScale(startScale)
    -- bullText:setOpacity(0)
    local imgActTime = 0.6
    local imgSclDown = cc.ScaleTo:create(imgActTime*0.5,bullText.originalScale)
    -- local imgtnt = cc.FadeTo:create(txtActTime*0.5,255)
    local imgSpawn= cc.Spawn:create(imgSclDown--[[,imgtnt]])
    local imgSclUp = cc.ScaleTo:create(imgActTime*0.25,1.5)
    local imgSclDownFinal = cc.ScaleTo:create(imgActTime*0.25,bullText.originalScale)
    bullText:runAction(cc.Sequence:create(imgSpawn,imgSclUp,imgSclDownFinal))






end

function UIGameTableDouniu:showCards(seatID,cards,showType,_type,extraArgs)
    -- local arrangeType = UIGameTableDouniu.ARRANGE_MIDDLE
    local displayID = self.playerData[seatID].displayID
    -- if self.playerData[seatID].displayedCards ~= nil then
    --    self.playerData[seatID].displayedCards:removeFromParent()
    --    self.playerData[seatID].displayedCards = nil
    -- end


    -- if displayID == 2 or displayID == 3 then
    --     arrangeType = UIGameTableDouniu.ARRANGE_RIGHT
    -- elseif displayID == 4 or displayID == 5 then 
    --     arrangeType = UIGameTableDouniu.ARRANGE_LEFT
    -- end
    -- local cards = self:arrangeCards(arrangeType,cards)
    -- self.playerData[seatID].displayedCards = cards 
    -- local cardNode = self['Panel_player_'..displayID]:getChildByName('Image_card')
    -- cards:setPositionX(cardNode:getPositionX())
    -- cards:setPositionY(cardNode:getPositionY())

    -- cards:setScaleX(cardNode:getScaleX())
    -- cards:setScaleY(cardNode:getScaleY())
    -- cards:setLocalZOrder(cardNode:getLocalZOrder()-1)
    -- -- cards:setGlobalZOrder(cardNode:getGlobalZOrder())


    -- cardNode:getParent():addChild(cards)

    GameTableCommon.showCards(self,seatID,cards,showType,_type,extraArgs)
    if showType == true then
        self:playCardTypeAnimation(displayID,_type)
        -- self['Panel_player_'..displayID]:getChildByName('Image_bulltype'):setVisible(true)
        -- self['Panel_player_'..displayID]:getChildByName('Image_bulltype'):getChildByName('Text_bull'):setString(UIGameTableDouniu.TypeTable[_type+1])
    end
end

-------------------------- TCP FUNCTIONS---------------------------------------------

function UIGameTableDouniu:POVShowCard(_onfinish)
    local orbitTime = 0.5
    local clonedCardTable = {} 
    for i=1,5 do
        self['Button_card_'..i].isPicked = false 
        if self['Button_card_'..i].originalY then
            self['Button_card_'..i]:setPositionY(self['Button_card_'..i].originalY)
        end
        local cardNode = self['Button_card_'..i]:clone()
        clonedCardTable[i]=cardNode 
        cardNode.srcPos = cc.p(cardNode:getPosition())
        cardNode:onTouch(function() end)
        cardNode:setPressedActionEnabled(false)
        cardNode:setTouchEnabled(false)
    end 
    table.insert(UIGameTableDouniu.selfShowdownCardTable,clonedCardTable) 
    GameTableCommon.alignItemsHorizontallyWithPadding(-80,clonedCardTable) 

    local offsetY = 30
    for i=1,5 do
        local cardNode = clonedCardTable[i]
        cardNode:setVisible(true)
        cardNode.destPos = cc.p(cardNode:getPosition())
        local pos = self['Panel_player_1']:getChildByName('Image_bulltype'):convertToWorldSpaceAR(cc.p(0,0)) 
        cardNode.destPos.x = pos.x +  cardNode.destPos.x 
        cardNode.destPos.y = pos.y +  cardNode.destPos.y + offsetY
        cardNode:setPosition(cardNode.srcPos)
        self['Button_card_'..i]:getParent():addChild(cardNode)
        cardNode:setLocalZOrder( self['Panel_player_1']:getLocalZOrder()  )
        self['Panel_player_1']:setLocalZOrder(self['Panel_player_1']:getLocalZOrder() + 10)
        local originalScaleX = cardNode:getScaleX()
        local originalScaleY = cardNode:getScaleY()
        local orbit1 = cc.EaseExponentialOut:create(cc.ScaleTo:create(orbitTime * 0.5, 0.001, originalScaleY))
        local orbit2 = cc.EaseExponentialOut:create(cc.ScaleTo:create(orbitTime * 0.5, originalScaleX, originalScaleY) )
        local function middleAct()
            cardNode.backImg = cc.Sprite:createWithSpriteFrameName('newcard/back.png')
            cardNode:addChild(cardNode.backImg)
            cardNode.backImg:setPositionX(cardNode:getContentSize().width*0.5)
            cardNode.backImg:setPositionY(cardNode:getContentSize().height*0.5) 
        end 
        local scaleFactor = 0.42
        local mvt = cc.EaseExponentialOut:create(cc.MoveTo:create(orbitTime*0.3,cardNode.destPos))
        local scl = cc.EaseExponentialOut:create(cc.ScaleTo:create(orbitTime*0.3,scaleFactor))
        local spwn = cc.Spawn:create(mvt,scl)

        local orbit3 = cc.EaseExponentialOut:create(cc.ScaleTo:create(orbitTime * 0.5, 0.001, scaleFactor))
        local orbit4 = cc.EaseExponentialOut:create(cc.ScaleTo:create(orbitTime * 0.5, scaleFactor, scaleFactor) )

        local function removeBackImg()
            cardNode.backImg:removeFromParent()
            cardNode.backImg = nil
        end
        local function ending()
            -- cardNode:removeFromParent()
            if _onfinish and i == 5 then 
                _onfinish(clonedCardTable)
            end
        end
        local actTable = {}
        -- middleAct()
        table.insert(actTable,orbit1)
        table.insert(actTable,cc.CallFunc:create(middleAct))
        table.insert(actTable,orbit2)
        table.insert(actTable,spwn)
        table.insert(actTable,orbit3)
        table.insert(actTable,cc.CallFunc:create(removeBackImg))
        table.insert(actTable,orbit4)
        table.insert(actTable,cc.CallFunc:create(ending))


        cardNode:runAction(cc.Sequence:create(actTable))
    end
end

UIGameTableDouniu.selfShowdownCardTable = {}
function UIGameTableDouniu:TCP_PLAYER_SHOW_CARDS(data) 
    dump(data,'TCP_PLAYER_SHOW_CARDS')  
    local cards = {}
    for i=1,5 do
        table.insert(cards,data['card'..i])
    end
    -- data.CardType
    printf('blahah:%s,',UIGameTableDouniu.TypsndeTable[data.CardType + 1] )
    GameTableCommon.playSound(self,data.seatID,UIGameTableDouniu.TypsndeTable[data.CardType+1] ) 
    self.playerData[data.seatID].nType = data.CardType

    if data.seatID == self.mySeatID then
        for i=1,5 do
            self['Button_card_'..i]:setVisible(false)
        end
        self:POVShowCard(function(cardTable)
            self:playCardTypeAnimation(self.playerData[data.seatID].displayID,data.CardType) 
        end)
    else 
        local extraArgs = 
        {
            useAnimation = true,
            animationType = 'orbit',
            animationOrbitIdxTable = {1,2,3,4,5},
            onFinishCallback = function()  
            end
        } 
        self:showCards(data.seatID,cards,true,data.CardType,extraArgs)
    end

end


function UIGameTableDouniu:startCounddown( msg,sec )
    self['Image_countdown']:setVisible(false)
    if sec >0 then 
        self['Image_countdown']:getChildByName('Text_time'):setString(msg..":"..sec - 1)
        local remaining = sec - 1
        self['Image_countdown']:setVisible(true)
        self:stopSchedule("countdown")
        self:createSchedule("countdown",function() 
            remaining=remaining-1
            if remaining < 0 then 
                self:stopSchedule("countdown") 
                self['Image_countdown']:setVisible(false)
                return
            end
            self['Image_countdown']:getChildByName('Text_time'):setString(msg..":"..remaining)
        end,1) 
    end
end

function UIGameTableDouniu:TCP_START_MULTIPLY(data) 
    dump(data,'TCP_START_MULTIPLY')   
 
    self:setupMultiplyButtons(data.MinMulti,data.MaxMulti,'MULTIPLY') 

    self.thisRoundMulti = data.GrabMulti

    self:startCounddown(UIGameTableDouniu.CDText[UIGameTableDouniu.TableStateMulti],self.timeTable[UIGameTableDouniu.TableStateMulti])

    self:clearAllStatus()
    self:setupDealer(data.DealSeatId)
end

function UIGameTableDouniu:TCP_PLAYER_GRAB_HOST(data)  
    dump(data,'TCP_PLAYER_GRAB_HOST')
    if data.multi == 0 then
        -- GameTableCommon.playSound(self,data.seatID, '_NoRob')
        self:updatePlayerStatus(data.seatID,UIGameTableDouniu.TableStateGrab)
    else
        self:showMultiplyAmountBySeatID(data.seatID,data.multi )
        -- GameTableCommon.playSound(self,data.seatID, '_Rob3')
    end
end

function UIGameTableDouniu:TCP_NETWORK_BAD_TRAFFIC(data) 
    dump(data,'TCP_NETWORK_BAD_TRAFFIC')  
end

function UIGameTableDouniu:setupDealer(seatID)
    GameTableCommon.setupDealer(self,seatID)
         -- -- body
         -- for k,v in pairs(self.playerData) do
         --    if seatID == v.seatID then
         --        self.playerData[seatID].isDealer = true
         --        local dealer =  cc.Sprite:createWithSpriteFrameName('room/Douniu_bg6.png')
         --        dealer:setName('dealer')
         --        self['Panel_player_'..v.displayID]:getChildByName('Image_avatar'):addChild(dealer)
         --    else
         --        local dealer = self['Panel_player_'..v.displayID]:getChildByName('Image_avatar'):getChildByName('dealer')
         --        if dealer then
         --            dealer:removeFromParent()
         --        end
         --    end
         -- end 
    
end 

function UIGameTableDouniu:clearMultiplyAmount()
    for k,v in pairs(self.playerData) do 
        local displayID = v.displayID
        self['Panel_player_'..displayID]:getChildByName('Text_multiply'):setVisible(false) 
    end
end

function UIGameTableDouniu:showMultiplyAmountBySeatID( seatID,m )
    -- body
    -- printError("showMultiplyAmountBySeatID")
    if m == 0 then
        self:updatePlayerStatus(seatID,UIGameTableDouniu.TableStateGrab)
        return 
    end
    local displayID = self.playerData[seatID].displayID
    if m <= 4 then
        self.lordMultiply = m 
        self.playerData[seatID].dnMul = 5
     else  
        self.playerData[seatID].dnMul =  m
     end

    self['Panel_player_'..displayID]:getChildByName('Text_multiply'):setVisible(true)
    self['Panel_player_'..displayID]:getChildByName('Text_multiply'):setString(string.format("x%s倍",m))
end



function UIGameTableDouniu:setupMultiplyButtons(min,max,_type)

    if self.playerData[self.mySeatID].isSat ~= true then return end
    -- printError(" UIGameTableDouniu:setupMultiplyButton")
    -- body 
    if min == max then 

        self['Panel_multiply']:setVisible(false)  
        self['Button_dont_grab']:setVisible(false)

        return
    end
    -- printError('setupMultiplyButtons setting Panel_multiply to true')
    print('setupMultiplyButtons setting Panel_multiply to true')
    self['Panel_multiply']:setVisible(true)  
    local myass = 0
    local offsetX = self['Button_dont_grab']:getBoundingBox().width * 0.5
    self['Button_dont_grab']:setVisible(true)
    if _type == 'MULTIPLY' then
        myass = 1
        offsetX = 0 
        self['Button_dont_grab']:setVisible(false)
    end
    -- for k,v in pairs(UIGameTableDouniu.multipleTable) do
    --     print(k,v)
    -- end
    for i=1,4 do
        local val = UIGameTableDouniu.multipleTable[i]-- math.floor((((max - min) / 4)   + (i - myass)*min))
        if _type ~= 'MULTIPLY' then
            val = math.floor((((max - min) / 4)   + (i - myass)*min))
        end
        local function f(event)
            if event.name == 'ended' then
                self:REQ_GRAB_HOST_OR_MULTIPLY(val,_type)
            end
        end
        if self['Button_multiply_'..i].originalX == nil then 
            self['Button_multiply_'..i].originalX = self['Button_multiply_'..i]:getPositionX()
        end 

        if self['Button_dont_grab'].originalX == nil then 
            self['Button_dont_grab'].originalX = self['Button_dont_grab']:getPositionX()
        end

        self['Button_dont_grab']:setPositionX(self['Button_dont_grab'].originalX  + offsetX) 
        self['Button_multiply_'..i]:setPositionX(self['Button_multiply_'..i].originalX  + offsetX)
        self['Button_multiply_'..i]:getChildByName('BitmapFontLabel_text'):setString(string.format("x%s倍",val)) 
        self['Button_multiply_'..i]:onTouch(f)
    end
end

function UIGameTableDouniu:TCP_KIKPLAYER(data)
    dump(data,'TCP_KIKPLAYER')
    GameTableCommon.kickPlayer( self,data )
end


function UIGameTableDouniu:TCP_PLAYER_MULTIPLY(data) 
    dump(data,'TCP_PLAYER_MULTIPLY')    
    self:showMultiplyAmountBySeatID( data.seatID,data.multi )
    -- GameTableCommon.playSound(self,data.seatID, '_jiabei')
end

function UIGameTableDouniu:TCP_START_SHOW_CARDS(data) 
    dump(data,'TCP_START_SHOW_CARDS')   
    self:clearAllStatus()
 

    self:startCounddown(UIGameTableDouniu.CDText[UIGameTableDouniu.TableStateTurn],self.timeTable[UIGameTableDouniu.TableStateTurn])


    if self.playerData[self.mySeatID].isSat ~= true then return end
    self['Button_card_5']:setVisible(true)
    self['Button_card_5'].val = data.cards[1]
    local path = Cardutl.getPathForCard( data.cards[1],nil,nil,"Douniu" )
    self['Button_card_5']:loadTextures(path,path,path,ccui.TextureResType.plistType)
    self:setButtonsByStatus(UIGameTableDouniu.TableStateTurn)
    local extraArgs = 
            {
                useAnimation = true,
                animationType = 'orbit',
                animationOrbitIdxTable = {5},
                onFinishCallback = function()  
                end
            }  
    local cards = {
      [1] = self['Button_card_1'].val,
      [2] = self['Button_card_2'].val,
      [3] = self['Button_card_3'].val,
      [4] = self['Button_card_4'].val,
      [5] = self['Button_card_5'].val,
    } 
    self:setupPOVCards(cards,extraArgs) 



    
end

function UIGameTableDouniu:setupPOVCards( cards,extraArgs )

    if self.playerData[self.mySeatID].isSat ~= true then return end 
    GameTableCommon.setupPOVCards(self, cards,extraArgs,5 )
    -- for i=1,5 do
    --     self['Button_card_'..i]:setVisible(true)
    --     self['Button_card_'..i]:loadTextures('newcard/back.png','newcard/back.png','newcard/back.png',ccui.TextureResType.plistType)
    -- end

    -- for k,v in pairs(cards) do
    --     print(k,v)
    --     self['Button_card_'..k]:setVisible(true) 
    --     self['Button_card_'..k].val = v  
    --     local path = Cardutl.getPathForCard( v,nil,nil,"Douniu" )
    --     print(path)
    --     self['Button_card_'..k]:loadTextures(path,path,path,ccui.TextureResType.plistType)
    -- end
end

function UIGameTableDouniu:TCP_START_GRAB_HOST(data) 
    dump(data,'TCP_START_GRAB_HOST')  
    self:clearTable()
     if self.resultPage and self.resultPage.removeSelf then     
        self.resultPage:removeSelf()
        self.resultPage = nil
    end
    self.currentRoomState = UIGameTableDouniu.TableStateGrab 
    for k,v in pairs(data.EnterGameSeatId) do
        self.playerData[v].isSat = true
    end
    self:startCounddown(UIGameTableDouniu.CDText[UIGameTableDouniu.TableStateGrab],self.timeTable[UIGameTableDouniu.TableStateGrab])
    self:setButtonsByStatus()
    self:setupMultiplyButtons(1,data.MaxMulti,'GRAB_HOST')
    self:clearAllStatus()
    if self.playerData[self.mySeatID].isSat ~= true then  
        GameTableCommon.setStaticMsg(self, '观战中，请等待下局开始...' )
        self['Button_readyup']:setVisible(true)
        self['Button_readyup']:setEnabled(false)
        self['Button_changeTable']:setVisible(true)
        if self.readyMoneyTag then 
            self['Button_changeTable']:setEnabled(self.PlayerData.coin>=self.readyMoneyTag)
        end 
    end

    self.isDealingCards = true
    for k,v in pairs(data.EnterGameSeatId) do
        -- if v.seatID ~= self.mySeatID then
        --     self:showCards(v.seatID,{0,0,0,0,0},false)
        -- end
        self:createSchedule("dealcard_"..k,function()
            self:stopSchedule("dealcard_"..k)
            local extraArgs = 
            {
                useAnimation = true,
                animationType = 'deal',
                onFinishCallback = function() 
                    if k == #data.EnterGameSeatId then
                        self.isDealingCards = false
                    end
                end
            } 

            if v ~= self.mySeatID then  
                self:showCards(v,{0,0,0,0,0},false,nil,extraArgs) 
            else
                self:setupPOVCards( data.Cards,extraArgs )  
            end

        end,0.1 *tonumber(k))

    end
    


    -- Button_card_2

end
function UIGameTableDouniu:TCP_PLAYER_DISCONNECTED(data)
    dump(data,'TCP_PLAYER_DISCONNECTED')  
    local player = self:getPlayerByUid( data.Uid )
    data.seatID = player.seatID
    GameTableCommon.disconnectPlayer( self,data.seatID ) 
    if self.playerData and self.playerData[data.seatID] then
        self['Panel_player_'..self.playerData[data.seatID].displayID]:setVisible(false)
        self['Panel_player_'..self.playerData[data.seatID].displayID]:getChildByName('Image_bulltype'):setVisible(false)
        UIGameTableDouniu.displayIDTable[self.playerData[data.seatID].displayID]=false
        self.playerData[data.seatID]=nil
    end
end

function UIGameTableDouniu:TCP_PLAYER_CONNECTED(data)
    dump(data,'TCP_PLAYER_CONNECTED')  
    self:setupPlayer(data)
end

function UIGameTableDouniu:TCP_PLAYER_READY(data)
    dump(data,'TCP_PLAYER_READY') 
    self:updatePlayerStatus(data.seatID,UIGameTableDouniu.TableStateReady)
end

function UIGameTableDouniu:TCP_LOGIN_SUCC(data)
    dump(data,'TCP_LOGIN_SUCC') 
    self.loginData = data
    LuaTools.stopWaiting()
    local readyMoney =  {['48']=1000,['49']=6000,['50']=20000,['51']=100000} 
    self.readyMoneyTag = readyMoney[tostring(data.tableType)]
    self:resetTable()
    self.currentRoomState = data.TableState
    self.mySeatID = data.MySeatID   
    self['Text_difen']:setString('底分：'..data.baseChip)

    GameTableCommon.handleLoginSuccess( self,data )

    self.timeTable.CurrentStateGoneTime     = data.CurrentStateGoneTime
    self.timeTable[UIGameTableDouniu.TableStateGrab ]  = data.GrabTimeOut
    self.timeTable[UIGameTableDouniu.TableStateMulti]  = data.MultiTimeOut
    self.timeTable[UIGameTableDouniu.TableStateTurn ]  = data.TurnTimeOut

    if data.CurrentDealerMulti then 
        self.lordMultiply = data.CurrentDealerMulti
    end

    for k,v in pairs(data.users) do 
        -- dump(v,"v")
        self.playerData[v.seatID] = v 
        if v.seatID == self.mySeatID then--force my displayID to 1
            -- print("v.seatID == self.mySeatID ")
            self.playerData[v.seatID].displayID = 1
            if v.PlayerState == UIGameTableDouniu.TableStateReady then 
                self['Button_readyup']:setEnabled(false)
            end
        else
        end
            self:setupPlayer(v)
        -- self:updatePlayerStatus(v.seatID,v.PlayerState,true)
 
        self.playerData[v.seatID].isSat = nil
        if v.PlayerState >= UIGameTableDouniu.PlayerStateUnGrab  then
            self.playerData[v.seatID].isSat = true
            if    v.seatID == self.mySeatID then
                -- self:updatePlayerStatus(v.seatID,UIGameTableDouniu.TableStateWait ,false,true)
                self:setupPOVCards( v.Cards )
            else
                if v.PlayerState ~= UIGameTableDouniu.PlayerStateTurn then
                    self:showCards(v.seatID,{0,0,0,0,0},false)
                end
            end
               
        end

        if v.PlayerState == UIGameTableDouniu.PlayerStateReady then
            self:updatePlayerStatus(v.seatID,1)
        end 

        if v.PlayerState == UIGameTableDouniu.PlayerStateUnTurn  then
            if v.seatID ~= self.mySeatID then
                self:showCards(v.seatID,{0,0,0,0,0},false)
            end 
            if v.Multi ~= 0 then 
                self:showMultiplyAmountBySeatID( v.seatID,v.Multi )
            end
        end 
 

        if v.PlayerState == UIGameTableDouniu.PlayerStateGrab then
            -- self:updatePlayerStatus(v.seatID,UIGameTableDouniu.TableStateGrab,nil,true) 
            if data.TableState < UIGameTableDouniu.TableStateMulti then
                self:showMultiplyAmountBySeatID( v.seatID,v.GrabMulti )
            end
             if  v.seatID == self.mySeatID then  
                self['Panel_multiply']:setVisible(false)   
                self['Button_dont_grab']:setVisible(false)   
             end
        end 

        if v.PlayerState == UIGameTableDouniu.PlayerStateUnGrab and v.seatID == self.mySeatID then
            self:setupMultiplyButtons(1,v.MaxGrabMulti,"GRAB_HOST")
            -- self:showMultiplyAmountBySeatID( v.seatID,v.GrabMulti )
        end 

        if v.PlayerState == UIGameTableDouniu.PlayerStateUnMulti and v.seatID == self.mySeatID then
 
            self:setupMultiplyButtons(v.MinMulti,v.MaxMulti,"MULTIPLY") 
            -- self:showMultiplyAmountBySeatID( v.seatID,v.GrabMulti )
        end 

        if v.PlayerState == UIGameTableDouniu.PlayerStateMulti then
            self:showMultiplyAmountBySeatID( v.seatID,v.Multi ) 
            if  v.seatID == self.mySeatID then  
                self['Panel_multiply']:setVisible(false)  
                self['Button_dont_grab']:setVisible(false)   
            end
        end
 
        if v.PlayerState == UIGameTableDouniu.PlayerStateTurn then
            self:showCards(v.seatID,v.Cards,true,v.TurnCardType)

            self['Button_have_bull']:setVisible(false) 
            self['Panel_calc']:setVisible(false)
             if v.seatID == self.mySeatID then
                for i=1,5 do
                    self['Button_card_'..i]:setVisible(false)
                end
            end
        end
    GameTableCommon.updatePlayerCoins(self, v.seatID,v.Coin )
    end
    self:setupDealer(data.CurrentDealerSeatId)
 -- GameTableCommon.setStaticMsg(delegate, str )
    self:setButtonsByStatus() 
    if data.TableState >= UIGameTableDouniu.TableStateMulti then 
        self:showMultiplyAmountBySeatID( data.CurrentDealerSeatId,data.CurrentDealerMulti)
    end

    if data.TableState >= UIGameTableDouniu.TableStateGrab then 
        self:startCounddown(UIGameTableDouniu.CDText[data.TableState],self.timeTable[data.TableState] - self.timeTable.CurrentStateGoneTime)
        if self.playerData[self.mySeatID].isSat ~= true then  
            GameTableCommon.setStaticMsg(self, '观战中，请等待下局开始...' ) 
            self['Button_readyup']:setVisible(true)
            self['Button_readyup']:setEnabled(false)
            self['Button_changeTable']:setVisible(true)
            if self.readyMoneyTag then 
               self['Button_changeTable']:setEnabled(self.PlayerData.coin>=self.readyMoneyTag)
            end 
        end
    end     
    cc.SpriteFrameCache:getInstance():addSpriteFrames("tableresult.plist")
    self['Image_roomtype']:setVisible(true)
    self['Image_roomtype']:loadTexture(string.format("tableresult/dn_%s.png",tonumber(data.tableType)-48 ),ccui.TextureResType.plistType) 

end

function UIGameTableDouniu:TCP_RSPD_FAIL(data)
    -- dump(data,'TCP_RSPD_FAIL')

    GameTableCommon.handleExceptionMsg(self,data)
    -- local blah = ""..cc.Director:getInstance():getTotalFrames()
    --  local b = G_BASEAPP:addView({
    --        uiName =  'UIDialog',
    --        uiInstanceName = blah
    --         }, 200)
    --     local func  = function()
    --         if(data.actionId == UIGameTableDouniu.CMD['READY']) then
    --             self['Button_readyup']:setEnabled(true)
    --         end
    --     end  

    --     b:setupDialog("信息",data.failedStr,func)  

--     actionId" 
-- failedStr"
-- failedType
--     if(data.actionId == UIGameTableDouniu.CMD['READY']) then
--         if(data.failedType == 0){
--                             room.actMgr.readyNoEnoughMoney();
--                         } 
--     else
--     end
--                         if(failedType == 0){
--                             room.actMgr.readyNoEnoughMoney();
--                         }
--                     }else{
--                         CommTipPopUtil.getCommTipPop(room.roomAct, msg).show();
--                     }
end


function UIGameTableDouniu:TCP_onConnected()
    --默认 斗地主 然后房间传-1 服务器分配
    print('UIGameTableDouniu:TCP_onConnected()')
    if G_LOADINGVIEW then
        G_LOADINGVIEW:removeSelf()
        G_LOADINGVIEW = nil 
    end
    local buffer = self:getLoginBuffer(self.tableType,self.friendID,self.RoomId)
    self.tcpGear:sendData(buffer) 
    self:scheduleHeartbeat()
    
        self:REQ_heartbeat() 
end

function UIGameTableDouniu:TCP_SYS_INFO(data)
    dump(data,'TCP_SYS_INFO')  

    GameTableCommon.showMsgByMsgType(self,data.infotype,data.info,data)
--     "TCP_SYS_INFO" = {
--     " HEXCMD " = "0x5E"
--     "CMD"      = 94(0x5E)
--     "info"     = "没人抢,第一张你最大,你的庄"
--     "infotype" = 1(0x1)
--     "siteid"   = 0(0x0)
-- }

    if data and data.info and string.find(data.info,'你的庄') then   
        self['Panel_player_1']:getChildByName('Text_multiply'):setVisible(true)  
        self['Panel_player_1']:getChildByName('Text_multiply'):setString("x1倍")  
    end
    -- self:showMsgByMsgType(data.infotype,data.info) 

end

function UIGameTableDouniu:clearTable()
    printf("CLEANING TABLE")
    self:stopSchedule("ROUND_OVER_DELAY")
    self:startCounddown('',0 )
    GameTableCommon.clearTable( self )
    GameTableCommon.setStaticMsg(self)
    self.lordMultiply = 1 
    for k,v in pairs(self.playerData) do 
        self.playerData[k].dnMul = 1
        self['Panel_player_'..v.displayID]:getChildByName('BitmapFontLabel_score'):setVisible(false)
        if self.playerData[k].displayedCards ~= nil then
            self.playerData[k].displayedCards:removeFromParent()
            self.playerData[k].displayedCards = nil
        end  
        self['Panel_player_'..v.displayID]:getChildByName('Image_bulltype'):setVisible(false)
        self.playerData[k].isSat = nil
        self.playerData[k].isDealer = nil 
 
       
    end
    for _,tbl in pairs(UIGameTableDouniu.selfShowdownCardTable) do
       for _,node in pairs(tbl) do
           node:removeFromParent()
       end
    end
    UIGameTableDouniu.selfShowdownCardTable = {}

    for i=1,3 do
        self['Text_calc_'..i]:setString("0")
    end
     self['Text_calc_sum']:setString("0")
     self['Button_readyup']:setEnabled(true)
     self['Button_changeTable']:setEnabled(true)
     if self.readyMoneyTag then 
        self['Button_changeTable']:setEnabled(self.PlayerData.coin>=self.readyMoneyTag)
     end 
    self:clearAllStatus()
    self:clearMultiplyAmount() 
    for i=1,5 do
        self['Button_card_'..i]:setVisible(false)
        self['Button_card_'..i].isPicked = false
        self['Button_card_'..i]:loadTextures('newcard/back.png','newcard/back.png','newcard/back.png',ccui.TextureResType.plistType)
        if self['Button_card_'..i].originalY then
            self['Button_card_'..i]:setPositionY(self['Button_card_'..i].originalY)
        end
    end
    self.hasBull = false
    self.pickedCardsCount = 0
    self.currentRoomState = UIGameTableDouniu.TableStateWait 
    self:setButtonsByStatus()
    local path = 'room/room_btn_green.png' 
    self['Button_have_bull']:loadTextures(path,path,path,ccui.TextureResType.plistType)
    -- self['Button_have_bull']:setTitleText("没牛")
    self['Button_have_bull']:getChildByName('Image_text'):loadTexture('room/Douniu_txt_no.png',ccui.TextureResType.plistType)

end

function UIGameTableDouniu:TCP_GAME_ROUND_OVER(data)
        dump(data,'TCP_GAME_ROUND_OVER') 

    -- self:stopSchedule("ROUND_OVER_DELAY")
    -- self:createSchedule("ROUND_OVER_DELAY",function() 
        -- self:stopSchedule("ROUND_OVER_DELAY") 
        self:startCounddown( "msg",0 )
        self['Button_have_bull']:setVisible(false) 
        self['Panel_calc']:setVisible(false)

    
        local argTable = {}
        argTable.infoTable = {}
    
        argTable.delegate = self
        for k,v in pairs(data.PlayInfoList) do
            local info = {}
            local curPlayer = self.playerData[v.seatID]  
            -- self.playerData[seatID].dnMul
            GameTableCommon.updatePlayerCoins(self, v.seatID,v.TotalChip )
            info.iconUrl  = curPlayer.PicUrl
            info.name  = curPlayer.Name
            if curPlayer.seatID == self.mySeatID then
                 info.name = "自己"
                info.isMyself = true
            end 
            info.coins  = v.WinLossChip
            info.sex  = curPlayer.Sex
            info.seatID  = curPlayer.seatID
    
            info.isDealer = curPlayer.isDealer 
            info.nType = curPlayer.nType
            printf("DID:%s, CardTypeMulti:%s,dnMul:%s,lordMultiply:%s",curPlayer.displayID,v.CardTypeMulti ,curPlayer.dnMul,self.lordMultiply)
            --info.mulText = v.CardTypeMulti * curPlayer.dnMul  * self.lordMultiply
            info.mulText = curPlayer.dnMul
            printf("info.mulText:%s",info.mulText )
    
            if v.seatID == self.mySeatID then
                if v.WinLossChip >= 0 then
                    argTable.isWon = true
                end
                local cardCalueTable = {}
                for i=1,5 do 
                    table.insert(cardCalueTable,self['Button_card_'..i].val)
                end
                -- dump(cardCalueTable,"cardCalueTable8888888888888888888888")
                argTable.cardsNode = self:arrangeCards(UIGameTableDouniu.ARRANGE_MIDDLE ,cardCalueTable)
                argTable.cardsNode:retain()
            end
-- c    ardsNode
            table.insert(argTable.infoTable,info) 
            -- BitmapFontLabel_score
            local displayID = self.playerData[v.seatID].displayID
            -- local score = self['Panel_player_'..displayID]:getChildByName('BitmapFontLabel_score')
            -- score:setVisible(true)
            -- local fntFile = "fonts/gameOverNum_title_win.fnt"
            -- if v.WinLossChip < 0 then 
            --     fntFile = "fonts/gameOverNum_title_lose.fnt"
            -- end
            -- score:setFntFile(fntFile) 
            -- score:setString(v.WinLossChip)  
            local coin = self['Panel_player_'..displayID]:getChildByName("Text_coins")
            if coin then 
                coin:setString(LuaTools.convertAmountChinese(v.TotalChip,10000)) 
            end
            if curPlayer.seatID == self.mySeatID then
                self.PlayerData.coin = v.TotalChip
            end
        end
    
    
        local sat = self.playerData[self.mySeatID].isSat
        if sat == true then  
            -- put POV player to first.
            for k,v in pairs(argTable.infoTable) do
                if v.seatID == self.mySeatID and k ~= 1 then
                    argTable.infoTable[k] , argTable.infoTable[1] = argTable.infoTable[1] , argTable.infoTable[k] 
                    break
                end
            end
    
            argTable.type = 'dn'
            argTable.readyCallback = function() 
                self:REQ_READY()  
                if self.resultPage and self.resultPage.removeSelf then 
                    self.resultPage:removeSelf()
                    self.resultPage = nil
                end
            end
            argTable.ctCallback = function() 
                self:PlayerCtrl_changeTable() 
                if self.resultPage and self.resultPage.removeSelf then 
                    self.resultPage:removeSelf()
                    self.resultPage = nil
                end
            end 
              
            dump(argTable,"argTable")
            -- self.resultPage = G_BASEAPP:addView('UIGameTableResult',5000,argTable)
        end
        -- self:clearTable()
    -- end,3)-- self:createSchedule("ROUND_OVER_DELAY"

    argTable.thisRoundMulti = self.thisRoundMulti
    if self.readyMoneyTag then 
        local abcd = (self.PlayerData.coin>=self.readyMoneyTag) and true or false 
        argTable.changeTabState = abcd 
    else 
        argTable.changeTabState =  true 
    end     
    self:createSchedule("ROUND_OVER_DELAY",function() 
        self:stopSchedule("ROUND_OVER_DELAY")
        self:clearTable()

        if sat == true then
            self.resultPage = G_BASEAPP:addView('UIGameTableResult',5000,argTable)
            self.resultPage:setVisible(false)
            self['Button_readyup']:setVisible(false)
            self['Button_changeTable']:setVisible(false)

            self:showResult(argTable)
        end  
        self['Button_readyup']:setEnabled(true) 
    end,1.5)
end

function UIGameTableDouniu:showResult(argTable)
    for k,v in pairs(argTable.infoTable) do
        self:showOneResult(v)
    end
end

function UIGameTableDouniu:showOneResult(info)
    local displayID = self.playerData[info.seatID].displayID
    local par = self['Panel_player_'..displayID]
    local size1 =par:getContentSize() 
    local total = info.coins
    if total > 0 and par:getChildByName('BMF_win') then 
        local num = (total < 10000) and total or LuaTools.convertAmountChinese(total)
        par:getChildByName('BMF_win'):setString('+'..num)
        par:getChildByName('BMF_win'):setVisible(true)
        local tempX,tempY = par:getChildByName('Image_avatar'):getPosition()
        par:getChildByName('BMF_win'):setPosition(tempX,tempY)
        local x,y = par:getChildByName('BMF_win'):getPosition()

        local tempHeight = size1.height-55
        if info.seatID == self.mySeatID then
            tempHeight = tempHeight + 25
        end
        local action1 = cc.MoveTo:create(1.0,cc.p(x,tempHeight))
        local function cb() 
            par:getChildByName('BMF_win'):setString('')
            par:getChildByName('BMF_win'):setVisible(false)
            par:getChildByName('BMF_win'):setPosition(cc.p(x,size1.height/2))
        end  
        par:getChildByName('BMF_win'):runAction(cc.Sequence:create(action1,
        cc.DelayTime:create(2),cc.CallFunc:create(cb) )) 
    elseif total < 0 and par:getChildByName('BMF_Loss') then 
        local num = (total> -10000) and math.abs(total) or LuaTools.convertAmountChinese(math.abs(total))
        par:getChildByName('BMF_Loss'):setString('-'..num)
        par:getChildByName('BMF_Loss'):setVisible(true)
        local tempX,tempY = par:getChildByName('Image_avatar'):getPosition()
        par:getChildByName('BMF_Loss'):setPosition(tempX,tempY)
        local x,y = par:getChildByName('BMF_Loss'):getPosition()

        local tempHeight = size1.height-55
        if info.seatID == self.mySeatID then
            tempHeight = tempHeight + 25
        end
        local action1 = cc.MoveTo:create(1.0,cc.p(x,tempHeight))
        local function cb() 
            par:getChildByName('BMF_Loss'):setString('')
            par:getChildByName('BMF_Loss'):setVisible(false)
            par:getChildByName('BMF_Loss'):setPosition(cc.p(x,size1.height/2))
        end  
        par:getChildByName('BMF_Loss'):runAction(cc.Sequence:create(action1,
        cc.DelayTime:create(2),cc.CallFunc:create(cb))) 
    else 
    end
end

function UIGameTableDouniu:TCP_HEARTBEAT(data)
    dump(data,'TCP_HEARTBEAT')
end





function UIGameTableDouniu:onCreate(argTable)

    LuaTools.beginWaiting(true)  
    argTable = argTable or {} 
    self.timeTable = {}
    dump(argTable,"UIGameTableDouniu:onCreate(argTable)")
    -- GameTableCommon.overrideBack( self ) 
    self.tableType  = argTable.tableType    or -1
    self.friendID   = argTable.friendID      or 0
    self.RoomId     = argTable.RoomId        or 0
    self.RoomLevel  = argTable.RoomLevel        or 0
    self.port       = argTable.port        or 0
    self.playerData = {}
    self.currentRoomState = UIGameTableDouniu.TableStateWait  
    self['Text_roomType']:setString("") 
    self.PlayerData =G_BASEAPP:getData('PlayerData')

    self['AtlasLabel_myCoins']:setString(LuaTools.convertAmountChinese(self.PlayerData.coin,10000))
    self['AtlasLabel_myDimonds']:setString(LuaTools.convertAmountChinese(self.PlayerData.gem,10000))

    self['Button_have_bull']:onTouch(self:getShowcardCallback())

    self.pickedCardsCount = 0
    self.currentRoomState = UIGameTableDouniu.TableStateWait 
    self.tcpGear = TCPGearbox.buildInstance({
            unpackerType = DataUnpacker.Type.GAME_Douniu, 
            delegate = self,  
            callbackPrefix = "TCP_",
            name = 'UIGameTableDouniu TCP',
            port = argTable.port--self.serverConfig.addr-- argTable.port or DEFAULT_TCP_PORT
        })
    -- for i=1,5 do
    --     self['Panel_player_'..i]:getChildByName('Image_bulltype'):setLocalZOrder(1000 + i) 
    -- end
    local function recruFunc()  
        self:addGobackEventAction(function() recruFunc() end) 
    end
    self:addGobackEventAction(function()
        recruFunc() 
    end)
    self.taskGameType = 2
    GameTableCommon.setupBasics( self ) 

    self['Button_have_bull']:setDontPlayDefaultSFX(true) 
    self['Panel_calc']:setDontPlayDefaultSFX(true)

    -- for i=1,5 do
    --     local par = self['Panel_player_'..i]:getChildByName('BMF_win')
    --     local x,y = par:getPosition()
    --     par:setPosition(x-50, y)

    --     par = self['Panel_player_'..i]:getChildByName('BMF_Loss')
    --     x,y = par:getPosition()
    --     par:setPosition(x-50, y)
    -- end
  
end
function UIGameTableDouniu:updateMyMoney(coin,gem)
    self['AtlasLabel_myCoins']:setString(LuaTools.convertAmountChinese(coin,10000))
    self['AtlasLabel_myDimonds']:setString(LuaTools.convertAmountChinese(gem,10000))
end 

return UIGameTableDouniu
