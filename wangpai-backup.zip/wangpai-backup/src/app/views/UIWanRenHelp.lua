local UIWanRenHelp = class("UIWanRenHelp", cc.load("mvc").ViewBase)

UIWanRenHelp.RESOURCE_FILENAME = "UIWanrRenHelp.csb"

UIWanRenHelp.RESOURCE_BINDING = { 
    ["Panel_main"]   = {["ended"] = "PlayerCtrl_Touch"}, 
    } 

local SHOW_DIS_TIME = 0.3

function UIWanRenHelp:PlayerCtrl_Touch()
    local function cb()
        self.app:removeView("UIWanRenHelp")
    end
    local closeAction = cc.MoveTo:create(SHOW_DIS_TIME,cc.p(1650,self["Panel_root"]:getPositionY()))
    local seq = cc.Sequence:create(closeAction,cc.CallFunc:create(cb),nil)
    self["Panel_root"]:runAction(seq)
end


function UIWanRenHelp:onCreate(data)
    local app = self:getApp()
    self.app = app

    local moveRight = cc.MoveTo:create(SHOW_DIS_TIME, cc.p(1280,self["Panel_root"]:getPositionY()))
    self["Panel_root"]:runAction(moveRight)
end

return UIWanRenHelp
