local UILottery = class("UILottery", cc.load("mvc").ViewBase)

UILottery.RESOURCE_FILENAME = "UILottery.csb"
UILottery.RESOURCE_PRELOADING = {"lottery.png"}

UILottery.RESOURCE_LOADING  = {
    --["res/background/mohuBg.png"] = {names = {"Image_bgAll"}}
}
local HttpHandler = require("app.network.HttpHandler")
UILottery.bt_LotteryNode = nil
UILottery.RESOURCE_BINDING = {
    ["Button_back"] = {["ended"] = "backEvent"},
    ["Button_one"]  = {["ended"] = "OneLottery"},
    ["Button_gogogo"]  = {["ended"] = "OneLottery"},
    ["Button_ten"]  = {["ended"] = "TenLottery"},
    ['Panel_reward']  = {["ended"] = "hideReward"},

    }
function UILottery:onCreate(cb)
    local app = self:getApp()
    self.app = app

    self.playerdata = app:getData('PlayerData')
    self.tool = app:getModel('Tools')
    self.config = app:getData('Config')
    self._callBack = cb 

    self.rewardImage = {'res_lottery/lottery1.png','res_lottery/lottery2.png','res_lottery/lottery3.png',
    'res_lottery/lottery4.png','res_lottery/lottery5.png','res_lottery/lottery6.png',
    'res_lottery/lottery7.png','res_lottery/lottery8.png','res_lottery/lottery9.png','res_lottery/lottery10.png'}
    
    self['Panel_oneReward']:setVisible(false)
    self.lastIndex = 1 
    self.updateLightPaused = false
    self:hideReward()
    self["Button_ten"]:setPressedActionEnabled(true)
    self["Button_one"]:setPressedActionEnabled(true)
    self.Image_role = self['Panel_role']:getChildByName('Image_role')

    self.role_effect1 = self['Panel_main']:getChildByName('Image_effect1')
    self.role_effect2 = self['Panel_main']:getChildByName('Image_effect2')

    self.rewardNum = {0,0,0,0,0,0,0,0,0,0}

    self.indexTable = {
    {type=6,index = 0,num=100},
    {type=7,index = 1,num=2},
    {type=1,index = 2,num=3000},
    {type=9,index = 3,num=1},
    {type=5,index = 4,num=5},
    {type=3,index = 5,num=1000000},
    {type=10,index = 6,num=5},
    {type=2,index = 7,num=50000},
    {type=10,index = 8,num=1},
    {type=8,index = 9,num=1},

}  
    local function cb1()
    local dataTable =     {
     ['uid']       =  tonumber(G_UID),
     ['token']     = G_TOKEN,
     ['cmd']       = HttpHandler.CMDTABLE.GET_LOTTERT,
    }
     local function succ(arg)
        for key=1,10 do 
            self.rewardNum[arg.types[key]] = arg.nums[key]
        end 
        self:updateImage(arg.types)
        self:updateNumber(arg.nums)
        self['Text_oneCost']:setString(tonumber(arg.free) == 0 and '1元宝' or '本次免费')
        if tonumber(arg.free) == 0 then 
            self['Image_inside_right']:loadTexture('res_lottery/1.png',ccui.TextureResType.plistType)
            self['Image_inside_left']:loadTexture('res_lottery/1.png',ccui.TextureResType.plistType)
            self['Image_switch_bg']:loadTexture('res_lottery/di_zi.png',ccui.TextureResType.plistType)
            --self.Image_role:initWithSpriteFrameName('res_lottery/role1.png')
            self.switchTag =true 
        end     
     end  
     self.tool:fastRequest(dataTable,succ)
    end 

     LuaTools.enterActionScaledWithMask(self['Panel_main'],cb1)


     local blink = 1   

     local a1 = cc.FadeOut:create(1)
     self['Image_inside']:runAction(cc.RepeatForever:create(cc.Sequence:create(a1, a1:reverse())))

     self:createSchedule('updateLight', function()  
        if self.updateLightPaused == true then 
           self['Image_inside_left']:setVisible(false)
           self['Image_inside_right']:setVisible(false) 
            return end
        if blink%2 == 1 then 
           self['Image_inside_left']:setVisible(true)
           self['Image_inside_right']:setVisible(false)   
        else 
           self['Image_inside_left']:setVisible(false)
           self['Image_inside_right']:setVisible(true)  
        end 
        blink = blink +1 
        end ,0.5)

end

function UILottery:getInxTypes(index)
    local tag 
    for key ,var in pairs(self.indexTable) do 
        if var.index == index then 
            tag =var.type 
            break
        end 
    end 
    return tag         
end   

function UILottery:getInxNums(index)
    local tag 
    for key ,var in pairs(self.indexTable) do 
        if var.index == index then 
            tag =var.num 
            break
        end 
    end 
    return tag         
end   

function UILottery:OneLottery()
    
    local dataTable =     {
     ['uid']       =  tonumber(G_UID),
     ['token']     = G_TOKEN,
     ['cmd']       = HttpHandler.CMDTABLE.LOTTERY_ONE,
    }
    local function succ(arg)
        self["Button_one"]:setTouchEnabled(false) 
        self["Button_ten"]:setTouchEnabled(false)
        self["Button_gogogo"]:setTouchEnabled(false)
        self["Button_back"]:setTouchEnabled(false) 
        self['Text_oneCost']:setString('1元宝')
        if self._callBack then 
           self._callBack()
        end     
        self:oneReward(arg.index+1,arg.index)

        local function cb()
            self.playerdata.coin       = arg.coin or self.playerdata.coin 
            self.playerdata.gem        = arg.gem or self.playerdata.gem
            self.playerdata.vip_level  = arg.vip_level or self.playerdata.vip_level
            self.playerdata.accu       = arg.accu or self.playerdata.accu  
            self.playerdata.prop[1]    = arg.prop['4'] or self.playerdata.prop[1] 
            self.playerdata.prop[2]    = arg.prop['7'] or self.playerdata.prop[2] 
            self.playerdata.telfee     = arg.telfee or self.playerdata.telfee 
            self.playerdata.vip_day    = arg.vip_day or self.playerdata.vip_day  
            self.playerdata.vipvalid   = arg.vipvalid or self.playerdata.vipvalid
            if self.app:getView('UIMainTop') then 
               self.app:callMethod('UIMainTop','updateWealth')
            end  
        end
        self["Button_gogogo"]:runAction(cc.Sequence:create(cc.DelayTime:create(5),cc.CallFunc:create(cb) ))
    end

    local function fail(arg)
        if arg.msg then
            self.tool:showAlert(arg.msg)
            if string.find(arg.msg,'不足') then 
               G_BASEAPP:addView('UIShopDiamond',self:getLocalZOrder()+1)
            end  
        end
    end     
    self.tool:fastRequest(dataTable,succ,fail) 
end     

function UILottery:oneReward(index,num)
    if not index then index = math.random(1,10) end  
    if index < self.lastIndex then  index = index + 10  end
    local action1 = cc.RotateBy:create(5, 360 * 4+(index-self.lastIndex)*36)
    self.updateLightPaused = true 

    audio.playSound(Sound.SoundTable['sfx']['Lottery_Begin'] , false)

    local action2 = cc.Speed:create(action1,3)    
    local function callback()
       --self.tool:showTips(msg)
       if  self['Panel_oneReward']:getChildByName('LotteryEffect')  then 
           self['Panel_oneReward']:removeChildByName('LotteryEffect')
       end 
       audio.playSound(Sound.SoundTable['sfx']['Lottery_Reward'] , false)
       self['Panel_oneReward']:setVisible(true)
       self['Image_oneReward']:setScale(1)
       local aaa = self:getInxNums(num)
       self['Text_oneReward']:setString('x'..aaa)
       self['Image_oneReward']:loadTexture(self.rewardImage[self:getInxTypes(num)],ccui.TextureResType.plistType)
		--if UILottery.bt_LotteryNode ~= nil then
			--UILottery.bt_LotteryNode:removeFromParent()
			--UILottery.bt_LotteryNode = nil
		--end
        local bt_LotteryNode = cc.CSLoader:createNode('Animation_lottery_light1.csb') 
        bt_LotteryNode:setPosition(cc.p(self['Panel_oneReward']:getContentSize().width/2,self['Panel_oneReward']:getContentSize().height/2))
        local action = cc.CSLoader:createTimeline('Animation_lottery_light1.csb')
        bt_LotteryNode:runAction(action)
        action:gotoFrameAndPlay(0,false)
        bt_LotteryNode:setName('LotteryEffect')
        self['Panel_oneReward']:addChild(bt_LotteryNode,1)
        self['Panel_oneReward']:getChildByName('Image_oneReward'):setLocalZOrder(11) 
        local function cbb()
            self['Panel_oneReward']:setVisible(false)
            self['Panel_oneReward']:removeChildByName('LotteryEffect')
        end     
       self['Image_oneReward']:runAction(cc.Sequence:create(cc.ScaleTo:create(1,1.25),cc.DelayTime:create(2),cc.CallFunc:create(cbb)))
       
    end 

    local function call1() 
        --audio.stopAllSounds()

        --audio.playSound(Sound.SoundTable['sfx']['Lottery_3'] , false)
        self.Image_role:setVisible(false)
        local t = 0.5
        local rotate = self['Pointer_go']:getRotation() 
        self.role_effect1:setRotation(rotate-180)
        self.role_effect2:setRotation(rotate-180)
        self.role_effect1:setVisible(true)
        self.role_effect2:setVisible(true)
        local act1 = cc.RotateBy:create(t,180)
        local act2 = cc.RotateBy:create(t,-180)
        self.role_effect1:runAction(act1)
        self.role_effect2:runAction(act2)
        self['Image_effect']:setRotation(rotate)
        local blink = cc.Blink:create(1.5,8)
        local function aaaa() 
            self.role_effect1:setVisible(false)
            self.role_effect2:setVisible(false)
            self['Image_effect']:setVisible(true)
        end     
        self['Image_effect']:runAction(cc.Sequence:create(cc.DelayTime:create(t),cc.CallFunc:create(aaaa),blink))
    end        
    
    local function callback1()
       self['Image_effect']:setVisible(false)
       self.updateLightPaused  = false
       self["Button_one"]:setTouchEnabled(true)
       self["Button_ten"]:setTouchEnabled(true)
       self["Button_gogogo"]:setTouchEnabled(true)
       self["Button_back"]:setTouchEnabled(true) 
       if not  self.switchTag   then          
            self['Image_inside_right']:loadTexture('res_lottery/1.png',ccui.TextureResType.plistType)
            self['Image_inside_left']:loadTexture('res_lottery/1.png',ccui.TextureResType.plistType)
            self['Image_switch_bg']:loadTexture('res_lottery/di_zi.png',ccui.TextureResType.plistType) 
        end   
    end  

    self['Pointer_go']:runAction(action2)
    self.Image_role:setVisible(true) 
    --self.Image_role:setOpacity(160)

    self.Image_role:runAction(action2:clone())
    self['Panel_main']:runAction(cc.Sequence:create(cc.DelayTime:create(2),cc.CallFunc:create(call1),
        cc.DelayTime:create(2.5),cc.CallFunc:create(callback),
        cc.DelayTime:create(1),cc.CallFunc:create(callback1)))
    self.lastIndex  = (index > 10 and (index-10) or index )
end

 

function UILottery:TenLottery()
    
    local dataTable =     {
     ['uid']       =  tonumber(G_UID),
     ['token']     = G_TOKEN,
     ['cmd']       = HttpHandler.CMDTABLE.LOTTERY_TEN,
    }
    local function succ(arg)
        self:tenReward(arg)
        self["Button_ten"]:setTouchEnabled(false)
        self["Button_one"]:setTouchEnabled(false)
        self["Button_gogogo"]:setTouchEnabled(false)
        --self["Button_back"]:setTouchEnabled(false) 
        local function cb()
            self.playerdata.coin       = arg.coin or self.playerdata.coin 
            self.playerdata.gem        = arg.gem or self.playerdata.gem
            self.playerdata.vip_level  = arg.vip_level or self.playerdata.vip_level
            self.playerdata.accu       = arg.accu or self.playerdata.accu  
            self.playerdata.prop[1]    = arg.prop['4'] or self.playerdata.prop[1] 
            self.playerdata.prop[2]    = arg.prop['7'] or self.playerdata.prop[2] 
            self.playerdata.telfee     = arg.telfee or self.playerdata.telfee 
            self.playerdata.vip_day    = arg.vip_day or self.playerdata.vip_day 
            self.playerdata.vipvalid   = arg.vipvalid or self.playerdata.vipvalid

            if self.app:getView('UIMainTop') then 
               self.app:callMethod('UIMainTop','updateWealth')
            end  
        end 
        self["Button_gogogo"]:runAction(cc.Sequence:create(cc.DelayTime:create(5),cc.CallFunc:create(cb) ))

    end
    local function fail(arg)
        if arg.msg then
            self.tool:showAlert(arg.msg)
            if string.find(arg.msg,'不足') then 
               G_BASEAPP:addView('UIShopDiamond',self:getLocalZOrder()+1)
            end  
        end
    end  
    self.tool:fastRequest(dataTable,succ,fail)
    self['Panel_reward']:setTouchEnabled(false)

end     

function UILottery:tenReward(info) 
    if type(info) ~= 'table'  then  return end 
    self['Panel_reward']:setVisible(true)
    self.playerdata.gem        = info.gem or self.playerdata.gem
    self.playerdata.vip_level  = info.vip_level or self.playerdata.vip_level
    local tag = 1 
    local function callback() 
        local temp = self:DoinitNumber(self:getInxNums(info.indexs[tag]))--(self.rewardNum[info.indexs[tag]])
        local par = self['Panel_reward']:getChildByName('Panel_ten_rew'..tag)
        par:setVisible(true)  
        par:getChildByName('Image_reward'):setVisible(true)      
        par:getChildByName('Image_reward'):loadTexture(self.rewardImage[self:getInxTypes(info.indexs[tag])],ccui.TextureResType.plistType)

       if  self['Panel_reward']:getChildByName('Panel_ten_rew'..tag):getChildByName('LotteryEffectTen') then 
           self['Panel_reward']:getChildByName('Panel_ten_rew'..tag):removeChildByName('LotteryEffectTen')
       end 
		--if UILottery.bt_LotteryNode ~= nil then
			--UILottery.bt_LotteryNode:removeFromParent()
			--UILottery.bt_LotteryNode = nil
		--end
        local bt_LotteryNode = cc.CSLoader:createNode('Animation_lottery_light2.csb') 
        bt_LotteryNode:setPosition(cc.p(par:getContentSize().width/2,par:getContentSize().height/2))
        local action = cc.CSLoader:createTimeline('Animation_lottery_light2.csb')
        bt_LotteryNode:runAction(action)
        action:gotoFrameAndPlay(0,false)
        par:addChild(bt_LotteryNode,100)
        bt_LotteryNode:setName('LotteryEffectTen')
        audio.playSound(Sound.SoundTable['sfx']['Lottery_Ten'] , false)


        par:getChildByName('Text_12'):setString(temp or '')
        if tag == 10 then 
           self:stopSchedule('reward') 
           self['Panel_reward']:setTouchEnabled(true)
           self["Button_ten"]:setTouchEnabled(true)
           self["Button_one"]:setTouchEnabled(true)
           local function cbbb() 
               audio.stopAllSounds()
               for key =1 ,10 do 
                   if  self['Panel_reward']:getChildByName('Panel_ten_rew'..key):getChildByName('LotteryEffectTen') then 
                       self['Panel_reward']:getChildByName('Panel_ten_rew'..key):removeChildByName('LotteryEffectTen')
                   end     
               end  
           end 
           self["Button_one"]:runAction(cc.Sequence:create(cc.DelayTime:create(0.6),cc.CallFunc:create(cbbb)))
        end    
        tag = tag + 1    
    end     
    self:createSchedule('reward',callback,0.6)

end 

function UILottery:updateImage(info)
    if type(info) ~= 'table' or #info == 0 then  return end 
    
    for key,var in pairs(info) do  
        local image = ccui.ImageView:create(self.rewardImage[var],ccui.TextureResType.plistType)
        -- if var == 9 then 
        --     image:setScale(0.9)
        -- end     
        self['Panel_reward'..key]:addChild(image)
        local size = self['Panel_reward'..key]:getContentSize()
        image:setPosition(size.width/2,size.height/2)
    end  
end     

function UILottery:DoinitNumber(num) 
    local str  
    if tonumber(num) >=1000 and tonumber(num)<10000 then  
       str = 'x'..(tonumber(num)/1000)..'千' 
    elseif tonumber(num) >=10000 then 
       str = 'x'..(tonumber(num)/10000)..'万'
    else  
       str = 'x'..num       
    end 
    return str 
end 

function UILottery:updateNumber(info)
    if type(info) ~= 'table' or #info == 0 then  return end 

    for key,var in pairs(info) do 
        local temp = self:DoinitNumber(var)
        self['Panel_role']:getChildByName('Panel_reward'..key):getChildByName('Text_2'):setString(temp or '')
    end      
end     

function UILottery:backEvent(event)
    --if UILottery.bt_LotteryNode ~= nil then
		--UILottery.bt_LotteryNode:removeFromParent()
		--UILottery.bt_LotteryNode = nil
	--end
    self:stopSchedule('updateLight')
    --self.app:removeView('UILottery')  
    LuaTools.viewAction1Over(self['Panel_main'],'UILottery')
    audio.stopAllSounds()
end

function UILottery:hideReward()
    
    self['Panel_reward']:setVisible(false)
    for key =1 ,10 do 
        self['Panel_reward']:getChildByName('Panel_ten_rew'..key):setVisible(false)
    end  
end 

return UILottery
















