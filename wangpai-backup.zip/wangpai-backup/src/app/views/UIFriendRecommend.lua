local UIFriendRecommend = class("UIFriendRecommend", cc.load("mvc").ViewBase)

UIFriendRecommend.RESOURCE_FILENAME = "UIFriendRecommand.csb"
--UIFriendRecommend.RESOURCE_PRELOADING = {"main.png"}
--UIFriendRecommend.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIFriendRecommend.RESOURCE_BINDING = { 
    ["Button_Close"] = {["ended"] = "close"},
    ["Button_copy"] = {["ended"] = "onCopy"},
    ["Button_thanksFriend"] = {["ended"] = "onThanksFriend"},
    ["Button_recommand"] = {["ended"] = "onRecommend"},

    }

function UIFriendRecommend:close()
    -- body
    -- self:removeSelf()
    
    LuaTools.viewAction1Over(self['Panel_main'],"UIFriendRecommend")
end

function UIFriendRecommend:onCopy()
       
    local text = "是一款非常刺激好玩的棋牌游戏, 成功加入本游戏, 系统将赠送您和您的推荐人各5万金币."
    local url = "http://ddz.217play.com:17179/friendshare?uid="..self.pData.uid
    if true == LuaTools.copyToClipBoard(text, url) then
        self.tool:showTips("分享内容已经复制")
    else
        self.tool:showTips("分享内容复制失败！")
    end
end

function UIFriendRecommend:onThanksFriend()   
   
   self.app:addView('UIFriendThanks',self:getLocalZOrder()+10)
   self:removeSelf()
end

function UIFriendRecommend:onRecommend()  
     
    local url =  "http://ddz.217play.com:17179/friendshare?uid="..self.pData.uid
    local title = "推荐得大奖"
    local content = "是一款非常刺激好玩的棋牌游戏, 成功加入本游戏, 系统将赠送您和您的推荐人各5万金币."
    LuaTools.share(url, title, content)
end



function UIFriendRecommend:onCreate(type)
    local app = self:getApp()
    self.app = app
    self.pData = app:getData('PlayerData')
    self.config = app:getData('Config')
    LuaTools.viewAction1(self['Panel_main'])

    self.tool = app:getModel('Tools')
    local appName = '云中斗地主'
    local url =  "http://ddz.217play.com:17179/friendshare?uid="..self.pData.uid
    local msg = '每成功推荐一位新玩家加入'..appName..',系统将赠送您5万金币,新玩家也能获取5万金币，多推多得金币。'
    self['Text_string']:setString(msg)
    self['Text_url']:setString(url)
end

return UIFriendRecommend
