local UIPreLoading = class("UIPreLoading", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
local scheduler = require("app.models.QScheduler")
UIPreLoading.RESOURCE_FILENAME = "UIPreLoading.csb"

--printWarning
-- UILoading.RESOURCE_PRELOADING = {"res/background/login_bg.png"}
-- UILoading.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}} }

UIPreLoading.RESOURCE_BINDING = {
    -- ["Button_findPsw"]  = {["ended"] = "enterFind"},
    -- ["Button_register"] = {["ended"] = "enterReg"},

}
 

function UIPreLoading:onCreate() 
     
    self.app  = self:getApp() 
    self.tool = self.app:getModel('Tools') 
    self.main = self.app:getModel('Main') 
    self.config = self.app:getData('Config')
    self.pData = self.app:getData('PlayerData')
    
    self['Image_rotation']:runAction(cc.RepeatForever:create(cc.RotateBy:create(1.5, 360)))
    G_BASEAPP:addView('UIMain',-100, true)

end



 
return UIPreLoading









