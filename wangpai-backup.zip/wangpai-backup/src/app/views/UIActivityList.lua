local UIActivityList = class("UIActivityList", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
UIActivityList.RESOURCE_FILENAME = "UIActivityList.csb"
--UIActivity.RESOURCE_PRELOADING = {"main.png"}
--UIActivity.RESOURCE_LOADING  = { ["res/background/mohuBg.png"] = {names = {"Image_bgAll"}} }

UIActivityList.RESOURCE_BINDING = { 
    ["Button_daily"]  = {["ended"] = "enterDaily"},
    --["ListView_Activities"]     = {["ON_SELECTED_ITEM_END"] = "selectEvent"},   
    }


function UIActivityList:enterDaily()
    if not self.app:getView('UIDailypacks') then 
       self.app:addView('UIDailypacks',11000)
    end    
end    

function UIActivityList:onCreate()
    -- local function recruFunc()  
    --     print("======UIActivity:onCreate()======overrided==========================")  
    --     self:addGobackEventAction(function() recruFunc() end) 
    -- end
    -- self:addGobackEventAction(function()
    --     recruFunc() 
    -- end)
    local app = self:getApp()
    self.app = app
    self.config = app:getData('Config')
    self.tool  = app:getModel('Tools')
    self.pData = self.app:getData('PlayerData')

    -- self['Button_pointGet']:removeFromParent() 
    -- if self.pData.scoreActive == 1 then --开启
    --    self['ListView_activity']:addChild(self['Button_pointGet'])
    -- end  

    self['Button_daily']:removeFromParent()
    if self.pData.dailyProduct == 1 then --开启
       self['ListView_activity']:addChild(self['Button_daily'])
    end   


end     


return UIActivityList
