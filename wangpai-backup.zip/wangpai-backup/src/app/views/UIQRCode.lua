﻿local UIQRCode = class("UIQRCode", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")

UIQRCode.RESOURCE_FILENAME = "UIQRCode.csb"
--UIAlert.RESOURCE_PRELOADING = {"main.png"}
--UIAlert.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIQRCode.RESOURCE_BINDING  = { 
     -- ['Panel_main']       = {["ended"] = "close"},
      ['Button_back']      = {["ended"] = "close"},
      ['Button_leftCode']  = {["ended"] = "leftQECode"},
      ['Button_rightCode'] = {["ended"] = "rightQECode"},
    } 

function UIQRCode:onCreate()
    local app = self:getApp()
    self.app = app
    self.tool = app:getModel('Tools')
    local function cb()
      self['Panel_black']:setVisible(true)
      self['Panel_black']:setEnabled(false)
    end  

    LuaTools.viewAction1(self["Panel_main"],cb())
end
 
function UIQRCode:leftQECode()  
     self:exec('Lcode')
end 

function UIQRCode:rightQECode()  
     self:exec('Rcode') 
end 	

function UIQRCode:exec(str) 
     
    local function onShareSuccess(arg)
        print("successs")
        self.tool:showAlert('分享成功')
    end

    local function onShareFailed(arg)
        
        if(arg=="noApp") then
            self.tool:showAlert('未安装微信，分享失败')
        else
            self.tool:showAlert("分享失败")
        end
    end


    --local path = cc.FileUtils:getInstance():getWritablePath() ..'wx_share_temp.png'
    local path = 'wx_share_temp.png'
    -- dump(path,"XXXXXXXXXXXXXXX") 
     LuaTools.saveNodeToFile(cc.Sprite:create('background/'..str..'.png'),path)
    self:createSchedule("blah",
                         function()
                            self:stopSchedule("blah")
                            local SDKHandler = require('app.network.SDKHandler')
                            local handler = SDKHandler.Type.SHARE_WEIXIN 
                            local sdk = SDKHandler.getInstance(handler,'SHARE_WEIXIN')

                            local test={}
                            sdk:SDKShare({onSueccCallback = onShareSuccess,
                                          onPendingCallback = function() print('onPendingCallback') end,
                                          onErrorCallback = onShareFailed},
                                          test)
                         end,
                         1.0)
end
 


function UIQRCode:close()
	--self['Panel_black']:setVisible(false)
    LuaTools.viewAction1Over(self["Panel_main"],"UIQRCode")
end 

return UIQRCode 
