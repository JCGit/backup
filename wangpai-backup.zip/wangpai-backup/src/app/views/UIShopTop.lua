local UIShopTop = class("UIShopTop", cc.load("mvc").ViewBase)
UIShopTop.RESOURCE_FILENAME = "UIShopTop.csb"
--UIShopTop.RESOURCE_PRELOADING = {"shop.png"}
--UIShopTop.RESOURCE_LOADING  = {    ["res/background/mohuBg.png"] = {names = {"Image_bgAll"}}}
UIShopTop.RESOURCE_BINDING = {
    ["Button_Close"] = {["ended"] = "onClose"},
    ["Button_charge"] = {["ended"] = "onCharge"},
}

function UIShopTop:onCreate()
    local app = self:getApp()
    self.app = app
    self.tool = app:getModel('Tools')
    LuaTools.viewAction2(self['Panel_main'], nil, false)
    self["Button_charge"]:setVisible(false)
end

function UIShopTop:onClose()
	self.app:callMethod("UIShop", "onClose")
    self:onExitAction()
end

function UIShopTop:onExitAction()
    LuaTools.viewAction2Over(self['Panel_main'],'UIShopTop')
end

function UIShopTop:onCharge()
    
    self.app:addView('UIShopDiamond',self:getLocalZOrder() +1, function() 
        self.app:callMethod('UIShop','updateContent')
        end)
end
return UIShopTop

