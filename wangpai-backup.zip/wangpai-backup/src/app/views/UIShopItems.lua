local UIShopItems = class("UIShopItems", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
require "cocos.cocos2d.json"
UIShopItems.RESOURCE_FILENAME = "UIShopItems.csb"
--UIShopProp.RESOURCE_PRELOADING = {"main.png"}
--UIShopProp.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIShopItems.RESOURCE_BINDING = {
   
}

--初始化
function UIShopItems:onCreate()
    local app = self:getApp()
    self.app = app
    self.tool = app:getModel('Tools')
    self:setSkipGoBack(true )
    self.pData = self.app:getData('PlayerData')
    self['Image_bgd']:setVisible(false)
    self.panelMain = self['Panel_main']
    self.panelMain:setVisible(false)
    self.lastGiftBubble = nil
    
    self:setVisible(false)
end

function UIShopItems:getPanelMain()
    return self['Panel_main']
end

--初始化UI
function UIShopItems:init()
    if #self.pData.shopItems == 0 then
        self:requestGetProduct()
    else
        self:initProductList()
    end
    self:setVisible(true)
end

--初始化道具
function UIShopItems:initProductList()
    local function onBuy(event)
        if event.name == 'ended' then
            
            local indexSel = event.target:getTag()
            local tInfo = {}
            tInfo.price = self.pData.shopItems[indexSel].price
            tInfo.pid = self.pData.shopItems[indexSel].pid
            tInfo.imgPath = self.itemImages[indexSel]
            self.app:addView('UIShopSubviews', self:getLocalZOrder() + 1, 1, tInfo)
        end
    end

        --点击购买
    local function onBuyVip(event)
        if event.name == 'ended' then 
            local indexSel = event.target:getTag()-2
            self:requestBuyProduct(self.pData.shopVip[indexSel].pid,1)
        end
    end
    self.toolDesc = {
                "可以将VIP等级比您低的玩家，在私人场除外，踢出房间。",
                "可以发广播给所有人，每次使用消耗1个喇叭。",
                "VIP周卡：尊享VIP特权，VIP成长值+7，踢人卡+3，小喇叭+3，另额外赠送2万金币",
                "VIP月卡：尊享VIP特权，VIP成长值+30，踢人卡+10，小喇叭+10，另额外赠送5万金币",
                "VIP半年卡：尊享VIP特权，VIP成长值+180，踢人卡+50，小喇叭+50，另额外赠送25万金币",
            }

    self.itemImages = {"res_shop/img_kick.png","res_shop/img_horn.png",'res_shop/img_vipcard1.png'
                      ,'res_shop/img_vipcard2.png','res_shop/img_vipcard3.png'}
    for k=1, 5  do
        local item = k>2 and self['Panel_Vip_model']:clone() or  self['Panel_Item_model']:clone()
        if k<=2 then 
            item:getChildByName('Text_cost'):setString(self.pData.shopItems[k].price.."元宝/个")
            item:getChildByName('Text_desc'):setString(self.toolDesc[k])
            item:getChildByName('Text_title'):setString(self.pData.shopItems[k].name)
            item:getChildByName('Image_item'):loadTexture(self.itemImages[k], ccui.TextureResType.plistType)
            local btbuy = item:getChildByName('Button_buy')
            btbuy:onTouch(onBuy)
            btbuy:setTag(k)        
        else  
            item:getChildByName('Image_item'):loadTexture(self.itemImages[k], ccui.TextureResType.plistType)
            item:getChildByName('Text_desc'):setString(self.toolDesc[k])
            item:getChildByName('Text_title'):setString(self.pData.shopVip[k-2].name)
            local bt = item:getChildByName('Button_buy')
            bt:getChildByName('Text_cost'):setString(self.pData.shopVip[k-2].price)
            bt:onTouch(onBuyVip)
            bt:setTouchEnabled(true)
            bt:setTag(k)
        end     
        item:setVisible(true)
        item:setBackGroundColorOpacity(0)  
        self['ListView_Items']:pushBackCustomItem(item)
    end
    self.panelMain:setVisible(true)
    self.panelMain:setBackGroundColorOpacity(0)
end

function UIShopItems:parseProductData(data)
    self.pData.shopItems = { --desc, name, pid, price, icon
        }
    self.pData.shopVip = { --desc, name, pid, price, icon
        }

    for k, v in ipairs(data.prop) do
        local subList = {}
        subList.desc = v.description
        subList.name = v.name
        subList.pid = v.pid 
        subList.price = v.price
        self.pData.shopItems[k] = subList
    end


    for k, v in ipairs(data.vip) do
        local subList = {}
        subList.desc = v.description
        subList.name = v.name
        subList.pid = v.pid 
        subList.price = v.price
        self.pData.shopVip[k] = subList
    end

    self:initProductList()
end

function UIShopItems:requestGetProduct()
    local dataTable   =     {
        ['uid']       = self.pData.uid,
        ['token']     = self.pData.token,
        -- ['cid']       = 2,
        ['ver']       = 1,
        ['cmd']       = HttpHandler.CMDTABLE.NEW_PRODUCT,
    }
    local function succ(arg)
        self:parseProductData(arg)
    end
    local function fail(arg)
        if arg.msg then
            self.tool:showAlert(arg.msg)
        end
    end
    self.tool:fastRequest(dataTable,succ,fail)
end

function UIShopItems:requestBuyProduct(pid, num)
    local dataTable =     {
        ['uid']      = self.pData.uid,
        ['token']    = self.pData.token,
        ['pid']      = pid,
        ['number']    = num,
        ['cmd']       = HttpHandler.CMDTABLE.BUY_PRODUCT,
    }
    local function succ(arg)
        self.pData.coin = tonumber( arg.coin ) or 0
        self.pData.gem = tonumber(arg.gem ) or 0
        self.pData.vip_type = tonumber( arg.vip_type ) or 0
        self.pData.vip_level = tonumber( arg.vip_level ) or 0
        self.pData.vip_day = tonumber( arg.vip_day ) or 0
        self.pData.vip_time = arg.vip_time or ""
        self.pData.vipvalid = arg.vipvalid or 0
        if arg.gift then 
            for k, v in pairs(arg.gift) do
                self.pData.gift[tonumber(k)] = v  or 0
            end
        else
            for k = 1, #self.pData.gift do
                self.pData.gift[k] = 0
            end
        end 
        if arg.prop  then 
            self.pData.prop[3] = arg.prop['1'] or self.pData.prop[3]
            self.pData.prop[2] = arg.prop['7'] or self.pData.prop[2]
            self.pData.prop[1] = arg.prop['4'] or self.pData.prop[1]
        end 
        self.tool:showTips(arg.msg)
        self.app:callMethod('UIShop','updateContent')
    end
    local function fail(arg)
        if arg.msg then
            self.tool:showAlert(arg.msg)
            -- if string.find(arg.msg,'不足') then 
            --    G_BASEAPP:addView('UIShopDiamond',self:getLocalZOrder()+1)
            -- end  
        end
    end
    self.tool:fastRequest(dataTable,succ, fail)
end

return UIShopItems
