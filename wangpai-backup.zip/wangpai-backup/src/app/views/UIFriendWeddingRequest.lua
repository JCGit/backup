
local UIFriendWeddingRequest = class("UIFriendWeddingRequest", cc.load("mvc").ViewBase)
UIFriendWeddingRequest.RESOURCE_FILENAME = "UIFriendWeddingRequest.csb"
--UIFriendWeddingRequest.RESOURCE_PRELOADING = {"social.png"}
--UIFriendWeddingRequest.RESOURCE_LOADING  = {["res/background/mohuBg.png"] = {names = {"Image_bgAll"}}}
UIFriendWeddingRequest.RESOURCE_BINDING = {
    ["Button_refuse"]  = {["ended"] = "refuse"},
    ["Button_accept"]  = {["ended"] = "accetp"},
    
}



function UIFriendWeddingRequest:onCreate(uid,name)
    local app = self:getApp()
    LuaTools.viewAction1(self['Panel_bg'])
    self.app = app
    local temp= {'有多少遗憾因为错过，有多少错过因为误解，有多少误解因为隔阂，有多少隔阂源于距离，不想再有距离，只愿和你永远相伴不分离，嫁给我!此生相依',
    '你的幸福是我今生最大的追求，你的微笑是我今生最大的满足，你的满意是我今生最大的收获，亲爱的，嫁给我好吗，因为娶到你是我今生最大的福气',
    '装不下多少问候，也写不出多少真情，只知道没有你在身边，连呼吸都觉得沉重，早已不喜欢分离重逢，只有永远相伴才能幸福永久，嫁给我，让我们共写人生',
    '那些爱称早已熟练，那些许诺早已兑现，那些开心依旧在心田，那些浪漫永存脑海间，和你在一起，快乐让我心翩跹，和你永相伴，即使人生短暂，也无遗憾，嫁给我，和我一起开心浪漫',
    '嫁给我好吗?虽然我知道这句话很老套，但是它却包含着我最真挚的爱意。以后的人生即使平淡，你也绝对是我的唯一',
    '想每天看到你的笑颜，想陪你哭，陪你笑，陪你一起走完人生的路。答应嫁给我，答应陪着我，让我们手牵手一辈子走下去',
    '你在我心里是唯一，无论缺点优点，都会是我唯一的记忆。爱你，不需要太多的言语，嫁给我吧，此爱一生不离去',
    '爱就一个字，却包含了海枯石烂的承诺，执子之手与子偕老的宿愿，荣辱与共其利断金的情愫，相敬如宾的一生追求。我爱你，有爱就要大声的告诉你，嫁给我吧!',
    '爱是风雨同舟;爱是患难与共。爱是执子之手，与之偕老。亲爱的，嫁给我吧，让我们相依为命，直到白首，依然相牵，笑看花开花谢，潮涨潮落，云卷云舒，朝霞夕阳',
    '多少孤单寂寞的夜，因为分离，多少思念深深的请，因为牵挂，多少开心浪漫的回忆，因为恋，多想和你永远在一起，因为人生短暂，嫁给我，让我们的人生不再孤单',
    '没有钻戒，没有玫瑰，没有花好圆月的时刻，也没有亲朋好友的见证，我只想对着苍天，对着你的手机说，嫁给我吧，让我们一起谱写开心幸福的人生',
    '我并不完美，但我会因为爱你而成长，我并不富有，但我会尽我所能建筑你的幸福，嫁给我吧，让我们手挽手，共同走进一个温暖的地方名字叫做家!',
    '一人是孤单，二人是爱，我不要关爱，友爱，恋爱，我要你做我的新娘，穿上婚纱，和我携手走在人生的旅途，我的胸怀就是你的避风港，你的安乐窝，许你一生一世的爱，一生一世的情',
    '花开花谢几多时，雁来雁在声渐老，一切皆变换，唯有我们的爱依然在。答应嫁给我好吗，今生爱你的心绝不会改',
    '真正的爱情不需要过于深情的言语，真正的爱情走过平淡，依然能够绽放美丽。不奢求太多，只愿这一生你能陪我走下去，嫁给我好吗?',
    '亲爱的没有海誓山盟，没有海枯石烂，只想问一问你是否愿意陪我走进婚姻的殿堂。从此我的生命里除了你，依旧还是你',
    '你与我并肩踏上爱情这条路，往前走莫回顾，珍藏起牵手的幸福。但愿你也能与我并肩踏上婚姻这条路，无论有多少困难，我们的爱一定不会改变。',
    '我总是不停的错过。错过初升的太阳，错过深秋的落叶。错过温馨的黄昏。我知道自己会后悔莫及。所以这一次。我不会再让自己错过你--我最深爱的人。嫁给我吧!',
    }
    local str = LuaTools.splitStringByNumber(temp[math.random(1,18)],23) 
    self['Text_txt']:setString('   '..str)
    --self['Text_name']:setString(name)
    self.uid = uid
end


function UIFriendWeddingRequest:accetp()
  
   if G_BASEAPP:getView('UIFriendWeddingRoom') then 
      G_BASEAPP:callMethod('UIFriendWeddingRoom','reqSock_ProposeAccept',self.uid)
   end  
   G_BASEAPP:removeView('UIFriendWeddingRequest')   
end

function UIFriendWeddingRequest:refuse()
  
   if G_BASEAPP:getView('UIFriendWeddingRoom') then 
      G_BASEAPP:callMethod('UIFriendWeddingRoom','reqSock_ProposeDeny',self.uid)
   end  
   --G_BASEAPP:removeView('UIFriendWeddingRequest')   
   LuaTools.viewAction1Over(self['Panel_bg'],"UIFriendWeddingRequest")
end

return UIFriendWeddingRequest

