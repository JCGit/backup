local UITask = class("UITask", cc.load("mvc").ViewBase)

UITask.RESOURCE_FILENAME = "UITask.csb"
--UITask.RESOURCE_PRELOADING = {"main.png"}
--UITask.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}
local HttpHandler = require("app.network.HttpHandler")
--printWarning

UITask.RESOURCE_BINDING = {
    ["Button_close"]  = {["ended"] = "backEvent"},
}

function UITask:backEvent(event)
    
    local app= self.app
    -- if self.app:getView('UIGameHall') then 
    --    local a = (self.numTask>0 and 1 or 2)
    --    app:callMethod('UIGameHall','showOrHideTask',a) 
    -- end    
    -- app:removeView('UITask')
    if self.redPointCallback then 
        local a = (self.numTask>0 and true or false)
        self.redPointCallback(a) 
    end 
    LuaTools.viewAction1Over(self['Panel_All'],"UITask")
end

function UITask:onCreate(id,_callback,onSuccCallback)
    local app = self:getApp()
    self.app = app
    -- if not id then id =9 end 
    id = 9
    self.onSuccCallback = onSuccCallback
    self.tool = app:getModel('Tools')
    self.gameTypeAll = id 
    self.PlayerData = app:getData('PlayerData')
    --self.sound    =  app:getModel('Sound') 
    local ver     = UserCache.getUserDataByKey("task_version"..id) 
    self.desc_get = UserCache.getUserDataByKey("task_desc_get"..id) 
    self.redPointCallback = _callback
    local function cb()
        local table = {
            ['uid']    = self.PlayerData.uid, 
            ['token']  = self.PlayerData.token,
            ['gameType'] = id, 
            ['version']  = ver or '',
            ['cmd']    = HttpHandler.CMDTABLE.GET_TASK }
        self.numTask = 0  
        local function succ(arg)
            dump(arg,'新任务列表')
            if arg.result == 0 then  
                self.dayScore  =  arg.dailyScore or 0 
                self.weekScore =  arg.weeklyScore  or 0 
                self.dayRewardList  =  arg.scoreAward.dayScoreAward or 0 
                self.weekRewardList =  arg.scoreAward.weekScoreAward or 0 

                self:updateList(arg)

                UserCache.setUserDataByKey("task_version"..id,arg.version)
                if arg.desc and  #arg.desc > 0 then 
                   UserCache.setUserDataByKey("task_desc_get"..id,arg.desc)
                end 
                --self['ListView_item']:scrollToTop(0.5,true) 
            else 
                self.tool:showTips(arg.msg)
            end 
        end     
        local function fails(arg)
            dump(arg,'请求新任务列表fail')
        end     
        self.tool:fastRequest(table,succ,fails)
    end 
    LuaTools.viewAction1(self['Panel_All'],cb)

end

function UITask:updateList(info)
    self['ListView_item']:setItemModel(self['Panel_item'])
    
    local function getStateMatch(id) 
        local state 
        for key,var in pairs(info.state) do 
            if  var.TaskId == id then 
                state = var.State 
                break 
            end       
        end     
        return state
    end     

    local function formatWord(str) 
        local temp 
        if string.len(str) > 34 then 
            temp = string.sub(str,1,34)..'...'
        else 
            temp = str 
        end         
        return temp
    end 

    local function touchGet(event)
        if event.name == 'ended' then 
            
            local tag = event.target:getTag()
            local tab = {
                ['uid']    = self.PlayerData.uid, 
                ['token']  = self.PlayerData.token,
                ['gameType'] =  self.gameTypeAll,
                ['taskId']   = tag,
                ['cmd']    = HttpHandler.CMDTABLE.GET_TASK_REWARD
            }
            local function succ(arg)
                self.numTask = self.numTask -1 
                self.PlayerData.coin = tonumber(arg.coin)
                self.PlayerData.gem  = tonumber(arg.gem)     

                self.dayScore  =  arg.dailyScore or self.dayScore 
                self.weekScore =  arg.weeklyScore  or self.weekScore 
                self:updatePacks()
                self.AtlasLabel_day:setString(self.dayScore)
                self.AtlasLabel_week:setString(self.weekScore)  
                local numb = self.dayScore >= 100 and 100 or (self.dayScore) 
                self.LoadingBar_task:setPercent(numb)

                local parent = event.target:getParent()  --self['ListView_item']:getItem(tag-1)
                parent:getChildByName("Button_receive"):setVisible(false)
                parent:getChildByName("Image_finish"):setVisible(true)
                audio.playSound(Sound.SoundTable['sfx']['Task'] , false)
                if arg.msg then 
                    self.tool:showTips(arg.msg) 
                end
                if G_BASEAPP:getView('UIMainTop') then 
                   G_BASEAPP:callMethod('UIMainTop','updateWealth') 
                   local tag1 = self.numTask>0 and true or false 
                   G_BASEAPP:callMethod('UIMainTop','updateTaskRedPoint',tag1) 
                end  

                if self.onSuccCallback then 
                   self.onSuccCallback(arg) 
                end
                --self.sound:playEffect('Get_Coin') 
            end 
            self.tool:fastRequest(tab,succ)
        end 
    end 
    if #info.desc == 0  then 
        info.desc = self.desc_get 
    end     
    local temp_table = {}   --info.desc   info.state
    for key=1,#info.state  do
        local temp = {} 
        temp.TaskDesc    = info.desc[key].TaskDesc--formatWord(info.desc[key].TaskDesc)
        temp.TaskCount   = info.desc[key].TaskCount  or 0
        temp.TaskProcess = getStateMatch(info.desc[key].TaskId) or 0
        temp.coin        = info.desc[key]['TaskAwards'].coin or 0
        temp.gem         = info.desc[key]['TaskAwards'].gem  or 0 
        temp.point       = info.desc[key]['TaskScore'] or 0 
        temp.kick        =  0 
        temp.laba        =  0
        temp.Order       = info.desc[key].Order
        temp.icon        = info.desc[key].TaskIcon
        if info.desc[key]['TaskAwards']["prop"] then 
           temp.kick        = info.desc[key]['TaskAwards']["prop"]['4'] or 0
           temp.laba        = info.desc[key]['TaskAwards']["prop"]['7'] or 0
        end    
        temp.id          = info.desc[key].TaskId  or 0
        table.insert(temp_table,temp) 
    end 
    table.sort(temp_table,function(a,b) 
        if tonumber(a.TaskProcess) ~= tonumber(b.TaskProcess) then 
            return tonumber(a.TaskProcess)<tonumber(b.TaskProcess) 
        else 
            return tonumber(a.Order)<tonumber(b.Order) 
        end 
    end) 

    local model=nil
    local count = 0  
  
    local taskImage 
    for key ,var in ipairs(temp_table) do 
        local precess = tonumber(var.TaskProcess)
        if precess~= -2 then 
            if precess == -1 then self.numTask = self.numTask +1 end 
            self['ListView_item']:pushBackDefaultItem()
            model=self['ListView_item']:getItem(count)
            model:setVisible(true)
            model:getChildByName('Text_taskName'):setString(var.TaskDesc)

           if var.icon and var.icon ~= "" then
              local function onFinishTable(status,downloadedSize,dst)
                  if status == "success" then
                     model:getChildByName('Image_logo'):loadTexture(dst,ccui.TextureResType.localType) 
                  else 
                     print('下载大奖赛logo失败')
                  end
              end
              local newName = var.icon
              LuaTools.getFileFromUrl({url = var.icon, destFile =(newName:gsub("/","_")), onFinishTable = onFinishTable })
           end

            model:getChildByName("Button_receive"):setTag(var.id)
            model:getChildByName("Button_receive"):onTouch(touchGet)   
            model:getChildByName("Button_receive"):setVisible(precess == -1)
            model:getChildByName("Image_ing"):setVisible(precess >= 0 )
            model:getChildByName("Image_finish"):setVisible(precess == -2)
            model:getChildByName("Text_point"):setString('积分:'..var.point)

            local str1 ='奖励:'      
            if var.coin ~=0 then
               str1 = str1..' 金币x'..var.coin 
            end 
            
            if var.gem ~= 0  then 
               str1 = str1..' 元宝x'..var.gem 
            end 
            
            if  var.kick ~=0 then 
               str1 = str1..' 踢人卡x'..var.kick 
            end         

            if  var.laba ~=0 then 
               str1 = str1..' 喇叭x'..var.laba 
            end                 


            model:getChildByName('Text_reward'):setString(str1)            
            model:getChildByName('Text_proress'):setString(precess >= 0 and 
                (precess..'/'..var.TaskCount) or (var.TaskCount..'/'..var.TaskCount) )
            count = count + 1 
        end
    end 
    
    for key,var in ipairs(temp_table) do 
        local precess = tonumber(var.TaskProcess)
        if  precess == -2 then 
            self['ListView_item']:pushBackDefaultItem()
            model=self['ListView_item']:getItem(count)
            model:setVisible(true)

            model:getChildByName('Text_taskName'):setString(var.TaskDesc)

               if var.icon and var.icon ~= "" then
                  local function onFinishTable(status,downloadedSize,dst)
                      if status == "success" then
                         model:getChildByName('Image_logo'):loadTexture(dst,ccui.TextureResType.localType) 
                      else 
                         print('下载大奖赛logo失败')
                      end
                  end
                  local newName = var.icon
                  LuaTools.getFileFromUrl({url = var.icon, destFile =(newName:gsub("/","_")), onFinishTable = onFinishTable })
               end   

            model:getChildByName("Button_receive"):setVisible(false)
            model:getChildByName("Image_finish"):setVisible(true)
            model:getChildByName("Image_ing"):setVisible(false)
            model:getChildByName("Text_point"):setString('积分:'..var.point)

            local str1 ='奖励:'
            if var.coin ~=0 then
               str1 = str1..' 金币x'..var.coin 
            end 
            
            if var.gem ~= 0  then 
               str1 = str1..' 元宝x'..var.gem 
            end 
            
            if  var.kick ~=0 then 
               str1 = str1..' 踢人卡x'..var.kick 
            end         

            if  var.laba ~=0 then 
               str1 = str1..' 喇叭x'..var.laba 
            end 
            model:getChildByName('Text_reward'):setString(str1)
            model:getChildByName('Text_proress'):setString(var.TaskCount..'/'..var.TaskCount)
            count = count + 1 

        end
    end 
    self['AtlasLabel_day']:setString(info.dailyScore or '0')
    self['AtlasLabel_week']:setString(info.weeklyScore or '0')  
    self.LoadingBar_task:setPercent(info.dailyScore>=100 and 100 or (info.dailyScore))
    if info.scoreAward and info.scoreAward.dayScoreAward and info.scoreAward.dayScoreAward['4'] then 
        for k ,v in pairs(info.scoreAward.dayScoreAward) do 
            self['Text_day'..k]:setString(v.score)
            self['Image_getReward'..k]:setVisible(v.state == -2)
            self['Particle_reward'..k]:setVisible(self.dayScore>=v.score and v.state ~= -2)
            local function reqDAward(event)
                if event.name == 'ended' then 
                   self:reqGetPacks(1,k)
                end    
            end     
            self['Button_dayReward'..k]:onTouch(reqDAward)
        end     
    end  

    if info.scoreAward and info.scoreAward.weekScoreAward and info.scoreAward.weekScoreAward['2'] then 
        for k ,v in pairs(info.scoreAward.weekScoreAward) do 
            self['AtlasLabel_week'..k]:setString(v.score)
            self['Image_getWeekAward'..k]:setVisible(v.state == -2)
            self['Particle_week'..k]:setVisible(self.weekScore>=v.score and v.state ~= -2) 
            local function reqWAward(event)
                if event.name == 'ended' then 
                   self:reqGetPacks(2,k)
                end    
            end     
            self['Button_weekReward'..k]:onTouch(reqWAward)
        end 
    end    
end
   
function UITask:reqGetPacks(types,id) 

    local tab = {
                ['uid']    = G_UID, 
                ['token']  = G_TOKEN,
                ['type']   = types,
                ['id']     = id,
                ['cmd']    = HttpHandler.CMDTABLE.NEW_TASK_REWARD
            }
    local function succ(arg)
       dump(arg,'领取任务礼包succ')
       -- LuaTools.showAlert('领取奖励成功')
       if arg.msg then 
           LuaTools.showAlert(arg.msg)
       end  
       audio.playSound(Sound.SoundTable['sfx']['Register_P'] , false)
       if types == 1 then  
          self['Particle_reward'..id]:setVisible(false)
          self['Image_getReward'..id]:setVisible(true)
       else 
          self['Particle_week'..id]:setVisible(false)
          self['Image_getWeekAward'..id]:setVisible(true)
       end    

    end 
    
    local function fails(arg) 
       LuaTools.showAlert('领取奖励失败')
       dump(arg,'领取任务礼包fail')
    end    
    
    local function getAwardName(info)  --LuaTools.convertAmountChinese(var.coin)
        local var = info.award
        local reward = ''
        if var.coin and  var.coin ~= 0 then 
           reward = reward..LuaTools.convertAmountChinese(var.coin)..'金币'..','
        end 
        
        if var.gem and var.gem ~=  0 then 
           reward = reward..var.gem..'个元宝'..','
        end    

        if var.telfee  and var.telfee ~=  0 then 
           reward = reward..var.telfee..'张话费券'..',' 
        end   

        if var.prop  and var.prop['1']  and  var.prop['1'] ~=  0 then 
           reward = reward..var.prop['1']..'张门票'..',' 
        end     

        if var.prop  and var.prop['4']  and  var.prop['4'] ~=  0 then 
           reward = reward..var.prop['4']..'张踢人卡'..',' 
        end  

        if var.prop  and var.prop['7']  and  var.prop['7'] ~=  0 then 
           reward = reward..var.prop['7']..'张喇叭卡'..',' 
        end       
       
        if  var.vip and var.vip['1'] and  tonumber(var.vip['1']) > 0   then  
           reward = reward..var.vip['1']..'张Vip周卡'..',' 
        end    

         if  var.vip_day  and  tonumber(var.vip_day) > 0   then  
           reward = reward..'Vip成长值'..var.vip_day..',' 
        end         
          

        return  string.sub(reward,1,(#reward-1))   
    end     

    if types == 1 then 
        if self['Particle_reward'..id]:isVisible() and self.dayScore >=tonumber(self.dayRewardList[tostring(id)].score) then 
            self.tool:fastRequest(tab,succ,fails)
        else 
           local str =  getAwardName(self.dayRewardList[tostring(id)])
           self:showBlackBg(types,id,str)
        end     
    else 
        if self['Particle_week'..id]:isVisible() and self.weekScore >=tonumber(self.weekRewardList[tostring(id)].score) then 
            self.tool:fastRequest(tab,succ,fails)
        else 
           local str = getAwardName(self.weekRewardList[tostring(id)])
           self:showBlackBg(types,id,str)
        end  
    end     
end 

function UITask:updatePacks()   
    if self.dayRewardList  and self.dayRewardList  ~= 0 then 
       for k,v in pairs(self.dayRewardList) do 
           if v.state ~= -2 and self.dayScore >= tonumber(v.score) and not self['Image_getReward'..k]:isVisible() then
              self['Particle_reward'..k]:setVisible(true)
           end 
       end        
    end     

    if self.weekRewardList and self.weekRewardList ~= 0 then 
       for k,v in pairs(self.weekRewardList) do 
           if v.state ~= -2 and self.weekScore >= tonumber(v.score) and not self['Image_getWeekAward'..k]:isVisible() then
              self['Particle_week'..k]:setVisible(true)
           end 
       end        
    end     
end 

function UITask:showBlackBg(types,id,str) 
    self['Panel_blackBg']:stopAllActions()
    local par = {
       ['1']={self['Button_dayReward1'],self['Button_dayReward2'],self['Button_dayReward3'],self['Button_dayReward4']},
       ['2']={self['Button_weekReward1'],self['Button_weekReward2']}    
       } 
    local child = par[tostring(types)][tonumber(id)]
    LuaTools.freezeWidget(child, 2.5)
    self['Panel_blackBg']:setAnchorPoint(types == 1 and cc.p(1,1) or cc.p(0,0))    
    self['Panel_blackBg']:setPosition(child:getPosition())
    self['Image_bgKind1']:setVisible(tonumber(types)==2)
    self['Image_bgKind2']:setVisible(tonumber(types)==1)
    self['Text_awardDesc']:setString(str)
    self['Panel_blackBg']:setVisible(true)
 
    local fadeAction = cc.Sequence:create(
        cc.DelayTime:create(2.5),
        cc.CallFunc:create(function() self['Panel_blackBg']:setVisible(false) end))

    self['Panel_blackBg']:runAction(fadeAction)
end     

return UITask
