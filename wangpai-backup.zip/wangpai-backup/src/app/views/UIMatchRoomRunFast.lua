local UIMatchRoomRunFast = class("UIMatchRoomRunFast", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
UIMatchRoomRunFast.RESOURCE_FILENAME = "UIMatchRoomRunFast.csb"
--UIMatchRoomRunFast.RESOURCE_PRELOADING = {"main.png"}
--UIMatchRoomRunFast.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIMatchRoomRunFast.RESOURCE_BINDING = {  
    ["Button_QuickStart"] = {["ended"] = "onQuickStart"},
    ["Button_chargeGem"]     = {["ended"] = "enterChargeDiamond"},
} 

--[=================跑得快场次================]--

--更新金币
function UIMatchRoomRunFast:updatePlayerCoin(_coin)
    _coin = _coin or self.pData.coin
    self['Text_myMoney']:setString(LuaTools.convertAmountChinese(self.pData.coin))
end


--进入充值砖石
function UIMatchRoomRunFast:enterChargeDiamond()
    G_BASEAPP:addView('UIQuickBuy', 1200,function(arg) 
        -- self.pData.coin = arg.coin  
        self['Text_myMoney']:setString(LuaTools.convertAmountChinese(self.pData.coin))
    end) 
end



function UIMatchRoomRunFast:enterCharge() 
    if not G_BASEAPP:getView('UIShopDiamond') then 
        G_BASEAPP:addView('UIShopDiamond', 1200,function(arg) 
            self['Text_myMoney']:setString(LuaTools.convertAmountChinese(self.pData.coin))
        end) 
    end   
end    

--检测金币对否小于0，并且是否该弹出充值
function UIMatchRoomRunFast:checkChips(val, text)
    if tonumber(self.pData.coin) <= val then
        local function onConfirm()
            if self.pData.gem > 0 then 
                self:enterChargeDiamond()
            else 
                self:enterCharge() 
            end  
         end
        local dlg = self.app:addView('UIDialog', self:getLocalZOrder() + 1, nil, true)
        dlg:setupDialog('金币不足', text, onConfirm, nil, false)
        return false
    end
    return true
end

--退出后回调
function UIMatchRoomRunFast:onExit() 
    if self.onExiting == nil then 
        self.onExiting = true
        if self.isEnterGameRoom == nil then
            self.app:callMethod('UIMain', 'showEnterMainActions') 
        end
    end
end

--点击快速开始
function UIMatchRoomRunFast:onQuickStart()
    if self:checkChips(0, Constants.STRING_NO_MONEY) == false then return end
    --判断该进入哪一个场次
    local myChips = tonumber(self.pData.coin)
    local indexRoom = 0

    --判断是金币条件符合进入显示的房间
    local minChipsRoom_1 = math.floor(Constants.PDK_ROOMS_DATA[1].min)
    if myChips < minChipsRoom_1 then      --自身的金币小于最小携带
        self:checkChips(minChipsRoom_1, "您的金币不足进入任意场，是否去充值？")
        return
    end

    --倒数循环判断可进入的场次
    -- for i = #Constants.PDK_ROOMS_DATA, 1, -1 do
    --     if self:checkEnabledEnterRoom(i) == true then
    --         indexRoom = i
    --         break
    --     end
    -- end

    --------------------------------  配置修改这里 只有一个场 点击快速开始
    indexRoom = 1 

    if indexRoom > 0 then
        self:enterRoom(indexRoom)
    else
        self.tool:showTips("无法匹配到可进入的房间")
    end
    
end

--检测金币是否足够进入该场次
function UIMatchRoomRunFast:checkEnabledEnterRoom(_index)
    local myChips = tonumber(self.pData.coin)
    local roomData = Constants.PDK_ROOMS_DATA[_index] 
    local max = roomData.max
    local min = roomData.min

    if max == 0 and min == 0 then   --无限制
        return true
    elseif max > 0 and min == 0 and myChips <= max then    --最大限制
        return true
    elseif min > 0 and max == 0 and myChips >= min then   --最小限制
        return true
    elseif min > 0 and max > 0 and myChips >= min and myChips <= max then  --范围限制
        return true
    else
        return false
    end
end

--根据已选择的场次进入对应的游戏
function UIMatchRoomRunFast:enterRoom(_index)
    --self.isEnterGameRoom = true
    --dump(Constants.PDK_ROOMS_DATA[_index], "ENTERING ROOM INFOS")
    local tableInfos = 
    {
        tableType   = Constants.PDK_ROOMS_DATA[_index].tType,
        -- friendID    = ,
        -- RoomId      = ,
        -- RoomLevel   = ,
        isPaodekuai = true,
    }

    -- local load = G_BASEAPP:addView("UILoading",200)  
    -- G_LOADINGVIEW = load
    -- load:setLoadingType(true)
    -- load:setNextAction(function()
    --     G_BASEAPP:addView("UIGameTablePaodekuai",500, tableInfos)  
    -- end)
    -- load:startProgress()
    
    G_BASEAPP:addView("UIGameTablePaodekuai",500, tableInfos)  

end

--展示进入动作
function UIMatchRoomRunFast:showEnterActions()
    --background actions
    local maskLayer = cc.LayerColor:create(cc.c4b(255,255,255,0))
    self['Panel_main']:addChild(maskLayer,-1)
    maskLayer:runAction(cc.Sequence:create(
        cc.FadeTo:create(0.5, 80),
        cc.FadeTo:create(0.2, 0),
        cc.CallFunc:create(function() maskLayer:removeFromParent() end)
        ,nil))

    self['Panel_bgd']:setOpacity(0)
    self['Panel_bgd']:runAction(cc.FadeTo:create(0.6,255))

    --widgets actions
    local btstart = self['Button_QuickStart']
    local moveIn = cc.MoveTo:create(0.6,cc.p(btstart:getPositionX(),72))
    local move_ease_out = cc.EaseBackOut:create(moveIn)
    btstart:runAction(move_ease_out)

    local panelTop = self['Panel_top']
    local moveIn2 = cc.MoveTo:create(0.6,cc.p(panelTop:getPositionX(),cc.Director:getInstance():getWinSize().height))
    local move_ease_out2 = cc.EaseBackOut:create(moveIn2)
    panelTop:runAction(move_ease_out2)
end

function UIMatchRoomRunFast:showListviewEnterActions()
    --listview items actions
    local listview = self['ListView_type']
    local function moveBackAfter(delay, byX)
        local backVal = 80
        if byX < 0 then
            backVal = -backVal
        end
         local moveIn = cc.MoveBy:create(delay,cc.p(byX+backVal,0))
         local moveOff = cc.MoveBy:create(0.2,cc.p(-backVal,0))
         return cc.Sequence:create(moveIn, moveOff)
    end
    for i,item in ipairs(listview:getChildren()) do
        --local moveIn = cc.MoveBy:create(0.47,cc.p(-self.winWidth,0))
        --local move_ease_in = cc.EaseBackOut:create(moveIn)
        --item:runAction(cc.Sequence:create(cc.DelayTime:create(i/10+0.2),move_ease_in,nil))
        item:runAction(cc.Sequence:create(cc.DelayTime:create(i/10+0.2),moveBackAfter(0.2,-self.winWidth),nil))
    end
end

function UIMatchRoomRunFast:onCreate()
    local app = self:getApp()
    self.app = app
    --LuaTools.viewAction2(self['Panel_main'])
    self.pData = app:getData('PlayerData')
    self.tool = app:getModel('Tools')
    --self.sound = app:getModel('Sound')
    self.config = app:getData('Config')
    cc.SpriteFrameCache:getInstance():addSpriteFrames("res_gametypesPDK.plist")
    self.winWidth = cc.Director:getInstance():getWinSize().width

    local function onClose(event)
        if event.name == 'began' then
        elseif event.name == 'ended' then 
            self:removeSelf()
            --LuaTools.viewAction2Over(self['Panel_main'],'UIMatchRoomRunFast')
        end
    end
    self['Button_QuickStart']:setPressedActionEnabled(false)
    self['Button_close']:onTouch(onClose)
    self['Text_myMoney']:setString(LuaTools.convertAmountChinese(self.pData.coin))


    --self:startUpdateCounts()

    -- local dataTable =     {
    --     ['uid']    = self.pData.uid,
    --     ['token']  = self.pData.token,
    --     ['type']   = 6,
    --     ['cmd']       = HttpHandler.CMDTABLE.MATCH_ROOMS,
    --  }
    -- local function succ(arg)    
    --      dump(arg,'跑得快的场次开放信息')
    --      self.gameOpenOrClose = arg.list
    --      self:initRooms()
    --      self:showEnterActions()
    -- end
    -- local function fail(arg)
    --     if arg.msg then
    --         self.tool:showTips(arg.msg)
    --     end
    -- end
    -- self.tool:fastRequest(dataTable,succ, fail,true)

         self:initRooms()
         self:showEnterActions()

    if self.pData.onlinePlayerNumber ~= 0 then 
       self:updatePlayerCounts(self.pData.onlinePlayerNumber)
    end   
end

--初始化场次UI
function UIMatchRoomRunFast:initRooms()

    local function compareSeatId(id)
        -- local tag = 1 
        -- if self.gameOpenOrClose then 
        --   for key,var in pairs(self.gameOpenOrClose) do 
        --     if var.siteid == id then 
        --         tag = var.online 
        --         break
        --     end     
        --   end   
        -- end 
        local tag = (id==107 and 1 or 0)
        return tag 
    end    

    local _array = Constants.PDK_ROOMS_DATA
    -- dump(_array)
    local listview = self['ListView_type']
    local itemModel = self['Panel_Item']

    itemModel:setVisible(false)

    listview:setItemModel(itemModel)
    listview:setBounceEnabled(false)
    listview:setScrollBarEnabled(false)
    listview:removeAllChildren()

    local function onEnterRoom(event)
        if event.name == 'began' then
        elseif event.name == 'ended' then
            if self:checkChips(0, Constants.STRING_NO_MONEY) == false then return end
           local tag = event.target:getTag()
           if self:checkEnabledEnterRoom(tag) == true then
                self:enterRoom(tag)
           else
                self.tool:showTips("您的金币不符合进入房间的条件")
           end
        end
    end

    for key ,var in ipairs(_array) do
        listview:pushBackDefaultItem()
        local item = listview:getItem(key-1) 
        local abcd = compareSeatId(var.tType) 
        local roomData = Constants.PDK_ROOMS_DATA[key]
        item:setTag(key)
        item:setTouchEnabled(abcd == 1 )

        item:onTouch(onEnterRoom)
        item:getChildByName('Text_difen'):setString(roomData.difen)
        item:getChildByName('Text_count'):setString('0')
        item:getChildByName('Image_sign'):loadTexture("res_gametypesPDK/pdk_sign"..key..".png", ccui.TextureResType.plistType)
        item:getChildByName('Image_type'):loadTexture("res_gametypesPDK/pdk_title"..key..".png", ccui.TextureResType.plistType)
        
        if  abcd == 0 then 
            item:getChildByName('Text_difen'):setColor(cc.c3b(77,77,77))
            item:getChildByName('Image_bgdRoom'):setColor(cc.c3b(77,77,77))
            item:getChildByName('Image_sign'):setColor(cc.c3b(77,77,77))
            item:getChildByName('Image_type'):setColor(cc.c3b(77,77,77))
            item:getChildByName('Text_count'):setColor(cc.c3b(77,77,77))
            item:getChildByName('Text_desc'):setColor(cc.c3b(77,77,77))
        end     
        local max = roomData.max
        local min = roomData.min
        local text
        if max > 0 and min > 0 then  --范围
            text = LuaTools.convertAmountChinese(min)..'-'..LuaTools.convertAmountChinese(max).."准入"
        elseif max > 0 and min == 0 then  --以下
            text = LuaTools.convertAmountChinese(max)..'以下准入'
        elseif max == 0 and min > 0 then 
            text = LuaTools.convertAmountChinese(min)..'以上准入'
        else
            text = '无限制'
        end
        item:getChildByName('Text_desc'):setString(text)
        item:runAction(cc.Sequence:create(
         cc.MoveBy:create(0.1,cc.p(self.winWidth,0)),
         cc.CallFunc:create(function() item:setVisible(true) end)
         ,nil))
    end 

    self:showListviewEnterActions()
end


--启动更新玩家个数
function UIMatchRoomRunFast:startUpdateCounts()
    self.app:callMethod('UIMain','reqSock_getOnliner')
    self:createSchedule("updateCounts",function()
        self.app:callMethod('UIMain','reqSock_getOnliner')
    end,self.config.refreshPlayerCountsDelay)
end

--更新玩家个数
function UIMatchRoomRunFast:updatePlayerCounts(_table)
   -- dump(_table,'popopopopo')
    for k=1,#Constants.PDK_ROOMS_DATA do 
        self['ListView_type']:getItem(k-1):getChildByName('Text_count'):setString(_table['107'][tostring(k-1)])
    end      
end


return UIMatchRoomRunFast
