local UIAddFriend = class("UIAddFriend", cc.load("mvc").ViewBase)

UIAddFriend.RESOURCE_FILENAME = "UIAddFriend.csb"
--UIAddFriend.RESOURCE_PRELOADING = {"main.png"}
--UIAddFriend.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIAddFriend.RESOURCE_BINDING = {
    ["Button_close"]   = {["ended"] = "backEvent"},
    ["Panel_bg"]       = {["ended"] = "backEvent"},
    ["Button_confirm"] = {["ended"] = "confirm"},
    ["ListView_item_select"]  = {["ON_SELECTED_ITEM_START"] = "select"},
}


local HttpHandler = require("app.network.HttpHandler")
local scheduler = require("app.models.QScheduler")
function UIAddFriend:backEvent(event)
    --self.app:removeView('UIAddFriend')
    LuaTools.viewAction1Over(self["Panel_bg"],"UIAddFriend")
end

function UIAddFriend:onCreate(uid,tag) 
    self.tgtuid = uid
    local app = self:getApp()
    self.app = app
    self.lastSelectedIndex = 1
    LuaTools.viewAction1(self["Panel_bg"])
    self.tool = app:getModel('Tools')
    self['TextField_uid']:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    if uid then 
       self['TextField_uid']:setString(uid)
    end 
    self['ListView_item_select']:setScrollBarEnabled(false)
    self.Text_uid:setString('我的ID：'..G_UID..'（ID可在个人信息查看）')
    self.maxGift = 6
    local price = {3000,60000,300000,500000,800000,5000000}
    local tem_img = {'common/gift1.png','common/gift3.png','common/gift4.png','common/gift5.png','common/gift6.png','common/gift7.png'}
    local img_tab = {}
    
    self['Button_model']:setPressedActionEnabled(false)
    self['ListView_item_select']:setItemModel(self['Button_model'])
    self['ListView_item_select']:removeAllItems()
    for key = 1 ,self.maxGift do 
        self['ListView_item_select']:pushBackDefaultItem()
        local model = self['ListView_item_select']:getItem(key-1)
        model:setVisible(true)
        model:getChildByName('Text_value'):setString(price[key])
        model:getChildByName('Image_check'):setVisible(false)
        model:getChildByName('Image_kind'):loadTexture(tem_img[key],ccui.TextureResType.plistType)
    end 
    self:switch(0,1)

end
--[[
4     咖啡
5     汽车
6     游艇
7     房产
8     波音飞机

]]
function UIAddFriend:confirm()
    local app = self.app
    if #self['TextField_uid']:getString() > 0 then

        -- app:getModel('Tools'):beginWaiting()

    local playerdata = self.app:getData('PlayerData')
    local paTable =     {
        ['uid']   = tonumber(playerdata.uid),
        ['token'] = G_TOKEN,
        ['cmd']   = HttpHandler.CMDTABLE.ADD_FRIEND,
        ['fuid']  = self['TextField_uid']:getString(),
        ['giftid']=  self.currentGift,
        ['type']  = 0,--0 表示离线 1表示在线
        ['ftype'] = 0,--0 表示普通好友 1 表示结婚
        ['from']  = 'hall',
        ['callback']  = function(arg)
          self.app:addView('UIAlert',1000)
          :setupDialog('Infomation',arg.msg)
          if arg.result == 0 then 
              playerdata.coin = arg.coin or   playerdata.coin
              if G_BASEAPP:getView('UIMainTop') then 
                  G_BASEAPP:callMethod('UIMainTop','updateWealth') 
              end  
          end 
           --self.app:getView('UIFriend'):initContent(1)
            -- self.app:getModel('Tools'):stopWaiting() 
                G_BASEAPP:removeView('UIAddFriend')   
        end
    }
    HttpHandler.new(paTable)

    else
          self.app:addView('UIAlert',1000)
          :setupDialog('Infomation','请输入玩家ID..')
    end
end

function UIAddFriend:select(event)
    local index = event.target:getCurSelectedIndex()+1
    self:switch(self.lastSelectedIndex,index)  
end

function UIAddFriend:switch(from,to)
    if to == 0 or not to then  return end
    local id_tab = {1,3,4,5,6,7}
    self.currentGift = id_tab[to]

    if from-1 >= 0 then 
       self['ListView_item_select']:getItem(from-1):getChildByName('Image_check'):setVisible(false)
    end 

    self['ListView_item_select']:getItem(to-1):getChildByName('Image_check'):setVisible(true)
    self.lastSelectedIndex = to 

end

return UIAddFriend
