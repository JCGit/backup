local UIAwards = class("UIAwards", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")

UIAwards.RESOURCE_FILENAME = "UIAwards.csb"
--UIAwards.RESOURCE_PRELOADING = {"main.png"}
--UIAwards.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

--0:已下架 1：未开启 2：报名中  ，3：入场中 ，4比赛中 ，5：已结束 ，6：参赛人数不足取消比赛 ，7：大厅拉人中
UIAwards.RESOURCE_BINDING = { 

    ["Button_close1"]     = {["ended"] =  "closeRule"},
    ["Button_close"]      = {["ended"] =  "closeNow"},
    ["Button_shop"]       = {["ended"] =  "enterQuickBuy"},
    ["Button_reFresh"]    = {["ended"] =  "updateNowView"},
    ["Button_rank"]      = {["ended"] =  "rankInfo"},
    ["Button_close2"]      = {["ended"] =  "closeRankInfo"},
    } 

function UIAwards:closeRule()
    self:closeActionView(self['Panel_interface'])
end    

function UIAwards:rankInfo()
    self.Panel_rank:setVisible(true)
    if #self.pData.matchFirstOneInfo > 0 then 
        self:updateRankInfo(self.pData.matchFirstOneInfo,0)
    else 
        self:requestGetRankInfo()
    end 
end 
function UIAwards:requestGetRankInfo() 
      local tab = { 
          ['uid']   = G_UID,
          ['token'] = G_TOKEN, 
          ['page']  = self.indexPage,
          ['cmd']   = HttpHandler.CMDTABLE.MATCH_FIRST, 
       }
      local function succ(arg)
          dump(arg,'请求第一名列表成功')
          print('当前分页='..self.indexPage)
          print(#self.pData.matchFirstOneInfo)
          self['ListView_preGames']:setTouchEnabled(true)
          self['ListView_preGames']:setBounceEnabled(true)   
          local temp = {} 
          for k ,var in pairs(arg.list) do 
              local info = {} 
              info.order = self:countNowTime(string.sub(k,-8))+ tonumber(string.sub(k,6,7)) + tonumber(string.sub(k,9,10))
              info.Name  = var.Name 
              info.Reward = var.Reward 
              info.StartTime = var.StartTime
              info.Winner    = var.Winner 
              info.time      = k
              table.insert(temp,info)
          end   

          local function testSort(a,b)
              return tonumber(a.order)< tonumber(b.order)
          end
          table.sort(temp,testSort)
          if self.indexPage == 1 then 
             self.pData.matchFirstOneInfo  = temp
          else 
            for key = 1 ,#temp do   
                local v = temp[key]
                table.insert(self.pData.matchFirstOneInfo,v)
            end
          end     
          self:updateRankInfo(temp,1)
      end 

      local function fail(arg)
          dump(arg,'请求第一名列表失败')
      end      
      LuaTools.fastRequest(tab,succ,fail)
end 


function UIAwards:closeRankInfo()
    self.Panel_rank:setVisible(false)
end   

function UIAwards:updateRankInfo(info,tag)
    if #self.ListView_preGames:getItems() == 0  or tag == 1  then 
      local num = #self.ListView_preGames:getItems()
      for key=1,#info do  
          local var = info[key] 
          local model  
          if key%2 == 0 then 
             model = self['Panel_preItem1'] 
          else 
             model = self['Panel_preItem2']  
          end    
          self.ListView_preGames:setItemModel(model)  
          self.ListView_preGames:pushBackDefaultItem()
          local item = self.ListView_preGames:getItem(num+key-1)
          item:getChildByName('Text_title'):setString(var.Name)
          item:getChildByName('Text_date'):setString(var.time)
          item:getChildByName('Text_name'):setString(var.Winner)
          item:getChildByName('Text_rank'):setString('1')
          local reward 
          if var.Reward then 
            if var.Reward.coin and tonumber(var.Reward.coin) > 0 then 
                reward = LuaTools.convertAmountChinese(var.Reward.coin)..'金币'
            elseif var.Reward.gem and tonumber(var.Reward.gem) > 0 then      
                reward = var.Reward.gem..'元宝'
            elseif var.Reward.telfee and tonumber(var.Reward.telfee) > 0 then      
                reward = var.Reward.gem..'张话费券'
            elseif var.Reward.ticket and var.Reward.ticket.count and tonumber(var.Reward.ticket.count) > 0 then          
                reward = var.Reward.ticket.count..'张门票'
            end   
          end  
          item:getChildByName('Text_reward'):setString(reward)
      end   
      self["ListView_preGames"]:scrollToBottom(2, true) 
      self['ListView_preGames']:jumpToItem(#self.pData.matchFirstOneInfo-9, cc.p(0,0), cc.p(0,0))

    end   
end  
  
function UIAwards:closeNow()       
    if  #self.allSchedule  > 0 then       
        for key,var in pairs(self.allSchedule) do 
            self:stopSchedule(var)
        end     
    end    
    G_BASEAPP:getView('UIMain').isShowingMainEnterAction = false 
    G_BASEAPP:callMethod('UIMain','showEnterMainActions')
    G_BASEAPP:callMethod('UIMainTop','updateWealth')
    -- LuaTools.viewAction2Over(self['Panel_ALLmain'],'UIAwards', nil, {"UIMain","UIMainTop"})  
    G_BASEAPP:removeView('UIAwards')
end  


function UIAwards:onCreate()
    local app = self:getApp()
    self.app = app
    self.tool = self.app:getModel('Tools') 
    self.main = self.app:getModel('Main') 
    self.config = self.app:getData('Config')
    self.pData = self.app:getData('PlayerData')
     
    self.allSchedule = {} --所有计时器   
    self.allInfo = {0,0,0,0}  
    -- self:setSkipGoBack(true)

    app:callMethod("UIMain", "loadGameRoomsInfos", self.config.keyDataGames.match,function() 
      --dump(self.pData.GameTypes.GameType_MATCH,'比赛场的配置信息') 
    end)

    -- self.allStateTag = {'等待入场','报名中','入场中','比赛中','已结束'} 
 
    self['Button_gameType1']:setPressedActionEnabled(false)  
    self['Button_gameType4']:setPressedActionEnabled(false)  


    for k=1,4 do 
        self['ListView_central'..k]:setItemModel(self['Panel_central'])  
        if k~=4 then 
           self['Button_rules'..k]:setPressedActionEnabled(false)  
        end     
    end     

    self.alReadyReged = {}  --是否报名的描述
    self['ListView_rewardRule']:setScrollBarEnabled(false)
    self['ListView_rewardRule1']:setScrollBarEnabled(false)
    self['ListView_central1']:setScrollBarEnabled(false)
    self['ListView_central2']:setScrollBarEnabled(false)
    self['ListView_central3']:setScrollBarEnabled(false)
    self['ListView_central4']:setScrollBarEnabled(false)

    self['ListView_rewardRule']:setItemModel(self['Panel_lastReward'])       
    self['ListView_rewardRule1']:setItemModel(self['Panel_lastReward1'])       

    self.ticketKind = {'门票','门票','门票','门票','门票'} 
    
    self.lastSelected = 1 

    
    self.lastRuleSel  = 1 


    self.showLocalTime = false 


    self.allStatusInfo = {}   --报名状态 
    self:updateWealth()

    self['Text_myGoldCup']:setString('0')
    self['Text_silverCup']:setString('0')
    self['Text_bronzeCup']:setString('0')
    -- local function cb() 
        self:requestList(1)
    -- end  
    -- LuaTools.viewAction2(self['Panel_ALLmain'], cb)

    for key=1,4 do 
         local function switchPage(event)
             if event.name == 'ended' then 
                 self:switchBut(self.lastSelected,key)
                 self:requestList(key)
             end  
         end 
         self['Button_gameType'..key]:onTouch(switchPage)
    end     

    for k=1,3 do 
         local function switchRule(event) 
             if event.name == 'ended' then  
                self:switchRuleBut(self.lastRuleSel,k)
             end 
         end    
         self['Button_rules'..k]:onTouch(switchRule)
    end     
    self.indexPage = 1 

    local function onScrolled(event)
        if event.name == "BOUNCE_BOTTOM" then
            if #self.pData.matchFirstOneInfo < 10*self.indexPage or (self.indexPage >= 10) then
                return
            end
            self['ListView_preGames']:setTouchEnabled(false)
            self['ListView_preGames']:setBounceEnabled(false)

            self.indexPage = self.indexPage + 1
            self:requestGetRankInfo()
        end
    end
    self['ListView_preGames']:onScroll(onScrolled) 


    local function onKeyReleased(keyCode, event)
        if keyCode == cc.KeyCode.KEY_BACK  then
            if  #self.allSchedule  > 0 then       
                for key,var in pairs(self.allSchedule) do 
                    self:stopSchedule(var)
                end   
            end    
            G_BASEAPP:getView('UIMain').isShowingMainEnterAction = false 
            G_BASEAPP:callMethod('UIMain','showEnterMainActions')
            G_BASEAPP:callMethod('UIMainTop','updateWealth')
        end
    end
    local listener = cc.EventListenerKeyboard:create()
    listener:registerScriptHandler(onKeyReleased, cc.Handler.EVENT_KEYBOARD_RELEASED )
    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener, self)

end

function UIAwards:switchBut(from,to)
   if (not to or from == to ) then  return  end 
   local butTab1 = {'res_awards/btn_head_01_1.png','res_awards/btn_head_02_1.png','res_awards/btn_head_03_1.png','res_awards/btn_head_04_1.png',} 
   local butTab2 = {'res_awards/btn_head_01.png','res_awards/btn_head_02.png','res_awards/btn_head_03.png','res_awards/btn_head_04.png',} 
   if from then  
     self['Button_gameType'..from]:loadTextures(butTab1[from],butTab1[from],butTab1[from],ccui.TextureResType.plistType)
   end 

   self['Button_gameType'..to]:loadTextures(butTab2[to],butTab2[to],butTab2[to],ccui.TextureResType.plistType) 
end     



function UIAwards:switchRuleBut(from,to)
   if (not to or from == to ) then  return  end 
   local butTab1 = {'res_awards/gz_btn_01.png','res_awards/gz_btn_02.png','res_awards/gz_btn_03.png'} 
   local butTab2 = {'res_awards/gz_btn_01_1.png','res_awards/gz_btn_02_1.png','res_awards/gz_btn_03_1.png'} 
   local parKind = {self['Panel_rule1'], self['Panel_rule2'],self['Panel_rule3']}
   local parKind1 = {self['Panel_rule1'], self['Panel_rule2'],self['Panel_rule4']}
   
   local par = self.lastSelected ==4 and parKind1 or parKind
   if from then  
     self['Button_rules'..from]:loadTextures(butTab2[from],butTab2[from],butTab2[from],ccui.TextureResType.plistType)
     par[from]:setVisible(false)
   end 

   self['Button_rules'..to]:loadTextures(butTab1[to],butTab1[to],butTab1[to],ccui.TextureResType.plistType) 
   par[to]:setVisible(true)
   self.lastRuleSel = to 

end     

function UIAwards:requestList(tag) 
   if  self.allInfo[tag] == 0   then 
        local tab = {
            ['uid']   = G_UID,
            ['token'] = G_TOKEN, 
            ['type']  = tag,
            ['unionid']   = G_CHANNELID,
            ['cmd']   = HttpHandler.CMDTABLE.MATCH_GAME, 
        }

        local function succ(arg)
             dump(arg,'请求比赛场列表成功')
             if arg.cup  then 
                self['Text_myGoldCup']:setString(arg.cup['1'] or 0)
                self['Text_silverCup']:setString(arg.cup['2'] or 0)
                self['Text_bronzeCup']:setString(arg.cup['3'] or 0)
             end   
             local tempTab  = {}
             local countTag = 1 
             for k,v in pairs(arg.list)  do 
                tempTab[countTag] = v 
                local str = self:countNowTime(string.sub(v.StartTime,-8)) 
                tempTab[countTag].awayBeginTime = str  or 0 
                countTag = countTag + 1 
             end  

             local function compareTime(a,b) 
                  if  tag ~= 4 then
                      if a.IsOnTop > b.IsOnTop then  
                         return a.IsOnTop > b.IsOnTop
                      else  
                         return a.awayBeginTime < b.awayBeginTime
                      end    
                  else
                      return a.awayBeginTime > b.awayBeginTime
                  end     
             end  
             table.sort(tempTab,compareTime)
             self.allInfo[tag]  = tempTab
             if not self.showLocalTime and arg.clock  then  
                local butKind = {'res_awards/btn_awards_07.png','res_awards/btn_awards_01.png','res_awards/btn_awards_02.png',
                'res_awards/btn_awards_05.png','res_awards/btn_awards_06.png','res_awards/btn_awards_03.png'}
                self.showLocalTime = true 
                self['Text_Time']:setVisible(false)
                self['Text_Time']:setString(arg.clock)
                self.nowSystemTime  = self:countNowTime(arg.clock)  --当前的系统时间  os.date("%X")
                local mySystemTime =   self:countNowTime(os.date("%X")) --我系统的时间

                local time = mySystemTime+1
                local name = 'localNowTime'
                table.insert(self.allSchedule,name) 
                -----------------------------------------------
                local function  callback()       
                        local hour   = math.floor(time/3600)
                        local minute = math.floor((time-hour*3600)/60)
                        local second = time - minute*60 - hour*3600
                        local temp = string.format("%02d:%02d:%02d",hour,minute,second) 
                        self['Text_Time']:setString(temp) 
                        if #self.allStatusInfo > 0 then 
                          for key,var in pairs(self.allStatusInfo) do    
                              local item = var.parent    
                              if not var.otherInfo.EnterTime   then var.otherInfo.EnterTime = 25 end 
                              local enterTime = tonumber(var.otherInfo.EnterTime)*60
                              print('当前时间:'..time)
                              print('开赛时间:'..var.staTime)
                              print('当前是否报名='..var.otherInfo.IsReged)
                              print('--------------------------')
                              if var.otherInfo.IsReged == 0  then  --未报名处理 time<=(var.staTime-enterTime)
                                  if  var.bmTime and  var.staTime and time >= var.bmTime and time<=var.staTime then --按钮状态切换为报名
                                      local function touch1(event)
                                          if event.name == 'ended' then 
                                              self:requestSignUp(var.otherInfo.Type,var.otherInfo.Id,function(arg) 
                                                     item:getChildByName('Button_join'):setTouchEnabled(false)
                                                     if time<=(var.staTime-enterTime) then 
                                                        item:getChildByName('Button_join'):loadTextures(butKind[6],butKind[6],butKind[6],ccui.TextureResType.plistType) 
                                                     else 
                                                        item:getChildByName('Button_join'):loadTextures(butKind[3],butKind[3],butKind[3],ccui.TextureResType.plistType) 
                                                     end  
                                                     if arg.regNum then 
                                                        item:getChildByName('Text_haveNumbers'):setString(arg.regNum)
                                                     end   
                                                     var.otherInfo.IsReged = 1 
                                                     var.otherInfo.State   = 2  
                                              end)
                                          end 
                                      end  
                                      if time >= var.bmTime and   time <= var.staTime   then 
                                         item:getChildByName('Button_join'):loadTextures(butKind[2],butKind[2],butKind[2],ccui.TextureResType.plistType)
                                         item:getChildByName('BitmapFontLabel_waitingBM'):setVisible(false)
                                      end 
                                      item:getChildByName('Button_join'):setEnabled(true)
                                      item:getChildByName('Button_join'):setTouchEnabled(true)
                                      item:getChildByName('Button_join'):onTouch(touch1)
                                  end  
                              elseif var.otherInfo.State == 3 or var.otherInfo.State == 4 then 
                                   item:getChildByName('BitmapFontLabel_waitingBM'):setVisible(false)
                                   local function enterGame(event)
                                      if event.name == 'ended' then 
                                         if var.otherInfo.DieOut and var.otherInfo.DieOut == 1 then --被淘汰 
                                            LuaTools.showAlert('您已被淘汰,无法进入')
                                         -- elseif var.otherInfo.DieOut and var.otherInfo.DieOut == 0 then --未及时入场
                                         --    LuaTools.showAlert('您未及时入场,已被视为弃赛')
                                         else  
                                            self:requestEnterGame(var.otherInfo,var.otherInfo.Type,(var.staTime-time),
                                            function()   end) 
                                         end
                                      end 
                                   end  
                                   item:getChildByName('Button_join'):setTouchEnabled(true)
                                   item:getChildByName('Button_join'):onTouch(enterGame) 
                              end
                              --倒计时显示
                              if var.staTime and time <= var.staTime and time>=(var.staTime-enterTime) and tonumber(var.otherInfo.State) < 4 then --按钮状态切换为入场
                                  if var.otherInfo.IsReged == 1  then 
                                      item:getChildByName('Button_join'):loadTextures(butKind[3],butKind[3],butKind[3],ccui.TextureResType.plistType)
                                      local function touch2(event) 
                                          if event.name == 'ended' then 
                                             self:requestEnterGame(var.otherInfo,var.otherInfo.Type,(var.staTime-time)) 
                                          end 
                                      end  
                                      item:getChildByName('Button_join'):setEnabled(true)
                                      item:getChildByName('Button_join'):setTouchEnabled(true)
                                      item:getChildByName('Button_join'):onTouch(touch2) 
                                  else
                                      local function touch3(event) 
                                          if event.name == 'ended' then 
                                             self:requestSignUp(var.otherInfo.Type,var.otherInfo.Id,function(arg) 
                                                     item:getChildByName('Button_join'):setTouchEnabled(false)
                                                     item:getChildByName('Button_join'):loadTextures(butKind[3],butKind[3],butKind[3],ccui.TextureResType.plistType) 
                                                     if arg.regNum then 
                                                        item:getChildByName('Text_haveNumbers'):setString(arg.regNum)
                                                     end   
                                                     var.otherInfo.IsReged = 1 
                                                     var.otherInfo.State   = 2 
                                              end)
                                          end 
                                      end  
                                      item:getChildByName('Button_join'):setEnabled(true)
                                      item:getChildByName('Button_join'):setTouchEnabled(true)
                                      item:getChildByName('Button_join'):onTouch(touch3) 
                                      --item:getChildByName('Button_join'):setEnabled(false)
                                      -- item:getChildByName('Button_join'):setColor(cc.c3b(77,77,77))
                                  end 
                                  item:getChildByName('Panel_time2'):setVisible(true)
                                  item:getChildByName('Panel_time1'):setVisible(false)
                                  local minute = math.floor((var.staTime -time)/60)
                                  local second = (var.staTime -time) - minute*60
                                  local temp = string.format("%02d:%02d",minute,second) 
                                        
                                  item:getChildByName('Panel_time2'):getChildByName('BitmapFontLabel_min'):setString(string.format("%02d",minute))
                                  item:getChildByName('Panel_time2'):getChildByName('BitmapFontLabel_sec'):setString(string.format("%02d",second))

                                  if (var.staTime -time) <= 0 then 
                                     item:getChildByName('Panel_time2'):setVisible(false)
                                     item:getChildByName('Panel_time1'):setVisible(true)
                                     item:getChildByName('Button_join'):loadTextures(butKind[4],butKind[4],butKind[4],ccui.TextureResType.plistType)
                                  end                                    
                              end  
                          end  
                        end 
                        time = self:countNowTime(os.date("%X"))
                end 
                self:createSchedule(name, callback, 1)  
             end  
             self:updateList(self.allInfo[tag],tag)
        end  

        local function fail(arg)
             dump(arg,'请求比赛场列表失败')
             if self.lastSelected  then 
                self['ListView_central'..self.lastSelected]:setVisible(false) 
             end  
             self['ListView_central'..tag]:setVisible(true)
        end  
        LuaTools.fastRequest(tab,succ, fail)
   else 
       if self.lastSelected  then 
           self['ListView_central'..self.lastSelected]:setVisible(false) 
       end  
       self['ListView_central'..tag]:setVisible(true)
   end  
   self.lastSelected = tag     

end     

--刷新当前界面 
function UIAwards:updateNowView()
    if  #self.allSchedule  > 0 then       
        for key,var in pairs(self.allSchedule) do 
            self:stopSchedule(var)
        end   
    end   
    self.allInfo =  {0,0,0,0}
    self.allStatusInfo = {} 
    self.allSchedule = {}
    self.showLocalTime = false 
    self:requestList(self.lastSelected) 
    LuaTools.freezeWidget(self["Button_reFresh"], 10) 
end


--进入快速购买
function UIAwards:enterQuickBuy()
    if not G_BASEAPP:getView('UIShopDiamond') then 
        G_BASEAPP:addView('UIShopDiamond', 1200,function() 
            self:updateWealth()
        end) 
    end     
end

function UIAwards:updateWealth()
    self['Text_myGem']:setString(LuaTools.convertAmountChinese(self.pData.gem))
    self['Text_myTickets']:setString(self.pData.prop[3])
    self['Text_myCoins']:setString(LuaTools.convertAmountChinese(self.pData.coin)) 
    self['Text_myFee']:setString(self.pData.telfee)
end   

function UIAwards:countNowTime(str)
   if #str ~= 8 then return -1 end 
   local a,b,c = tonumber(string.sub(str,1,2)),tonumber(string.sub(str,4,5)),tonumber(string.sub(str,7,8))
   local time = 3600*a+60*b+c
   return  time 
end   


--窗口缩放动作
function UIAwards:openActionView(panel)
   panel:setVisible(true)
   panel:setScale(0)
   local scale  = cc.ScaleTo:create(0.2,1.1)
   local scale1 = cc.ScaleTo:create(0.2,1)
      panel:runAction(cc.Sequence:create(scale,scale1))
end   

function UIAwards:closeActionView(panel)
   local scale  = cc.ScaleTo:create(0.1,1.1)
   local  act  = cc.ScaleTo:create(0.2,0)
   local function cb() 
      self:switchRuleBut(self.lastRuleSel,1)
   end  
   panel:runAction(cc.Sequence:create(scale,act,cc.CallFunc:create(cb)))
end   

--更新列表
function UIAwards:updateList(tab,tag)     
    local list = self['ListView_central'..tag]
    list:removeAllChildren() 
    local count = 0 
    local butKind = {'res_awards/btn_awards_07.png','res_awards/btn_awards_01.png','res_awards/btn_awards_02.png',
    'res_awards/btn_awards_05.png','res_awards/btn_awards_06.png','res_awards/btn_awards_03.png'}
    
    local parKind = {self['ListView_central1'],self['ListView_central2'],self['ListView_central3'],self['ListView_central4']}
    for k,v in pairs(parKind) do 
        if v~= list then 
            v:setVisible(false)
        else 
            v:setVisible(true)
        end     
    end     
    for key=1,#tab do 
        local var = tab[key] 
        if var then 
           list:pushBackDefaultItem() 
           local item = list:getItem(count)
           item:getChildByName('Text_name'):setString(var.Name)
           item:getChildByName('Text_haveNumbers'):setString(var.RegNum)
           local baoMing = ''
           if var.Fee then 
              if var.Fee.asset and tonumber(var.Fee.asset.count)>0 then 
                 local t1 = tonumber(var.Fee.asset.type) == 2 and '元宝' or '金币' 
                 if   tonumber(var.Fee.asset.type) == 2  then 
                      t1 = '元宝'  
                 elseif  tonumber(var.Fee.asset.type) == 1  then  
                      t1 = '金币'     
                 elseif  tonumber(var.Fee.asset.type) == 3  then  
                      t1 = '张话费券'      
                 end  
                 baoMing = LuaTools.convertAmountChinese(var.Fee.asset.count)..t1 
              end     
              if var.Fee.ticket and tonumber(var.Fee.ticket.count)>0 then 
                 if baoMing ~= '' then 
                    baoMing = baoMing..'或'
                 end    
                 baoMing = baoMing..var.Fee.ticket.count..'张'..self.ticketKind[tonumber(var.Fee.ticket.type)] 
              end      
           end 

           if tag ~= 4  then  --未结束的状态  RegistTime   StartTime    and var.IsReged == 0 
               local tempTabs = {} 
               --报名时间  self.nowSystemTime  
               local mySystemTime =   self:countNowTime(os.date("%X")) --我系统的时间
               
               local dif = self.nowSystemTime - mySystemTime  
               local bmTime = self:countNowTime(string.sub(var.RegistTime,-8)) 
               if bmTime ~= -1 then 
                  tempTabs.bmTime = bmTime-dif
               end 
               --比赛开始时间
               local  staTime = self:countNowTime(string.sub(var.StartTime,-8)) 
               if staTime ~= -1 then 
                  tempTabs.staTime  = staTime-dif
               end 
               if  var.IsReged ==1   then  
                    local tempReged = {} 
                    tempReged.title = var.Name 
                    tempReged.time  = string.sub(var.StartTime,-8) 
                    tempReged.count = staTime
                    -- tempReged.condition = baoMing 
                    table.insert(self.alReadyReged,tempReged)
               end  
               tempTabs.parent    = item 
               tempTabs.otherInfo = var 
               table.insert(self.allStatusInfo,tempTabs) 
           else 
               item:getChildByName('Panel_time1'):setVisible(false) 
               item:getChildByName('Panel_time2'):setVisible(false) 
           end  


           if baoMing == '' then 
              baoMing  = '免费参加'
           end  
           item:getChildByName('Text_feiyong'):setString(baoMing) 
           local  beginTime = string.sub(var.StartTime,-8) 
           beginTime = string.sub(beginTime,1,5) 
           item:getChildByName('Panel_time1'):getChildByName('BitmapFontLabel_1'):setString(beginTime or '')
           --禁止报名条件
           -- if var.State == 1 then 
           --    item:getChildByName('Button_join'):setEnabled(false)
           -- end  
           if var.State == 7 then var.State = 3 end 
           if butKind[var.State] then 
              if var.State == 2 and var.MaxPlayers == var.RegNum then 
                  local image = 'res_awards/btn_awards_04.png'
                  item:getChildByName('Button_join'):loadTextures(image,image,image,ccui.TextureResType.plistType)
                  item:getChildByName('Button_join'):setEnabled(false)
              else   
                  item:getChildByName('Button_join'):loadTextures(butKind[var.State],butKind[var.State],butKind[var.State],ccui.TextureResType.plistType)
              end 
              if var.State == 1 then 
                 item:getChildByName('BitmapFontLabel_waitingBM'):setVisible(true)
                 item:getChildByName('BitmapFontLabel_waitingBM'):setString(string.sub(var.RegistTime,12,16))
              end   
           else 
              item:getChildByName('Button_join'):loadTextures(butKind[5],butKind[5],butKind[5],ccui.TextureResType.plistType)
           end  

           var.Condition = baoMing
           if var.Icon and var.Icon ~= "" then
              local function onFinishTable(status,downloadedSize,dst)
                  if status == "success" then
                     item:getChildByName('Image_logo'):loadTexture(dst,ccui.TextureResType.localType) 
                  else 
                     print('下载大奖赛logo失败')
                  end
              end
              local newName = var.Icon
              LuaTools.getFileFromUrl({url = var.Icon, destFile =(newName:gsub("/","_")), onFinishTable = onFinishTable })
           end
           -----------------------------------------------
           -----------------------------------------------
           local function cb1() 
              self:requestSignUp(var.Type,var.Id,function(arg) 
                    -- if var.State == 2 then  
                       item:getChildByName('Button_join'):loadTextures(butKind[6],butKind[6],butKind[6],ccui.TextureResType.plistType)
                    -- elseif var.State ==3 then  
                    --    item:getChildByName('Button_join'):loadTextures(butKind[3],butKind[3],butKind[3],ccui.TextureResType.plistType)
                    -- end  
                     item:getChildByName('Button_join'):setTouchEnabled(false)
                     if arg.regNum then 
                        item:getChildByName('Text_haveNumbers'):setString(arg.regNum)
                     end   
                     var.IsReged = 1 
              end)
           end 
           
           local function cb2() 
              --  self:cancelSignUp(var.Type,var.Id,function(arg) 
              --        item:getChildByName('Button_join'):loadTextures(butKind[2],butKind[2],butKind[2],ccui.TextureResType.plistType)
              --        item:getChildByName('Button_join'):setTouchEnabled(true)
              --        if arg and  arg.regNum then 
              --           item:getChildByName('Text_haveNumbers'):setString(arg.regNum)
              --        end  
              --        var.IsReged = 0
              -- end)             
           end  
           -----------------------------------------------
           local function enterHelp(event) 
               if event.name == 'ended' then 
                  self:updateRule(var,cb1,cb2,self.lastSelected)
               end 
           end  
           item:setTouchEnabled(true)
           item:onTouch(enterHelp)

           item:getChildByName('Button_join'):setPressedActionEnabled(false)
           if  var.IsReged ==1   then 
               if var.State == 2  then 
                  item:getChildByName('Button_join'):loadTextures(butKind[6],butKind[6],butKind[6],ccui.TextureResType.plistType)
               elseif var.State == 3  then 
                  item:getChildByName('Button_join'):loadTextures(butKind[3],butKind[3],butKind[3],ccui.TextureResType.plistType)
               end  
           elseif var.State == 2  then      
                   -- local function SignUps(event) 
                   --     if event.name == 'ended' then 
                   --          cb1()
                   --     end 
                   -- end  
                   -- item:getChildByName('Button_join'):onTouch(SignUps)
           else 
               item:getChildByName('Button_join'):setEnabled(false)       
               if var.State == 3 then 
                   -- item:getChildByName('Button_join'):setColor(cc.c3b(77,77,77))
                   -- local function nonono(event) 
                   --     if event.name == 'ended' then 
                   --          LuaTools.showAlert('您未报名,无法入场')
                   --     end 
                   -- end  
                   -- item:getChildByName('Button_join'):onTouch(nonono)
               end 
           end 
           count = count + 1 
        end     
    end  
end  

--申请报名
function UIAwards:requestSignUp(tag,id,cb) 
    local tempReged = self:getInfoById(id,tag) 
    local strMsg 
    if tempReged.Condition ~= '免费参加' then 
       strMsg =  '报名本场比赛需消耗('..tempReged.Condition..'),确定报名?'
    else   
       strMsg= '报名后将无法取消报名,确定报名?'
    end    
    local countTime = self:countNowTime(string.sub(tempReged.StartTime,-8))
    if #self.alReadyReged > 0 then 
        for k,v in pairs(self.alReadyReged) do 
            if  math.abs(v.count-countTime) <=3600 then 
               strMsg = '您已报名'..v.time..'开始的'..v.title..',是否继续报名?'
            end   
        end   
    end   
    local d = G_BASEAPP:addView('UIDialog', 65530)
    d:setupDialog('', strMsg, 
    function()
        d:removeSelf()
        local tab = { 
            ['uid']   = G_UID,
            ['token'] = G_TOKEN, 
            ['type']  = tag,
            ['id']    = id,
            ['unionid']   = G_CHANNELID,
            ['cmd']   = HttpHandler.CMDTABLE.MATCH_SIGHUP, 
         } 
        local function succ(arg)
            dump(arg,'比赛场报名成功')
            if arg.msg then 
               LuaTools.showAlert(arg.msg)
            end     

            if tempReged.Id then 
               local tempTab = {} 
               tempTab.title = tempReged.Name 
               tempTab.time  = string.sub(tempReged.StartTime,-8) 
               tempTab.count = countTime 
               table.insert(self.alReadyReged,tempTab)
            end   
            self.pData.coin    = tonumber(arg.info.coin)  or self.pData.coin 
            self.pData.gem     = tonumber(arg.info.gem)   or self.pData.gem  
            self.pData.prop[3] = tonumber(arg.info.prop['1'])  or self.pData.prop[3]

            self:updateWealth()
            if cb then 
                cb(arg)
            end     
        end 

        local function fail(arg)
            dump(arg,'比赛场报名失败')
            if arg.lackMoney and tonumber(arg.lackMoney) == 1 then 
               for k,v in pairs(self.allInfo[self.lastSelected]) do  
                   if v.Id == id  and v.Type == tag then 
                       -- local parTemp = v 
                       -- if parTemp and parTemp.Fee and parTemp.Fee.asset and parTemp.Fee.asset.type == 2  then  --元宝
                       --      G_BASEAPP:addView('UIShopDiamond', 1200,function(arg) 
                       --          self['Text_myGem']:setString(LuaTools.convertAmountChinese(self.pData.gem))
                       --          self['Text_myCoins']:setString(LuaTools.convertAmountChinese(self.pData.coin))
                       --      end) 
                       -- elseif  parTemp and parTemp.Fee and parTemp.Fee.asset and parTemp.Fee.asset.type == 1  then  --金币
                       --     if self.pData.bank and tonumber(self.pData.bank)> 0 then 
                       --         G_BASEAPP:addView('UISupplyMoney',self:getLocalZOrder()+1,function(arg) 
                       --          self['Text_myCoins']:setString(LuaTools.convertAmountChinese(self.pData.coin))
                       --         end)
                       --     else     
                       --         self:enterQuickBuy() 
                       --     end  
                       -- else 
                       --     G_BASEAPP:addView('UIShop',1200)       
                       -- end     
                       self:enterQuickBuy() 
                       break
                   end   
               end         
            end   
        end      
        LuaTools.fastRequest(tab,succ,fail)
    end) 
end     

--取消报名 
function UIAwards:cancelSignUp(tag,id,cb)
    local tempReged = self:getInfoById(id,tag) 

    local tab = { 
            ['uid']   = G_UID,
            ['token'] = G_TOKEN, 
            ['type']  = tag,
            ['id']    = id,
            ['unionid']   = G_CHANNELID,
            ['cmd']   = HttpHandler.CMDTABLE.MATCH_CANCEL, 
         }
    local function succ(arg)
        dump(arg,'取消报名 成功')
        if arg.msg then 
           LuaTools.showAlert(arg.msg)
        end     
        self.pData.coin    = tonumber(arg.info.coin)  or self.pData.coin 
        self.pData.gem     = tonumber(arg.info.gem)   or self.pData.gem  
        self.pData.prop[3] = tonumber(arg.info.prop['1'])  or self.pData.prop[3]
        self:updateWealth()
        if cb then 
            cb(arg)
        end     
    end 

    local function fail(arg)
        dump(arg,'取消报名 失败')
    end      
    LuaTools.fastRequest(tab,succ,fail)
end     


function UIAwards:getInfoById(id,tag)
     local info = {}
     for k,v in pairs(self.allInfo[self.lastSelected]) do  
         if v.Id == id  and tag == v.Type then 
             info = v 
             break
         end   
     end 
     return info
end   

function UIAwards:requestEnterGame(info,types,time,cb)
     if cb then cb() end  
     G_BASEAPP:callMethod("UIMain", "loadGameRoomsInfos", self.config.keyDataGames.match,
     function() 
     info.port = self.pData.GameTypes.GameType_MATCH[info.Type].port 
     G_BASEAPP:addView('UIGameTableMatch',1200,info,info.Type,time,function() self:closeNow() end)
     end,
     function() end) 
end     


function UIAwards:updateRule(info,cb1,cb2,tag)
   self:openActionView(self['Panel_interface'])
   self['Panel_rule1']:getChildByName('Text_name'):setString(info.Name)
   self['Panel_rule1']:getChildByName('Text_time'):setString(info.RegistTime..'(开赛前'..info.EnterTime..'分钟停止报名)')
   self['Panel_rule1']:getChildByName('Text_gameTime'):setString(info.StartTime)
   self['Panel_rule1']:getChildByName('Text_condition'):setString(info.Condition..'(优先消耗门票)')
   self['Panel_rule1']:getChildByName('Text_number'):setString('最低'..info.MinPlayers..'人,最高'..info.MaxPlayers..'人')
   
   self['Panel_rule1']:setVisible(true)
   self['Panel_rule2']:setVisible(false)
   self['Panel_rule3']:setVisible(false) 
   self['Panel_rule4']:setVisible(false) 
   self['Button_go']:setTitleText(info.State ~= 2  and '知道了' or (info.IsReged ==1 and '好的' or '立即报名') )

   local function confirmOrCancel(event) 
      if event.name == 'ended' then 
          local text = self['Button_go']:getTitleText() 
          if text == '立即报名' then 
                if cb1 then 
                    cb1() 
                end     
          elseif  text == '好的' then 
              if cb2 then 
                cb2()
              end    
          end   
          -- self['Panel_interface']:setVisible(false)
          self:closeActionView(self['Panel_interface'])
      end  
   end  
   self['Button_go']:onTouch(confirmOrCancel)

   local count = 0 
   local listParent  = tag== 4 and self['ListView_rewardRule1'] or self['ListView_rewardRule']   
   listParent:removeAllChildren()
   local cupKind = {'res_awards/top_win_01.png','res_awards/top_win_02.png','res_awards/top_win_03.png'}
   
   local newReward = {}  
   if info.Reward then 
     for k,v in pairs(info.Reward) do 
         newReward[tonumber(k)] = v 
     end     
   end 

   local function testSort(a,b)
      return tonumber(a.level)< tonumber(b.level)
   end
   table.sort(newReward,testSort)

   local rewardTab = {}  
   if  tag ~= 4  then 
       for  k=1,#newReward do 
            local var = newReward[k] 
            rewardTab[k] = {}
            listParent:pushBackDefaultItem()
            local item = listParent:getItem(count)
            item:getChildByName('Image_cup'):setVisible(var.level <= 3 )
            if var.level <=3 then 
               item:getChildByName('Image_cup'):loadTexture(cupKind[var.level],ccui.TextureResType.plistType)
            end 
            if var.minRank == var.maxRank then 
               item:getChildByName('Text_rank'):setString('第'..var.minRank..'名')
            else 
               item:getChildByName('Text_rank'):setString('第'..var.minRank..'-'..var.maxRank..'名')
            end     
            local reward = ''
            if var.name and var.name ~= '' then 
               reward = reward..var.name..',' 
            end 

            if var.coin ~= 0 then 
               reward = reward..LuaTools.convertAmountChinese(var.coin)..'金币'..','
            end 
            
            if var.gem ~=  0 then 
               reward = reward..LuaTools.convertAmountChinese(var.gem)..'个元宝'..','
            end    

            if var.telfee ~=  0 then 
               reward = reward..var.telfee..'张话费券'..',' 
            end   



            if var.ticket and var.ticket.count > 0 then 
               reward = reward..var.ticket.count..'张'..self.ticketKind[var.ticket.type]..','                         
            end  
            rewardTab[k].reward = string.sub(reward,1,(#reward-1)) 
            rewardTab[k].minRank = var.minRank 
            rewardTab[k].maxRank = var.maxRank 
            item:getChildByName('Text_reward'):setString(string.sub(reward,1,(#reward-1)))
            item:setVisible(true)  
            count = count + 1 
       end 
   else  
       for  k=1,#newReward do 
            local var = newReward[k] 
            rewardTab[k] = {}   
            local reward = ''
            if var.name and var.name ~= '' then 
               reward = reward..var.name..',' 
            end 
            if var.coin ~= 0 then 
               reward = reward..LuaTools.convertAmountChinese(var.coin)..'金币'..',' 
            end 
            
            if var.gem ~=  0 then 
               reward = reward..LuaTools.convertAmountChinese(var.gem)..'个元宝'..',' 
            end    

            if var.telfee ~=  0 then 
               reward = reward..var.telfee..'张话费券'..','  
            end   

            if var.ticket and var.ticket.count > 0 then 
               reward = reward..var.ticket.count..'张'..self.ticketKind[var.ticket.type]..','                          
            end  
            rewardTab[k].reward = string.sub(reward,1,(#reward-1)) 
            rewardTab[k].minRank = var.minRank 
            rewardTab[k].maxRank = var.maxRank 
       end  

       local function getRewardInfo(ranks)
           local a = ''
           for k,v in pairs(rewardTab) do 
               if tonumber(ranks)>=v.minRank and tonumber(ranks)<=v.maxRank then 
                    a = v.reward 
                    break
               end  
           end
           return a 
       end  
        
       local totalNumRank = 0 
       for i,v in pairs(info.Rank)  do 
           if v then 
              totalNumRank = totalNumRank + 1 
           end    
       end  

       -- dump(info.Rank,'当前的=======')
       if totalNumRank>0 then 
          for k=1,totalNumRank do 
              listParent:pushBackDefaultItem()
              local item = listParent:getItem(k-1)
              item:getChildByName('Image_cup'):setVisible(k <= 3 )
              item:getChildByName('Text_name'):setString(info.Rank[tostring(k)] or '') 

              if k <=3 then 
                 item:getChildByName('Image_cup'):loadTexture(cupKind[k],ccui.TextureResType.plistType)
              end 
              item:getChildByName('Text_rank'):setString('第'..k..'名')
              item:getChildByName('Text_reward'):setString(getRewardInfo(k))
              item:setVisible(true)  
          end   
       end   
   end     
end     



return UIAwards
