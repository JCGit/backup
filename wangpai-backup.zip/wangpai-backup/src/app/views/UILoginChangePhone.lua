local UILoginChangePhone = class("UILoginChangePhone", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
UILoginChangePhone.RESOURCE_FILENAME = "UILoginChangePhone.csb"
--UIActivity.RESOURCE_PRELOADING = {"main.png"}
--UIActivity.RESOURCE_LOADING  = { ["res/background/mohuBg.png"] = {names = {"Image_bgAll"}} }

UILoginChangePhone.RESOURCE_BINDING = { 
    ["Button_Close"]  = {["ended"] = "onClose"},
    ["Button_confirm"]  = {["ended"] = "onConfirm"},
    ["Button_GetSms"]  = {["ended"] = "onGetSms"},

    }

function UILoginChangePhone:onCreate()
    local app = self:getApp()
    self.app = app
    self.tool = app:getModel('Tools') 
    self.account = app:getModel('Account')
    self.config = app:getData('Config')
    self.pData = app:getData('PlayerData')

    self:initTextField(self['TextField_oldphone'])
    self:initTextField(self['TextField_newphone'])
    self:initTextField(self['TextField_newphone2'])
    self:initTextField(self['TextField_smsCode'])

    self.account:handleTxfControl(self['TextField_oldphone'],nil, 'num')
    self.account:handleTxfControl(self['TextField_newphone'], nil, 'num')
    self.account:handleTxfControl(self['TextField_newphone2'],nil, 'num')
    self.account:handleTxfControl(self['TextField_smsCode'], nil, 'num')

    --init Get Sms code Enable time
    if self.pData.smsCodeTimeEnable > 0 then
        self.timeLast = self.config.getSmsDelayTime - (os.time() - self.pData.smsCodeTimeEnable)
        if self.timeLast > 0 then
            self['Button_GetSms']:setEnabled(false)
            self['Button_GetSms']:setTitleText('('..self.timeLast..')获取')
            self:createSchedule('updateCount', function()  
                self.timeLast = self.timeLast - 1
                self['Button_GetSms']:setTitleText('('..self.timeLast..')获取')
                if self.timeLast == 0 then
                    self:stopSchedule('updateCount')
                    self['Button_GetSms']:setEnabled(true)
                    self['Button_GetSms']:setTitleText('获取')
                end
            end,1)
        else
            self['Button_GetSms']:setEnabled(true)
            self['Button_GetSms']:setTitleText('获取')
        end
    end
end

function UILoginChangePhone:initTextField(_txf)
    _txf:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    _txf:setTextColor(self.config.Txf_textColorLogin)
end

function UILoginChangePhone:onClose()
    
    self:stopSchedule('updateCount')
    self:removeSelf()
end

function UILoginChangePhone:onConfirm()
    
    local oldphone = self['TextField_oldphone']:getString()
    local phone = self['TextField_newphone']:getString()
    local phone2 = self['TextField_newphone2']:getString()
    local codeSms = self['TextField_smsCode']:getString()

    if #oldphone ~= 11 or false == self.account:strContainOnlyNum(oldphone) then
        self.tool:showTips("旧的电话号码不正确请重新输入。")
        return
    end    

    --检测密码内容是否合格
    if  #phone ~= 11 or false == self.account:strContainOnlyNum(phone) then
        self.tool:showTips("新的电话号码不正确请重新输入。")
        return
    end
    --检测两次输入的密码是否一致
    if phone ~= phone2 then
        self.tool:showTips("两次输入的电话号码不一致，请重新输入。")
        return
    end

    if (false == self.account:strContainOnlyNum(codeSms)) or #codeSms == 0 then
        self.tool:showTips(self.account.smsCodeError)
        return
    end
    
    local dataTable =     {
        ['uid']   = self.pData.uid,
        ['token']  = self.pData.token,
        ['oldPhone']      = oldphone,
        ['phone']      = phone,
        ['msgCode']       = codeSms,
        ['cmd']       = HttpHandler.CMDTABLE.MODIFY_PHONE,
    }
    local function succ(arg)
        self.tool:showTips(arg.msg)
        local function cb() 
            self:stopSchedule('updateCount')
            self:removeSelf()
        end
        self:runAction(cc.Sequence:create(cc.DelayTime:create(1.5), cc.CallFunc:create(cb),nil))
    end
     local function fail(arg)
        self.tool:showTips(arg.msg)
    end
    self.tool:fastRequest(dataTable,succ, fail)
end

function UILoginChangePhone:onGetSms()
    self:requestGetSmsCode()
end

function UILoginChangePhone:requestGetSmsCode()
    local oldphone = self['TextField_oldphone']:getString()
    local phone = self['TextField_newphone']:getString()
    local phone2 = self['TextField_newphone2']:getString()

    if #oldphone ~= 11 or false == self.account:strContainOnlyNum(oldphone) then
        self.tool:showTips("旧的电话号码不正确请重新输入。")
        return
    end    

    --检测密码内容是否合格
    if  #phone ~= 11 or false == self.account:strContainOnlyNum(phone) then
        self.tool:showTips("新的电话号码不正确请重新输入。")
        return
    end
    --检测两次输入的密码是否一致
    if phone ~= phone2 then
        self.tool:showTips("两次输入的电话号码不一致，请重新输入。")
        return
    end

    local dataTable =     {
        ['type']   = 1,
        ['account']   = "",
        ['uid']   = '',
        ['phone']   = phone,
        ['cmd']       = HttpHandler.CMDTABLE.GET_SMS,
    }
    local function succ(arg)
        self.tool:showTips(arg.msg)
        self.pData.smsCodeTimeEnable = os.time()
        self.timeLast = self.config.getSmsDelayTime
        self['Button_GetSms']:setEnabled(false)
        self:createSchedule('updateCount', function()  
        self.timeLast = self.timeLast - 1
        self['Button_GetSms']:setTitleText('('..self.timeLast..')获取')
        if self.timeLast == 0 then
            self:stopSchedule('updateCount')
            self['Button_GetSms']:setEnabled(true)
            self['Button_GetSms']:setTitleText('获取')
        end
        end,1)
    end

    local function fail(arg)
        self.tool:showTips(arg.msg)
    end
    self.tool:fastRequest(dataTable,succ, fail)
end


return UILoginChangePhone
