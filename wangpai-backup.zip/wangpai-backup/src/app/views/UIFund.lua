local UIFund = class("UIFund", cc.load("mvc").ViewBase)

UIFund.RESOURCE_FILENAME = "UIFund.csb"

local HttpHandler = require("app.network.HttpHandler")
local GameTableCommon = require("app.models.GameTableCommon")

UIFund.RESOURCE_BINDING = { 
      --["ListView_fund"] = {["ON_SELECTED_ITEM_END"] = "selectKind"},      
      ["Button_back"] = {["ended"] = "backView"}, 
      ["Button_buy"] = {["ended"] = "buyFund"}, 

    } 

function UIFund:backView()
    if not self.fundNum then self.fundNum = 0 end 
    self.app:callMethod('UIMainTop','updateFundRedPoint',self.fundNum> 0 )
    --self.app:removeView('UIFund')
    LuaTools.viewAction1Over(self['Panel_second'],'UIFund')
end   

function UIFund:buyFund()
    local dataTable =     {
        ['uid']    = self.PlayerData.uid,
        ['token']  = self.PlayerData.token,
        ['cid']    = 6,
        ['cmd']    = HttpHandler.CMDTABLE.GET_PRODUCT,
    }
    local function succ(arg)
        --self:parseProductData(arg)
        self.app:addView('UICharge',self:getLocalZOrder()+10,arg.products[1])
    end
    local function fail(arg)
        if arg.msg then
            self.tool:showAlert(arg.msg)
        end
    end
    self.tool:fastRequest(dataTable,succ, fail)
end     




function UIFund:onCreate()
    local app = self:getApp()
    self.app = app
    self.tool = app:getModel('Tools')
    
    self.fundNum = 0 
    self.PlayerData = app:getData('PlayerData')
    local function cb() 
        local ver     = UserCache.getUserDataByKey("task_version8") 
        self.desc_get = UserCache.getUserDataByKey("task_desc_get8") 
        local table = {
            ['uid']    = self.PlayerData.uid, 
            ['token']  = self.PlayerData.token,
            ['gameType'] = 8, 
            ['version']  = ver or '',
            ['cmd']    = HttpHandler.CMDTABLE.GET_TASK }
        self.numTask = 0  
        local function succ(arg)
            if arg.result == 0 then  
                self:initList(arg)
                UserCache.setUserDataByKey("task_version8",arg.version)
                if arg.desc and  #arg.desc > 0 then 
                   UserCache.setUserDataByKey("task_desc_get8",arg.desc)
                end 
            else 
                self.tool:showTips(arg.msg)
            end 
        end     
        local function fail()
            print('fundFail')
        end     
        LuaTools.fastRequest(table,succ,fail)
        self:UpdateInfo()
    end 
    LuaTools.enterActionScaledWithMask(self['Panel_second'],cb)    
end

function UIFund:initList(info)
    local function getStateMatch(id) 
        local state 
        for key,var in pairs(info.state) do 
            if  var.TaskId == id then 
                state = var.State 
                break 
            end       
        end     
        return state
    end     

    local function touchGet(event)
        if event.name == 'ended' then    
            local tag = event.target:getTag()
            local tab = {
                ['uid']    = self.PlayerData.uid, 
                ['token']  = self.PlayerData.token,
                ['gameType'] =  8,
                ['taskId']  = tag,
                ['cmd']    = HttpHandler.CMDTABLE.GET_TASK_REWARD
            }
            local function succ(arg)
                self.numTask = self.numTask -1 
                self.PlayerData.coin = tonumber(arg.coin)
                self.PlayerData.gem  = tonumber(arg.gem)                
                local parent = event.target:getParent()  --self['ListView_item']:getItem(tag-1)
                parent:getChildByName("Button_get"):setVisible(false)
                parent:getChildByName("Image_fin"):setVisible(true)
                --audio.playSound(Sound.SoundTable['sfx']['Task'] , false)
                self.tool:showTips('基金领取成功')
                --LuaTools.coinRain(self['Panel_All']) 
                if G_BASEAPP:getView('UIMainTop') then 
                   G_BASEAPP:callMethod('UIMainTop','updateWealth') 
                end  
                if  GameTableCommon.getLastDelegate()  then 
                    GameTableCommon.updateGems(GameTableCommon.getLastDelegate(),self.PlayerData.gem)
                    if GameTableCommon.getLastDelegate().Button_jijin then 
                        GameTableCommon.getLastDelegate().Button_jijin:setVisible(false)
                    end      
                end     

                if parent == self['Panel_model6'] then 
                     self.PlayerData.bitFundFinish = 1 
                     G_BASEAPP:callMethod('UIMainTop','updateGpack') 
                end     


                if self.fundNum > 0 then 
                    self.fundNum = self.fundNum -1 
                end     
                --self.sound:playEffect('Get_Coin') 
            end 
            self.tool:fastRequest(tab,succ)
        end 
    end 
    if #info.desc == 0  then 
        info.desc = self.desc_get 
    end     
    local temp_table = {}   --info.desc   info.state
    for key=1,#info.state  do
        local temp = {} 
        temp.TaskDesc    = info.desc[key].TaskDesc  
        temp.TaskCount   = info.desc[key].TaskCount  or 0
        temp.TaskProcess = getStateMatch(info.desc[key].TaskId) or 0
        temp.gem         = info.desc[key]['TaskAwards'].gem  or 0 
        temp.id          = info.desc[key].TaskId  or 0
        table.insert(temp_table,temp) 
    end 
    local gem_tab = {'res_charge/img_gem1.png','res_charge/img_gem2.png','res_charge/img_gem3.png',
                     'res_charge/img_gem4.png','res_charge/img_gem5.png','res_charge/img_gem5.png'}
    for key=1,6 do 
        local var = temp_table[key]
        local precess = tonumber(var.TaskProcess)
        local model= self['Panel_model'..key]  
        model:setVisible(true)
        model:getChildByName('Text_total'):setString(var.TaskDesc)
        model:getChildByName("Button_get"):setVisible(precess == -1 )
        model:getChildByName("Button_get"):setTag(var.id)
        model:getChildByName("Button_get"):onTouch(touchGet)   
       -- model:getChildByName("Image_gem"):loadTexture(gem_tab[key],ccui.TextureResType.plistType)
        model:getChildByName("Image_ing"):setVisible(precess > -1 and self.PlayerData.bitcheckFund == 1)
        model:getChildByName("Image_fin"):setVisible(precess == -2)
        model:getChildByName("Image_no"):setVisible(self.PlayerData.bitcheckFund == 0)
        if precess >= 0 then 
            self.Text_totalNum:setString(precess) 
        end     
        local str1 =var.gem ..' 元宝'
        if precess == -1 then 
            self.fundNum = self.fundNum+ 1 
        end     
        model:getChildByName('Text_money'):setString(str1)
    end 
    for key =1 ,5 do 
        self['Panel_second']:getChildByName('Image_arrow'..key):setLocalZOrder(999)
    end     
end   

function UIFund:UpdateInfo()
    self["Button_buy"]:setVisible(self.PlayerData.bitcheckFund == 0)
    if self.PlayerData.bitcheckFund == 1 then  
        self.Button_back:getChildByName('Image_word'):loadTexture('res_fund/gb.png',ccui.TextureResType.plistType) 
        local size = self.Panel_second:getContentSize()
        self.Button_back:setPositionX(size.width/2)
        for key = 1,6 do 
            self['Panel_model'..key]:getChildByName("Image_no"):setVisible(false)  
            self['Panel_model'..key]:getChildByName("Image_ing"):setVisible(true)
        end 
    else
        self.Button_buy:setVisible(true)

    end 
    self.Button_back:setVisible(true)

end     


return UIFund
