local UIHelps= class("UIHelps", cc.load("mvc").ViewBase)
UIHelps.RESOURCE_FILENAME = "UIHelps.csb"
local HttpHandler = require("app.network.HttpHandler")

UIHelps.RESOURCE_BINDING = { 
    ["Button_Close"] = {["ended"] = "onBack"},
    ["Button_confirm"] = {["ended"] = "confirm"},
    ["Button_agreement"] = {["ended"] = "onOpenAgreement"},
    }


function UIHelps:onCreate(tag)
    local app = self:getApp()
    self.app = app
    self.config = app:getData('Config')
    self.tool = app:getModel('Tools')
    self.pData = app:getData('PlayerData')
    self.account = app:getModel('Account')
    self.tempTag = tag  or 1    
    self:setSkipGoBack(true )

   local function recruFunc()  
        print("======UIActivity:onCreate()======overrided==========================")  
        self:addGobackEventAction(function() recruFunc() end) 
    end
    self:addGobackEventAction(function()
        recruFunc() 
    end)

    self.subviews = {
        --1.view name     2.objet
        {"UIHelpFrequent", nil},
        {"UIHelpPointRule", nil},
        {"UIHelpGetChips", nil},
        {"UIHelpGamesRule", nil},
        {"UIHelpFeedback", nil},
    }
    self.objetViewSel = nil
    self.indexViewSelected = 0

    self:initUIViews()

    LuaTools.enterActionScaledWithMask(self['Panel_All'])
    LuaTools.viewAction1(self.objetViewSel:getPanelMain())
end

function UIHelps:transitionViewAction(_action)
   self:runAction(_action:clone())
   self.objetViewSel:runAction(_action:clone())
end

function UIHelps:showView(index, _show)
    if index < 1 or index > #self.subviews then return end
    
    if self.indexViewSelected == 0 then 
        self.objetViewSel = self.app:addView(self.subviews[index][1],205)
        self.subviews[index][2] = self.objetViewSel
    else
        local oldpanel = self['Panel_Type_'..self.indexViewSelected]
        oldpanel:getChildByName('Text_title'):setColor(self.config.ColorTextUnselect)
        oldpanel:getChildByName('Image_blur'):setVisible(false)
        
        self.objetViewSel:setVisible(false)
        if self.subviews[index][2] == nil then 
            self.objetViewSel = self.app:addView(self.subviews[index][1],205)
            self.subviews[index][2] = self.objetViewSel
        else
            self.objetViewSel = self.subviews[index][2]
        end
    end
    local newpanel = self['Panel_Type_'..index]
    newpanel:getChildByName('Text_title'):setColor(self.config.ColorTextSelect)
    newpanel:getChildByName('Image_blur'):setVisible(true)
    newpanel:setVisible(true)
    if _show then 
        self.objetViewSel:setVisible(_show)
    else
        self.objetViewSel:setVisible(true)
    end
    
    self.indexViewSelected = index
end

function UIHelps:initUIViews() 
    local function onSwitchView(event)
        if event.name == 'began' then
          
        elseif event.name == 'ended' then
            local tag = event.target:getTag()
            if tag ==  self.indexViewSelected  then
                return
            end
            self:showView(tag)
            for i, var in pairs(self.subviews) do
                --self.tool:freezeWidget(self['Panel_Type_'..i], 0.3)
            end
        end
    end
    
    for key,var in pairs(self.subviews) do
        local panel = self['Panel_Type_'..key]
        panel:setTag(key)
        panel:onTouch(onSwitchView)
        panel:getChildByName('Image_blur'):setVisible(false)
        panel:getChildByName('Text_title'):setColor(self.config.ColorTextUnselect)
    end

    self:showView(self.tempTag,true)
end

function UIHelps:onBack()
    -- self:removeSelf()
    if self.objetViewSel and self.objetViewSel.removeSelf then 
        LuaTools.viewAction1Over(self.objetViewSel:getPanelMain(),self.subviews[self.indexViewSelected][1])
    end
    LuaTools.viewAction1Over(self["Panel_All"],"UIHelps")
end

function UIHelps:onExit1( )
    -- body
    for i,view in ipairs(self.subviews) do
        local object = view[2]
        if object and object.removeSelf then
            object:removeSelf()
            object = nil
        end
    end
end

function UIHelps:onOpenAgreement()
    print("Opening Xieyi URL")
    
    -- LuaTools.openWebURL("http://ddz.217play.com:17179/agreement/agreement")
end

return UIHelps








