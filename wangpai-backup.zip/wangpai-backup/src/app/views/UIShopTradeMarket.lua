local UIShopTradeMarket = class("UIShopTradeMarket", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
UIShopTradeMarket.RESOURCE_FILENAME = "UIShopTradeMarket.csb"
--UIShopCoin.RESOURCE_PRELOADING = {"main.png"}
--UIShopCoin.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIShopTradeMarket.RESOURCE_BINDING = {
    ["Button_SellChips"]   = {["began"] = "onSellChips"},
    ["Button_BuyChips"]   = {["began"] = "onBuyChips"},
    ["Button_refresh"]   = {["began"] = "onRefresh"},
    ["Button_Sell"]   = {["ended"] = "onSell"},
    ["Button_listAmount"]   = {["ended"] = "onShowListAmount"},
    ["ListView_amount"]  = {["ON_SELECTED_ITEM_END"] = "onClickListviewAmount"},
    }

local ONE_PAGE = 10

--初始化
function UIShopTradeMarket:onCreate()
    local app = self:getApp()
    self.app = app
    self.tool = app:getModel('Tools')
    self.pData = self.app:getData('PlayerData')
    self:setSkipGoBack(true )
    self.config = self.app:getData('Config')
    self.indexListAmountSel = 1      --排序标签
    self.isViewInit = false          
    self.indexForServer = -1
    self.sortData = {0, 10, 50, 100} --购买市场排序
    
    self.mainListView = self['ListView_Items']
    self.mainListView:setItemModel(self['Panel_Item'])
    self['Panel_Item']:setVisible(false)
    self['Image_bgd']:setVisible(false)

    self.listViewAmount = self['ListView_amount']
    self.listViewAmount:setScrollBarEnabled(false)
    self.panelAmount = self['Panel_amount']
    self.bgListView = self['Image_bgListview']
    self:setVisible(false)
end

--初始化UI
function UIShopTradeMarket:init()
    self:initUIView()
    self:requestGetProduct(1, false)
    self:setVisible(true)
end

function UIShopTradeMarket:getPanelMain()
    return self['Panel_main']
end

function UIShopTradeMarket:initUIView()
     self.listClass = {'最便宜','1-10元宝','11-50元宝','50以上元宝'}
    --init amount list
    self:initClassList(self.listClass)

    self:setClassificationBuyInfos(self.indexListAmountSel)
    --init list item
    local function onScrolled(event)
        if event.name == "BOUNCE_BOTTOM" then
            if #self.listData < 10*self.indexPage then
                return
            end
            self.mainListView:setTouchEnabled(false)
            self.mainListView:setBounceEnabled(false)
            print('EXPENDING PAGE...')
            self.indexPage = self.indexPage + 1
            self:requestGetProduct(self.indexPage, true)
        end
    end
    self.mainListView:onScroll(onScrolled)
end

--售卖金币
function UIShopTradeMarket:onSell()
    
    self.app:addView('UIShopSubviews', self:getLocalZOrder() + 1, 3)
end

--刷新交易市场
function UIShopTradeMarket:onRefresh()
    
    self:requestGetProduct(1, false)
end

function UIShopTradeMarket:setClassificationBuyInfos(index)
    self['Text_amountChosen']:setString(self.listClass[index])
    self.indexListAmountSel = index
end

--显示交易市场价格表
function UIShopTradeMarket:onShowListAmount()
    
    self.listViewAmount:setVisible(not  self.listViewAmount:isVisible())
    self.bgListView:setVisible(not  self.bgListView:isVisible())
    local bt = self['Button_listAmount']
    if self.listViewAmount:isVisible() == true then 
        bt:loadTextureNormal("res_shop/btn_up.png", ccui.TextureResType.plistType)
        bt:loadTexturePressed("res_shop/btn_up.png", ccui.TextureResType.plistType)
    else
        bt:loadTextureNormal("res_shop/btn_down.png", ccui.TextureResType.plistType)
        bt:loadTexturePressed("res_shop/btn_down.png", ccui.TextureResType.plistType)
    end
end

--点击交易市场价格表元素
function UIShopTradeMarket:onClickListviewAmount(event) 
    local indexSel = event.target:getCurSelectedIndex()+1
    self:setClassificationBuyInfos(indexSel)
    self:requestGetProduct(1, false)
    self:onShowListAmount()
end

--初始化易市场价格表UI
function UIShopTradeMarket:initClassList(list)
    --init amount list
    self.listViewAmount:removeAllChildren()
    self.listViewAmount:setItemModel(self.panelAmount)
    self.panelAmount:setVisible(true)
    local panel
    for key, var in ipairs(list) do
        self.listViewAmount:pushBackDefaultItem()
        panel = self.listViewAmount:getItem(key-1)
        panel:getChildByName('Text_amount'):setString(var)
        if key == #list then
            panel:getChildByName('Image_botborder'):setVisible(false)
        end
    end
    self.panelAmount:setVisible(false)
    self.listViewAmount:setVisible(false)
    self.bgListView:setVisible(false)
end

--显示金币买列表
function UIShopTradeMarket:updateBuyChipsView(_array)
    local function onBuy(event)
        if event.name == 'ended' then
            local indexSel = event.target:getTag()
            G_BASEAPP:addView('UIDialog',999999)
            G_BASEAPP:callMethod('UIDialog','setupDialog', '','确定购买?',
                    function() 
                       self:requestBuyProduct(self.listData[indexSel].mid)
                    end)
        end
    end
    
    local function onOffMarket(event)
        if event.name == 'ended' then
            local indexSel = event.target:getTag()
            self:requestOffMarket(self.listData[indexSel].mid)
        end
    end
   
    self['Panel_Item']:setVisible(true)
    local item
    for key ,var in ipairs(_array) do
        self.mainListView:pushBackDefaultItem()
        local childCount = self.mainListView:getChildrenCount()
        item = self.mainListView:getItem(childCount-1)
        -- item:getChildByName('Text_itemCount'):setString(var[1])
        item:getChildByName('Text_chips'):setString(self.tool:convertAmountChinese(var.coin)..'金币')
        item:getChildByName('Text_desc'):setString('1元宝='..(math.floor(var.coin/var.gem))..'金币')
        item:getChildByName('Text_player'):setString('卖家:'..var.name)
        if key % 2 == 0 then
            item:getChildByName('Image_mask'):loadTexture("res_shop/img_mask2.png", ccui.TextureResType.plistType)
        end
        local button_panel = item:getChildByName('Panel_Button_buy')
        local btbuy = button_panel:getChildByName('Button_buy')
        local textGem = button_panel:getChildByName('Text_gem')
        if tonumber(var.uid) == self.pData.uid then  --自己的
            
            button_panel:getChildByName('Image_gem'):setVisible(false)
            textGem:setString('下架')
            textGem:setAnchorPoint(cc.p(0.5,0.5))
            textGem:setPositionX(button_panel:getContentSize().width/2)
            btbuy:loadTextureNormal("res_shop/btn_3.png", ccui.TextureResType.plistType)
            btbuy:loadTexturePressed("res_shop/btn_3.png", ccui.TextureResType.plistType)
            local newTxt = item:getChildByName('Text_desc'):clone()
            newTxt:setScale(0.9)
            newTxt:setString('原售价:'..var.gem.."元宝")
            newTxt:setPositionY(item:getChildByName('Text_player'):getPositionY())
            item:getChildByName('Text_desc'):setPositionY(item:getChildByName('Text_chips'):getPositionY())
            item:addChild(newTxt, 1)
            btbuy:onTouch(onOffMarket)
            btbuy:setTag(childCount)
            else
            btbuy:onTouch(onBuy)
            btbuy:setTag(childCount)
            textGem:setString(var.gem)
        end

    end
    self['Panel_Item']:setVisible(false)
    
end

--扩展购买金币列表
function UIShopTradeMarket:appendBuyProductData(data)
    self:updateData(self.listData, data)
    local newData = {}
    self:updateData(newData, data)
    self:updateBuyChipsView(newData)
end

--解析购买金币数据
function UIShopTradeMarket:parseBuyProductData(data)
    self:updateData(self.listData, data)
    self:updateBuyChipsView(self.listData)
end

--解析内容
function UIShopTradeMarket:updateData(_table, data)
    for k = 1, #data.market do
        local subList = {}
        subList.coin = data.market[k].coin or 0
        subList.gem = data.market[k].gem or 0
        subList.mid = data.market[k].mid or 0
        subList.name = data.market[k].name or ""
        subList.uid = data.market[k].uid or ""
        table.insert(_table, subList)
    end
    --dump(_table)
end

--请求交易市场列表
--@params: 市场类型，页，是否是扩展
function UIShopTradeMarket:requestGetProduct(page, isAppend)
    local gemSort = 0
    gemSort = self.sortData[self.indexListAmountSel]
    if isAppend == false then
        self.indexForServer = -1
    end
    local dataTable =     {
        ['uid']   = self.pData.uid,
        ['token']  = self.pData.token,
        ['index']      = self.indexForServer,
        ['type']     = 0,
        ['gems']    = gemSort,
        ['cmd']       = HttpHandler.CMDTABLE.TRADE_MARKET,
    }
    local function succ(arg)
        if self.isViewInit == false then
            self.isViewInit = true
        end
        if isAppend == false then
            self.mainListView:removeAllChildren()
            self.listData = {}
            self.indexPage = 1
            self.indexForServer = arg.index
           --[[ if #arg.market == 0 then
                self['Image_noData']:setVisible(true)
            else
                self['Image_noData']:setVisible(false)
            end]]--
           -- self.indexListviewItem = 0
            self:parseBuyProductData(arg)
        else  
            self.indexPage = page
            self.indexForServer = arg.index
            self:appendBuyProductData(arg)
        
            self.mainListView:jumpToItem((self.indexPage-1)*ONE_PAGE-1, cc.p(0,0), cc.p(0,0))
            
            self.mainListView:setBounceEnabled(true)
            self.mainListView:setTouchEnabled(true)
        end
    end
    self.tool:fastRequest(dataTable,succ)
end

--购买金币
function UIShopTradeMarket:requestBuyProduct(pid)
    local dataTable =     {
        ['uid']   = self.pData.uid,
        ['token']  = self.pData.token,
        ['mid']      = pid,
        ['cmd']       = HttpHandler.CMDTABLE.BUY_COINS,
    }
    local function succ(arg)
        self.pData.coin = tonumber(arg.coin) or 0
        self.pData.gem = tonumber(arg.gem) or 0
        self.tool:showAlert(arg.msg)
        self.app:callMethod('UIShop','updateContent')
        self:requestGetProduct(1, false)
    end
    local function fail(arg)
        if arg.msg then
            self.tool:showAlert(arg.msg)
            -- if string.find(arg.msg,'不足') then 
            --   G_BASEAPP:addView('UIShopDiamond',self:getLocalZOrder()+1)
            -- end  
        end
    end
    self.tool:fastRequest(dataTable,succ, fail)
end

--下架金币
function UIShopTradeMarket:requestOffMarket(pid)
    local dataTable =     {
        ['uid']   = self.pData.uid,
        ['token']  = self.pData.token,
        ['mid']      = pid,
        ['cmd']       = HttpHandler.CMDTABLE.OFF_MARKET,
    }
    local function succ(arg)
        self.pData.coin = tonumber(arg.coin) or 0
        self.pData.gem = tonumber(arg.gem) or 0
        self.tool:showAlert("下架成功")
        self.app:callMethod('UIShop','updateContent')
        self:requestGetProduct(1, false)
    end
    local function fail(arg)
        if arg.msg then
            self.tool:showAlert(arg.msg)
        end
    end
    self.tool:fastRequest(dataTable,succ, fail)
end

return UIShopTradeMarket