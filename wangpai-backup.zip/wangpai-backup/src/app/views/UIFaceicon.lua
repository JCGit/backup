local UIFaceicon = class("UIFaceicon", cc.load("mvc").ViewBase)

UIFaceicon.RESOURCE_FILENAME = "UIFaceicon.csb"
--UIFaceicon.RESOURCE_PRELOADING = {"faceicon.png"}
--UIFaceicon.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}},

UIFaceicon.RESOURCE_BINDING = {
    ["ListView_select"] = {["ON_SELECTED_ITEM_START"] = "selectEvent"},   
    ['Panel_main']      = {["ended"] = "closeView"}, 
    ['Button_hide']     = {["ended"] = "closeView"}, 
    ['Button_send']     = {["ended"] = "sendMsg"}, 
    }

function UIFaceicon:closeView()
    
     LuaTools.viewAction1Over(self['Panel_Layer'],'UIFaceicon')
end 


function UIFaceicon:sendMsg()
    
    local str = self['TextField_say']:getString()
    if self.callback then
        local tbl =  {
                 msgType = 3,
                 msg = str }
        self.callback(tbl)
    end
    -- if G_BASEAPP:getView('UIGameTableDeZhou') then 
    --    G_BASEAPP:callMethod('UIGameTableDeZhou','reqSock_CHAT_WORD',str) 
    -- end   
    G_BASEAPP:removeView('UIFaceicon')
end 

function UIFaceicon:onCreate(_callback)
    local app = self:getApp()
    self.app = app
    LuaTools.viewAction1(self['Panel_Layer'])

    self.PlayerData = app:getData('PlayerData')
    self.callback = _callback
    
    
    self.face = 27
    self.roleTag = 3
    self.lastSelectedIndex =1 
    self:swithchPage(0,1)
    --self:addFace()
    self:initFace()
    self:updateWord() 
    self['ListView_select']:setScrollBarEnabled(false)
    self['TextField_say']:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
end
function UIFaceicon:selectEvent(event)
    local index = event.target:getCurSelectedIndex()+1
    self:swithchPage(self.lastSelectedIndex,index)  
end

function UIFaceicon:swithchPage(from,to)
    local image1_tab = {'res_profile/btn_head_z1.png','res_profile/btn_head_y1.png'}
    local image2_tab = {'res_profile/btn_head_z.png','res_profile/btn_head_y.png'}    
    local temp = {self['Button_touch1'],self['Button_touch2']}
    local temp1 = {self['ListView_word'],self['ListView_chat']}
    if from ~= 0 then 
        temp[from]:loadTextures(image2_tab[from],image2_tab[from],image2_tab[from],ccui.TextureResType.plistType)
        temp1[from]:setVisible(false)
        temp[from]:setTitleColor(cc.c3b(172,147,128))
        
    end     
    temp[to]:loadTextures(image1_tab[to],image1_tab[to],image1_tab[to],ccui.TextureResType.plistType)
    temp1[to]:setVisible(true)
    temp[to]:setTitleColor(cc.c3b(255,255,255))

    self.lastSelectedIndex = to 
    if to ==2 then 
        self:updateChat()
    end 
end 

function UIFaceicon:initFace() --self['ScrollView_face']
    local model
    for key = 1,self.roleTag do 
        self['Panel_model']:getChildByName('Image_'..key):setVisible(false)
    end 
    self['ListView_face']:setItemModel(self['Panel_model'])
    
    local temp = (self.face%self.roleTag == 0 and self.face/self.roleTag or (self.face/self.roleTag+1) ) 
    for key = 1 , temp do         
        self['ListView_face']:pushBackDefaultItem() 
        model =  self['ListView_face']:getItem(key-1)
        model:setVisible(true)
        for k = 1,self.roleTag do     
            if self.face >= (key*self.roleTag+k-self.roleTag) then    
                local image =  model:getChildByName('Image_'..k)
                image:setVisible(true)
                image:loadTexture(string.format('res_chat/faceicon%d.png',key*self.roleTag+k-self.roleTag),ccui.TextureResType.plistType)
                image:getChildByName('Button_1'):setTag(key*self.roleTag+k-self.roleTag)
                image:getChildByName('Button_1'):setOpacity(0)
                
                local function face(event)
                    if event.name == 'ended' then 
                        image:getChildByName('Button_1'):setOpacity(255)
                        local tar = event.target:getTag()
                        if self.callback then
                            local tbl =  {
                                     msgType = 1,
                                     msg = tar }
                            self.callback(tbl)
                        end
                        -- if G_BASEAPP:getView('UIGameTableDeZhou') then 
                        --     G_BASEAPP:callMethod('UIGameTableDeZhou','reqSock_CHAT_FACE',tar)    
                        -- end   
                        G_BASEAPP:removeView('UIFaceicon')        
                    end
                end
                image:getChildByName('Button_1'):onTouch(face)
            end  
        end 
    end 

end 

function UIFaceicon:addFace()
    local layout,item = nil,nil
 
    for key = 1 ,self.face do 
        item = ccui.Layout:create()
        item:setContentSize(self['Image_item']:getContentSize()) 
        local image_name =cc.Sprite:createWithSpriteFrameName(string.format('faceicon/faceicon%d.png',key))
        item:setName("Panel_item_" .. key)
        
        item:setLayoutType(ccui.LayoutType.RELATIVE)    
        local button = ccui.Button:create('icon/faceicon_bg.png','icon/faceicon_bg.png')
        button:setAnchorPoint(0.5,0.5)
        image_name:setAnchorPoint(0.5,0.5)
        button:setTag(key)
        
        button:setPressedActionEnabled(false)
        button:setOpacity(0)
        local function face(event)
           if event.name == 'ended' then 
              button:setOpacity(255)
              local tar = event.target:getTag()
              self.app:callMethod('UIGameHall','butChatFace',tar)          
              self.app:removeView('UIFaceicon')  
           end
        end
        button:onTouch(face)
        item:addChild(image_name,3)
        local size = item:getContentSize()
        image_name:setPosition(size.width/2,size.height/2)
        --item:setBackGroundImage('faceicon/faceicon_bg.png',ccui.TextureResType.plistType) 
        item:addChild(button,2)       
        button:setPosition(size.width/2,size.height/2)
        image_name:setPosition(size.width/2,size.height/2)

        self['ScrollView_face']:setName('Panel_par')         
        self['ScrollView_face']:setLayoutType(ccui.LayoutType.RELATIVE)

        layout = ccui.RelativeLayoutParameter:create()
        layout:setRelativeName("Panel_item_" .. key)
        if key == 1 then 
            layout:setRelativeToWidgetName('Panel_par')
            layout:setAlign(ccui.RelativeAlign.alignParentTopLeft)
            layout:setMargin({left = 30, top = 25, right = 0, bottom = 0})
        elseif key % self.roleTag == 1 then
            layout:setRelativeToWidgetName("Panel_item_" .. key - self.roleTag)
            layout:setAlign(ccui.RelativeAlign.locationBelowCenter)
            layout:setMargin({left = 0, top = 20, right = 0, bottom = 0})
        else
            layout:setRelativeToWidgetName("Panel_item_" .. key - 1)
            layout:setAlign(ccui.RelativeAlign.locationRightOfCenter)
            layout:setMargin({left = 2, top = 0, right = 0, bottom = 0})
        end
        item:setLayoutParameter(layout)
        item:setTouchEnabled(true)
        self['ScrollView_face']:addChild(item)        
    end    
end 

function UIFaceicon:updateWord()
    local model = self['Button_wordItem']
    self['ListView_word']:setItemModel(model)
    local text_table = {'快点吧~我等得花儿都谢了',
        '投降输一半，速度投降吧',
        '你的牌打得太好了',
        '吐了个槽的，整个一个杯具啊',
        '天灵灵，地灵灵，给手好牌行不行',
        '大清早的，鸡还没叫呢，慌什么嘛',
        '不要走，决战到天亮',
        '大家好，很高兴见到各位！',
        '出来混，迟早要还的' }  
    
    local item = nil 
    for key = 1 ,#text_table do 
        self['ListView_word']:pushBackDefaultItem() 
        item =  self['ListView_word']:getItem(key-1)
        item:setVisible(true)
        item:setTitleText(text_table[key])
        item:setPressedActionEnabled(false)
        local function wordTouch(event)
            if event.name == 'ended' then 
                if self.callback then
                    local tbl = 
                    {
                        msgType = 2,
                        msg = key,
                    }
                    self.callback(tbl)
                end
                -- if G_BASEAPP:getView('UIGameTableDeZhou') then 
                --    G_BASEAPP:callMethod('UIGameTableDeZhou','reqSock_CHAT_COMMON',key) 
                -- end    
               G_BASEAPP:removeView('UIFaceicon') 
            end 
        end     
        item:onTouch(wordTouch)
    end    
    model:removeFromParent()
end 

function UIFaceicon:updateChat()
    if  #self.PlayerData.faceIconRecord < 1  then return end 

    self['ListView_chat']:removeAllItems()
    local item = nil 
    for key,var in pairs(self.PlayerData.faceIconRecord) do 
        local model = self['Panel_chatModel']:clone() 
        model:setVisible(true)
        local textArea = ccui.Text:create()
        textArea:ignoreContentAdaptWithSize(false)
        textArea:setContentSize(cc.size(model:getContentSize().width, 48))
        textArea:setAnchorPoint(0,0)
        textArea:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT)
        textArea:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
        textArea:setString(var)
        textArea:setFontSize(22)
        textArea:setPosition(0,5)
        model:addChild(textArea)

        self['ListView_chat']:pushBackCustomItem(model)
    end 
    self['ListView_chat']:scrollToBottom(0.5,true) 
end 

function UIFaceicon:addChatRecord(str)
     if self['ListView_chat']:isVisible() then 
         self['ListView_chat']:pushBackDefaultItem()   
         local model = self['ListView_chat']:getItem(#(self['ListView_chat']:getItems())-1)  
         model:setString(str)
         self['ListView_chat']:scrollToBottom(0.5, true) 
     end 
end     

return UIFaceicon



