local UIRedeemPoints = class("UIRedeemPoints", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")

UIRedeemPoints.RESOURCE_FILENAME = "UIRedeemPoints.csb"

UIRedeemPoints.RESOURCE_BINDING = { 
    ["Button_back"]   = {["ended"] = "backEvent"}, 
    ["Button_1_0"]   = {["ended"] = "changeShowHelp"}, 
    ["Button_1"]   = {["ended"] = "changeShowRecord"}, 
    } 

function UIRedeemPoints:backEvent()
    LuaTools.viewAction1Over(self['Panel_Layer'],'UIRedeemPoints')
end

function UIRedeemPoints:changeShowHelp()
    self.isShowHelp = not self.isShowHelp
    self:setPanelVisible('Panel_2', self.isShowHelp)
end

function UIRedeemPoints:changeShowRecord()
    self.isShowRecord = not self.isShowRecord
    self:setPanelVisible('Panel_2_0', self.isShowRecord)
    if self.isShowRecord then
        self:sortHistory()
        self:refreshHistory()
    end
end

function UIRedeemPoints:refreshHistory()
    self['ListView_2']:setItemModel(self['Panel_4'])
    self['ListView_2']:setScrollBarEnabled(false)
    if #self.history == 0 then
        self['ListView_2']:removeAllItems()
        return
    end
    for i=1,#self.history do
        local data = self.history[i]
        if i > #self['ListView_2']:getItems() then
            self['ListView_2']:pushBackDefaultItem()
        end
        local item = self['ListView_2']:getItem(i-1)
        local timeText = item:getChildByName('Text_15_0_0_0_0_0')
        local desText = item:getChildByName('Text_15_0_0_0_0')
        desText:setString(data.desc)
        local timeStr = os.date("%Y.%m.%d",data.date)
        timeText:setString(timeStr)
    end
end

function UIRedeemPoints:sortHistory()
    local function sort(a, b)
        return a.date < b.date
    end
    table.sort( self.history, sort )
end

function UIRedeemPoints:setPanelVisible(name, visible)
    self[name]:setVisible(visible)
end

function UIRedeemPoints:requestAllData()
    local dataTable =     {
    ['uid']       = self.pData.uid,
    ['token']     = self.pData.token,
    ['cmd']       = HttpHandler.CMDTABLE.ACTIVITY_PROCCESS,
    ['ActiveType']       = 8,
    ['ActiveId']       = 1,
    }
    local function succ(arg)
        dump(arg, "UIRedeemPoints")
        if arg.result == 0 then
            self:refreshUI(arg)
            if arg.history then
                self.history = arg.history
            end
        else
            self.app:removeView('UIRedeemPoints')
        end
    end
    local function fail(arg)
        self.app:removeView('UIRedeemPoints')
    end
    self.tool:fastRequest(dataTable,succ, fail,false)
end

function UIRedeemPoints:refreshUI(data)
    local todayNum = data.Score.today
    local totalNum = data.Score.total
    local startDay = data.StartDay
    local endDay = data.EndDay
    if todayNum then
        self['Panel_main']:getChildByName('Text_1_1_0'):setString(todayNum)
    end
    if totalNum then
        self['Panel_main']:getChildByName('Text_1_1_0_0'):setString(totalNum)
    end
    if startDay and endDay then
        self['Panel_main']:getChildByName('Text_1_1_1_0'):setString(startDay..'-'..endDay)
    end
    
    local allAwards = data.Awards
    if not allAwards or #allAwards == 0 then
        self['ListView_1']:removeAllItems()
        return
    end

    for i=1,#allAwards do
        local data = allAwards[i]
        if i > 1 then
            self['ListView_1']:pushBackDefaultItem()
        end
        local item = self['ListView_1']:getItem(i-1)
        self:setItemByData(item, data)
    end
end

function UIRedeemPoints:setItemByData(item, data)
    local awardText = item:getChildByName('Text_12')
    local numText = item:getChildByName('Text_12_0')
    local pointText = item:getChildByName('Text_12_0_0')
    local str = self:getAwardText(data.award)
    awardText:setString(str)
    if data.count == -1 then
        numText:setString('无限')
    else
        numText:setString(data.count)
    end
    pointText:setString(data.cost)

    local function doReq()
        if self.requesting then
             return       
        end
        local dataTable =     {
            ['uid']       = self.pData.uid,
            ['token']     = self.pData.token,
            ['cmd']       = 'activity/exchangeAwardByScore',
            ['index']       = data.index,
        }
        local function succ(arg)
            self.requesting = false
            dump(arg, "clickFunc")
            if arg.history then
                self.history = arg.history
            end
            if arg.total then
                self['Panel_main']:getChildByName('Text_1_1_0_0'):setString(arg.total)
            end
            self.pData.coin = arg.info.coin
            self.pData.gem = arg.info.gem
            G_BASEAPP:callMethod('UIMain','updateAllPageInfo')
            local num = arg.award.count
            if num == -1 then
                numText:setString('无限')
            else
                numText:setString(num)
            end
            LuaTools.showAlert('成功兑换'..str)
        end
        local function fail(arg)
            self.requesting = false
        end
        self.tool:fastRequest(dataTable,succ, fail,false)
        self.requesting = true
    end

    local function clickFunc(event)
        if event.name == 'ended' then 
            if data.count == 0 then
                LuaTools.showAlert('该奖品已兑换完毕')
                return
            end
            if data.cost >= 50 then
                local d = G_BASEAPP:addView('UIDialog', 65530)
                d:setupDialog('', '是否确认兑换？', 
                function()   
                    doReq()
                end)
            else
                doReq()
            end
        end
    end

    local btn = item:getChildByName('Button_3')
    btn:onTouch(clickFunc)
end

function UIRedeemPoints:getAwardText(data)
    local str = ""
    if data['telfee'] then
        local num = LuaTools.convertAmountChinese(data['telfee'])
        str = str .. num .."话费券 "
    end

    if data['gem'] then
        local num = LuaTools.convertAmountChinese(data['gem'])
        str = str .. num .."元宝 "
    end

    if data['coin'] then
        local num = LuaTools.convertAmountChinese(data['coin'])
        str = str .. num .."金币 "
    end

    if data['vip_day'] then
        local num = LuaTools.convertAmountChinese(data['vip_day'])
        str = str .. num .."VIP成长值 "
    end
    return str
end

function UIRedeemPoints:onCreate(data)
    local app = self:getApp()
    self.app = app
    self.tool  = app:getModel('Tools')
    self.pData = app:getData('PlayerData')
    self.config = app:getData('Config')

    self.isShowHelp = false
    self:setPanelVisible('Panel_2', self.isShowHelp)
    self.isShowRecord = false
    self:setPanelVisible('Panel_2_0', self.isShowRecord)

    local m = self['ListView_1']:getChildByName('Panel_1')
    self['ListView_1']:setItemModel(m)
    self['ListView_1']:setScrollBarEnabled(false)

    local function cb()
        self:requestAllData()
    end

    LuaTools.enterActionScaledWithMask(self['Panel_Layer'],cb)
end

return UIRedeemPoints
