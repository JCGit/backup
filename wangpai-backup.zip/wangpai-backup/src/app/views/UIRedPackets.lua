local UIRedPackets = class("UIRedPackets", cc.load("mvc").ViewBase)

UIRedPackets.RESOURCE_FILENAME = "UIRedPackets.csb"
--UIDialog.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}
local HttpHandler = require("app.network.HttpHandler")

UIRedPackets.RESOURCE_BINDING = { 
    ["Button_close"] = {["ended"] = "exitScene"},

    }



function UIRedPackets:exitScene()  
    LuaTools.viewAction1Over(self['Panel_main'],"UIRedPackets",nil, self)
end

function UIRedPackets:onCreate(num)
    if not num then num = 5 end 
    local app = self:getApp()
    self.app = app
    self.config = app:getData('Config')
    self.tool  = app:getModel('Tools')
    self.pData = self.app:getData('PlayerData')
    
    self['Text_title']:setString('再赢'..num..'局可抢夺以下奖励')
    local function  cb1()
       print('jinrule')
    end     
    LuaTools.enterActionScaledWithMask(self['Panel_main'],cb1)
end   


return UIRedPackets
