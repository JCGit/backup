local UIShopDiamond = class("UIShopDiamond", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
UIShopDiamond.RESOURCE_FILENAME = "UIShopDiamond.csb"
--UIShopPoint.RESOURCE_PRELOADING = {"main.png"}
--UIShopPoint.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIShopDiamond.RESOURCE_BINDING = {
    ["Button_close"] = {["ended"] = "onClose"},
    }
    
    
UIShopDiamond.PAY_ZHIFUBAO = 2
UIShopDiamond.PAY_YIBAO = 3
UIShopDiamond.PAY_WEIXIN = 1
local NUMBER_ITEM_PER_ROW =1

--关闭此UI
function UIShopDiamond:onClose()
    LuaTools.viewAction1Over(self['Panel_main'],"UIShopDiamond")
    --self.app:removeView('UIShopDiamond')
end

--初始化
--@param: 回调
function UIShopDiamond:onCreate(onSuccCb)
    local app = self:getApp()
    self.app = app
    --self:setSkipGoBack(true )
    self.onSuccCb = onSuccCb
    self.tool = app:getModel('Tools')
    self.pData = self.app:getData('PlayerData')
    self.config = app:getData('Config')
    self.mainListView = self['ListView_Items']
    self['Text_myDiamond']:setString(self.tool:convertAmountChinese(self.pData.gem))
    
    self.mainListView:setVisible(false)

    LuaTools.enterActionScaledWithMask(self['Panel_main'], function() self:init() end)

end

--初始化UI
function UIShopDiamond:init()
    if #self.pData.shopDiamonds == 0 then
        self:requestGetProduct()
    else
        self:initProductList()
    end
    self.mainListView:setVisible(true)
end


--初始化产品数据
function UIShopDiamond:initProductList()
    local function onBuy(event)
        if event.name == 'ended' then
            
            local indexSel = event.target:getTag()
            local data = self.pData.shopDiamonds[indexSel]
            if self.pData.paytotal and tonumber(self.pData.paytotal) > 0 then 
                data.rate = 0 
            end     
            local isCoins =  tonumber(data.gem > 0) and false or true 
            payValue = nil

            local function onPaySuccess()
                self['Text_myDiamond']:setString(self.tool:convertAmountChinese(self.pData.gem))
                if self.onSuccCb then
                    self.onSuccCb()
                end
            end
            self.app:addView('UICharge',self:getLocalZOrder()+10, data, onPaySuccess)
        end
    end
    
    self.mainListView:setItemModel(self['Panel_Row1'])
    for i = 1,#self.pData.shopDiamonds do 
        self.mainListView:pushBackDefaultItem()
        local item = self.mainListView:getItem(i-1)
        item:setVisible(true)
        item:setBackGroundColorOpacity(0)
        local var = self.pData.shopDiamonds[i]
        local bt = item:getChildByName('Button_buy')
        bt:setTitleText('¥'..var.price)
        bt:onTouch(onBuy)  
        bt:setTag(i)

        item:getChildByName('Image_hot'):setVisible(tonumber(var.gem) > 0 and (var.isFirst)) 
        if  var.coins> 0 then 
             item:getChildByName('Image_chips'):loadTexture('res_charge/cion_m.png', ccui.TextureResType.plistType)
        elseif  var.ticket and  var.ticket>0  then 
            item:getChildByName('Image_chips'):loadTexture('res_charge/cion_fee.png', ccui.TextureResType.plistType)
        end 
        local reward   

        local value = var.coins
        local nameMoney = ''
        if tonumber(var.coins) > 0 then
            value =var.coins 
            nameMoney = '金币'
            reward =  item:getChildByName('Panel_reward0')       
        elseif var.gem > 0 then 
            value = var.gem
            nameMoney = '元宝'    
            if tonumber(value) < 10 then 
               reward =  item:getChildByName('Panel_reward1')    
            elseif tonumber(value) >=100 then 
               reward =  item:getChildByName('Panel_reward3') 
            else 
               reward =  item:getChildByName('Panel_reward2')   
            end        
        else 
            value = var.ticket
            nameMoney = '张门票'   
            reward =  item:getChildByName('Panel_reward0')    
            item:getChildByName('Text_total'):setPosition(cc.p(
                item:getChildByName('Text_total'):getPositionX(),item:getContentSize().height/2))
        end

        reward:setVisible(nameMoney ~= '张门票')

        item:getChildByName('AtlasLabel_chipsCount'):setString(self.tool:convertAmountChinese(value)..nameMoney)       
         
        reward:getChildByName('Text_money1'):setString(self.tool:convertAmountChinese(value))--(tonumber(var.coins) > 0 and (value..'万') or value) 

        reward:getChildByName('Text_money2'):setVisible( tonumber(var.active) > 0)
        reward:getChildByName('Image_gem2'):setVisible( tonumber(var.active) > 0)
        if tonumber(var.active) > 0 then 
             local temp1 =( tonumber(var.coins) > 0 and self.tool:convertAmountChinese(var.active) or var.active )
             reward:getChildByName('Image_gem2'):getChildByName('Text_child'):setString(temp1)
        end    

        local totalAAA = var.isFirst and (value+tonumber(var.active)+tonumber(var.first)) or (value+tonumber(var.active))
        item:getChildByName('Text_total'):setString('总计:'..self.tool:convertAmountChinese(totalAAA)..nameMoney)    
        if reward:getChildByName('Text_money3') then 
            reward:getChildByName('Text_money3'):setVisible(var.isFirst)
            reward:getChildByName('Image_gem3'):setVisible(var.isFirst)     
            if tonumber(var.first) > 0 then 
                 reward:getChildByName('Image_gem3'):getChildByName('Text_child'):setString(var.first)          
            end    
        end 
        local vipTab = {'VIP周卡x1','VIP月卡x1','VIP半年卡x1'}
        if reward:getChildByName('Panel_other') then 
            if tonumber(var.vip)> 0 then 
                reward:getChildByName('Panel_other'):setVisible(true) 
                reward:getChildByName('Panel_other'):getChildByName('Text_vip'):setString(vipTab[tonumber(var.vip)])
                reward:getChildByName('Panel_other'):getChildByName('Text_tiren'):setString('+踢人卡x'..var.tiren)
                reward:getChildByName('Panel_other'):getChildByName('Text_laba'):setString('+喇叭卡x'..var.laba)
            else 
                reward:getChildByName('Panel_other'):setVisible(false)   
                local x,y = reward:getPosition()
                reward:setPosition(cc.p(x,y-20))
            end 
        end 
    end
end




--拷贝数据（可避免）
function UIShopDiamond:parseProductData(data)
    self.pData.shopDiamonds = { --desc, name, pid, amount, price, oldprice, hot
        }
    for k, v in ipairs(data.products) do
        local subList = {}
        local str = v.description or '12-14点 19-22点'

        subList.vip  = 0 
        subList.tiren = 0 
        subList.laba  = 0 
        if v.vip then 
           for s,ss in pairs(v.vip) do 
               subList.vip = s 
           end 
        end 

        if v.prop and  v.prop['4']  and tonumber(v.prop['4'])>0  then 
            subList.tiren = v.prop['4']
        end      

        if v.prop and v.prop['7']  and tonumber(v.prop['7'])>0  then 
            subList.laba = v.prop['7']
        end      

        if v.prop and v.prop['1']  and tonumber(v.prop['1'])>0  then 
            subList.ticket = v.prop['1']
        end  

        subList.first = 0   --首充
        if v.discount and v.discount.first then 
          subList.first  = v.discount['first']['gem']  or  v.discount['first']['coin'] 
        end   
        if tonumber(self.pData.paytotal) > 0 then 
            subList.first = 0 
        end     
         
        subList.active = 0  --活动
        if v.discount and v.discount.active then 
          subList.active  = v.discount['active']['gem']  or  v.discount['active']['coin'] 
        end    


        subList.name = v.name
        subList.pid = v.pid 
        subList.gem = v.gems
        subList.price = v.price
        subList.coins = v.coins
        subList.hot = v.hot
        subList.rate = v.rate
        subList.isFirst = v.firstCharge or false 
        self.pData.shopDiamonds[k] = subList
    end
    self:initProductList()
end

--请求获取产品列表
function UIShopDiamond:requestGetProduct()
    local dataTable =     {
        ['uid']    = self.pData.uid,
        ['token']  = self.pData.token,
        ['cid']      = 4,
        ['ver']    = 1,
        ['cmd']       = HttpHandler.CMDTABLE.GET_PRODUCT,
    }
    local function succ(arg)
        self:parseProductData(arg)
    end
    local function fail(arg)
        if arg.msg then
            self.tool:showAlert(arg.msg)
        end
    end

    if LuaTools.isPlatformIOS() then
        dataTable.cid = 9
        dataTable.cmd = HttpHandler.CMDTABLE.IOS_SHOP
    end
    self.tool:fastRequest(dataTable,succ, fail)
end

--请求购买产品
function UIShopDiamond:requestBuyProduct(pid, num)
    local dataTable =     {
        ['uid']   = self.pData.uid,
        ['token']  = self.pData.token,
        ['pid']      = pid,
        ['number']    = num,
        ['cmd']       = HttpHandler.CMDTABLE.BUY_PRODUCT,
    }
    local function succ(arg)
        self.pData.coin = tonumber(arg.coin) or  self.pData.coin 
        self.pData.gem = tonumber(arg.gem) or self.pData.gem
        self.tool:showAlert(arg.msg)
        if  arg.prop and arg.prop['1'] then  
            self.pData.prop[3] = tonumber(arg.prop['1'])  
        end      
        self.app:callMethod('UIShop','updateContent')
    end
    local function fail(arg)
        if arg.msg then
            self.tool:showAlert(arg.msg)
        end
    end
    self.tool:fastRequest(dataTable,succ, fail)
end

return UIShopDiamond
