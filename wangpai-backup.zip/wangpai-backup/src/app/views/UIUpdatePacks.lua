local UIUpdatePacks = class("UIUpdatePacks", cc.load("mvc").ViewBase)

UIUpdatePacks.RESOURCE_FILENAME = "UIUpdatePacks.csb"
--UIDialog.RESOURCE_PRELOADING = {"main.png"}
--UIDialog.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}
local HttpHandler = require("app.network.HttpHandler")

UIUpdatePacks.RESOURCE_BINDING = { 
    ["Button_close"] = {["ended"] = "exitScene"},
    ["Button_buy"] = {["ended"] = "confirm"},

    }



function UIUpdatePacks:exitScene() 
    LuaTools.viewAction1Over(self['Panel_main'],"UIUpdatePacks",nil, self)
end

function UIUpdatePacks:onCreate(id)
    local app = self:getApp()
    self.app = app
    self.config = app:getData('Config')
    self.tool  = app:getModel('Tools')
    self.pData = self.app:getData('PlayerData')
    self.tagId = id 
    local TitleTab  = {'res_icon/newbie_txt.png','res_icon/holiday_txt.png',
                      'res_icon/update_txt.png','res_icon/return_txt.png',} 
    self['Image_title']:loadTexture(TitleTab[id],ccui.TextureResType.plistType)
    local function  cb1()
      local dataTable =     {
          ['uid']    = G_UID,
          ['token']  = G_TOKEN,
          ['ActiveType'] =10,
          ['ActiveId']   =id,
          ['cmd']    = HttpHandler.CMDTABLE.ACTIVITY_UPACKS,
      }
      local function succ(arg)
          dump(arg,'every礼包内容')
          self['Text_title']:setString(arg.ActiveDesc)
          self:initUI(arg.Awards)
      end
      local function fail(arg)
          if arg.msg then
              self.tool:showAlert(arg.msg)
          end
      end
      self.tool:fastRequest(dataTable,succ, fail)
    end     
    LuaTools.enterActionScaledWithMask(self['Panel_main'],cb1)
end   

function UIUpdatePacks:initUI(info)
    local imageTab = {'res_reward/jinbi.png','res_reward/yunbao.png','res_reward/zhouka.png',
       'res_reward/laba.png','res_reward/tirenka.png','res_reward/vip_icon.png','res_reward/Tickets.png'} 
    local tag = 1    
    if info.coin and tonumber(info.coin) > 0  then     
        self['Image_reward'..tag]:loadTexture(imageTab[1],ccui.TextureResType.plistType)
        self['Text_reward'..tag]:setString(LuaTools.convertAmountChinese(info.coin)..'金币')
        tag = tag + 1 
    end     

    if info.gem and tonumber(info.gem) > 0  and tag <=4 then     
        self['Image_reward'..tag]:loadTexture(imageTab[2],ccui.TextureResType.plistType)
        self['Text_reward'..tag]:setString(info.gem..'个元宝')
        tag = tag + 1 
    end     

    if info.prop and info.prop['4'] and  tonumber(info.prop['4']) > 0  and tag <=3 then     
        self['Image_reward'..tag]:loadTexture(imageTab[5],ccui.TextureResType.plistType)
        self['Text_reward'..tag]:setString(info.prop['4']..'张踢人卡')
        tag = tag + 1 
    end   
    if info.prop and info.prop['1'] and  tonumber(info.prop['1']) > 0  and tag <=3 then     
        self['Image_reward'..tag]:loadTexture(imageTab[7],ccui.TextureResType.plistType)
        self['Text_reward'..tag]:setString(info.prop['1']..'张比赛券')
        tag = tag + 1 
    end 

    if info.prop and info.prop['7'] and  tonumber(info.prop['7']) > 0  and tag <=3 then     
        self['Image_reward'..tag]:loadTexture(imageTab[4],ccui.TextureResType.plistType)
        self['Text_reward'..tag]:setString(info.prop['7']..'张喇叭卡')
        tag = tag + 1 
    end      

    if info.vip and info.vip['1'] and  tonumber(info.vip['1']) > 0  and tag <=3 then     
        self['Image_reward'..tag]:loadTexture(imageTab[3],ccui.TextureResType.plistType)
        self['Text_reward'..tag]:setString(info.vip['1']..'张Vip周卡' )
        tag = tag + 1 
    end

    if info.vip_day and tonumber(info.vip_day) > 0  and tag <=3 then     
        self['Image_reward'..tag]:loadTexture(imageTab[6],ccui.TextureResType.plistType)
        self['Text_reward'..tag]:setString('Vip成长值+'..info.vip_day)
        tag = tag + 1 
    end     

end     

function UIUpdatePacks:confirm()   
    local dataTable =     {
        ['uid']    = G_UID,
        ['token']  = G_TOKEN,
        ['ActiveType'] =10,
        ['ActiveId']   =self.tagId,
        ['unionid']    =G_CHANNELID,
        ['cmd']    = HttpHandler.CMDTABLE.ACTIVITY_GETUPACKS,
    }
    local function succ(arg)
        dump(arg,'领取every礼包secc')
        if arg.msg  then 
            LuaTools.showAlert(arg.msg)
        end   
        self.pData.coin = arg.coin  or self.pData.coin  
        self.pData.gem  = arg.gem  or self.pData.gem  
        self.pData.vip_day = arg.vip_day  or self.pData.vip_day         
        self.pData.vipvalid = arg.vipvalid  or self.pData.vipvalid  
        self.pData.vip_level = arg.vip_level  or self.pData.vip_level  
        if arg.prop then 
           if arg.prop['1'] then 
             self.pData.prop[3] = arg.prop['1'] or self.pData.prop[3] 
           end 
           if arg.prop['4'] then 
             self.pData.prop[1] = arg.prop['4'] or self.pData.prop[1] 
           end 
           if arg.prop['7'] then 
             self.pData.prop[2] = arg.prop['7'] or self.pData.prop[2]
           end  
        end   
        self.pData.updatePacks[tostring(self.tagId)] = 0
        if G_BASEAPP:getView('UIMainTop') then 
            G_BASEAPP:callMethod('UIMainTop','updateWealth')
            G_BASEAPP:callMethod('UIMainTop','handleUpdatePacks')
        end   
        G_BASEAPP:removeView('UIUpdatePacks')
    end
    local function fail(arg)
        if arg.msg then
            self.tool:showAlert(arg.msg)
        end
    end
    self.tool:fastRequest(dataTable,succ, fail)

end

return UIUpdatePacks
