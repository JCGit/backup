local UICharge = class("UICharge", cc.load("mvc").ViewBase)

UICharge.RESOURCE_FILENAME = "UICharge.csb"
--UIAlert.RESOURCE_PRELOADING = {"main.png"}
--UIAlert.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UICharge.RESOURCE_BINDING = { 
    ["ListView_pay"] = {["ON_SELECTED_ITEM_END"] = "selectPayKind"},      
    ["Button_close"] = {["ended"] = "close"}, 
    ["Button_confirm"] = {["ended"] = "confirm"}, 
    } 


function UICharge:close()
    self.app:removeView('UICharge')
end     

function UICharge:confirm(event)
        local SDKHandler = require('app.network.SDKHandler')
        --支付成功回调
        local function onPaySuccess()
            -- LuaTools.showAlert("支付成功")
            if G_BASEAPP:getView('UISpree') then 
               G_BASEAPP:removeView('UISpree')
            end 
               
            --[[local gem = self.payInfo.gems or 0 
            local coin =  self.payInfo.coins or 0 
            self.pData.gem = self.pData.gem + gem
            self.pData.coin = self.pData.coin + coin
            if self.pData.prop[1] then 
               self.pData.prop[1] = self.pData.prop[1] + self.payInfo.prop['4']
            end 

            if self.pData.prop[2] then 
               self.pData.prop[2] = self.pData.prop[2] + self.payInfo.prop['7']
            end    
            if self.payInfo.pid == 61 then 
               self.pData.bitcheckFund = 1 
               self.app:callMethod('UIFund','UpdateInfo')
            end    

            if self.payInfo.pid == 71 then 
                self.pData.limitedProduct = 0  
                G_BASEAPP:callMethod('UIMainTop','HideLimitSpree')
            end  
			]]
            G_BASEAPP:removeView('UICharge')
        end

        --支付失败回调
       local function onPayFailed(arg)
            if(arg == "noApp") then
                LuaTools.showAlert('未安装微信，支付失败')
            else
                LuaTools.showAlert('支付失败')
            end
        end
        local handler, sdk, name
        if self.lastSelectedIndex == 2 then
            handler = SDKHandler.Type.ALIPAY 
            name = 'ALIPAY'
        elseif self.lastSelectedIndex == 3 then
            handler = SDKHandler.Type.YIBAO 
            name = "YIBAO"
        elseif self.lastSelectedIndex == 1 then 
            handler = SDKHandler.Type.WEIXIN
            name = "WEIXIN"
        else     
            return
        end 
        sdk = SDKHandler.getInstance(handler,name)--SDKHandler.new(handler ,name) 
		sdk:SDKPay({
            onSueccCallback = onPaySuccess,
            onPendingCallback = function() print('onPendingCallback') end,
            onErrorCallback = onPayFailed, 
        },
        { productID = self.payInfo.pid,
          isFast = 0,
          realAmount =self.payInfo.price,
          unionid =G_CHANNELID,
          did = self.pData.did,
          productName=self.payInfo.name,
          productDesc='确定花费'..self.payInfo.price..'元购买?'})
end     

function UICharge:onCreate(info,cb)
    local app = self:getApp()
    self.app = app
    self.pData = self.app:getData('PlayerData')
    self.payInfo = info
	G_PAYINFO = info;
    local payImage = {'res_fund/pay_weixin.png','res_fund/pay_ali.png','res_fund/pay_yibao.png'}  
    self['ListView_pay']:removeAllChildren()
    self['ListView_pay']:setScrollBarEnabled(false)
    self['ListView_pay']:setItemModel(self['Panel_PayItem']) 
     self.cb =  cb
    self.Text_payMoney:setString('支付金额'..self.payInfo.price..'元')
    self["ListView_pay"]:setScrollBarEnabled(false)

    local function confirm(event)
		
        if event.name == 'ended' then 
            local SDKHandler = require('app.network.SDKHandler')
            --支付成功回调
			local function paySuccess(str)
				if G_CHANNELID == "dch_tx_02" then
					LuaTools.stopWaiting() 
				end
				--[[local gem = self.payInfo.gems or 0 
                local coin =  self.payInfo.coins or 0 
                self.pData.gem = self.pData.gem + gem
                self.pData.coin = self.pData.coin + coin

                if self.pData.prop[1] then 
                   self.pData.prop[1] = self.pData.prop[1] + self.payInfo.prop['4']
                end 
                if self.pData.prop[2] then 
                   self.pData.prop[2] = self.pData.prop[2] + self.payInfo.prop['7']
                end    
                if self.payInfo.pid == 61 then 
                   self.pData.bitcheckFund = 1 
                   self.app:callMethod('UIFund','UpdateInfo')
                end    

                local temp_tab = {}
                temp_tab.gem  =  self.pData.gem 
                temp_tab.coin =  coin
                if self.cb then
                    self.cb(temp_tab)
                end
                ]]
                -- self.app:removeView('UICharge')
				
			end
			
            local function onPaySuccess(str)
				if G_CHANNELID == "dch_tx_02" then
					LuaTools.stopWaiting()
					local args = json.decode(str)
					local PayConfig = require("app.data.PayConfig")
					local conf = {};
					local temp = PayConfig[G_CHANNELID];--根据渠道获取对象sdk配置参数
					for key, value in pairs(temp) do      
						if temp[key] ~= nil then
							conf[key] = temp[key];
						end
					end  
					for key, value in pairs(conf) do      
						if args[key] ~= nil then
							conf[key] = args[key];
						end
					end
					conf['cmd'] = conf['cmd_pay']
					conf['unionid'] = G_CHANNELID
					conf['pid'] = G_PAYINFO.pid
					conf['realAmount'] = G_PAYINFO.price*100
					
					local function fail(args) 
						LuaTools.stopWaiting()  
						LuaTools.showAlert("系统异常，请重新登录即可获取充值数据！")
					end
					--腾讯支付回调数据conf保存到临时文件，下次登录再次请求接口
					LuaTools.setPayData(conf)
					LuaTools.fastRequest(conf,paySuccess,fail,{ 
						disableAlert =true
					})
				else
					paySuccess(str)	
				end
            end
						
            --支付失败回调
            local function onPayFailed(arg)
                 if(arg == "noApp") then
                    LuaTools.showAlert('未安装微信，支付失败')
                 else
                     LuaTools.showAlert('支付失败')
                 end
            end
            local handler, sdk, name
            if self.lastSelectedIndex == 2 then
                handler = SDKHandler.Type.ALIPAY 
                name = 'ALIPAY'
            elseif self.lastSelectedIndex == 3 then
                handler = SDKHandler.Type.YIBAO 
                name = "YIBAO"
            elseif self.lastSelectedIndex == 1 then 
                handler = SDKHandler.Type.WEIXIN
                name = "WEIXIN"
            elseif self.lastSelectedIndex == 4 then 
                handler = SDKHandler.Type.BAIDU
                name = "BAIDU"
            else     
                return
            end 
            if G_CHANNEL_CONFIG.isSdkPay then 
				dump("第三方支付")
                local myArgs = 
                { pid = self.payInfo.pid,
                  fast = 0,
                  realAmount =self.payInfo.price*100,
                  unionid =G_CHANNELID,
                  did = self.pData.did,
                  productName=self.payInfo.name,
                  productDesc='确定花费'..self.payInfo.price..'元购买？'}
                local ThirdSDKHandler = require('app.network.ThirdSDKHandler')
                ThirdSDKHandler.doSDKPay(onPaySuccess, function() print('onPendingCallback') end, onPayFailed, myArgs)
            else
				dump("非第三方支付")
                sdk = SDKHandler.getInstance(handler,name)--SDKHandler.new(handler ,name) 
                sdk:SDKPay({
                    onSueccCallback = onPaySuccess,
                    onPendingCallback = function() print('onPendingCallback') end,
                    onErrorCallback = onPayFailed, 
                },
                { productID = self.payInfo.pid,
                  isFast = 0,
                  realAmount =self.payInfo.price,
                  unionid =G_CHANNELID,
                  did = self.pData.did,
                  productName=self.payInfo.name,
                  productDesc='确定花费'..self.payInfo.price..'元购买？'})
            end
            self['Panel_main']:runAction(cc.Sequence:create(cc.DelayTime:create(4),
               cc.CallFunc:create(function() G_BASEAPP:removeView('UICharge') end) ))
        end     
    end     

    for key=1,3 do 
        self['ListView_pay']:pushBackDefaultItem()
        local model = self['ListView_pay']:getItem(key-1)
        model:setVisible(true)
        --model:getChildByName('Image_SelectPay'):setVisible(false)
        model:getChildByName('Image_pay'):loadTexture(payImage[key],ccui.TextureResType.plistType) 
        model:setTag(key)
        model:onTouch(confirm)
    end      
    self.lastSelectedIndex = 1 
    --self:swithPayKind(0,1)
    if G_CHANNEL_CONFIG.isSdkPay then
        self:setVisible(false)
        self["ListView_pay"]:setEnabled(false)
        self["ListView_pay"]:setTouchEnabled(false)
        confirm({name='ended'})
    end 
end




function UICharge:selectPayKind(event)
    local index = event.target:getCurSelectedIndex()+1
    self.lastSelectedIndex  = index
    --self:swithPayKind(self.lastSelectedIndex,index) 
end   

function UICharge:swithPayKind(from,to)
  if not to or to == 0 then return end 
    if from and from ~= 0 then 
       self['ListView_pay']:getItem(from-1):getChildByName('Image_SelectPay'):setVisible(false)
       self['ListView_pay']:getItem(from-1):getChildByName('CheckBox_1'):setSelected(false)
    end 

    self['ListView_pay']:getItem(to-1):getChildByName('Image_SelectPay'):setVisible(true)
    self['ListView_pay']:getItem(to-1):getChildByName('CheckBox_1'):setSelected(true)
    self.lastSelectedIndex = to 
end   

return UICharge
