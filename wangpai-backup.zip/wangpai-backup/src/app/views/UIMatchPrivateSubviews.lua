local UIMatchPrivateSubviews = class("UIMatchPrivateSubviews", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
UIMatchPrivateSubviews.RESOURCE_FILENAME = "UIMatchPrivateSubviews.csb"
--UIMatchPrivateSubviews.RESOURCE_PRELOADING = {"main.png"}
--UIMatchPrivateSubviews.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIMatchPrivateSubviews.RESOURCE_BINDING = {

}
local GAME_DDZ = "斗地主"
local GAME_DOUNIU = "斗牛"
local GAME_ZJH = "欢乐赢三张"

--初始化
function UIMatchPrivateSubviews:onCreate(table)
    local app = self:getApp()
    self.app = app
    self.tool = app:getModel('Tools')
    self.pData = app:getData('PlayerData')
    self.config = app:getData('Config')
    self.account = app:getModel('Account')
    self.dataTable = table

    self.createRoom = self['Panel_createRoom']
    self.continueCreate = self['Panel_continueCreate']
    self.password = self['Panel_password']

    self.createRoom:setVisible(false)
    self.continueCreate:setVisible(false)
    self.password:setVisible(false)

    if table.stype == "create" then
        self:initCreateRoomView()
    elseif table.stype == "pwd" then
        self:initEnterPasswordView()
    end
    LuaTools.enterActionScaledWithMask(self['Panel_main'])

end

--更新创建房间UI
function UIMatchPrivateSubviews:updateCreateView(_show)
    self.createRoom:getChildByName("Image_maxBlinds"):setVisible(_show)
    self.createRoom:getChildByName("Image_maxRounds"):setVisible(_show)
    self.createRoom:getChildByName("Image_pkRounds"):setVisible(_show)
end

--初始化创建房间UI
function UIMatchPrivateSubviews:initCreateRoomView()
    self.createRoom:setVisible(true)
    --init create room UI
    
    local function onContinueCreate(event)
        if event.name == 'ended' then
            
            LuaTools.viewAction1Over(self.createRoom, nil, function()
                self:handleOnContinueCreateLogic(event.target)
             end)
            
        end
    end
    local panelOption = self.createRoom:getChildByName("Panel_ChooseOption")
    panelOption:setVisible(false)
    local listView = panelOption:getChildByName("ListView_option")
    local defaultItem = panelOption:getChildByName('Panel_option')
    listView:setItemModel(defaultItem)
    --listView:setScrollBarEnabled(false)

    self.createRoom:getChildByName("Button_close"):onTouch(function(event) self:onClose(event) end) 
    local bt_gemCreate = self.createRoom:getChildByName("Button_gemCreate")
    bt_gemCreate:onTouch(onContinueCreate)
    bt_gemCreate:setTag(1)
    local bt_coinCreate = self.createRoom:getChildByName("Button_coinCreate")
    bt_coinCreate:onTouch(onContinueCreate)
    bt_coinCreate:setTag(2)

    local availableGames = self.dataTable.instance:getGameAvailables()
    --dump(availableGames)

    local panelsValue = {
         {"Image_gameType", availableGames, 'gameType'},
         {"Image_waitTime",{10,15,20,25,30}, 'waitTime'},
         {"Image_diZhu", {50,100,300,500,1000,3000},'minBlind'},
         {"Image_minChips", {50000,100000,500000,1000000,5000000},'enterChips'},
         {"Image_maxBlinds",{500,1000,3000,5000,10000,30000},'maxBlind'},
         {"Image_maxRounds",{20,30,40,50,66,88}, 'maxPkRound'},
         {"Image_pkRounds",{2,3,4,5,6},'pkRounds'}
    }
    local targetArrowSel = nil

    --打开选项UI
    local function onOpenOptions(event)  
        if event.name == 'ended' then
            
            local target = event.target
            local tag = target:getTag()

            local function onSelectValue(event)
                if event.name == 'ended' then
                    local index = event.target:getTag()
                    local value = panelsValue[tag][2][index]
                    print("VALUE SELECTED [key :" ..panelsValue[tag][3].."]: "..value)
                    self.optionValues[panelsValue[tag][3]] = value     --update table value
                    
                    if tag == 1 and index == 1 then  --斗地主就不显示这些UI
                        self:updateCreateView(false)
                    elseif tag == 1 and index == 2 then
                        self:updateCreateView(true)
                    end

                    if tag == 3 or tag == 4 or tag == 5 then
                        value = LuaTools.convertAmountChinese(value)
                    end

                    if tag == 2 then 
                        target:getChildByName('Text_value'):setString(value..'秒')  --update ui
                    else
                        target:getChildByName('Text_value'):setString(value)  --update ui
                    end
                    

                    target:getChildByName('Image_arrow'):loadTexture('res_profile/img_arrow_bot.png' ,ccui.TextureResType.plistType)
                    --targetArrowSel = target:getChildByName('Image_arrow')
                    panelOption:setVisible(false)
                end
            end
            if targetArrowSel and tag == targetArrowSel:getParent():getTag() and panelOption:isVisible() == true then
                panelOption:setVisible(false)
                targetArrowSel:loadTexture('res_profile/img_arrow_bot.png' ,ccui.TextureResType.plistType)
                return 
            end

            panelOption:setPosition(target:getPosition())
            listView:removeAllChildren()
            defaultItem:setVisible(true)
            
            local panel
            for key, var in ipairs(panelsValue[tag][2]) do
                listView:pushBackDefaultItem()
                panel = listView:getItem(key-1)
                if tag == 3 or tag == 4 or tag == 5 then
                    var = LuaTools.convertAmountChinese(var)
                end
                panel:getChildByName('Text_option'):setString(var)
                panel:onTouch(onSelectValue)
                panel:setTag(key)
                if key == #panelsValue[tag][2] then
                    panel:getChildByName('Image_botborder'):setVisible(false)
                end
            end
            defaultItem:setVisible(false)
            panelOption:setVisible(true)
            if targetArrowSel then 
                targetArrowSel:loadTexture('res_profile/img_arrow_bot.png' ,ccui.TextureResType.plistType)
            end
            targetArrowSel = target:getChildByName('Image_arrow')
            targetArrowSel:loadTexture('res_profile/img_arrow_up.png',ccui.TextureResType.plistType)
        end
    end

    --init panel select Value
    
    for i,v in ipairs(panelsValue) do
        print('IIII:'..i.."Val: "..v[1])
        local item = self.createRoom:getChildByName(v[1])
        item:setTouchEnabled(self.pData.gameFilter.zjh == 1)
        item:setTag(i)
        item:onTouch(onOpenOptions)
        item:getChildByName('Image_arrow'):loadTexture('res_profile/img_arrow_bot.png',ccui.TextureResType.plistType)
    end

    
    --[  打开创建房间必须初始化的  ]--

    self.txf_roomName = self.createRoom:getChildByName("Image_roomName"):getChildByName('TextField_roomName')
    self.txf_roomName:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    self.txf_roomName:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    self.txf_roomPwd = self.createRoom:getChildByName("Image_roomPwd"):getChildByName('TextField_roomPwd')
    self.txf_roomPwd:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    self.txf_roomPwd:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    self.account:handleTxfControl(self.txf_roomPwd)
    self:updateCreateView(false)


    --参数默认值
    self.optionValues = {       --Default Values
        gameType = GAME_DDZ,
        roomName = '',
        roomPwd = '',
        waitTime = 15,
        enterChips = 50000,
        minBlind = 300,
        maxBlind = 3000,
        pkRounds = 3,
        maxPkRound = 30,
    }

    self:textfieldEvents()

    self.createRoom:getChildByName('Image_gameType'):getChildByName('Text_value'):setString(self.optionValues.gameType)
    self.createRoom:getChildByName('Image_waitTime'):getChildByName('Text_value'):setString(self.optionValues.waitTime..'秒')
    self.createRoom:getChildByName('Image_minChips'):getChildByName('Text_value'):setString(self.tool:convertAmountChinese(self.optionValues.enterChips))
    self.createRoom:getChildByName('Image_diZhu'):getChildByName('Text_value'):setString(self.tool:convertAmountChinese(self.optionValues.minBlind))
    self.createRoom:getChildByName('Image_maxBlinds'):getChildByName('Text_value'):setString(self.tool:convertAmountChinese(self.optionValues.maxBlind))
    self.createRoom:getChildByName('Image_pkRounds'):getChildByName('Text_value'):setString(self.optionValues.pkRounds)
    self.createRoom:getChildByName('Image_maxRounds'):getChildByName('Text_value'):setString(self.optionValues.maxPkRound)
    self.createRoom:getChildByName("Image_roomName"):getChildByName('TextField_roomName'):setString(self.optionValues.roomName)
    self.createRoom:getChildByName("Image_roomPwd"):getChildByName('TextField_roomPwd'):setString(self.optionValues.roomPwd)

    self.continueCreate:setVisible(false)
    self.createRoom:setVisible(true)
    self:updateCreateView(false)
    self.createRoom:setVisible(true)
    LuaTools.viewAction1(self.createRoom)
end

--初始化继续创建房间UI
function UIMatchPrivateSubviews:handleOnContinueCreateLogic(_target)
    local tag = _target:getTag()
    --print('CONTINUE CREATE TAG: '..tag)

    local costVal = 0
    local hourVal = 4

    local numberHours = 8    --const
    local percentPerHour = 100/numberHours  --const
    local bgd_hour = self.continueCreate:getChildByName('Image_hourbubble')
    local sliderHour = self.continueCreate:getChildByName('Slider_Hours')
    local defaultTextHourColor = cc.c4b(255,255,255,255)

    --更新整体消费内容
    local function updateTotalDesc()
        local desc
        if tag == 1 then
            if self.checkboxSel == 1 then
                costVal = hourVal*1
            else
                costVal = hourVal*2
            end
            desc = self.tool:convertAmountChinese(costVal)..'元宝'
        else
            if self.checkboxSel == 1 then
                costVal = hourVal*20000
            else
                costVal = hourVal*40000
            end
            desc = self.tool:convertAmountChinese(costVal)..'金币'
        end
        self.continueCreate:getChildByName('Text_totalCost'):setString('共需消费'..desc)
    end
    
    --更新时间
    local function updateHour()
        local imgHour = self.continueCreate:getChildByName('Text_hour'..hourVal)
        imgHour:setTextColor(cc.c4b(255,255,255,255))
        bgd_hour:setPosition(cc.p(imgHour:getPosition()))
        sliderHour:setPercent(hourVal*percentPerHour )
        updateTotalDesc()
    end

    --滑动
    local function onSlideHour(event)
        if event.name == "ON_PERCENTAGE_CHANGED" then
            local slider = event.target
            local percent = slider:getPercent()
            local lastHour = hourVal
            if percent == 0 then
                hourVal = 1
            else
                hourVal = math.ceil(percent/percentPerHour)
            end
            
            --print('HOUR: '..hourVal.."  PERCENT: "..percent)
            local imgHour = self.continueCreate:getChildByName('Text_hour'..hourVal)
            bgd_hour:setPosition(cc.p(imgHour:getPosition()))
            if hourVal ~= lastHour then
                updateTotalDesc()
                self.continueCreate:getChildByName('Text_hour'..lastHour):setTextColor(defaultTextHourColor)
                imgHour:setTextColor(cc.c4b(255,255,255,255))
            end
        end
    end

    --关闭即系创建房间窗口
    local function onClose(event)
        if event.name == 'ended' then
            
            self.continueCreate:getChildByName('Text_hour'..hourVal):setTextColor(defaultTextHourColor)
            --self.continueCreate:setVisible(false)
            self.createRoom:setVisible(true)
            LuaTools.viewAction1Over(self.continueCreate, nil, function() 
                LuaTools.viewAction1(self.createRoom)
            end)
            
        end
    end

    --点击确定创建房间
    local function onConfirm(event)
        if event.name == 'ended' then
            --request Create room
            -- print('Type: '..tag..' Hours: '..hourVal..'Cost: '..costVal)
            -- dump(self.optionValues)
            local tagServ = tag
            if tagServ == 2 then
                tagServ = 0 
            end
            if #self.txf_roomName:getString() > 0 then
                self.optionValues.roomName = self.txf_roomName:getString()
            end
            self.optionValues.roomPwd = self.txf_roomPwd:getString()
            self:requestCreateRoom(self.optionValues, tagServ, hourVal, self.checkboxSel-1)
        end
    end

    --勾选
    function onCheckBox(event)
        if event.name == 'selected' then
            local tag = event.target:getTag()
            event.target:setSelected(true)
            if tag ~= self.checkboxSel and self.checkboxSel > 0 then 
                self['CheckBox_'..self.checkboxSel]:setSelected(false)
            end
            self.checkboxSel = tag
            updateTotalDesc()
            elseif event.name == 'unselected' then
            event.target:setSelected(true)
        end 
    end

    --【 继续创建房间必须初始化的 】--

    sliderHour:onEvent(onSlideHour)
    updateHour()
    self.continueCreate:getChildByName('Button_confirm'):onTouch(onConfirm)
    self.continueCreate:getChildByName('Button_Close'):onTouch(onClose)
    --self.continueCreate:getChildByName('Panel_touchCtrl'):onTouch(onClose)
    --self.continueCreate:getChildByName('Panel_touchCtrl'):setTouchEnabled(true)
    local checkb1, checkb2
    checkb1 = self.continueCreate:getChildByName('CheckBox_1')
    checkb2 = self.continueCreate:getChildByName('CheckBox_2')
    checkb1:onEvent(onCheckBox)
    checkb1:setTag(1)
    checkb1:setSelected(true)
    checkb2:onEvent(onCheckBox)
    checkb2:setTag(2)
    checkb2:setSelected(false)
    self.checkboxSel = 1
    local title,desc_1,desc_2

    if tag == 1 then
        title = '元宝创建'
        desc_1 = '每小时1个元宝,5%系统服务费'
        desc_2 = '每小时2个元宝,无系统服务费'
    else
        title = '金币创建'
        desc_1 = '每小时2万金币,5%系统服务费'
        desc_2 = '每小时4万金币,无系统服务费'
    end
    self.continueCreate:getChildByName('Text_title'):setString(title)
    self.continueCreate:getChildByName('Text_desc1'):setString(desc_1)
    self.continueCreate:getChildByName('Text_desc2'):setString(desc_2)

    self.continueCreate:getChildByName('Text_desc2'):setVisible(self.pData.ifGetTaxOpen == 1)
    checkb2:setVisible(self.pData.ifGetTaxOpen == 1)
    checkb1:setTouchEnabled(self.pData.ifGetTaxOpen == 1)

    local desc_1 = self.continueCreate:getChildByName('Text_desc1')
    updateTotalDesc()
    self.continueCreate:setVisible(true)
    LuaTools.viewAction1(self.continueCreate)
    self.createRoom:setVisible(false)
end

--打开输入密码界面
function UIMatchPrivateSubviews:initEnterPasswordView()
    self.password:setVisible(true)
    local txf = self.password:getChildByName('TextField_pwd')
    txf:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    txf:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)

    self.account:handleTxfControl(txf)

    txf:setString('')
 
    local function onOk(event)
        if event.name == 'ended' then
            local str = txf:getString()
            --检测密码长度是否合格 
            local data = self.dataTable.data[self.dataTable.index]
            if #str< 1 or #str > 6 then
                self.tool:showTips("密码长度不在1~6之内，请重新输入")
                return
            end 
            --检测密码内容是否合格
            if false == self.account:strContainOnlyNumAndChar(str) then
                self.tool:showTips(self.account.pwdError)
                return
            end
            if data.pwd ~= str then
                self.tool:showTips("密码不正确，请重新输入")
                return
            end
            --进入房间
            self.dataTable.instance:enterRoom(data.gameType, data.roomId)
            self.password:setVisible(false)
            self:closeView()
        end
    end

    self.password:getChildByName('Button_ok'):onTouch(onOk)
    self.password:getChildByName('Button_close'):onTouch(function(event) self:onClose(event) end)

end

--输入框
function UIMatchPrivateSubviews:textfieldEvents()
    --两个字符串长度对比
    local function compareStrSize(_str, _strModel)
        local val1, val2
        local text =  ccui.Text:create()
        text:setString(_str) 
        val1 = text:getVirtualRendererSize().width
        text:setString(_strModel) 
        val2 = text:getVirtualRendererSize().width
        
        if val1 > val2 then
            return false
        end
 
        return true
    end

    --根据长度去裁切字符串
    local function cropStringToSize( _str, _strModel)
        local tabStr = LuaTools.UStr2Table(_str)
        local strName = ""
        for i=1, #tabStr do 
            table.remove(tabStr, #tabStr-1)
            print("CORRECT SIZE STR: "..table.concat(tabStr))
            strName = table.concat(tabStr)
            if compareStrSize(strName, _strModel) == true then 
                return strName
            end
        end 
    end

    --输入房间名称限制长度以及特殊字符
    local function onSetName(event)
        local txf = event.target
        if event.name == "ATTACH_WITH_IME" then
        elseif event.name == "DETACH_WITH_IME" then

        elseif event.name == "INSERT_TEXT" then
            print("INSERT TEXT")
            if compareStrSize (txf:getString(), "一二三四五六七", true) == false then
                txf:setString(cropStringToSize(txf:getString(),"一二三四五六七"))
                return
            end
        elseif event.name == "DELETE_BACKWARD" then
            print('DELETE_BACKWARD')
        end
    end

    self.txf_roomName:onEvent(onSetName)
    if compareStrSize (self.pData.nick, "一二三四", true) == false then
        self.optionValues.roomName = cropStringToSize(self.pData.nick,"一二三四")..'的房间'
    else
        self.optionValues.roomName = self.pData.nick..'的房间'
    end
    
    --输入房间密码限制长度以及特殊字符
    local lastValidPwd = ''
    local function onSetPwd(event)
        local txf = event.target
        if event.name == "ATTACH_WITH_IME" then
        elseif event.name == "DETACH_WITH_IME" then

        elseif event.name == "INSERT_TEXT" then
            print("INSERT TEXT")
            
            if self.account:strContainOnlyNumAndChar(txf:getString()) == true then 
                lastValidPwd = txf:getString()
            else
                txf:setString(lastValidPwd)
                return
            end
            if compareStrSize (txf:getString(), "123456", true) == false then
                txf:setString(cropStringToSize(txf:getString(),"123456"))
                return
            end
            
        elseif event.name == "DELETE_BACKWARD" then
            print('DELETE_BACKWARD')
        end
    end
    self.txf_roomPwd:onEvent(onSetPwd)

end

--关闭创建房间
function UIMatchPrivateSubviews:closeView()
    LuaTools.viewAction1Over(self['Panel_main'], "UIMatchPrivateSubviews")
end

--点击关闭创建房间
function UIMatchPrivateSubviews:onClose(event)
    if event.name == 'ended' then
        self:closeView()
    end
end

--请求创建房间
--@params: 1.房间信息表，2.支付类型，3.时间， 4.收费类型
function UIMatchPrivateSubviews:requestCreateRoom(_table, _typePay, _hours, _typeFee)
    local dataTable =     {
            ['uid']   = self.pData.uid,
            ['token']  = self.pData.token,
            ['name']      = _table.roomName,
            ['bpour']      = _table.minBlind,
            ['tpour']    = _table.maxBlind,
            ['maxt']    = _table.maxPkRound,
            ['comt']    = _table.pkRounds,
            ['pw']      = _table.roomPwd,
            ['carry']      = _table.enterChips,
            ['wtime']      = _table.waitTime,
            ['ttime']      = _hours,
            ['type']      = _typePay,
            ['way']      = _typeFee,
            ['gameType']  = self.dataTable.instance:getGameType(_table.gameType), --self:getGameType(_table.gameType),
            ['unionid']   = self.config.unionID,
            ['cmd']       = HttpHandler.CMDTABLE.PRIVATE_CREATE,
        }
        local function succ(arg)
            dump(arg, "requestCreateRoom succ")
            local gameType = arg.gameType
            local rid = arg.rid
            if arg.msg then
                 self.tool:showTips(arg.msg)
            end
            self.pData.coin = tonumber( arg.coin ) or 0
            self.pData.gem = tonumber(arg.gem ) or 0

            self:closeView()
            self.dataTable.instance:requestGetRoomsList()

            if G_BASEAPP:getView('UIMainTop') then 
               G_BASEAPP:callMethod('UIMainTop','updateWealth') 
            end  
            self.dataTable.instance:enterRoom(gameType, rid)
        end
        local function fail(arg)
            if arg.msg then
                self.tool:showTips(arg.msg)
            end
        end
        self.tool:fastRequest(dataTable,succ, fail)
end

return UIMatchPrivateSubviews
