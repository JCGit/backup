local UILoginChangePwd = class("UILoginChangePwd", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
UILoginChangePwd.RESOURCE_FILENAME = "UILoginChangePwd.csb"
--UILoginChangePsw.RESOURCE_PRELOADING = {"main.png"}
--UILoginChangePsw.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}},

UILoginChangePwd.RESOURCE_BINDING = {
    ["Button_Close"]  = {["ended"] = "onClose"},
    ["Button_confirm"]  = {["ended"] = "onConfirm"},
}

function UILoginChangePwd:onCreate()
    local app = self:getApp()
    self.app = app
    
    self.pdata = app:getData('PlayerData')
    self.tool = app:getModel('Tools') 
    self.account = app:getModel('Account')
    self.config = app:getData('Config')

    self:initTextField(self['TextField_oldPwd'])
    self:initTextField(self['TextField_NewPwd'])
    self:initTextField(self['TextField_ConfirmPwd'])

    self.account:handleTxfControl(self['TextField_oldPwd'])
    self.account:handleTxfControl(self['TextField_NewPwd'])
    self.account:handleTxfControl(self['TextField_ConfirmPwd'])

end

function UILoginChangePwd:initTextField(_txf)
    _txf:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    _txf:setTextColor(self.config.Txf_textColorLogin)
end

function UILoginChangePwd:onConfirm()
    
    local oldPwd = self['TextField_oldPwd']:getString()
    local newPwd = self['TextField_NewPwd']:getString()
    local confPwd = self['TextField_ConfirmPwd']:getString()
    
    --检测密码长度是否合格
    if #newPwd< self.account.pwdMinLen or #newPwd > self.account.pwdMaxLen then
        self.tool:showTips(self.account.pwdLenght)
        return
    end
    --检测密码内容是否合格
    if false == self.account:strContainOnlyNumAndChar(newPwd) then
        self.tool:showTips(self.account.pwdError)
        return
    end
    --检测两次输入的密码是否一致
    if newPwd ~= confPwd then
        self.tool:showTips(self.account.pwdNotMatched)
        return
    end

    local dataTable =     {
        ['uid']   = self.pdata.uid,
        ['token']  = self.pdata.token,
        ['oldpw']      = oldPwd,
        ['newpw']       = newPwd,
        ['cmd']       = HttpHandler.CMDTABLE.MODIFY_PWD,
    }
    local function succ(arg)
        UserCache.setUserDataByKey("password",newPwd )
        UserCache.setCommonDataByKey("password", newPwd)
        self.tool:showTips('修改密码成功！')
        self:runAction(cc.Sequence:create(cc.DelayTime:create(1.5), cc.CallFunc:create(function() self:removeSelf() end),nil))
    end
    self.tool:fastRequest(dataTable,succ)
end

function UILoginChangePwd:onClose()
    
    self.app:removeView('UILoginChangePwd')
end

return UILoginChangePwd
