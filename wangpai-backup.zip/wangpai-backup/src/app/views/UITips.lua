local UITips= class("UITips", cc.load("mvc").ViewBase)
UITips.RESOURCE_FILENAME = "UITips.csb"


UITips.RESOURCE_BINDING = { 
    ["Button_Close"] = {["ended"] = "exit"},
    ["Button_confirm"] = {["ended"] = "confirm"},
    ["Button_one"] = {["ended"] = "btnOne"},


    }

function UITips:exit() 
    
    if self.cancelCallback then
        self.cancelCallback()
    end   
    self.app:removeView('UITips')
end

function UITips:btnOne()   
    
    if self.okCallback then
        self.okCallback()
    end
    if self and self.app then
        self.app:removeView('UITips')
    end
end

function UITips:confirm()   
    print('confirm')
    
    if self.okCallback then
        self.okCallback()
    end
    if self and self.app then
        self.app:removeView('UITips')
    end
end


function UITips:onCreate(tag)

    local app = self:getApp()
    self.app = app       
    self.Button_one:setVisible(tag == 1) 
    self.Button_Close:setVisible(tag ~= 1) 
    self.Button_confirm:setVisible(tag ~= 1) 

end



function UITips:setupDialog(title,msg,confirmCB, cancelCB)
    print(msg)
    self.Text_title:setString(title)
    self.Text_string:setString(msg)
    self.okCallback = confirmCB
    self.cancelCallback = cancelCB
end


return UITips








