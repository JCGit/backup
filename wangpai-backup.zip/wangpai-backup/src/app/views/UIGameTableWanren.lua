local UIGameTableWanren = class("UIGameTableWanren", cc.load("mvc").ViewBase)

UIGameTableWanren.RESOURCE_FILENAME = "UIGameTableWanren.csb" 

-- local GameTableCommon = require("app.models.GameTableCommon")
local TCPConnector = require('app.network.TCPConnector')
local DataPacker = require('app.network.DataPacker')
local DataUnpacker = require('app.network.DataUnpacker')
local HttpHandler = require("app.network.HttpHandler")
 
require("app.models.cardutl")
UIGameTableWanren.RESOURCE_BINDING = { 

    -- ["Button_dont_grab"]   = {["ended"] = "PlayerCtrl_dont_grab"}, 
    -- ["Button_readyup"]   = {["ended"] = "REQ_READY"}, 
    -- ["Button_changeTable"]   = {["ended"] = "PlayerCtrl_changeTable"},  
    ["Button_back"]   = {["ended"] = "back"},  

    -- ['Button_allin']    = {['ended']  =   "PlayerCtrl_allin"   },
    -- ['Button_follow']   = {['ended']  =   "PlayerCtrl_follow"   },
    -- ['Button_add']      = {['ended']  =   "PlayerCtrl_add"   },
    -- ['Button_show']     = {['ended']  =   "PlayerCtrl_show"   },
    ['Button_Help']     = {['ended']  =   "PlayerCtrl_showHelp"   },
    ['Button_unseat_palyer']     = {['ended']  =   "PlayerCtrl_showUnSeatPlayer"   },
    ['Button_dealer']     = {['ended']  =   "PlayerCtrl_dealer"   },
    ['Button_dealerDown']     = {['ended']  =   "PlayerCtrl_dealerDown"   },

    ['Button_recentstats']     = {['ended']  =   "PlayerCtrl_showRecentStats"   },
    
    ['Button_100']     = {['ended']  =   "PlayerCtrl_selectChip100"   },
    ['Button_1000']     = {['ended']  =   "PlayerCtrl_selectChip1000"   },
    ['Button_1wan']     = {['ended']  =   "PlayerCtrl_selectChip1w"   },
    ['Button_10wan']     = {['ended']  =   "PlayerCtrl_selectChip10w"   },
    -- ['Button_10wan']     = {['ended']  =   "PayChipsTest"   },
    ['Button_100wan']     = {['ended']  =   "PlayerCtrl_selectChip100w"   },
    -- ['Button_100wan']     = {['ended']  =   "gatherChipsTest"   },
    ['Panel_card_1']     = {['ended']  =   "BetChip1"   },
    ['Panel_card_2']     = {['ended']  =   "BetChip2"   },
    ['Panel_card_3']     = {['ended']  =   "BetChip3"   },
    ['Panel_card_4']     = {['ended']  =   "BetChip4"   },
    ['Button_chatBtn']   = {['ended']  =   "showChatView"   },

}
UIGameTableWanren.Config = DataUnpacker.Config[DataUnpacker.Type.GAME_Wanren]
UIGameTableWanren.CMD = DataUnpacker.CMD[DataUnpacker.Type.GAME_Wanren]['REQ']

UIGameTableWanren.dealer = 1
UIGameTableWanren.spades = 2
UIGameTableWanren.hearts = 3
UIGameTableWanren.clubs = 4
UIGameTableWanren.diamonds = 5
UIGameTableWanren.bt_LotteryNode = nil
function UIGameTableWanren:initAllCards()
    local strName = {"Panel_banker","Panel_card_1","Panel_card_2","Panel_card_3","Panel_card_4"}
    self.allCardTable = {}
    self.allCardPosTable = {}
    for i=UIGameTableWanren.dealer, UIGameTableWanren.diamonds do
        local parent = self[strName[i]]
        self.allCardTable[i] = {}
        self.allCardPosTable[i] = {}
        self:initOneSideCards(self.allCardTable[i], self.allCardPosTable[i], parent)
    end
end

function UIGameTableWanren:initOneSideCards(cardTable, cardPosTable, parent)
    for i=1,5 do
        local cardImg = parent:getChildByName("Panel_showCard"):getChildByName("Image_poke"..i)
        local backSprite = parent:getChildByName("Panel_showCard"):getChildByName("Image_poke"..i):clone()
        backSprite:setVisible(false)
        self:addChild(backSprite)
        table.insert(cardTable, backSprite)
        local posTable = cardImg:getParent():convertToWorldSpace(cc.p(cardImg:getPosition()))
        table.insert(cardPosTable, posTable)
    end
end



function UIGameTableWanren:dealtCards(valueTable, callback)
    self:preDealtCardsRestPos()
    self:doDealtCards(valueTable, callback)
    audio.playSound(Sound.SoundTable['sfx']['WRFapai'] , false)
end

function UIGameTableWanren:doDealtCards(valueTable, finishCallback)
    local isDidCallback = false
    local function myFinishCallback()
        self:didDealtCardsHide()
        finishCallback()
    end
    for i=1,#self.allCardTable do
        local oneSideImgs = self.allCardTable[i]
        local pos = self.allCardPosTable[i][1]
        for j=1,#oneSideImgs do
            local target = self.allCardPosTable[i][j]
            local img = oneSideImgs[j]
            local moveAction = cc.MoveTo:create(0.4,cc.p(pos))
            local delayAction = cc.DelayTime:create(0.08*j)
            local move2Action = cc.MoveTo:create(0.4,cc.p(target))
            local seqAction = nil
            if j == 1 then
                local pos2 = self.allCardPosTable[i][2]
                local function callback()
                    self:loadCardTexture(img, valueTable[i])
                end
                local delay2Action = cc.DelayTime:create(0.4)
                local move3Action = cc.MoveTo:create(0.4,cc.p(pos2))
                local callAction = cc.CallFunc:create(callback)
                local move4Action = cc.MoveTo:create(0.4,cc.p(pos))
                local call2Action = cc.CallFunc:create(myFinishCallback)

                if isDidCallback == false then
                    seqAction = cc.Sequence:create(delayAction,moveAction,move2Action,delay2Action,move3Action,callAction,move4Action,call2Action,nil)
                    isDidCallback = true
                else
                    seqAction = cc.Sequence:create(delayAction,moveAction,move2Action,delay2Action,move3Action,callAction,move4Action,nil)
                end
            else
                seqAction = cc.Sequence:create(delayAction,moveAction,move2Action,nil)
            end
            img:runAction(seqAction)
        end
    end
end

function UIGameTableWanren:loadCardTexture(img, value)
    img:loadTexture(Cardutl.getPathForCard(value,nil,nil,'Douniu'),ccui.TextureResType.plistType) 
end

function UIGameTableWanren:didDealtCardsHide()
    for i=1,#self.allCardTable do
        local oneSideImgs = self.allCardTable[i]
        for j=1,#oneSideImgs do
            local img = oneSideImgs[j]
            img:setVisible(false)
        end
    end
end

function UIGameTableWanren:preDealtCardsRestPos()
    for i=1,#self.allCardTable do
        local oneSideImgs = self.allCardTable[i]
        for j=1,#oneSideImgs do
            local img = oneSideImgs[j]
            img:setVisible(true)
            img:loadTexture('newcard/back.png',ccui.TextureResType.plistType)
            img:setPosition(640,420)
        end
    end
end

function UIGameTableWanren:PlayerCtrl_showUnSeatPlayer()
    self.app:addView("UIWanRenUnseat", self:getLocalZOrder()+2,self.noSeatPlayerInfo)
end
 

function UIGameTableWanren:PlayerCtrl_showHelp()
    self.app:addView("UIWanRenHelp", self:getLocalZOrder()+2)
end

function UIGameTableWanren:PlayerCtrl_dealer()
    local tab = {}
    tab.money = self.zhuangNeed          --上庄条件
    tab.word  = self.dealerState         --当前状态（上庄or 下装）
    tab.nowList =  self.nowDealerList    --当前庄家列表
    tab.nowInfo =  self.nowDealerInfo    --当前庄家信息
    self.app:addView("UIBecomeBanker", 502, tab,function() 
           self:REQ_GRAB_DEALER() 
    end)
end

function UIGameTableWanren:PlayerCtrl_dealerDown()
    local tab = {}
    tab.money = self.zhuangNeed          --上庄条件
    tab.word  = self.dealerState         --当前状态（上庄or 下装）
    tab.nowList =  self.nowDealerList    --当前庄家列表
    tab.nowInfo =  self.nowDealerInfo    --当前庄家信息
    self.app:addView("UIBecomeBanker", 502, tab,function() 
           self:REQ_DROP_DEALER() 
    end)
end

function UIGameTableWanren:back()
	--if UIGameTableWanren.bt_LotteryNode ~= nil then
		--UIGameTableWanren.bt_LotteryNode:removeFromParent()
		--UIGameTableWanren.bt_LotteryNode = nil
	--end
    G_BASEAPP:addView('UIDialog',999999)
    G_BASEAPP:callMethod('UIDialog','setupDialog', '','确定退出?',
    function() 
        self:closeWanRenTcp()    
        G_BASEAPP:getView('UIMain').isShowingMainEnterAction = false 
        G_BASEAPP:callMethod('UIMain','showEnterMainActions')
        G_BASEAPP:callMethod('UIMainTop','updateWealth')
        G_BASEAPP:removeView('UIGameTableWanren') 
        G_BASEAPP:removeView({uiName = 'UIBroadcast', uiInstanceName = "forGameWanren"})
        if G_BASEAPP:getView('UIDialog') then 
            G_BASEAPP:removeView('UIDialog')  
        end    
    end)     
end     

function UIGameTableWanren:setSelectingChipButton(btn, num)
    if not self.selectChipTagImg then
        self.selectChipTagImg = cc.Sprite:createWithSpriteFrameName("wanren/ring_b.png")
        self["Button_100"]:getParent():addChild(self.selectChipTagImg)
    end
    if self.lastSelectChipButton then
        self.lastSelectChipButton:setScale(1.0)
    end
    self.lastSelectChipButton = btn
    self.lastSelectChipButton:setScale(1.2)
    self.selectChipTagImg:setScale(1.2)
    local posX,posY = btn:getPosition()
    self.selectChipTagImg:setPosition(posX,posY)
    self.selectChipNum = num
end

function UIGameTableWanren:PlayerCtrl_selectChip100()
    self:setSelectingChipButton(self["Button_100"], 100)
end

function UIGameTableWanren:PlayerCtrl_selectChip1000()
    self:setSelectingChipButton(self["Button_1000"], 1000)
end

function UIGameTableWanren:PlayerCtrl_selectChip1w()
    self:setSelectingChipButton(self["Button_1wan"], 10000)
end

function UIGameTableWanren:PlayerCtrl_selectChip10w()
    self:setSelectingChipButton(self["Button_10wan"], 100000)
end

function UIGameTableWanren:PlayerCtrl_selectChip100w()
    self:setSelectingChipButton(self["Button_100wan"], 1000000)
end

--趋势
function UIGameTableWanren:PlayerCtrl_showRecentStats()
    self.app:addView("UIWanrRenTender", 503,self.winOrLoseTrend)
end

function UIGameTableWanren:BetChip1()
   self:REQ_BET(1,self.selectChipNum)

   -- local function call1()
   --     for i=1,20 do
   --         self:FlyChips(2,100,2) 
   --         self:FlyChips(2,1000,3) 
   --         self:FlyChips(3,1000,1) 
   --         self:FlyChips(3,10000,4) 
   --         self:FlyChips(7,10000,1) 
   --     end
   -- end
   -- local function call2()
   --     self:doDealtResult({1}, {2,3}, {1,4})
   -- end
   -- local delay = cc.DelayTime:create(1.5)
   -- local seq = cc.Sequence:create(cc.CallFunc:create(call1),delay,cc.CallFunc:create(call2))
   -- self:runAction(seq)
end 

function UIGameTableWanren:BetChip2()
   self:REQ_BET(2,self.selectChipNum)
end 

function UIGameTableWanren:BetChip3()
    self:REQ_BET(3,self.selectChipNum)
end 

function UIGameTableWanren:BetChip4()
    self:REQ_BET(4,self.selectChipNum)
end 

---------------------------- REQUESTS ------------------------------
local _ = 
[[
                    ██████╗ ███████╗ ██████╗ ██╗   ██╗███████╗███████╗████████╗███████╗                       
                    ██╔══██╗██╔════╝██╔═══██╗██║   ██║██╔════╝██╔════╝╚══██╔══╝██╔════╝                       
                    ██████╔╝█████╗  ██║   ██║██║   ██║█████╗  ███████╗   ██║   ███████╗                       
                    ██╔══██╗██╔══╝  ██║▄▄ ██║██║   ██║██╔══╝  ╚════██║   ██║   ╚════██║                       
                    ██║  ██║███████╗╚██████╔╝╚██████╔╝███████╗███████║   ██║   ███████║                       
                    ╚═╝  ╚═╝╚══════╝ ╚══▀▀═╝  ╚═════╝ ╚══════╝╚══════╝   ╚═╝   ╚══════╝                                   
                                                                                          
]]
 
function UIGameTableWanren:showChatView()
    self.app:addView('UIFaceicon',502,function(tab) 
        local  tag  = tab.msgType
        local  msg  = tab.msg 
        if tag == 1 then --face 
             self:REQ_EMOJI(msg)
        elseif tag == 2 then --common
             self:REQ_CONST_TEXT(msg)
        elseif tag == 3 then --word 
             self:REQ_CHAT(msg)
        else  
            return 
        end        
    end)
end 


--聊天 
function UIGameTableWanren:REQ_CHAT(str)   
    local bufferHnd = DataPacker.new(UIGameTableWanren.CMD['CHAT'],{protocalVersion = 2})   
    bufferHnd:writeData(str,DataPacker.STRING)
    self.tcpGear:sendData(bufferHnd:doPack())
end


function UIGameTableWanren:REQ_EMOJI(id) 
    local bufferHnd = DataPacker.new(UIGameTableWanren.CMD['EMOJI'],{protocalVersion = 2})   
    bufferHnd:writeData(id,DataPacker.SHORT)
    self.tcpGear:sendData(bufferHnd:doPack())
end


function UIGameTableWanren:REQ_CONST_TEXT(id) 
    local bufferHnd = DataPacker.new(UIGameTableWanren.CMD['CONST_TEXT'],{protocalVersion = 2})   
    bufferHnd:writeData(id,DataPacker.SHORT)
    self.tcpGear:sendData(bufferHnd:doPack())
end



function UIGameTableWanren:REQ_heartbeat()  
    local bufferHnd = DataPacker.new(UIGameTableWanren.CMD['HEARTBEAT'],{protocalVersion = 2})
    local buffer = bufferHnd:doPack()
    self.tcpGear:sendData(buffer) 
end

--请求上庄
function UIGameTableWanren:REQ_GRAB_DEALER()
    local bufferHnd = DataPacker.new(UIGameTableWanren.CMD['GRAB_DEALER'],{protocalVersion = 2})
    local buffer = bufferHnd:doPack()
    self.tcpGear:sendData(buffer) 
end     

--请求下庄
function UIGameTableWanren:REQ_DROP_DEALER()
    local bufferHnd = DataPacker.new(UIGameTableWanren.CMD['DROP_DEALER'],{protocalVersion = 2})
    local buffer = bufferHnd:doPack()
    self.tcpGear:sendData(buffer) 
end

--下注 seatId:  1-4 
function UIGameTableWanren:REQ_BET(seatId,chip)
    local bufferHnd = DataPacker.new(UIGameTableWanren.CMD['BET'],{protocalVersion = 2})
    bufferHnd:writeData(seatId,DataPacker.BYTE)
    bufferHnd:writeData(chip,DataPacker.INT)
    local buffer = bufferHnd:doPack()
    self.tcpGear:sendData(buffer) 

end

--离开房间
function UIGameTableWanren:REQ_ASK_LEAVE()
    local bufferHnd = DataPacker.new(UIGameTableWanren.CMD['ASK_LEAVE'],{protocalVersion = 2})
    local buffer = bufferHnd:doPack()
    self.tcpGear:sendData(buffer) 
    self.tcpGear:closeAndRelease()
end

--更新信息
function UIGameTableWanren:REQ_UPDATA_INFO()
    local bufferHnd = DataPacker.new(UIGameTableWanren.CMD['UPDATA_INFO'],{protocalVersion = 2})
    local buffer = bufferHnd:doPack()
    self.tcpGear:sendData(buffer) 
end

--坐下  seatId:0-5
function UIGameTableWanren:REQ_ASK_SIT(seatId)
    local bufferHnd = DataPacker.new(UIGameTableWanren.CMD['ASK_SIT'],{protocalVersion = 2})
    bufferHnd:writeData(seatId,DataPacker.BYTE)
    local buffer = bufferHnd:doPack()
    self.tcpGear:sendData(buffer) 
end

--请求站起
function UIGameTableWanren:REQ_ASK_STAND(seatId)
    local bufferHnd = DataPacker.new(UIGameTableWanren.CMD['ASK_STAND'],{protocalVersion = 2})
    bufferHnd:writeData(seatId,DataPacker.BYTE)
    local buffer = bufferHnd:doPack()
    self.tcpGear:sendData(buffer) 
end


 
------------------------------------- TCP FUNCTIONS---------------------------------------------
local _ = 
[[                    
            ████████╗ ██████╗██████╗     ███╗   ███╗███████╗████████╗██╗  ██╗ ██████╗ ██████╗ ███████╗
            ╚══██╔══╝██╔════╝██╔══██╗    ████╗ ████║██╔════╝╚══██╔══╝██║  ██║██╔═══██╗██╔══██╗██╔════╝
               ██║   ██║     ██████╔╝    ██╔████╔██║█████╗     ██║   ███████║██║   ██║██║  ██║███████╗
               ██║   ██║     ██╔═══╝     ██║╚██╔╝██║██╔══╝     ██║   ██╔══██║██║   ██║██║  ██║╚════██║
               ██║   ╚██████╗██║         ██║ ╚═╝ ██║███████╗   ██║   ██║  ██║╚██████╔╝██████╔╝███████║
               ╚═╝    ╚═════╝╚═╝         ╚═╝     ╚═╝╚══════╝   ╚═╝   ╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚══════╝          
]]
--登录成功
function UIGameTableWanren:TCP_LOGIN_SUCC(data)
    dump(data,'万人场登录成功') 
    self.waitingChipTime   = data.WaitChipTime 
    self.waitingResultTime = data.WaitResTime 
    local time = (data.NiuState == 3 and data.currWResTime or data.currChipTime )
    
    self['Panel_forbidBet']:setVisible(data.NiuState == 3) 
    self['Panel_timer']:setVisible(data.NiuState ~= 3)
    if data.NiuState == 2 then 
       self:testProgress(time) 
    end  

    local tempDealer = {}   
    tempDealer.uid     = data.DealerUid 
    tempDealer.coin    = data.DealerChip 
    tempDealer.nick    = data.DealerNick 
    tempDealer.sex     = data.DealerSex 
    tempDealer.vipLevel= data.DealerVipLevel 
    tempDealer.vipType = data.DealerVipType 
    tempDealer.icon    = data.DealerIcon 
    tempDealer.otherInfo = data.DealerOtherInfo 

    self.nowDealerInfo = tempDealer --当前庄家信息

    LuaTools.stopWaiting() 
    self.zhuangNeed = data.ZhuangNeed 
    self.winOrLoseTrend = data.HisTrend or {} 

    self['Text_derlerName']:setString(data.DealerNick)--(LuaTools.getFinalNameStr(data.DealerNick,6))
    self['Text_DealerCoin']:setString(LuaTools.convertAmountChinese(data.DealerChip)) 

    if data.DealerIcon and data.DealerIcon ~= "" and data.DealerNick ~= "系统" then  --庄家头像
       local  newHeadSpr
       local function onFinishTable(status,downloadedSize,dst)  
          if status == "success" then
             newHeadSpr = cc.Sprite:create(dst)
          else 
             newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[data.DealerSex+1])   
          end
          LuaTools.makeSpriteRounded(newHeadSpr, self['Image_DealerAvatar'], self.config.maskSprite, false)
       end
       local newName = data.DealerIcon
       LuaTools.getFileFromUrl({url = data.DealerIcon, destFile =(newName:gsub("/","_")), onFinishTable = onFinishTable })
    else 
       newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[data.DealerSex+1])
       LuaTools.makeSpriteRounded(newHeadSpr, self['Image_DealerAvatar'], self.config.maskSprite, false)   
    end 

    if data.DealerUid  ==  G_UID then --我是庄家  
        self['Button_dealer']:setVisible(false)
        self['Button_dealerDown']:setVisible(true)
        self.dealerState  = '申请下庄'
    end     
    self['Panel_banker']:getChildByName('Image_9'):setLocalZOrder(555)
    self['Panel_banker']:getChildByName('Text_DealerCoin'):setLocalZOrder(556)
    self['Panel_banker']:getChildByName('Text_derlerName'):setLocalZOrder(556)


    self['Text_myName']:setString(data.nick)--(LuaTools.getFinalNameStr(data.nick,6))
    self.pData.coin = tonumber(data.chip)
    self:updateMyCoin()
    --self['Text_myCoin']:setString(LuaTools.convertAmountChinese(data.chip)) 
    -------------------------------------------------------------------------------
    -------------------------------------------------------------------------------
    --自己头像
    local spr   
    local oldAvatar = UserCache.getUserDataByKey('icon')
    if oldAvatar and #oldAvatar > 0 then
        spr = cc.Sprite:create(oldAvatar)
    else
        spr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[self.pData.sex+1])
    end 
    LuaTools.makeSpriteRounded(spr, self['Image_myAvatar'], self.config.maskSprite, true)  
    -------------------------------------------------------------------------------
    -------------------------------------------------------------------------------

    --更新奖池信息
    if data.poolInfo and #data.poolInfo > 0 then 
        for key,var in pairs(data.poolInfo) do 
            local par 
            if var.seatId == 0 then  
                par = self['Panel_banker']
                
            else 
               par = self['Panel_card_'..var.seatId]
               par:getChildByName('Text_ammount_upper'):setVisible(true)
               par:getChildByName('Text_ammount_upper'):setString(LuaTools.convertAmountChinese(var.chip)) 
            end     

            if var.cardCount > 0 then 

                par:getChildByName('Panel_showCard'):getChildByName('Image_poke1'):loadTexture(
                Cardutl.getPathForCard(var.card[1],nil,nil,'Douniu'),ccui.TextureResType.plistType) 

               -- for k,v in pairs(var.card) do 
               --     par:getChildByName('Panel_showCard'):getChildByName('Image_poke'..k):loadTexture(
               --      Cardutl.getPathForCard(v,nil,nil,'Douniu'),ccui.TextureResType.plistType) 
               -- end  
            end  
        end     
    end     
    -------------------------------------------------------------------------------
    -------------------------------------------------------------------------------
    --我的下注信息
    if data.chipInfo and #data.chipInfo > 0 then 
        for key,var in pairs(data.chipInfo) do 
            if self['Panel_card_'..var.seatId] then 
                local bg = self['Panel_card_'..var.seatId]:getChildByName('Image_ammount_bottom')
                bg:setVisible(true)
                bg:getChildByName('Text_ammount_bottom'):setVisible(true)
                if tonumber(var.chip)>0 then 
                    bg:loadTexture('wanren/bgT3.png',ccui.TextureResType.plistType)
                    bg:getChildByName('Text_ammount_bottom'):setColor(cc.c3b(255,222,0))
                    bg:getChildByName('Text_ammount_bottom'):setString(LuaTools.convertAmountChinese(var.chip))
                else 
                    bg:loadTexture('wanren/bgT1.png',ccui.TextureResType.plistType)
                    bg:getChildByName('Text_ammount_bottom'):setColor(cc.c3b(255,255,255))
                    bg:getChildByName('Text_ammount_bottom'):setString('未下注')
                end      
            end     
        end 
    end  
    -------------------------------------------------------------------------------
    -------------------------------------------------------------------------------
    --更新座位信息  
    if data.seatInfo then 
        for key,var in pairs(data.seatInfo) do 
            local b = {} 
            b.uid    = var.uid 
            b.seatId = var.seatId
            b.coin   = var.coin
            b.sex    = var.sex
            b.name   = var.nick
            table.insert(self.seatPlayerUidTable,b)
            local par = self['Panel_Player'..var.seatId]:getChildByName('Panel_personInfo')
            par:setVisible(true)
            self['Panel_Player'..var.seatId]:getChildByName('btn_sit'):setVisible(false)
            local headImage = self['Panel_Player'..var.seatId]:getChildByName('Panel_personInfo'):getChildByName('Image_avatar')
            local newHeadSpr
            if var.icon and var.icon ~= ""  then  
               local function onFinishTable(status,downloadedSize,dst)
                  if status == "success" then
                     newHeadSpr = cc.Sprite:create(dst)
                  else 
                     newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[var.sex+1])   
                  end
                  LuaTools.makeSpriteRounded(newHeadSpr,headImage , self.config.maskSprite, false)
               end
               local newName = var.icon
               LuaTools.getFileFromUrl({url = var.icon, destFile =(newName:gsub("/","_")), onFinishTable = onFinishTable })
            else 
               newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[var.sex+1])
               LuaTools.makeSpriteRounded(newHeadSpr, headImage, self.config.maskSprite, false)   
            end 

            if var.uid == G_UID then 
               for key=0,5,1 do 
                   self['Panel_Player'..key]:getChildByName('btn_sit'):setTouchEnabled(false)
               end    
            end 
            par:getChildByName('Text_nickname'):setString(var.nick)
            par:getChildByName('Text_nickname'):setLocalZOrder(1001)
            par:getChildByName('Image_bg'):setLocalZOrder(1000)
            par:getChildByName('Text_coin'):setLocalZOrder(1001)
            par:getChildByName('Text_coin'):setString(LuaTools.convertAmountChinese(var.coin)) 
            par:setTag(var.uid) 

            local function checkPersonInfo(event)
                if event.name == 'ended' then 
                    local tab = {} 
                    tab.uid = var.uid  
                    tab.tag = 0
                    self.app:addView('UIFriendBrief',self:getLocalZOrder()+1,tab)
                end  
            end     
            par:getChildByName('Button_detail'):onTouch(checkPersonInfo)
            par:getChildByName('Button_detail'):setPressedActionEnabled(false)

        end  
    end     
    -------------------------------------------------------------------------------
    -------------------------------------------------------------------------------
    --所有玩家列表处理 
    if data.PlayerList then  
       local function compare(uid)
           for key,var in pairs(self.seatPlayerUidTable) do 
               if tostring(uid) == tostring(var.uid) then 
                   return true 
               end 
           end        
       end  
       for key,var in pairs(data.PlayerList) do 
           if #tostring(var.uid) > 5 and  tostring(G_UID) ~= tostring(var.uid) then 
              local result = compare(var.uid) 
              if result ~= true then 
                    local temp = {} 
                    temp.uid      = var.uid 
                    temp.coin     = var.coin 
                    temp.sex      = var.sex 
                    temp.vipLevel = var.vipLevel
                    temp.vipType  = var.vipType 
                    temp.icon     = var.icon 
                    temp.nick     = var.nick 
                    self:saveNoSeatPlayerInfo(temp)  
              end   
           end    
       end   
    end    
    -------------------------------------------------------------------------------
    -------------------------------------------------------------------------------    
    --庄家列表处理 
    if data.DealerList then 
        self.nowDealerList =  data.DealerList
    end  

end


function UIGameTableWanren:testProgress(time)
    if  not time or time == 0  then 
        self:stopSchedule('runLeftTime')
        self['Panel_timer']:setVisible(false)
        return 
    end 
    if self['Panel_timer']:getChildByName('action') then 
        self['Panel_timer']:removeChildByName('action') 
    end     
    self:stopSchedule('runLeftTime')
    self['Panel_timer']:setVisible(true)
    self['Text_countdown']:setString(time)
    local temp = time 
    local function countTime()
        temp = temp - 1 
        self['Text_countdown']:setString(temp)
        if temp <= 0  then 
           self['Panel_timer']:setVisible(false)
           self['Text_countdown']:setString('')
           self:stopSchedule('runLeftTime')
        end    
    end 
    self:createSchedule('runLeftTime',countTime,1)
    local panel =  self['Panel_timer'] 

    local   to  = cc.ProgressTo:create(time, 100)
    local sprite = cc.Sprite:create('res/icon/ring_s.png')      
    sprite:setColor(cc.c3b(0,255,0))
    sprite:setAnchorPoint(0.5,0.5)
    local pro = cc.ProgressTimer:create(sprite)
    pro:setType(cc.PROGRESS_TIMER_TYPE_RADIAL)
    panel:addChild(pro,99)
    pro:setName('action')
    -- local action1 = cc.TintTo:create(1.5, 255, 0, 0)
    -- local action2 = cc.Sequence:create(cc.DelayTime:create(time/2),action1)
    -- local spawn  = cc.Spawn:create(to,action2)
    local function callback()
        if panel:getChildByName('action') then 
           panel:removeChildByName('action') 
        end    
    end 
    local x,y = panel:getChildByName('Text_countdown'):getPosition()
    pro:setPosition(cc.p(x+40,y))
    pro:runAction(cc.Sequence:create(to,cc.CallFunc:create(callback)))  
end    

--申请上庄成功
function UIGameTableWanren:TCP_GRAB_SUCC(data)
    -- dump(data,'申请上庄成功') 
    LuaTools.showAlert('申请上庄成功')

end

--申请下庄成功     
function UIGameTableWanren:TCP_DROP_SUCC(data)
    -- dump(data,'申请下庄成功 ') 
    LuaTools.showAlert('申请下庄成功')
end

--发第一张     
function UIGameTableWanren:TCP_SEND_FIRST(data)
    -- dump(data,'发第一张') 
    if  self.changeDealerState == true  and self.changeDealerInfo  then 
        self:changeDealer(self.changeDealerInfo) 
        self.changeDealerState = false 
    end     

    if data.count > 0 then 
        for  k=1 ,4 do 
            self['Panel_card_'..k]:setTouchEnabled(true)
            self['Panel_card_'..k]:getChildByName('Image_winLight'):setVisible(false)
            self['Image_cardTypeBg'..k]:getChildByName('Image_lastDouble'):setVisible(false)
        end  
        local FirstCardTable = {}   --执行动作传过去第一张牌的table
        self:testProgress(self.waitingChipTime)

        for key=1,data.count  do 
            local var = data.cardInfo[key]
            local par 
            if var.seatId == 0 then  
                par = self['Panel_banker']
            else 
                par = self['Panel_card_'..var.seatId]
            end     
        
            if var.cardCount > 0 then 
               FirstCardTable[var.seatId+1] = var.card[1]
            end  
        end     
       for k,v in pairs(FirstCardTable) do 
            local par 
            if k == 1 then  
                par = self['Panel_banker']
            else 
                par = self['Panel_card_'..(k-1)]
            end  
            par:getChildByName('Panel_showCard'):setVisible(false)
            par:getChildByName('Panel_showCard'):getChildByName('Image_poke1'):loadTexture(
            Cardutl.getPathForCard(v,nil,nil,'Douniu'),ccui.TextureResType.plistType) 
       end  
       self['Panel_wiatingBegin']:setVisible(false)
        self:dealtCards(FirstCardTable,function() 
            self['Panel_banker']:getChildByName('Panel_showCard'):setVisible(true)
            for key=1,4  do 
                self['Panel_card_'..key]:getChildByName('Panel_showCard'):setVisible(true)
                local bg = self['Panel_card_'..key]:getChildByName('Image_ammount_bottom')
                bg:setVisible(true)
                if self.nowPoolHaveBet and self.nowPoolHaveBet[key] > 0 then
                   bg:loadTexture('wanren/bgT3.png',ccui.TextureResType.plistType)
                   bg:getChildByName('Text_ammount_bottom'):setColor(cc.c3b(255,222,0))
                   bg:getChildByName('Text_ammount_bottom'):setString(LuaTools.convertAmountChinese(self.nowPoolHaveBet[key])) 
                else     
                   bg:loadTexture('wanren/bgT1.png',ccui.TextureResType.plistType)
                   bg:getChildByName('Text_ammount_bottom'):setColor(cc.c3b(255,255,255))
                   bg:getChildByName('Text_ammount_bottom'):setString('未下注') 
                end    
            end     
        end) 

    end     
end




--下注   
function UIGameTableWanren:TCP_BET_SUCC(data)
    -- dump(data,'下注成功') 
end


--每个下注池的下注额
function UIGameTableWanren:TCP_POOL_INFO(data)
    dump(data,'每个下注池的下注额') 
    if data.poolCount > 0 then 
        for key,var in pairs(data.poolInfo) do 
            if self['Panel_card_'..var.seatId] then 
                self['Panel_card_'..var.seatId]:getChildByName('Text_ammount_upper'):setVisible(true)
                self['Panel_card_'..var.seatId]:getChildByName('Text_ammount_upper'):setString(
                    LuaTools.convertAmountChinese(var.chip)) 
                self.poolChips[var.seatId]  = var.chip 
            end    
        end     
    end 
end


--等待结果,禁止下注 
function UIGameTableWanren:TCP_FORBID_BET(data)
   -- dump(data,'等待结果,禁止下注 ') 
   self['Panel_forbidBet']:setVisible(true)
   self['Panel_timer']:setVisible(false)
   for k = 1,4 do 
       self['Panel_card_'..k]:setTouchEnabled(false)
   end     
end

--个人结算 
function UIGameTableWanren:TCP_PLAYER_COUNT(data)
    dump(data,'个人结算 ') 
    local function finalAcvtion() 
        if data.Players then   --结算动作执行 
            for key,var in pairs(data.Players) do 
                if tostring(var.uid) ~= tostring(G_UID) then  
                    if var.info then 
                       local total = 0 
                       for i,v in pairs(var.info) do 
                            total = total + v.result
                       end  
                       local par = self:getSeatPosition(var.uid) 
                       local size1 =par:getContentSize() 
                       if total > 0 and par:getChildByName('BMF_win') then 
                          local num = (total< 10000) and total or LuaTools.convertAmountChinese(total)
                          par:getChildByName('BMF_win'):setString('+'..num)
                          par:getChildByName('BMF_win'):setVisible(true)
                          local action1 = cc.MoveTo:create(0.5,cc.p(size1.width/2,size1.height+25))
                          -- local action2 = cc.FadeOut:create(3)  (cc.Spawn:create(action1,action2)
                          par:getChildByName('Panel_personInfo'):getChildByName('Text_coin'):setString(LuaTools.convertAmountChinese(var.coin))
                          local function cb() 
                              local x,y = par:getChildByName('BMF_win'):getPosition()
                              par:getChildByName('BMF_win'):setString('')
                              par:getChildByName('BMF_win'):setVisible(false)
                              par:getChildByName('BMF_win'):setPosition(cc.p(size1.width/2,size1.height/2))
                          end  
                          par:getChildByName('BMF_win'):runAction(cc.Sequence:create(action1,
                            cc.DelayTime:create(2),cc.CallFunc:create(cb) )) 
                       elseif total < 0 and par:getChildByName('BMF_Loss') then 
                          local num = (total> -10000) and math.abs(total) or LuaTools.convertAmountChinese(math.abs(total))
                          par:getChildByName('BMF_Loss'):setString('-'..num)
                          par:getChildByName('BMF_Loss'):setVisible(true)
                          local action1 = cc.MoveTo:create(0.5,cc.p(size1.width/2,size1.height+25))
                          -- local action2 = cc.FadeOut:create(3)
                          par:getChildByName('Panel_personInfo'):getChildByName('Text_coin'):setString(LuaTools.convertAmountChinese(var.coin))
                          local function cb() 
                              local x,y = par:getChildByName('BMF_Loss'):getPosition()
                              par:getChildByName('BMF_Loss'):setString('')
                              par:getChildByName('BMF_Loss'):setVisible(false)
                              par:getChildByName('BMF_Loss'):setPosition(cc.p(size1.width/2,size1.height/2))
                          end  

                            par:getChildByName('BMF_Loss'):runAction(cc.Sequence:create(action1,
                            cc.DelayTime:create(2),cc.CallFunc:create(cb) )) 
                       else 
                           par:getChildByName('Panel_personInfo'):getChildByName('Text_coin'):setString(LuaTools.convertAmountChinese(var.coin))
                       end  

                    end  
                else 
                    local par = self:getSeatPosition(var.uid)
                    par:getChildByName('Panel_personInfo'):getChildByName('Text_coin'):setString(LuaTools.convertAmountChinese(var.coin))
                end   
            end     
        end 
        if data.chipInfo then 
           local total = 0 
           for i,v in pairs(data.chipInfo) do 
                total = total + v.chip
           end  
           local par = self['Panel_bottom']
           local size1 = par:getContentSize() 
           if total > 0 and par:getChildByName('BMF_win') then 
              local num = (total < 10000) and total or LuaTools.convertAmountChinese(total)
              par:getChildByName('BMF_win'):setString('+'..num)
              par:getChildByName('BMF_win'):setVisible(true)
              local x,y = par:getChildByName('BMF_win'):getPosition()

              local action1 = cc.MoveTo:create(0.5,cc.p(x,size1.height+25))
              self['Text_myCoin']:setString(LuaTools.convertAmountChinese(data.playerCoin))
              local function cb() 
                  par:getChildByName('BMF_win'):setString('')
                  par:getChildByName('BMF_win'):setVisible(false)
                  par:getChildByName('BMF_win'):setPosition(cc.p(x,size1.height/2))
              end  
                par:getChildByName('BMF_win'):runAction(cc.Sequence:create(action1,
                cc.DelayTime:create(2),cc.CallFunc:create(cb) )) 
           elseif total < 0 and par:getChildByName('BMF_Loss') then 
              local num = (total> -10000) and math.abs(total) or LuaTools.convertAmountChinese(math.abs(total))
              par:getChildByName('BMF_Loss'):setString('-'..num)
              par:getChildByName('BMF_Loss'):setVisible(true)
              local x,y = par:getChildByName('BMF_Loss'):getPosition()

              local action1 = cc.MoveTo:create(0.5,cc.p(x,size1.height+25))   --LuaTools.convertAmountChinese(var.coin))
              self['Text_myCoin']:setString(LuaTools.convertAmountChinese(data.playerCoin))
              -- local action2 = cc.FadeOut:create(3)
              local function cb() 
                  par:getChildByName('BMF_Loss'):setString('')
                  par:getChildByName('BMF_Loss'):setVisible(false)
                  par:getChildByName('BMF_Loss'):setPosition(cc.p(x,size1.height/2))
              end  
                par:getChildByName('BMF_Loss'):runAction(cc.Sequence:create(action1,
                cc.DelayTime:create(2),cc.CallFunc:create(cb))) 
           else 
               self['Text_myCoin']:setString(LuaTools.convertAmountChinese(data.playerCoin))
           end  
        end    
        
        for key= 1,4 do 
            self['Panel_card_'..key]:getChildByName('Text_ammount_upper'):setString('0')
        end
        if data.dealerCoin  then --and self.changeDealerState ~= true then 
           self['Text_DealerCoin']:setString(LuaTools.convertAmountChinese(data.dealerCoin))   
        end    
    end
    if data.playerCoin then 
       self.pData.coin = data.playerCoin
    end  

    --需要在这个回调里补充 更新座位上玩家金币
    self:doDealtResult( self.finalLossPoolDouble,self.finalWinPool,self.finalLossPool,function() finalAcvtion()  end)


    self['Panel_fullscreenmode']:runAction(cc.Sequence:create(cc.DelayTime:create(5),cc.CallFunc:create(function()
       self:resetStadus()  
    end   )))
end


--换庄  
function UIGameTableWanren:TCP_CHANGE_DEALER(data)
   self.changeDealerInfo  = data   
   self.changeDealerState = true
   -- dump(data,'换庄') 
   -- local function cb()
   --    self:changeDealer(self.changeDealerInfo)
   -- end  
   -- self['Panel_fullscreenmode']:runAction(cc.Sequence:create(cc.DelayTime:create(3),cc.CallFunc:create(cb)))
end

function UIGameTableWanren:changeDealer(data)
    local tempDealer = {}   
    tempDealer.uid     = data.uid 
    tempDealer.coin    = data.coin 
    tempDealer.nick    = data.nick 
    tempDealer.sex     = data.sex 
    tempDealer.vipLevel= data.vipLevel 
    tempDealer.vipType = data.vipType 
    tempDealer.icon    = data.icon 
    tempDealer.otherInfo = data.otherInfo 

    self.nowDealerInfo = tempDealer  -- 当前庄家信息  
    
    for key,var in pairs(self.nowDealerList) do 
        if tostring(var.uid) == tostring(data.uid) then 
            table.remove(self.nowDealerList,key)
        end 
    end         

    self['Text_derlerName']:setString(data.nick)--(LuaTools.getFinalNameStr(data.nick,6)) 
    self['Text_DealerCoin']:setString(LuaTools.convertAmountChinese(data.coin)) 

    if data.icon and data.icon ~= ""  then  --庄家头像
       local  newHeadSpr
       local function onFinishTable(status,downloadedSize,dst)
          if status == "success" then
             newHeadSpr = cc.Sprite:create(dst)
          else 
             newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[data.sex+1])   
          end
          LuaTools.makeSpriteRounded(newHeadSpr, self['Image_DealerAvatar'], self.config.maskSprite, false)
       end
       local newName = data.icon
       LuaTools.getFileFromUrl({url = data.icon, destFile =(newName:gsub("/","_")), onFinishTable = onFinishTable })
    else 
       newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[data.sex+1])
       LuaTools.makeSpriteRounded(newHeadSpr, self['Image_DealerAvatar'], self.config.maskSprite, false)   
    end 
    if tostring(data.uid) == tostring(G_UID) then   --我自己上庄
       self.dealerState  = '申请下庄'
       self['Button_dealer']:setVisible(false)
       self['Button_dealerDown']:setVisible(true) 
       self:setChipButtonStatus(self.pData.coin,1)
    else  
       self.dealerState  = '申请上庄'
       self['Button_dealer']:setVisible(true)
       self['Button_dealerDown']:setVisible(false)
       self:setChipButtonStatus(self.pData.coin)
    end 
    self.changeDealerInfo = nil 
end     


--登出成功   
function UIGameTableWanren:TCP_LOGOUT_SUCC(data)
   -- dump(data,'登出成功') 
end

--更新信息
function UIGameTableWanren:TCP_UPDATE_PLAYER(data)
-- dump(data,'更新信息') 
end

--消息提示 
function UIGameTableWanren:TCP_MSG_TIPS(data)
   dump(data,'消息提示') 
   if data.msg then 
        if data.msg == '登陆失败，正在其他服务器游戏' then 
            G_BASEAPP:addView('UIDialog',999999,1)
            G_BASEAPP:callMethod('UIDialog','setupDialog', '',data.msg,
                        function() 
                            if self then  
                                self:closeWanRenTcp()    
                                G_BASEAPP:getView('UIMain').isShowingMainEnterAction = false 
                                G_BASEAPP:callMethod('UIMain','showEnterMainActions')
                                G_BASEAPP:callMethod('UIMainTop','updateWealth')
                                G_BASEAPP:removeView('UIGameTableWanren')
                                G_BASEAPP:removeView({uiName = 'UIBroadcast', uiInstanceName = "forGameWanren"})
                                if tonumber(data.seatId) > 0 then 
                                        G_BASEAPP:removeView('UIDialog')
                                        local seatId = data.seatId
                                        local info = G_BASEAPP:getData('Config').gameSeatIdInfo 
                                        local text 
                                        for key,var in pairs(info) do 
                                            if tostring(seatId) == key then 
                                                text = var 
                                            end 
                                        end 
                                        if      string.find(text,'地主')  then  
                                            G_BASEAPP:callMethod('UIMainBottom','quickEnterWPDZ')                                                                                

                                        elseif   string.find(text,'斗牛') then  
                                            G_BASEAPP:callMethod('UIMainBottom','setQuickStart', 'dn') 
                                            G_BASEAPP:callMethod('UIMainBottom','quickStart')

                                        elseif   string.find(text,'三张') then   

                                            G_BASEAPP:callMethod('UIMainBottom','setQuickStart', 'zjh') 
                                            G_BASEAPP:callMethod('UIMainBottom','quickStart')

                                        elseif   string.find(text,'德州') then  
                                            G_BASEAPP:callMethod('UIMainBottom','quickEnterPokerRoom', seatId)


                                        elseif   string.find(text,'炸翻天') then  

                                            G_BASEAPP:callMethod('UIMainBottom','setQuickStart', 'ddz') 
                                            G_BASEAPP:callMethod('UIMainBottom','quickStart')

                                        elseif   string.find(text,'升级') then  
                                            G_BASEAPP:callMethod('UIMainBottom','quickEnterRunFast', seatId)
                                        elseif  string.find(text,'比赛') then   
                                            G_BASEAPP:addView('UIAwards',999)
                                        else 
                                            return     
                                        end  
                                end 
                            else 
                                G_BASEAPP:removeView('UIDialog')
                            end 
                        end,
                        function() 
                            print('cancle LeaveTexusRoom')
                        end)
        else
            LuaTools.showAlert(data.msg)
        end  
   end    
end

--最后结果
function UIGameTableWanren:TCP_FINAL_RESULT(data)
     dump(data,'最后结果  ') 
     self['Panel_forbidBet']:setVisible(false)
     local tempTrend = {} 
     local FinalResult = {}  --存放输赢信息
        if data.count > 0 then 
           for key,var in pairs(data.doubleInfo) do 
                local par 
                if var.seatId == 0 then  
                    par = self['Panel_banker']
                    self['Image_resultBg']:getChildByName('Text_niu'):setString(self.cardTypeTableWord[var.cardType+1])
                else 
                    par = self['Panel_card_'..var.seatId]
                    local image =var.multi >= 0  and  ('wanren/'..self.cardTypeTableImageWin[var.cardType+1])  or 
                            ('wanren/'..self.cardTypeTableImage[var.cardType+1])
                    local doubleBgTag = var.cardType <= 9  and 1 or (var.cardType -8)
                    self['Image_cardTypeBg'..var.seatId]:getChildByName('Image_lastDouble'):setVisible(var.cardType >= 7
                         or data.doubleInfo[1].cardType>=7)
                    self['Image_cardTypeBg'..var.seatId]:getChildByName('Image_cardtype'):loadTexture(
                        image,ccui.TextureResType.plistType)
                    if var.multi >= 0 then --玩家赢了 
                        table.insert(self.finalWinPool,var.seatId)   
                        if self.lastDoubleBgWin[doubleBgTag] then
                            self['Image_cardTypeBg'..var.seatId]:getChildByName('Image_lastDouble'):loadTexture(self.lastDoubleBgWin[doubleBgTag],
                                ccui.TextureResType.plistType)
                        end 
                        local bg = nil 
                        if var.cardType < 7 then  
                            bg = self.cardNiuTypeBg[2]
                        elseif var.cardType < 10 and var.cardType >= 7 then 
                            bg = self.cardNiuTypeBg[3]
                        else     
                            bg = self.cardNiuTypeBg[4]
                        end 
                        self['Image_cardTypeBg'..var.seatId]:loadTexture(bg,ccui.TextureResType.plistType)
                    else    --玩家输了 
                        table.insert(self.finalLossPool,var.seatId)
                        self['Image_cardTypeBg'..var.seatId]:loadTexture(self.cardNiuTypeBg[1],ccui.TextureResType.plistType)
                        if var.multi < -1 then 
                           table.insert(self.finalLossPoolDouble,var.seatId)
                        end  
                        doubleBgTag = data.doubleInfo[1].cardType<= 9  and 1 or (data.doubleInfo[1].cardType -8)
                        if self.lastDoubleBgLoss[doubleBgTag] then
                            self['Image_cardTypeBg'..var.seatId]:getChildByName('Image_lastDouble'):loadTexture(self.lastDoubleBgLoss[doubleBgTag],
                                ccui.TextureResType.plistType)
                        end 
                    end     

                    tempTrend[var.seatId] = (var.multi >= 0 and 1 or 0 )
                    FinalResult[var.seatId] = var.multi 
                end     

                if var.valueCount > 0 then 
                   for k,v in pairs(var.cardValue) do  
                       self:rotateCard(par:getChildByName('Panel_showCard'):getChildByName('Image_poke'..k),v)
                   end  
                   audio.playSound(Sound.SoundTable['sfx']['Fapai'] , false)
                end  
           end  
           table.remove(self.winOrLoseTrend,1)
           -- dump(tempTrend,'最后结果的趋势表') 

           table.insert(self.winOrLoseTrend,tempTrend)
           self:cardBgAction(FinalResult)
           self.nowHaveBet = 0 
           self:setChipButtonStatus(self.pData.coin)
        end     
end

--牛牛背景缩放
function UIGameTableWanren:cardBgAction(tab)
     for key =1,4 do 
         self['Image_cardTypeBg'..key]:setVisible(true)
         self['Image_cardTypeBg'..key]:setScale(2)
         local scale1 = cc.ScaleTo:create(0.3,0.8) 
         local scale2 = cc.ScaleTo:create(0.1,1)  
         self.PoolNeedFlyChips[key] = tab[key]*self.poolChips[key]
         self['Image_cardTypeBg'..key]:runAction(cc.Sequence:create(scale1,scale2)) 
         if tab[key] > 0 then 
            if not self['Panel_card_'..key]:getChildByName('winAction') then 
                UIGameTableWanren.bt_LotteryNode = cc.CSLoader:createNode('Animation_wanren_win.csb') 
                local x,y = self['Panel_card_'..key]:getChildByName('Image_winlose'):getPosition() 
                UIGameTableWanren.bt_LotteryNode:setPosition(cc.p(x,y))
                local action = cc.CSLoader:createTimeline('Animation_wanren_win.csb')
                UIGameTableWanren.bt_LotteryNode:runAction(action)
                action:gotoFrameAndPlay(0,false)
                self['Panel_card_'..key]:addChild(UIGameTableWanren.bt_LotteryNode,1)
                UIGameTableWanren.bt_LotteryNode:setName('winAction')                  
            end
            self['Panel_card_'..key]:getChildByName('Image_winLight'):setVisible(true)
        else 
            self['Panel_card_'..key]:getChildByName('Image_winlose'):setVisible(true)        
        end
     end    

     --庄家的输赢

     self['Image_resultBg']:setVisible(true)

     -- local total = 0 
     -- for key,var in pairs(tab) do 
     --     total = total + var*self.poolChips[key]
     --     self.PoolNeedFlyChips[key] = var*self.poolChips[key]
     -- end 

     -- local image = total <= 0  and 'wanren/win1.png' or 'wanren/lose1.png' 
     -- self['Panel_banker']:getChildByName('Image_winlose'):loadTexture(image,ccui.TextureResType.plistType)
     -- self['Panel_banker']:getChildByName('Image_winlose'):setVisible(true)
end     


--翻转
function UIGameTableWanren:rotateCard(par,value,time)  
    if not time then time = 0.1 end 
    local function callback2()
        -- par:loadTexture(image,ccui.TextureResType.plistType)
        par:loadTexture(Cardutl.getPathForCard(value,nil,nil,'Douniu'),ccui.TextureResType.plistType) 
    end 
    local orbit1 = cc.OrbitCamera:create(time,1, 0, 0, -90, 0, 0)
    local move = cc.OrbitCamera:create(time*2,1, 0, 0, 0, 0, 0) 
    par:runAction(cc.Sequence:create(cc.DelayTime:create(0.1),orbit1,cc.CallFunc:create(callback2),move))  
end 

--重置所有状态
function UIGameTableWanren:resetStadus() 
   --Panel_banker 庄家
    for key =1 ,5 do 
        self['Panel_banker']:getChildByName('Panel_showCard'):getChildByName('Image_poke'..key):loadTexture(
            'newcard/back.png',ccui.TextureResType.plistType)
        self['Panel_card_1']:getChildByName('Panel_showCard'):getChildByName('Image_poke'..key):loadTexture(
            'newcard/back.png',ccui.TextureResType.plistType)

        self['Panel_card_2']:getChildByName('Panel_showCard'):getChildByName('Image_poke'..key):loadTexture(
            'newcard/back.png',ccui.TextureResType.plistType)

        self['Panel_card_3']:getChildByName('Panel_showCard'):getChildByName('Image_poke'..key):loadTexture(
            'newcard/back.png',ccui.TextureResType.plistType)

        self['Panel_card_4']:getChildByName('Panel_showCard'):getChildByName('Image_poke'..key):loadTexture(
            'newcard/back.png',ccui.TextureResType.plistType)

    end 
    
    for key=1,4 do 
        self['Image_cardTypeBg'..key]:setVisible(false)
        self['Panel_card_'..key]:getChildByName('Panel_showCard'):setVisible(false)  
        self['Panel_card_'..key]:getChildByName('Image_ammount_bottom'):setVisible(false) 
        self['Panel_card_'..key]:getChildByName('Image_winlose'):setVisible(false)  
        if self['Panel_card_'..key]:getChildByName('winAction') then 
            self['Panel_card_'..key]:getChildByName('winAction'):removeFromParent(true)  
        end 
        self['Panel_card_'..key]:setTouchEnabled(false)
        self['Panel_card_'..key]:getChildByName('Image_winLight'):setVisible(false)
        self['Image_cardTypeBg'..key]:getChildByName('Image_lastDouble'):setVisible(false)


    end     
    self['Panel_banker']:getChildByName('Panel_showCard'):setVisible(false)
    -- self['Panel_banker']:getChildByName('Image_winlose'):setVisible(false)
    self['Image_resultBg']:setVisible(false)
    self['Panel_forbidBet']:setVisible(false)
    self['Panel_timer']:setVisible(false)

    self.finalWinPool = {} 
    self.finalLossPoolDouble = {} 
    self.finalLossPool = {} 
    self.nowPoolHaveBet   = {0,0,0,0}  

    self['Panel_wiatingBegin']:setVisible(true)  



end     


--根据uid得到座位位置结点
function UIGameTableWanren:getSeatPosition(uid)
-- print('进来时候的uid='..uid)
   local par 
   for key = 1,6 do 
       local tag = self['Panel_Player'..(key-1)]:getChildByName('Panel_personInfo'):getTag()
       -- print('得到的tag='..tag)

       if tostring(tag) == tostring(uid) then 
            par =  self['Panel_Player'..(key-1)]
            break 
       end  
   end  
   if par == nil then 
      par = self['Button_unseat_palyer'] 
   end  
   return par 
end     

--玩家是否坐下
function UIGameTableWanren:IfHaveSeatId(uid)
   local par 
   for key = 1,6 do 
       local tag = self['Panel_Player'..(key-1)]:getChildByName('Panel_personInfo'):getTag()
       if tostring(tag) == tostring(uid) then 
            par =  self['Panel_Player'..(key-1)]
            break 
       end  
   end  
   return par 
end 


--玩家根据uid 得到对应的座位号  0-5有座位玩家  6是我自己  7无座位
function UIGameTableWanren:getSeatIDByUid(uid)
    local function compare(uid)
       for key,var in pairs(self.seatPlayerUidTable) do 
           if tostring(uid) == tostring(var.uid) then 
              return var.seatId 
           end 
       end        
    end 


    local tag  
    if tostring(uid) ==tostring(G_UID) then 
        tag = 6 
    else
        tag =  compare(uid) 
        if not tag then tag = 7 end 
    end 
    
    return tag        
end    

--玩家坐下    
function UIGameTableWanren:TCP_PLSYER_SITDOWN(data)
    dump(data,'玩家坐下') 

    local b = {} 
    b.uid    = data.uid 
    b.seatId = data.seatId
    b.coin   = data.coin 
    b.name   = data.nick
    table.insert(self.seatPlayerUidTable,b)
    self:clearNoSeatPlayerInfo(data.uid)
    local par = self['Panel_Player'..data.seatId]:getChildByName('Panel_personInfo')
    par:setVisible(true)
    self['Panel_Player'..data.seatId]:getChildByName('btn_sit'):setVisible(false)
    local headImage = self['Panel_Player'..data.seatId]:getChildByName('Panel_personInfo'):getChildByName('Image_avatar')
    local newHeadSpr
    if data.icon and data.icon ~= ""  then  --庄家头像
       local function onFinishTable(status,downloadedSize,dst)
          if status == "success" then
             newHeadSpr = cc.Sprite:create(dst)
          else 
             newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[data.sex+1])   
          end
          LuaTools.makeSpriteRounded(newHeadSpr,headImage , self.config.maskSprite, false)
       end
       local newName = data.icon
       LuaTools.getFileFromUrl({url = data.icon, destFile =(newName:gsub("/","_")), onFinishTable = onFinishTable })
    else 
       newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[data.sex+1])
       LuaTools.makeSpriteRounded(newHeadSpr, headImage, self.config.maskSprite, false)   
    end 
    
    par:getChildByName('Text_nickname'):setString(data.nick)--(LuaTools.getFinalNameStr(data.nick,5)) 
    par:getChildByName('Text_nickname'):setLocalZOrder(1001)
    par:getChildByName('Image_bg'):setLocalZOrder(1000)
    par:getChildByName('Text_coin'):setLocalZOrder(1001)
    par:getChildByName('Text_coin'):setLocalZOrder(1001)
    self['Panel_Player'..data.seatId]:getChildByName('BMF_win'):setLocalZOrder(1005)
    self['Panel_Player'..data.seatId]:getChildByName('BMF_Loss'):setLocalZOrder(1005)

    par:getChildByName('Text_coin'):setString(LuaTools.convertAmountChinese(data.coin)) 
    par:setTag(data.uid)
    if tostring(data.uid) ==tostring(G_UID) then 
       for key=0,5,1 do 
           if key ~= data.seatId then 
              self['Panel_Player'..key]:getChildByName('btn_sit'):setTouchEnabled(false)
           end 
       end        
    end     

    local function checkPersonInfo(event)
        if event.name == 'ended' then 
            local tab = {} 
            tab.uid = data.uid  
            tab.tag = 0
            self.app:addView('UIFriendBrief',self:getLocalZOrder()+1,tab)
        end  
    end     
    par:getChildByName('Button_detail'):onTouch(checkPersonInfo)
    par:getChildByName('Button_detail'):setPressedActionEnabled(false)
    par:getChildByName('Button_detail'):setTouchEnabled(false)
end

--玩家站起   
function UIGameTableWanren:TCP_PLSYER_STANDUP(data)
    -- dump(data,'玩家站起 ') 
    if data.SeatId then 
       local par =  self['Panel_Player'..data.SeatId]
       par:getChildByName('Panel_personInfo'):setTag(1)
       par:getChildByName('Panel_personInfo'):setVisible(false)
       par:getChildByName('btn_sit'):setVisible(true)

       for key,var in pairs(self.seatPlayerUidTable) do 
           if tostring(var.seatId) == tostring(data.SeatId) then 
              table.remove(self.seatPlayerUidTable,key)
           end 
       end  
    end  
end

--庄家列表
function UIGameTableWanren:TCP_DEALER_LIST(data)
    -- dump(data,'庄家列表')
    if data.DealerList then 
        self.nowDealerList = data.DealerList 
    end     
end    
 


--有人下注
function UIGameTableWanren:TCP_SOMEONE_BET(data)
    -- dump(data,'有人下注 ')   --这里的seatId 是指奖池id 
    if data.coin and data.uid and data.seatId then 
        if tostring(data.uid) == tostring(G_UID)   then 
           self.nowHaveBet = self.nowHaveBet +  tonumber(data.coin)
           self.pData.coin = tonumber(self.pData.coin) - tonumber(data.coin)
           self.nowPoolHaveBet[data.seatId] = self.nowPoolHaveBet[data.seatId] + tonumber(data.coin)
           self:updateMyCoin()

            local bg = self['Panel_card_'..data.seatId]:getChildByName('Image_ammount_bottom')
            bg:loadTexture('wanren/bgT3.png',ccui.TextureResType.plistType)
            bg:getChildByName('Text_ammount_bottom'):setColor(cc.c3b(255,222,0))
            bg:getChildByName('Text_ammount_bottom'):setString(LuaTools.convertAmountChinese(self.nowPoolHaveBet[data.seatId])) 
        end  
        local id = self:getSeatIDByUid(data.uid) 
        self:FlyChips(id,data.coin,data.seatId) 

        
        for key,var in pairs(self.seatPlayerUidTable) do 
            if var.uid == G_UID then 
                self['Panel_Player'..var.seatId]:getChildByName('Panel_personInfo'):
                getChildByName('Text_coin'):setString(LuaTools.convertAmountChinese(self.pData.coin))        
            end 
        end                 
            -- if var.uid == data.uid then 
            --     var.coin = tonumber(var.coin) - tonumber(data.coin) 
            --     if var.seatId >=0 and var.seatId <=5 and var.coin >= 0 then 
            --         self['Panel_Player'..var.seatId]:getChildByName('Panel_personInfo'):
            --         getChildByName('Text_coin'):setString(LuaTools.convertAmountChinese(var.coin))
            --     end     
            -- end 
    end  
end     

function UIGameTableWanren:setButtonStats(btn, status)
    btn:setTouchEnabled(status)
    -- btn:setEnabled(status)
    btn:setBright(status)
    if status == false then
        btn:setColor(cc.c3b(77,77,77))
    else
        btn:setColor(cc.c3b(255,255,255))
    end
end
--置灰筹码判断
function UIGameTableWanren:setChipButtonStatus(coin,tag)
    local tempCoin = coin / 8 - self.nowHaveBet
    self:setButtonStats(self["Button_100"],false)
    self:setButtonStats(self["Button_1000"],false)
    self:setButtonStats(self["Button_1wan"],false)
    self:setButtonStats(self["Button_10wan"],false)
    self:setButtonStats(self["Button_100wan"],false)
    
    if tag == 1 then  --我自己上庄  置灰全部下注按钮
        return
    end     
    if tempCoin > 100 then
        self:setButtonStats(self["Button_100"],true)
    end
    if tempCoin > 1000 then
        self:setButtonStats(self["Button_1000"],true)
    end
    if tempCoin > 10000 then
        self:setButtonStats(self["Button_1wan"],true)
    end
    if tempCoin > 100000 then
        self:setButtonStats(self["Button_10wan"],true)
    end
    if tempCoin > 1000000 then
        self:setButtonStats(self["Button_100wan"],true)
    end
end

--更新金币显示
function UIGameTableWanren:updateMyCoin()
    self['Text_myCoin']:setString(LuaTools.convertAmountChinese(self.pData.coin)) 
    self:setChipButtonStatus(self.pData.coin)
end     

--有人进入
function UIGameTableWanren:TCP_SOMEONE_IN(data) 
   -- dump(data,'有人进入')
   if data.uid then  
       if data.uid ~= G_UID then 
           local temp = {}  
           temp.uid      = data.uid 
           temp.coin     = data.coin 
           temp.sex      = data.sex 
           temp.vipLevel = data.vipLevel
           temp.vipType  = data.vipType 
           temp.icon     = data.icon 
           temp.nick     = data.nick 

           self:saveNoSeatPlayerInfo(temp)  
       end 
   end  


end

--有人离开
function UIGameTableWanren:TCP_SOMEONE_OUT(data)
   dump(data,'有人离开')
    if data.uid then 
       local tag  = self:getSeatIDByUid(data.uid)
       if tag <= 5 then 
           local par =  self['Panel_Player'..tag]
           par:getChildByName('Panel_personInfo'):setTag(1)
           par:getChildByName('Panel_personInfo'):setVisible(false)
           par:getChildByName('btn_sit'):setVisible(true)

           for key,var in pairs(self.seatPlayerUidTable) do 
               if tostring(var.seatId) == tostring(tag) then 
                  table.remove(self.seatPlayerUidTable,key)
               end 
           end  
       elseif  tag == 7 then 
           self:clearNoSeatPlayerInfo(data.uid) 
       end     
    end  

end

--保存无座玩家信息
function UIGameTableWanren:saveNoSeatPlayerInfo(tab)  
    local function compare(uid) 
        for key,var in pairs(self.noSeatPlayerInfo)  do 
            if tostring(var.uid) == tostring(uid) then 
                return true 
            end 
        end         
    end     

    if  #self.noSeatPlayerInfo > 0 then 
        local temp = compare(tab.uid) 
        if  temp ~= true then 
            table.insert(self.noSeatPlayerInfo,tab) 
        end 
    else 
        table.insert(self.noSeatPlayerInfo,tab) 
    end          
end     

--清除无座玩家信息
function UIGameTableWanren:clearNoSeatPlayerInfo(uid)
    if #self.noSeatPlayerInfo == 0 or not uid  then  return end 
    for key,var in pairs(self.noSeatPlayerInfo)  do 
        if tostring(var.uid) == tostring(uid) then 
            table.remove(self.noSeatPlayerInfo,key)
        end 
    end 
end     

---------------------------------------------------------------------
---------------------------------------------------------------------
---------------------------------------------------------------------
---------------------------------------------------------------------
function UIGameTableWanren:getLoginBuffer(tableId) 
    if not tableId then tableId = 9 end 
    local bufferHnd = DataPacker.new(UIGameTableWanren.CMD['TABLE_LOGIN'],{protocalVersion = 2})
    bufferHnd:writeData(G_UID,DataPacker.INT)
    bufferHnd:writeData(G_TOKEN,DataPacker.STRING)
    bufferHnd:writeData(tableId,DataPacker.BYTE)
    return bufferHnd:doPack()
end

function UIGameTableWanren:TCP_onConnected() 
    if G_LOADINGVIEW then
        G_LOADINGVIEW:removeSelf()
        G_LOADINGVIEW = nil 
    end
    local buffer = self:getLoginBuffer()
    self.tcpGear:sendData(buffer) 
    self:scheduleHeartbeat()
end

function UIGameTableWanren:scheduleHeartbeat()
    self:stopSchedule('heartbeat')
    self:createSchedule('heartbeat', function()   
        self:REQ_heartbeat() 
    end,20)  
end


function UIGameTableWanren:TCP_HEARTBEAT(data)
    -- dump(data,'Wanren_TCP_HEARTBEAT')
end 


function UIGameTableWanren:closeWanRenTcp()  
   self:stopSchedule('heartbeat')
   self:REQ_ASK_LEAVE()
end     

-------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------

function UIGameTableWanren:onCreate(argTable)
    local app = self:getApp()
    self.tool = app:getModel('Tools')
    self.app  = app
    argTable = argTable or {} 
    self.timeTable = {}
    self.tableType  = argTable.tableType    or -1
    self.friendID   = argTable.friendID      or -1
    self.RoomId     = argTable.RoomId        or -1
    self.config  = app:getData('Config')
    self.pData   = app:getData('PlayerData') 

    self.dealerState  = '申请上庄'
    self.seatPlayerUidTable = {}  --有座位玩家 存放uid 和座位id(0-5) and coin
    self.poolChips        = {0,0,0,0}  --奖池当前的下注额    
    self.PoolNeedFlyChips = {}  --最终结算时 各个奖池的输赢状况
    self.nowHaveBet       = 0   --当前已下注的总筹码
    self.nowPoolHaveBet   = {0,0,0,0}  --当前我在各个奖池下注的筹码

    self.noSeatPlayerInfo = {}  --没有座位的玩家信息
    self.nowDealerList    = {}  --当前庄家列表
    self.nowDealerInfo    = {}  --当前庄家信息

    self['Button_chatBtn']:setVisible(true) 

    self.finalWinPool  = {} 
    self.finalLossPoolDouble = {} 
    self.finalLossPool = {} 

    audio.stopAllSounds()  
    audio.stopMusic(true) 
    


    local broadCast =  self.app:addView({uiName = 'UIBroadcast', uiInstanceName = "forGameWanren"},501)
    broadCast:setPositionX(self['Panel_boardcast']:getPositionX())
    broadCast:setPositionY(self['Panel_boardcast']:getPositionY())

    self.CleanAllStadusTag  = false  --清除所有状态
    local function onKeyReleased(keyCode, event)
        if keyCode == cc.KeyCode.KEY_BACK  then
              self:back()
        end
    end
    local listener = cc.EventListenerKeyboard:create()
    listener:registerScriptHandler(onKeyReleased, cc.Handler.EVENT_KEYBOARD_RELEASED )
    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener, self)

    self.seatChipsTab = {
                          {{},{},{},{}},
                          {{},{},{},{}},
                          {{},{},{},{}},
                          {{},{},{},{}},
                          {{},{},{},{}},
                          {{},{},{},{}},
                          {{},{},{},{}},
                          {{},{},{},{}},
                          }
    self:setSelectingChipButton(self["Button_100"], 100)
    for key=1,6 do 
        self['Panel_Player'..(key-1)]:getChildByName('Panel_personInfo'):setVisible(false) 
    end     
    -- dump(self.pData.GameTypes,'ssssssssssssdddddddddddddddddd')
    local nowPort 
    if self.pData.GameTypes['GameType_WRDN'] and self.pData.GameTypes['GameType_WRDN'][1] then 
        nowPort =  self.pData.GameTypes['GameType_WRDN'][1].port  
    end     
    self.tcpGear = TCPGearbox.buildInstance({
            unpackerType = DataUnpacker.Type.GAME_Wanren, 
            delegate = self,  
            callbackPrefix = "TCP_",
            name = 'UIGameTableWanren TCP',
            -- ip = '14.17.77.164'
            port = nowPort or 6830
    })
    self.lastDoubleBgWin = {
    "wanren/double2.png",
    "wanren/double3.png",
    "wanren/double4.png",
    "wanren/double5.png",
    "wanren/double8.png",
    }
    self.lastDoubleBgLoss = {
    "wanren/doubleL2.png",
    "wanren/doubleL3.png",
    "wanren/doubleL4.png",
    "wanren/doubleL5.png",
    "wanren/doubleL8.png",
    }

    self.cardTypeTableImage = {
     "imagL_0.png",
     "imagL_1.png",
     "imagL_2.png",
     "imagL_3.png",
     "imagL_4.png",
     "imagL_5.png",
     "imagL_6.png",
     "imagL_7.png",
     "imagL_8.png",
     "imagL_9.png",
     "imagL_10.png",
     "4bombL.png",
     "fivekindsL.png",
     "fivesmallL.png",
     }
     
     self.cardTypeTableImageWin =   {
     "imag_0.png",
     "imag_1.png",
     "imag_2.png",
     "imag_3.png",
     "imag_4.png",
     "imag_5.png",
     "imag_6.png",
     "imag_7.png",
     "imag_8.png",
     "imag_9.png",
     "imag_10.png",
     "4bomb.png",
     "fivekinds.png",
     "fivesmall.png",
     }

     self.cardNiuTypeBg = {
     "wanren/imag_bg.png",
     "wanren/imag_bgw2.png",
     "wanren/imag_bgw1.png",
     "wanren/imag_bgw3.png",
     } 
     self.cardTypeTableWord = {"没牛","牛一","牛二","牛三","牛四", 
     "牛五","牛六","牛七","牛八","牛九","牛牛", "四炸","五花牛","五小牛"}


     for key =1,6 do 
         local function sitDown(event)
            if event.name == 'ended' then 
               if G_UID  == self.nowDealerInfo.uid then 
                  LuaTools.showAlert('庄家不能坐下')
                  return 
               elseif tonumber(self.pData.coin) < 1000000 then 
                  LuaTools.showAlert('金币超过100万方可入座喔~')
                  return 
               end    
               self:REQ_ASK_SIT(key-1)
            end    
         end 
         self['Panel_Player'..(key-1)]:getChildByName('btn_sit'):onTouch(sitDown)
     end        
     
     self['Image_myAvatar']:setLocalZOrder(111)
     self['Panel_bottom']:getChildByName('BMF_win'):setLocalZOrder(112)
     self['Panel_bottom']:getChildByName('BMF_Loss'):setLocalZOrder(112)

     for key =1,4 do 
        self['Image_cardTypeBg'..key]:setLocalZOrder(100)
        self['Panel_card_'..key]:getChildByName('Panel_showCard'):setVisible(true)
        self['Panel_card_'..key]:getChildByName('Image_ammount_bottom'):setVisible(false)
     end    
     self['Panel_bottom']:setLocalZOrder(10) 
    
    self:initAllCards()
    self:setChipButtonStatus(self.pData.coin)

    self:initAllPlayerPos()
    self:initAllTablePos()

    self["Panel_card_1"]:setDontPlayDefaultSFX(true)
    self["Panel_card_2"]:setDontPlayDefaultSFX(true)
    self["Panel_card_3"]:setDontPlayDefaultSFX(true)
    self["Panel_card_4"]:setDontPlayDefaultSFX(true)
end

function UIGameTableWanren:initAllTablePos()
    self.allTablePos = {}
    for i=1,4 do
        local pos = self["Panel_card_"..i]:getParent():convertToWorldSpace(cc.p(self["Panel_card_"..i]:getPosition()))
        table.insert(self.allTablePos, pos)
    end
end

function UIGameTableWanren:initAllPlayerPos()
    self.allPlayerPos = {}
    local pos = nil
    for i=1, 9 do
        if i <= 6 then
            pos = self["Panel_Player"..(i-1)]:getParent():convertToWorldSpace(cc.p(self["Panel_Player"..(i-1)]:getPosition()))
        elseif i == 7 then
            pos = self["Image_myAvatar"]:getParent():convertToWorldSpace(cc.p(self["Image_myAvatar"]:getPosition()))
        elseif i == 8 then
            pos = self["Button_unseat_palyer"]:getParent():convertToWorldSpace(cc.p(self["Button_unseat_palyer"]:getPosition()))
        else
            pos = self["Image_DealerAvatar"]:getParent():convertToWorldSpace(cc.p(self["Image_DealerAvatar"]:getPosition()))
        end
        table.insert(self.allPlayerPos, pos)
    end
    -- dump(self.allPlayerPos, "allPlayerPos")
end
-- {1} {2,3,4}
function UIGameTableWanren:doDealtResult(doubleLoseTable, winTable, loseTable, callBack)
    local function myFinishCallback()
        for k,v in pairs(self.seatChipsTab) do
            for k2,v2 in pairs(v) do
                for k3,v3 in pairs(v2) do
                    v3:removeFromParent(true)
                end
            end
        end
        self.seatChipsTab = {
                          {{},{},{},{}},
                          {{},{},{},{}},
                          {{},{},{},{}},
                          {{},{},{},{}},
                          {{},{},{},{}},
                          {{},{},{},{}},
                          {{},{},{},{}},
                          {{},{},{},{}},
                          }
        callBack()
    end
    local function callChipToPlayer()
        self:gatherChipsAllTable(winTable, myFinishCallback)
    end

    local function callBankerPay()
        self:bankerPayAllTable(winTable, callChipToPlayer)
    end
    local function callBankerGet()
        self:bankerGetAllTable(loseTable, callBankerPay)
    end

    local function callPlayerPay()
        self:playerPayAllTable(doubleLoseTable, callBankerGet)
    end
    local delay = cc.DelayTime:create(2.0)
    local call = cc.CallFunc:create(callPlayerPay)
    local seq = cc.Sequence:create(delay, call)
    self:runAction(seq)
end

function UIGameTableWanren:FlyChips(seatID,amount,kindNum)
    local per100Wan = amount / 1000000 
    for i=1, per100Wan do
        self:flyOneChip(seatID, 1000000, kindNum)
    end

    local per10Wan = ( amount % 1000000 ) / 100000
    for i=1, per10Wan do
        self:flyOneChip(seatID, 100000, kindNum)
    end

    local per1Wan = ( amount % 100000 ) / 10000
    for i=1, per1Wan do
        self:flyOneChip(seatID, 10000, kindNum)
    end

    local per1000 = ( amount % 10000 ) / 1000
    for i=1, per1000 do
        self:flyOneChip(seatID, 1000, kindNum)
    end

    local per100 = ( amount % 1000 ) / 100
    for i=1, per100 do
        self:flyOneChip(seatID, 100, kindNum)
    end

    audio.playSound(Sound.SoundTable['sfx']['Chip_in'] , false)
end

function UIGameTableWanren:flyOneChip(seatID, amount, kindNum)
    local isFast = false
    local scaleToFactor = 0.48               --筹码缩放值
    local moveSpeed = 1.5
    local easeRate = 0.2
    local img = 'wanren/'..amount..'.png'
    local chipNode = ccui.ImageView:create(img,ccui.TextureResType.plistType)
    local startPos = self.allPlayerPos[seatID+1]
    self['Panel_fullscreenmode']:addChild(chipNode,50)
    chipNode:setVisible(true)
    chipNode:setScale(scaleToFactor)
    chipNode:setPosition(startPos)
    table.insert(self.seatChipsTab[seatID+1][kindNum],chipNode)

    local tempPos = self.allTablePos[kindNum]
    local tgtPosX =  tempPos.x +  math.random(20, self['Panel_card_'..kindNum]:getContentSize().width-20) 
    local tgtPosY =  tempPos.y +  math.random(20, self['Panel_card_'..kindNum]:getContentSize().height-60)
    

    if isFast then
        chipNode:setVisible(true)
        chipNode:setPosition(cc.p(tgtPosX,tgtPosY)) 
        chipNode:setScale(scaleToFactor)
    else   
        chipNode:setOpacity(0)
        chipNode:stopAllActions()
        local mov = cc.MoveTo:create(moveSpeed,cc.p(tgtPosX,tgtPosY))
        local ease = cc.EaseExponentialOut:create(mov)
        local rotate = cc.RotateBy:create(moveSpeed,math.random(-90,90))
        rotate = cc.EaseExponentialOut:create(rotate)
        local fadeIn = cc.FadeTo:create(moveSpeed*0.1 ,255)
        local spawn = cc.Spawn:create(ease,fadeIn,rotate) 
        local act = cc.Sequence:create(cc.DelayTime:create(0.2),cc.Show:create(),spawn)
        chipNode:runAction(act)
    end
end

function UIGameTableWanren:gatherChipsAllTable(winTable, finishCallback)
    if winTable == nil or #winTable == 0 then
        finishCallback()
        return
    end
    local isDisCall = false
    for k,v in pairs(winTable) do
        if isDisCall == false and finishCallback then
            self:getChips(v, false, finishCallback)
            isDisCall = true
        else
            self:getChips(v, false)
        end
    end
    if self:cheekTableHaveChip(winTable) == true then
        audio.playSound(Sound.SoundTable['sfx']['Chipfly'] , false)
    end
end

--赢金币，不管是庄家还是玩家
function UIGameTableWanren:getChips(kindNum, isBanker, finishCallback)
    local isDisCall = false
    local time = 1.0
    for i=1,8 do
        for k,v in pairs(self.seatChipsTab[i][kindNum]) do
            local mov = nil
            local tempTime = time
            if isBanker == true then
                mov = cc.MoveTo:create(tempTime, self.allPlayerPos[9])
            else
                mov = cc.MoveTo:create(tempTime, self.allPlayerPos[i])
            end
            local ease = cc.EaseExponentialOut:create(mov)
            local out = cc.FadeOut:create(tempTime*0.6)
            local spawn = cc.Spawn:create(ease, out)
            local seq = nil
            if isDisCall == false and finishCallback then
                local call = cc.CallFunc:create(finishCallback)
                seq = cc.Sequence:create(cc.DelayTime:create(math.random(1,10)*0.05), spawn, call)
                isDisCall = true
            else
                seq = cc.Sequence:create(cc.DelayTime:create(math.random(1,10)*0.05), spawn)
            end
            v:runAction(seq)
        end
    end

    if isDisCall == false and finishCallback then
        local call = cc.CallFunc:create(finishCallback)
        local action = cc.Sequence:create(cc.DelayTime:create(1.5), call)
        self:runAction(action)
    end
end

function UIGameTableWanren:bankerGetAllTable(loseTable, finishCallback)
    if loseTable == nil or #loseTable == 0 then
        finishCallback()
        return
    end
    local isDisCall = false
    for k,v in pairs(loseTable) do
        if isDisCall == false and finishCallback then
            self:getChips(v, true, finishCallback)
            isDisCall = true
        else
            self:getChips(v, true)
        end
    end
    if self:cheekTableHaveChip(loseTable) == true then
        audio.playSound(Sound.SoundTable['sfx']['Chipfly'] , false)
    end
end

function UIGameTableWanren:playerPayAllTable(loseTable, finishCallback)
    if loseTable == nil or #loseTable == 0 then
        finishCallback()
        return
    end

    local allCopy = {}
    local isDisCall = false
    local copy = nil
    for k,v in pairs(loseTable) do
        if isDisCall == false and finishCallback then
            copy = self:doPayChipsToPool(v, false, finishCallback)
            isDisCall = true
        else
            copy = self:doPayChipsToPool(v, false)
        end
        table.insert(allCopy, copy)
    end

    for k,v in pairs(allCopy) do
        for k2,v2 in pairs(v) do
            table.insert(self.seatChipsTab[v2.seatID][v2.kindNum], v2)
        end
    end
    if self:cheekTableHaveChip(loseTable) == true then
        audio.playSound(Sound.SoundTable['sfx']['Chipfly'] , false)
    end
end


function UIGameTableWanren:bankerPayAllTable(winTable, finishCallback)
    if winTable == nil or #winTable == 0 then
        finishCallback()
        return
    end

    local allCopy = {}
    local isDisCall = false
    local copy = nil
    for k,v in pairs(winTable) do
        if isDisCall == false and finishCallback then
            copy = self:doPayChipsToPool(v, true, finishCallback)
            isDisCall = true
        else
            copy = self:doPayChipsToPool(v, true)
        end
        table.insert(allCopy, copy)
    end
    if isDisCall == false then
        printError("isDisCall == false")
    end

    for k,v in pairs(allCopy) do
        for k2,v2 in pairs(v) do
            table.insert(self.seatChipsTab[v2.seatID][v2.kindNum], v2)
        end
    end
    if self:cheekTableHaveChip(winTable) == true then
        audio.playSound(Sound.SoundTable['sfx']['Chipfly'] , false)
    end
end

--扔筹码出去桌子，不管是庄家还是玩家
function UIGameTableWanren:doPayChipsToPool(kindNum, isBanker, finishCallback)
    local isDisCall = false
    local moveSpeed = 1.5
    local allCopyImg = {}
    for i=1,8 do
        local allImg = self.seatChipsTab[i][kindNum]
        for j=1, #allImg do
            local v = allImg[j]
            local newImg = v:clone()
            newImg.seatID = i
            newImg.kindNum = kindNum
            self['Panel_fullscreenmode']:addChild(newImg,51)
            table.insert(allCopyImg, newImg)
        end
    end
    for k,v in pairs(allCopyImg) do
        local startPos = nil
        if isBanker == true then
            startPos = self.allPlayerPos[9]
        else
            startPos = self.allPlayerPos[v.seatID]
        end
        v:setPosition(startPos.x, startPos.y)
        local tempPos = self.allTablePos[kindNum]
        local tgtPosX =  tempPos.x +  math.random(20, self['Panel_card_'..kindNum]:getContentSize().width-20) 
        local tgtPosY =  tempPos.y +  math.random(20, self['Panel_card_'..kindNum]:getContentSize().height-60)

        local mov = cc.MoveTo:create(moveSpeed,cc.p(tgtPosX,tgtPosY))
        local ease = cc.EaseExponentialOut:create(mov)
        local rotate = cc.RotateBy:create(moveSpeed,math.random(-90,90))
        rotate = cc.EaseExponentialOut:create(rotate)
        local fadeIn = cc.FadeTo:create(moveSpeed*0.1 ,255)
        local spawn = cc.Spawn:create(ease,fadeIn,rotate) 
        local act = nil
        if isDisCall == false and finishCallback then
            local call = cc.CallFunc:create(finishCallback)
            act = cc.Sequence:create(cc.DelayTime:create(math.random(1,10)*0.05), spawn, call)
            isDisCall = true
        else
            act = cc.Sequence:create(cc.DelayTime:create(math.random(1,10)*0.05), spawn)
        end
        v:runAction(act)
    end
    if isDisCall == false and finishCallback then
        local call = cc.CallFunc:create(finishCallback)
        local action = cc.Sequence:create(cc.DelayTime:create(1.5), call)
        self:runAction(action)
    end
    return allCopyImg
end

function UIGameTableWanren:cheekTableHaveChip(table)
    for k,v in pairs(table) do
        for i=1,8 do
            local allImg = self.seatChipsTab[i][v]
            if #allImg > 0 then
                return true
            end
        end
    end
    return false
end

function UIGameTableWanren:addChatBg(arg)
    local size = arg.parentNode:getContentSize()
    local wPointPar =  arg.parentNode:convertToWorldSpace(cc.p(0,0))
    local logCount   --G_BASEAPP:getData('PlayerData').chatLogCount 
    -- logCount = logCount + 1 
    if  arg.parentNode == self['Button_chatBtn'] then 
        logCount = 100000 
        if self:getChildByName('chat_record_new100000') then 
            self:removeChildByName('chat_record_new100000')
        end 
    else 
        logCount = math.random(1,99999)
    end     

    local chat_bg  
    if arg.msgType == 1 then  --表情     
        chat_bg = ccui.ImageView:create(string.format('res_chat/faceicon%d.png',arg.msg),ccui.TextureResType.plistType)
        self:addChild(chat_bg,10086)

        chat_bg:setName('chat_record_new'..logCount) 
        chat_bg:setPosition(wPointPar.x+size.width/2,wPointPar.y+size.height/2) 
        local act1 = cc.ScaleTo:create(0.5,1.6)
        local act2 = cc.ScaleTo:create(0.5,1.2)  
        local act3 = act1:clone() 
        local act4 = act2:clone()
        chat_bg:runAction(cc.Sequence:create(act1,act2,act1:clone(),act2:clone(),act3,act4))
    else 
        local text_table = {'快点吧~我等得花儿都谢了',
                            '投降输一半，速度投降吧',
                            '你的牌打得太好了',
                            '吐了个槽的，整个一个杯具啊',
                            '天灵灵，地灵灵，给手好牌行不行',
                            '大清早的，鸡还没叫呢，慌什么嘛',
                            '不要走，决战到天亮',
                            '大家好，很高兴见到各位！',
                            '出来混，迟早要还的',
                            '再见了，我会想念大家的'} 
        local str = (arg.msgType ==2 and text_table[tonumber(arg.msg)] or arg.msg) 
        if arg.msgType ==2 then 
           local a = tonumber(arg.sex) == 1 and 'female' or 'male' 
           local b = tonumber(arg.sex) == 1 and 'Woman_Chat_' or 'Man_Chat_'
           audio.playSound(Sound.SoundTable['voice'][a][b..arg.msg],false)
        end    
        -- print(arg.isRight)
        local hisStr = arg.name..':'..str
        table.insert( G_BASEAPP:getData('PlayerData').faceIconRecord,hisStr)

        local chat_bg = ccui.ImageView:create(arg.isRight and 'wanren/Roomchatnormal1.png' or 'wanren/Roomchatnormal2.png',ccui.TextureResType.plistType) 
        self:addChild(chat_bg,10086) 

        chat_bg:setScale9Enabled(true)
        chat_bg:setCapInsets(cc.rect(31, 50, 32, 11))--(cc.rect(31, 31, 50, 21))
        
        chat_bg:setName('chat_record_new'..logCount) 
        
        local posX,posY = (arg.isRight==true and 0 or size.width) , size.height
        chat_bg:setPosition(wPointPar.x+posX/2+45,wPointPar.y+posY/2) 

        local text2 =  ccui.Text:create()
        text2:setFontSize(30)
        text2:setString(str) 
        val1 = text2:getVirtualRendererSize().width
        local bg_width = (val1>=500 and 500 or val1)
        local b = math.ceil(val1/500)+1 
        local textArea = ccui.Text:create()
        textArea:ignoreContentAdaptWithSize(false)
        textArea:setContentSize(cc.size(bg_width, b*30+10))
        textArea:setAnchorPoint(0,0.5)
        textArea:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT)
        textArea:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
        chat_bg:setContentSize(cc.size(bg_width+50, b*30+20))

        textArea:setString(str)
        textArea:setFontSize(30)
        textArea:setColor(cc.c3b(255,255,255))
        local myPosX = (arg.isRight and  (bg_width+20) or 30)
        textArea:setPosition(myPosX,chat_bg:getContentSize().height/2)
        if arg.isRight then
            textArea:setAnchorPoint(1,0.5)
            chat_bg:setAnchorPoint(1,0)
        else     
            textArea:setAnchorPoint(0,0.5)
            chat_bg:setAnchorPoint(0,0)
        end     
        chat_bg:addChild(textArea)
    end  
    local function  fadeAction()
         if self:getChildByName('chat_record_new'..logCount) then 
            self:removeChildByName('chat_record_new'..logCount)
         end    
    end     
    arg.parentNode:runAction(cc.Sequence:create(cc.DelayTime:create(3),cc.CallFunc:create(fadeAction)))
end

--根据uid得到玩家位置信息  uid  name  供聊天展示
function UIGameTableWanren:getChatInfoTab(data)

    if tonumber(data.uid) == tonumber(G_UID)   then  
       data.name        = self.pData.nick 
       data.sex         = self.pData.sex
       data.parentNode  = self['Image_myAvatar']
       data.isRight     = false
    elseif tonumber(data.uid) == tonumber(self.nowDealerInfo.uid) then  -- 庄家 
       data.name        = self.nowDealerInfo.nick 
       data.sex         = self.nowDealerInfo.sex
       data.parentNode  = self['Image_DealerAvatar']
       data.isRight     = false 
    else 
       local function compare(uid)
           local a = ''            
           for key,var in pairs(self.seatPlayerUidTable) do 
               if tostring(uid) == tostring(var.uid) then 
                   a = var 
               end 
           end        
           return a 
       end  
       local tempTag = compare(data.uid)
       if tempTag~= '' then 
           tempTag.parentNode =   self['Panel_Player'..tempTag.seatId]
           tempTag.isRight    = tonumber(tempTag.seatId)>2 and true or false 
       else 
           tempTag = {}
           for key,var in pairs(self.noSeatPlayerInfo)  do 
                if tostring(var.uid) == tostring(data.uid) then 
                    tempTag = var
                    tempTag.name = var.nick
                end 
           end  
           tempTag.parentNode =  self['Button_chatBtn']
           tempTag.isRight    =  true 
       end  
       tempTag.uid = data.uid 
       tempTag.msg = data.msg 
       tempTag.msgType = data.msgType 
       data = tempTag
    end     
    return data 
end    

--文字聊天  wordChat
function UIGameTableWanren:TCP_CHAT(info) 
    local temp = {} 
    temp.msgType = 3
    temp.msg     = info.msg
    temp.uid     = info.playerUID
    self:addChatBg(self:getChatInfoTab(temp))
end 

--表情聊天 faceChat     playerUID
function UIGameTableWanren:TCP_EMOJI(info)
    local temp = {} 
    temp.msgType = 1 
    temp.msg     = info.msg
    temp.uid     = info.playerUID
    self:addChatBg(self:getChatInfoTab(temp))
end 

--常用语聊天  commonChat
function UIGameTableWanren:TCP_CONST_TEXT(info) 
    local temp = {} 
    temp.msgType = 2 
    temp.msg     = info.msg
    temp.uid     = info.playerUID
    self:addChatBg(self:getChatInfoTab(temp))
end 

return UIGameTableWanren
