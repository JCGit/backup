local UIGameTableSanzhang = class("UIGameTableSanzhang", cc.load("mvc").ViewBase)

UIGameTableSanzhang.RESOURCE_FILENAME = "UIGameTableSanzhang.csb" 

local GameTableCommon = require("app.models.GameTableCommon")
local TCPConnector = require('app.network.TCPConnector')
local DataPacker = require('app.network.DataPacker')
local DataUnpacker = require('app.network.DataUnpacker')
local HttpHandler = require("app.network.HttpHandler")
 

UIGameTableSanzhang.RESOURCE_BINDING = { 

    ["Button_dont_grab"]   = {["ended"] = "PlayerCtrl_dont_grab"}, 
    ["Button_readyup"]   = {["ended"] = "REQ_READY"}, 
    ["Button_changeTable"]   = {["ended"] = "PlayerCtrl_changeTable"},  
    ["Button_back"]   = {["ended"] = "PlayerCtrl_back"},  

    ['Button_allin']    = {['ended']  =   "PlayerCtrl_allin"   },
    ['Button_follow']   = {['ended']  =   "PlayerCtrl_follow"   },
    ['Button_add']      = {['ended']  =   "PlayerCtrl_add"   },
    ['Button_show']     = {['ended']  =   "PlayerCtrl_show"   },
    ['Button_comp']     = {['ended']  =   "PlayerCtrl_comp"   },
    ['Button_drop']     = {['ended']  =   "PlayerCtrl_drop"   },

    ['CheckBox_follow5']     = {['ended']  =    "processCheckBoxes"   },
    ['CheckBox_follow10']     = {['ended']  =   "processCheckBoxes"   },
    ['CheckBox_follow20']     = {['ended']  =   "processCheckBoxes"   },
    ['CheckBox_followall']     = {['ended']  =  "processCheckBoxes"   },
    ['Button_cancelAutomode']     = {['ended']  =  "cancelAutomode"   },
    ['Button_autoComfirm']     = {['ended']  =  "enableAutomode"   },
    ['Button_autoCancel']     = {['ended']  =  "cancelAutomode"   },
    
    ['Button_closeAddPanel']     = {['ended']  =   "PlayerCtrl_closeAddPanel"   },
    ['Button_autoPlay']     = {['ended']  =   "PlayerCtrl_autoPlay"   },

    -- ["Button_card_1"]   = {["ended"] = "getCardClickCallback"},  
    -- ["Button_card_2"]   = {["ended"] = "getCardClickCallback"},  
    -- ["Button_card_3"]   = {["ended"] = "getCardClickCallback"},  
    -- ["Button_card_4"]   = {["ended"] = "getCardClickCallback"},  
    -- ["Button_card_5"]   = {["ended"] = "getCardClickCallback"},  
 
}

 UIGameTableSanzhang.Config = DataUnpacker.Config[DataUnpacker.Type.GAME_Sanzhang]

UIGameTableSanzhang.SEX_MALE        = GameTableCommon.SEX_MALE     -- 男
UIGameTableSanzhang.SEX_FEMALE      = GameTableCommon.SEX_FEMALE   -- 女
UIGameTableSanzhang.DROP_COLOR = cc.c3b(150,150,150)

UIGameTableSanzhang.chipAmountTable = 
{ 
      {str = "100",    img = "zjh/100.png"  ,val = 100      }           ,
      {str = "300",    img = "zjh/300.png"  ,val = 300      }           ,
      {str = "500",    img = "zjh/500.png"  ,val = 500      }           ,
      {str = "800",    img = "zjh/800.png"  ,val = 800      }           ,
      {str = "1千" ,   img = "zjh/1000.png" ,val = 1000     }        ,
      {str = "3千" ,   img = "zjh/3000.png" ,val = 3000     }        ,
      {str = "5千" ,   img = "zjh/5000.png" ,val = 5000     }        ,
      {str = "8千" ,   img = "zjh/8000.png" ,val = 8000     }        ,
      {str = "1万" ,   img = "zjh/1w.png"   ,val = 10000  }        ,
      {str = "3万" ,   img = "zjh/3w.png"   ,val = 30000  }        ,
      {str = "5万" ,   img = "zjh/5w.png"   ,val = 50000  }        ,
      {str = "8万" ,   img = "zjh/8w.png"   ,val = 80000  }        ,
      {str = "10万",   img = "zjh/10w.png"  ,val = 100000  }            ,
} 
 





UIGameTableSanzhang.ARRANGE_MIDDLE = 1
UIGameTableSanzhang.ARRANGE_LEFT = 2
UIGameTableSanzhang.ARRANGE_RIGHT = 3


UIGameTableSanzhang.TypeTable = 
{
    [6]  = '(豹子)三条',
    [5]  = '同花顺',
    [4]  = '（金花）同花',
    [3]  = '顺子',
    [2]  = '一对',
    [1]  = '高牌',
    [0]  = '无效牌',

}


UIGameTableSanzhang.TIP_NORMAL_PLAYER_TOAST = 0x01;-- // 客户端Toast弹窗
UIGameTableSanzhang.TIP_NORMAL_PLAYER_POP = 0x02;--// 客户端Pop弹窗
UIGameTableSanzhang.TIP_NORMAL_PLAYER_CloseConn = 0x03;--// 关闭连接,触摸退出房间
UIGameTableSanzhang.TIP_NORMAL_READY_COIN_NO_ENOUGH = 0x04;--// 关闭连接,触摸退出房间


-- UIGameTableSanzhang.ImageStatusTable = {
--     'RoomPlayerSatus_1.png',
--     'RoomPlayerSatus_5.png',
-- }
-- UIGameTableSanzhang.ButtonStatusTable = {
--     [UIGameTableSanzhang.TableStateWait] = 
--     {
--         {name = 'Button_readyup',       enabled = true},
--         {name = 'Button_changeTable',   enabled = true},
--     },
--     [UIGameTableSanzhang.TableStateReady] = 
--     {
--         {name = 'Button_readyup',       enabled = true},
--         {name = 'Button_changeTable',   enabled = true},
--     }, 
--     [UIGameTableSanzhang.TableStateGrab] = 
--     {
--         {name = 'Button_dont_grab',       enabled = true},
--         {name = 'Panel_multiply',   enabled = true},
--     },
--     [UIGameTableSanzhang.TableStateMulti] = 
--     { 
--         {name = 'Panel_multiply',   enabled = true},
--     },--Button_dont_grab
--     [UIGameTableSanzhang.TableStateTurn] = 
--     {
--         {name = 'Button_have_bull',       enabled = true},
--         {name = 'Panel_calc',   enabled = true},
--     },
-- }

UIGameTableSanzhang.displayIDTable = 
{
    true,
    false,
    false,
    false,
    false,
}
UIGameTableSanzhang.CMD = DataUnpacker.CMD[DataUnpacker.Type.GAME_Sanzhang]['REQ']
------------------------- button callbacks ---------------------------
 
 function UIGameTableSanzhang:PlayerCtrl_autoPlay()
    self:automodeCalback()
 end


 function UIGameTableSanzhang:PlayerCtrl_closeAddPanel() 
    self['Image_addPanel']:setVisible(false)
 end

 function UIGameTableSanzhang:PlayerCtrl_back()
    -- body

   -- GameTableCommon.quitComfirm(self,{CMD = UIGameTable.CMD['USER_GRAB_LORD']})
   if self.pkNode ~= nil then
        self.pkNode:removeFromParent()
        self.pkNode = nil
    end
   GameTableCommon.quitComfirm(self)
end

function UIGameTableSanzhang:PlayerCtrl_allin()
    self:REQ_ALLIN()  
end


function UIGameTableSanzhang:PlayerCtrl_follow()
    
    audio.playSound(Sound.SoundTable['sfx']['Chip_in'], false)  
    -- printError('PLAYING Chip_inChip_inChip_inChip_inChip_inChip_inChip_inChip_inChip_inChip_inChip_inChip_in')
    self:REQ_FOLLOW()
end


function UIGameTableSanzhang:PlayerCtrl_add(event)
    local tag = event.target:getTag() 
    self:generateAdditionButton( self.additionTable ) 
end


function UIGameTableSanzhang:PlayerCtrl_show()
    print(' UIGameTableSanzhang:PlayerCtrl_show()')
    self:REQ_SHOW_CARDS()
end


function UIGameTableSanzhang:PlayerCtrl_comp()
    if self:getNumberOfPlayerStillPlaying() <=2 then 
        for k,v in pairs(self.playerData) do
            if v.isDrop ~= true and v.isSat == true and k ~= self.mySeatID then
                dump(v,'found['..k..']')
                dump(self.playerData,'all')
                self:REQ_COMPARE(k)
                break
            end
        end 
    else 
        self:showComp()
    end

end


function UIGameTableSanzhang:PlayerCtrl_drop()
    self:REQ_DROP()
end



function UIGameTableSanzhang:PlayerCtrl_changeTable() 
    -- if self.isChangeTableLockDown == true then 
    --     local blah = ""..cc.Director:getInstance():getTotalFrames()
    --     G_BASEAPP:addView({
    --        uiName =  'UIAlert',
    --        uiInstanceName = blah
    --         },1000)
    --     :setupDialog('Infomation',"更换平率过快，低于1秒限制。")
    --     return
    -- end
    -- self.isChangeTableLockDown = true
    -- self:createSchedule("changeTableLockDown",function()
    --     self:stopSchedule("changeTableLockDown")
    --     self.isChangeTableLockDown = nil
    -- end,1)  
    self:PlayerCtrl_closeAddPanel()
    self:REQ_CHANGE_TABLE()
    LuaTools.beginWaiting(true)  
end




---------------------------- REQUESTS ------------------------------
local _ = 
[[
                    ██████╗ ███████╗ ██████╗ ██╗   ██╗███████╗███████╗████████╗███████╗                       
                    ██╔══██╗██╔════╝██╔═══██╗██║   ██║██╔════╝██╔════╝╚══██╔══╝██╔════╝                       
                    ██████╔╝█████╗  ██║   ██║██║   ██║█████╗  ███████╗   ██║   ███████╗                       
                    ██╔══██╗██╔══╝  ██║▄▄ ██║██║   ██║██╔══╝  ╚════██║   ██║   ╚════██║                       
                    ██║  ██║███████╗╚██████╔╝╚██████╔╝███████╗███████║   ██║   ███████║                       
                    ╚═╝  ╚═╝╚══════╝ ╚══▀▀═╝  ╚═════╝ ╚══════╝╚══════╝   ╚═╝   ╚══════╝                                   
                                                                                          
]]

function UIGameTableSanzhang:REQ_FRIENDREQUEST_RESULT(uid,res )  
    local bufferHnd = DataPacker.new(self.CMD['FRIEND_REQUEST_RESULT'])   
    bufferHnd:writeData(uid,DataPacker.INT) 
    bufferHnd:writeData(res,DataPacker.BYTE) 
    self.tcpGear:sendData(bufferHnd:doPack()) 
end

function UIGameTableSanzhang:REQ_FRIENDREQUEST(toUID )  
    local bufferHnd = DataPacker.new(self.CMD['FRIEND_REQUEST'])   
    bufferHnd:writeData(toUID,DataPacker.INT) 
    self.tcpGear:sendData(bufferHnd:doPack()) 
end


function UIGameTableSanzhang:REQ_SENDGIFT( playerUID,giftID ) 
    printf('UIGameTableSanzhang:REQ_SENDGIFT(  playerUID:%s,giftID:%s )',playerUID,giftID)
    local bufferHnd = DataPacker.new(self.CMD['SENDGIFT'],{protocalVersion = 1})   
    bufferHnd:writeData(playerUID,DataPacker.INT)
    bufferHnd:writeData(giftID,DataPacker.BYTE)
    local packed = bufferHnd:doPack()
    self.tcpGear:sendData(bufferHnd:doPack()) 
    printf('DONE UIGameTableSanzhang:REQ_SENDGIFT(  playerUID:%s,giftID:%s )',playerUID,giftID)
end

function UIGameTableSanzhang:REQ_CHAT(str)   
    local bufferHnd = DataPacker.new(UIGameTableSanzhang.CMD['CHAT'],{protocalVersion = 1})   
    bufferHnd:writeData(str,DataPacker.STRING)
    self.tcpGear:sendData(bufferHnd:doPack())
end


function UIGameTableSanzhang:REQ_EMOJI(id) 
    local bufferHnd = DataPacker.new(UIGameTableSanzhang.CMD['EMOJI'],{protocalVersion = 1})   
    bufferHnd:writeData(id,DataPacker.SHORT)
    self.tcpGear:sendData(bufferHnd:doPack())
end


function UIGameTableSanzhang:REQ_CONST_TEXT(id) 
    local bufferHnd = DataPacker.new(UIGameTableSanzhang.CMD['CONST_TEXT'],{protocalVersion = 1})   
    bufferHnd:writeData(id,DataPacker.SHORT)
    self.tcpGear:sendData(bufferHnd:doPack())
end


function UIGameTableSanzhang:REQ_TABLE_DISCONNECT() 
    local bufferHnd = DataPacker.new(self.CMD['TABLE_DISCONNECT'])   
    self.tcpGear:sendData(bufferHnd:doPack())
end


function UIGameTableSanzhang:REQ_KICK_PLAYER(uid) 
    local bufferHnd = DataPacker.new(UIGameTableSanzhang.CMD['KIKPLAYER'],{protocalVersion = 1})   
    bufferHnd:writeData(uid,DataPacker.INT)
    self.tcpGear:sendData(bufferHnd:doPack())
end

function UIGameTableSanzhang:REQ_SHOW_CARDS()
    local bufferHnd = DataPacker.new(UIGameTableSanzhang.CMD['PEEK_CARDS'],{protocalVersion = 1})  
    local buffer = bufferHnd:doPack() 
    self.tcpGear:sendData(buffer) 
end


function UIGameTableSanzhang:REQ_FOLLOW()
    local bufferHnd = DataPacker.new(UIGameTableSanzhang.CMD['FOLLOW_BET'],{protocalVersion = 1})  
    local buffer = bufferHnd:doPack() 
    self.tcpGear:sendData(buffer) 
end



function UIGameTableSanzhang:REQ_ADD(AMOUNT)
    local bufferHnd = DataPacker.new(UIGameTableSanzhang.CMD['ADD_BET'],{protocalVersion = 1})  
    bufferHnd:writeData(AMOUNT,DataPacker.LONG)
    local buffer = bufferHnd:doPack() 
    self.tcpGear:sendData(buffer) 
end



function UIGameTableSanzhang:REQ_DROP()
    local bufferHnd = DataPacker.new(UIGameTableSanzhang.CMD['DROP_CARDS'],{protocalVersion = 1})   
    local buffer = bufferHnd:doPack() 
    self.tcpGear:sendData(buffer) 
end



function UIGameTableSanzhang:REQ_ALLIN()  
    local bufferHnd = DataPacker.new(UIGameTableSanzhang.CMD['ALLIN'],{protocalVersion = 1})  
    local buffer = bufferHnd:doPack() 
    self.tcpGear:sendData(buffer) 
end




function UIGameTableSanzhang:REQ_COMPARE(seatID)  
    local bufferHnd = DataPacker.new(UIGameTableSanzhang.CMD['COMPARE_CARDS'],{protocalVersion = 1})  
    bufferHnd:writeData(seatID,DataPacker.BYTE)
    local buffer = bufferHnd:doPack() 
    self.tcpGear:sendData(buffer) 
end



function UIGameTableSanzhang:REQ_CHANGE_TABLE()  
    local bufferHnd = DataPacker.new(UIGameTableSanzhang.CMD['CHANGE_TABLE'],{protocalVersion = 1})  
    local buffer = bufferHnd:doPack() 
    self.tcpGear:sendData(buffer) 
end



function UIGameTableSanzhang:REQ_READY()  
    self['Button_readyup']:setEnabled(false)
    local bufferHnd = DataPacker.new(UIGameTableSanzhang.CMD['READY'],{protocalVersion = 1})  
    local buffer = bufferHnd:doPack() 
    self.tcpGear:sendData(buffer) 
end



function UIGameTableSanzhang:REQ_heartbeat()  
     if self.heartBeatBuffer == nil then 
        local bufferHnd = DataPacker.new(UIGameTableSanzhang.CMD['HEARTBEAT'],{protocalVersion = 1})
        self.heartBeatBuffer = bufferHnd:doPack()
     end
    print(' UIGameTableSanzhang:REQ_heartbeat() ')
    self.tcpGear:sendData(self.heartBeatBuffer) 
    -- self:REQ_SENDGIFT( 61434790,1 ) 
end

  
------------------------------------- DISPLAY FUNCTIONS----------------------------------------
local _ = 
[[ 
                                                                                                              
                    ██████╗ ██╗███████╗██████╗ ██╗      █████╗ ██╗   ██╗███████╗                              
                    ██╔══██╗██║██╔════╝██╔══██╗██║     ██╔══██╗╚██╗ ██╔╝██╔════╝                              
                    ██║  ██║██║███████╗██████╔╝██║     ███████║ ╚████╔╝ ███████╗                              
                    ██║  ██║██║╚════██║██╔═══╝ ██║     ██╔══██║  ╚██╔╝  ╚════██║                              
                    ██████╔╝██║███████║██║     ███████╗██║  ██║   ██║   ███████║                              
                    ╚═════╝ ╚═╝╚══════╝╚═╝     ╚══════╝╚═╝  ╚═╝   ╚═╝   ╚══════╝                              
                                                                                          
]]


 
function UIGameTableSanzhang:startCompare(argTable) 
    require("app.models.cardutl")
    self['ListView_buttonPanel']:setScrollBarEnabled(false)
    self:clearAllTimer()
    self:killCompareAnimation()
    self:setButtons({disableAll = true})
    self.isComparing = true
    -- if true then return end
    local _seatIDFrom                   = argTable.seatIDFrom
    local _seatIDTo                     = argTable.seatIDTo   
    local _isWon                         = argTable.isWon  
    local _onFinish                     =argTable.onFinishCallback
    local _displayIDFrom                = self.playerData[_seatIDFrom].displayID
    local _displayIDTo                  = self.playerData[_seatIDTo].displayID

    

    local _cardNodeIDFrom                = self.playerData[_seatIDFrom].displayedCards
    local _cardNodeIDTo                  = self.playerData[_seatIDTo].displayedCards

    local loseDisplayID = _displayIDFrom 
    local lostSeatID   = _seatIDFrom
    local loseCardsNode = _cardNodeIDFrom


    if _isWon == true then 
        loseDisplayID = _displayIDTo
        loseCardsNode = _cardNodeIDTo 
        lostSeatID   = _seatIDTo
    end

    self.lastCompareLostSeatID   = lostSeatID 

    self.lastCompareSeatIDFrom    = _seatIDFrom 
    self.lastCompareSeatIDTo   =   _seatIDTo   

    self.lastCompareOnFinishCallback   = argTable.onFinishCallback
    local winlossOriginalFromPos
    local winlossOriginalToPos
-- displayedCards

    if self.pkNode ~= nil then
        self.pkNode:removeFromParent()
        self.pkNode = nil
    end
    self.pkNode = cc.CSLoader:createNode('Animation_zjh_pk.csb') 
    -- local clonedCardNodeFrom = 

    local nodeLeft = cc.utils:findChildren(self.pkNode,'Node_left')[1]  
    local nodeRight = cc.utils:findChildren(self.pkNode,'Node_right')[1]  
  
    -- 1,4,5 are on the left side. 

    local function setOriginalVisible( seatID,visible )
        printf('setOriginalVisible:seatID:%s',seatID)
         if seatID == self.mySeatID then 
            self['Button_card_1']:setVisible(visible)
            self['Button_card_2']:setVisible(visible)
            self['Button_card_3']:setVisible(visible)
         else
            self.playerData[seatID].displayedCards:setVisible(visible)
         end
    end

    local function createClonedTable(seatID,cardsNode,outOriginalPos)
        local ret = {}
        if seatID == self.mySeatID then 
            for i=1,3 do
                local worldPos = self['Button_card_'..i]:convertToWorldSpaceAR(cc.p(0,0))
                local spriteNode = cc.Sprite:createWithSpriteFrameName(Cardutl.getPathForCard( self['Button_card_'..i].val,nil,nil,"Douniu" ))
                spriteNode:setPositionX(worldPos.x) 
                spriteNode:setPositionY(worldPos.y) 
    
                spriteNode:setScale(self['Button_card_'..i]:getScale()) 
                spriteNode.originalScale = spriteNode:getScale()
                spriteNode.originalPos = cc.p(spriteNode:getPosition())
                if i ==2 then
                    outOriginalPos = spriteNode.originalPos
                end
                self:addChild(spriteNode,2000,2000)
                table.insert(ret,spriteNode)
            end
        else
            for i=1,3 do
                local cardNode = cardsNode:getChildByTag(i)
                local worldPos = cardNode:convertToWorldSpaceAR(cc.p(0,0))
                local val = self.playerData[seatID].Cards[i]
                local spriteNode = cc.Sprite:createWithSpriteFrameName(Cardutl.getPathForCard(val,nil,nil,"Douniu" ))
                spriteNode:setPositionX(worldPos.x)
                spriteNode:setPositionY(worldPos.y)
    
                spriteNode:setAnchorPoint(cardNode:getAnchorPoint()) 
 
                spriteNode:setScale(cardsNode:getScale()) 
                spriteNode.originalScale = spriteNode:getScale()
                spriteNode.originalPos = cc.p(spriteNode:getPosition())
                if i ==2 then
                    outOriginalPos = spriteNode.originalPos
                end

                self:addChild(spriteNode,2000,2000)
                table.insert(ret,spriteNode)
            end
        end
        return ret
    end



    local clonedCardNodeFromTable   = createClonedTable(_seatIDFrom     ,_cardNodeIDFrom ,winlossOriginalFromPos   )
    local clonedCardNodeToTable     = createClonedTable(_seatIDTo       ,_cardNodeIDTo  , winlossOriginalToPos    ) 
    self.clonedCardNodeAnimationTable = self.clonedCardNodeAnimationTable or {}
    table.insert(self.clonedCardNodeAnimationTable,clonedCardNodeFromTable)
    table.insert(self.clonedCardNodeAnimationTable,clonedCardNodeToTable)
    setOriginalVisible( _seatIDFrom ,   false )  
    setOriginalVisible( _seatIDTo   ,   false )  

    local fromPos = nodeLeft:convertToWorldSpaceAR(cc.p(display.cx,display.cy))
    local toPos = nodeRight:convertToWorldSpaceAR(cc.p(display.cx,display.cy))
    if _displayIDFrom ==  2 or _displayIDFrom == 3  then
        fromPos,toPos = toPos,fromPos
    end
     


    --from animation.
    local moveTime = 0.8
    local animDelayTime = moveTime
    local scale = 0.5
    -- printf("from:(%.2f,%.2f),to(%.2f,%.2f)",fromPos.x,fromPos.y,toPos.x,toPos.y)
    local function createStartAnimation(tbl,pos)
        for i=1,#tbl do
            local node = tbl[i]
            local scl = cc.EaseExponentialOut:create(cc.ScaleTo:create(moveTime,1.1))
            local scldown = cc.ScaleTo:create(moveTime*0.1,scale)--cc.EaseExponentialOut:create(cc.ScaleTo:create(moveTime*0.1,scale))
            local moveToX,moveToY = pos.x,pos.y
            -- printf('node:getContentSize().width:%s,node:getScale():%s',node:getContentSize().width,node:getScale() )
            moveToX = ( moveToX + (i-2) * node:getContentSize().width * 0.5 * scale )
            local mvtb = cc.MoveBy:create(0.01, cc.p(-10,-10))
            local mvt = cc.MoveTo:create(moveTime * 0.1, cc.p(moveToX,moveToY))--cc.EaseExponentialOut:create(cc.MoveTo:create(moveTime * 0.5, cc.p(moveToX,moveToY)))
            node:stopAllActions()--[[c.DelayTime:create(i*0.1),cc.DelayTime:create(i*0.1),]]
            node:runAction(cc.Sequence:create(scl, mvtb,  cc.Spawn:create(mvt,scldown),cc.CallFunc:create(function()
                LuaTools.vibrateScreen( 0.2,5)
            end))) 
        end
    end
    createStartAnimation(clonedCardNodeFromTable,fromPos)
    createStartAnimation(clonedCardNodeToTable,toPos)
    
    local function createWinLoseAnimation(pos)
        if self.losewonTbl == nil then
            self.losewonTbl = {}
        end
        local path = 'Animation_zjh_pk_lose.csb'  
        local animNode = cc.CSLoader:createNode(path)
        animNode:setVisible(false)
        table.insert(self.losewonTbl,animNode)
        self:createSchedule("winloseDelay",function()
            self:stopSchedule('winloseDelay')
            printf("winloseDelay ")
            local act = cc.CSLoader:createTimeline(path)
            animNode:runAction(act) 
            animNode:setVisible(true)
            act:gotoFrameAndPlay(0,false)
        end,0.1)
        animNode:runAction(cc.Sequence:create(cc.DelayTime:create(1),cc.CallFunc:create(function ()
            animNode:setVisible(false)
        end)))
        self:addChild(animNode,2010)
        animNode:setPosition(pos)

    end

    local function  createRestoreAnimation(tbl,winloseNode)
        printf('createRestoreAnimation')
         for i=1,#tbl do
            local node = tbl[i]
            -- node.originalScale
            -- node.originalPos =
 
            local scldown = cc.EaseExponentialOut:create(cc.ScaleTo:create(0.5,node.originalScale)) 
            local mvt = cc.EaseExponentialOut:create(cc.MoveTo:create(moveTime, node.originalPos))
            node:stopAllActions()
            node:runAction(cc.Sequence:create(cc.DelayTime:create(i*0.1), cc.Spawn:create(mvt,scldown))) 

            printf('winloseNode:%s',winloseNode)
            if i == 2 and winloseNode then
                winloseNode:stopAllActions()   
                local scldown = cc.EaseExponentialOut:create(cc.ScaleTo:create(0.5,0.5))  
                local posX = node.originalPos.x - node:getBoundingBox().width * node:getAnchorPoint().x + node:getBoundingBox().width *0.5
                local posY = node.originalPos.y - node:getBoundingBox().height * node:getAnchorPoint().y + node:getBoundingBox().height *0.5
                local mvtt = cc.EaseExponentialOut:create(cc.MoveTo:create(moveTime, cc.p(posX,posY)))
                local dly  = cc.DelayTime:create(0.01)
                local fadeOut = cc.FadeOut:create(0.5) 
                winloseNode:runAction(cc.Sequence:create(cc.DelayTime:create(i*0.1),cc.Spawn:create(mvtt,scldown),dly,fadeOut,cc.CallFunc:create(
                    function() 
                        printf("winloseNode Image_lose")
                        self['Panel_player_'..loseDisplayID]:getChildByName('Image_lose'):setVisible(true) 
                        for i=1,3 do 
                            local tint = cc.TintTo:create(0.5,UIGameTableSanzhang.DROP_COLOR)
                            local n = loseCardsNode:getChildByTag(i)
                            n:runAction(tint)
                        end 
                        -- 
                    end)))
            end
        end
    end
    
    -- printf("_isWon:%s",_isWon)
    self.pkNode:setVisible(false)
    self:createSchedule("pkAnim",function() 
        self:stopSchedule('pkAnim') 
        printf("pkAnim")
        audio.playSound(Sound.SoundTable['sfx']['Cmp_light'] , false)
        self.pkNode:setVisible(true)
        self.pkNode:setPosition(cc.p(display.cx,display.cy))
        local action = cc.CSLoader:createTimeline('Animation_zjh_pk.csb')
        self.pkNode._act = action
        self.pkNode:runAction(action)
        action:gotoFrameAndPlay(0,false)
        action:setFrameEventCallFunc(function(frame)
            local str = frame:getEvent()
            if str == 'onResult' then
                printf("onResult")
                local winPos = fromPos
                if _isWon == true then  
                   winPos = toPos
                end
                createWinLoseAnimation(winPos)
                -- createWinLoseAnimation(not _isWon,losePos)
            elseif str == 'onFinish' then
                printf("onFinish")
                if _isWon then  
                    createRestoreAnimation(clonedCardNodeFromTable)
                    createRestoreAnimation(clonedCardNodeToTable,self.losewonTbl[#self.losewonTbl])
                else
                    createRestoreAnimation(clonedCardNodeFromTable,self.losewonTbl[#self.losewonTbl])
                    createRestoreAnimation(clonedCardNodeToTable)
                end
                
                self:createSchedule('finishPKAnim',function()
                    self:stopSchedule('finishPKAnim')
                    printf("finishPKAnim")
                    self.isComparing = nil
                    if _onFinish then
                        _onFinish()
                        self.lastCompareLostSeatID    = nil
                        self.lastCompareOnFinishCallback = nil 
                        self.lastCompareSeatIDFrom = nil
                        self.lastCompareSeatIDTo   = nil 
                    end
                    setOriginalVisible( _seatIDFrom ,   true )  
                    setOriginalVisible( _seatIDTo   ,   true )  
                    self.pkNode:removeFromParent()  
                    self.pkNode = nil
                    for k,v in pairs(clonedCardNodeFromTable) do
                        v:removeFromParent()
                    end 
                    for k,v in pairs(clonedCardNodeToTable) do
                        v:removeFromParent()
                    end

                end,1)
            end
    
        end)


    end,animDelayTime)

    



    
    self:addChild(self.pkNode) 
    



    -- action:setLastFrameCallFunc(function()
    --     if self.pkNode ~= nil then
    --         self.pkNode:removeFromParent()
    --         self.pkNode = nil
    --     end
    -- end) 
    -- body
end


function UIGameTableSanzhang:showComp(hide)
    for k,v in pairs(self.playerData) do
        if v.isSat and v.isDrop ~= true and v.seatID ~= self.mySeatID then 
            self['Panel_player_'..v.displayID]:getChildByName('Button_compblah'):setVisible((hide == nil)) 
        end
    end
    -- body
end
function UIGameTableSanzhang:generateAdditionButton( additionTable )
    if self.additionButtonBaseNode then
        self.additionButtonBaseNode:removeFromParent()
        self.additionButtonBaseNode = nil
    end
    self['Image_addPanel']:setVisible(true)
    self.additionButtonBaseNode = cc.Menu:create()
    self.additionButtonBaseNode:setPosition(0,0)
    self['Image_addPanel']:getChildByName('Node_center'):addChild(self.additionButtonBaseNode)
    for k,v in ipairs(additionTable) do
        local spriteNormal = cc.Sprite:createWithSpriteFrameName(v.img)
        -- local spriteDisabled = cc.Sprite:createWithSpriteFrameName("zjh/btn4.png")
        local item1 = cc.MenuItemSprite:create(spriteNormal, spriteNormal, spriteNormal)
        -- local label = cc.LabelTTF:create(v.v, "Marker Felt", 36)
        -- local size = spriteNormal:getContentSize()
        -- label:setPosition(cc.p(size.width * 0.5, size.height * 0.5))
        -- item1:addChild(label)

        local function menuCallback(sender) 
            self:REQ_ADD(v.k)
            self.additionButtonBaseNode:setVisible(false)
            self['Image_addPanel']:setVisible(false)
            self['Button_add']:setEnabled(false)   
            audio.playSound(Sound.SoundTable['sfx']['Chip_add'], false) 
        end
        if v.k <= self.CurrentBet then
            item1:setEnabled(false)
            item1:setColor(cc.c3b(80,80,80))
        end
        item1:registerScriptTapHandler(menuCallback)
        self.additionButtonBaseNode:addChild(item1)
    end



    --  local spriteNormal = cc.Sprite:createWithSpriteFrameName("zjh/x.png") 
    -- local item1 = cc.MenuItemSprite:create(spriteNormal, spriteNormal, spriteNormal)
    self.additionButtonBaseNode:alignItemsHorizontallyWithPadding(30)
    -- -- local label = cc.LabelTTF:create('关闭', "Marker Felt", 36)
    -- -- local size = spriteNormal:getContentSize()
    -- -- label:setPosition(cc.p(size.width * 0.5, size.height * 0.5))
    -- -- item1:addChild(label)

    -- local function menuCallback(sender) 
    --    if self.additionButtonBaseNode then
    --         self.additionButtonBaseNode:removeFromParent()
    --         self.additionButtonBaseNode = nil
    --     end 
    -- end
    -- item1:registerScriptTapHandler(menuCallback)
    -- self.additionButtonBaseNode:addChild(item1)




end

function UIGameTableSanzhang:generateAdditionChipTable(min,max)
    self.additionTable = {}
    -- for k,v in pairs(UIGameTableSanzhang.chipAmountTable) do
    --     if v.val >= min and v.val <= max then 
    --         local t = 
    --         {
    --             v = v.str,
    --             img = v.img,
    --             k = v.val
    --         }
    --         table.insert(self.additionTable,t)
    --     end
    -- end

    local tempNum = 1 
    for k=#UIGameTableSanzhang.chipAmountTable ,1,-1 do
        local v = UIGameTableSanzhang.chipAmountTable[k]
        if v.val >= min and v.val <= max and tempNum <=5 then 
            local t = 
            {
                v = v.str,
                img = v.img,
                k = v.val
            }
            table.insert(self.additionTable,t)  
            tempNum = tempNum + 1 
        end
    end  

    local function srt(a,b)
        return a.k < b.k
    end
    table.sort(self.additionTable,srt)
    -- dump( self.additionTable," self.additionTable")
end

function UIGameTableSanzhang:setPlayerChip( seatID,amount )
    -- Image_chipBG
    -- body

    if self.playerData[seatID] then 
         local node = self['Panel_player_'..self.playerData[seatID].displayID]
         local textBGNode = node:getChildByName('Image_chipBG')
         local textNode = textBGNode:getChildByName('Text_chipnum')
         textBGNode:setVisible(true)
         if amount == nil then  
            textBGNode:setVisible(false)
            return
         end
         textNode:setString(LuaTools.convertAmountChinese(amount,10000))
    end

end

function UIGameTableSanzhang:clearAllTimer()
    -- body
    for k,v in pairs(self.playerData) do
        local node = self['Panel_player_'..v.displayID]
        if node.timerNode then
            node.timerNode:removeFromParent()
            node.timerNode = nil
        end
    end
end

function UIGameTableSanzhang:setSpotlight( seatID )
    -- body
    local player = self.playerData[seatID]
    for k,player in pairs(self.playerData) do
        if player.spotLens then 
            self.playerData[k].spotLens:removeFromParent()
            self.playerData[k].spotLens = nil 
        end
    end
    if player then 
        local rotateTime = 1
        local node = self['Panel_player_'..player.displayID]
        if self['spotLight'] == nil then 
            self['spotLight'] = cc.Sprite:createWithSpriteFrameName('tableresult/spotLight.png')
            self['Panel_tales']:addChild(self['spotLight'])
            self['Image_addPanel']:setLocalZOrder(101) 
            self['spotLight']:setLocalZOrder(98)
            self['spotLight']:setAnchorPoint(cc.p(0.5,0))
            self['spotLight']:setPosition(display.center) 
        end
        self['spotLight']:stopAllActions()
        local to = node:getChildByName('Image_avatar'):convertToWorldSpaceAR(cc.p(0,0))
        local angle = LuaTools.Lookat(display.center,to)
        local act =  cc.EaseExponentialOut:create(cc.RotateTo:create(rotateTime,angle))
        self['spotLight']:runAction(act)

        self.playerData[seatID].spotLens = cc.Sprite:createWithSpriteFrameName('tableresult/spotLightLens.png') 
        local lensPos = cc.p(node:getChildByName('Image_avatar'):getContentSize().width/2,node:getChildByName('Image_avatar'):getContentSize().height/2)
        self.playerData[seatID].spotLens:setPosition(lensPos)
        node:getChildByName('Image_avatar'):addChild(self.playerData[seatID].spotLens)
        self.playerData[seatID].spotLens:setOpacity(0)
        self.playerData[seatID].spotLens:runAction(cc.EaseExponentialOut:create(cc.FadeTo:create(rotateTime,255)))
       
    end
end

function UIGameTableSanzhang:setTimer( seatID,time,imm )
    -- body
    -- printf('UIGameTableSanzhang:setTimer imm:%s',imm)
    self:clearAllTimer()
    time = time or self.loginData.betTimeout
     if self.playerData[seatID] then 
        local node = self['Panel_player_'..self.playerData[seatID].displayID]
        if node.timerNode then
            node.timerNode:removeFromParent()
            node.timerNode = nil
        end
        local delay = 0.1
        if imm == true then 
            delay = 0
        end
        self:stopSchedule('spotLightDelay')
        self:createSchedule('spotLightDelay',function (  )
            self:stopSchedule('spotLightDelay')
            self:setSpotlight( seatID )
            -- body
        end,delay)
        node.timerNode = cc.ProgressTimer:create(cc.Sprite:createWithSpriteFrameName("zjh/cd.png")) 
        node.timerNode:setColor(cc.c3b(0,255,0))
        node.timerNode:setPercentage(100)
        node.timerNode:setScaleX(-1)
        -- node.timerNode:setPosition(cc.p(node:getChildByName('Image_avatar'):getContentSize().width/2,node:getChildByName('Image_avatar'):getContentSize().height/2))
        node.timerNode:setPosition(cc.p(node:getChildByName('Image_avatar'):getPositionX(),node:getChildByName('Image_avatar'):getPositionY()))
        node.timerNode:setType(cc.PROGRESS_TIMER_TYPE_RADIAL)
        local act = cc.Spawn:create(cc.ProgressTo:create(time, 0),cc.TintTo:create(time*0.5,cc.c3b(255,0,0)))
        node.timerNode:runAction(cc.ProgressTo:create(time, 0))

        self:stopSchedule("timer_"..seatID)
        self:createSchedule("timer_"..seatID,function()
                self:stopSchedule("timer_"..seatID)
                if node.timerNode then
                    node.timerNode:removeFromParent()
                    node.timerNode = nil
                end
            end,
            time)
        node:getChildByName('Image_avatar'):getParent():addChild(node.timerNode)
    end 

end

function UIGameTableSanzhang:killCompareAnimation(clearAll)


    printf('UIGameTableSanzhang:killCompareAnimation(%s)',clearAll)
    self:stopSchedule('finishPKAnim')
    self:stopSchedule('winloseDelay')
    self:stopSchedule('pkAnim')
    self.isComparing = nil
    for _,cardTbl in pairs(self.clonedCardNodeAnimationTable or {}) do
        if cardTbl then
            for _,v in pairs(cardTbl or {}) do
                if tolua.isnull(v) == false then 
                    v:removeFromParent()
                end
            end
        end
    end 
    self.clonedCardNodeAnimationTable = {}

    for k,v in pairs(self.losewonTbl or {}) do
        if tolua.isnull(v) == false then 
            v:removeFromParent()
        end
    end

    printf('self.pkNode: isnull:%s',tolua.isnull(self.pkNode))
    if  self.pkNode ~= nil and tolua.isnull(self.pkNode) == false then  
        self.pkNode:removeFromParent()
        self.pkNode = nil
    end


    if clearAll == true then --clear all
        printf('cleaning...')
        self['Button_card_1']:setVisible(false)
        self['Button_card_2']:setVisible(false)
        self['Button_card_3']:setVisible(false)
        for i=1,5 do
            if self.playerData[i] then 
                if  self.playerData[i].displayedCards  then 
                    -- self.playerData[i].displayedCards:setVisible(false)
                    self.playerData[i].displayedCards:removeFromParent()
                    self.playerData[i].displayedCards=nil   
                end
                local displayID = self.playerData[i].displayID
                self['Panel_player_'..displayID]:getChildByName('Image_lose'):setVisible(false) 
            end
        end

    
    else-- fast foward.
         
        printf('fast foward.')
        printf('checking self.lastCompareOnFinishCallback... (%s)',self.lastCompareOnFinishCallback)
        if self.lastCompareOnFinishCallback then  
            printf('calling self.lastCompareOnFinishCallback.')
            self.lastCompareOnFinishCallback()
            self.lastCompareOnFinishCallback = nil
        end

        --lost action ff

        printf('checking self.lastCompareLostSeatID... (%s)',self.lastCompareLostSeatID)
        if self.lastCompareLostSeatID and self.playerData[self.lastCompareLostSeatID] then   
            local displayID = self.playerData[self.lastCompareLostSeatID].displayID
            self['Panel_player_'..displayID]:getChildByName('Image_lose'):setVisible(true) 
            if self.lastCompareLostSeatID == self.mySeatID then 
                self['Button_card_1']:setColor(UIGameTableSanzhang.DROP_COLOR)
                self['Button_card_2']:setColor(UIGameTableSanzhang.DROP_COLOR)
                self['Button_card_3']:setColor(UIGameTableSanzhang.DROP_COLOR)
            else 
                if  self.playerData[self.lastCompareLostSeatID].displayedCards then 
                    self.playerData[self.lastCompareLostSeatID].displayedCards:setColor(UIGameTableSanzhang.DROP_COLOR)  
                end
            end  
        end

        --FF from seat id stuff
        printf('checking self.lastCompareSeatIDFrom... (%s)',self.lastCompareSeatIDFrom)
        if self.lastCompareSeatIDFrom and self.playerData[self.lastCompareSeatIDFrom] then   
            local displayID = self.playerData[self.lastCompareSeatIDFrom].displayID 
            if self.lastCompareSeatIDFrom == self.mySeatID then 
                self['Button_card_1']:setVisible(true)
                self['Button_card_2']:setVisible(true)
                self['Button_card_3']:setVisible(true)
            else 
                if  self.playerData[self.lastCompareSeatIDFrom].displayedCards then 
                    self.playerData[self.lastCompareSeatIDFrom].displayedCards:setVisible(true) 
                end 
            end  
        end

        --ff to seat id stuff
        printf('checking self.lastCompareSeatIDTo... (%s)',self.lastCompareSeatIDTo)
        if self.lastCompareSeatIDTo and self.playerData[self.lastCompareSeatIDTo] then   
            local displayID = self.playerData[self.lastCompareSeatIDTo].displayID 
            if self.lastCompareSeatIDTo == self.mySeatID then 
                self['Button_card_1']:setVisible(true)
                self['Button_card_2']:setVisible(true)
                self['Button_card_3']:setVisible(true)
            else 
                if  self.playerData[self.lastCompareSeatIDTo].displayedCards then 
                    self.playerData[self.lastCompareSeatIDTo].displayedCards:setVisible(true) 
                end 
            end  
        end  
    end 
end

function UIGameTableSanzhang:setPlayerStatus(seatID,status)
    -- printError("")
    -- printf("setPlayerStatus==>>  seatID:%s,status:%s,self.playerData[seatID]:%s",seatID,status,self.playerData[seatID])
    -- dump(self.playerData[seatID])
    if self.playerData[seatID] then
        self.playerData[seatID].PlayerState = status
        local display =self.playerData[seatID].displayID
        self['Panel_player_'..display]:getChildByName('Image_chipBG'):setVisible(false)  
        if status >= UIGameTableSanzhang.Config['PlayerStateWaitBet'] then
            self['Panel_player_'..display]:getChildByName('Image_chipBG'):setVisible(true)  
            self.playerData[seatID].isSat = true
            if seatID == self.mySeatID then 
                self.iTookPart = true 
            end
        end

        if status == UIGameTableSanzhang.Config['PlayerStateGiveUp'] then
            self.playerData[seatID].isDrop = true
            if seatID == self.mySeatID then 
                self.iTookPart = true 
            end
        end

        
        local node = self['Image_status_'..self.playerData[seatID].displayID]
        printf("node:%s",node)
        if seatID == self.mySeatID and status <= 1 then
            self['Button_readyup']:setVisible(true)
            self['Button_changeTable']:setVisible(true)
            self['Button_readyup']:setEnabled(true)
            if self.readyMoneyTag then 
               self['Button_changeTable']:setEnabled(self.PlayerData.coin>=self.readyMoneyTag)
            end 
        end
        if node then
            node:setVisible(false)
        end 
        if status == 1 then 
            -- self:clearPlayerPanel( seatID ) 
            if node then
                node:setVisible(true)
                node:loadTexture("room/RoomPlayerSatus_1_ex.png",ccui.TextureResType.plistType) 
            end 
            if seatID == self.mySeatID then
                self['Button_readyup']:setEnabled(false)
            end
        elseif status == 2 then
        
        end  
    end
end

-- @param: status       
-- @param: isFirstCaller
-- @param: canCompare   
-- @param: watchedCard  
-- @param: allined      
-- @param: disableAll   

 function UIGameTableSanzhang:automodeCalback()
    self['Panel_autoMode']:setVisible(true)
 end

function UIGameTableSanzhang:chatCallback(arg)
    dump(arg,'UIGameTableSanzhang:chatCallback(arg)')
end

function UIGameTableSanzhang:setButtons(argTable)

    self.tool = self:getApp():getModel('Tools')
    
    -- printError('fuck me')
    argTable = argTable or {}
    local _playerData       = self.playerData[self.mySeatID]       or  {}
    local _status           = argTable.status           or  _playerData.PlayerState                             or 0
    -- local _isFirstCaller    = argTable.isFirstCaller    or  (self.IsFirstPlaying == 1)                          or false 
    local _canCompare       = argTable.canCompare       or   (self.WheelCount >= self.loginData.minRound and self:getNumberOfPlayerStillPlaying() >= 2 )                or false 
    local _watchedCard      = argTable.watchedCard      or   ( _playerData.IsLookCard == 1)                              or false 
    local _allined          = argTable.allined          or   _playerData.allined                                or false 
    local _disableAll       = argTable.disableAll       or  false 

    printf('setButtons ==> self.iTookPart:%s,self.currentRoomState:%s', self.iTookPart,self.currentRoomState)
    if self.iTookPart == false and self.currentRoomState >  UIGameTableSanzhang.Config['JINNIU_ROOM_STATE_WAIT'] then    
        self["Button_readyup"]:setVisible(true) 
        self["Button_readyup"]:setEnabled(false)
        self["Button_changeTable"]:setVisible(true) 
        if self.readyMoneyTag then 
           self['Button_changeTable']:setEnabled(self.PlayerData.coin>=self.readyMoneyTag)
        end 
        GameTableCommon.setStaticMsg(self, '观战中，请等待下局开始...' )
        self:setPlayerChip( self.mySeatID )

    end
    if _playerData.isSat ~= true or _playerData.isDrop then 
        self['ListView_buttonPanel']:setVisible(false)
        return
    end
    if self.iTookPart == true then 
        self["Button_readyup"]:setVisible(false) 
        self["Button_readyup"]:setEnabled(true)
        self["Button_changeTable"]:setVisible(false) 
    end


    self['Button_allin']:setEnabled(true)
    self['Button_follow']:setEnabled(true)
    self['Button_add']:setEnabled(true)
    self['Button_show']:setEnabled(true)
    self['Button_comp']:setEnabled(true)
    self['Button_drop']:setEnabled(true)
    self['Image_addPanel']:setVisible(false)

    if _disableAll == true then
        self['Button_allin']:setEnabled(false)
        self['Button_follow']:setEnabled(false)
        self['Button_add']:setEnabled(false)
        self['Button_show']:setEnabled(false)
        self['Button_comp']:setEnabled(false)
        self['Button_drop']:setEnabled(false) 
        return
    end 

    -- printf('setButtons:%s',_status)
    if _status == UIGameTableSanzhang.Config['PlayerStateWaitBet'] then
        self['ListView_buttonPanel']:setVisible(true)
        self['Button_allin']:setEnabled(false)
        self['Button_follow']:setEnabled(false)
        self['Button_add']:setEnabled(false) 
        self['Button_comp']:setEnabled(false) 
    elseif _status == UIGameTableSanzhang.Config['PlayerStateBetOn'] then --it my turn! 
        self['ListView_buttonPanel']:setVisible(true) 
        self['Button_comp']:setEnabled(false) 
    else 
        self['ListView_buttonPanel']:setVisible(false)
    end

    -- printf('_isFirstCaller:%s',(self.IsFirstPlaying == 1))
    if (self.IsFirstPlaying == 1) then
        self['Button_show']:setEnabled(false)
        self['Button_drop']:setEnabled(false)
    end

    -- printf("_canCompare:%s",_canCompare)
    -- printf("self.WheelCount:%s  self.loginData.minRound:%s  self:getNumberOfPlayerStillPlaying():%s",
        -- self.WheelCount,self.loginData.minRound, self:getNumberOfPlayerStillPlaying())
    if _canCompare == true and _status == UIGameTableSanzhang.Config['PlayerStateBetOn']  then
--        if not self.isShowTipCompare then
--            self['Panel_tip']:setVisible(true)
--            local  movSpeed = 0.5
--            local  tgtPos = self['Text_currentPool_bg']:getParent():convertToWorldSpace(cc.p(self["Panel_tip"]:getPosition()))
--            local mov = cc.MoveTo:create(movSpeed,cc.p(tgtPos.x,tgtPos.y-45))
--            local movReback = cc.MoveTo:create(0.5,cc.p(tgtPos.x,tgtPos.y))
--            local act = cc.Sequence:create(cc.Show:create(),mov,cc.DelayTime:create(2),movReback)
--            self['Panel_tip']:runAction(act)
--            self['Panel_tip']:setVisible(false)
--            self.isShowTipCompare = true
--        end

        self['Button_comp']:setEnabled(true)
    end

    if _watchedCard == true then 
        self['Button_show']:setEnabled(false)
    end
    -- printf('_allined:%s,self.mySeatID:%s,_playerData.seatID:%s',_allined , self.mySeatID , _playerData.seatID)
    if (_allined == true and self.mySeatID == _playerData.seatID) or self:getNumberOfPlayerStillPlaying() > 2  then 
        self['Button_allin']:setEnabled(false)
    end


    printf('self.CurrentBet:%s,self.allined :%s',self.CurrentBet,self.allined )
    if self.CurrentBet >= self.loginData.maxBet then 
        self['Button_add']:setEnabled(false) 
    end

    if self.allined == true then 
        self['Button_add']:setEnabled(false) 
        self['Button_follow']:setEnabled(false) 
        self['Button_comp']:setEnabled(false) 
    end

    if self.tableType == 65 then 
        self['Button_show']:setEnabled(false)
    end

    -- self.accumulatedAutoround


     -- CurrentBet



end

 
function UIGameTableSanzhang:quitComfirm()
    -- body 
    local d = G_BASEAPP:addView('UIDialog', 65530)
    d:setupDialog('', '是否确定退出房间？', 
    function()   
        self:quitTable()
    end) 

end
 
 
function UIGameTableSanzhang:quitTable()
        -- self.Broadcast:removeSelf()
        local bufferHnd = DataPacker.new(UIGameTableSanzhang.CMD['TABLE_DISCONNECT'],{protocalVersion = 1})   
        self.tcpGear:sendData(bufferHnd:doPack()) 
        self.tcpGear:closeAndRelease() 
        self:removeSelf()
end



function UIGameTableSanzhang:getLoginBuffer(tableType,friendID,RoomId) 
    local bufferHnd = DataPacker.new(UIGameTableSanzhang.CMD['TABLE_LOGIN'],{protocalVersion = 1})
    bufferHnd:writeData(G_UID,DataPacker.INT)
    bufferHnd:writeData(G_TOKEN,DataPacker.STRING)
    bufferHnd:writeData(tableType,DataPacker.BYTE)
    bufferHnd:writeData(friendID,DataPacker.INT)
    bufferHnd:writeData(RoomId,DataPacker.INT)
    return bufferHnd:doPack()
end


function UIGameTableSanzhang:showMsgByMsgType(msgType,msg)
    LuaTools.stopWaiting()
    local blah = ""..cc.Director:getInstance():getTotalFrames()
    if msgType == UIGameTableSanzhang.TIP_NORMAL_PLAYER_TOAST then
        G_BASEAPP:addView({
           uiName =  'UIAlert',
           uiInstanceName = blah
            },1000)
        :setupDialog('Infomation',msg)
    else
        local b = G_BASEAPP:addView({
           uiName =  'UIDialog',
           uiInstanceName = blah
            }, 200)
        local func = nil
        if msgType == UIGameTableSanzhang.TIP_NORMAL_PLAYER_CloseConn 
            or msgType == UIGameTableSanzhang.TIP_NORMAL_READY_COIN_NO_ENOUGH then
            func = function()
                self:quitTable()
            end 
        end 

        b:setupDialog("信息",msg,func,func)  
    end
end


 function UIGameTableSanzhang:getPlayerByUid( uid )
    return GameTableCommon.getPlayerByUid(self, uid )
    -- for k,v in pairs(self.playerData) do
    --     if v.Uid == uid then
    --         return v 
    --     end
    -- end
 end

function UIGameTableSanzhang:generateChipTableByAmount( _amount,dontCheckMax )
    local amount = _amount   
    local ret = {}
    while amount > 0 do 
        local i = #UIGameTableSanzhang.chipAmountTable
        while i >= 1 do
        -- for i = #UIGameTableSanzhang.chipAmountTable,1,-1 do
            local v = UIGameTableSanzhang.chipAmountTable[i]
            -- print('i:',i,'amount:',amount,'entered for,v.val:',v.val,'self.loginData.minBet:',self.loginData.minBet)
            if v.val <= amount and (dontCheckMax == true or v.val <= self.minBet )then
                -- print("chosen val:",v.val)
                table.insert(ret,v)
                amount=amount-v.val    
                i=i+1
            end
            i=i-1
        end
    end
    return ret

end

function UIGameTableSanzhang:gatherChipsToSeatID(displayID, seatID,finishCallback )
    local moveTotalTime = 0.5
    local len = #self.thrownChips
    local moveSpeed = 0.3 
    -- cc.CallFunc:create(callback2)

    for k,v in pairs(self.thrownChips) do
        local worldPos = self['Panel_player_'..displayID]:getChildByName("Image_avatar"):convertToWorldSpaceAR(cc.p(0,0))
        local tgtPosX =  worldPos.x--self['Panel_player_'..displayID]:getPositionX()  +  math.random(1, self['Panel_chipArea']:getContentSize().width*0.3) 
        local tgtPosY =  worldPos.y--self['Panel_player_'..displayID]:getPositionY()  +  math.random(1, self['Panel_chipArea']:getContentSize().height*0.3)
       
        v:stopAllActions()
        local mov = cc.MoveTo:create(moveSpeed,cc.p(tgtPosX,tgtPosY))
        local ease = cc.EaseExponentialOut:create(mov)
        local scl =  cc.FadeTo:create(moveSpeed * 0.8,0) --cc.ScaleBy:create(moveSpeed * 0.5,0.001) 
        scl = cc.EaseExponentialOut:create(scl)
        local func = cc.CallFunc:create(function()
            v:setVisible(false)
            if k == len and finishCallback then
                finishCallback()
            end 
        end)
        local spwn = cc.Spawn:create(ease,scl)
        v:runAction(cc.Sequence:create(cc.DelayTime:create(k*(moveTotalTime / len)),spwn,func))
    end
end

function UIGameTableSanzhang:throwChips( seatID,_amount ,isFast,dontCheckMax)


    -- audio.playSound(Sound.SoundTable['sfx']['Chip_in'], false)
    local displayID = self.playerData[seatID].displayID
    if self.thrownChips == nil then
        self.thrownChips = {}
    end
    local moveSpeed = 1
    local easeRate = 0.2
    local amounts
    if self.allined == true then
        amounts = {
            {
                img = 'zjh/allinChip.png'
            }
        }
        printf('throwChips ALL IN!!!')
    else

        amounts = self:generateChipTableByAmount( _amount,dontCheckMax ) 
    end

    local scaleToFactor = 0.57--0.7
    -- dump(amounts,"amounts")
    for k,v in pairs(amounts) do
        -- printf('loading image:%s',v.img)
        local chipNode = cc.Sprite:createWithSpriteFrameName(v.img)
        table.insert(self.thrownChips,chipNode)
        local posX = self['Panel_player_'..displayID]:getPositionX() + self['Panel_player_'..displayID]:getContentSize().width * 0.5
        local posY = self['Panel_player_'..displayID]:getPositionY()
        self['Panel_chipLayer']:addChild(chipNode)
        chipNode:setVisible(false)
        chipNode:setScale(scaleToFactor)
        chipNode:setPosition(cc.p(posX+ math.random(-25,25),posY + math.random(-25,25)))
        local tgtPosX =  self['Panel_chipArea']:getPositionX()+  math.random(1, self['Panel_chipArea']:getContentSize().width) 
        local tgtPosY =  self['Panel_chipArea']:getPositionY()+  math.random(1, self['Panel_chipArea']:getContentSize().height)
        if isFast then
            chipNode:setVisible(true)
            chipNode:setPosition(cc.p(tgtPosX,tgtPosY)) 
            chipNode:setScale(scaleToFactor)
        else 
            chipNode:setOpacity(0)
            chipNode:stopAllActions()
            local mov = cc.MoveTo:create(moveSpeed,cc.p(tgtPosX,tgtPosY))
            local ease = cc.EaseExponentialOut:create(mov)
            local rotate = cc.RotateBy:create(moveSpeed,math.random(-90,90))
            rotate = cc.EaseExponentialOut:create(rotate)
            local scl = cc.ScaleTo:create(moveSpeed * 0.5,scaleToFactor)
            local fadeIn = cc.FadeTo:create(moveSpeed * 0.2,255)
            local spawn = cc.Spawn:create(ease,fadeIn,rotate,scl) 
            if self.allined == true then
                chipNode:setScale(1.2) 
                spawn = cc.Spawn:create(ease,scl,fadeIn) 
            end

            local act = cc.Sequence:create(cc.DelayTime:create(k * 0.2),cc.Show:create(),spawn)
            
            chipNode:runAction(act)
        end

    end

end

function UIGameTableSanzhang:setupPlayer(data)
    local v = data 

    self.playerData[v.seatID] = v
    printf('self.currentRoomState:%s',self.currentRoomState)
    if self.currentRoomState >  UIGameTableSanzhang.Config['JINNIU_ROOM_STATE_IDLE'] then
        printf('setting player :%s to Sat.',v.seatID)
        -- self.playerData[v.seatID].isSat = true
    end
    if v.seatID ~= self.mySeatID then
        self:insertPlayerToDisplayTable(self.playerData[v.seatID]) 
    else
        self.playerData[v.seatID].displayID = 1
    end

    

    self.playerData[v.seatID].BetTotal = self.playerData[v.seatID].BetTotal or self.loginData.baseChip  
    --显示该玩家相关组件
    print('setting displayID%s to visible',v.displayID)
    self['Panel_player_'..v.displayID]:setVisible(true)
 

    --设置性别 
--                      local newSprite = cc.Sprite:createWithSpriteFrameName(spritePath)
--   122              local maskSprite = cc.Sprite:createWithSpriteFrameName('game/default_photo.png') 
--   123:             local spriteItem = LuaTools:createMaskedSprite(newSprite, maskSprite) 
 


 --     "VLevel"      = 0
 -- "VType"       = 0

    -- if v.VType > 0 then
    --     local vipNode = self['Panel_player_'..v.displayID]:getChildByName("Image_vip")  
    --     vipNode:setVisible(true)
    --     local vipBG = 'common/icon_vip_bg_'..(v.VType - 1)..'.png'
    --     local viplv = 'common/icon_vip_'..(v.VLevel - 1)..'.png' 
    --     printf('vipBG:%s,viplv:%s',vipBG,viplv)
    --     vipNode:loadTexture(vipBG,ccui.TextureResType.plistType)
    --     vipNode:getChildByName("Image_lvl"):loadTexture(viplv,ccui.TextureResType.plistType) 
    -- end
    GameTableCommon.setVIP(self, v.VLevel,v.VType,v.displayID )
    --设置头像

    GameTableCommon.setAvatar(self,v.PicUrl,v.displayID,v.Sex)
    -- if v.PicUrl and v.PicUrl~="" then
    --     local iconUrl = self['Panel_player_'..v.displayID]:getChildByName("Image_avatar")  
    --     local newName = self.icon
    --     local function onFinishTable(status,downloadedSize,dst) 
    --         if status == "success" then
    --             -- iconUrl:loadTexture(dst,ccui.TextureResType.localType)
    --             local newSprite = cc.Sprite:create(dst)
    --             local maskSprite = cc.Sprite:createWithSpriteFrameName('common/circle.png') 
    --             local spriteItem = LuaTools.createMaskedSprite(newSprite, maskSprite) 
    --             -- self:addChild(spriteItem) 
    --             spriteItem:setScaleX(iconUrl:getContentSize().width / spriteItem:getContentSize().width)
    --             spriteItem:setScaleY(iconUrl:getContentSize().height / spriteItem:getContentSize().height)
    --             spriteItem:setAnchorPoint(0,0)
    --             iconUrl:addChild(spriteItem) 
    --         else 
    --             print('获取好友头像失败')
    --         end
    --     end 
    --     LuaTools.getFileFromUrl({
    --         url =  v.PicUrl,
    --         destFile = ( v.PicUrl:gsub("/","_")),
    --         onFinishTable = onFinishTable
    --         }) 
    -- else
    --     local sex = self['Panel_player_'..v.displayID]:getChildByName("Image_avatar")
    --     local sexPath = "common/default_avater_man.png"
    
    --     if v.Sex == UIGameTableSanzhang.SEX_FEMALE then 
    --         sexPath = "common/default_avater_woman.png"
    --         -- local sex = self['Panel_player_'..v.displayID]:getChildByName("Image_avatar") 
    --         -- sex:loadTexture("common/Room_female_head.png",ccui.TextureResType.plistType) 
    --     end
    
    --     local newSprite = cc.Sprite:createWithSpriteFrameName(sexPath)
    --     local maskSprite = cc.Sprite:createWithSpriteFrameName('common/circle.png') 
    --     local spriteItem = LuaTools.createMaskedSprite(newSprite, maskSprite) 
    
    --     spriteItem:setScaleX(sex:getContentSize().width / spriteItem:getContentSize().width)
    --     spriteItem:setScaleY(sex:getContentSize().height / spriteItem:getContentSize().height)
    --     spriteItem:setAnchorPoint(0,0)
    --     sex:addChild(spriteItem)
    
    --     -- sex:loadTexture(spriteItem) 
    
    -- end

    if self.playerData[v.seatID].compareCallback == nil and v.seatID ~= self.mySeatID then
        self.playerData[v.seatID].compareCallback = function() 
            self:showComp(true)
            self:REQ_COMPARE(v.seatID) 
        end
        self['Panel_player_'..v.displayID]:getChildByName('Button_compblah'):onTouch(self.playerData[v.seatID].compareCallback)
    end
    --设置昵称
    if v.Name then
        local nick = self['Panel_player_'..v.displayID]:getChildByName("Text_nickname")
        if nick then
            nick:setString( v.Name) 
        end
    end
    --设置金币
    if v.Coin then
        self.playerData[v.seatID].totalCoins = v.Coin
        local coin = self['Panel_player_'..v.displayID]:getChildByName("Text_coins")
        if coin then
            coin:setString(LuaTools.convertAmountChinese(v.Coin,10000)) 
        end
    end



end 

function UIGameTableSanzhang:autoModeAction()
    -- printError('================== BEGIN UIGameTableSanzhang:autoModeAction() ======================')
    -- printf('self.playerData[self.mySeatID].isSat:%s',self.playerData[self.mySeatID].isSat)
    -- printf('self.autoMode :%s',self.autoMode )
    -- printf('self.selectedAutomode :%s',self.selectedAutomode)
    -- printf('self.accumulatedAutoround :%s',self.accumulatedAutoround)
    -- printf('self.allined :%s',self.allined)
    -- printf('self.prevWheelCount :%s',self.prevWheelCount)
    -- printf('self.WheelCount :%s',self.WheelCount)
    -- if self.WheelCount == self.prevWheelCount then return end
    -- self.prevWheelCount = self.WheelCount 
    if self.playerData[self.mySeatID].isSat == true and self.autoMode == true  then
        if self.selectedAutomode == -1 or self.accumulatedAutoround < self.selectedAutomode then
            if self.selectedAutomode ~= -1 then
                self.accumulatedAutoround = self.accumulatedAutoround+1
            end
            if self.allined == true then
                self:PlayerCtrl_drop()
            else
                self:PlayerCtrl_follow()
            end
        else
            self:setAutomode(false)
        end 
    end
    -- printf('================== END UIGameTableSanzhang:autoModeAction() ======================')
end

function UIGameTableSanzhang:setAutomode( enabled )
    -- printError('setAutomode')
    if self.currentRoomState <=  UIGameTableSanzhang.Config['JINNIU_ROOM_STATE_WAIT'] 
        or   self.playerData == nil or self.playerData[self.mySeatID] == nil  or self.playerData[self.mySeatID].isSat ~= true then
        return
    end
    printf('UIGameTableSanzhang:setAutomode:%s',enabled)
    self.autoMode = enabled
    self['Button_cancelAutomode']:setVisible(enabled)
    if enabled == false then--reset
        self.accumulatedAutoround = 0
    end
    -- printf()
    if self.playerData[self.mySeatID].PlayerState >= UIGameTableSanzhang.Config['PlayerStateBetOn']  
        and self.playerData[self.mySeatID].isDrop ~= true then
        self:autoModeAction()
    end
    self['Panel_autoTextAnimation']:setVisible(enabled)
    if self['Panel_autoTextAnimation'].animationNode == nil then 
        self['Panel_autoTextAnimation'].animationNode =  GameTableCommon.createAnimationNode('Animation_trusteeship.csb',nil,true)
        self['Panel_autoTextAnimation']:addChild(self['Panel_autoTextAnimation'].animationNode)
    end
    if enabled == true then  
        self['Button_autoPlay']:loadTextures('common/autoTriggered.png','common/autoTriggered.png','common/autoTriggered.png',ccui.TextureResType.plistType)
    else 
        self['Button_autoPlay']:loadTextures('common/auto.png','common/auto.png','common/auto.png',ccui.TextureResType.plistType)
    end
end

function UIGameTableSanzhang:enableAutomode() 

    self['Panel_autoMode']:setVisible(false) 
    self:setAutomode( true )
end

function UIGameTableSanzhang:cancelAutomode() 
    self['Panel_autoMode']:setVisible(false) 
    self:setAutomode( false )
end


function UIGameTableSanzhang:processCheckBoxes( arg ) 
    local checkBoxTable = 
    {
        [ 'CheckBox_follow5'   ] =  5,
        [ 'CheckBox_follow10'  ]=  10,
        [ 'CheckBox_follow20'  ]=  20,
        [ 'CheckBox_followall' ]=  -1,
    }
    -- if arg.target:isSelected() == true then return end
    printf("target:%s",arg.target:isSelected())
    local selCount = 0
    -- setSelected
    for k,v in pairs(checkBoxTable) do 
       self[k]:setSelected(false)  
    end
    arg.target:setSelected(true)  
    self.selectedAutomode = checkBoxTable[arg.target:getName()]
    -- body
end

function UIGameTableSanzhang:showAutomodeSelection(show)
    -- body
    -- self.autoMode = show
    self['Panel_autoMode']:setVisible(show)
end
 

function UIGameTableSanzhang:scheduleHeartbeat()
    self:stopSchedule('heartbeat')
    self:createSchedule('heartbeat', function()   
        self:REQ_heartbeat() 
    end,20)  
end 

function UIGameTableSanzhang:clearAllStatus()
    print('clearAllStatus')
    for k,v in pairs(self.playerData) do
        local suffix = v.displayID    
        self['Image_status_' .. suffix]:setVisible(false) 
    end 
end
 
-- function setPlayerState(seatID,state)
--     if state == 0 then
--         self['Image_status_'..self.playerData[v.seatID].displayID]:setVisible(true)
--     end
-- end

function UIGameTableSanzhang:insertPlayerToDisplayTable(data)
    GameTableCommon.insertPlayerToDisplayTable(self,data)
    -- dump(UIGameTableSanzhang.displayIDTable,"UIGameTableSanzhang.displayIDTable")
    -- for k,v in pairs(UIGameTableSanzhang.displayIDTable) do
    --     if v == false then
    --         -- dump(data,"before display inserted table") 
    --         UIGameTableSanzhang.displayIDTable[k] = true
    --         data.displayID = k 
    --         -- dump(data,"after display inserted table")
    --         -- printf("^^^ the %s has been inserted to table ^^^",k)
    --         -- dump(UIGameTableSanzhang.displayIDTable,"UIGameTableSanzhang.displayIDTable AFTER")
    --         return k
    --     end
    -- end 
    -- -- printError("insertPlayerToDisplayTable: seats are full!")
end

function UIGameTableSanzhang:resetTable()
    self:clearTable()
    for i=2,5 do
        UIGameTableSanzhang.displayIDTable[i] = false
        self['Panel_player_'..i]:setVisible(false) 
    end
    UIGameTableSanzhang.displayIDTable[1] = true
    self.playerData = {}
end

-- function UIGameTableSanzhang:alignItemsHorizontallyWithPadding(padding,childredTable) 
--     local width = -padding; 
--     for k,child in pairs(childredTable) do
--         width  = width + child:getContentSize().width * child:getScaleX() + padding;
--     end

--     local x = -width / 2.0 ;
    
--     for k,child in pairs(childredTable) do
--         child:setPosition(x + child:getContentSize().width * child:getScaleX() / 2.0 , 0);
--         x  = x+ child:getContentSize().width * child:getScaleX() + padding;
--     end 
-- end

function UIGameTableSanzhang:arrangeCards(arrangeType,cardCalueTable,_padding,extraArgs)

    return GameTableCommon.arrangeCards(self,arrangeType,cardCalueTable,_padding,extraArgs)
    -- local parent = display.newNode() 
    -- local spritePath = Cardutl.getPathForCard( cardCalueTable[1],nil,nil,'Douniu')  
    -- print("arrangeCards spritePath：",spritePath)
    -- local card = cc.Sprite:createWithSpriteFrameName(spritePath)
    -- local padding = card:getContentSize().width * 0.5
    -- local width =   padding * #cardCalueTable + card:getContentSize().width * card:getScaleX() 
    -- local aPoint = cc.p(0,0.5) 
    -- if arrangeType == UIGameTableSanzhang.ARRANGE_RIGHT then 
    --     aPoint = cc.p(0,0.5)
    -- elseif  arrangeType == UIGameTableSanzhang.ARRANGE_MIDDLE then 
    --     aPoint = cc.p(0.5,0.5)
    -- end

    -- local cardInstanceTable = {}
    -- -- dump(cardCalueTable,"cardCalueTable")
    -- for k,v in pairs(cardCalueTable) do
    --     -- print(k,v)
    --     local spritePath = Cardutl.getPathForCard(v,nil,nil,'Douniu' ) 
    --     local card = cc.Sprite:createWithSpriteFrameName(spritePath)
    --     parent:addChild(card)  
    --     card:setAnchorPoint(aPoint)
    --     card:setTag(tonumber(k))   
    --     if arrangeType == UIGameTableSanzhang.ARRANGE_LEFT then
    --         card:setPosition(tonumber(k) * padding  - padding, 0); 
    --     elseif  arrangeType == UIGameTableSanzhang.ARRANGE_RIGHT  then  
    --         card:setPosition((tonumber(k)) * padding - width , 0); 
    --     end
    --     table.insert(cardInstanceTable,card)
    --     local p = card:convertToWorldSpaceAR(cc.p(0,0))
    --     printf('arrangeCards(%s):(%s,%s)',k,p.x,p.y )
    -- end
    -- if arrangeType == UIGameTableSanzhang.ARRANGE_MIDDLE then
    --     self:alignItemsHorizontallyWithPadding(_padding or -80,cardInstanceTable)
    -- end

    -- dump(extraArgs,"extraArgs")

    -- if extraArgs == nil then 
    --     printError('extraArgs is nil')
    -- end

    -- if extraArgs and extraArgs.useAnimation == true then
    --     if extraArgs.animationType == 'deal' then 
    --         audio.playSound(Sound.SoundTable['sfx']['Fapai'] , false)
    --         GameTableCommon.dealCardAnimation( cardInstanceTable,extraArgs.onFinishCallback )
    --     elseif extraArgs.animationType == 'orbit' then
    --         for k,v in pairs(extraArgs.animationOrbitIdxTable or {}) do
    --             GameTableCommon.orbitCard(cardCalueTable[v])
    --         end
    --     end
    -- end
 
end


function UIGameTableSanzhang:showCards(seatID,cards,showType,_type,extraArgs)
    -- local arrangeType = UIGameTableSanzhang.ARRANGE_MIDDLE
    -- local displayID = self.playerData[seatID].displayID
    -- self.playerData[seatID].Cards = cards
    -- if self.playerData[seatID].displayedCards ~= nil then
    --    self.playerData[seatID].displayedCards:removeFromParent()
    --    self.playerData[seatID].displayedCards = nil
    -- end


    -- if displayID == 2 or displayID == 3 then
    --     arrangeType = UIGameTableSanzhang.ARRANGE_RIGHT
    -- elseif displayID == 4 or displayID == 5 then 
    --     arrangeType = UIGameTableSanzhang.ARRANGE_LEFT
    -- end
    -- local cards = self:arrangeCards(arrangeType,cards,nil,extraArgs)
    -- self.playerData[seatID].displayedCards = cards 
    -- local cardNode = self['Panel_player_'..displayID]:getChildByName('Image_card')
    -- cards:setPositionX(cardNode:getPositionX())
    -- cards:setPositionY(cardNode:getPositionY())

    -- cards:setScaleX(cardNode:getScaleX())
    -- cards:setScaleY(cardNode:getScaleY())
    -- cards:setLocalZOrder(cardNode:getLocalZOrder()-1)
    -- -- cards:setGlobalZOrder(cardNode:getGlobalZOrder())


    -- cardNode:getParent():addChild(cards)
    GameTableCommon.showCards(self,seatID,cards,showType,_type,extraArgs)
    if showType == true then
        self['Panel_player_'..displayID]:getChildByName('Image_bulltype'):setVisible(true)
        self['Panel_player_'..displayID]:getChildByName('Image_bulltype'):getChildByName('Text_bull'):setString(UIGameTableSanzhang.TypeTable[_type+1])
    end
end

function UIGameTableSanzhang:clearPlayerPanel( seatID,delData ) 
    local k = seatID
    local v = self.playerData[seatID]
    if self.playerData and self.playerData[seatID] then
         
        if seatID == self.lastCompareSeatIDFrom or seatID == self.lastCompareSeatIDTo then 
            self:killCompareAnimation()
        end
        local panel = self['Panel_player_'..self.playerData[seatID].displayID]
        printf("CLEANING:\n %s \n",self.playerData[seatID].displayID )
        self:setPlayerChip( seatID)
        -- self['Panel_player_'..self.playerData[seatID].displayID]:setVisible(false) 
        self['Panel_player_'..self.playerData[seatID].displayID]:getChildByName('Image_lose'):setVisible(false) 
        if delData == true then 
            self['Image_status_'..self.playerData[seatID].displayID]:setVisible(false)
        end
        panel:getChildByName('Image_watched'):setVisible(false)
        panel:getChildByName('Image_dropped'):setVisible(false) 
        panel:getChildByName('Image_lose'):setVisible(false) 
        UIGameTableSanzhang.displayIDTable[self.playerData[seatID].displayID]=false 
        if self.playerData[seatID].spotLens then
            self.playerData[seatID].spotLens:removeFromParent()
            self.playerData[seatID].spotLens = nil 
        end



        local node = self['Panel_player_'..v.displayID] 
        if  self['Panel_player_'..v.displayID]:getChildByName('Button_compblah') then
            self['Panel_player_'..v.displayID]:getChildByName('Button_compblah'):setVisible(false)
        end
        self['Panel_player_'..v.displayID]:getChildByName('BitmapFontLabel_score'):setVisible(false)
        self['Panel_player_'..v.displayID]:getChildByName('Image_dropped'):setVisible(false) 
        self['Panel_player_'..v.displayID]:getChildByName('Image_watched'):setVisible(false)

        self['Panel_player_'..v.displayID]:getChildByName('Image_lose'):setVisible(false) 

        if self.playerData[k].displayedCards ~= nil then
            self.playerData[k].displayedCards:removeFromParent()
            self.playerData[k].displayedCards = nil
            printf('[%s].displayedCards removed.',k)
        end  
        if self.playerData[k].dealerLogo then
            self.playerData[k].dealerLogo :removeFromParent()
            self.playerData[k].dealerLogo = nil
        end
        self.playerData[k].isDealer = nil 
        self.playerData[k].isDrop = nil
        self.playerData[k].isSat = nil
        self['Panel_player_'..v.displayID]:getChildByName('Image_bulltype'):setVisible(false)

        node:getChildByName('Image_chipBG'):setVisible(false)  
        if  self['Panel_player_'..v.displayID].timerNode then
            self['Panel_player_'..v.displayID].timerNode:removeFromParent()
            self['Panel_player_'..v.displayID].timerNode = nil
        end
        self.playerData[k].BetTotal = self.loginData.baseChip
        self.playerData[k].IsLookCard = 0
        self.playerData[k].allined = 0
        self.playerData[k].Cards = {}
        if self.playerData[k].spotLens then
            self.playerData[k].spotLens:removeFromParent()
            self.playerData[k].spotLens = nil 
        end
      

        if delData == true then
            self.playerData[seatID]=nil
            panel:setVisible(false)
        end

    end

end

function UIGameTableSanzhang:clearTable()
    for k,v in pairs(self.playerData) do 
        self:clearPlayerPanel(k)
        -- local node = self['Panel_player_'..v.displayID] 
        -- if  self['Panel_player_'..v.displayID]:getChildByName('Button_compblah') then
        --     self['Panel_player_'..v.displayID]:getChildByName('Button_compblah'):setVisible(false)
        -- end
        -- self['Panel_player_'..v.displayID]:getChildByName('BitmapFontLabel_score'):setVisible(false)
        -- self['Panel_player_'..v.displayID]:getChildByName('Image_dropped'):setVisible(false) 
        -- self['Panel_player_'..v.displayID]:getChildByName('Image_watched'):setVisible(false)

        -- self['Panel_player_'..v.displayID]:getChildByName('Image_lose'):setVisible(false) 

        -- if self.playerData[k].displayedCards ~= nil then
        --     self.playerData[k].displayedCards:removeFromParent()
        --     self.playerData[k].displayedCards = nil
        -- end  
        -- if self.playerData[k].dealerLogo then
        --     self.playerData[k].dealerLogo :removeFromParent()
        --     self.playerData[k].dealerLogo = nil
        -- end
        -- self.playerData[k].isDealer = nil 
        -- self.playerData[k].isDrop = nil
        -- self.playerData[k].isSat = nil
        -- self['Panel_player_'..v.displayID]:getChildByName('Image_bulltype'):setVisible(false)

        -- node:getChildByName('Image_chipBG'):setVisible(false)  
        -- if  self['Panel_player_'..v.displayID].timerNode then
        --     self['Panel_player_'..v.displayID].timerNode:removeFromParent()
        --     self['Panel_player_'..v.displayID].timerNode = nil
        -- end
        -- self.playerData[k].BetTotal = self.loginData.baseChip
        -- self.playerData[k].IsLookCard = 0
        -- self.playerData[k].allined = 0
        -- self.playerData[k].Cards = {}
        -- if self.playerData[k].spotLens then
        --     self.playerData[k].spotLens:removeFromParent()
        --     self.playerData[k].spotLens = nil 
        -- end
        -- if self['spotLight'] then 
        --     self['spotLight']:removeFromParent()
        --     self['spotLight'] = nil 
        -- end
        

       
    end 
    for k,v in pairs(self.losewonTbl or {}) do
        if tolua.isnull(v) == false then
            v:removeFromParent()
        end
    end
    self:stopSchedule('spotLightDelay')
    self:stopSchedule('checkComparing')
    if self['spotLight'] then 
        self['spotLight']:removeFromParent()
        self['spotLight'] = nil 
    end
    self.losewonTbl = nil
    self.lastCompareOnFinishCallback = nil
    self.lastCompareLostSeatID  = nil
    self.lastCompareSeatIDFrom = nil
    self.lastCompareSeatIDTo = nil

    self.iTookPart = false
    self:updateBaseAmount( nil,true )
    self:updateWhells(0,true)
    self:clearAllStatus()
    self:setButtons({ status = 0})
    self.WheelCount = 1
    GameTableCommon.setStaticMsg(self)
    self:setAutomode(false)
    self.allined = nil
    self.CurrentTotalBet = 0 
    self.minBet = self.loginData.minBet
    self.CurrentBet = self.loginData.minBet
    self.accumulatedAutoround = 0
    for k,v in pairs(self.thrownChips or {}) do
        if tolua.isnull(v) == false then
            v:removeFromParent()
        end
    end
    self.thrownChips = {}

    for i=1,5 do
        self['Panel_player_'..i]:getChildByName('Image_lose'):setVisible(false) 
        self['Panel_player_'..i]:getChildByName('Image_dropped'):setVisible(false) 
        self['Panel_player_'..i]:getChildByName('Image_watched'):setVisible(false) 
    end
    -- self:clearMultiplyAmount() 

    -- self['Text_guodi']:setString('锅底:')
    -- self['Text_fengding']:setString('封顶:')
    for i=1,3 do
        self['Button_card_'..i]:setVisible(false) 
        self['Button_card_'..i]:setColor(cc.c3b(255,255,255))
        self['Button_card_'..i]:loadTextures('newcard/back.png','newcard/back.png','newcard/back.png',ccui.TextureResType.plistType)
    end 
    self.currentRoomState =  UIGameTableSanzhang.Config.JINNIU_ROOM_STATE_WAIT 
    local path = 'room/room_btn_green.png'  
    
    self.isShowTipCompare = false
end

function UIGameTableSanzhang:setupDealer(seatID)
    GameTableCommon.setupDealer(self,seatID)
     -- bodyD:\celebritypoker\YZDDZ\cocosstudio\zjh\dealer.png
     -- for k,v in pairs(self.playerData) do
     --    if seatID == v.seatID then
     --        self.playerData[k].isDealer = true
     --        local dealer =self.playerData[k].dealerLogo
     --        if dealer then
     --            dealer:removeFromParent()
     --            self.playerData[k].dealerLogo = nil
     --        end

     --        dealer =  cc.Sprite:createWithSpriteFrameName('zjh/dealer.png')
     --        self.playerData[k].dealerLogo = dealer
     --        dealer:setName('dealer')
     --        self['Panel_player_'..v.displayID]:getChildByName('Image_avatar'):getParent():addChild(dealer)
     --        local posX = self['Panel_player_'..v.displayID]:getChildByName('Image_avatar'):getPositionX()
     --        local posY = self['Panel_player_'..v.displayID]:getChildByName('Image_avatar'):getPositionY()
     --        posX = posX - self['Panel_player_'..v.displayID]:getChildByName('Image_avatar'):getContentSize().width / 2
     --        posY = posY + self['Panel_player_'..v.displayID]:getChildByName('Image_avatar'):getContentSize().height / 2


     --        dealer:setPositionX(posX)
     --        dealer:setPositionY(posY)
     --    else

     --        local dealer =self.playerData[k].dealerLogo
     --        if dealer then
     --            dealer:removeFromParent()
     --            self.playerData[k].dealerLogo = nil
     --        end
     --    end
     -- end 
    
end 
 

function UIGameTableSanzhang:setupPOVCards( cards,extraArgs )
    GameTableCommon.setupPOVCards(self, cards,extraArgs,3 )
    -- for i=1,3 do
    --     self['Button_card_'..i]:setVisible(true)
    --     self['Button_card_'..i]:loadTextures('newcard/back.png','newcard/back.png','newcard/back.png',ccui.TextureResType.plistType)
    -- end
    -- self.playerData[self.mySeatID].Cards = cards
    -- for k,v in pairs(cards) do
    --     print(k,v)
    --     self['Button_card_'..k]:setVisible(true) 
    --     self['Button_card_'..k].val = v  
    --     local path = Cardutl.getPathForCard( v,nil,nil,"Douniu" )
    --     print(path)
    --     self['Button_card_'..k]:loadTextures(path,path,path,ccui.TextureResType.plistType)
    -- end

    -- if extraArgs and extraArgs.useAnimation == true then 
    --     if extraArgs.animationType == 'deal' then
    --         local tbl = {}
    --         for i=1,3 do
    --             table.insert(tbl, self['Button_card_'..i])
    --         end
    --         GameTableCommon.dealCardAnimation( tbl, extraArgs.onFinishCallback)
    --     elseif extraArgs.animationType == 'orbit' then
    --         for k,v in pairs(extraArgs.animationOrbitIdxTable or {}) do
    --             GameTableCommon.orbitCard(self['Button_card_'..k])
    --         end
    --     end
    -- end
end
 

function UIGameTableSanzhang:startCounddown( msg,sec )
    -- self['Image_countdown']:setVisible(false)
    -- if sec >0 then 
    --     self['Image_countdown']:getChildByName('Text_time'):setString(msg..":"..sec - 1)
    --     local remaining = sec - 1
    --     self['Image_countdown']:setVisible(true)
    --     self:stopSchedule("countdown")
    --     self:createSchedule("countdown",function() 
    --         remaining=remaining-1
    --         if remaining < 0 then 
    --             self:stopSchedule("countdown") 
    --             self['Image_countdown']:setVisible(false)
    --             return
    --         end
    --         self['Image_countdown']:getChildByName('Text_time'):setString(msg..":"..remaining)
    --     end,1) 
    -- end
end


function UIGameTableSanzhang:updateBaseAmount( addedAmount,shutdown,set )
    -- body
    if shutdown then 
        self['Text_currentPool']:setString("000000000")
        self['Text_currentPool_bg']:setString("000000000") 
        self['Text_currentPool']:setVisible(false)
        return
    end 
    self.CurrentTotalBet=self.CurrentTotalBet+addedAmount
    if set == true then
        self.CurrentTotalBet = addedAmount
    end
    self['Text_currentPool']:setVisible(true) 
    base = string.format("%09d",self.CurrentTotalBet)
    self['Text_currentPool']:setString(self.CurrentTotalBet)
    self['Text_currentPool_bg']:setString(base) 
end

function UIGameTableSanzhang:updateWhells(curr,reset)
    self.WheelCount = curr  

    self['Text_kebilun']:setColor(cc.c3b(255,255,255))
    self['Text_zuidalun']:setColor(cc.c3b(255,255,255))
    if reset == true then
        self['Text_zuidalun']:setString('最大轮:')
        self['Text_kebilun']:setString('可比轮:')
    end

    if self.WheelCount < self.loginData.maxRound then
        self['Text_zuidalun']:setString('最大轮:'..self.WheelCount..'/'..self.loginData.maxRound)
    elseif self.WheelCount == self.loginData.maxRound then 
        self['Text_zuidalun']:setString('最大轮:'..self.WheelCount..'/'..self.loginData.maxRound)
        self['Text_zuidalun']:setColor(cc.c3b(255,255,0))
    end

    if self.WheelCount < self.loginData.minRound then
        self['Text_kebilun']:setString('可比轮:'..self.WheelCount..'/'..self.loginData.minRound)
    elseif self.WheelCount == self.loginData.minRound then 
        if not self.isShowTipCompare then
            self['Panel_tip']:setVisible(true)
            self['Panel_tip']:setPosition(cc.p(640,763))
            local  movSpeed = 0.5
            local  tgtPos = self['Text_currentPool_bg']:getParent():convertToWorldSpace(cc.p(self["Panel_tip"]:getPosition()))
            local mov = cc.MoveTo:create(movSpeed,cc.p(tgtPos.x,tgtPos.y-42))
            local movReback = cc.MoveTo:create(0.5,cc.p(tgtPos.x,tgtPos.y))
            local act = cc.Sequence:create(cc.Show:create(),mov,cc.DelayTime:create(2),movReback)
            self['Panel_tip']:runAction(act)
            self['Panel_tip']:setVisible(false)
            self.isShowTipCompare = true
        end
        self['Text_kebilun']:setString('可比轮:'..self.WheelCount..'/'..self.loginData.minRound)
        self['Text_kebilun']:setColor(cc.c3b(255,255,0))
    end

 end 

 function UIGameTableSanzhang:getNumberOfPlayerStillPlaying()
     local ret = 0
     for k,v in pairs(self.playerData) do
         if v.isDrop ~= true and v.isSat == true then
            ret=ret+1
         end
     end
     return ret
 end

 function UIGameTableSanzhang:userDropCards(seatID,hideText)
    local displayID = self.playerData[seatID].displayID
    if self.playerData[seatID] then 
        self.playerData[seatID].isDrop = true
    end
    if seatID == self.mySeatID then  
        self:setButtons({ status = 0})
        self["ListView_buttonPanel"]:setVisible(false) 
        self["Button_readyup"]:setVisible(true) 
        self["Button_readyup"]:setEnabled(false)
        self["Button_changeTable"]:setVisible(true)
        if self.readyMoneyTag then 
           self['Button_changeTable']:setEnabled(self.PlayerData.coin>=self.readyMoneyTag)
        end 
        -- local act = cc.Sequence:create(cc.DelayTime:create(0.5),cc.Hide:create())
        -- local act = cc.FadeTo:create(0.5,0)
        for i=1,3 do
            self["Button_card_"..i]:runAction(cc.TintTo:create(0.3,UIGameTableSanzhang.DROP_COLOR)) 
            -- self["Button_card_"..i]:runAction(act:clone())
            --      self.playerData[seatID].displayedCards:runAction(cc.TintTo:create(0.3,UIGameTableSanzhang.DROP_COLOR)) --setColor(cc.c3b(100,100,100))  
      
        end 
        -- self['Panel_player_'..displayID]:getChildByName('Image_dropped'):setVisible(true)
        -- runAction(act:clone())
    else
        if self.playerData[seatID] and self.playerData[seatID].displayedCards then 
            self.playerData[seatID].displayedCards:setCascadeColorEnabled(true) 
            self.playerData[seatID].displayedCards:runAction(cc.TintTo:create(0.3,UIGameTableSanzhang.DROP_COLOR)) --setColor(cc.c3b(100,100,100))  
        end
    --     Image_watched
    --     Image_dropped
    end
    -- self.playerData[seatID].isSat = false
    if hideText ~= true then 
        self['Panel_player_'..displayID]:getChildByName('Image_dropped'):setVisible(true)
    end
    self['Panel_player_'..self.playerData[seatID].displayID]:getChildByName('Image_lose'):setVisible(false)
    self['Panel_player_'..self.playerData[seatID].displayID]:getChildByName('Image_watched'):setVisible(false)
end

------------------------------------- TCP FUNCTIONS---------------------------------------------
local _ = 
[[                    
            ████████╗ ██████╗██████╗     ███╗   ███╗███████╗████████╗██╗  ██╗ ██████╗ ██████╗ ███████╗
            ╚══██╔══╝██╔════╝██╔══██╗    ████╗ ████║██╔════╝╚══██╔══╝██║  ██║██╔═══██╗██╔══██╗██╔════╝
               ██║   ██║     ██████╔╝    ██╔████╔██║█████╗     ██║   ███████║██║   ██║██║  ██║███████╗
               ██║   ██║     ██╔═══╝     ██║╚██╔╝██║██╔══╝     ██║   ██╔══██║██║   ██║██║  ██║╚════██║
               ██║   ╚██████╗██║         ██║ ╚═╝ ██║███████╗   ██║   ██║  ██║╚██████╔╝██████╔╝███████║
               ╚═╝    ╚═════╝╚═╝         ╚═╝     ╚═╝╚══════╝   ╚═╝   ╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚══════╝          
]]
-- 

function UIGameTableSanzhang:TCP_KIKPLAYER(data)
    dump(data,'TCP_KIKPLAYER')
    GameTableCommon.kickPlayer( self,data )
end

function UIGameTableSanzhang:TCP_PLAYER_COMPARE(data)
    dump(data,'TCP_PLAYER_COMPARE')  
 
    -- FitCardChip     Int64       比牌金币数

    -- NextSeatId      int8        下一个下注座位ID，有可能为-1：代表游戏结束，紧接该消息后面会收到游戏结束的消息包
    -- WheelCount      int8        当前下注轮数
    

    local argTable = 
    {
        seatIDFrom =   data.seatID,
        seatIDTo   =   data.ToFitSeatId,
        isWon   =   (data.IsWin == 1),
        onFinishCallback = function()

            if data.NextSeatId >= 0 then 
                -- self:killCompareAnimation()
                self:updateSomeRelativedStuffAndCanThisFunctionNameBeAnyLongerOrWhat(data)
            end

            local loseSeatID = data.seatID
            if data.IsWin == 1 then 
                loseSeatID = data.ToFitSeatId 
                --self.playerData[data.seatID].totalCoins = self.playerData[data.seatID].totalCoins + data.FitCardChip
                self:updatePlayerCoins( data.seatID,self.playerData[data.seatID].totalCoins ,nil,1) 
            else 
                --self.playerData[data.ToFitSeatId].totalCoins = self.playerData[data.ToFitSeatId].totalCoins + data.FitCardChip
                self:updatePlayerCoins( data.ToFitSeatId,self.playerData[data.ToFitSeatId].totalCoins,nil,1 ) 
            end 
            printf('loseSeatID:%s',loseSeatID)
            self:userDropCards(loseSeatID,true) 
            self:updateBaseAmount(data.FitCardChip)
            self:updateWhells(data.WheelCount)

            if data.seatID == self.mySeatID or data.seatID == self.ToFitSeatId  then
                local IWon = (data.IsWin == 1)
                if data.seatID == self.ToFitSeatId then
                    IWon = not IWon
                end

                local wonTable = {
                    [true] = Sound.SoundTable['sfx']['Cmp_Win'],
                    [false] =Sound.SoundTable['sfx']['Cmp_Lose'],
                }
                audio.playSound(wonTable[IWon] , false)

            end 

        end
    }
    self:startCompare(argTable)


    if data.seatID == self.mySeatID or data.seatID == self.ToFitSeatId  then
        local mysSeatID = data.ToFitSeatId  
        if data.seatID == self.mySeatID then -- I  started.
            mysSeatID = data.seatID 
        end 
        local sex = 'male' 
        if self.playerData[mysSeatID].Sex == UIGameTableSanzhang.SEX_FEMALE then 
            sex = 'female' 
        end
        local prefix = Sound.SoundTable['prefix'][sex]
        audio.playSound(Sound.SoundTable['voice'][sex][prefix..'_cmp'] , false) 
    end
    
    


end

function UIGameTableSanzhang:TCP_PLAYER_PEEK(data) 
    dump(data,'TCP_PLAYER_PEEK')  
    self.playerData[data.seatID].IsLookCard = 1 
    if data.seatID == self.mySeatID then
        local extraArgs = 
            {
                useAnimation = true,
                animationType = 'orbit',
                animationOrbitIdxTable = {1,2,3},
                onFinishCallback = function()  
                end
            } 
        self:setupPOVCards(data.cards,extraArgs)  
        self:setButtons()
-- IsLookCard

    end 
    local displayID = self.playerData[data.seatID].displayID
    self['Panel_player_'..displayID]:getChildByName('Image_watched'):setVisible(true)

  

    GameTableCommon.playSound(self,data.seatID, '_watch' )

end


function UIGameTableSanzhang:TCP_PLAYER_DROP_CARDS(data) 
    dump(data,'TCP_PLAYER_DROP_CARDS') 
    self:updateWhells(data.WheelCount)
    self:userDropCards(data.seatID)

    GameTableCommon.playSound(self,data.seatID, '_giveup' )
    if --[[data.seatID ~= self.mySeatID and]] data.NextSeatId >= 0  then 
        data.isApplySoptlightNow = true
        self:killCompareAnimation()
        self:updateSomeRelativedStuffAndCanThisFunctionNameBeAnyLongerOrWhat(data)
    end
    if data.seatID == self.mySeatID then 
        for k,v in pairs(self.playerData) do
            if  self['Panel_player_'..v.displayID]:getChildByName('Button_compblah') then
                self['Panel_player_'..v.displayID]:getChildByName('Button_compblah'):setVisible(false)
            end
        end
    end
-- ='seatID'    
-- ='NextSeatId'
-- ='WheelCount'

end

 
 

function UIGameTableSanzhang:TCP_PLAYER_ALLIN(data) 
    dump(data,'TCP_PLAYER_ALLIN')   


    self.allined = true
    self.playerData[data.seatID].allined = true  
    self:updateBaseAmount(data.allinCoin) 
    self:killCompareAnimation()
    self:updateSomeRelativedStuffAndCanThisFunctionNameBeAnyLongerOrWhat(data)
    self:updateWhells(data.WheelCount)

     GameTableCommon.playSound(self,data.seatID, '_allin' )
 
    -- seatID    
    -- allinCoin 
    -- nextSeatId
    -- wheelCount
end

function UIGameTableSanzhang:updatePlayerCoins( seatID,curCoin,dontShowBankcrupt ,tag)
    -- printError('updatePlayerCoins:seatID:%s,displayID:%s, curCoin:%s',seatID,self.playerData[seatID].displayID curCoin)
    
    GameTableCommon.updatePlayerCoins(self, seatID,curCoin,nil,dontShowBankcrupt,tag )
    -- self.playerData[seatID].totalCoins = curCoin
    -- local coin = self['Panel_player_'..self.playerData[seatID].displayID]:getChildByName("Text_coins")
    -- if seatID == self.mySeatID then
    --     coin = self['AtlasLabel_myCoins']
    --     self.PlayerData.coin = curCoin
    -- end
    -- if coin then
    --     coin:setString(LuaTools.convertAmountChinese(curCoin,10000)) 
    -- end
end

function UIGameTableSanzhang:updateSomeRelativedStuffAndCanThisFunctionNameBeAnyLongerOrWhat(data)
    self.WheelCount = data.WheelCount

        self.IsFirstPlaying = 0
    for k,v in pairs(self.playerData) do
         self.playerData[k].PlayerState =  UIGameTableSanzhang.Config['PlayerStateWaitBet'] 
        if  self['Panel_player_'..v.displayID]:getChildByName('Button_compblah') then
            self['Panel_player_'..v.displayID]:getChildByName('Button_compblah'):setVisible(false)
        end
    end
    local addedAmount = data.addCoin or data.followCoin or data.allinCoin   or 0
    printf('######### [addedAmount:%s] #######',addedAmount)

    if addedAmount then  
        self.playerData[data.seatID].totalCoins = self.playerData[data.seatID].totalCoins - addedAmount
        self:updatePlayerCoins( data.seatID,self.playerData[data.seatID].totalCoins,  ( self.allined == true ),1  )
    end


-- "TCP_PLAYER_FOLLOW" = {
    -- " HEXCMD "   = "0x4D"
    -- "CMD"        = 77(0x4D)
    -- "NextSeatId" = 2(0x2)
    -- "WheelCount" = 4(0x4)
    -- "followCoin" = 10000(0x2710)
    -- "seatID"     = 1(0x1)
-- }


--         local coin = self['Panel_player_'..v.displayID]:getChildByName("Text_coins")
--         if coin then
--             coin:setString(LuaTools.convertAmountChinese(v.Coin)) 
--         end

    self:throwChips(data.seatID,addedAmount)
    -- printf('data.addCoin:%s, data.followCoin:%s, data.allinCoin:%s,',data.addCoin , data.followCoin , data.allinCoin)
    self.playerData[data.seatID].BetTotal = self.playerData[data.seatID].BetTotal  + addedAmount
    self:setPlayerChip(data.seatID,self.playerData[data.seatID].BetTotal) 
    if data.NextSeatId >=0 then
        self.playerData[data.NextSeatId].PlayerState =  UIGameTableSanzhang.Config['PlayerStateBetOn']
        self:setTimer(data.NextSeatId,nil,data.isApplySoptlightNow)
    end
    -- if data.NextSeatId == self.mySeatID then
    self:setButtons() 
    if data.seatID ~= self.mySeatID then 
        self:autoModeAction()
    end
    -- self:killCompareAnimation()
    -- else
    --     self:setButtons({ disableAll = true  })
    -- end

end

function UIGameTableSanzhang:TCP_PLAYER_ADD_BET(data) 
    dump(data,'TCP_PLAYER_ADD_BET') 

     -- " HEXCMD "   = "0x4E"
 -- "CMD"        = 78
 -- "NextSeatId" = 1
 -- "WheelCount" = 1
 -- "addCoin"    = 5000
 -- "seatID"     = 0 
    self.CurrentBet = data.addCoin
    self.minBet = data.addCoin
    self:updateBaseAmount(data.addCoin) 
    self:updateWhells(data.WheelCount)
    self:killCompareAnimation()
    self:updateSomeRelativedStuffAndCanThisFunctionNameBeAnyLongerOrWhat(data)
    if data.seatID ~= self.mySeatID then  
        audio.playSound(Sound.SoundTable['sfx']['Chip_add'], false)
    end

    GameTableCommon.playSound(self,data.seatID, '_add' )

    -- if data.WheelCount == 1 and self.IsFirstPlaying == 1 then
    -- else
    -- end

end

function UIGameTableSanzhang:TCP_PLAYER_FOLLOW(data) 
    dump(data,'TCP_PLAYER_FOLLOW')  

    self:updateBaseAmount(data.followCoin) 
    self:updateWhells(data.WheelCount)
    self:killCompareAnimation()
    self:updateSomeRelativedStuffAndCanThisFunctionNameBeAnyLongerOrWhat(data)

    if data.seatID ~= self.mySeatID then  
        -- printError('PLAYING Chip_inChip_inChip_inChip_inChip_inChip_inChip_inChip_inChip_inChip_inChip_inChip_in')
        audio.playSound(Sound.SoundTable['sfx']['Chip_in'], false)
    end 
    GameTableCommon.playSound(self,data.seatID, '_follow' )
    -- " HEXCMD "   = "0x4D"
-- "CMD"        = 77
-- "NextSeatId" = 1
-- "WheelCount" = 6
-- "followCoin" = 3000
-- "seatID"     = 0
end

function UIGameTableSanzhang:TCP_NETWORK_BAD_TRAFFIC(data) 
    dump(data,'TCP_NETWORK_BAD_TRAFFIC')  
end

function UIGameTableSanzhang:TCP_PLAYER_DISCONNECTED(data)
    dump(data,'TCP_PLAYER_DISCONNECTED')  
    local player = self:getPlayerByUid( data.Uid )
    data.seatID = player.seatID

    GameTableCommon.disconnectPlayer( self,data.seatID ) 
    self:clearPlayerPanel( data.seatID,true )
end

function UIGameTableSanzhang:TCP_PLAYER_CONNECTED(data)
    dump(data,'TCP_PLAYER_CONNECTED')  
    self:setupPlayer(data) 
    self:setPlayerStatus(data.seatID,UIGameTableSanzhang.Config['PlayerStateUnReady'])
end

function UIGameTableSanzhang:TCP_PLAYER_READY(data)
    dump(data,'TCP_PLAYER_READY')  
    self:setPlayerStatus(data.seatID,UIGameTableSanzhang.Config['PlayerStateReady'])
end



function UIGameTableSanzhang:TCP_LOGIN_SUCC(data)
    dump(data,'TCP_LOGIN_SUCC') 
    self.loginData = data
    LuaTools.stopWaiting() 
    self.currentRoomState = data.TableState
    printf('TCP_LOGIN_SUCC:self.currentRoomState:%s',self.currentRoomState )
    ----------------------------各个场次的准备金
    local readyMoney   = {['60']=100,['61']=1000,['62']=30000,['63']=100000,['65']=30000} 
    self.readyMoneyTag =  readyMoney[tostring(data.tableType)]
    ----------------------------
    self.mySeatID = data.mySeatID    
    self.betTimeout = data.betTimeout
    self.IsFirstPlaying = data.IsFirstPlaying
    self.CurrentBet = data.CurrentBet
    self:generateAdditionChipTable(data.minBet,data.maxBet)
  
    self.WheelCount = data.CurrentWheel
    self.minBet = self.loginData.minBet
    self:updateWhells(self.WheelCount)
    self:resetTable()   
    self:killCompareAnimation(true)
    self.currentRoomState = data.TableState
    self.CurrentTotalBet = data.baseChip

    GameTableCommon.handleLoginSuccess( self,data )

    if data.CurrentAllinSeatId and data.CurrentAllinSeatId >=0 then
        self.allined = true
    end

    self['Text_guodi']:setString('锅底:'..data.baseChip)
    self['Text_fengding']:setString('封顶:'..data.maxBet)
    if data.CurrentTotalBet then
        self.CurrentTotalBet = data.CurrentTotalBet 
        self:updateBaseAmount( 0 )  
    end
    printf('CurrentTotalBet:%s',self.CurrentTotalBet) 
    if self.currentRoomState == UIGameTableSanzhang.Config['JINNIU_ROOM_STATE_IDLE']  then 
        self['Button_readyup']:setVisible(true)
        self['Button_changeTable']:setVisible(true)
        self['Button_readyup']:setEnabled(true) 
        if self.readyMoneyTag then 
           self['Button_changeTable']:setEnabled(self.PlayerData.coin>=self.readyMoneyTag)
        end 
    end
    -- "TableState"           = 1  <--- game_start
    if data.CurrentDealerMulti then
       -- self.dealerM = data.CurrentDealerMulti 
    end
    for k,v in pairs(data.users) do
        self:setupPlayer(v)
        self:setPlayerStatus(v.seatID,v.PlayerState) 

        -- BetTotal
        local showTotal = (v.BetTotal ~= nil )
        printf('v.BetTotal :%s,self.currentRoomState:%s',v.BetTotal,self.currentRoomState)
        if showTotal and self.currentRoomState >  UIGameTableSanzhang.Config['JINNIU_ROOM_STATE_WAIT'] then 
            self:setPlayerChip(v.seatID,self.playerData[v.seatID].BetTotal) 
        end
        --没有准备的就隐藏下注筹码
        if v.PlayerState == 0 then
            local node = self['Panel_player_'..self.playerData[v.seatID].displayID]
            local textBGNode = node:getChildByName('Image_chipBG')
            textBGNode:setVisible(false)
        end
        local cardTable = v.Cards 
        if v.CardCount and v.CardCount <= 0 then 
            cardTable = {0,0,0}
        end
        if v.seatID ~= self.mySeatID then  
            if cardTable then
                self:showCards(v.seatID,cardTable) 
            end
        else 
            if cardTable then
                self:setupPOVCards(cardTable)
            end
            self:setButtons({ 
                isFirstCaller = (data.IsFirstPlaying == 1),   
                })
        end
        if v.IsLookCard == 1 then  
            self['Panel_player_'..v.displayID]:getChildByName('Image_watched'):setVisible(true)
        end

        if v.PlayerState == UIGameTableSanzhang.Config['PlayerStateGiveUp'] then 
            self['Panel_player_'..v.displayID]:getChildByName('Image_dropped'):setVisible(true) 
            self['Panel_player_'..v.displayID]:getChildByName('Image_watched'):setVisible(false)
            if self.playerData[v.seatID].displayedCards then 
                self.playerData[v.seatID].displayedCards:setColor(UIGameTableSanzhang.DROP_COLOR)
            end
        end
 

    end 
    if data.DealerID then 
        self.playerData[data.DealerID].isDealer = true
        self:setupDealer(data.DealerID )
    end



    if data.CurrentStateGoneTime then
        self:setTimer(data.CurrentBetSeatId,self.betTimeout - data.CurrentStateGoneTime)
    end

    if self.currentRoomState >  UIGameTableSanzhang.Config['JINNIU_ROOM_STATE_WAIT'] then
        self['ListView_buttonPanel']:setVisible(true)
        self.minBet = data.CurrentBet
        -- self:throwChips( 0,data.CurrentTotalBet ,true)
    end
        dump(self.playerData) 
        printf('the fuck i took part:%s',self.iTookPart)
        self:setButtons() 

        -- local convertTable = 
        -- {
        --     [61] = 60,
        --     [62] = 61,
        -- }
        local tblNu = tonumber(data.tableType)--convertTable[tonumber(data.tableType)] or tonumber(data.tableType)
        printf('tonumber(data.tableType):%s',tonumber(data.tableType))
    if data.tableType <= 60000000 then 
        cc.SpriteFrameCache:getInstance():addSpriteFrames("tableresult.plist")
        self['Image_tableType']:loadTexture(string.format("tableresult/tbl_b_%s.png",tblNu - 60),ccui.TextureResType.plistType) 
        self['Image_tableType']:setVisible(true)
    end 
        -- self:throwChips(self.mySeatID,149500)
end

function UIGameTableSanzhang:TCP_RSPD_FAIL(data)
    dump(data,'TCP_RSPD_FAIL')
    GameTableCommon.handleExceptionMsg(self,data)

   
    -- local blah = ""..cc.Director:getInstance():getTotalFrames()
    --  local b = G_BASEAPP:addView({
    --        uiName =  'UIDialog',
    --        uiInstanceName = blah
    --         }, 1200)
    --     local func  = function()
    --         if(data.actionId == UIGameTableSanzhang.CMD['READY']) then
    --             self['Button_readyup']:setEnabled(true)
    --         end
    --     end  

    --     b:setupDialog("信息",data.failedStr,func)  

--     actionId" 
-- failedStr"
-- failedType
--     if(data.actionId == UIGameTableSanzhang.CMD['READY']) then
--         if(data.failedType == 0){
--                             room.actMgr.readyNoEnoughMoney();
--                         } 
--     else
--     end
--                         if(failedType == 0){
--                             room.actMgr.readyNoEnoughMoney();
--                         }
--                     }else{
--                         CommTipPopUtil.getCommTipPop(room.roomAct, msg).show();
--                     }
end


function UIGameTableSanzhang:TCP_onConnected() 
    print('UIGameTableSanzhang:TCP_onConnected()')
    if G_LOADINGVIEW then
        G_LOADINGVIEW:removeSelf()
        G_LOADINGVIEW = nil 
    end
    -- 183.61.183.197:6829
    print(self.tableType,self.friendID,self.RoomId)
    local buffer = self:getLoginBuffer(self.tableType,self.friendID,self.RoomId)
    self.tcpGear:sendData(buffer) 
    self:REQ_heartbeat()
    self:scheduleHeartbeat() 
end

function UIGameTableSanzhang:TCP_SYS_INFO(data)
    dump(data,'TCP_SYS_INFO')   
    -- self:showMsgByMsgType(data.infotype,data.info) setset
    GameTableCommon.showMsgByMsgType(self,data.infotype,data.info,data)

end

function UIGameTableSanzhang:TCP_GAME_START(data) 
    dump(data,'TCP_GAME_START')  

    self:killCompareAnimation(true)
    self:clearTable()
    if self.resultPage and self.resultPage.removeSelf then     
        self.resultPage:removeSelf()
        self.resultPage = nil
    end
    self:setupDealer(data.DealerSeatId)
    self:setTimer(data.BetSeatId,self.betTimeout)
    self:clearAllStatus()
    self.IsFirstPlaying = 1
    self.currentRoomState = UIGameTableSanzhang.Config['JINNIU_ROOM_STATE_PLAY']
    self["Button_readyup"]:setVisible(false)
    self["Button_changeTable"]:setVisible(false)

    self:updateBaseAmount( self.loginData.baseChip*#data.EnterGameSeatId ,nil,true) 
    self.iTookPart = false 
    for k,v in pairs(data.EnterGameSeatId) do

        self.playerData[v].totalCoins = self.playerData[v].totalCoins - self.loginData.baseChip
        self:updatePlayerCoins(v,self.playerData[v].totalCoins ) 
        self:throwChips( v,self.loginData.baseChip,nil,true )
        self:setPlayerChip(v,self.loginData.baseChip) 
        self.playerData[v].isSat = true
        self.playerData[v].PlayerState = UIGameTableSanzhang.Config['PlayerStateWaitBet']
        if v == data.BetSeatId then
            self.playerData[v].PlayerState = UIGameTableSanzhang.Config['PlayerStateBetOn']
        end
        if v == self.mySeatID then  
            self.iTookPart = true
        end
        
        self.isDealingCards = true
        self:createSchedule("dealcard_"..k,function()
            self:stopSchedule("dealcard_"..k)
            local extraArgs = 
            {
                useAnimation = true,
                animationType = 'deal',
                onFinishCallback = function() 
                    if k == #data.EnterGameSeatId then
                        self.isDealingCards = false
                    end
                end
            } 
            if v ~= self.mySeatID then 
                printf('self:showCards on START') 
                self:showCards(v,{0,0,0},nil,nil,extraArgs)
            else 
                self:setupPOVCards( {0,0,0},extraArgs )  
            end

        end,0.1 *tonumber(k))

        


 
    end  
    self:setButtons({ 
                isFirstCaller = true,  
                })


    -- self:updateBaseAmount( -self.loginData.baseChip ) 
        --     " HEXCMD "        = "0x4A"
        -- "BetSeatId"       = 1
        -- "CMD"             = 74
        -- "DealerSeatId"    = 0
        -- "EnterGameSeatId" = {
        --     1 = 0
        --     2 = 1
        -- }
end



function UIGameTableSanzhang:TCP_GAME_ROUND_OVER(data)
    dump(data,'TCP_GAME_ROUND_OVER')  


    -- self:startCounddown( "msg",0
    --  )
    -- self['Button_have_bull']:setVisible(false) 
    -- self['Panel_calc']:setVisible(false)
    -- for k,v in pairs(data.PlayInfoList) do
    --     -- BitmapFontLabel_score
    --     local displayID = self.playerData[v.seatID].displayID
    --     local score = self['Panel_player_'..displayID]:getChildByName('BitmapFontLabel_score')
    --     score:setVisible(true)
    --     local fntFile = "fonts/gameOverNum_title_win.fnt"
    --     if v.WinLossChip < 0 then 
    --         fntFile = "fonts/gameOverNum_title_lose.fnt"
    --     end
    --     score:setFntFile(fnthrhtFile) 
    --     score:setString(v.WinLossChip)  
    --     local coin = self['Panel_player_'..displayID]:getChildByName("Text_coins")
    --     if coin then
    --         coin:setString( v.TotalChip) 
    --     end
    -- end



    --assambly data for resulting page
    self:PlayerCtrl_closeAddPanel()
    local argTable = {}
    argTable.infoTable = {}
    argTable.cardsNodeTable = {} 
    argTable.delegate = self
    -- dump(data.PlayInfoList,'data.PlayInfoList in TCP_GAME_ROUND_OVER')  
    -- for k,v in pairs(data.PlayInfoList) do
    for k=1,#data.PlayInfoList do 
        local v = data.PlayInfoList[k]
       local info = {}
       -- dump(v,"v in TCP_GAME_ROUND_OVER")
       local curPlayer = self.playerData[v.seatID]  
       info.iconUrl  = curPlayer.PicUrl
       info.name  = curPlayer.Name 
       if curPlayer.seatID == self.mySeatID then
            info.name = "自己" 
            info.isMyself = true
       end
       info.coins  = v.WinChip
       info.sex  = curPlayer.Sex
       info.seatID  = curPlayer.seatID
    
       info.isDealer = curPlayer.isDealer 
       info.nType = curPlayer.nType
       info.mulText = v.CardTypeMulti
       -- self:updatePlayerCoins( v.seatID,v.TotalChip )
    
       if v.WinChip >= 0 then
           info.won = true
       end
       if data.WinSeatId == self.mySeatID then  
           argTable.isWon = true 
       end
      
       if curPlayer.seatID == self.mySeatID then
           self.PlayerData.coin = v.TotalChip
       end
           -- local cardCalueTable = {} 
           -- if v.seatID == self.mySeatID then 
           --      for i=1,3 do 
           --          table.insert(cardCalueTable,self['Button_card_'..i].val)
           --      end    
           -- else

           -- end
           -- dump(cardCalueTable,"cardCalueTable")
           info.cardsNode = self:arrangeCards(UIGameTableSanzhang.ARRANGE_MIDDLE ,v.Cards,-80)
           info.cardsNode:retain()
           -- printf('[[[[[[[[ getReferenceCount: %s',info.cardsNode:getReferenceCount())
    
    
       table.insert(argTable.infoTable,info)
    
    end
   self:setAutomode( false )
    local wasISat =  self.playerData[self.mySeatID].isSat 
    if wasISat == true then  
        -- put POV player to first.
        for k,v in pairs(argTable.infoTable) do
            if v.seatID == self.mySeatID and k ~= 1 then
                argTable.infoTable[k] , argTable.infoTable[1] = argTable.infoTable[1] , argTable.infoTable[k] 
                break
            end
        end
    
        argTable.type = 'zjh'
        argTable.readyCallback = function() 
            self:REQ_READY()  
            if self.resultPage and self.resultPage.removeSelf then 
                self.resultPage:removeSelf()
                self.resultPage = nil
            end
        end
        argTable.ctCallback = function() 
            self:PlayerCtrl_changeTable() 
            if self.resultPage and self.resultPage.removeSelf then 
                self.resultPage:removeSelf()
                self.resultPage = nil
            end
        end  
        -- dump(argTable,"ORIGINAL argTable") 
         
    end 



    self['Button_readyup']:setEnabled(true) 
    local d = self.playerData[data.WinSeatId].displayID
    for k,v in pairs(data.PlayInfoList) do 
        self:updatePlayerCoins( v.seatID,v.TotalChip)
    end
    printf("checkComparing ....... ")
    self:createSchedule('checkComparing',function()
        if self.isComparing == nil then
            self:stopSchedule('checkComparing')

            printf("checkComparing DONE. ")

                -- self:clearTable()     
                printf("wasISat?????===>%s",wasISat)
                if wasISat == nil then  
                    self:clearTable() 
                end
                self['Button_readyup']:setEnabled(true) 
                self:gatherChipsToSeatID(d, data.WinSeatId,function()   

                printf("gatherChipsToSeatID DONE. ")
                if wasISat == true then 
                    if self.readyMoneyTag then 
                    local abcd = (self.PlayerData.coin>=self.readyMoneyTag) and true or false 
                        argTable.changeTabState = abcd 
                    else
                        argTable.changeTabState = true 
                    end  
                    self.resultPage = G_BASEAPP:addView('UIGameTableResult',5000,argTable) 
                end

                self:clearTable() 
                self['Button_readyup']:setEnabled(true) 
                if wasISat == true then  
                    self['Button_readyup']:setEnabled(true) 
                    self['Button_readyup']:setVisible(false)
                    self['Button_changeTable']:setVisible(false) 
                end

                -- self['Button_readyup']:setVisible(true)
                -- self['Button_changeTable']:setVisible(true)
                -- self['Button_readyup']:setEnabled(true) 
                

            end )--self:gatherChipsToSeatID
        end 
    end,0.01)
  

            

    


    


end

function UIGameTableSanzhang:TCP_HEARTBEAT(data)
    dump(data,'TCP_HEARTBEAT')
end




-------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------

-- UIGameTableSanzhang

-- 参数：
-- tableType ---> 房间ID 。 比如:62=扎金花高级场 61=扎金花重机厂 etc
-- friendID 
-- RoomId   <--- 暂时无用？？


 


function UIGameTableSanzhang:onCreate(argTable)
    
    self.isShowTipCompare = false   -- 显示提示可以比牌
    LuaTools.beginWaiting(true)  
    argTable = argTable or {} 
    self.timeTable = {}
    dump(argTable,"UIGameTableSanzhang:onCreate(argTable)")
    -- GameTableCommon.overrideBack( self ) 
    self.taskGameType = 3
    GameTableCommon.setupBasics( self ) 
    self.tableType  = argTable.tableType    or -1
    self.friendID   = argTable.friendID      or -1
    self.RoomId     = argTable.RoomId        or -1
    self.playerData = {}
    self.currentRoomState = UIGameTableSanzhang.TableStateWait 
    self.autoMode = false
    self.selectedAutomode = 5
    local state = cc.GLProgramState:getOrCreateWithGLProgramName('ShaderUIGrayScale');
    self['Button_readyup']:setGLProgramState(state)
    -- self.Broadcast = G_BASEAPP:addView('UIBroadcast',110, false)
    -- self.Broadcast:setLocalZOrder(10000) 
    -- self['Text_roomType']:setString("") 
    self.PlayerData =G_BASEAPP:getData('PlayerData')
    self['AtlasLabel_myCoins']:setString(LuaTools.convertAmountChinese(self.PlayerData.coin,10000)) 

    local function recruFunc()  
        self:addGobackEventAction(function() recruFunc() end) 
    end
    self:addGobackEventAction(function()
        recruFunc() 
    end)
    -- Image_tableType
    
                -- node:loadTexture("room/RoomPlayerSatus_1_ex.png",ccui.TextureResType.plistType) 

    -- self:enableBack(true,function()
    --     print('UIGameTableSanzhang:onCreateUIGameTableSanzhang:onCreate')
    -- end) 
    -- self['AtlasLabel_myDimonds']:setString(self.PlayerData.gem)

    -- self['Button_have_bull']:onTouch(self:getShowcardCallback())

    -- Button_card_1
-- convertToWorldSpaceAR(cc.p(0,0))
    
 
    -- cc.utils:findChildren()
    -- self.pkNode:getChildByName('Node'):setVisible(false)

    self.pickedCardsCount = 0
    self.tcpGear = TCPGearbox.buildInstance({
            unpackerType = DataUnpacker.Type.GAME_Sanzhang, 
            delegate = self,  
            callbackPrefix = "TCP_",
            name = 'UIGameTableSanzhang TCP',
            -- ip = '14.17.77.164'
            port = argTable.port-- argTable.port or DEFAULT_TCP_PORT
        })

    self['Panel_autoTouchArea']:onTouch(function(event)

        if event.name == 'ended' then
            self:cancelAutomode()
        end

    end)
    audio.playMusic(Sound.SoundTable['bgm']['MusicEx_Sanzhang'], true)

    self:setButtonSoundStatus()
end

function UIGameTableSanzhang:setButtonSoundStatus()
    self["Button_allin"]:setDontPlayDefaultSFX(true)
    self["Button_follow"]:setDontPlayDefaultSFX(true)
    self["Button_add"]:setDontPlayDefaultSFX(true)
    self["Button_show"]:setDontPlayDefaultSFX(true)
    self["Button_comp"]:setDontPlayDefaultSFX(true)
    self["Button_drop"]:setDontPlayDefaultSFX(true)
end


return UIGameTableSanzhang
