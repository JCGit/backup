local UIGameTableMenu = class("UIGameTableMenu", cc.load("mvc").ViewBase)

local GameTableCommon = require("app.models.GameTableCommon")
UIGameTableMenu.RESOURCE_FILENAME = "UIGameTableMenu.csb"
--UIGameTableMenu.RESOURCE_PRELOADING = {"main.png"}
--UIGameTableMenu.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIGameTableMenu.RESOURCE_BINDING = { 
    ["Button_menu"] = {["ended"] = "ToggleMenu"},
    ["Button_exit"] = {["ended"] = "quit"},
    ["Button_automode"] = {["ended"] = "automode"},
    ["Button_help"] = {["ended"] = "help"}, 
    ["Button_settings"] = {["ended"] = "settings"}, 
    ["Button_bg"] = {["ended"] = "ToggleMenu"}, 

    
    }

UIGameTableMenu.buttonTable = 
{
    [true] = 'common/drop_btn_upon.png',
    [false] = 'common/Room_btn_back.png'
}

function UIGameTableMenu:settings()
    G_BASEAPP:addView("UISetting",1300)
end

function UIGameTableMenu:help()
    self:ToggleMenu()
    -- GameTableCommon.toggleHelp(self,true) 
    if self.isDouNiu then 
        G_BASEAPP:addView('UIHelpDouniu',self:getLocalZOrder()+1)
    elseif  self.isWangPai then 
        G_BASEAPP:addView('UIHelpDDZClassic',self:getLocalZOrder()+1)
    elseif  self.isSanzhang then 
        G_BASEAPP:addView('UIHelpSanzhang',self:getLocalZOrder()+1)
    elseif  self.isDdz then 
        G_BASEAPP:addView('UIHelpDDZBooms',self:getLocalZOrder()+1)
    elseif  self.isPaoDeKuai then 
        G_BASEAPP:addView('UIHelpDDZRunFast',self:getLocalZOrder()+1)
    end     
end

function UIGameTableMenu:automode() 
    self:ToggleMenu()
    if self.automodeCalback then
        self.automodeCalback(self.delegate)
    end
end


 

function UIGameTableMenu:quit() 
    if self.delegate.isGameStarted == true then  
        LuaTools.showAlert('对局中无法退出')
        return  
    end
    GameTableCommon.quitComfirm(self.delegate)
end

function UIGameTableMenu:ToggleMenu()

    local spriteFrameCache = cc.SpriteFrameCache:getInstance()
    spriteFrameCache:addSpriteFrames("common.plist")
    self.isOn = not self.isOn
    self['Panel_menu']:setVisible(self.isOn)
    local path = UIGameTableMenu.buttonTable[self.isOn]
    self['Button_menu']:loadTextures(path,path,path,ccui.TextureResType.plistType)

end
 
function UIGameTableMenu:onCreate(delegate)
    local app = self:getApp()
    self.delegate = delegate
    self.app = app
    self.isOn = false
    self:setSkipGoBack(false)
    GameTableCommon.setupHelpPanel(delegate, self )
    self.automodeCalback = delegate.automodeCalback
    if delegate.taskGameType and delegate.taskGameType == 2 then
        self['Button_automode']:setVisible(false) 
        -- self['Button_help']:setVisible(false)
        self['Button_help']:setPosition(self['Button_automode']:getPosition())
        self.isDouNiu = true 
    end

    if delegate.taskGameType and delegate.taskGameType == 3 then
        self['Button_automode']:setVisible(false)  
        self['Button_help']:setPosition(self['Button_automode']:getPosition())
        self.isSanzhang = true 
    end
    if delegate.taskGameType and (delegate.taskGameType == 1 or delegate.taskGameType ==4 )  then 
        -- self['Button_help']:setVisible(false)
        if delegate.taskGameType == 1 then 
            if delegate.isWangPaiDDZ then 
                self.isWangPai = true 
            else     
                self.isDdz = true
            end      
        elseif  delegate.taskGameType ==4 then 
            self.isPaoDeKuai = true 
        end     
    end
    
    if delegate.isGameTableMatch then 
        self['Button_help']:setVisible(false)  
    end     
end
 
 
return UIGameTableMenu
