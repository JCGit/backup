local UIVerUpdate = class("UIVerUpdate", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
UIVerUpdate.RESOURCE_FILENAME = "UIVerUpdate.csb"

local scheduler = require("app.models.QScheduler")
UIVerUpdate.RESOURCE_BINDING = {
    ["Button_back"]     = {["ended"] = "backEvent"},
    ["Button_update"] = {["ended"] = "ClickUpDate"}
    }

local callback = nil
local apk_name = ''
local apk_path = ''
function UIVerUpdate:onCreate(_cb)
    local app  = self:getApp()
    self.app   = app
	self['Panel_Layer']:setVisible(false)
    self['LoadingBar_update']:setVisible(false)
    self['LoadingBar_bg']:setVisible(false)
    self['Text_3']:setVisible(false)
    self['Text_3_0']:setVisible(false)
	
    self.cb = _cb
	if self['Text_1'] then
		self['Text_1']:ignoreContentAdaptWithSize(false)
		self['Text_1']:setContentSize(cc.size(self['Image_1']:getContentSize().width - 25,self['Image_1']:getContentSize().height-10))
		self['Text_1']:setString(G_UPDATEINFO.baseupdate.description)
		
	end   
	if G_UPDATEINFO.baseupdate.isForce == 1 then
			--强行更新
		self['Button_back']:setVisible(false)	
		self['Button_back']:setTouchEnabled(false)	
	end
	
	self.dummyNode = display.newNode()
    self:addChild(  self.dummyNode)
	callback = _cb
	
	function split(str, pat)  
        local t = {}  
        local last_end = 0  
        local s, e = string.find(str, pat, 1)  
        local i = 1  
        while s do     
            table.insert(t, string.sub(str, last_end + 1, last_end + s - last_end - 1))  
            last_end = e  
            s, e = string.find(str, pat, last_end + 1)   
            i = i + 1  
        end  
        if last_end <= #str then  
            cap = string.sub(str, last_end + 1)  
            table.insert(t, cap)  
        end  
        return t    
    end  
	
	apk_name = split(G_UPDATEINFO.baseupdate.apk,'/')
	if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) then 
		apk_path = LuaTools.GetSDRoot()..'/'
	else
		apk_path = cc.FileUtils:getInstance():getWritablePath()
	end
	self['Panel_Layer']:setVisible(true)
	
	
end

function UIVerUpdate:backEvent(event)
	callback()
	G_BASEAPP:removeView('UIVerUpdate')
end

function UIVerUpdate:ClickUpDate(event)
	self['Button_update']:setVisible(false)
	self['LoadingBar_update']:setVisible(true)
    self['LoadingBar_bg']:setVisible(true)
    self['Text_3']:setVisible(true)
    self['Text_3_0']:setVisible(true)
	self['Button_back']:setTouchEnabled(false)	
	self['LoadingBar_update']:setPercent(0)
	if self['Text_3_0'] then
		self['Text_3_0']:setString("更新中:")
	end
	if io.exists(apk_path..apk_name[#apk_name]) then
		if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) then  
			local is_link = LuaTools.getOpenFile(function(data) 
				if G_UPDATEINFO.baseupdate.isForce == 1 then
					cc.Director:getInstance():endToLua()
				else
					callback()
					
				end
			end,apk_path..apk_name[#apk_name])
			if is_link == false then
				LuaTools.showAlert(tostring("安装失败") )
			end
		else
			callback()
		end
		
		local function closeUI()
			G_BASEAPP:removeView('UIVerUpdate')
		end
		
		local scheduler = require("app.models.QScheduler")
		
		scheduler.performWithDelayGlobal(closeUI,0.01)
	else
		self:proceedUpdate({
                http =  G_UPDATEINFO.baseupdate.apk,
                onDataCallback = self:getDownloadDataCallback(),
                onFinishCallback = self:getDownloadFinishCallback(),
                })
	end
	
end

function UIVerUpdate:proceedUpdate(_param)
    local http = _param.http
    http = string.gsub(http, "http://", "")
    http = string.gsub(http, "https://", "")
    local onDataCallback = _param.onDataCallback
    local onFinishCallback = _param.onFinishCallback 
   
    local host , file = LuaTools.splitUrl(http)
    
    
	
    local param = 
    { 
      host = host,
      file = file,
      dst = table.concat({apk_path , apk_name[#apk_name]}),
      onDataCallback = onDataCallback,
      onFinishCallback = onFinishCallback
    } 
   LuaTools.downloadFile(param) 

end

function UIVerUpdate:getDownloadDataCallback()
    return function (downloadedSize) 
        print('DOWNLOADING....'..downloadedSize)
		print(downloadedSize.."/"..G_UPDATEINFO.baseupdate.len)
		local posX = downloadedSize / G_UPDATEINFO.baseupdate.len * 100
		printf('updating posx:%s',posX)
        self.dummyNode:stopAllActions()
        self.dummyNode:runAction(cc.MoveTo:create(0.5,cc.p(posX,0)))
		if self.hasProgressUpdate == nil then  
            self.hasProgressUpdate = true
            self.handel = self:createSchedule('updateScheduler',function()
                self['LoadingBar_update']:setPercent( self.dummyNode:getPositionX() )
                -- self.Text_progress:setString(string.format('...%d%%',self.dummyNode:getPositionX()))
                self['Text_3_0']:setString('更新中:'..string.format("%0.2f",(self.dummyNode:getPositionX()*(G_UPDATEINFO.baseupdate.len/1024/1024/100)))..'M/'..string.format("%0.2f",(G_UPDATEINFO.baseupdate.len/1024/1024))..'M')
				local cur_num = string.format("%0.2f",(self.dummyNode:getPositionX()*(G_UPDATEINFO.baseupdate.len/1024/1024/100)))
				local all_num = string.format("%0.2f",(G_UPDATEINFO.baseupdate.len/1024/1024))
				local str_num =string.format("%0.2f",tonumber(cur_num)/tonumber(all_num))
				if tonumber(str_num) < 0.1 then
					self['Text_3']:setString(string.sub(str_num,4,5).."%")
				elseif tonumber(str_num) < 1 then
					self['Text_3']:setString(string.sub(str_num,3,4).."%")
				else
					self['Text_3']:setString("100%")
				end
			end,0.01)
        end
    end
end

function UIVerUpdate:getDownloadFinishCallback()
    return function (status,downloadedSize,dst)
		printf('FINISHED DOWNLOAD:(%s),size:%s,path:%s',status,downloadedSize,dst)
		if status == 'success' then
			
			scheduler.performWithDelayGlobal(function()
				if self.handel ~= nil then
					scheduler.unscheduleGlobal(self.handel)
				end
				
				self.dummyNode:stopAllActions()
				self.dummyNode:runAction(cc.MoveTo:create(0.5,cc.p( 100,0)))
				if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) then 
					if LuaTools.CheckJavaMethod("openFile") then
						local is_link = LuaTools.getOpenFile(function(data) 
							if G_UPDATEINFO.baseupdate.isForce == 1 then
								cc.Director:getInstance():endToLua()
							else
								callback()
								
							end
						end,dst)
						if is_link == false then
							LuaTools.showAlert(tostring("安装失败") )
						end
					else
						LuaTools.showAlert("apk下载路径： "..dst)
					end
					
				else
					callback()
				end
				G_BASEAPP:removeView('UIVerUpdate')
				--MASTER_RESET() 
			end,0.5)
		else
			self['Button_back']:setTouchEnabled(true)
			LuaTools.showAlert(tostring("更新失败") )
			callback()
			G_BASEAPP:removeView('UIVerUpdate')
		end
    end
end

return UIVerUpdate