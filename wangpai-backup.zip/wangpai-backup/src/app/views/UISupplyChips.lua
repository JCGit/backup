local UISupplyChips = class("UISupplyChips", cc.load("mvc").ViewBase)
UISupplyChips.RESOURCE_FILENAME = "UISupplyChips.csb"
--UISupplyChips.RESOURCE_PRELOADING = {"hall.png"}

UISupplyChips.RESOURCE_BINDING = {
    ["Button_close"]      = {["ended"] = "backEvent"},
    ["Button_buy"]     = {["ended"] = "buyChip"},
    ["Slider_chip"]   = {["ON_PERCENTAGE_CHANGED"] = "addChipsSlider"}, 

}

function UISupplyChips:backEvent(event) 
    self.app:removeView("UISupplyChips")
end

function UISupplyChips:buyChip(event) 
    local app = self.app
    local str = tonumber(self['Text_addChip']:getString())
    if self.cb then 
        self.cb(str)
    end     
    --app:callMethod('UIGameHall','initBuyChips',str)
    app:removeView('UISupplyChips')
end

function UISupplyChips:addChipsSlider(event)
    local percent = event.target:getPercent()
    local num = self.max/100*percent
    self['Image_move']:setPosition(self["Slider_chip"]:getContentSize().width*percent/100,self['Image_move']:getPositionY())  
    self['Text_addChip']:setString(math.floor(num))  
end


function UISupplyChips:onCreate(max,cb)
 
    local app = self:getApp()
    self.app = app
    self.cb = cb 
    self.PlayerData =app:getData('PlayerData')
    self["Button_close"]:setPressedActionEnabled(false)
    --self["Button_buy"]:setPressedActionEnabled(false)
    self['Text_maxCoin']:setString(max)
    self["Slider_chip"]:setPercent(50) 
    self.max = max 
    self['Text_addChip']:setString(self.max/2)
    self['Image_move']:setAnchorPoint(cc.p(0.5,0.5))
    local sx, sy = self.app:getModel('Tools'):getUIScale()

    self.width = self["Panel_model"]:getContentSize().width * sx
    self['Text_total']:setString(self.PlayerData.coin)

end

return UISupplyChips

