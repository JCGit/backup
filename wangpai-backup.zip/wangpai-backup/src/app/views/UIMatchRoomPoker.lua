local UIMatchRoomPoker = class("UIMatchRoomPoker", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
UIMatchRoomPoker.RESOURCE_FILENAME = "UIMatchRoomPoker.csb"
--UIMatchRoomPoker.RESOURCE_PRELOADING = {"main.png"}
--UIMatchRoomPoker.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIMatchRoomPoker.RESOURCE_BINDING = {  
    ["Button_QuickStart"] = {["ended"] = "onQuickStart"},
    ["Button_chargeGem"]     = {["ended"] = "enterChargeDiamond"},
} 

--[=================扑克牌场次================]--
local DURATION_SWITCH_MOVE = 0.2
local TAG_BEGINNER = 'beginner'
local TAG_PRO = 'pro'
local TAG_SPEEDUP = 'speedup'

--更新金币
function UIMatchRoomPoker:updatePlayerCoin(_coin)
    _coin = _coin or self.pData.coin
    self['Text_myMoney']:setString(LuaTools.convertAmountChinese(self.pData.coin))
end


--进入充值砖石
function UIMatchRoomPoker:enterChargeDiamond()
    G_BASEAPP:addView('UIQuickBuy', 1200,function(arg) 
        -- self.pData.coin = arg.coin 
        self['Text_myMoney']:setString(LuaTools.convertAmountChinese(self.pData.coin))
    end) 
end


function UIMatchRoomPoker:enterCharge() 
    if not G_BASEAPP:getView('UIShopDiamond') then 
        G_BASEAPP:addView('UIShopDiamond', 1200,function(arg) 
            self['Text_myMoney']:setString(LuaTools.convertAmountChinese(self.pData.coin))
        end) 
    end   
end     

--检测金币对否小于0，并且是否该弹出充值
function UIMatchRoomPoker:checkChips(val, text)
    if tonumber(self.pData.coin) <= val then
        local function onConfirm()
            if self.pData.gem > 0 then 
                self:enterChargeDiamond()
            else 
                self:enterCharge() 
            end  
        end
        local dlg = self.app:addView('UIDialog', self:getLocalZOrder() + 1, nil, true)
        dlg:setupDialog('金币不足', text, onConfirm, nil, false)
        return false
    end
    return true
end

--退出后回调
function UIMatchRoomPoker:onExit() 
    if self.onExiting == nil then 
        self.onExiting = true
        if self.isEnterGameRoom == nil then
            self.app:callMethod('UIMain', 'showEnterMainActions') 
        end
    end
end

--点击快速开始
function UIMatchRoomPoker:onQuickStart()
    if self:checkChips(0, Constants.STRING_NO_MONEY) == false then return end
    --判断该进入哪一个场次
    local myChips = tonumber(self.pData.coin)
    local indexRoom = 0

    --判断是金币条件符合进入显示的房间
    local minChipsRoom_1 = math.floor(self.gameDataSel[1].maxChips/10)
    if myChips < minChipsRoom_1 then      --自身的金币小于最小携带
        self:checkChips(minChipsRoom_1, "您的金币小于这些游戏场的最小携带，是否去充值？")
        return
    end

    --倒数循环判断可进入的场次
    for i = #self.gameDataSel, 1, -1 do
        local maxChips = self.gameDataSel[i].maxChips
        local minChips = math.floor(maxChips/10)
         print("My Chips: "..myChips.." min: "..minChips.." max: "..maxChips)
        if myChips >= minChips then 
            indexRoom = i     
            break       --如果进入在小携带和大携带之间，进入对应的房间
        end
    end

    if indexRoom > 0 then
        self:enterRoom(indexRoom)
    else
        self.tool:showTips("无法匹配到可进入的房间")
    end
    
end

--检测金币是否足够进入该场次
function UIMatchRoomPoker:checkEnabledEnterRoom(_index)
    local myChips = tonumber(self.pData.coin)
    local maxChips = self.gameDataSel[_index].maxChips
    local minChips = math.floor(maxChips/10)
    print("Min chips to enter: "..minChips.."    Max chips: "..maxChips)
    if myChips < minChips then      --自身的金币小于最小携带
        self.tool:showTips("您的金币小于该游戏场的最小携带")
    else  --可以进入游戏
        self:enterRoom(_index)
    end
end

--根据已选择的场次进入对应的游戏
function UIMatchRoomPoker:enterRoom(_index)
    --self.isEnterGameRoom = true
    --dump(self.gameDataSel[_index], "ENTERING ROOM INFOS")
    local tableType
    if self.isSelect_6_Players == true then  --选择了6人场
        tableType = self.gameDataSel[_index].tType_6
    else
        tableType = self.gameDataSel[_index].tType_9
    end
    -- local load = G_BASEAPP:addView("UILoading",200)  
    -- G_LOADINGVIEW = load
    -- load:setLoadingType(true)
    -- load:setNextAction(function()
    --     G_BASEAPP:addView("UIGameTableDeZhou",500, tableType)  
    -- end)
    -- load:startProgress()
    G_BASEAPP:addView("UIGameTableDeZhou",500, tableType)  
end

--打印数据
function UIMatchRoomPoker:printRoomData(dataname, viewname, siteId, roomId, port)
    local tb = {
        dataname = dataname,
        viewname = viewname,
        siteId = siteId,
        roomId = roomId,
        port = port,
    }
    --dump(tb,"RoomData")
end

--展示进入动作
function UIMatchRoomPoker:showEnterActions()
    --background actions
    local maskLayer = cc.LayerColor:create(cc.c4b(255,255,255,0))
    self['Panel_main']:addChild(maskLayer,-1)
    maskLayer:runAction(cc.Sequence:create(
        cc.FadeTo:create(0.5, 80),
        cc.FadeTo:create(0.2, 0),
        cc.CallFunc:create(function() maskLayer:removeFromParent() end)
        ,nil))

    self['Panel_bgd']:setOpacity(0)
    self['Panel_bgd']:runAction(cc.FadeTo:create(0.6,255))

    --widgets actions
    local btstart = self['Button_QuickStart']
    local moveIn = cc.MoveTo:create(0.6,cc.p(btstart:getPositionX(),72))
    local move_ease_out = cc.EaseBackOut:create(moveIn)
    btstart:runAction(move_ease_out)

    local panelSlider = self['Panel_players']
    local moveInzz = cc.MoveTo:create(0.6,cc.p(panelSlider:getPositionX(),27))
    local move_ease_outzz = cc.EaseBackOut:create(moveInzz)
    panelSlider:runAction(move_ease_outzz)

    local panelTop = self['Panel_top']
    local moveIn2 = cc.MoveTo:create(0.6,cc.p(panelTop:getPositionX(),cc.Director:getInstance():getWinSize().height))
    local move_ease_out2 = cc.EaseBackOut:create(moveIn2)
    panelTop:runAction(move_ease_out2)

    local menuButtons = self['Panel_menubuttons']
    menuButtons:setVisible(false)
    local act = cc.Sequence:create(
        cc.ScaleTo:create(0.01, 0),
        cc.CallFunc:create(function() menuButtons:setVisible(true) end),
        cc.ScaleTo:create(0.5, 1.1),
        cc.ScaleTo:create(0.24,1)
        ,nil)
    menuButtons:runAction(act)
end

function UIMatchRoomPoker:showListviewEnterActions()
    --listview items actions
    local listview = self['ListView_type']
    local function moveBackAfter(delay, byX)
        local backVal = 80
        if byX < 0 then
            backVal = -backVal
        end
         local moveIn = cc.MoveBy:create(delay,cc.p(byX+backVal,0))
         local moveOff = cc.MoveBy:create(0.2,cc.p(-backVal,0))
         return cc.Sequence:create(moveIn, moveOff)
    end
    for i,item in ipairs(listview:getChildren()) do
        --local moveIn = cc.MoveBy:create(0.47,cc.p(-self.winWidth,0))
        --local move_ease_in = cc.EaseBackOut:create(moveIn)
        --item:runAction(cc.Sequence:create(cc.DelayTime:create(i/10+0.2),move_ease_in,nil))
        item:runAction(cc.Sequence:create(cc.DelayTime:create(i/10+0.2),moveBackAfter(0.2,-self.winWidth),nil))
    end
end

function UIMatchRoomPoker:onCreate()
    local app = self:getApp()
    self.app = app
    --LuaTools.viewAction2(self['Panel_main'])
    self.pData = app:getData('PlayerData')
    self.tool = app:getModel('Tools')
    --self.sound = app:getModel('Sound')
    self.config = app:getData('Config')
    cc.SpriteFrameCache:getInstance():addSpriteFrames("res_gametypes.plist")
    self.winWidth = cc.Director:getInstance():getWinSize().width

    self.gameDataSel = Constants.POKER_ROOMS_DATA[TAG_BEGINNER]

    local function onClose(event)
        if event.name == 'began' then
        elseif event.name == 'ended' then 
            self:removeSelf()
            --LuaTools.viewAction2Over(self['Panel_main'],'UIMatchRoomPoker')
        end
    end
    self['Button_QuickStart']:setPressedActionEnabled(false)
    self['Button_close']:onTouch(onClose)
    self['Text_myMoney']:setString(LuaTools.convertAmountChinese(self.pData.coin))

    
    self:initMenuButtons()
    self:showEnterActions()
    self:initSliderPlayers()
    --self:startUpdateCounts()
    if self.pData.onlinePlayerNumber ~= 0 then 
       self:updatePlayerCounts(self.pData.onlinePlayerNumber)
    end   
end

--初始化场次UI
function UIMatchRoomPoker:initRooms()
    local _array = self.gameDataSel
    --dump(_array)
    local listview = self['ListView_type']
    local itemModel = self['Panel_Item']

    itemModel:setVisible(false)
    itemModel:setBackGroundColorOpacity(0)

    listview:setItemModel(itemModel)
    listview:setBounceEnabled(false)
    listview:setScrollBarEnabled(false)
    listview:setBackGroundColorOpacity(0)
    itemModel:setBackGroundColorOpacity(0)
    listview:removeAllChildren()

    --点击房间
    local function onEnterRoom(event)
        if event.name == 'began' then
        elseif event.name == 'ended' then
            if self:checkChips(0, Constants.STRING_NO_MONEY) == false then return end
           local tag = event.target:getTag()
           self:checkEnabledEnterRoom(tag)
        end
    end

    for key ,var in ipairs(_array) do
        listview:pushBackDefaultItem()
        local item = listview:getItem(key-1) 

        item:getChildByName('Text_count'):setString('0')
        item:getChildByName('Text_desc'):setString("盲注："..LuaTools.convertAmountChinese(var.minBlind)..'/'..LuaTools.convertAmountChinese(var.minBlind*2))
        
        item:setTag(key)
        item:setTouchEnabled(true)
        item:onTouch(onEnterRoom)
        
        item:getChildByName('Image_bgdRoom'):loadTexture("game/texus_chip"..key..".png", ccui.TextureResType.plistType)
        item:getChildByName('Text_maxStack'):setString(LuaTools.convertAmountChinese(var.maxChips))
        
        item:runAction(cc.Sequence:create(
         cc.MoveBy:create(0.1,cc.p(self.winWidth,0)),
         cc.CallFunc:create(function() item:setVisible(true) end)
         ,nil))
    end 

    self:showListviewEnterActions()
end

--初始化场次按钮
function UIMatchRoomPoker:initMenuButtons()
    local btPanel = self['Panel_menubuttons']
    self.indexGameSelected = -1

    --切换按钮
    local function onChangeGame(event)
        if event.name == 'ended' then
            local index = event.target:getTag()
            self:showButton(index)
            --1秒钟内禁止点击任何按钮
            for i=1,3 do
                local bt = btPanel:getChildByName('Panel_bt'..i)
                LuaTools.freezeWidget(bt, 1)
            end
        end
    end

    for i=1,3 do   --按钮个数
        local bt = btPanel:getChildByName('Panel_bt'..i)
        bt:setBackGroundColorOpacity(0)
        bt:setTouchEnabled(true)
        bt:setTag(i)
        bt:onTouch(onChangeGame)
    end

    self:showButton(1)
end

--显示对应的场次类型按钮
function UIMatchRoomPoker:showButton(_index)
    if self.indexGameSelected == _index then return end
    local btPanel = self['Panel_menubuttons']
    if self.indexGameSelected > 0 then
        local oldImgTitle = btPanel:getChildByName('Panel_bt'..self.indexGameSelected):getChildByName("Image_title")
        oldImgTitle:loadTexture("game/texus_head"..self.indexGameSelected.."Unselect.png", ccui.TextureResType.plistType)
    end
    local newImgTitle = btPanel:getChildByName('Panel_bt'.._index):getChildByName("Image_title")
    newImgTitle:loadTexture("game/texus_head".._index.."Select.png", ccui.TextureResType.plistType)
    local imgBack = btPanel:getChildByName('Image_chooseBt')
    imgBack:setPositionX(btPanel:getChildByName('Panel_bt'.._index):getPositionX())
    self:switchRoomDataView(_index)
    self.indexGameSelected = _index
end

--切换按钮后获取对应的房间信息
function UIMatchRoomPoker:switchRoomDataView(_index)
    if _index == 1 then
        self.gameDataSel = Constants.POKER_ROOMS_DATA[TAG_BEGINNER]
    elseif _index == 2 then
        self.gameDataSel = Constants.POKER_ROOMS_DATA[TAG_PRO]
    elseif _index == 3 then
        self.gameDataSel = Constants.POKER_ROOMS_DATA[TAG_SPEEDUP]
    end
    self:initRooms()  --显示新的房间
end

--初始化选择房间人数滑动按钮
function UIMatchRoomPoker:initSliderPlayers()
    local function move(_target, _toOn)
        local parent = _target:getParent()
        local move
        if _toOn == false then 
            move = cc.MoveTo:create(DURATION_SWITCH_MOVE,cc.p(parent:getContentSize().width, _target:getPositionY()))
        else
            move = cc.MoveTo:create(DURATION_SWITCH_MOVE,cc.p(_target:getContentSize().width, _target:getPositionY()))
        end
        _target:runAction(move)
    end

    --切花状态
    local function onSwitchState(event)
        if event.name == 'ended' then
            self.isSelect_6_Players = not self.isSelect_6_Players
            move(event.target:getChildByName('Image_circle'), self.isSelect_6_Players)
            self:initRooms()   --重新显示新的房间  6人/9人
            LuaTools.freezeWidget(event.target, 1)
        end
    end

    self.isSelect_6_Players = false   --默认按钮状态为选择9人坐的房间

    local panel = self['Panel_players']
    panel:onTouch(onSwitchState)
    panel:setBackGroundColorOpacity(0)
    panel:setTouchEnabled(true)
    local img_circle = panel:getChildByName('Image_circle')
    
    if self.isSelect_6_Players == false then
        img_circle:runAction(cc.MoveTo:create(0.01,cc.p(panel:getContentSize().width,img_circle:getPositionY())))
    else
        img_circle:runAction(cc.MoveTo:create(0.01,cc.p(img_circle:getContentSize().width,img_circle:getPositionY())))
    end

    
end

--启动更新玩家个数
function UIMatchRoomPoker:startUpdateCounts()
    self.app:callMethod('UIMain','reqSock_getOnliner')
    self:createSchedule("updateCounts",function()
        self.app:callMethod('UIMain','reqSock_getOnliner')
    end,self.config.refreshPlayerCountsDelay)
end

--更新玩家个数
function UIMatchRoomPoker:updatePlayerCounts(_table)
   -- dump(_table)
   print("Updating rooms players count...")
     local items = self['ListView_type']:getChildren()
    for i,v in ipairs(#self.gameDataSel) do
        local count
        if self.keyGame == Constants.KEY_ZJH then  --扎金花
            count = _table['60'][tostring(i-1)]
        else
            count = _table[tostring(v.siteid)][tostring(i-1)]
        end
        items[i]:getChildByName('Text_count'):setString(count)
    end
end


return UIMatchRoomPoker
