local UIBindAccountDialog = class("UIBindAccountDialog", cc.load("mvc").ViewBase)

UIBindAccountDialog.RESOURCE_FILENAME = "UIBindAccountDialog.csb"
--UIBindAccountDialog.RESOURCE_PRELOADING = {"main.png"}
--UIBindAccountDialog.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIBindAccountDialog.RESOURCE_BINDING = { 
    ["Button_cancel"] = {["ended"] = "onCancel"},
    ["Button_confirm"] = {["ended"] = "onConfirm"},
    ["Button_one"] = {["ended"] = "confirm"},
}

function UIBindAccountDialog:onCancel() 
    
    local function cb()
        if self.cb then
          self.cb()
        end
    end
    LuaTools.viewAction1Over(self['Panel_Layer'],'UIBindAccountDialog',cb)
end

function UIBindAccountDialog:onConfirm()   
    
    LuaTools.viewAction1Over(self['Panel_Layer'],'UIBindAccountDialog')
    self.app:addView("UILoginBindAccount", self:getLocalZOrder()+1)
end

function UIBindAccountDialog:onCreate(_cb)
    local app = self:getApp()
    self.app = app
    self.pData = app:getData('PlayerData')
    self.tool = app:getModel('Tools')
    self.config = app:getData('Config')
    self.cb = _cb
    self.pData.isBindAccountDlgShowed = true
    -- --self.sound = app:getModel('Sound')
     
    LuaTools.viewAction1(self['Panel_Layer']) 
    self['Text_line1']:setString("亲爱的["..self.pData.nick.."]您当前的账号为游客账号")
    self['Text_line2']:setString("为保障您的权益,我们强烈建议您完善您的账号信息!")
end

return UIBindAccountDialog
