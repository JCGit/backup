local UIHelpDDZRunFast= class("UIHelpDDZRunFast", cc.load("mvc").ViewBase)
UIHelpDDZRunFast.RESOURCE_FILENAME = "UIHelpDDZRunFast.csb"
local HttpHandler = require("app.network.HttpHandler")

UIHelpDDZRunFast.RESOURCE_BINDING = { 
      ["Panel_main"] = {["ended"] = "hideAll"}, 

}

function UIHelpDDZRunFast:onCreate()
    local app = self:getApp()
    self.app = app
    self.config = app:getData('Config')
    self.tool = app:getModel('Tools')
    self.pData = app:getData('PlayerData') 
    
    self.sizes = self['Panel_root']:getContentSize()
    local move = cc.MoveBy:create(0.3,cc.p(self.sizes.width,0))
    self['Panel_root']:runAction(move)

end

function UIHelpDDZRunFast:hideAll()
    self.app:removeView('UIHelpDDZRunFast')
end     

return UIHelpDDZRunFast








