local UIDailypacks = class("UIDailypacks", cc.load("mvc").ViewBase)

UIDailypacks.RESOURCE_FILENAME = "UIDailypacks.csb"
--UIDialog.RESOURCE_PRELOADING = {"main.png"}
--UIDialog.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}
local HttpHandler = require("app.network.HttpHandler")

UIDailypacks.RESOURCE_BINDING = { 
    ["Button_close"] = {["ended"] = "exitScene"},
    ["Button_buy"] = {["ended"] = "confirm"},

    }



function UIDailypacks:exitScene() 
    if self.cbs then
        self.cbs()
    end   
    LuaTools.viewAction1Over(self['Panel_main'],"UIDailypacks",nil, self)
end

function UIDailypacks:onCreate(cb)
    local app = self:getApp()
    self.app = app
    self.config = app:getData('Config')
    self.tool  = app:getModel('Tools')
    self.pData = self.app:getData('PlayerData')
    self.cbs = cb 
    print('jinrule')
    local function  cb1()
      local dataTable =     {
          ['uid']    = G_UID,
          ['token']  = G_TOKEN,
          ['cid']    = 8,
          ['cmd']    = HttpHandler.CMDTABLE.GET_PRODUCT,
      }
      local function succ(arg)
          --self:parseProductData(arg)
          dump(arg,'每日礼包内容')
          self.payInfo = arg.products[1]
          self:initUI(self.payInfo)
      end
      local function fail(arg)
          if arg.msg then
              self.tool:showAlert(arg.msg)
          end
      end
      self.tool:fastRequest(dataTable,succ, fail)
    end     
    LuaTools.enterActionScaledWithMask(self['Panel_main'],cb1)
end   

function UIDailypacks:initUI(info)
    local imageTab = {'res_reward/jinbi.png','res_reward/yunbao.png','res_reward/zhouka.png',
       'res_reward/laba.png','res_reward/tirenka.png','res_reward/vip_icon.png'} 
    local tag = 1    
    if info.coins and tonumber(info.coins) > 0  then     
        self['Image_reward'..tag]:loadTexture(imageTab[1],ccui.TextureResType.plistType)
        self['Text_reward'..tag]:setString(LuaTools.convertAmountChinese(info.coins)..'金币')
        tag = tag + 1 
    end     

    if info.gems and tonumber(info.gems) > 0  and tag <=4 then     
        self['Image_reward'..tag]:loadTexture(imageTab[2],ccui.TextureResType.plistType)
        self['Text_reward'..tag]:setString(info.gems..'个元宝')
        tag = tag + 1 
    end     

    if info.prop and info.prop['4'] and  tonumber(info.prop['4']) > 0  and tag <=4 then     
        self['Image_reward'..tag]:loadTexture(imageTab[5],ccui.TextureResType.plistType)
        self['Text_reward'..tag]:setString(info.prop['4']..'张踢人卡')
        tag = tag + 1 
    end   

    if info.prop and info.prop['7'] and  tonumber(info.prop['7']) > 0  and tag <=4 then     
        self['Image_reward'..tag]:loadTexture(imageTab[4],ccui.TextureResType.plistType)
        self['Text_reward'..tag]:setString(info.prop['7']..'张喇叭卡')
        tag = tag + 1 
    end   

    if info.vip and info.vip['1'] and  tonumber(info.vip['1']) > 0  and tag <=4 then     
        self['Image_reward'..tag]:loadTexture(imageTab[3],ccui.TextureResType.plistType)
        self['Text_reward'..tag]:setString(info.vip['1']..'张Vip周卡' )
        tag = tag + 1 
    end

    if info.vip_day and tonumber(info.vip_day) > 0  and tag <=4 then     
        self['Image_reward'..tag]:loadTexture(imageTab[6],ccui.TextureResType.plistType)
        self['Text_reward'..tag]:setString('Vip成长值+'..info.vip_day)
        tag = tag + 1 
    end     

    self['BitmapFontLabel_now']:setString(info.price or '')
    self['BitmapFontLabel_pre']:setString(info.oldprice or '')

end     

function UIDailypacks:confirm()   
    if self.payInfo then 
       self.app:addView('UICharge',self:getLocalZOrder()+10,self.payInfo, self.cbs)
    end    
end


return UIDailypacks
