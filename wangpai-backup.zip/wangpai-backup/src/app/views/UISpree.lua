
local UISpree = class("UISpree", cc.load("mvc").ViewBase)
UISpree.RESOURCE_FILENAME = "UISpree.csb"

local HttpHandler = require("app.network.HttpHandler")
UISpree.RESOURCE_PRELOADING = {"res_fund.png",'res_newFunction.png'}
--UISpree.RESOURCE_LOADING  = {["res/background/mohuBg.png"] = {names = {"Image_bgAll"}}}
UISpree.RESOURCE_BINDING = {
    ["Button_back"] = {["ended"] = "backEvent"}, 
    ["Button_1"] = {["ended"] = "getPackage"}, 
    ["Panel_1"] = {["ended"] = "backEvent"}, 



}

--printWarning
 

function UISpree:backEvent()
    --self:removeFromParent()
    if self.cb2 then 
       self.cb2() 
    end   
    LuaTools.viewAction1Over(self['Panel_Layer'],'UISpree')  

end

function UISpree:getPackage() 
    self.app:addView('UICharge',self:getLocalZOrder()+10,self.payInfo, self.cb)
end

 function UISpree:initUI(argTable)
    local vCard = {'VIP周卡','VIP月卡','VIP年卡'}
    self.Text_diomend:setString('元宝x'..(argTable.gems or "1"))
    self.Text_coin:setString('金币x'..(math.modf(argTable.coins/10000) or "2")..'万')
    self.Text_card:setString('VIP周卡x'..(argTable.vip['1'] or 1)) 
    self.Text_speaker:setString('喇叭x'..(argTable.prop['4'] or "4"))
    self.Text_kikcard:setString('踢人卡x'..(argTable.prop['7'] or "5"))

    --self.Text_bought:setString((argTable.buynum or "6789"))  
    --self['Text_AllPeople']:setString(argTable.sold)
    
    -- if argTable.sold  and tonumber(argTable.sold) ~= 0 then 
    --     local length = string.len(argTable.sold)
    --     for key=1,length  do 
    --         self['Text_buy'..6-key]:setString(string.sub(argTable.sold,length+1-key,length+1-key))
    --     end 
    -- end         

 end

function UISpree:onCreate(cb1,cb2) 
    self.app = self:getApp() 
    self.tool = self.app:getModel('Tools')
    self.config = self.app:getData('Config')
    self.cb = cb1
    self.cb2 = cb2
    self.PlayerData = self.app:getData('PlayerData')
    -- cc.SpriteFrameCache:getInstance():addSpriteFrames("res_newFunction.plist")

    --self.deviceInfos = LuaTools.getAllInfomationYouNeeded()
    local leftImage = {'res_fund/left1.png','res_fund/left2.png','res_fund/left3.png','res_newFunction/left4.png'}
    local rightImage = {'res_fund/right1.png','res_fund/right2.png','res_fund/right3.png','res_newFunction/right4.png'}
    local headImage = {'res_fund/haed1.png','res_fund/haed2.png','res_fund/haed3.png','res_newFunction/haed4.png'}
    if tonumber(self.PlayerData.gpackFlag) < 4 then 
      self['Image_head']:loadTexture(headImage[tonumber(self.PlayerData.gpackFlag)+1],ccui.TextureResType.plistType)
      self['Image_left']:loadTexture(leftImage[tonumber(self.PlayerData.gpackFlag) +1],ccui.TextureResType.plistType)
      self['Image_right']:loadTexture(rightImage[tonumber(self.PlayerData.gpackFlag) +1],ccui.TextureResType.plistType)
    end 

    local function  cb()
     local dataTable =     {
          ['uid']   =  tonumber(G_UID),
          ['token']     = G_TOKEN,
          --['packid']    = 60,
          --['imsi']      = self.deviceInfos.imsi
          ['cmd']       = HttpHandler.CMDTABLE.GET_GIFTPACK,
        }
        local function succ(arg)
           dump(arg,'小额礼包请求成功')
            if arg.list[self.PlayerData.gpackFlag+1]  then 
               self.payInfo = arg.list[self.PlayerData.gpackFlag+1] 
               self:initUI( arg.list[self.PlayerData.gpackFlag+1] )
            end    
        end
        local function fail(arg) 
             -- self.app:addView('UIAlert',1000)
             -- :setupDialog('Infomation',arg.msg)
             self.app:removeView('UISpree')
        end
        self.tool:fastRequest(dataTable,succ)
    end     
    
     LuaTools.enterActionScaledWithMask(self['Panel_Layer'],cb)

     local time_now = os.date("*t") 
     local SpreeTagBuy = time_now.year..time_now.month..time_now.day
     cc.UserDefault:getInstance():setStringForKey("SpreeTagBuy",SpreeTagBuy) 
 end
 

return UISpree
