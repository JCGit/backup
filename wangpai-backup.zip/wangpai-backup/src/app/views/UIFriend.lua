
local UIFriend = class("UIFriend", cc.load("mvc").ViewBase)
UIFriend.RESOURCE_FILENAME = "UIFriend.csb"

local HttpHandler = require("app.network.HttpHandler")
--UIFriend.RESOURCE_PRELOADING = {"social.png"}
--UIFriend.RESOURCE_LOADING  = {["res/background/mohuBg.png"] = {names = {"Image_bgAll"}}}
UIFriend.RESOURCE_BINDING = {
    ["Button_back"]       = {["ended"] = "backEvent"},
    ["addFriendButton"]   = {["ended"] = "addFriendEvent"},
    ["Button_friend"]     = {["ended"] = "listfriend"},
    ["ListView_left"]     = {["ON_SELECTED_ITEM_END"] = "selectEvent"},   
    ["Button_addfriend"]  = {["ended"] = "addFriendEvent"},
    ["Button_invitefriend"]   = {["ended"] = "invite"},
    ['Button_createWedding']  = {["ended"] = "enterWeddingRoom"},
    ['Button_refreshWed']     = {["ended"] = "refreshWedding"}, --刷新列表
}

function UIFriend:invite(event)
   LuaTools.openURL(DEFAULT_HTTP_URL..HttpHandler.CMDTABLE.SHARE.."?uid="..tonumber(G_UID).."&unionid=G_CHANNELID",'url')
end

function UIFriend:enterWeddingRoom()
  
   self.app:addView('UIFriendWeddingCreate',130)
end 

function UIFriend:selectEvent(event)
    LuaTools.playBtSound()
    local index = event.target:getCurSelectedIndex()+1
    self:swithchPage(self.lastSelectedIndex,index)  
end

function UIFriend:swithchPage(from,to)
    if not to or to == 0 then return end 
    local butTab  = {self['Button_type_1'],self['Button_type_2']} 
    local panelTab = {self['Panel_friend'],self['Panel_wedding']}
    if from and from ~= 0 then 
       butTab[from]:loadTextures('res_rank/btn_unselect.png','res_rank/btn_unselect.png','res_rank/btn_unselect.png',ccui.TextureResType.plistType)
       panelTab[from]:setVisible(false)
       butTab[from]:setTitleColor(cc.c3b(255,233,178))--(self.config.ColorTextUnselect)
    end 

    butTab[to]:loadTextures('res_rank/btn_select.png','res_rank/btn_select.png','res_rank/btn_select.png',ccui.TextureResType.plistType)
    panelTab[to]:setVisible(true)
    self.lastSelectedIndex = to 
    butTab[to]:setTitleColor(cc.c3b(255,255,255))
    if from ~= to then 
          self:initContent(to)
    end    
end 




function UIFriend:backEvent()
  
   UserCache.saidHelloToUser = false
   LuaTools.viewAction1Over(self['Panel_main'],'UIFriend')
   --G_BASEAPP:removeView('UIFriend')
end




function UIFriend:addFriendEvent()   
  self.app:addView('UIAddFriend',302) 
end


function UIFriend:onCreate(type,id)
    local app = self:getApp()
    self.model = app:getModel("Social")
    self.lastSelectedIndex = 1 
    self.addFriend =  self['addFriendButton']
    self.app = app
    self.num = 0  
    self.playerdata = self.app:getData('PlayerData')
    self.config = app:getData('Config')
    self.tool = app:getModel('Tools')

    self.roomType = type
    self.roomId   = id 
    self["ListView_left"]:setScrollBarEnabled(false)
    local tab_maxFriend = {12,13,15,16,18,20,22,24,26,28,30,32,35,40,50}
    self.maxFriendNum = self.playerdata.vip_level == 0 and 5 or tab_maxFriend[tonumber(self.playerdata.vip_level)]
    local item = self['Button_cell']
    self['ListView_friend']:setItemModel(item)
    item:removeFromParent()
    UserCache.readCSHistory()
     local spriteFrameCache = cc.SpriteFrameCache:getInstance()
     spriteFrameCache:addSpriteFrames("common.plist")

     LuaTools.enterActionScaledWithMask(self['Panel_main'],function() self:swithchPage(2,1) end)
   
    self['Button_addfriend']:setPressedActionEnabled(true)
    --self['Button_invitefriend']:setPressedActionEnabled(true)
    self['Panel_wedding']:setVisible(false)
    for key = 1 ,2 do  
        self['Button_type_'..key]:setPressedActionEnabled(false)
    end   

    local temp = self['Panel_itemWed']
    self['ListView_wedding']:setItemModel(temp)

end

function UIFriend:refreshWedding()
    
    local playerdata = self.app:getData('PlayerData')
    local paTable =     {
        ['uid']   = tonumber(playerdata.uid),
        ['token'] = G_TOKEN,
        ['cmd']   = HttpHandler.CMDTABLE.GET_WEDDING_LIST }  
    local function succ(arg) 
        self:updateWeddingList(arg.room)    
    end    
    local function fail()
      self['Image_noData']:setVisible(true)
    end  
    self.tool:fastRequest(paTable,succ,fail,false)
    self.tool:freezeWidget(self['Button_refreshWed'], 3)
end 

function UIFriend:initContent(_type)
    local playerdata = self.app:getData('PlayerData')
    self['Image_noData']:setVisible(false)
    local temp_tpye = (_type == 1  and HttpHandler.CMDTABLE.GET_FRIEND_LIST or HttpHandler.CMDTABLE.GET_WEDDING_LIST)
    local paTable =     {
        ['uid']   = tonumber(playerdata.uid),
        ['token'] = G_TOKEN,
        ['cmd']   = temp_tpye }  
    local function succ(arg) 
        self['Image_noData']:setVisible(false)
        if _type == 1 then  --friend
          self:updateList(arg.items)
        else  --wedding
          self:updateWeddingList(arg.room)
        end   
    end    
    local function fail()
      self['Image_noData']:setVisible(true)
       if  _type == 1 then  --friend 
           self['ListView_friend']:removeAllChildren()
           self['Text_friendlimit']:setString('好友人数上限:0'..'/'..self.maxFriendNum) 
           local function cccc()
              self['Image_noFriend']:setVisible(true)
           end 
           self['Image_noFriend']:runAction(cc.Sequence:create(cc.DelayTime:create(2),cc.CallFunc:create(cccc)))   
       end 
    end  
    self.tool:fastRequest(paTable,succ,fail)
end


function UIFriend:getRoomName(id)
    local temp = {           ["1"] = "炸翻天场", 
                             ["2"] = "炸翻天场",
                             ["3"] = "炸翻天场",
                             ["4"] = "炸翻天场",
                             ["5"] = "炸翻天场",
                             ["7"] = "炸翻天场",
                             ["9"] = "斗牛场",
                            ["17"] = "抢地主场",
                            ["18"] = "抢地主场",
                            ["33"] = "大奖赛场",
                            ["48"] = "五人斗牛场",      
                            ["49"] = "五人斗牛场",
                            ["50"] = "五人斗牛场",
                            ["51"] = "五人斗牛场",
                            ["60"] = "欢乐赢三张",
                            ["61"] = "欢乐赢三张",
                            ["62"] = "欢乐赢三张",
                            ["63"] = "欢乐赢三张",
                            ["64"] = "欢乐赢三张",
                            ["65"] = "欢乐赢三张",
                            ['66'] = '欢乐赢三张',
                            ["14"] = "婚礼场",
                 } 
    local str  
    if tonumber(id) < 0 then 
        str = '离线'
    else      
        for key,var in pairs(temp) do 
            if tonumber(id) == tonumber(key) then 
               str = var 
               break 
            end 
        end                
    end       
    if not str then str = '在线' end 

    return '当前状态:'..str 
end 

function UIFriend:updateList(info)
    local pData = self.app:getData('PlayerData')
    local delayTime = 0.8
    local function touchItem(event) 
        if event.name == 'began' or event.name == 'moved'then
           if self.FriendScheduler == nil then 
               local function  countNum()
                   self.num = self.num + 0.5 
               end 
               self.FriendScheduler = self:createSchedule("FriendScheduler", countNum, 0.1)
           end
        elseif event.name == 'cancelled' then  
           self:stopSchedule('FriendScheduler')
           self.FriendScheduler = nil 
            self.num = 0 
        elseif event.name == 'ended' then 
           self:stopSchedule('FriendScheduler')
           self.FriendScheduler = nil             
           if self.num >=delayTime then                  
              self.app:addView('UIDialog', 200)
              self.app:callMethod('UIDialog','setupDialog', '', '你确定要删除该好友吗？',
              function()
                local dataTable   =     {
                    ['uid']       = tonumber(G_UID),
                    ['token']     = G_TOKEN,
                    ['fuid']      = event.target:getTag(),
                    ['cmd']       = HttpHandler.CMDTABLE.DEL_FRIEND,
                  }
                  local function succ(arg)
                      if arg.msg then
                         self:initContent(1)
                         for k,v in pairs(pData.friendUidList) do 
                             if tonumber(v) == tonumber(event.target:getTag()) then 
                                table.remove(pData.friendUidList,k)
                             end 
                         end        
                      end
                  end
                  self.tool:fastRequest(dataTable,succ)
              end)
           else
             local tab_aaaa = {} 
             tab_aaaa.uid = event.target:getTag()
             tab_aaaa.tag = 1 
             self.app:addView('UIFriendBrief',312,tab_aaaa)
           end 
           self.num = 0 
        end
    end
    local function chat(event)
        if event.name == 'ended'  then
            local uid = event.target:getParent():getTag()   
            self.app:addView('UIChat',323,2,uid)
            event.target:getChildByName('Image_redPoint'):setVisible(false)
        end
    end    
    self['Text_friendlimit']:setString('好友人数上限：'..#info..'/'..self.maxFriendNum)
    self['ListView_friend']:removeAllChildren()
    if info and #info>=1 then 
      pData.friendUidList = {}
      for key =1 ,#info do
          local val = info[key]
          table.insert(pData.friendUidList,val.uid)
          self['ListView_friend']:pushBackDefaultItem()
          local model = self['ListView_friend']:getItem(key-1)
          model:setPressedActionEnabled(false)
          model:setVisible(true)
          model:onTouch(touchItem)
          model:setTag(val.uid)
          model:getChildByName('Button_chat'):onTouch(chat)
          model:getChildByName('Image_vipframe'):setVisible(val.vip > 0)
          model:getChildByName('Image_vipframe'):setLocalZOrder(101)
          model:getChildByName('Image_vipframe'):loadTexture(val.vipvalid<=7 and 'common/icon_vip_bg_0.png' or 
            (val.vipvalid>30 and 'common/icon_vip_bg_2.png' or 'common/icon_vip_bg_1.png') ,ccui.TextureResType.plistType)
          model:getChildByName('Image_vipframe'):getChildByName('Text_viplevel'):setString('V'..val.vip)
          model:getChildByName('Text_money'):setString(LuaTools.convertAmountChinese(val.coin))
          if tonumber(val.sex) == 1 then 
              model:getChildByName('Image_avatar'):loadTexture("common/default_avater_woman.png",ccui.TextureResType.plistType)
              model:getChildByName('Image_sex'):loadTexture('res_rank/female.png',ccui.TextureResType.plistType)
          end

          model:getChildByName('Button_invite'):setVisible(false)
          local gameName = self:getRoomName(val.siteid)
          model:getChildByName('Text_online'):setString(gameName)    
          model:getChildByName('Button_join'):setVisible(false)--(val.siteid > 0 ) 
          if self.roomType and self.roomId  then    
                model:getChildByName('Button_invite'):setVisible(true)
          end 

            if tonumber(val.siteid) <0 then --房间号，小于0表示没在线，0表示在线，大于0表示在游戏中，即房间号
              model:getChildByName('Text_online'):setString('离线')
              model:getChildByName('Text_online'):setColor(cc.c3b(128,128,128))  
            elseif tonumber(val.siteid) == 0 then 
              --model:getChildByName('Button_invite'):setVisible(false)
            else
              local function joinRoom(event)
                if event.name == 'ended' then 
                      local table = {}
                      table.siteid = val.siteid 
                      table.roomid = 0 
                      table.port      = self.playerdata:getGamePort(val.siteid)
                      table.friendID  = val.uid 
                      table.tableType = val.siteid
                         
                      if  string.find(gameName,'婚礼场')  then 
                         if  not G_BASEAPP:getView('UIFriendWeddingRoom') then                            
                             G_BASEAPP:addView('UIFriendWeddingRoom',130,val.uid,val.nick)
                         end 
                      end 
                      
                      local viewName
                      if  string.find(gameName,'主') then 
                           viewName = 'UIGameTable'
                      elseif  string.find(gameName,'牛') then 
                           viewName = 'UIGameTableDouniu'    
                      elseif  string.find(gameName,'牌') then
                           viewName = 'UIGameTableSanzhang'
                      end   
                      if viewName then  
                          local load = G_BASEAPP:addView("UILoading",200)  
                          G_LOADINGVIEW = load
                          load:setLoadingType(true)
                          load:setNextAction(function()
                              G_BASEAPP:addView(viewName,500,table)  
                          end)
                          load:startProgress() 
                          self.app:callMethod('UIMain', 'showExitMainActions')
                          self:removeSelf()
                      end 
                    self:backEvent()           
                end
              end
              model:getChildByName('Button_join'):onTouch(joinRoom)
              model:getChildByName('Button_invite'):onTouch(joinRoom)
            end

          local textName = model:getChildByName('Text_name')
          local textModel =  "一二三四五三四五"
          LuaTools.cropLabel(textModel, (val.nick or 'Unnamedplayer'), textName)


          local newHeadSpr 
          if val.icon and  val.icon ~= "" then
              local function onFinishTable(status,downloadedSize,dst)
                  if status == "success" then
                     newHeadSpr = cc.Sprite:create(dst)
                  else 
                     newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[val.sex+1])   
                  end
                  LuaTools.makeSpriteRounded(newHeadSpr, model:getChildByName('Image_avatar'), self.config.maskSprite, false)
              end
              local newName = val.icon
              LuaTools.getFileFromUrl({
                 url = val.icon,
                 destFile = (newName:gsub("/","_")),
                 onFinishTable = onFinishTable
                 })
          else 
              newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[val.sex+1])   
              LuaTools.makeSpriteRounded(newHeadSpr, model:getChildByName('Image_avatar'), self.config.maskSprite, false)
          end
      end
    end 
    
    --更新小红点  
    for key,var in pairs(pData.chatLogTable) do 
        if var > 0 then 
            self:updateRedPoint(key)
        end    
    end 
    
end

function UIFriend:updateWeddingList(info)
    if type(info) ~= 'table' then return end  
    self['ListView_wedding']:removeAllItems()
    local function touchItem(event)  
        if event.name == 'ended' then 
          
            self.app:addView('UIFriendWeddingRoom',109,event.target:getTag())
        end       
    end

    local model ,tag = nil,0
    for key,var in pairs(info) do 
        self['ListView_wedding']:pushBackDefaultItem()
        model = self['ListView_wedding']:getItem(tag)
        model:setVisible(true)
        model:setTag(var.rid)
        model:getChildByName('Text_id'):setString(var.rid)
        model:getChildByName('Text_number'):setString(var.number)
        model:getChildByName('Text_type'):setString(tonumber(var.level) == 99 and '浪漫:99元宝' or 
          (tonumber(var.level) == 520 and '豪华:520元宝' or '至尊:1314元宝'))
        model:getChildByName('Text_name'):setString(var.name)
        model:onTouch(touchItem) 
        if tonumber(info.rid) == tonumber(self.playerdata.uid) then 
           model:getChildByName('Text_id'):setColor(cc.c3b(255,0,0))
           model:getChildByName('Text_name'):setColor(cc.c3b(255,0,0))
        end    
        tag = tag + 1 
    end   
end 

function UIFriend:updateRedPoint(uid)
    for key=0,(#(self['ListView_friend']:getItems())-1) do 
        local child = self['ListView_friend']:getItem(key)
        if  child:getTag() == tonumber(uid) then 
            child:getChildByName('Button_chat'):getChildByName('Image_redPoint'):setVisible(true)         
        end 
    end      
end 

return UIFriend
