local UIMainBottom = class("UIMainBottom", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
UIMainBottom.RESOURCE_FILENAME = "UIMainBottom.csb"
--UIMainBottom.RESOURCE_PRELOADING = {"main.png"}
--UIMainBottom.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIMainBottom.RESOURCE_BINDING = { 
     -- ["Button_start"]      = {["ended"] = "quickStart"},
     -- ["Button_shop"]   = {["ended"] = "enterShop"},
      ["Button_friend"]   = {["ended"] = "enterFriend"},
      ["Button_rank"]     = {["ended"] = "enterRank"},
      ["Button_activity"] = {["ended"] = "enterActivity"},
      ["Button_mail"]     = {["ended"] = "enterMail"},
      ["Button_Sign"]     = {["ended"] = "enterSign"},
      ["Button_setting"]     = {["ended"] = "enterSetting"},
      ["Button_back"]     = {["ended"] = "exitGame"},
      ["Button_GiftExchange"]   = {["ended"] = "enterGiftExchange"},
      ["Button_TelFee"]   = {["ended"] = "enterFeeExchange"},
      ["Button_Help"]     = {["ended"] = "enterHelp"},
     ["Button_privateRooms"]   = {["ended"] = "enterPrivateRooms"},
    } 

--初始化
function UIMainBottom:onCreate()
    local app = self:getApp()
    self.app = app
    self.pData = app:getData('PlayerData')
    self.tool = app:getModel('Tools')
    self.config = app:getData('Config')
    -- --self.sound = app:getModel('Sound')

    self.panelMore = self['Panel_More']
    self.panelMore:setVisible(false)
    self.panelMore:setBackGroundColorOpacity(0)
    self.keynameGame = '' 
    self.gameDataSel = nil
    self.outOfViewPositionY = self["Panel_Bottom"]:getPositionY()
    self:updateMailDot()
    self['Panel_main']:setBackGroundColorOpacity(0)
    self['Panel_Bottom']:setTouchEnabled(false)

    self:showSignDot(false)
    self:setQuickStart(Constants.KEY_DDZ)
    --self:initTouchHandler()
    
    self:initAnimations()
end

--显示/隐藏签到红点
function UIMainBottom:showSignDot(_show)
    self['Button_Sign']:getChildByName('Image_redDot'):setVisible(_show)
    self['Button_More']:getChildByName('Image_redDot'):setVisible(_show)
end

--进入大厅动作
function UIMainBottom:showEnterActions()
    local moveTop = cc.MoveTo:create(0.4, cc.p(self["Panel_Bottom"]:getPositionX(),0))
    self["Panel_Bottom"]:runAction(moveTop)
end

--退出大厅动作
function UIMainBottom:showExitActions()
    local moveTop = cc.MoveTo:create(0.4, cc.p(self["Panel_Bottom"]:getPositionX(),self.outOfViewPositionY))
    self["Panel_Bottom"]:runAction(moveTop)
end

--初始化UI
function UIMainBottom:initAnimations()
    local function onStart(event)
        if event.name == 'began' then 
        elseif event.name == 'ended' then 
            self:quickStart()
        end
    end
    self.panelStart = self['Panel_quickstart']
    self.panelStart:setTouchEnabled(true)
    self.panelStart:onTouch(onStart)
	
    self.panelShop = self['Panel_shop']
    self.panelShop:setTouchEnabled(true)
    self.panelShop:onTouch(function(event) if event.name == 'ended' then self:enterShop() end end)
end



--进入游戏 (炸翻天，斗牛，三张牌)
function UIMainBottom:enterGame(seatIDS)
    local dataRoom = self:getDataRoomsSelected()
    local myChips = tonumber(self.pData.coin)
    local indexRoom = 0
    local sizeTable = #dataRoom
    if self.keynameGame == Constants.KEY_ZJH then
        sizeTable = #dataRoom-1    --不能进入秒杀场和道具场
    end
    for i = sizeTable, 1, -1 do
         local max = dataRoom[i].max
        local min = dataRoom[i].min
        indexRoom = i
       -- table.insert(tabl, self.pData.GameTypes[self.type][i])
       if myChips >= min and max < 0 then     
            break
       elseif max > 0 and myChips <= max and myChips >= min then 
            break
       end
    end
    -- dump(self.pData.GameTypes,"self.pData.GameTypes")
    -- dump(self.gameDataSel,'122334455')
    local siteid = seatIDS or dataRoom[indexRoom].siteid
    local roomId = dataRoom[indexRoom].roomid
    if  self.keynameGame == Constants.KEY_DN then 
        if self.pData.coin <=50000 then 
           roomId = 0 
        elseif  self.pData.coin > 50000 and self.pData.coin <=200000 then   
           roomId = 1  
        elseif  self.pData.coin > 200000 and self.pData.coin <=1000000 then   
           roomId = 2  
        elseif  self.pData.coin > 1000000 then   
           roomId = 3             
        end        
    end     
    local viewName = self.gameDataSel.viewName 
    local dataRoomName = self.gameDataSel.dataName
    local port = self.pData:getGamePort(siteid)
    local table = {}

    if self.keynameGame == Constants.KEY_DDZ then
        -- if self.pData.bitcheckCaiNiao == 0 and self.pData.vip_level < 1 then 
        --     roomId = -1 
        -- end     
        table['tableType'] = siteid
        table['RoomLevel'] = roomId
    elseif  self.keynameGame == Constants.KEY_DN then
        table['RoomLevel'] = roomId
    elseif  self.keynameGame == Constants.KEY_ZJH then
        table['tableType'] = siteid
    end
    table['port'] = port
	
    self:printRoomData(dataRoomName, viewName, siteid, roomId, port)
    self:loadRoomWithViewAndData(viewName, table)
end

function UIMainBottom:loadRoomWithViewAndData(_view, _data)
    self.app:callMethod("UIMain", "showExitMainActions",function()
        -- local load = G_BASEAPP:addView("UILoading",200)  
        -- G_LOADINGVIEW = load
        -- load:setLoadingType(true)
        -- load:setNextAction(function()
        --     G_BASEAPP:addView(_view,500,_data)  
        -- end)
        -- load:startProgress()
        G_BASEAPP:addView(_view,500,_data)  
    end)
end

--打印数据表
function UIMainBottom:printRoomData(dataname, viewname, siteId, roomId, port)
    local tb = {
        dataname = dataname,
        viewname = viewname,
        siteId = siteId,
        roomId = roomId,
        port = port,
    }
    dump(tb,"RoomData")
end


function UIMainBottom:showDifferentView(cb)
    if self.pData.gem > 0 then 
        if not G_BASEAPP:getView('UIQuickBuy') then 
            G_BASEAPP:addView('UIQuickBuy',6666,cb)
        end 
    else 
        if not G_BASEAPP:getView('UIShopDiamond') then 
            G_BASEAPP:addView('UIShopDiamond',6666,cb)
        end 
    end         

end     

--快速进入比赛场
function UIMainBottom:quickEnterMatch() 
    self.app:callMethod("UIMain", "showExitMainActions",function()
        G_BASEAPP:addView('UIAwards',500)  
    end)
end     

function UIMainBottom:getDataRoomsSelected()
    local dataRoomName = self.gameDataSel.dataName
    return self.pData.GameTypes[dataRoomName]
end

--快速进入德州扑克
function UIMainBottom:quickEnterPokerRoom(seatIDS)
    local orderSearch = {'speedup', 'pro', 'beginner'}
    local myChips = tonumber(self.pData.coin)
    local function getBestRoom()
        for i,key in ipairs(orderSearch) do
        local dataRooms = Constants.POKER_ROOMS_DATA[key]
            for j = #dataRooms, 1, -1 do
                local roomInfos = dataRooms[j]
                local max = roomInfos.maxChips
                local min = math.floor(max/10)
                if myChips >= min then 
                    return roomInfos
                end
            end
        end
    end
    local bestRoom = getBestRoom()
    if bestRoom then 
        dump(bestRoom, "Best Room found:")
        self:loadRoomWithViewAndData("UIGameTableDeZhou", (seatIDS or  bestRoom.tType_9))
    else
        self.tool:showTips("没有匹配到合适的房间。。。")
    end
end

--快速进入跑得快
function UIMainBottom:quickEnterRunFast(seatIDS)
    self.app:callMethod("UIMain", "loadGameRoomsInfos", self.config.keyDataGames.pdk,function() 
        dump(self.pData.GameTypes,'王牌跑得快场次配置信息')
        local myChips = tonumber(self.pData.coin)
        local function getBestRoom()
            for i = #Constants.PDK_ROOMS_DATA, 1, -1 do
                -- local roomInfos = Constants.PDK_ROOMS_DATA[i]
                -- local max = roomInfos.max
                -- local min = roomInfos.min
                -- if max == 0 and min == 0 then   --无限制
                --     return roomInfos
                -- elseif max > 0 and min == 0 and myChips <= max then    --最大限制
                --     return roomInfos
                -- elseif min > 0 and max == 0 and myChips >= min then   --最小限制
                --     return roomInfos
                -- elseif min > 0 and max > 0 and myChips >= min and myChips <= max then  --范围限制
                --     return roomInfos
                -- end
                return Constants.PDK_ROOMS_DATA[1]
            end
        end
        local bestRoom = getBestRoom()
        if bestRoom then 
            local table = {
                tableType   = seatIDS or bestRoom.tType,
                isPaodekuai = true,
                port  =self.pData.GameTypes.GameType_PDK[1].port--self.pData:getGamePort(bestRoom.tType)
            }
            self:loadRoomWithViewAndData("UIGameTablePaodekuai", table)
        else
            self.tool:showTips("没有匹配到合适的房间。。。")
        end
    end )    

end

--快速进入王牌斗地主
function UIMainBottom:quickEnterWPDZ()
    -- self.tool:showTips("即将开放，敬请期待")
    self.app:callMethod("UIMain", "loadGameRoomsInfos", self.config.keyDataGames.ddzNor,function() 
       dump(self.pData.GameTypes,'王牌斗地主场次配置信息')
            local myChips = tonumber(self.pData.coin)
            local function getBestRoom()
                -- for i = #Constants.WPDZ_ROOMS_DATA, 1, -1 do
                --     local roomInfos = Constants.WPDZ_ROOMS_DATA[i]
                --     local max = roomInfos.max
                --     local min = roomInfos.min
                --     if max == 0 and min == 0 then   --无限制
                --         return roomInfos
                --     elseif max > 0 and min == 0 and myChips <= max then    --最大限制
                --         return roomInfos
                --     elseif min > 0 and max == 0 and myChips >= min then   --最小限制
                --         return roomInfos
                --     elseif min > 0 and max > 0 and myChips >= min and myChips <= max then  --范围限制
                --         return roomInfos
                --     end
                -- end
                return Constants.WPDZ_ROOMS_DATA[1]
            end
            local bestRoom = getBestRoom()
            local port = self.pData.GameTypes.GameType_DDZNOR[1].port--self.pData:getGamePort(bestRoom.tType)
            if port < 0 then 
                print("无法找到对应的PORT："..bestRoom.tType)
                self.tool:showTips("期待游戏开放吧。。。")
                return
            end
            if bestRoom then 
                dump(bestRoom, "Best Room found:")
                local table = {
                    tableType   = bestRoom.tType,
                    RoomLevel   = bestRoom.roomId,
                    port =  port,
                    isWangPaiDDZ =true,
                }
                self:loadRoomWithViewAndData("UIGameTableClassic", table)
            else
                self.tool:showTips("没有匹配到合适的房间。。。")
            end
        end )

end

--快速进入万人
function UIMainBottom:quickEnterWanren() 
   --self.app:addView('UIGameTableWanren',168)  
   self.app:callMethod("UIMain", "loadGameRoomsInfos", self.config.keyDataGames.wrdn,
     function() 
        self.app:callMethod("UIMain", "showExitMainActions",function()
            -- local load = G_BASEAPP:addView("UILoading",200)  
            -- G_LOADINGVIEW = load
            -- load:setLoadingType(true)
            -- load:setNextAction(function()
            --     G_BASEAPP:addView('UIGameTableWanren',500)  
            --     end)
            -- load:startProgress()
             G_BASEAPP:addView('UIGameTableWanren',500)  
            end)
     end, 
     function()    
        self.tool:showTips("无法获取房间信息")
     end 
    ) 
end     
function UIMainBottom:initTouchHandler(_graphPriority)
    local listener = cc.EventListenerTouchOneByOne:create()
    listener:registerScriptHandler(function(touch, event) self:onTouchBegan(touch, event) return true end,cc.Handler.EVENT_TOUCH_BEGAN )
    self.eventDispatcher = self:getEventDispatcher()
    self.eventDispatcher:addEventListenerWithSceneGraphPriority(listener, _graphPriority)

    self['Button_More']:onTouch(function(event)self:onOpenMore(event) end)
end

function UIMainBottom:onTouchBegan( touch, event )
    --print("TOUCH BEGAN")
    if self.panelMore:isVisible() == false then 
            return
    end 
    local loc = touch:getLocation()
    if false == cc.rectContainsPoint(self.panelMore:getBoundingBox(), cc.p(loc.x, loc.y)) and
    false == cc.rectContainsPoint(self['Button_More']:getBoundingBox(), cc.p(loc.x, loc.y))  
    then 
        self.panelMore:setVisible(false)
        self['Button_More']:loadTextureNormal("res_lobby/bt_moreUp.png", ccui.TextureResType.plistType)
        self['Button_More']:loadTexturePressed("res_lobby/bt_moreUp.png", ccui.TextureResType.plistType)
    end
end

function UIMainBottom:setQuickStart(_keyName)
    self.keynameGame = _keyName
    self.gameDataSel = self.config.keyDataGames[_keyName]
end

--更新UI色彩
function UIMainBottom:updateFrameColor(_colorback, _colorButtons)
    print("UPDATE BOTTOM COLOR")
    self['Image_bg']:setColor(_colorback)

    self['Button_friend']:setColor(_colorButtons)
    self['Button_rank']:setColor(_colorButtons)
    self['Button_activity']:setColor(_colorButtons)
    self['Button_mail']:setColor(_colorButtons)
    self['Button_setting']:setColor(_colorButtons)
    self['Button_GiftExchange']:setColor(_colorButtons)
    self['Button_Help']:setColor(_colorButtons)
    self['Button_privateRooms']:setColor(_colorButtons)
    self['Button_More']:setColor(_colorButtons)
    self['Button_Sign']:setColor(_colorButtons)
    self['Image_morebgd']:setColor(_colorback)
end

--快速开始
function UIMainBottom:quickStart()
    if self:checkChips() == false then return end
    if self.pData.gamePorts  and self.pData.gamePorts[tostring(1)] and   #self.pData.gamePorts[tostring(1)] == 0 then
        self.tool:showTips("无法获取房间信息。")
        print("NO PORTS FOUND.")
        return
    end

    if self.pData.showOneGame == 1 then 
        self.keynameGame = Constants.KEY_DDZ
        self.app:callMethod("UIMain", "loadGameRoomsInfos", self.gameDataSel,
            function() 
                self:enterGame()
            end,
            function()
               self.tool:showTips("无法找到房间的信息。。。")
            end)
        return 
    end     
    --判断进入哪一个游戏房间
    print("KEYNAME: "..self.keynameGame)
    if self.keynameGame == Constants.KEY_POKER then 
        self:quickEnterPokerRoom()
		local sendumeng = {}
		sendumeng['type'] = 'event'
		sendumeng['eventId'] = 'quickgame_poker'
		LuaTools.setUmeng(sendumeng)
    elseif self.keynameGame == Constants.KEY_RUNFAST then 
        self:quickEnterRunFast()
		local sendumeng = {}
		sendumeng['type'] = 'event'
		sendumeng['eventId'] = 'quickgame_runfast'
		LuaTools.setUmeng(sendumeng)
    elseif self.keynameGame == Constants.KEY_MATCH then 
        self:quickEnterMatch() 
		local sendumeng = {}
		sendumeng['type'] = 'event'
		sendumeng['eventId'] = 'quickgame_match'
		LuaTools.setUmeng(sendumeng)
    elseif self.keynameGame == Constants.KEY_DDZNOR then 
        self:quickEnterWPDZ()
		local sendumeng = {}
		sendumeng['type'] = 'event'
		sendumeng['eventId'] = 'quickgame_wpdz'
		LuaTools.setUmeng(sendumeng)
    elseif self.keynameGame == Constants.KEY_WANREN then 
        self:quickEnterWanren()   
		local sendumeng = {}
		sendumeng['type'] = 'event'
		sendumeng['eventId'] = 'quickgame_wanren'
		LuaTools.setUmeng(sendumeng)		
    else   
        --斗地主炸翻天，斗牛，扎金花，房间信息是从服务器获取的，就需要执行以下处理：
        if self.gameDataSel == nil or self.gameDataSel == {} then
             self.tool:showTips("暂时无法进入该游戏，获取游戏房间信息失败。。。")
            return
        end
        self.app:callMethod("UIMain", "loadGameRoomsInfos", self.gameDataSel,
            function() 
                self:enterGame()
            end,
            function()
               self.tool:showTips("无法找到到房间的信息。。。")
            end)
    end
	self.app:callMethod("UIMain", "clearTarget",function()
        
    end)
end




--好友红点
function UIMainBottom:HideRedPoint()
    if #self.pData.chatLogTable > 0 then 
        for key,var in pairs(self.pData.chatLogTable) do 
            self.pData.chatLogNumber = self.pData.chatLogNumber + var 
        end 
    end   

    self['Image_friendDot']:setVisible(self.pData.chatLogNumber ~= 0)
    self['Image_friendDot']:getChildByName('Text_num'):setString(self.pData.chatLogNumber)        
end 

--邮件红点
function UIMainBottom:updateMailDot()
       self['Image_mailDot']:setVisible(self.pData.newMailCount>0)
end 

--打开更多
function UIMainBottom:onOpenMore(event)
    if event.name == 'began' then
        
    elseif event.name == 'ended' then
        
        self.panelMore:setVisible(not self.panelMore:isVisible())
        if self.panelMore:isVisible() == true then 
            self['Button_More']:loadTextureNormal("res_lobby/bt_more.png", ccui.TextureResType.plistType)
            self['Button_More']:loadTexturePressed("res_lobby/bt_more.png", ccui.TextureResType.plistType)
        else
            self['Button_More']:loadTextureNormal("res_lobby/bt_moreUp.png", ccui.TextureResType.plistType)
            self['Button_More']:loadTexturePressed("res_lobby/bt_moreUp.png", ccui.TextureResType.plistType)
        end
    end
end

--检查金币是否为0
function UIMainBottom:checkChips()
    if tonumber(self.pData.coin) <= 0 then
        if self.pData.bank and tonumber(self.pData.bank)> 0 then 
            G_BASEAPP:addView('UISupplyMoney',111111)
        elseif self.pData.gem > 0 then 
            G_BASEAPP:addView('UIQuickBuy',111111)
        else     
            local paTable =     {
                ['uid']   = G_UID,
                ['token'] = G_TOKEN,
                ['cmd']   = HttpHandler.CMDTABLE.GET_FREE_COIN  }  
            local function succ(arg) 
                if arg.msg then 
                    LuaTools.showAlert(arg.msg)
                end        
            end    
            local function fail()
                if self.pData.gpackFlag <4 then      
                    G_BASEAPP:addView('UISpree',111111)
                else 
                    G_BASEAPP:addView('UIShopDiamond',111111)
                end     
            end     
            LuaTools.fastRequest(paTable,succ,fail)
        end   
        return false
    else  
    end
    if tonumber(self.pData.coin) <= 0 then
        local function onConfirm()
          --  self:enterChargeDiamond()
           G_BASEAPP:addView('UIQuickBuy', self:getLocalZOrder() + 2,function(arg) 
                self.pData.coin = arg.coin
                if self.app:getView('UIMainTop') then 
                   self.app:callMethod('UIMainTop','updateWealth')
                end 
            end)
        end
        --弹出是否去充值对话框
        local dlg = self.app:addView('UIDialog', self:getLocalZOrder() + 1, nil, true)
        dlg:setupDialog('金币不足', Constants.STRING_NO_MONEY, onConfirm, nil, false)


        return false
    end
    return true

end

--帮助
function UIMainBottom:enterHelp()
   -- print("TOUCH ITEM BEGAN")
   
   self.app:addView('UIHelps',100) 
end

--进入商城
function  UIMainBottom:enterShop(event)
    self.app:addView('UIShop',110, 1)
end

--进入好友
function UIMainBottom:enterFriend(event)        
            
   self.app:addView('UIFriend',100) 
end

--进入排行
function UIMainBottom:enterRank(event)
      
  self.app:addView('UIRank',100) 
  --self.app:callMethod("UIMain","showEnterMainActions")
end  

--进入私人场  
function UIMainBottom:enterPrivateRooms(event)
    self.panelMore:setVisible(false)
    self.app:addView('UIMatchPrivate',100)
end



--进入活动
function UIMainBottom:enterActivity(event)
    self.app:addView('UIActivity',168) 

   -- self.app:callMethod("UIMain", "showExitMainActions",function()
   --      local load = G_BASEAPP:addView("UILoading",200)  
   --      G_LOADINGVIEW = load
   --      load:setLoadingType(true)
   --      load:setNextAction(function()
   --          G_BASEAPP:addView('UIGameTableWanren',500)  
   --      end)
   --      load:startProgress()
   --  end)
end

    

--进入邮件
function UIMainBottom:enterMail(event)
    
    self.app:addView('UIMail',100)
end

--进入签到
function UIMainBottom:enterSign(event)
    
     self.app:addView('UIRegistration',100,function() self:showSignDot() end,self.pData.signStadus)
end

--进入设置  
function UIMainBottom:enterSetting(event)
    self.app:addView('UISetting',99)
end

--退出游戏
function UIMainBottom:exitGame(event)
    self.app:addView('UIDialog', self:getLocalZOrder() + 1)
    self.app:callMethod('UIDialog','setupDialog', '', '确定要退出游戏？', 
    function()
        if LuaTools.isPlatformIOS() then
            os.exit(0)
            -- cc.Director:getInstance():endToLua()
        else
            cc.Director:getInstance():endToLua()
        end
    end, function()  end) 
end


--进入礼品兑换 
function UIMainBottom:enterGiftExchange(event)
    
    if LuaTools.isPlatformIOS() then
        -- ios下兑换按钮也跳转到商城
       self.app:addView('UIShop',110, 5)
    else

        self.app:addView('UIGiftExchange',99)
    end
end

function UIMainBottom:enterFeeExchange()
       self.app:addView('UIShop',110, 5)
end

--[[加载指定项]]
function UIMainBottom:loadTarget()
    local scheduler = require("app.models.QScheduler")
	local scheduler_hand = nil
    local function settime()
		if self['Panel_Bottom'] ~= nil and self['Panel_Bottom'] ~= nil and self.bt_quickStartNode == nil and self.bt_ShopNode == nil then
			self.bt_quickStartNode = cc.CSLoader:createNode('Animation_start.csb') 
			self.bt_quickStartNode:setPosition(cc.p(self.panelStart:getPositionX(),self.panelStart:getPositionY()))
			local action = cc.CSLoader:createTimeline('Animation_start.csb')
			self.bt_quickStartNode:runAction(action)
			action:gotoFrameAndPlay(0,true)
			self['Panel_Bottom']:addChild(self.bt_quickStartNode,1)
			
			self.bt_ShopNode = cc.CSLoader:createNode('Animation_shop.csb') 
			self.bt_ShopNode:setPosition(cc.p(self.panelShop:getPositionX(),self.panelShop:getPositionY()))
			local action = cc.CSLoader:createTimeline('Animation_shop.csb')
			self.bt_ShopNode:runAction(action)
			action:gotoFrameAndPlay(0,true)
			self['Panel_Bottom']:addChild(self.bt_ShopNode,1)
			scheduler.unscheduleGlobal(scheduler_hand)
		end
		
	end
	scheduler_hand = scheduler.scheduleGlobal(settime,0.01)
end

--[[释放指定项]]
function UIMainBottom:clearTarget()
    if self.bt_quickStartNode ~= nil then
		self.bt_quickStartNode:removeFromParent()
		self.bt_quickStartNode = nil
	end
	if self.bt_ShopNode ~= nil then
		self.bt_ShopNode:removeFromParent()
		self.bt_ShopNode = nil
	end
end

return UIMainBottom
