local UIAutoLogin = class("UIAutoLogin", cc.load("mvc").ViewBase)

UIAutoLogin.RESOURCE_FILENAME = "UIAutoLogin.csb"
--UIDialog.RESOURCE_PRELOADING = {"main.png"}
--UIDialog.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIAutoLogin.RESOURCE_BINDING = { 
    ["Button_cancel"] = {["ended"] = "exitScene"},
    ["Button_Close"] = {["ended"] = "exitScene"},

    }
function UIAutoLogin:exitScene()  
    if self.cancelCallback then
	   self.cancelCallback()
    end
    self.app:removeView('UIAutoLogin')
end

--初始化
function UIAutoLogin:onCreate()
    -- if G_CHANNEL_CONFIG.isOurOnlyAutoLogin then
    --     local v = self["Button_cancel"]
    --     if v ~= self["Button_guest"] then

    --         v:setVisible(false)
    --         v:setTouchEnabled(false)
    --     end
    -- end
    
    self:setLockGoback(true)
    local app = self:getApp()
    self.app = app
    self.config = app:getData('Config')
    local MaxCount = 3
    self['Text_string']:setString(MaxCount..'s') 
    self.deltaAdd = 0
    local resAddAt1  = false
	if G_CHANNELID == 'vivo_02' or G_CHANNEL_CONFIG.isSdkLogin then

        self["Button_cancel"]:setVisible(false)
		self["Panel_main"]:setVisible(false)
	else
		cc.SpriteFrameCache:getInstance():addSpriteFrames("common.plist")
		self:createSchedule('updateCount', function()  
			-- local delta = cc.Director:getInstance():getDeltaTime()
			self.deltaAdd = self.deltaAdd + 1
			self['Text_string']:setString(math.ceil(MaxCount-self.deltaAdd)..'s') 

			if self.deltaAdd > 2 then 
				self.tfinishCb()
				self:stopSchedule('updateCount')
				-- G_BASEAPP:removeView('UIAutoLogin') 
			end
		end,1) 
	end
end


function UIAutoLogin:setupDialog(timerFinishCB,cancelCB)
    self.tfinishCb = timerFinishCB
    self.cancelCallback = cancelCB
	if G_CHANNELID == 'vivo_02' then
		self.tfinishCb()
	end
end

return UIAutoLogin
