local UILoading = class("UILoading", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
local scheduler = require("app.models.QScheduler")
UILoading.RESOURCE_FILENAME = "UILoading.csb"
require('cocos.cocos2d.json')
require('app.network.rc4')
require('cocos.cocos2d.json')
require('app.network.DidParseEntry')
require('app.network.DidSaveEntry')

UILoading.RESOURCE_BINDING = {
    -- ["Button_findPsw"]  = {["ended"] = "enterFind"},
    -- ["Button_register"] = {["ended"] = "enterReg"},
    -- ["Button_login"]    = {["ended"] = "enterMain1"},
    -- ['Button_tourist']  = {["ended"] = "touristGo"},
    
    -- ["TextField_account"] = {["ended"] = "textAcco"},
    -- ["blahahahahah"]     = {["ended"] = "gogogogo"},

}
 

function UILoading:onCreate() 
    self.app  = self:getApp() 
    self.tool = self.app:getModel('Tools') 
    self.main = self.app:getModel('Main') 
    self.config = self.app:getData('Config')
    self.pData = self.app:getData('PlayerData')
    self.LoadingBar_1:setPercent(100)
    self.Text_progress:setString('')
    self.Text_status:setString('加载中...')
    self.Text_version:setString(self.config.textVersion)
    self.progress = 0
    self.isFastLoad = false

    self['Text_progress']:setVisible(true)
    self['Text_status']:setVisible(true)
    
    self:setLockGoback(true)
    self['LoadingBar_1']:setVisible(true) 
    self['Image_circle']:runAction(cc.RepeatForever:create(cc.RotateBy:create(1.5, 360)))
    self.dummyNode = display.newNode()
    self:addChild(  self.dummyNode)

    -- local did = '4737c5bac5333357375d4fba375d4f57d1'  --q8q52300595746920  7737f5e7b24e18
    -- local byteArr =  LuaTools.hexStr2ByteArr(did) 
    -- local aaaa    = DidParseEntry.CrevasseBufferNoCC(byteArr, 1 ,#byteArr)  --DidParseEntry.CrevasseBufferNoCCOld(byteArr, 1 ,#byteArr)
    -- local str = {}
    -- for key=1,#aaaa do 
    --     str[key] =string.char(aaaa[key])
    -- end     
    -- local s = table.concat(str)
    -- dump(s,'888888888888888888888888')

    -- local aaaa1    = DidParseEntry.CrevasseBufferNoCCOld(byteArr, 1 ,#byteArr)
    -- local str1 = {}
    -- for key=1,#aaaa1 do 
    --     str1[key] =string.char(aaaa1[key])
    -- end     
    -- local s1 = table.concat(str1)
    -- dump(s1,'888888888888888888888888')
    -- print(#s)
    -- local new = UserCache.saveOldDid(s) 
    
    self.channelId = LuaTools.getChannelID() 

end

function UILoading:startProgress()
	if self.isRegularLoading then
		self:doRegularLoading() 
	else
        self:doUpdateContent()
    end
end

function UILoading:setFastLoad(b)
    self.isFastLoad = b
    self['Panel_Update']:setVisible(false)
end

function UILoading:requestDID(dataTable) 
    self.deviceInfos = LuaTools.getAllInfomationYouNeeded()
	if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) then  --在安卓上，从SD卡根目录读取
		self.pData.didTag =  UserCache.loadDID(LuaTools.GetSDRoot().."/.android/.device_sys_sn/",0)
	else
		self.pData.didTag =  UserCache.loadDID(cc.FileUtils:getInstance():getWritablePath().."",1)
	end
end

function UILoading:doUpdateContent() 
    self['Panel_Update']:setVisible(true)
    self['Panel_regular']:setVisible(false)
	local extraParam = {}
    self.Text_update:setString('检查更新...')
     local dataTable =     {
        ['verid']     = G_CURVER, 
        ['channel']   = G_CHANNELID, 
        ['cmd']       = HttpHandler.CMDTABLE.SYS_UPDATE, 
    }
    self:requestDID(dataTable)
    dataTable['requestDID'] = 0
    if nil == UserCache.csDID or '' == UserCache.csDID then 
        dataTable['pmodel']     = self.deviceInfos.model
        dataTable['imei']       = self.deviceInfos.imei
        dataTable['imsi']       = self.deviceInfos.imsi
        dataTable['mac']        = self.deviceInfos.mac
        dataTable['type']       = self.config.loginType
        dataTable['requestDID'] = 1 
    end

	if ISINIT then
		extraParam['disableWaiting'] = "x" 
	end
    local function succ(arg) 
		G_UPDATEINFO = arg
        dump(arg,'请求热更新成功')
        if arg.did then 
            self.pData.dids = arg.did 
            UserCache.saveDID(arg.did)  
            UserCache.csDID =  UserCache.decryptDID(arg.did) 
        end 

        local downloadLink = ''
        local tempVer = G_CURVER
		  
        self.currVer = tempVer --UserCache.getCommonDataByKey("currentVersion") or 10000  -- 
        if UserCache.getCommonDataByKey("currentVersion") then 
                local s = UserCache.getCommonDataByKey("currentVersion")
                local a = string.find(s,':')
                if a ~= nil then 
                    local code = string.sub(s,1,a-1)
                    local vers = string.sub(s,a+1,-1)
                    if code == tostring(self.channelId) then 
                        tempVer = tonumber(vers) 
                    end    
                else 
                    tempVer = tonumber(s)
                    local tempId =  self.channelId..':'..s
                    UserCache.setCommonDataByKey('currentVersion', tempId)
                    UserCache.saveCommonData()
                    cc.FileUtils:getInstance():purgeCachedEntries()
                end     
            end         
        self.newVer = arg.version or G_CURVER
        print('now verSion =') 
        print(self.currVer)
        print(self.newVer )

         
       self.len = 0
       if arg then
			if tonumber(G_CURVER) < tonumber(self.newVer) then
				if arg.apk_url1 then
					downloadLink = arg.apk_url1 
				end 
				self.len = arg.len1
			else
				if self.doneCallback then
                    self.doneCallback() 
                end
                local tempId =  self.channelId..':'..self.newVer 
                    UserCache.setCommonDataByKey('currentVersion', tempId)
                    UserCache.saveCommonData()
                    cc.FileUtils:getInstance():purgeCachedEntries()
				return
			end
		end
		
		self.apkSize = LuaTools.getFildSizeToM(tonumber(self.len)/2)
		
		local function upDataFile()
			self:proceedUpdate({
                http =  downloadLink,
                onDataCallback = self:getDownloadDataCallback(),
                onFinishCallback = self:getDownloadFinishCallback(),
                })
		end
		
		local isAndroidForce = false
		--判断是否用2g,3g,4g
		if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) then
			local tempWifi = LuaTools.getNetworkStatus()
			if tempWifi =='wifi'then 
			else
				isAndroidForce = true
			end
		end
		
		if  isAndroidForce then --G_UPDATEINFO.isForce == 1 or
			--强 更
			self['Panel_noWifi']:setVisible(true) 
			self['Text_value']:setString(self.apkSize)
			local function a2(event) 
				if event.name == 'ended' then 
					self['Panel_noWifi']:setVisible(false) 
					upDataFile()
				end  
			end      
			self['Button_updateNow']:onTouch(a2)

			local function b2(event) 
				if event.name == 'ended' then  
					self['Panel_noWifi']:setVisible(false) 
					if G_UPDATEINFO.isForce == 1 then
						cc.Director:getInstance():endToLua()
					elseif G_UPDATEINFO.isForce == 0 then
                        if self.doneCallback then
                            self.doneCallback() 
                        end
                        local tempId =  self.channelId..':'..self.newVer 
                        UserCache.setCommonDataByKey('currentVersion', tempId)
                        UserCache.saveCommonData()
                        cc.FileUtils:getInstance():purgeCachedEntries()
                        return
                    end
				end 
			end 
			self['Button_cancel1']:onTouch(b2)
		else
			upDataFile()
		end	       
    end

    local function fail(arg)
        -- dump(arg,'测试绑定账号登录')
		if ISINIT then ISINITTIP = true end
		if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) then
			local status = LuaTools.getNetworkStatus()
			local is_network = false
			if status == 'none' then
				is_network = true
			end
			
			local function fun_tips()
				if G_CHANNELID == 'vivo_02' or G_CHANNEL_CONFIG.isSdkLogin then
					G_BASEAPP:addView('UIWaiting',999999,true,'当前无网络连接，请确认本地网络',1,true)
				else
					G_BASEAPP:addView("UILogin", 1, true)
					LuaTools.showAlert("当前无网络连接，请确认本地网络") 
				end
			end
			
			if is_network then
				fun_tips()
				return 
			end
			if arg.result == 9 then
				if arg.did then 
                    self.pData.dids = arg.did 
                    UserCache.saveDID(arg.did)  
                    UserCache.csDID =  UserCache.decryptDID(arg.did ) 
                end
			else
				fun_tips()
			end
		else
			-- LuaTools.showAlert("登录出错，请联系客服qq解决") 
		end

    end
    LuaTools.fastRequest(dataTable,succ,fail,extraParam)
end


function UILoading:getDownloadDataCallback()
    return function (downloadedSize) 
        -- self.Text_update:setString('正在下载更新包') 
        local posX = downloadedSize / self.len * 100
        self.dummyNode:stopAllActions()
        self.dummyNode:runAction(cc.MoveTo:create(0.5,cc.p(posX,0)))

        if self.hasProgressUpdate == nil then  
            self.hasProgressUpdate = true
            local tempTag = true 
            self:createSchedule('updateScheduler',function()
                if  self.dummyNode:getPositionX() < 50 then 
                self.LoadingBar_1:setPercent( self.dummyNode:getPositionX()*2 )                
                self.Text_update:setString('正在下载:'..string.format("%0.2f",(self.dummyNode:getPositionX()*(self.len/1024/1024/100)))..'M/'..self.apkSize)
                elseif self.dummyNode:getPositionX() >= 50 then 
                    self.Text_update:setString('资源解压中...')
                    self.LoadingBar_1:setPercent( (self.dummyNode:getPositionX()-50)*2 )        
                end        
            end,0.01)
        end
        -- print('DOWNLOADING....'..downloadedSize)
    end
end

function UILoading:getDownloadFinishCallback()
    return function (status,downloadedSize,dst)
        printf('FINISHED DOWNLOAD:(%s),size:%s,path:%s',status,downloadedSize,dst)
        if status == 'success' then 
            if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) then  
                cc.FileUtils:getInstance():uncompressDir(dst,cc.FileUtils:getInstance():getWritablePath()) 
				local dst = cc.FileUtils:getInstance():getWritablePath().."patch.zip"	
            end
                local tempId =  self.channelId..':'..self.newVer 
                UserCache.setCommonDataByKey('currentVersion', tempId)
                UserCache.saveCommonData()
                cc.FileUtils:getInstance():purgeCachedEntries()
        end
        scheduler.performWithDelayGlobal(function() 
            self.Text_update:setString('数据检查完毕')
            self.dummyNode:stopAllActions()
            self.dummyNode:runAction(cc.MoveTo:create(0.5,cc.p( 100,0)))
        end,0.1)

        scheduler.performWithDelayGlobal(function()  
            -- if (cc.PLATFORM_OS_ANDROID == cc.Application:getInstance():getTargetPlatform()) then   
                -- LuaTools.restartApplication()
            -- else  
                MASTER_RESET() 
            -- end 
        end,0.5)
    end
end

function UILoading:proceedUpdate(_param)
    local http = _param.http
    http = string.gsub(http, "http://", "")
    http = string.gsub(http, "https://", "")
    local onDataCallback = _param.onDataCallback
    local onFinishCallback = _param.onFinishCallback 
    
    local host , file = LuaTools.splitUrl(http)
    
    local dst = cc.FileUtils:getInstance():getWritablePath()
    local param = 
    { 
      host = host,
      file = file,
      dst = table.concat({dst , "patch.zip"}),
      onDataCallback = onDataCallback,
      onFinishCallback = onFinishCallback
    } 
   LuaTools.downloadFile(param) 
end


function UILoading:doRegularLoading()
    self['Panel_Update']:setVisible(false)
    self['Panel_regular']:setVisible(true)
    if self.isFastLoad ~= true then
	   local dummyNode = display.newNode()
	   self:addChild(dummyNode)
	   dummyNode:runAction(cc.MoveTo:create(0.5,cc.p(100,0)))
	   self.updateScheduler = scheduler.scheduleGlobal(function()
	   	self.progress = dummyNode:getPositionX()
	   	self.LoadingBar_1:setPercent(self.progress) 
        	self.Text_progress:setString('...'..string.format('%.0f',self.progress).."%") 
            
        	if self.progress>= math.random(95,100) then
        		scheduler.unscheduleGlobal(self.updateScheduler)
        		self.updateScheduler = nil
        		if self.doneCallback then
        			self.doneCallback()
        		end
                scheduler.performWithDelayGlobal(function()
                    -- self:removeFromParent()
                end,0.5)
        	end
    
	   end, 0)
    else
        if self.doneCallback then
            self.doneCallback()
        end
    end
end

function UILoading:setLoadingType(b)
	self.isRegularLoading = b
end

function UILoading:setNextAction(_callback)
	self.doneCallback = _callback
end
 
return UILoading









