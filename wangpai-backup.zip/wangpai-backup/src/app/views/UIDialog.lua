local UIDialog = class("UIDialog", cc.load("mvc").ViewBase)

UIDialog.RESOURCE_FILENAME = "UIDialog.csb"
--UIDialog.RESOURCE_PRELOADING = {"main.png"}
--UIDialog.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIDialog.RESOURCE_BINDING = { 
    ["Button_cancel"] = {["ended"] = "exitScene"},
    ["Button_confirm"] = {["ended"] = "confirm"},
    ["Button_one"] = {["ended"] = "confirm"},


    }



function UIDialog:exitScene() 
    
    if self.cancelCallback then
        self.cancelCallback()
    end   
    --self:removeSelf()
    LuaTools.viewAction1Over(self['Panel_main'],"UIDialog",nil, self)
end

function UIDialog:confirm()   
	print('confirm')
    
    if self.okCallback then
	   self.okCallback() 
    end
    if self.autoRemove == nil or self.autoRemove == true then 
        --self:removeSelf()
         LuaTools.viewAction1Over(self['Panel_main'],"UIDialog",nil, self)
    end
end

UIDialog.TYPE_ONE_BUTTON = 1
UIDialog.TYPE_DEFAULT = 0

function UIDialog:onCreate(_type, autoRemove)
    local app = self:getApp()
    self.app = app
     
    LuaTools.viewAction1(self['Panel_Layer']) 

    self.autoRemove = autoRemove
    if _type and _type == UIDialog.TYPE_ONE_BUTTON then
        -- self['Button_confirm']:runAction(cc.MoveTo:create(0.01,cc.p(self['Panel_main']:getContentSize().width/2,self['Button_confirm']:getPositionY())))
        self['Button_cancel']:setVisible(false)
        self['Button_confirm']:setVisible(false)
        self['Button_one']:setVisible(true)
        self:setLockGoback(true)
    end
    self['Panel_Layer']:setTouchEnabled(true)
end
 

function UIDialog:setupDialog(title,msg,confirmCB, cancelCB, showMask)
	print(msg)
    self['Image_bg1']:setVisible(title~= '')
    self['Image_bg2']:setVisible(title == '')
	self.Text_title:setString(title)
	self.Text_string:setString(msg)     
	self.okCallback =   confirmCB
    self.cancelCallback = cancelCB  
    self['Panel_Mask']:setVisible(showMask)
end

return UIDialog
