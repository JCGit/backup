local UIFriendBrief = class("UIFriendBrief", cc.load("mvc").ViewBase)
require('cocos.cocos2d.json')

UIFriendBrief.RESOURCE_FILENAME = "UIFriendBrief.csb"
UIFriendBrief.RESOURCE_PRELOADING = {"res_friendBrief.png",'common.png','res_profile.png','newcard.png'}
--UIAlert.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

local HttpHandler = require("app.network.HttpHandler")
UIFriendBrief.RESOURCE_BINDING = {
        ["Button_close"]  = {["ended"] = "exitRoom"},
        ["Panel_1"]     = {["ended"] = "exitRoom"},
        ["Button_add"]  = {["ended"] = "addFriend"},
        ["Button_gift"]  = {["ended"] = "giveGift"},
        ["Button_kick"]  = {["ended"] = "kickPlayer"},
        ["ListView_game_kind"] = {["ON_SELECTED_ITEM_END"] = "selectGameKind"},      
        ["ListView_select"]   = {["ON_SELECTED_ITEM_END"] = "selectHeadInfo"},  



    }

function UIFriendBrief:exitRoom()
    -- self.app:removeView('UIFriendBrief')
    
    LuaTools.viewAction1Over(self['Panel_main'],"UIFriendBrief")
end

function UIFriendBrief:selectHeadInfo(event)
    local index = event.target:getCurSelectedIndex()
    self['Panel_baseInfo']:setVisible(index == 0)
    self['Panel_skillInfo']:setVisible(index == 1)

    local image1,image2 
    if index == 0 then 
       image1 = 'res_profile/btn_head_z1.png'
       image2 = 'res_profile/btn_head_y.png' 
       self['Button_touch1']:setTitleColor(cc.c3b(255,255,255))
       self['Button_touch2']:setTitleColor(cc.c3b(172,147,128))
    else
       image1 = 'res_profile/btn_head_z.png'
       image2 = 'res_profile/btn_head_y1.png' 
       self['Button_touch2']:setTitleColor(cc.c3b(255,255,255))
       self['Button_touch1']:setTitleColor(cc.c3b(172,147,128))
    end    
    self['Button_touch1']:loadTextures(image1,image1,image1,ccui.TextureResType.plistType)
    self['Button_touch2']:loadTextures(image2,image2,image2,ccui.TextureResType.plistType)
 
end




function UIFriendBrief:giveGift()
    local str = self["Button_gift"]:getTitleText()
    if str ==  '赠送礼物' then 
       self.app:addView('UISendGift',self:getLocalZOrder() + 20,self.uid,self.requestTag,self.SendGiftcb,self.versionNow)
    elseif str == '出售礼物' then      
        dump(self.SellGiftCb,'self.SellGiftCb')
        self.app:addView('UIProfileSubViews', self:getLocalZOrder() + 20, 3,0,nil, self.SellGiftCb) 
    end     
end

function UIFriendBrief:addFriend()
    -- if self.versionNow <  300000 then 
    --     LuaTools.showAlert('您添加的好友当前版本过低,无法添加')
    --     return 
    -- end   
    local tab_maxFriend = {12,13,15,16,18,20,22,24,26,28,30,32,35,40,50}
    local maxFriendNum = self.pData.vip_level == 0 and 5 or tab_maxFriend[tonumber(self.pData.vip_level)] 
    if self.pData.friendUidList  and #self.pData.friendUidList >= maxFriendNum then 
         LuaTools.showAlert('您的好友数已达到上限，无法添加好友')
        return 
    end 

    if self.requestTag and self.requestTag == 2  then 
        if self.AskFriendCb then    
            self.AskFriendCb(self.uid) 
            LuaTools.showAlert('已发送好友邀请')
        end    
    else
       self.app:addView('UIAddFriend',self:getLocalZOrder() + 20,self.uid)
    end    
end

function UIFriendBrief:selectGameKind(event) 
    local index = event.target:getCurSelectedIndex()+1
    self:swithGameKind(self.lastSelectedIndex,index) 
end 

function UIFriendBrief:swithGameKind(from,to) 
    if not to or to == 0 then return end 
    local function getModelType(tex) 
        local num 
        if tex == '欢乐赢三张' or tex == '名人德州' or tex =='王牌斗牛' then 
            num = 1 
        else 
            num = 2 
        end 
        return num      
    end     

    if from and from ~= 0 then 
       self['ListView_game_kind']:getItem(from-1):loadTextures('res_profile/btn_label1.png','res_profile/btn_label1.png','res_profile/btn_label1.png',ccui.TextureResType.plistType)
       self['ListView_game_kind']:getItem(from-1):setTitleColor(cc.c3b(255,233,178))
       local text1 = self['ListView_game_kind']:getItem(from-1):getTitleText() 
       self['Panel_model'..(getModelType(text1))]:setVisible(false)
    end 

    self['ListView_game_kind']:getItem(to-1):loadTextures('res_profile/btn_label.png','res_profile/btn_label.png','res_profile/btn_label.png',ccui.TextureResType.plistType)
    self.lastSelectedIndex = to 
    self['ListView_game_kind']:getItem(to-1):setTitleColor(cc.c3b(255,255,255))
    if to then 
        local text = self['ListView_game_kind']:getItem(to-1):getTitleText() 
        local tag  = getModelType(text)
        self['Panel_model'..tag]:setVisible(true)  
        if _G.next(self.infoSkill) == nil then return end
        local infos = self.infoSkill[text]
        local lev, expA, expN = LuaTools.expInfos(infos.wins + infos.fails, self.config.levelExp,1)
        local lev1, expA1, expN1 = LuaTools.expInfos(infos.wins, self.config.levelExp,2)
        local totalTime ,winTime ,rate = (infos.wins + infos.fails),infos.wins, 0
        if (infos.wins + infos.fails) > 0 then 
            rate = math.ceil(infos.wins/(infos.wins + infos.fails)*100)
        end     
        self['Panel_model'..tag]:getChildByName('Panel_left'):getChildByName('Text_gameLevel'):setString(lev)
        self['Panel_model'..tag]:getChildByName('Panel_left'):getChildByName('Text_gameSkill'):setString(lev1)
        self['Panel_model'..tag]:getChildByName('Panel_bot'):getChildByName('Text_gameplayed'):setString(totalTime)
        self['Panel_model'..tag]:getChildByName('Panel_bot'):getChildByName('Text_wins'):setString(winTime)
        self['Panel_model'..tag]:getChildByName('Panel_bot'):getChildByName('Text_winPercent'):setString(rate..'%') 
        if tag == 1 then 
            local cardNum = text=='欢乐赢三张' and 3 or 5 
            self:showcard(cardNum, infos.besthand) 
        else 
            self['Panel_model'..tag]:getChildByName('Panel_left'):getChildByName('Text_gameRaise'):setString((infos.mx_ddz or infos.mx_dd or infos.mx_pdk or 0)..'倍')
            self['Panel_model'..tag]:getChildByName('Panel_left'):getChildByName('Text_gameChips'):setString(infos.mc_ddz or infos.mc_dd or infos.mc_pdk or 0)
        end     
    end 
end 


--踢人
function UIFriendBrief:kickPlayer(uid)
    
    local function onEnterShop()
        self.app:addView('UIShop',33333 ,1) 
        --self.app:removeView('UIDialog')
    end
    if tonumber(self.PlayerData.prop[1]) < 1 then 
        self.app:addView('UIDialog', 20011)
        self.app:callMethod('UIDialog','setupDialog', '', '您的踢人卡已用完，是否进入商城购买？',onEnterShop) 
        return 
    end 
    if self.tagCallback then 
       self.tagCallback()
    end
    -- if self.requestTag and self.requestTag ==2 and self.app:getView('UIGameHall') then 
    --     self.app:callMethod('UIGameHall','butLetGo',self.uid)            
    -- end 
    self:exitRoom()
end

function UIFriendBrief:onCreate(table)
    self.app = self:getApp()
    self.tagCallback = table.cbKick
    self.SendGiftcb  = table.cbSendGift
    self.SellGiftCb  = table.cbSellGift
    self.AskFriendCb = table.cbAskFriend
    local tag = table.tag 
    self.requestTag = tag    --无参表示http请求 ，tag==2 表示tcp请求
    self.config = self.app:getData('Config')
    self.tool = self.app:getModel('Tools')
    self.PlayerData = self.app:getData('PlayerData')
    self.pData = self.PlayerData
    local uid = table.uid
    self.uid = uid
    local showOrHide = true  
    cc.SpriteFrameCache:getInstance():addSpriteFrames("newcard.plist")
  
    self['ListView_game_kind']:setScrollBarEnabled(false)
    self['ListView_gift']:setScrollBarEnabled(false)
        for i=1,5 do
            self['Panel_model1']:getChildByName('Panel_right'):getChildByName('Image_card'..i):setVisible(false)
        end

    self['Button_kick']:setVisible(false)

    self['ListView_game_kind']:removeAllChildren()
    self['ListView_game_kind']:setItemModel(self['Button_gameModel']) 
    local temp_keyWord = {['dd']='王牌斗地主',['ddz']='全民炸翻天',['dn']= '王牌斗牛',
                          ['pdk']='王牌跑得快',['zjh']='欢乐赢三张'}   
    for key,var in pairs(self.pData.gameFilter) do 
        if var == 1 and   key ~= 'wrdn' and key ~= 'match' then 
            self['ListView_game_kind']:pushBackDefaultItem() 
            local model = self['ListView_game_kind']:getItem(#(self['ListView_game_kind']:getItems())-1)
            model:setVisible(true)
            model:setTitleText(temp_keyWord[key])
        end 
    end  

    if tag == 0 then  --万人场 
       self['Button_kick']:setVisible(false)
       self['Button_gift']:setVisible(false)
       self['Button_add']:setVisible(false)
    end   

    self['Button_gift']:setTitleText( (tag==2 and tonumber(uid) == tonumber(self.PlayerData.uid))  and  '出售礼物' or '赠送礼物')
   
    self.AllSkillInfo = {}

    local x1,y1 = self['Button_add']:getPosition() 
    local x2,y2 = self['Button_gift']:getPosition() 
    local x3,y3 = self['Button_kick']:getPosition() 

    if tag == 3 then  --排行
       self['Button_add']:setVisible(true)
       if  not table.hideFriednBtn then 
           self['Button_kick']:setVisible(false)
           self['Button_gift']:setVisible(true)
           self['Button_gift']:setPosition(x3-100,y3) 
           self['Button_add']:setPosition(x1+80,y1)
       else 
           self['Button_gift']:setVisible(false)
           self['Button_add']:setPosition(x2,y2) 
       end     
    end     

     local function compare(uid) 
         if self.PlayerData.friendUidList and #self.PlayerData.friendUidList > 0 then 
            for key ,var in pairs(self.PlayerData.friendUidList) do 
                if var == tonumber(uid) then 
                    return true        
                end
            end         
         end 
     end   

    if tag == 5 then  --婚礼房
       self['Button_kick']:setVisible(false)
       self['Button_gift']:setVisible(false) 
       local temp_tcpShow = compare(uid) or false
       if tonumber(uid) == tonumber(self.PlayerData.uid) then 
           self['Button_add']:setVisible(false)
       else     
           self['Button_add']:setVisible(not temp_tcpShow)
       end 
       self['Button_add']:setPosition(x2,y2)
    end   

    if tag == 1 then  --好友
       self['Button_add']:setVisible(false)
        self['Button_gift']:setVisible(true)
    end    
    self.maxGift = 7 
    self.lastSelectedIndex  = 1 


    LuaTools.viewAction1(self['Panel_main'],function()
            local dataTable =     {
              ['uid']    = tonumber(G_UID),
              ['token']  = G_TOKEN,
              ['tuid']   = uid,
              ['cmd']    = HttpHandler.CMDTABLE.GET_USERINFOS,
            }
            local function succ(arg)
                self:initUI(arg)
                self.versionNow =  tonumber(arg.vername) or 0 
                if  tag == 2 then  
                  -- if self.versionNow < 300000   then 
                  --    if tonumber(uid) ~= tonumber(self.PlayerData.uid) then 
                  --      LuaTools.showAlert('当前玩家的游戏版本过低,无法赠送礼物、添加好友') 
                  --      self['Button_add']:setVisible(false)
                  --      self['Button_gift']:setVisible(false)
                  --      self['Button_kick']:setVisible(true)
                  --      local x,y = self['Button_gift']:getPosition()
                  --      self['Button_kick']:setPosition(x2,y2)
                  --    end 
                  -- else 
                       local temp_tcpShow = compare(uid) or false
                       self['Button_gift']:setVisible(true)
                       if tonumber(uid) == tonumber(self.PlayerData.uid) then 
                           self['Button_add']:setVisible(false)
                           self['Button_kick']:setVisible(false)
                           self['Button_gift']:setVisible(false)
                       else     
                           self['Button_add']:setVisible(not temp_tcpShow)
                           self['Button_kick']:setVisible(true)
                       end 
                       if not self['Button_add']:isVisible() and tonumber(uid) ~= tonumber(self.PlayerData.uid) then 
                           self['Button_gift']:setPosition(x1+80,y1)
                           self['Button_kick']:setPosition(x3-100,y3)
                       end   
                  -- end    
                end 
                if tonumber(uid) == tonumber(self.PlayerData.uid)  then 
                    for key,var in pairs(arg.gift) do 
                       self.PlayerData.gift[tonumber(key)] = var 
                    end 
                end 
            end
            LuaTools.fastRequest(dataTable,succ)
        end )
    -- if  self['Button_gift']:getTitleText() == '出售礼物' then 
    --     self['Button_gift']:setVisible(false)
    -- end  
end


function UIFriendBrief:initUI( arg )

    self.infoSkill = {['王牌斗地主']=arg.gamedd,['全民炸翻天']=arg.gameddz,['王牌斗牛']= arg.gamedn,
    ['王牌跑得快']=arg.gamepdk,['欢乐赢三张']=arg.gamezjh  }
    self:swithGameKind(0,1)

    local money = tonumber(arg.coin)
    local lev, expA, expN = LuaTools.expInfos(money, self.config.fortuneExp,1)
    local a, b, c = LuaTools.expInfos(arg.totalwins + arg.totalfails, self.config.levelExp,1)
    self['Text_level']:setString('Lv.'..a)
    local fortuneName = self.config.fortuneName[lev]
    self['Text_status']:setString(fortuneName or ' ')  --财富等级 
    self['Text_meili']:setString(LuaTools.convertAmountChinese(arg.charm or 0)  )       --魅力值
    self['Text_contact']:setString(arg.contact or '')   --联系方式
    self.Text_ChipsValue:setString(LuaTools.convertAmountChinese(arg.coin))           --金币
    self.Text_DiamondValue:setString(LuaTools.convertAmountChinese(arg.gem))          --钻石
    self['Text_address']:setString(arg.area)           --地址              
    self['Image_myVipBg']:setVisible(arg.vipvalid > 0) 
    self['Image_myVipBg']:getChildByName('Text_viplevel'):setString('V'..arg.vip)

    self['Image_myVipBg']:loadTexture(arg.vipvalid<=7 and 'common/icon_vip_bg_0.png' or 
      (arg.vipvalid>30 and 'common/icon_vip_bg_2.png' or 'common/icon_vip_bg_1.png') ,ccui.TextureResType.plistType) 

    self['Image_myVipBg']:setLocalZOrder(2)
          

    
    self['ListView_gift']:removeAllItems()
    self['ListView_gift']:setItemModel(self['Panel_Item_right']) 
    for key = 1 ,self.maxGift do 
        self['ListView_gift']:pushBackDefaultItem()
        local item = self['ListView_gift']:getItem(key-1) 
        item:setVisible(true)
        item:getChildByName('Text_num'):setString(arg.gift[tostring(key)] or 0)
        item:getChildByName('Image_item'):loadTexture(string.format('common/gift%d.png',key),ccui.TextureResType.plistType)
    end   

    local temp_head = tonumber(arg.sex) == 0  and ("res_profile/img_sex_male.png") or ("res_profile/img_sex_female.png")
    self.Image_gender:loadTexture(temp_head,ccui.TextureResType.plistType)  --性别
    --self.Image_married:loadTexture(temp_head,ccui.TextureResType.plistType)  --女头像

    -- if tonumber(arg.sex) == 0 then
    --   self.Image_head:loadTexture("main/default_avater_woman.png",ccui.TextureResType.plistType)  --我自己的头像
    -- end

    local textName = self['Text_Gname']
    local textModel =  "一二三四五三"
    LuaTools.cropLabel(textModel, arg.nick, textName)
    self.Text_uid:setString("Uid:"..arg.uid)


    --self.Text_cardValue:setString(  self.tool:convertToText(arg.accu or 0 ))   --话费
    --self.Text_date:setString('出道时间:'..string.sub(arg.createtime,1,11)) --( string.split(arg.createTime," ")[1])

    local newHeadSpr 
    if arg.icon and arg.icon ~= "" then
      local function onFinishTable(status,downloadedSize,dst)
        if status == "success" then
           newHeadSpr = cc.Sprite:create(dst)
        else 
           newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.zA[tonumber(arg.sex)+1])   
        end
        LuaTools.makeSpriteRounded(newHeadSpr, self.Image_head, self.config.maskSprite, false)
      end
      local newName = arg.icon
      LuaTools.getFileFromUrl({
         url = arg.icon,
         destFile = (newName:gsub("/","_")),
         onFinishTable = onFinishTable
         })
    else 
        newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[tonumber(arg.sex)+1])   
        LuaTools.makeSpriteRounded(newHeadSpr, self.Image_head, self.config.maskSprite, false)
    end 

    

    --对象
    if arg.partner and arg.partner.uid then 
        if arg.partner.icon and arg.partner.icon ~= "" then
          local function onFinishTable(status,downloadedSize,dst)
            if status == "success" then
               newHeadSpr = cc.Sprite:create(dst)
            else 
               newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[arg.partner.sex+1])   
            end
            LuaTools.makeSpriteRounded(newHeadSpr, self['Image_marriedPart'], self.config.maskSprite, false)
          end
          local newName = arg.partner.icon
          LuaTools.getFileFromUrl({
             url = arg.partner.icon,
             destFile = (newName:gsub("/","_")),
             onFinishTable = onFinishTable
             })
        else 
            newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[arg.partner.sex+1])   
            LuaTools.makeSpriteRounded(newHeadSpr, self['Image_marriedPart'], self.config.maskSprite, false)
        end 

        --self.Text_married:setString(arg.partner.nick)
        local textName = self.Text_married
        local textModel =  "一二三四五三四五"
        LuaTools.cropLabel(textModel, arg.partner.nick, textName)


        self['Image_herVipBg']:setVisible(arg.partner.vipvalid > 0) 
        self['Image_herVipBg']:getChildByName('Text_viplevel'):setString('V'..arg.partner.vip)

        self['Image_herVipBg']:loadTexture(arg.partner.vipvalid<7 and 'common/icon_vip_bg_0.png' or 
          (arg.partner.vipvalid>=30 and 'common/icon_vip_bg_2.png' or 'common/icon_vip_bg_1.png') ,ccui.TextureResType.plistType)

        self['Image_herVipBg']:setLocalZOrder(2)
    end             
end
--显示最佳手牌
function UIFriendBrief:showcard( _count, _tablHand )
    if _tablHand and _tablHand ~= false and _tablHand ~= "" then 
        _tablHand= json.decode(_tablHand)
        --dump(_tablHand)
        for i=1,_count do
            local card 
            if _count == 3 then 
                card = self['Panel_model1']:getChildByName('Panel_right'):getChildByName('Image_card'..i+1)
            else 
                card = self['Panel_model1']:getChildByName('Panel_right'):getChildByName('Image_card'..i)
            end  
            if next(_tablHand)then 
                card:setVisible(true)
                local path = Cardutl.getPathForCard(_tablHand[i], nil, nil, 'Douniu')
                card:loadTexture(path,ccui.TextureResType.plistType)
            end
        end
    else
        for i=1,5 do
            self['Panel_model1']:getChildByName('Panel_right'):getChildByName('Image_card'..i):setVisible(false)
        end
    end
end


return UIFriendBrief
