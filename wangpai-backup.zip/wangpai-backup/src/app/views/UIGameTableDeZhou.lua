local UIGameTableDeZhou = class("UIGameTableDeZhou", cc.load("mvc").ViewBase)

----------------------------------------------------------------
local TCPConnector = require('app.network.TCPConnector')
local DataPacker = require('app.network.DataPacker')
local DataUnpacker = require('app.network.DataUnpacker')
local HttpHandler = require("app.network.HttpHandler")

----------------------------------------------------------------

UIGameTableDeZhou.RESOURCE_FILENAME = "UIGameTableDeZhou.csb"
UIGameTableDeZhou.RESOURCE_PRELOADING = {"game.png",'res_chat.png','card.png'}
UIGameTableDeZhou.bt_LotteryNode = nil
UIGameTableDeZhou.RESOURCE_LOADING  = {
    ["res/background/game_bg.png"]     = {names = {"Image_bg"}},
    ["res/background/game_tables.png"] = {names = {"Image_bg2"}} 
} 
  
UIGameTableDeZhou.RESOURCE_BINDING = {

        ["Button_back"]      = {["ended"] = "LeaveHall"},
        ["Button_help"]      = {["ended"] = "showCardType"},
        ["Panel_cardType"]   = {["ended"] = "hideCardType"},

        ["Panel_leave"]      = {["ended"] = "HideLeave"},
        ["Panel_addChips"]   = {["ended"] = "hideAddChips"},

        ["Button_backToHall"]  = {["ended"] = "butBack"},     --回到大厅

        ["Button_changeTab"]   = {["ended"] = "butChange"},   --换桌

        ["Button_standUp"]     = {["ended"] = "butStand"},    --站起 
        ['Button_mySitDown']   = {["ended"] = "butSitDown"},    --坐下
         
        ["Button_addChips"]    = {["ended"] = "butaddChips"}, --购买筹码
        ["Button_fee"]         = {["ended"] = "reqSock_SER_FEE"},    --打赏 


        ['Button_shop']   = {["ended"] = "butShop"},
        ['Button_chat']   = {["ended"] = "butChat"},
        ['Button_task']   = {["ended"] = "butTask"},

        ['Panel_chat']    = {["ended"] = "butShowChat"},


        ["Button_fold"]   = {["ended"] = "reqSock_ABANDON_CARD"},
        ["Button_call"]   = {["ended"] = "butFollow"},
        ["Button_rise"]   = {["ended"] = "butAdd"}, 

        ["Slider_chip"]   = {["ON_PERCENTAGE_CHANGED"] = "addChipsSlider"}, 

        ['Button_chip1']  = {["ended"] = "addChip1"}, 
        ["Button_chip2"]  = {["ended"] = "addChip2"}, 
        ["Button_chip3"]  = {["ended"] = "addChip3"}, 
        ["Button_allIn"]  = {["ended"] = "addChipAll"}, 

        ["Button_confirm"]  = {["ended"] = "confirmChip"}, 
        ['Image_preOpr1']   = {["ended"] = "preOperate1"}, 
        ['Image_preOpr2']   = {["ended"] = "preOperate2"}, 
        ['Image_preOpr3']   = {["ended"] = "preOperate3"}, 
        ['Image_endShow']   = {["ended"] = "endShowCard"},  
        ['Button_endShow']  = {["ended"] = "butEndShowCard"}, 

}
UIGameTableDeZhou.Texus = DataUnpacker.CMD[DataUnpacker.Type.Texus]['REQ'] 
--登出请求
function UIGameTableDeZhou:butBack()
    if not self.myCarry then self.myCarry = 0 end 
    local app = self.app
	--if UIGameTableDeZhou.bt_LotteryNode ~= nil then
		--UIGameTableDeZhou.bt_LotteryNode:removeFromParent()
		--UIGameTableDeZhou.bt_LotteryNode = nil
	--end
    if  self.myRoundState ~= 0  then 
        G_BASEAPP:addView('UIDialog',999999)
        G_BASEAPP:callMethod('UIDialog','setupDialog', '','确定退出房间?',
                    function() 
                        self:startOrEndTime(2)
                        self:closeTexusTcp()
                        self.PlayerData.coin = self.PlayerData.coin + self.myCarry
                        G_BASEAPP:callMethod('UIMain','updateWealth')
                        G_BASEAPP:removeView('UIGameTableDeZhou')
                    end,
                    function() 
                        print('cancle LeaveTexusRoom')
                    end) 
        self:HideLeave()
    else 
        self:startOrEndTime(2)
        self.PlayerData.coin = self.PlayerData.coin + self.myCarry
        self.app:callMethod('UIMain','updateWealth')
        self:closeTexusTcp()
        G_BASEAPP:removeView('UIGameTableDeZhou')
    end 
    G_BASEAPP:callMethod('UIMain','showEnterMainActions')
end 

function UIGameTableDeZhou:closeTexusTcp()
        self:reqSock_EXIT_RQ()           --登出       
        self:stopSchedule('heartbeat') 
end     

function UIGameTableDeZhou:reqSock_EXIT_RQ()
    local bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['EXIT_RQ'])
    local buffer = bufferHnd:doPack()
    UIGameTableDeZhou.hallTcpInstance:sendData(buffer)
    UIGameTableDeZhou.hallTcpInstance:closeAndRelease()
end     
 

--小红点
function UIGameTableDeZhou:msgRedPoint(num)
   self['Image_msgRedPoint']:setVisible(num~=0)
end 


--牌型
function UIGameTableDeZhou:showCardType()
    if self.cardTypeCreate == true then 
        local language = {{'皇家同花顺','同花顺','金刚','葫芦','同花','顺子','三条','两对','一对','高牌'},
        {'Royal Flush','Straight Flush','Four of a kind','Full House','Flush','Straight','Three of a kind','Two Pairs','One Pair','High Card'}}   
        local temp = {                                                
            {'card/card_hearts_1.png','card/card_hearts_13.png','card/card_hearts_12.png','card/card_hearts_11.png','card/card_hearts_10.png'},           
            {'card/card_diamonds_9.png','card/card_diamonds_8.png','card/card_diamonds_7.png','card/card_diamonds_6.png','card/card_diamonds_5.png'},           
            {'card/card_spades_1.png','card/card_hearts_1.png','card/card_diamonds_1.png','card/card_clubs_1.png','card/card_clubs_13.png'},          
            {'card/card_spades_1.png','card/card_hearts_1.png','card/card_diamonds_1.png','card/card_clubs_13.png','card/card_hearts_13.png'},          
            {'card/card_spades_1.png','card/card_spades_10.png','card/card_spades_7.png','card/card_spades_4.png','card/card_spades_2.png'},               
            {'card/card_clubs_8.png','card/card_diamonds_7.png','card/card_hearts_6.png','card/card_spades_5.png','card/card_diamonds_4.png'},               
            {'card/card_spades_1.png','card/card_hearts_1.png','card/card_diamonds_1.png','card/card_diamonds_13.png','card/card_hearts_11.png'},                   
            {'card/card_spades_1.png','card/card_hearts_1.png','card/card_diamonds_13.png','card/card_hearts_13.png','card/card_hearts_11.png'},                
            {'card/card_spades_1.png','card/card_hearts_1.png','card/card_hearts_13.png','card/card_hearts_12.png','card/card_spades_11.png'},
            {'card/card_spades_13.png','card/card_hearts_10.png','card/card_diamonds_7.png','card/card_spades_4.png','card/card_spades_2.png'}    
        }
        local item = self['Panel_cardTypeModel']
        self['ListView_cardType']:setItemModel(item) 

        local model 
        for key ,var in pairs(temp)   do 
            self['ListView_cardType']:pushBackDefaultItem()
            model = self['ListView_cardType']:getItem(key-1)
            if key%2 == 0 then  model:setBackGroundColor(cc.c3b(51,44,87)) end 
            model:getChildByName('Image_1'):loadTexture(var[1],ccui.TextureResType.plistType)
            model:getChildByName('Image_2'):loadTexture(var[2],ccui.TextureResType.plistType)
            model:getChildByName('Image_3'):loadTexture(var[3],ccui.TextureResType.plistType)
            model:getChildByName('Image_4'):loadTexture(var[4],ccui.TextureResType.plistType)
            model:getChildByName('Image_5'):loadTexture(var[5],ccui.TextureResType.plistType)
            model:getChildByName('Text_detail'):setString(language[self.langeageType][key]) 
        end 
        self.cardTypeCreate = false 
    end 

    local size = self['Panel_cardType']:getContentSize()
    local move1 = cc.MoveBy:create(0.1,cc.p(size.width,0))    
    self['Panel_cardType']:runAction(move1)
end 

function UIGameTableDeZhou:hideCardType()
    local size = self['Panel_cardType']:getContentSize()
    local move1 = cc.MoveBy:create(0.1,cc.p(-size.width,0))    
    self['Panel_cardType']:runAction(move1)
end 

function UIGameTableDeZhou:LeaveHall(from)
    if self.menuActivated == true then return end
    -- if type(from) == 'string' then
    --     self.app.goBackActionQueue:pop()
    -- end
    local size = self['Panel_leave']:getContentSize()
    local move1 = cc.MoveBy:create(0.1,cc.p(size.width,0))    
    self['Panel_leave']:runAction(move1) 
    self.menuActivated = true

end 

function UIGameTableDeZhou:HideLeave()
    local size = self['Panel_leave']:getContentSize()
    local move1 = cc.MoveBy:create(0.1,cc.p(-size.width,0))   
    self['Panel_leave']:runAction(move1)
    self.menuActivated = false
    -- self.app:addGobackEventAction(function()
    --     self:LeaveHall('1')
    -- end)

end 

function UIGameTableDeZhou:butShop()
    self.app:addView('UIQuickBuy',self:getLocalZOrder() + 10)
end 

--更新时间
function UIGameTableDeZhou:upateTime()
    local time = os.date("%X",os.time())
    time = string.sub(time,1,5)
    --self['Text_nowTime']:setString(time)
end 

--送礼物  butBuyGift  
function UIGameTableDeZhou:reqSock_GIVE_GIFT(uid,giftId) 
    local bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['GIVE_GIFT'])
    bufferHnd:writeData(uid,DataPacker.INT)   
    bufferHnd:writeData(giftId,DataPacker.BYTE)    
    bufferHnd:writeData(1,DataPacker.SHORT)    
    UIGameTableDeZhou.hallTcpInstance:sendData(bufferHnd:doPack())
end 




--踢人   butLetGo
function UIGameTableDeZhou:reqSock_LET_GO(uid)
    local bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['LET_GO'])
    bufferHnd:writeData(uid,DataPacker.INT)    
    UIGameTableDeZhou.hallTcpInstance:sendData(bufferHnd:doPack())
end 


--换桌
function UIGameTableDeZhou:butChange() 
   if self.myRoundState == 0 then  --牌局未开始直接换桌
      self:reqSock_CHANGE_TAB() 
      self:initEverything()
   else 
       G_BASEAPP:addView('UIDialog',999999)
        G_BASEAPP:callMethod('UIDialog','setupDialog', '','确定要换桌?',
                    function() 
                        self:reqSock_CHANGE_TAB() 
                    end,
                    function() 
                        print('cancle changeTab')
                    end) 
   end  
   self.tool:freezeWidget(self['Button_changeTab'], 3)
end 

function UIGameTableDeZhou:reqSock_CHANGE_TAB()
    local bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['CHANGE_TAB'])
    bufferHnd:writeData(0,DataPacker.BYTE)   
    UIGameTableDeZhou.hallTcpInstance:sendData(bufferHnd:doPack())
end 
--------------------------
function UIGameTableDeZhou:initMyCardInfo()
    for key =1 ,5 do 
        self['Image_card_show'..key]:setVisible(false)
        self['Image_card_show'..key]:loadTexture('card/card_back.png',ccui.TextureResType.plistType)
        self['Image_card_show'..key]:getChildByName('Image_lightBg'):setVisible(false)
    end 
    
    self:endProgress()
    for key = 1 ,8 do 
        self['Panel_Pool'..key]:setVisible(false)
    end 
    if  self['Panel_me']:getChildByName('Image_moveChip') then 
        self['Panel_me']:removeChildByName('Image_moveChip')
    end 
    self['Panel_me']:getChildByName('Image_endCard1'):setVisible(false)
    self['Panel_me']:getChildByName('Image_endCard2'):setVisible(false)
    self['Panel_me']:getChildByName('Image_endCard1'):loadTexture('card/card_back.png',ccui.TextureResType.plistType)
    self['Panel_me']:getChildByName('Image_endCard2'):loadTexture('card/card_back.png',ccui.TextureResType.plistType)

    self['Panel_me']:getChildByName('Image_chip'):setVisible(false)
    self['Image_myCard1']:setVisible(false)
    self['Image_myCard2']:setVisible(false)
    self['Image_myCard1']:loadTexture('card/card_back.png',ccui.TextureResType.plistType)
    self['Image_myCard2']:loadTexture('card/card_back.png',ccui.TextureResType.plistType) 
    self['Panel_me']:getChildByName('Image_lightCard1'):setVisible(false)
    self['Panel_me']:getChildByName('Image_lightCard2'):setVisible(false)
    self.myRoundState = 0 
    self['Text_Mychips']:setString('')
    self['Text_myName']:setString(self.PlayerData.nick) 
    self['Image_myHead']:setColor(cc.c3b(255,255,255))
    self['Panel_me']:setColor(cc.c3b(255,255,255))
    self['Image_cardTypeBg']:setVisible(false)
    self['Image_endShow']:setVisible(false)
end     

--初始化所有
function UIGameTableDeZhou:initEverything()
    self:initMyCardInfo()
    self['Button_endShow']:setVisible(false)             

    self['CheckBox_show']:setSelected(false)
    self['Button_call']:setTitleText(self.languageTable[self.langeageType][1])
    self['Text_riseName']:setVisible(false)
    self['Image_cardTypeBg']:loadTexture('game/game_card_bg.png',ccui.TextureResType.plistType)
    self['Image_cardTypeBg']:getChildByName('Image_mycardtype'):setColor(cc.c3b(255,255,255))
    self.poolNum  = 1     
    self['Image_myZh']:setVisible(false)
    for key,var in pairs(self.pos_tab) do 
        if  var:getChildByName('Image_moveChip') then 
            var:removeChildByName('Image_moveChip')
        end 

        if  var:getChildByName('inviteFriend')   then 
            var:removeChildByName('inviteFriend')
        end     
        if var == self['Panel_me'] then         
           self['Text_Mychips']:setString('')
        else 
           var:getChildByName('Image_chip'):getChildByName('Text_chip'):setString('')
        end 
        var:getChildByName('Image_chip'):setColor(cc.c3b(255,255,255))
        if var ~= self['Panel_me'] then 
           var:getChildByName('Image_zhuang'):setVisible(false)        
        end    
        if var:getChildByName('Image_model') then 
            --var:setOpacity(255)
            var:setColor(cc.c3b(255,255,255))    
            var:getChildByName('Image_model'):setColor(cc.c3b(255,255,255))                
            local parent  = var:getChildByName('Image_model'):getChildByName('Panel_endCard') 
            parent:setVisible(false)
            parent:getChildByName('Image_endCardBG'):setVisible(false)
            parent:getChildByName('Image_endCard1'):loadTexture('card/card_back.png',ccui.TextureResType.plistType)
            parent:getChildByName('Image_endCard2'):loadTexture('card/card_back.png',ccui.TextureResType.plistType)
            parent:getChildByName('Image_lightCard1'):setVisible(false)
            parent:getChildByName('Image_lightCard2'):setVisible(false)
            parent:getChildByName('Image_endCardBG'):loadTexture('game/game_card_bg.png',ccui.TextureResType.plistType)
            parent:getChildByName('Image_endCardBG'):getChildByName('Card_type'):setColor(cc.c3b(255,255,255))  
            if  var:getChildByName('Image_model'):getChildByName('Image_head'):getChildByName('swapMenu') then 
                var:getChildByName('Image_model'):getChildByName('Image_head'):getChildByName('swapMenu'):setColor(cc.c3b(255,255,255))
            end              
        end  
    end  
end 



function UIGameTableDeZhou:butaddChips()
    local max = (self.PlayerData.coin >= self.maxCarry) and self.maxCarry or self.PlayerData.coin
    self.app:addView('UISupplyChips',self:getLocalZOrder()+20,max,function(num) self:reqSock_BUY_CHIP(num) end )
end 



--更新用户信息请求
function UIGameTableDeZhou:reqSock_UPDATA_INFO() 
    local bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['UPDATA_INFO'])
    UIGameTableDeZhou.hallTcpInstance:sendData(bufferHnd:doPack())
end 

--购买筹码   initBuyChips
function UIGameTableDeZhou:reqSock_BUY_CHIP(num)
    local bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['BUY_CHIP'])
    local chip = tonumber(num)
    bufferHnd:writeData(chip,DataPacker.LONG)    
    UIGameTableDeZhou.hallTcpInstance:sendData(bufferHnd:doPack())    
end 

-- 设置自动补充筹码  saveBuyChips 
function UIGameTableDeZhou:reqSock_AUTO_BUY(tag,less,to) 
    local bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['AUTO_BUY'])
    bufferHnd:writeData(tag,DataPacker.BYTE)  
    bufferHnd:writeData(less,DataPacker.LONG)      
    bufferHnd:writeData(to,DataPacker.LONG)   
    UIGameTableDeZhou.hallTcpInstance:sendData(bufferHnd:doPack())  
end 

function UIGameTableDeZhou:butChat()
    self.app:addView('UIFaceicon',self:getLocalZOrder() +10,function(tab) 
        local  tag  = tab.msgType
        local  msg  = tab.msg 
        if tag == 1 then --face 
             self:reqSock_CHAT_FACE(msg)
        elseif tag == 2 then --common
             self:reqSock_CHAT_COMMON(msg)
        elseif tag == 3 then --word 
             self:reqSock_CHAT_WORD(msg)
        else  
            return 
        end        
    end)
end 
--任务
function UIGameTableDeZhou:butTask()
    self.app:addView('UITask',self:getLocalZOrder() +10,4,function(tag) self['Button_task']:getChildByName('Image_10'):setVisible(tag) 
        end ,
        function(arg)   self.PlayerData.coin =tonumber(arg.coin) end ) 
end 
--请求更新任务列表
function UIGameTableDeZhou:askTaskRedPoint()
    local table = {
        ['uid']    = self.PlayerData.uid, 
        ['token']  = self.PlayerData.token,
        ['cmd']    = HttpHandler.CMDTABLE.GET_TASK }
    local function succ(arg)
        if arg.result == 0  then  
            for key,var in pairs(arg.mission) do 
                if tonumber(var.TaskProcess) == -1 then 
                   self:showOrHideTask(1)
                   break
                end 
            end        
        end 
    end     
    self.tool:fastRequest(table,succ)


    -- local tab = {
    --     ['uid']      = G_UID, 
    --     ['token']    = G_TOKEN,
    --     ['gameType'] = delegate.taskGameType, 
    --     ['version']  = UserCache.getUserDataByKey("task_version"..delegate.taskGameType) or '',
    --     ['cmd']      = HttpHandler.CMDTABLE.GET_TASK  
    -- }    
    -- if delegate['Image_tackNotification'] then 
    --    delegate['Image_tackNotification']:setVisible(false)
    -- end 
    -- local temp_gameType = delegate.taskGameType
    -- local function  cbSuccess(arg)
    --     UserCache.setUserDataByKey("task_version"..temp_gameType,arg.version)
    --     if #arg.desc > 0 then 
    --        UserCache.setUserDataByKey("task_desc_get"..temp_gameType,arg.desc)
    --     end        
    --         for key,var in pairs(arg.state) do 
    --         if tonumber(var.State) == -1 then 
    --            delegate['Image_tackNotification']:setVisible(true)
    --            break 
    --         end 
    --     end           
    -- end    
    -- LuaTools.fastRequest(tab,cbSuccess)
end 

function UIGameTableDeZhou:askFriendUid()
    local paTable =     {
        ['uid']   = tonumber(self.PlayerData.uid),
        ['token'] = self.PlayerData.token,
        ['cmd']   = HttpHandler.CMDTABLE.GET_FRIEND_LIST
    } 
    local function succ(arg)
        for key,var in pairs(arg.items) do 
            table.insert(self.PlayerData.friendUid,tonumber(var.uid))
        end     
    end 
    self.tool:fastRequest(paTable,succ)
end 

--任务红点   1:显示  ，2：不显示
function UIGameTableDeZhou:showOrHideTask(tag)
   self['Button_task']:getChildByName('Image_10'):setVisible(tag==1)
end 

function UIGameTableDeZhou:butShowChat()
    --self.app:addView('UIChat',108)
end 

--坐下协议  butSit 
function UIGameTableDeZhou:reqSock_SIT_DOWN(chip)
    if  not chip  then  print('坐下时购买筹码出错') end 
    if  not self.selectSeat  then  self.selectSeat = 255 end 

    local bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['SIT_DOWN'])
    bufferHnd:writeData(self.selectSeat,DataPacker.BYTE)  
    bufferHnd:writeData(chip,DataPacker.LONG)  
    UIGameTableDeZhou.hallTcpInstance:sendData(bufferHnd:doPack())    
end 

--站起
function UIGameTableDeZhou:butStand()
    if self.myRoundState == 0 then  
        self:initEverything()
        self:reqSock_STAND_UP() 
    else 
        --self.app:addView('UIStandUp',125,2)  
        G_BASEAPP:addView('UIDialog',999999)
        G_BASEAPP:callMethod('UIDialog','setupDialog', '','确定要站起?',
                    function() 
                        self:reqSock_STAND_UP() 
                    end,
                    function() 
                        print('cancle butStand')
                    end) 
    end  
    self:HideLeave()
end 

function UIGameTableDeZhou:reqSock_STAND_UP()
    local bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['STAND_UP'])
    UIGameTableDeZhou.hallTcpInstance:sendData(bufferHnd:doPack())
end 

--坐下按钮
function UIGameTableDeZhou:butSitDown()     
    local chip 
    if self.PlayerData.coin >= self.maxCarry/2 then 
       chip = self.maxCarry/2
    elseif self.PlayerData.coin >= self.minCarry then 
       chip = self.minCarry 
    else 
       self.tool:showTips('您的金币不足，请及时补充')   
       return 
    end         
    self:reqSock_SIT_DOWN(chip)
    self['Button_mySitDown']:setVisible(false)
end 

function UIGameTableDeZhou:preOperate1()  
    self:prepareEvent(1,2,3)  
end 

function UIGameTableDeZhou:prepareEvent(a,b,c)
    self['CheckBox_pre'..a]:setSelected(not self['CheckBox_pre'..a]:isSelected()) 
    if self['CheckBox_pre'..a]:isSelected() then 
        self['Image_preOpr'..a]:loadTextures('game/game_btn_4_1.png','game/game_btn_4_1.png','game/game_btn_4_1.png',ccui.TextureResType.plistType)
    else 
    
        self['Image_preOpr'..a]:loadTextures('game/game_btn_4.png','game/game_btn_4.png','game/game_btn_4.png',ccui.TextureResType.plistType)
    end 
    if self['CheckBox_pre'..a]:isSelected() then 
        self['CheckBox_pre'..b]:setSelected(false)
        self['CheckBox_pre'..c]:setSelected(false)
    end   
end 



function UIGameTableDeZhou:preOperate2()
    self:prepareEvent(2,1,3)  
end 

function UIGameTableDeZhou:preOperate3()
    self:prepareEvent(3,2,1)  
end 

function UIGameTableDeZhou:endShowCard()
    self['CheckBox_show']:setSelected(not self['CheckBox_show']:isSelected()) 
end 

function UIGameTableDeZhou:butEndShowCard()
    self['Button_endShow']:setVisible(false) 
    local bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['SHOW_CARD'])
    UIGameTableDeZhou.hallTcpInstance:sendData(bufferHnd:doPack())

    self.showCardState  = 1  
    if self.myTwoCards and #self.myTwoCards > 0 then 
        local a,b = self['Panel_me']:getChildByName('Image_endCard1'),self['Panel_me']:getChildByName('Image_endCard2')
        local card1,card2 = self.PlayerData:getCard(self.myTwoCards[1]),self.PlayerData:getCard(self.myTwoCards[2])
        self:rotateCard(a,card1)  
        self:rotateCard(b,card2)  
        self['Image_myCard1']:setVisible(false)
        self['Image_myCard2']:setVisible(false)
        self['Panel_me']:getChildByName('Image_lightCard1'):setVisible(false)
        self['Panel_me']:getChildByName('Image_lightCard2'):setVisible(false)
    end
end 

--跟注 /看牌
function UIGameTableDeZhou:butFollow()
    -- printf('跟注 /看牌')  
    self:switchOperate(2) 

    local bufferHnd
    if self['Text_riseName']:isVisible() then 
        bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['FOLLOW_CHIP'])
    elseif  self['Button_call']:getTitleText() == self.languageTable[self.langeageType][1] then   
        bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['SEE_CARD'])
    else 
        bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['ALL_IN'])
    end      

    UIGameTableDeZhou.hallTcpInstance:sendData(bufferHnd:doPack())
end

function UIGameTableDeZhou:hideAddChips()
    local size = self['Panel_addChips']:getContentSize()
    local x,y =  self['Panel_addChips']:getPosition() 
    if y~= self.addChipsPosY then 
        local move1 = cc.MoveBy:create(0.1,cc.p(0,-size.height))   
        self['Panel_addChips']:runAction(move1)
    end 
end 


--加注
function UIGameTableDeZhou:butAdd()
    self['Panel_addChips']:setVisible(true)
    local size = self['Panel_addChips']:getContentSize()
    local move1 = cc.MoveBy:create(0.1,cc.p(0,size.height))   
    self['Panel_addChips']:runAction(move1)

    local my = tonumber(self['Text_Mychips']:getString()) 
    if not my then my = 0  end  
    local a = self.maxChip-my 
    local num =( self.bigBlind>(self.maxChip-my) *2 ) and  self.bigBlind or (self.maxChip-my) *2 
    if a >= self.myCarry then num = self.myCarry end  
    if num > self.myCarry then  num = self.myCarry  end 
    
    
       
    self['Text_addChip']:setString(num == self.myCarry and 'All In' or num)
    self.addChipInit = num    --  self.addChipInit 打开加注页面时，初始化最低加注筹码 
    self["Slider_chip"]:setPercent(num == self.myCarry and 100 or 0) 
    self["Slider_chip"]:setTouchEnabled(num ~= self.myCarry)
    
    self['Button_chip3']:setTouchEnabled(self.myCarry >= self.bigBlind and true or false )
    self['Button_chip3']:setBright(self.myCarry >= self.bigBlind and true or false )

    self['Button_chip2']:setTouchEnabled(self.myCarry >= self.bigBlind*5 and true or false )
    self['Button_chip2']:setBright(self.myCarry >= self.bigBlind*5 and true or false )

    self['Button_chip1']:setTouchEnabled(self.myCarry >= self.bigBlind*10 and true or false )
    self['Button_chip1']:setBright(self.myCarry >= self.bigBlind*10 and true or false )
end

function UIGameTableDeZhou:addChipsSlider(event)
    local percent = event.target:getPercent()
    local num = (self.myCarry-self.addChipInit)/100*percent+self.addChipInit
    self['Text_addChip']:setString(num~=self.myCarry and  math.floor(num) or 'All In')
end

--确认加注
function UIGameTableDeZhou:confirmChip()
    self:switchOperate(2) 

    --local bufferHnd = DataPacker.new(self.PlayerData.ROOM_ADD_CHIP)
    local bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['ADD_CHIP'])
    local str = self['Text_addChip']:getString()
    if str == 'All In' then 
       self:reqSock_ALL_IN() 
    else   
        bufferHnd:writeData(str,DataPacker.LONG) 
        UIGameTableDeZhou.hallTcpInstance:sendData(bufferHnd:doPack())
    end    
    self:hideAddChips()
end 

function UIGameTableDeZhou:addChip1()
    local money = self['Button_chip1']:getTitleText()
    self:resSlider(money)
end 
function UIGameTableDeZhou:addChip2()
    local money = self['Button_chip2']:getTitleText()
    self:resSlider(money)
end 

function UIGameTableDeZhou:addChip3()
    local money = self['Button_chip3']:getTitleText()
    self:resSlider(money)
end 

function UIGameTableDeZhou:addChipAll()
    self["Slider_chip"]:setPercent(100)
    self['Text_addChip']:setString('All In')
end 

function UIGameTableDeZhou:resSlider(money)
    local coin
    if self['Text_addChip']:getString() == 'All In' then  
        coin = self.myCarry
    else     
        coin = tonumber(money)+tonumber(self['Text_addChip']:getString())
    end    
    if coin>self.myCarry then coin = self.myCarry end 
    self["Slider_chip"]:setPercent((coin)/self.myCarry*100) 
    self['Text_addChip']:setString(coin==self.myCarry and 'All In' or coin)
end 

-- 弃牌  butAbandon
function UIGameTableDeZhou:reqSock_ABANDON_CARD()
    self:switchOperate(2) 

    local bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['ABANDON_CARD']) 
    UIGameTableDeZhou.hallTcpInstance:sendData(bufferHnd:doPack())
end

--全下  butAllIn
function UIGameTableDeZhou:reqSock_ALL_IN()
    local bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['ALL_IN'])
    UIGameTableDeZhou.hallTcpInstance:sendData(bufferHnd:doPack())
end

--文字聊天  butChatWord 
function UIGameTableDeZhou:reqSock_CHAT_WORD(str)
    local bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['CHAT_WORD'])
    bufferHnd:writeData(str,DataPacker.STRING) 
    UIGameTableDeZhou.hallTcpInstance:sendData(bufferHnd:doPack())
end

--表情聊天  butChatFace
function UIGameTableDeZhou:reqSock_CHAT_FACE(id)
    local bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['CHAT_FACE'])
    bufferHnd:writeData(id,DataPacker.SHORT) 
    UIGameTableDeZhou.hallTcpInstance:sendData(bufferHnd:doPack())
end

--常用语聊天 butChatCommon
function UIGameTableDeZhou:reqSock_CHAT_COMMON(id)
    local bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['CHAT_COMMON'])
    bufferHnd:writeData(id,DataPacker.SHORT) 
    UIGameTableDeZhou.hallTcpInstance:sendData(bufferHnd:doPack())
end

--请求添加好友  butAskFriend
function UIGameTableDeZhou:reqSock_ASK_FRI(uid)
    local bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['ASK_FRI'])
    bufferHnd:writeData(uid,DataPacker.INT)   
    UIGameTableDeZhou.hallTcpInstance:sendData(bufferHnd:doPack())
end 
--响应添加好友  butIfAddFriend
function UIGameTableDeZhou:reqSock_RES_FRI(uid,tag)
    local bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['RES_FRI'])
    bufferHnd:writeData(uid,DataPacker.INT)   
    bufferHnd:writeData(tag,DataPacker.BYTE)    
    UIGameTableDeZhou.hallTcpInstance:sendData(bufferHnd:doPack())
end 
----------------------------------------------------

function UIGameTableDeZhou:onCreate(tag)
    if not tag then tag = 76 end 
    local app = self:getApp()

    self.menuActivated = false
    self.app = app
    --self.app:addView('UIChat',108)
    self.tableTypeTag = tag 
    self.openGameTesuxView = true 
    
    self.languageTable = {{'看牌','全下','跟注','网络错误!!!','思考中...','大盲注','小盲注','加注','弃牌'},
        {'Check','All In','Call ','net wrong!!!','Thinking..','BB','SB','Rise','Fold'}}     
    self.langeageType = 1 
    self.PlayerData = app:getData('PlayerData')
    self.pData = self.PlayerData
    self.tool = app:getModel('Tools')
    self.config = app:getData('Config')
    self.main = app:getModel('Main')
    self:setUpTexusTcp()

    self.cardTypeCreate = true       
    self.waitingTime = 0 
    self.operateTime = 0 
    self.leftTopShow = true 
    self.mySeat_id   = 0
    self.littleBlind = 0 
    self.bigBlind    = 0 
    self.maxCarry    = 0 
    self.minCarry    = 0 
    self.countTcp = 1
    self:startOrEndTime(1)
    self.OpertateX,self.OpertateY  = self['Panel_preOperate']:getPosition() 

    --self.sound:playMusic('HallBgMusic')   

    self:initBroadcastUI()
    self.talkPosX,self.talkPoxY = self['Text_MytalkPos']:getPosition() 
    self.addChipsPosX ,self.addChipsPosY = self['Panel_addChips']:getPosition() 
    self["Button_rise"]:setPressedActionEnabled(false) 
    self.playerSexTab = {} 
    --self:upateTime() 
    self['Image_preOpr1']:setPressedActionEnabled(false)
    self['Image_preOpr2']:setPressedActionEnabled(false)
    self['Image_preOpr3']:setPressedActionEnabled(false)
    
    self['Panel_MytalkPos']:setVisible(false)
    --self:askTaskRedPoint()   --更新任务小红点 
    if G_LOADINGVIEW then
        G_BASEAPP:removeView('UILoading')
        G_LOADINGVIEW = nil
    end

    self.ALLposition = {} 

    local function onKeyReleased(keyCode, event)
        if keyCode == cc.KeyCode.KEY_BACK  then
            if self.menuActivated ~= true then
                self:LeaveHall()
                self:closeTexusTcp()
                G_BASEAPP:callMethod('UIMain','showEnterMainActions')
                self.PlayerData.coin = self.PlayerData.coin + self.myCarry
                G_BASEAPP:callMethod('UIMain','updateWealth')
                self:startOrEndTime(2)
            else
                self:butBack()
            end
        end
    end
    local listener = cc.EventListenerKeyboard:create()
    listener:registerScriptHandler(onKeyReleased, cc.Handler.EVENT_KEYBOARD_RELEASED )
    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener, self)

    -- self['power_Bar']:setVisible(false)
    -- self['Image_netStatus']:setVisible(false)
    
    -- local tempBattery,tempWifi = LuaTools.getBatteryStatus(),LuaTools.getNetworkStatus()
    -- if tempBattery then      
    --     self['power_Bar']:setVisible(true)
    --     self:callBattery(tempBattery)
    -- end     

    -- if tempWifi then 
    --     self['Image_netStatus']:setVisible(true)
    --     self:callWifi(tempWifi) 
    -- end 
    -- local function updateBatteryStatus(str)
    --     self:callBattery(str)
    -- end
    -- local function updateWifiInfo(str)
    --     self:callWifi(str) 
    -- end 
    -- LuaTools.registerBatteryStatus(updateBatteryStatus)
    -- LuaTools.registerNetworkStatus(updateWifiInfo)
    
end

function UIGameTableDeZhou:setUpTexusTcp()
      UIGameTableDeZhou.hallTcpInstance = TCPGearbox.buildInstance({
            unpackerType = DataUnpacker.Type.Texus, 
            delegate = self,  
            callbackPrefix = "RespCMD_",
            name = 'TexusTCP',
            port = 6840

        })
end     

function UIGameTableDeZhou:RespCMD_onConnected() 
    UIGameTableDeZhou.hallTcpInstance:sendData(self:reqSock_Login(self.tableTypeTag,0,0))
    self:sendHeartbeat()  
end     

function UIGameTableDeZhou:reqSock_Login(tableType,friendID,RoomId) 
     local bufferHnd =DataPacker.new(UIGameTableDeZhou.Texus['LOGIN'])
     bufferHnd:writeData(G_UID,DataPacker.INT)
     bufferHnd:writeData(G_TOKEN,DataPacker.STRING)
     bufferHnd:writeData(tableType,DataPacker.INT) 
     bufferHnd:writeData(friendID,DataPacker.INT)
     bufferHnd:writeData(RoomId,DataPacker.INT)
     bufferHnd:writeData(0,DataPacker.BYTE)
     return bufferHnd:doPack()
end

function UIGameTableDeZhou:sendHeartbeat()
    self:stopSchedule('heartbeat')
    self:createSchedule('heartbeat', function()   
        self:reqSock_HeartBeat() 
    end,20)  
end

function  UIGameTableDeZhou:reqSock_HeartBeat()
    local bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['HEARTBEAT'])
    local buffer = bufferHnd:doPack()
    UIGameTableDeZhou.hallTcpInstance:sendData(buffer)
end     

function UIGameTableDeZhou:initBroadcastUI()
    local function onEnterChat(event)
        if event.name == 'ended' then
            self.app:addView('UIChat',self:getLocalZOrder()+20)
        end  
    end
    self.broadCastType = 'end'
    --self['Panel_LimitB']:setEnabled(false)
    --self['Panel_LimitB']:setTouchEnabled(false)
    self['Image_broadBg']:setVisible(false)
    self['Panel_chat']:setTouchEnabled(true)
    self['Panel_chat']:onTouch(onEnterChat)
    self['Button_horn']:onTouch(onEnterChat)
end


--宝箱
function UIGameTableDeZhou:startOrEndTime(kind) 
    local pData = G_BASEAPP:getData('PlayerData')
    --kind=1表示开始计时，kind =2 表示结束计时     宝箱按钮的名称需改为‘Button_rewardBox’ ，倒计时文本名：'Text_rewardBox_time'
    local total_time = {60,180,300,600,1200,1800} 

    local function countTime(time)
        local function  callback()       
                local minute = math.floor(time/60)
                local second = time - minute*60
                local temp = string.format("%02d:%02d",minute,second) 
                self['Text_rewardBox_time']:setString(time >=1 and temp or '领取奖励')  
                --delegate['Button_rewardBox']:setEnabled(time<=0)
                time = time -1
                if time < 0 then 
                    if self['Panel_boxReward'] then 
                        if not self['Panel_boxReward']:getChildByName('newBoxLight') then 
                            UIGameTableDeZhou.bt_LotteryNode = cc.CSLoader:createNode('Animation_box.csb') 
                            UIGameTableDeZhou.bt_LotteryNode:setPosition(cc.p(self['Panel_boxReward']:getContentSize().width/2-4,self['Panel_boxReward']:getContentSize().height/2+1))
                            local action = cc.CSLoader:createTimeline('Animation_box.csb')
                            UIGameTableDeZhou.bt_LotteryNode:runAction(action)
                            UIGameTableDeZhou.bt_LotteryNode:setName('newBoxLight')
                            action:gotoFrameAndPlay(0,true)
                            self['Panel_boxReward']:addChild(UIGameTableDeZhou.bt_LotteryNode,10)  
                        end     
                        self['Panel_boxReward']:setVisible(true)
                        --delegate['Panel_boxReward']:getChildByName('Image_rotate'):runAction(cc.RepeatForever:create(cc.RotateBy:create(3,180)))
                        self['Button_rewardBox']:setVisible(false)

                    end     
                    self:stopSchedule('BoxRewardScheduler')   
                end  
        end 
        self:createSchedule("BoxRewardScheduler", callback, 1)  
    end 


    if kind == 2 then --结束计时
       time  = pData.getReward
       local s = self['Text_rewardBox_time']:getString()
       self:stopSchedule('BoxRewardScheduler')
       
       if not s or s=='' then return  end   

       if s == '领取奖励' then 
          clock = total_time[time]
       else 
          local a,b = tonumber(string.sub(s,1,2))*60,tonumber(string.sub(s,4,5))
          clock =total_time[time] - (a+b)
       end    
    end 

    local tab = {
        ['uid']    = pData.uid, 
        ['token']  = pData.token,
        ['type']   = kind, 
        ['time']   = time,
        ['clock']  = clock,
        ['cmd']    = HttpHandler.CMDTABLE.GET_ONLINE_TIME,
    }    
    self.bonusCount = 0
    local function  cbSuccess(arg)
        if kind == 1 then 
            self.bonusCount = (arg.time == false and 1 or tonumber(arg.time))
            if self.bonusCount > 6 then 
               self['Button_rewardBox']:setVisible(false)
               return  
            end 
            pData.getReward =  self.bonusCount 
            local go_time = (arg.clock == false and 0 or tonumber(arg.clock))

            local left = total_time[self.bonusCount]- go_time     
            countTime(left)  
        end    

        local function rewardBoxCallback(event)
                if event.name == 'ended' then
                    local paTable =     {
                        ['uid']       = pData.uid, 
                        ['token']     = pData.token,
                        ['time']      =  self.bonusCount or 1,
                        ['cmd']       = HttpHandler.CMDTABLE.GET_ONLINE_REWARD,
                    }

                    if self['Text_rewardBox_time']:getString() == '领取奖励' then 
                        self['Text_rewardBox_time']:setString('')
                        if self['Panel_boxReward'] then 
                           self['Panel_boxReward']:setVisible(false)
                           self['Button_rewardBox']:setVisible(true)
                           audio.playSound(Sound.SoundTable['sfx']['Task'] , false)
                        end   
                    else 
                        LuaTools.showAlert('领奖时间未到')
                        return
                    end     
                    LuaTools.fastRequest(paTable,function(arg)
                        self.bonusCount =  self.bonusCount + 1 
                        pData.getReward =  self.bonusCount  
                        if  self.bonusCount > 6 then 
                            self['Button_rewardBox']:setVisible(false)
                            self['Text_rewardBox_time']:setString('')
                            return  
                        end  
                        countTime(total_time[self.bonusCount]) 
                        if arg.coin then
                            pData.coin = arg.coin
                        end 
                        LuaTools.showAlert(tostring(arg.msg) )
                    end)
                end
        end
        self['Button_rewardBox']:onTouch(rewardBoxCallback)
        if self['Panel_boxReward'] then 
            self['Panel_boxReward']:onTouch(rewardBoxCallback) 
        end     
    end    
    LuaTools.fastRequest(tab,cbSuccess)

end 

--打赏  butGiveFee 
function UIGameTableDeZhou:reqSock_SER_FEE()
    local bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['SER_FEE'])
    UIGameTableDeZhou.hallTcpInstance:sendData(bufferHnd:doPack())
end 
--sendTcp


function UIGameTableDeZhou:initPosition(id)
    if self.TableType < 19 then 
        local temp = {0,1,2,3,4,5,6,7,8}
        for key,var in pairs(temp) do  
            if var == id then 
                table.remove(temp,key)
            end
        end      
        self.seat_id =  temp
        if id == 4 then 
            self.pos_tab = {self['Panel_right1'],self['Panel_right2'],self['Panel_right3'],self['Panel_right4'],self['Panel_left4'],self['Panel_left3'],self['Panel_left2'],self['Panel_left1']}
        elseif id == 0 then   
            self.pos_tab = {self['Panel_left4'],self['Panel_left3'],self['Panel_left2'],self['Panel_left1'],self['Panel_right1'],self['Panel_right2'],self['Panel_right3'],self['Panel_right4']}  
        elseif id == 1 then    
            self.pos_tab = {self['Panel_right4'],self['Panel_left4'],self['Panel_left3'],self['Panel_left2'],self['Panel_left1'],self['Panel_right1'],self['Panel_right2'],self['Panel_right3']}     
        elseif id == 2 then    
            self.pos_tab = {self['Panel_right3'],self['Panel_right4'],self['Panel_left4'],self['Panel_left3'],self['Panel_left2'],self['Panel_left1'],self['Panel_right1'],self['Panel_right2']}         
        elseif id == 3 then               
            self.pos_tab = {self['Panel_right2'],self['Panel_right3'],self['Panel_right4'],self['Panel_left4'],self['Panel_left3'],self['Panel_left2'],self['Panel_left1'],self['Panel_right1']}  
        elseif id == 5 then             
            self.pos_tab = {self['Panel_left1'],self['Panel_right1'],self['Panel_right2'],self['Panel_right3'],self['Panel_right4'],self['Panel_left4'],self['Panel_left3'],self['Panel_left2']}                                                                                                      
        elseif id == 6 then             
            self.pos_tab = {self['Panel_left2'],self['Panel_left1'],self['Panel_right1'],self['Panel_right2'],self['Panel_right3'],self['Panel_right4'],self['Panel_left4'],self['Panel_left3']}                                                                                                     
        elseif id == 7 then             
            self.pos_tab = {self['Panel_left3'],self['Panel_left2'],self['Panel_left1'],self['Panel_right1'],self['Panel_right2'],self['Panel_right3'],self['Panel_right4'],self['Panel_left4']}                                                                                                      
        elseif id == 8 then             
            self.pos_tab = {self['Panel_left4'],self['Panel_left3'],self['Panel_left2'],self['Panel_left1'],self['Panel_right1'],self['Panel_right2'],self['Panel_right3'],self['Panel_right4']}                                                                                                      
        else 
            self.pos_tab = {self['Panel_right1'],self['Panel_right2'],self['Panel_right3'],self['Panel_right4'],self['Panel_centerOne'],self['Panel_left4'],self['Panel_left3'],self['Panel_left2'],self['Panel_left1']}
        end   
    else 
        local temp = {0,1,2,3,4,5}
        for key,var in pairs(temp) do  
            if var == id then 
                table.remove(temp,key)
            end
        end      
        self.seat_id =  temp
        if id == 4 then 
            self.pos_tab = {self['Panel_sixLeft1'],self['Panel_sixRight1'],self['Panel_sixRight2'],
                self['Panel_sixRight3'],self['Panel_sixLeft2']}
        elseif id == 1 then    
            self.pos_tab = {self['Panel_sixRight3'],self['Panel_sixLeft2'],self['Panel_sixLeft1'],
                self['Panel_sixRight1'],self['Panel_sixRight2']}    
        elseif id == 2 then    
            self.pos_tab = {self['Panel_sixRight2'],self['Panel_sixRight3'],self['Panel_sixLeft2'],
                self['Panel_sixLeft1'],self['Panel_sixRight1']} 
        elseif id == 3 then          
            self.pos_tab = {self['Panel_sixRight1'],self['Panel_sixRight2'],self['Panel_sixRight3'],
                self['Panel_sixLeft2'],self['Panel_sixLeft1']}      
        elseif id == 0 or id == 5 then  
            self.pos_tab = {self['Panel_sixLeft2'],self['Panel_sixLeft1'],self['Panel_sixRight1'],
                self['Panel_sixRight2'],self['Panel_sixRight3']}    
        else  
            self.pos_tab = {self['Panel_sixRight1'],self['Panel_sixRight2'],self['Panel_sixRight3'],
                self['Panel_centerOne'],self['Panel_sixLeft2'],self['Panel_sixLeft1']}           
        end   
    end 
    self:flashLight()
end 

function UIGameTableDeZhou:getSeatIds()
    return self.seat_id 
end 
--进入房间初始化数据  InitInfo
function UIGameTableDeZhou:RespCMD_LOGIN_SUCC(info)   
    print('登录房间成功')
    dump(info)
    self.mySeat_id   = info.SeatId
    self.pos_tab  = {} 
    self.seat_id  = {} 
    self.waitingTime = info.BetOnTimeOut
    self.operateTime = info.ReadyTimeOut
    self.littleBlind = info.BaseChip 
    self.bigBlind    = self.littleBlind *2 
    self.TableType   = info.TableType 
    self.TableId     = info.TableId
    self.myCarry = 0
    --self.PlayerData.coin = 0 
    self.myRoundState  = 0
    self['Panel_preOperate']:setVisible(false)    
    self['Panel_operate']:setVisible(false) 
    
    if self.mySeat_id == -1 then 
       self['Panel_me']:setVisible(false)
       LuaTools.showAlert('自动坐下失败，请补充金币')
       self['Button_mySitDown']:setVisible(true)
    end     
    self:initPosition(self.mySeat_id)
    for key,var in pairs(self.pos_tab) do 
        if  var:getChildByName('Image_model')  then 
            var:removeChildByName('Image_model')
            var:getChildByName('Image_card1'):setVisible(false)
            var:getChildByName('Image_card2'):setVisible(false)
            var:getChildByName('Image_chip'):setVisible(false)
            var:getChildByName('Image_zhuang'):setVisible(false) 
        end 
        if  var:getChildByName('Image_moveChip') then 
            var:removeChildByName('Image_moveChip')
        end 
        if  var:getChildByName('inviteFriend')   then 
            var:removeChildByName('inviteFriend')
        end     
--        if var:getChildByName('SIT_DOWN') then 
--            var:removeChildByName('SIT_DOWN')
--        end   
    end 
--    if self['Panel_centerOne']:getChildByName('SIT_DOWN') then 
--       self['Panel_centerOne']:removeChildByName('SIT_DOWN')
--    end 
    
    if  self.mySeat_id>=0 and self.mySeat_id<= 8 then 
        self['Panel_me']:setVisible(true) 
        self['Button_fee']:setTouchEnabled(true)
        self['Button_mySitDown']:setVisible(false)
        self['Panel_centerOne']:setVisible(false)
    end      

    if self.openGameTesuxView == false  then  
        self:stopSchedule('HallScheduler')        
        self['Image_myCard1']:setVisible(false)
        self['Image_myCard2']:setVisible(false)
        self['Panel_me']:getChildByName('Image_lightCard1'):setVisible(false)
        self['Panel_me']:getChildByName('Image_lightCard2'):setVisible(false)

        self['Image_cardTypeBg']:setVisible(false)
        --self:getOnlineReward(1,0,0)  
        
        if self.app:getView('UIAddChips') then 
             self.app:removeView('UIAddChips')
        end
    end 
    print('我的座位位置是'..info.SeatId)
    local spr = (#self.PlayerData.iconPath > 0  and (cc.Sprite:create(self.PlayerData.iconPath)) or (cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[self.PlayerData.sex+1])))
    LuaTools.myheadChange(spr,self['Image_myHead'],self['Panel_me'],G_UID,self:getFriendBrifTab(G_UID))
    self['Image_myHead']:setVisible(true)


    if  self.openGameTesuxView ==true  then 
        self.commonCard   = {}    --存放公共牌
        -------------------------------------------------    
        local a ,str111 = self.TableType,nil 
        if (a>=71 and a<=76) or (a>=89 and a<=94) then 
            str111 =  '初级场(盲注:'..self.littleBlind..'/'..self.bigBlind..')'
        elseif  (a>=77 and a<=82) or (a>=95 and a<=100) then 
            str111 =  '中级场(盲注:'..self.littleBlind..'/'..self.bigBlind..')'
        elseif  (a>=83 and a<=88) or (a>=101 and a<=106) then 
            str111 =  '高级场(盲注:'..self.littleBlind..'/'..self.bigBlind..')'        
        else
            str111 =  '富豪场(盲注:'..self.littleBlind..'/'..self.bigBlind..')'        
        end  
        self['Text_mangzhu']:setString(str111)      
             
        if self.TableType < 19 then        
           self.playerName = {{0,0},{1,0},{2,0},{3,0},{4,0},{5,0},{6,0},{7,0},{8,0}}         
        else 
           self.playerName = {{0,0},{1,0},{2,0},{3,0},{4,0},{5,0}}
        end 
        self['Button_chip3']:setTitleText(self.bigBlind)
        self['Button_chip2']:setTitleText(self.bigBlind*5)
        self['Button_chip1']:setTitleText(self.bigBlind*10)

        self.pre         = true     
        self.maxCarry    = info.MaxChip
        self.minCarry    = info.MinChip
        self.maxChip     = self.littleBlind *2 
        self.compareChip = self.littleBlind *2  
        self.totalChip   = 0 
        self.room_fee    = info.ServiceFee  --服务费

        self.poolNum     = 1 
        self.nowPlayers  = {}  
        self['Panel_Pool1']:setVisible(false)
    end 
    for key ,var  in pairs(info.Users) do 
        local sex_tab = {} 
        sex_tab.uid = var.Uid
        sex_tab.sex = var.Sex
        table.insert(self.playerSexTab,sex_tab)  --玩家性别表
        local aaa = self:compareData(var.SeatId)
        if not aaa  then   aaa= self['Panel_me'] end 
        table.insert(self.nowPlayers,aaa)
        if var.SeatId  ==  self.mySeat_id then      
            self['Text_myMoney']:setString(var.Chip)
            self['Image_myVip']:setVisible(var.VLevel~= 0)   
            self['Image_myVip']:getChildByName('AtlasLabel_myVip'):setString(var.VLevel) 
            self['Text_myName']:setString(var.Name)
            self['Panel_me']:setTag(var.Uid)
            self.myCarry = var.Chip
            --self.PlayerData.coin = var.Coin 
            self.myRoundState  = var.PlayerState
            self['Panel_preOperate']:setVisible(var.PlayerState ~= 0)    
            self['Panel_operate']:setVisible(var.PlayerState ~= 0) 
            if var.PlayerState ~= 0 then 
                self['Image_myCard1']:setVisible(true)
                self['Image_myCard2']:setVisible(true)
                self['Image_cardTypeBg']:setVisible(true)
                local child = self['Image_cardTypeBg']:getChildByName('Image_mycardtype')
                child:setString(self.PlayerData.cardType[self.langeageType][var.CardType])
                --self['Image_cardTypeBg']:setContentSize(cc.p(child:getContentSize().width+30,child:getContentSize().height))  
                local image1,image2 = self.PlayerData:getCard(var.Card[1]),self.PlayerData:getCard(var.Card[2])
                self['Image_myCard1']:loadTexture(image1,ccui.TextureResType.plistType)
                self['Image_myCard2']:loadTexture(image2,ccui.TextureResType.plistType)
                self['Text_Mychips']:setString(var.BetTotal)
            else 
                self['Image_myHead']:setColor(cc.c3b(127,127,127))
                --self['Panel_me']:setOpacity(175)
            end 
        else 
            self:giveSeatId(var)
            for k,v in pairs(self.playerName) do 
                if v[1] == var.SeatId then 
                   v[2] = var.Name
                end 
            end        
            if var.PlayerState ~= 0 then 
                local parent = self:compareData(var.SeatId)
                parent:getChildByName('Image_card1'):setVisible(true)
                parent:getChildByName('Image_card2'):setVisible(true)
                if parent == self['Panel_me'] then         
                   self['Text_Mychips']:setString(var.BetTotal)
                else 
                   parent:getChildByName('Image_chip'):getChildByName('Text_chip'):setString(var.BetTotal)
                end         
            end 
        end       
    end 

    if info.TableState ~=1 and info.TableState ~= 0 and info.TableState ~= 6 then 
        for key ,var in pairs(info.Pools) do --更新奖池
            if var ~= 0 then 
                self['Panel_Pool'..key]:setVisible(true)
                self['Panel_Pool'..key]:getChildByName('Text_total'):setString(var) 
            end    
        end 
        self.commonCard = info.DeskCards
        print('我进入牌局，牌局中有玩家，当前的公共牌')
        dump(info.DeskCards)
        for key ,var in pairs(info.DeskCards) do --公共牌
            self['Image_card_show'..key]:setVisible(true)
            self['Image_card_show'..key]:loadTexture(self.PlayerData:getCard(var),ccui.TextureResType.plistType)           
        end 

        --庄家
        if  info.CurrentDealerSeatId~= self.mySeat_id then 
            local parent = self:compareData(info.CurrentDealerSeatId)  
            parent:getChildByName('Image_zhuang'):setVisible(true)
        else 
            self['Image_myZh']:setVisible(true)
        end   
        
        self.maxChip = 0 
        for key, var in pairs(info.Users) do 
           self.maxChip = (var.BetTotal >=self.maxChip and var.BetTotal or self.maxChip)
        end 
          
        --当前牌桌下注的玩家              
        if  info.CurrentBetSeatId ~= self.mySeat_id then       
            local nowPlay = self:compareData(info.CurrentBetSeatId)  
            self:testProgress(nowPlay:getChildByName('Image_model'):getChildByName('Image_head'),2,nil)
            
        else 
            self:testProgress(self['Image_myHead'],1,info.CurrentStateGoneTime)
        end 
    end  
    
    --发送设置自动补充筹码
    local temp_type = {'primary','middle','senior','extreme','competition'}
    local   str  =  UserCache.getUserDataByKey(temp_type[info.TableType])
    if str and str~= '' then 
        local   info =  self.tool:getStringTab(str)
        self:reqSock_AUTO_BUY(1,info[1],info[2])
    end      

    self.openGameTesuxView = false
end 

--手电筒的缩放 和角度
function UIGameTableDeZhou:flashLight()
    self.AllRotation = {} 
    local fromX,fromY = self['Panel_main']:getChildByName('hall_light_effect'):getPosition() 
    local size = self['Panel_main']:getChildByName('hall_light_effect'):getContentSize()
    for key,var in  pairs(self.pos_tab) do 
        local temp= {}
        local toX,toY  = var:getPosition()   
        local distance = cc.pGetDistance(cc.p(fromX,fromY),cc.p(toX,toY))
        local scale    = distance/size.height
        temp.parent   = var 
        temp.rotation = (LuaTools.Lookat(cc.p(fromX,fromY),cc.p(toX,toY)))-180 
        temp.scale    = scale 
        table.insert(self.AllRotation,temp)
    end 
end 

--显示手电筒
function UIGameTableDeZhou:ShowFlashLight(par)
    local actionTime = 0.2
    if self.AllRotation and #self.AllRotation ~= 0 then 
        self['Panel_main']:getChildByName('hall_light_effect'):setVisible(true) 
        if  par == self['Panel_me'] then 
          self['Panel_main']:getChildByName('hall_light_effect'):runAction(cc.ScaleTo:create(actionTime,1,1))--setRotation(var.rotation)
          self['Panel_main']:getChildByName('hall_light_effect'):runAction(cc.RotateTo:create(actionTime,0))           
        else 
            for key,var in pairs(self.AllRotation) do 
                if var.parent == par and par:getChildByName('Image_model') then 
                    self['Panel_main']:getChildByName('hall_light_effect'):runAction(cc.ScaleTo:create(actionTime,1,var.scale))--setRotation(var.rotation)
                    self['Panel_main']:getChildByName('hall_light_effect'):runAction(cc.RotateTo:create(actionTime,var.rotation))
                end 
            end
        end
    end
end 
--创建进度条
function UIGameTableDeZhou:testProgress(panel,tag,short) 
    self:stopSchedule('playWaringMusic')

    if self.PlayerData.warningId ~= 0 then 
       --self.sound:stopEffect(self.PlayerData.warningId) 
    end    

    if  tag == 1 then 
        self:preOrNot() 
    else 
        self:preShowButton()  
    end      

    if not panel then return end 
    
    local to ,time 
    if  short then 
        time = self.waitingTime-tonumber(short)
    else
        time = self.waitingTime
    end  
    to  = cc.ProgressTo:create(time, 100)
    
    if  panel == self['Image_myHead'] then 
        self:ShowFlashLight(self['Panel_me'])
        self['Text_myName']:setString(self.languageTable[self.langeageType][5])
        if  not short then            
            local count_num = 1 
            local function playWaring()
                count_num = count_num + 1 
                if count_num >=5 then 
                   self:stopSchedule('playWaringMusic')
                   --audio.playSound(Sound.SoundTable['Texus']['Warning'] , false)
                end    
            end 
            self:createSchedule('playWaringMusic',playWaring,1)
        end     
    else 
        local par = panel:getParent()
        self:ShowFlashLight(par:getParent())
        par:getChildByName('Text_name'):setString(self.languageTable[self.langeageType][5])
    end  

    local sprite = cc.Sprite:create('res/icon/game_timing.png')   
    sprite:setColor(cc.c3b(0,255,0))
    local action1 = cc.TintTo:create(1.5, 255, 0, 0)
    local action2 = cc.Sequence:create(cc.DelayTime:create(time/2),action1)
    local spawn  = cc.Spawn:create(to,action2)
    sprite:setAnchorPoint(0.5,0.5)
    local pro = cc.ProgressTimer:create(sprite)
    pro:setType(cc.PROGRESS_TIMER_TYPE_RADIAL)
    panel:addChild(pro,99)
    pro:setName('action')
    local function callback()
        if panel:getChildByName('action') then 
           panel:removeChildByName('action') 
        end    
        self:hideAddChips()
    end 
    local size = panel:getContentSize()
    pro:setPosition(cc.p(size.width/2,size.height/2))
    pro:runAction(cc.Sequence:create(spawn,cc.CallFunc:create(callback)))  
    
end 

--结束进度条
function UIGameTableDeZhou:endProgress()
    --audio.stopAllSounds()

    if self['Image_myHead']:getChildByName('action') then 
        self['Image_myHead']:removeChildByName('action')
    end 
    --self['Panel_main']:getChildByName('hall_light_effect'):setVisible(false) 
    for key,var in pairs(self.pos_tab) do  
        if var:getChildByName('Image_model') and var:getChildByName('Image_model'):getChildByName('Image_head'):getChildByName('action') then     
           var:getChildByName('Image_model'):getChildByName('Image_head'):removeChildByName('action')        
        end 
    end      
end 
--点击查看个人信息获得的table
function UIGameTableDeZhou:getFriendBrifTab(id)
    local tab_temp = {} 
    tab_temp.uid = id
    tab_temp.tag = 2
    tab_temp.cbKick =  function()
           self:reqSock_LET_GO(id)
           self.PlayerData.prop[1]=self.PlayerData.prop[1]-1
    end 
    tab_temp.cbSendGift = function(playerUID,giftID) 
        self:reqSock_GIVE_GIFT(playerUID,giftID)  
    end
    tab_temp.cbAskFriend = function() 
        self:reqSock_ASK_FRI(id)
    end 
    tab_temp.cbSellGift = function() 

    end
    return tab_temp
end 

--给座位上添加控件
function UIGameTableDeZhou:giveSeatId(info)
    local parent ,person     
    for key,var in pairs(self.seat_id) do 
        if var == tonumber(info.SeatId) then 
            parent = self.pos_tab[key]  
        end    
    end 
    if parent:getChildByName('Image_model') then 
        parent:removeChildByName('Image_model')
    end    
    local child = self['Image_model']:clone()
    local size = parent:getContentSize() 
    child:setName('Image_model')
    child:setLocalZOrder(20)
    child:setAnchorPoint(0.5,0.5)
    parent:addChild(child)
    parent:getChildByName('Image_card1'):setLocalZOrder(21)
    parent:getChildByName('Image_card2'):setLocalZOrder(23)
    
    child:setPosition(cc.p(size.width/2,size.height/2)) 
    parent:setVisible(true)
    local item = parent:getChildByName('Image_model')
    item:getChildByName('Text_name'):setString(info.Name)    
    item:getChildByName('Text_money'):setString(info.Chip)  
    item:getChildByName('Image_vip'):setVisible(info.VLevel~=0) 
    item:getChildByName('Image_vip'):getChildByName('AtlasLabel_vip'):setString(info.VLevel)

    if #info.PicUrl > 0 then
        local function onFinishTable(status,downloadedSize,dst)
            if status == "success" then
                local spr = cc.Sprite:create(dst)                          
                LuaTools.myheadChange(spr,item:getChildByName('Image_head'),item,info.Uid,self:getFriendBrifTab(info.Uid)) 
            else
                local spr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[info.Sex+1])
                LuaTools.myheadChange(spr,item:getChildByName('Image_head'),item,info.Uid,self:getFriendBrifTab(info.Uid)) 
            end
        end
        local newName = info.PicUrl
        LuaTools.getFileFromUrl({
            url = info.PicUrl,
            destFile = (newName:gsub("/","_")),   
            onFinishTable = onFinishTable
        })
    else 
        local spr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[info.Sex+1])
        LuaTools.myheadChange(spr,item:getChildByName('Image_head'),item,info.Uid,self:getFriendBrifTab(info.Uid)) 
    end

    parent:setTag(tonumber(info.Uid))
end 

--离开桌子
function UIGameTableDeZhou:leaveTab(tag,uid)
    for key,var in pairs(self.playerSexTab) do 
        if var.uid == uid then 
           table.remove(self.playerSexTab,key)
        end 
    end        
    if  tag == 1 then 
        for key,var in pairs(self.seat_id) do 
            local par = self:compareData(var)
            if var == uid  and par:getChildByName('Image_model')  then 
                par:removeChildByName('Image_model')
                par:setTag(0)
                par:getChildByName('Image_card1'):setVisible(false)
                par:getChildByName('Image_card2'):setVisible(false)
                par:getChildByName('Image_chip'):setVisible(false)
                par:getChildByName('Image_zhuang'):setVisible(false)
                
                for k,v in pairs(self.playerName) do 
                    if v[1] == uid then  
                       v[2] = 0  
                    end     
                end                    
            end    
        end  
    else 
        for key,var in pairs(self.pos_tab) do 
            if var:getTag() == uid  and var:getChildByName('Image_model')  then 
                var:removeChildByName('Image_model')
                var:setTag(0)
                var:getChildByName('Image_card1'):setVisible(false)
                var:getChildByName('Image_card2'):setVisible(false)
                var:getChildByName('Image_chip'):setVisible(false)
                var:getChildByName('Image_zhuang'):setVisible(false)
                break
            end 
        end  
    end 
end 

--所有失败响应
function UIGameTableDeZhou:RespCMD_ALL_LOSE(data)
     print('进入所有失败')
     dump(data)
     G_BASEAPP:addView('UIDialog',self:getLocalZOrder()+20,1)
     G_BASEAPP:callMethod('UIDialog','setupDialog', '',data.failedStr,
                    function() 
                        G_BASEAPP:removeView('UIGameTableDeZhou')
                        G_BASEAPP:callMethod('UIMain','showEnterMainActions')
                        if tonumber(data.SeatId) > 0 then 
                                local seatId = data.SeatId
                                local info = G_BASEAPP:getData('Config').gameSeatIdInfo 
                                local text 
                                for key,var in pairs(info) do 
                                    if tostring(seatId) == key then 
                                        text = var 
                                    end 
                                end 
                                if text then 
                                      if string.find(text,'地主') then 
                                          G_BASEAPP:callMethod('UIMainBottom','enterGame', seatId)
                                          return 
                                      elseif   string.find(text,'斗牛') then 
                                          G_BASEAPP:callMethod('UIMainBottom','enterGame', seatId)
                                      elseif   string.find(text,'三张') then  
                                          G_BASEAPP:callMethod('UIMainBottom','enterGame', seatId)
                                      -- elseif   string.find(text,'德州') then  
                                      --     G_BASEAPP:callMethod('UIMainBottom','quickEnterPokerRoom', seatId)
                                      elseif   string.find(text,'升级') then  
                                          G_BASEAPP:callMethod('UIMainBottom','quickEnterRunFast', seatId)
                                      else 
                                          return     
                                      end   
                                end 
                        end     
                    end) 
     --LuaTools.showAlert(data.failedStr)
end 

--登出成功
function UIGameTableDeZhou:RespCMD_LOGOUT_SUCC()

end    

--异地登录
function UIGameTableDeZhou:RespCMD_LOGIN_CONFLICT() 
     G_BASEAPP:addView('UIDialog',self:getLocalZOrder()+20,1)
     G_BASEAPP:callMethod('UIDialog','setupDialog', '','您的帐号已在其他设备上登录,请重新登录',
                    function() 
                        self:closeTexusTcp()
                        self.PlayerData.coin = self.PlayerData.coin + self.myCarry
                        G_BASEAPP:callMethod('UIMain','updateWealth')
                        G_BASEAPP:removeView('UIGameTableDeZhou')
                        G_BASEAPP:callMethod('UIMain','showEnterMainActions')
                        self:startOrEndTime(2)
                    end)
end     

--更新用户信息  updatePlayerInfo
function UIGameTableDeZhou:RespCMD_UPDATE_USERINFO(info)
    if tonumber(self.PlayerData.uid) == tonumber(info.PlayerId) then  
        self['Text_myMoney']:setString(info.chip)   
        self.myCarry = info.chip        
        --self.PlayerData.coin = info.coin
    else     
        for key,var in pairs(self.pos_tab) do 
            if var:getTag() == info.PlayerId and  var:getChildByName('Image_model') then 
                var:getChildByName('Image_model'):getChildByName('Text_money'):setString(info.chip)  
            end 
        end
    end 
end 


--心跳响应
function UIGameTableDeZhou:RespCMD_HEARTBEAT()

end    

--喇叭
function UIGameTableDeZhou:startBroadcast() 
    print('BROADCASTING...')
    -- self['Panel_LimitB']:setClippingEnabled(false)
    if self.broadCastType == 'on' then     --if there isn't already a broadcast running
        return
    end
    if #self.PlayerData.listBroadcastMsg == 0 then     --no more message to broadcast
        self['Image_broadBg']:setVisible(false)
        self.broadCastType = 'end'
        return
    end
    local function callFuncBroadcastNext()
        self['Text_broad']:setPositionX(self['Panel_LimitB']:getContentSize().width)

        self.broadCastType = 'end'
        self:startBroadcast()
    end
    self.broadCastType = 'on' 
    self['Image_broadBg']:setVisible(true)
    self['Text_broad']:setString(self.PlayerData.listBroadcastMsg[1])
    local moveTo = cc.MoveBy:create(self.config.broadcastTime, 
        cc.p(-(self['Panel_LimitB']:getContentSize().width + self['Text_broad']:getContentSize().width),
            0))

    self['Text_broad']:runAction(cc.Sequence:create(moveTo, cc.CallFunc:create(callFuncBroadcastNext), nil))
    if #self.PlayerData.listBroadcastMsg > 0 then
        table.remove(self.PlayerData.listBroadcastMsg, 1)
    end
end

--用户进入牌桌 someoneIn 
function UIGameTableDeZhou:RespCMD_USER_ENTER(tag)
end 

--用户离开牌桌  someoneLeave
function UIGameTableDeZhou:RespCMD_USER_LEFT(info) 
    self:leaveTab(2,info.Uid)
end

--用户坐下  someoneSit 
function UIGameTableDeZhou:RespCMD_USER_SIT(info) 
    local function cb1()
        local aaa= self:compareData(info.SeatId)
        if  not  aaa then aaa = self['Panel_me'] end  
        table.insert(self.nowPlayers,aaa)
        for key,var in pairs(self.playerName) do 
            if var[1] == info.SeatId then 
                var[2]  = info.Name 
            end    
        end 
        
        if tostring(info.Uid)  ~= tostring(self.PlayerData.uid) then 
            self:giveSeatId(info)      
            local sex_tab = {} 
            sex_tab.uid = info.Uid
            sex_tab.sex = info.Sex
            table.insert(self.playerSexTab,sex_tab)  --玩家性别表 
        else 
            self:initPosition(info.SeatId)     
            self['Button_fee']:setTouchEnabled(true)
            self['Image_myVip']:setVisible(info.VLevel~= 0)   
            self['Image_myVip']:getChildByName('AtlasLabel_myVip'):setString(info.VLevel) 
            self['Panel_me']:setVisible(true)
            self.myRoundState = 0 
            self['Panel_centerOne']:setVisible(false) 
            self['Text_myMoney']:setString(info.Chip)
            self['Text_myName']:setString(info.Name)
            self.mySeat_id = info.SeatId 
            self.myCarry   = info.Chip
            --self.PlayerData.coin = info.Coin 
        end 
    end     
    if  self.seat_id and #self.seat_id > 0 then 
        cb1()
    else 
        local function callback() 
           if  self.seat_id  and #self.seat_id > 0 then 
               self:stopSchedule('preTimeWait')
               cb1()
           end     
        end               
        self:createSchedule("preTimeWait", callback, 0.1)  
    end     
end

--用户站起  someoneUp 
function UIGameTableDeZhou:RespCMD_USER_STAND(info) 
    print('用户站起')
    if info.Uid == self.mySeat_id then    --self.PlayerData.uid then 
        --self:getOnlineReward(2,0,0)
        --self['Button_box']:setVisible(false)
         
        self['Button_fee']:setTouchEnabled(false)
        self['Panel_me']:setVisible(false)
        self['Button_mySitDown']:setVisible(true)
        if self.TableType < 19 then 
           self.seat_id ={0,1,2,3,4,5,6,7,8} 
        else 
           self.seat_id ={0,1,2,3,4,5} 
        end 
        table.insert(self.pos_tab,self.mySeat_id+1,self['Panel_centerOne'])
        self['Panel_operate']:setVisible(false)
        self['Panel_preOperate']:setVisible(false) 
        self['Panel_centerOne']:setVisible(true) 
        self.mySeat_id = 200 
        self:reqSock_UPDATA_INFO() 
        --        local function sitDown(event) 
        --            if event.name == 'ended' then 
        --                local tag =event.target:getTag()
        --                self.selectSeat = tag        
        --                if  self.PlayerData.coin >= self.minCarry then 
        --                    local max = (self.maxCarry >= self.PlayerData.coin) and  self.PlayerData.coin or self.maxCarry  
        --                    self.app:addView('UIAddChips',125,self.minCarry,max,self.bigBlind*2,self.TableType)                     
        --                else 
        --                    self.app:addView('UIQuickBuy',125)
        --                end 
        --            end     
        --        end 
        --        for key,var in pairs(self.seat_id) do 
        --            local par = self:compareData(var)
        --            if par:getChildByName('inviteFriend') then 
        --               par:removeChildByName('inviteFriend')
        --            end    
        --            if not par:getChildByName('Image_model') then                
        --                local image = ccui.ImageView:create('game/game_leisure.png',ccui.TextureResType.plistType)
        --                --local button = ccui.Button:create('icon/game_leisure.png','icon/game_leisure.png')
        --                par:addChild(image)
        --                local size = par:getContentSize() 
        --                image:setAnchorPoint(0.5,0.5)
        --                image:setPosition(cc.p(size.width/2,size.height/2))
        --                image:setTouchEnabled(true) 
        --                image:setTag(var)
        --                image:setName('SIT_DOWN')
        --                image:onTouch(sitDown) 
        --            end  
        --        end         
    else 
        self:leaveTab(1,info.Uid)       
    end 
end

--返回父节点
function UIGameTableDeZhou:compareData(id)
    local parent  
    for key,var in pairs(self.seat_id) do 
        if var == id then             
            parent = self.pos_tab[key] 
            return parent 
        end    
    end  
end

--发牌动作
function UIGameTableDeZhou:cardAction(tab,card) 
    self['Button_fee']:setTouchEnabled(false)

    self.nowPlayers = {}  
    for key ,var in pairs(tab) do 
        local temp = self:compareData(var.SeatId)  
        if not temp then 
            temp = self['Panel_me']  
            self.myRoundState = 1 
            self['Image_myHead']:setColor(cc.c3b(255,255,255))
            --self['Panel_me']:setOpacity(255)
        end 
        if temp ~= self['Panel_me'] and not temp:getChildByName('Image_model')  then 
            self:giveSeatId(var)       
        end 
        if temp:getChildByName('Image_model') then  
           local showCardBg=  temp:getChildByName('Image_model'):getChildByName('Panel_endCard')
           if showCardBg:isVisible() then 
              showCardBg:setVisible(false)
           end 
        end 
        table.insert(self.nowPlayers,temp)
    end 
     
    local  count = 1 
    local sound_table = {'SendCard1','SendCard2','SendCard3','SendCard4','SendCard5','SendCard6'}
    local image1,image2 = self.PlayerData:getCard(card[1]),self.PlayerData:getCard(card[2])
    
    local  function callback()  
        local armature  = self['Panel_main']:getChildByName('Armature_dealer')
        armature:getAnimation():play('deal')  

        for key,var in pairs(self.nowPlayers) do 
            local tempA = count
            local posX,posY = var:getPosition()
            local image = ccui.ImageView:create('card/card_licensing.png',ccui.TextureResType.plistType)
            image:setScale(0.65)
            image:setOpacity(55)
            self['Panel_main']:addChild(image)
            local x,y=self['Image_cardAction']:getPosition() 
            image:setPosition(cc.p(x,y-50))  
            local action   = cc.MoveTo:create(0.4,cc.p(posX,posY))
            local ease     = cc.EaseOut:create(action, 0.25) 
            local function imageOpa()
                image:setOpacity(255)
            end 
            local rotation = cc.RotateBy:create(0.3, 180)
            local spawn    = cc.Spawn:create(ease,cc.Sequence:create(cc.DelayTime:create(0.25),cc.CallFunc:create(imageOpa)))
            local function action1()         
                image:removeFromParent()
                if tempA< 3 then 
                    if var == self['Panel_me'] then 
                        self:rotateCard(self['Image_myCard'..tempA],self.PlayerData:getCard(card[tempA]),0.25) 
                        --self['Image_myCard'..tempA]:setVisible(true)
                        --self['Image_myCard'..tempA]:loadTexture(self.PlayerData:getCard(card[tempA]),ccui.TextureResType.plistType)               
                    else 
                        var:getChildByName('Image_card'..tempA):setVisible(true)    
                    end   
                end 
            end 
            image:runAction(cc.Sequence:create(spawn,cc.CallFunc:create(action1)))
        end         
        audio.playSound(Sound.SoundTable['Texus'][sound_table[count%6+1]] , false)
        count = count + 1     

        if count == 3  then 
            self:stopSchedule('CardMove')
            for key ,var in pairs(self.nowPlayers) do 
                if var ~= self['Panel_me'] then 
                    local chip = var:getChildByName('Image_model'):getChildByName('Text_money'):getString()  
                    var:getChildByName('Image_model'):getChildByName('Text_money'):setString(tonumber(chip)-self.room_fee)                           
                else  
                    self.myCarry = self.myCarry - self.room_fee 
                    self['Text_myMoney']:setString(self.myCarry)     
                end 
            end      
            local armature  = self['Panel_main']:getChildByName('Armature_dealer')
            armature:getAnimation():play('standby',-1) 
            self['Button_fee']:setTouchEnabled(true) 
            
            if  self.mySeat_id >=0 and self.mySeat_id <= 8 then  
                local function inviteFriend(event) 
                    if event.name == 'ended' then 
                        self.app:addView('UIFriend',self:getLocalZOrder()+20,self.TableType,self.TableId)                   
                    end     
                end 
                for key,var in pairs(self.pos_tab) do 
                    if  not var:getChildByName('Image_model') then 
                        local image = ccui.ImageView:create('game/game_addfriend.png',ccui.TextureResType.plistType)
                        var:addChild(image)
                        local size = var:getContentSize() 
                        image:setAnchorPoint(0.5,0.5)
                        image:setPosition(cc.p(size.width/2,size.height/2))
                        image:setTouchEnabled(true) 
                        image:setName('inviteFriend')
                        image:onTouch(inviteFriend) 
                        self.inviteFriendTag = var     --显示加好友的图片     
                        break
                    end  
                end         
            end  
        end    
    end 
    self:createSchedule("CardMove", callback, 0.5) 
end 

--游戏开始 gameStart 
function UIGameTableDeZhou:RespCMD_GAME_START(info)
    --庄家座位ID  小盲注座位ID   大盲注座位ID      牌数    牌
    -------------------------------------------------     
    --self['Panel_main']:stopAllActions()
    self:initEverything()

    self['Text_addCallCoin']:setString('')
    self.maxChip      = self.littleBlind *2 
    self.compareChip  = self.littleBlind *2  
    self.totalChip    = 0 
    self.myTwoCards   = info.PCard   --我自己的两张牌
    self.commonCard   = {}
    self.showCardState = 0 
    
    self.AllInStadus   = false 
    self.turnCardStadus= false 

    local bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['NET_RES'])
    UIGameTableDeZhou.hallTcpInstance:sendData(bufferHnd:doPack())

    self:cardAction(info.SeatID, info.PCard)
    if self.mySeat_id   == info.DealSeatId then  
        self['Image_myZh']:setVisible(true)  
    else 
        local  par =    self:compareData(info.DealSeatId)
        par:getChildByName('Image_zhuang'):setVisible(true)
    end 
    --小盲注座位
    if self.mySeat_id   == info.CurrentSmallBlindsSeatId then 
        self:chipMove(self['Panel_me'],self.littleBlind)
        self['Text_Mychips']:setString(self.littleBlind) 
        self.myCarry = self.myCarry - self.littleBlind 
        self['Text_myMoney']:setString(self.myCarry)      
        self['Text_myName']:setString(self.languageTable[self.langeageType][7])
    else 
        local par =  self:compareData(info.CurrentSmallBlindsSeatId)  
        self:chipMove(par,self.littleBlind)
        if par == self['Panel_me'] then         
           self['Text_Mychips']:setString(self.littleBlind)
        else 
           par:getChildByName('Image_chip'):getChildByName('Text_chip'):setString(self.littleBlind)
        end  
        local coin = par:getChildByName('Image_model'):getChildByName('Text_money'):getString() 
        par:getChildByName('Image_model'):getChildByName('Text_money'):setString(tonumber(coin)-self.littleBlind)
        par:getChildByName('Image_model'):getChildByName('Text_name'):setString(self.languageTable[self.langeageType][7])
    end 

    --大盲注 
    if self.mySeat_id   == info.CurrentBigBlindsSeatId then 
        self:chipMove(self['Panel_me'],self.bigBlind)
        self['Text_Mychips']:setString(self.bigBlind)
        self.myCarry = self.myCarry - self.bigBlind 
        self['Text_myMoney']:setString(self.myCarry) 
        self['Text_myName']:setString(self.languageTable[self.langeageType][6])
    else 
        local par =  self:compareData(info.CurrentBigBlindsSeatId)  
        self:chipMove(par,self.bigBlind)
        if par == self['Panel_me'] then         
           self['Text_Mychips']:setString(self.bigBlind)
        else 
           par:getChildByName('Image_chip'):getChildByName('Text_chip'):setString(self.bigBlind)
        end  
        local coin = par:getChildByName('Image_model'):getChildByName('Text_money'):getString() 
        par:getChildByName('Image_model'):getChildByName('Text_money'):setString(tonumber(coin)-self.bigBlind)
        par:getChildByName('Image_model'):getChildByName('Text_name'):setString(self.languageTable[self.langeageType][6])
    end    


end
--第一个开始的玩家 firstBeginPlayer
function UIGameTableDeZhou:RespCMD_FIRST_BEGIN(data)
    if self.mySeat_id >=0 and self.mySeat_id <= 8 then  
        self['Panel_operate']:setVisible(true)
        self['Panel_preOperate']:setVisible(true) 
    end 
    if data.seatId >=0 and data.seatId <= 8 then 
        if self.mySeat_id   == data.seatId then 
            self:testProgress(self['Image_myHead'],1,nil) 
        else 
            local par =  self:compareData(data.seatId)  
            if par:getChildByName('Image_model') then 
                local image = par:getChildByName('Image_model'):getChildByName('Image_head') 
                self:testProgress(image,2)
            end 
        end       
    end 
end 

--游戏翻牌 turnCard 
function UIGameTableDeZhou:RespCMD_TURN_CARD(info)
    self:endProgress()

    audio.playSound(Sound.SoundTable['Texus']['OpenThreeCard'] , false)
    self.turnCardStadus= true 

    local armature  = self['Panel_main']:getChildByName('Armature_dealer')
    armature:getAnimation():play('deal')  
    if info.PSeatId >=0 and info.PSeatId <= 8 then 
        if self.mySeat_id   == info.PSeatId then 
            self:testProgress(self['Image_myHead'],1,nil)
            self['Button_call']:setTitleText(self.languageTable[self.langeageType][1])
            self['Text_riseName']:setVisible(false)
            local bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['NET_RES'])
            UIGameTableDeZhou.hallTcpInstance:sendData(bufferHnd:doPack())
        else 
            local par =  self:compareData(info.PSeatId)  
            local image = par:getChildByName('Image_model'):getChildByName('Image_head') 
            self:testProgress(image,2,nil)
        end 
    end    
    local image1,image2,image3 = self.PlayerData:getCard(info.PCard1),self.PlayerData:getCard(info.PCard2),self.PlayerData:getCard(info.PCard3) 
    local temp_image = {image1,image2,image3}      
    table.insert(self.commonCard,info.PCard1)
    table.insert(self.commonCard,info.PCard2)
    table.insert(self.commonCard,info.PCard3)

    local temp_num =1 
    local function callback()
        self:rotateCard(self['Image_card_show'..temp_num],temp_image[temp_num]) 
        temp_num = temp_num+1 
        if temp_num ==4 then 
            self:stopSchedule('showCardAction')
            local armature  = self['Panel_main']:getChildByName('Armature_dealer')
            armature:getAnimation():play('standby',-1) 
            if self.mySeat_id >=0 and self.mySeat_id <= 8  and self.myRoundState ~= 0 then 
               self['Image_cardTypeBg']:setVisible(true)
               local child = self['Image_cardTypeBg']:getChildByName('Image_mycardtype')
               child:setString(self.PlayerData.cardType[self.langeageType][info.CardType])    
            end    
        end  
    end 
    self:createSchedule("showCardAction", callback, 0.3)        

end 

--游戏转牌 moveCard
function UIGameTableDeZhou:RespCMD_OVER_CARD(info)
    local function callback11()
        self:endProgress()

        audio.playSound(Sound.SoundTable['Texus']['OpenOneCard'] , false)
        if info.PSeatId >=0 and info.PSeatId <= 8 then 
            if self.mySeat_id   == info.PSeatId then 
                self:testProgress(self['Image_myHead'],1,nil)
                self['Button_call']:setTitleText(self.languageTable[self.langeageType][1])
                self['Text_riseName']:setVisible(false)
                local bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['NET_RES'])
                UIGameTableDeZhou.hallTcpInstance:sendData(bufferHnd:doPack())
            else 
                local par =  self:compareData(info.PSeatId)  
                local image = par:getChildByName('Image_model'):getChildByName('Image_head') 
                self:testProgress(image,2)
            end       
        end 
        table.insert(self.commonCard,info.PCard1)

        self:rotateCard(self['Image_card_show4'],self.PlayerData:getCard(info.PCard1)) 
    end       

    local function showType()
        if self.mySeat_id >=0 and self.mySeat_id <= 8  and self.myRoundState ~= 0 then 
            self['Image_cardTypeBg']:setVisible(true)
            local child = self['Image_cardTypeBg']:getChildByName('Image_mycardtype')
            child:setString(self.PlayerData.cardType[self.langeageType][info.CardType])
        end 
    end                                                              
    local time_temp = (self.AllInStadus == true and 1.2 or 0.3)          
    self['Image_cardTypeBg']:runAction(cc.Sequence:create(cc.DelayTime:create(time_temp),cc.CallFunc:create(callback11),cc.CallFunc:create(showType)))

end

-- 游戏河牌 riverCard
function UIGameTableDeZhou:RespCMD_RIVER_CARD(info)
    local function callback11()
        self:endProgress()

        audio.playSound(Sound.SoundTable['Texus']['OpenOneCard'] , false)

        if info.PSeatId >=0 and info.PSeatId <= 8 then 

            if self.mySeat_id   == info.PSeatId then 
                self:testProgress(self['Image_myHead'],1)
                self['Button_call']:setTitleText(self.languageTable[self.langeageType][1])
                self['Text_riseName']:setVisible(false)
                local bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['NET_RES'])
                UIGameTableDeZhou.hallTcpInstance:sendData(bufferHnd:doPack())
            else 
                local par =  self:compareData(info.PSeatId)  
                local image = par:getChildByName('Image_model'):getChildByName('Image_head') 
                self:testProgress(image,2)
            end 
        end 
        table.insert(self.commonCard,info.PCard1)
        self:rotateCard(self['Image_card_show5'],self.PlayerData:getCard(info.PCard1)) 
    end       

    local function showType()
        if self.mySeat_id >=0 and self.mySeat_id <= 8  and self.myRoundState ~= 0 then 
            self['Image_cardTypeBg']:setVisible(true)
            local child = self['Image_cardTypeBg']:getChildByName('Image_mycardtype')
            child:setString(self.PlayerData.cardType[self.langeageType][info.CardType])
        end 
    end 
    local time_temp = (self.AllInStadus == true and 1.5 or 0.3)          
    self['Image_cardTypeBg']:runAction(cc.Sequence:create(cc.DelayTime:create(time_temp),cc.CallFunc:create(callback11),cc.CallFunc:create(showType)))
end 

--翻转
function UIGameTableDeZhou:rotateCard(par,image,time)  
    if not time then time = 0.1 end 
    par:setVisible(true) 
    local function callback2()
        --par:setRotation3D(cc.vec3(0, 0, 180))  cc.DelayTime:create(1),  cc.CallFunc:create(callback1),cc.DelayTime:create(2),
        par:loadTexture(image,ccui.TextureResType.plistType)
    end 
    local orbit1 = cc.OrbitCamera:create(time,1, 0, 0, -90, 0, 0)
    local move = cc.OrbitCamera:create(time*2,1, 0, 0, 0, 0, 0) 
    par:runAction(cc.Sequence:create(cc.DelayTime:create(0.1),orbit1,cc.CallFunc:create(callback2),move))  
end 

--预操作按钮 与 操作按钮  切换  
function UIGameTableDeZhou:preOrNot()
    local checkBox_table = {self['CheckBox_pre1'],self['CheckBox_pre2'],self['CheckBox_pre3']}
    local myCoin = tonumber(self['Text_Mychips']:getString())
    if  not myCoin then myCoin = 0  end  
    local bufferHnd
    if  self.compareChip ~=  self.maxChip and self['CheckBox_pre2']:isSelected() then 
        self['CheckBox_pre2']:setSelected(false)     
        self.compareChip =  self.maxChip
    end 

    local a = self['Text_Mychips']:getString()
    local b = tonumber(a)
    if not b then  b = 0  end 
    if  self.maxChip - b > 0 then 
        if self.maxChip - b < self.myCarry then 
            self['Text_addCallCoin']:setString(self.maxChip - b)
            self['Text_riseName']:setString(self.languageTable[self.langeageType][3])
            self['Text_riseName']:setVisible(true)
            self['Button_call']:setTitleText('')
        else 
            self['Text_riseName']:setVisible(false)
            self['Button_call']:setTitleText(self.languageTable[self.langeageType][2])
            self['Text_addCallCoin']:setString('')
        end    
    else 
        self['Text_riseName']:setVisible(false)
        self['Button_call']:setTitleText(self.languageTable[self.langeageType][1])
        self['Text_addCallCoin']:setString('')
    end 

    if  self['CheckBox_pre1']:isSelected() then    
        if  myCoin < self.maxChip then  --弃牌
            bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['ABANDON_CARD'])
        else                            --看牌     
            bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['SEE_CARD'])
        end 
        local function callback1()  
            UIGameTableDeZhou.hallTcpInstance:sendData(bufferHnd:doPack())
            self['CheckBox_pre1']:setSelected(false)
        end 
        self['CheckBox_pre1']:runAction(cc.Sequence:create(cc.DelayTime:create(0.3),cc.CallFunc:create(callback1)))  
        return  
    end         

    if  self['CheckBox_pre2']:isSelected() then            
        if myCoin < self.maxChip then 
            if self.maxChip - myCoin > self.myCarry then 
                bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['ALL_IN'])
            else    
                bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['FOLLOW_CHIP'])
            end 
        else 
            bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['SEE_CARD'])
        end   
        local function callback()   
            UIGameTableDeZhou.hallTcpInstance:sendData(bufferHnd:doPack())
            self['CheckBox_pre2']:setSelected(false)
        end 
        self['CheckBox_pre2']:runAction(cc.Sequence:create(cc.DelayTime:create(0.3),cc.CallFunc:create(callback)))    
        return 
    end 

    if  self['CheckBox_pre3']:isSelected() then    
        if  myCoin == self.maxChip then 
            bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['SEE_CARD'])
        else     
            if self.myCarry >=  self.maxChip then 
                bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['FOLLOW_CHIP'])
            else 
                bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['ALL_IN'])
            end 
        end 
        local function callback()     
            UIGameTableDeZhou.hallTcpInstance:sendData(bufferHnd:doPack())
            self['CheckBox_pre3']:setSelected(false)
        end 
        self['CheckBox_pre3']:runAction(cc.Sequence:create(cc.DelayTime:create(0.3),cc.CallFunc:create(callback)))  
        return                         
    end               
    self:switchOperate(1) 
    self:switchPreOperate(2)
end

function UIGameTableDeZhou:switchOperate(tag)
    local x,y  = self['Panel_operate']:getPosition() 
    local move1 = cc.MoveTo:create(0.1,cc.p(self.OpertateX,0))
    local move2 = cc.MoveTo:create(0.1,cc.p(self.OpertateX,self.OpertateY)) 
    self['Panel_operate']:stopAllActions()
    if tag == 1 and y<0 then  
        audio.playSound(Sound.SoundTable['Texus']['MyTurn'] , false)
        self['Panel_operate']:runAction(move1)    
    elseif tag == 2 and y~= self.OpertateY then 
        self['Panel_operate']:runAction(move2)
        if self['Image_myHead']:getChildByName('action') then 
            self['Image_myHead']:removeChildByName('action')
        end 
    end 
end

function UIGameTableDeZhou:switchPreOperate(tag)
    local x,y  = self['Panel_preOperate']:getPosition() 
    local move1 = cc.MoveTo:create(0.1,cc.p(self.OpertateX,0))
    local move2 = cc.MoveTo:create(0.1,cc.p(self.OpertateX,self.OpertateY)) 
    self['Panel_preOperate']:stopAllActions()
    if tag == 1 and y<0 then  
        self['Panel_preOperate']:runAction(move1)    
    elseif tag == 2 and y~= self.OpertateY then 
        self['Panel_preOperate']:runAction(move2)
    end 
end 

function UIGameTableDeZhou:preShowButton() 
    self:switchPreOperate(1)
    if self.compareChip ~=  self.maxChip then 
        self['CheckBox_pre2']:setSelected(false)
        self['CheckBox_pre1']:setSelected(false)     
        self['CheckBox_pre3']:setSelected(false)
        self.compareChip =  self.maxChip
    end     
    local a = self['Text_Mychips']:getString()
    local b = tonumber(a)
    if not b  then  b = 0 end 
    if self.maxChip - b > 0 then 
        if self.maxChip - b <= self.myCarry then 
            self['Text_pre2']:setVisible(true)
            self['Text_preCallCoin']:setString(self.maxChip - b)
            self['Image_preOpr2']:setTitleText('')
        else 
            self['Text_pre2']:setVisible(false)
            self['Text_preCallCoin']:setString(self.myCarry)
            self['Image_preOpr2']:setTitleText('  '..self.languageTable[self.langeageType][2])
        end    
    else 
        self['Text_pre2']:setVisible(false) 
        self['Text_preCallCoin']:setString('')
        self['Image_preOpr2']:setTitleText('  '..self.languageTable[self.langeageType][1])
    end  
end  

--飞筹码
function UIGameTableDeZhou:chipMove(par,num)
    if  par:getChildByName('Image_moveChip') then 
        par:removeChildByName('Image_moveChip')
    end 
    --local chip = ccui.ImageView:create('card/chip_1_bet.png',ccui.TextureResType.plistType)
    local chip = self['Image_manyChips']:clone()  
    local temp = self.PlayerData:giveChips(num,self.bigBlind) 
    chip:loadTexture(temp.parent,ccui.TextureResType.plistType) 
--    print('是大盲注还是小盲注'..num)
--    dump(temp)
    if temp.child and #temp.child> 0 then 
       for key,var in pairs(temp.child) do 
           if key<=6 then 
           chip:getChildByName('Image_'..key):setVisible(true)
           chip:getChildByName('Image_'..key):loadTexture(var,ccui.TextureResType.plistType) 
           end 
       end 
    end     
    chip:setAnchorPoint(0.5,0.5) 
    par:addChild(chip)
    if par == self['Panel_me'] then         
       self['Text_Mychips']:setString(num)
    else 
       par:getChildByName('Image_chip'):getChildByName('Text_chip'):setString(num)
    end    
    local size = par:getContentSize()
    chip:setPosition(size.width/2,size.height/2) 
    chip:setName('Image_moveChip')
    local x,y = par:getChildByName('Image_chip'):getPosition() 
    local move = cc.MoveTo:create(0.2,cc.p(x,y))
    local function callback()
        par:getChildByName('Image_chip'):setVisible(true)
    end 

    chip:runAction(cc.Sequence:create(move,cc.DelayTime:create(0.2),cc.CallFunc:create(callback)))  
end 

--回合结束收集筹码 
function UIGameTableDeZhou:collectChip(new,total,aaaa) 
    local temp = {self['Panel_left4'],self['Panel_left3'],self['Panel_left2'],self['Panel_left1'],
        self['Panel_right1'],self['Panel_right2'],self['Panel_right3'],self['Panel_right4'],self['Panel_me'],self['Panel_centerOne']} 

    local model_image = self['Panel_Pool'..total]:getChildByName('Image_totalChip')
    local x1,y1 =model_image:getPosition() 
    local worldPoint = self['Panel_Pool'..total]:convertToWorldSpace(cc.p(x1,y1))
 
    for key,var in pairs(temp) do 
        var:getChildByName('Image_chip'):setVisible(false)         
        if var == self['Panel_me'] then         
           self['Text_Mychips']:setString('')
        else 
           var:getChildByName('Image_chip'):getChildByName('Text_chip'):setString('')
        end 
        if var:getChildByName('Image_moveChip') then 
            local nodePoint  = var:convertToNodeSpace(cc.p(worldPoint.x,worldPoint.y))             
            local move1 = cc.MoveTo:create(0.3,cc.p(nodePoint.x,nodePoint.y))
            local function callback() 
                var:removeChildByName('Image_moveChip')  --cc.DelayTime:create(1.5),
            end 
            var:getChildByName('Image_moveChip'):runAction(cc.Sequence:create(move1,cc.CallFunc:create(callback)))
        end 
    end                     
    
    
    local function callback1()
        for key ,var in pairs(aaaa) do  
            local model_image = self['Panel_Pool'..key]:getChildByName('Image_totalChip') 
            if model_image:getChildByName('chip_many') then 
                model_image:removeChildByName('chip_many')
            end     

            local chip = self['Image_manyChips']:clone()   
            local temp = self.PlayerData:giveChips(var,self.bigBlind) 
            chip:loadTexture(temp.parent,ccui.TextureResType.plistType) 
            if temp.child and #temp.child> 0 then 
                for key,var in pairs(temp.child) do 
                    if key<=6 then 
                        chip:getChildByName('Image_'..key):setVisible(true)
                        chip:getChildByName('Image_'..key):loadTexture(var,ccui.TextureResType.plistType) 
                    end 
                end 
            end   
            chip:setAnchorPoint(0.5,0.5) 
            model_image:addChild(chip)
            local size = model_image:getContentSize() 
            chip:setPosition(size.width/2,size.height/2) 
            chip:setName('chip_many')
        end 
    end 
    self['Panel_main']:runAction(cc.Sequence:create(cc.DelayTime:create(0.6),cc.CallFunc:create(callback1)))                                                                                  
end 

--游戏结束结算筹码    
function UIGameTableDeZhou:gameOverChip(temp,poolId)    
    local x1,y1 =  self['Panel_Pool'..poolId]:getChildByName('Image_totalChip'):getPosition() 
    local worldPoint = self['Panel_Pool'..poolId]:convertToWorldSpace(cc.p(x1,y1))
    local nodePoint  = self['Panel_main']:convertToNodeSpace(cc.p(worldPoint.x,worldPoint.y))  
        
    if #temp == 1 then     
        local tab = temp[1]
        self:showLightCard(tab.handCard[1],tab.handCard[2],tab.maxCard,tab.parent) 
        self:showWinImage(tab.parent)
        local x,y = tab.parent:getPosition()
        local tag = math.random(1,3)
        local function moveChip()
            local random = math.random(1,6)
            local image = string.format('card/chip_%d_bet.png',random) 
            local chip = ccui.ImageView:create(image,ccui.TextureResType.plistType) 
            local move  = cc.MoveTo:create(0.6,cc.p(x,y)) 
            tag = tag+1 
            self['Panel_main']:addChild(chip)
            chip:setAnchorPoint(0.5,0.5)
            chip:setPosition(cc.p(nodePoint.x,nodePoint.y))  
            if tag == 6 then 
                self:stopSchedule('gameOverChipCount')
                local child ,bmf  
                if tab.parent:getTag() == tonumber(self.PlayerData.uid) then 
                    child = self['Text_myMoney']
                    bmf   = tab.parent:getChildByName('BitmapFontLabel_winMoney')
                else 
                    if tab.parent:getChildByName('Image_model') then 
                        child = tab.parent:getChildByName('Image_model'):getChildByName('Text_money')
                        bmf   = tab.parent:getChildByName('Image_model'):getChildByName('BitmapFontLabel_winMoney')
                    else 
                        return                   
                    end       
                end 
                local text = child:getString()

                if not text or text == '' then text ='0' end 
                local b  = tonumber(text)
                child:setString(b+tonumber(tab.money))        
                
                local text = bmf:clone() 
                text:setString('+'..tab.money)
                local x,y = bmf:getPosition() 
                bmf:getParent():addChild(text)              
                text:setPosition(x,y)       
                local function callback1() 
                    text:removeFromParent()
                end  
                local fadeOut = cc.FadeOut:create(3)
                text:runAction(cc.Sequence:create(fadeOut,cc.CallFunc:create(callback1)))
            end   
            local function callback()
                chip:removeFromParent()
            end 
            chip:runAction(cc.Sequence:create(move,cc.CallFunc:create(callback)))
        end     
        self:createSchedule('gameOverChipCount', moveChip, 0.06)   
    else 
        for key,var in pairs(temp) do 
            self:showLightCard(var.handCard[1],var.handCard[2],var.maxCard,var.parent) 
            self:showWinImage(var.parent)
        end 
        local tag = math.random(1,2)
        local function manyPeopleWin()
             for key,var in pairs(temp) do 
                local x,y = var.parent:getPosition()
                local image = string.format('card/chip_%d_bet.png',math.random(1,6))  
                local chip = ccui.ImageView:create(image,ccui.TextureResType.plistType) 
                local move  = cc.MoveTo:create(0.6,cc.p(x,y)) 
                self['Panel_main']:addChild(chip)
                chip:setAnchorPoint(0.5,0.5)
                chip:setPosition(cc.p(nodePoint.x,nodePoint.y))    
                local function callback()
                    chip:removeFromParent()
                end 
                chip:runAction(cc.Sequence:create(move,cc.CallFunc:create(callback)))
                tag = tag+1 

                if tag == 3 then 
                    self:stopSchedule('gameOvermanyPeopleWin')
                    local child ,bmf                      
                    for k,v in pairs(temp) do 
                        if v.parent == self['Panel_me'] then 
                            child = self['Text_myMoney']                            
                            local text = v.parent:getChildByName('BitmapFontLabel_winMoney'):clone() 
                            text:setString('+'..v.money)
                            local x,y = v.parent:getChildByName('BitmapFontLabel_winMoney'):getPosition() 
                            v.parent:addChild(text)
                            text:setPosition(x,y)       
                            local function callback1() 
                                text:removeFromParent()
                            end  
                            local fadeOut = cc.FadeOut:create(3)
                            text:runAction(cc.Sequence:create(fadeOut,cc.CallFunc:create(callback1))) 
                        else 
                            if v.parent:getChildByName('Image_model') then 
                                child = v.parent:getChildByName('Image_model'):getChildByName('Text_money')
                                local aaaa = v.parent:getChildByName('Image_model'):getChildByName('BitmapFontLabel_winMoney')
                                local text = aaaa:clone() 
                                text:setString('+'..v.money)
                                local x,y = aaaa:getPosition() 
                                v.parent:getChildByName('Image_model'):addChild(text)
                                text:setPosition(x,y)       
                                local function callback1() 
                                    text:removeFromParent()
                                end  
                                local fadeOut = cc.FadeOut:create(3)
                                text:runAction(cc.Sequence:create(fadeOut,cc.CallFunc:create(callback1)))
                            else 
                                return                    
                            end       
                        end 
                        local text = child:getString()
                        if not text or text == '' then text ='0' end   
                        local b  = tonumber(text)
                        child:setString(b+tonumber(v.money))    
                    end    
                end 
             end 

        end 
        self:createSchedule('gameOvermanyPeopleWin', manyPeopleWin, 0.06)   
    end 
end 


--用户看牌(就是不加注，过)  noMoreChip
function UIGameTableDeZhou:RespCMD_SEE_CARD(info)
    self:endProgress()
    if info.SeatId  == self.mySeat_id   then  
        self['Text_myName']:setString(self.languageTable[self.langeageType][1])
        audio.playSound(Sound.SoundTable['Texus'][self.PlayerData.sex ==0 and 'CheckGirl' or 'CheckMen'] , false)
    else 
        local par =  self:compareData(info.SeatId)    
        audio.playSound(Sound.SoundTable['Texus']['CheckCard'] , false)
        if par  and  par:getChildByName('Image_model') then  
            par:getChildByName('Image_model'):getChildByName('Text_name'):setString(self.languageTable[self.langeageType][1])
        end 
    end  

    if info.NextSeatId  >= 0 and info.NextSeatId <= 8 then    

        if self.mySeat_id   == info.NextSeatId  then  
            self:testProgress(self['Image_myHead'],1) 
                local bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['NET_RES'])
                UIGameTableDeZhou.hallTcpInstance:sendData(bufferHnd:doPack())
        else 
            local par =  self:compareData(info.NextSeatId)  
            if par:getChildByName('Image_model') then 
                local image = par:getChildByName('Image_model'):getChildByName('Image_head') 
                self:testProgress(image,2)
            end          
        end 
    end     
end 

--用户跟注  followChip
function UIGameTableDeZhou:RespCMD_FOLLOW_CHIP(info)
    if self.mySeat_id   == info.SeatId  then 
        if tonumber(info.IncChip) == 0 then  
            self['Text_myName']:setString(self.languageTable[self.langeageType][1])
            audio.playSound(Sound.SoundTable['Texus'][self.PlayerData.sex ==0 and 'CheckGirl' or 'CheckMen'] , false)
        else 
            self['Text_myName']:setString(self.languageTable[self.langeageType][3]) 
            self.myCarry = self.myCarry- info.IncChip
            self['Text_myMoney']:setString(self.myCarry)
            self:chipMove(self['Panel_me'],info.FollowChip)
            audio.playSound(Sound.SoundTable['Texus'][self.PlayerData.sex ==0 and 'FollowGirl' or 'FollowMen'] , false)

        end 
    else 
        audio.playSound(Sound.SoundTable['Texus']['addChip'] , false)
        local par =  self:compareData(info.SeatId)  
        if  par:getChildByName('Image_model') then    
            if  tonumber(info.IncChip) == 0 then  
                par:getChildByName('Image_model'):getChildByName('Text_name'):setString(self.languageTable[self.langeageType][1])            
            else   
                par:getChildByName('Image_model'):getChildByName('Text_name'):setString(self.languageTable[self.langeageType][3]) 
                local coin = par:getChildByName('Image_model'):getChildByName('Text_money'):getString() 
                par:getChildByName('Image_model'):getChildByName('Text_money'):setString(tonumber(coin)-info.IncChip)
                self:chipMove(par,info.FollowChip) 
            end
        end
    end

    if info.FollowChip > self.maxChip then   
        self.maxChip = info.FollowChip 
    end        
    self:endProgress()  

    if info.NextSeatId  >= 0 and info.NextSeatId <= 8 then    
        if  self.mySeat_id   == info.NextSeatId then 
            self:testProgress(self['Image_myHead'],1)
                local bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['NET_RES'])
                UIGameTableDeZhou.hallTcpInstance:sendData(bufferHnd:doPack())
        else
            local par =  self:compareData(info.NextSeatId)  
            if par:getChildByName('Image_model') then             
                local image = par:getChildByName('Image_model'):getChildByName('Image_head') 
                self:testProgress(image,2)
            end
        end 
    end       
end 

--用户加注 addChip
function UIGameTableDeZhou:RespCMD_ADD_CHIP(info)
    if  self.mySeat_id   == info.SeatId then 
        self['Text_myName']:setString(self.languageTable[self.langeageType][8]) 
        self.myCarry = self.myCarry- info.IncChip
        self['Text_myMoney']:setString(self.myCarry)
        self:chipMove(self['Panel_me'],info.AddChip)
        local temp1 = (self.PlayerData.sex == 0) and 'CallGirl' or 'CallMen'
        audio.playSound(Sound.SoundTable['Texus'][temp1] , false)
    else 
        local par =  self:compareData(info.SeatId) 
        audio.playSound(Sound.SoundTable['Texus']['addChip'] , false)
        if par:getChildByName('Image_model') then 
            par:getChildByName('Image_model'):getChildByName('Text_name'):setString(self.languageTable[self.langeageType][8]) 
            local coin = par:getChildByName('Image_model'):getChildByName('Text_money'):getString() 
            par:getChildByName('Image_model'):getChildByName('Text_money'):setString(tonumber(coin)-info.IncChip)
            self:chipMove(par,info.AddChip) 
        end
    end

    if info.AddChip> self.maxChip then   
        self.maxChip = info.AddChip
    end        
    self:endProgress()
    if info.NextSeatId  >= 0 and info.NextSeatId <= 8 then    
        if self.mySeat_id   == info.NextSeatId then 
            self:testProgress(self['Image_myHead'],1)
                local bufferHnd = DataPacker.new(UIGameTableDeZhou.Texus['NET_RES'])
                UIGameTableDeZhou.hallTcpInstance:sendData(bufferHnd:doPack())
        else 
            local par =  self:compareData(info.NextSeatId)  
            if par:getChildByName('Image_model') then           
                local image = par:getChildByName('Image_model'):getChildByName('Image_head') 
                self:testProgress(image,2)
            end
        end   
    end 
end 

--用户弃牌 abandonCard
function UIGameTableDeZhou:RespCMD_ABANDON_CARD(info)
    self:endProgress()
    local temp = self:compareData(info.SeatId)   
    if not temp  then temp = self['Panel_me'] end 
    local x,y = temp:getPosition() 
    local image = self['Image_abondonCard']:clone()
   
    local posX,posY = self['Image_cardAction']:getPosition() 
    local action =  cc.MoveTo:create(0.3,cc.p(posX,posY))
    local function action1() 
        image:removeFromParent()
    end 

    if self.mySeat_id   == info.SeatId  then  
        --self.myRoundState = 0 
        self['Text_myName']:setString(self.languageTable[self.langeageType][9]) 
        self['Image_myHead']:setColor(cc.c3b(127,127,127))
        self['Image_endShow']:setVisible(true)
        self['Panel_preOperate']:setVisible(false)
        self['Panel_operate']:setVisible(false)
        audio.playSound(Sound.SoundTable['Texus'][self.PlayerData.sex ==0 and 'FoldGirl' or 'FollowMen'] , false)
    else 
        temp:getChildByName('Image_card1'):setVisible(false)
        temp:getChildByName('Image_card2'):setVisible(false)
        audio.playSound(Sound.SoundTable['Texus']['FoldCard'] , false)
        self['Panel_main']:addChild(image)
        image:setPosition(cc.p(x,y))  
        image:runAction(cc.Sequence:create(action,cc.CallFunc:create(action1)))
        if temp:getChildByName('Image_model') then 
            local  temp_aaa = temp:getChildByName('Image_model')
            temp_aaa:getChildByName('Text_name'):setString(self.languageTable[self.langeageType][9]) 
            if temp_aaa:getChildByName('Image_head'):getChildByName('swapMenu') then 
               temp_aaa:getChildByName('Image_head'):getChildByName('swapMenu'):setColor(cc.c3b(87,87,87))
            end   
        end
    end

    if info.NextSeatId  >= 0 and info.NextSeatId <= 8 then    
        if self.mySeat_id   == info.NextSeatId  then 
            self:testProgress(self['Image_myHead'],1)
        else 
            local par =  self:compareData(info.NextSeatId)  
            local image = par:getChildByName('Image_model'):getChildByName('Image_head') 
            self:testProgress(image,2)
        end   
    end
end 

--用户全下 allIn
function UIGameTableDeZhou:RespCMD_ALL_IN(info)
    self:endProgress()
    if self.turnCardStadus == false  then 
         self.AllInStadus   = true  
    end    
    if  self.mySeat_id   == info.SeatId then 
        self['Text_myName']:setString(self.languageTable[self.langeageType][2]) 
        self.myCarry = self.myCarry- info.IncChip
        if self.myCarry<0 then self.myCarry =0 end 
        self['Text_myMoney']:setString(self.myCarry)
        self:chipMove(self['Panel_me'],info.AllinChip)
        audio.playSound(Sound.SoundTable['Texus'][self.PlayerData.sex ==0 and 'AllInGirl' or 'AllInMen'] , false)

    else 
        local par =  self:compareData(info.SeatId)  
        if par:getChildByName('Image_model') then         
            par:getChildByName('Image_model'):getChildByName('Text_name'):setString(self.languageTable[self.langeageType][2]) 
            local coin = par:getChildByName('Image_model'):getChildByName('Text_money'):getString() 
            par:getChildByName('Image_model'):getChildByName('Text_money'):setString(tonumber(coin)-info.IncChip)
            self:chipMove(par,info.AllinChip) 
        end
    end

    if  info.AllinChip > self.maxChip then   
        self.maxChip = info.AllinChip 
    end 

    if  info.NextSeatId  >= 0 and info.NextSeatId <= 8 then  
        if self.mySeat_id   == info.NextSeatId then 
            self:testProgress(self['Image_myHead'],1)
        else 
            local par =  self:compareData(info.NextSeatId)  
            if par:getChildByName('Image_model') then 
                local image = par:getChildByName('Image_model'):getChildByName('Image_head') 
                self:testProgress(image,2)
            end
        end   
    end
end 

-- 一回合下注结束  oneRoundOver 
function UIGameTableDeZhou:RespCMD_ONE_ROUND_OVER(info)
    self.maxChip = 0 
    self.compareChip = 0 
    self:endProgress() 
    self.totalChip = info.RoundBetTotal + self.totalChip
    for key=1,3 do 
        self['Image_preOpr'..key]:loadTextures('game/game_btn_4.png','game/game_btn_4.png','game/game_btn_4.png',ccui.TextureResType.plistType)
        self['CheckBox_pre'..key]:setSelected(false)   
    end        
    
    self['Text_addCallCoin']:setString('')
    self['Panel_Pool1']:setVisible(true)
    --audio.stopAllSounds()
    if  self.nowPlayers and #self.nowPlayers > 1 then  
        self:showPlayersName(self.nowPlayers)
        for key,var in pairs(self.nowPlayers) do 
            if var == self['Panel_me'] then 
                self['Text_Mychips']:setString('')
            else 
                var:getChildByName('Image_chip'):getChildByName('Text_chip'):setString('')    
            end    
        end 
    end 
    self['Text_antes']:setString('底池:'..self.totalChip)
    
    self.poolNum   = self.poolNum  + info.newPoolCount 
    print('回合结束')
    
    local mainPool = info.RoundBetTotal
    
    local temp_poolMoney = {}
   
    if  info.newPoolCount > 0 and #info.NewChipPoolList==info.newPoolCount then 
        for key,var in pairs(info.NewChipPoolList) do 
            local id,chip =var.PoolId+1,var.Chip
            mainPool = mainPool - chip 
            self['Panel_Pool'..id]:setVisible(true)
            self['Panel_Pool'..id]:getChildByName('Text_total'):setString(chip)      
            temp_poolMoney[tostring(id)] = chip            
                              
        end 
    end 
    local now =self['Panel_Pool'..(self.poolNum-info.newPoolCount)]:getChildByName('Text_total'):getString() 
    if not now  or now == '' then now = '0' end  
    self['Panel_Pool'..(self.poolNum-info.newPoolCount)]:getChildByName('Text_total'):setString(tonumber(now)+mainPool)
    temp_poolMoney[tostring(self.poolNum-info.newPoolCount)] = tonumber(now)+mainPool
    local function callback()
        self:collectChip(info.newPoolCount,(self.poolNum-info.newPoolCount),temp_poolMoney)
        audio.playSound(Sound.SoundTable['Texus']['GetTotal'] , false)
    end 
    self['Panel_main']:runAction(cc.Sequence:create(cc.DelayTime:create(0.5),cc.CallFunc:create(callback))) 
end
--显示玩家name
function UIGameTableDeZhou:showPlayersName(tab)
    for key,var in pairs(tab) do 
        for k,v in pairs(self.playerName) do 
            local aaa= self:compareData(v[1])            
            if  var==aaa and v[2]~= 0 and aaa:getChildByName('Image_model') then 
                aaa:getChildByName('Image_model'):getChildByName('Text_name'):setString(v[2])
            end 
        end 
    end 
end 

--显示高光牌
function UIGameTableDeZhou:showLightCard(card1,card2,tableMore,parent)  
   if  #tableMore ~= 5  then return end  
   local function compare(number) 
        for key,var in pairs(tableMore) do 
            if number == var then 
               return true 
            end    
        end           
   end 
   for key =1 ,5 do 
       self['Image_card_show'..key]:getChildByName('Image_lightBg'):setVisible(false)
   end     
--   print('显示高亮牌报错')
--   dump(self.commonCard)
   for key,var in pairs(self.commonCard) do 
       local a = compare(var) 
       if a == true then 
          self['Image_card_show'..key]:getChildByName('Image_lightBg'):setVisible(true)
       end 
   end 
   local b,c = compare(card1),compare(card2)

   if parent == self['Panel_me'] then 
      parent:getChildByName('Image_lightCard1'):setVisible(self.showCardState ~= 1 and b)    
      parent:getChildByName('Image_lightCard2'):setVisible(self.showCardState ~= 1 and c)   
      
   else      
      parent:getChildByName('Image_model'):getChildByName('Panel_endCard'):getChildByName('Image_lightCard1'):setVisible(b)    
      parent:getChildByName('Image_model'):getChildByName('Panel_endCard'):getChildByName('Image_lightCard2'):setVisible(c)    
   end  
end 

--显示WIN
function UIGameTableDeZhou:showWinImage(parent)  
   if parent:getChildByName('show_WinImage')  then 
      return  
   end 
   local image 
   if parent == self['Panel_me'] then          
        local size = self['Panel_me']:getContentSize()         
        local node = cc.CSLoader:createNode('res/win.csb')
        local action = cc.CSLoader:createTimeline('res/win.csb'); 
        node:setAnchorPoint(0.5,0)
        self['Panel_me']:addChild(node)
        node:runAction(action)
            action:gotoFrameAndPlay(0,false)    
        node:setLocalZOrder(25)  
        node:setPosition(size.width*0.55,size.height*1.6) 
        node:setName('show_WinImage')    
   
        local function callback()
            node:removeFromParent()
        end 
        self['Panel_me']:runAction(cc.Sequence:create(cc.DelayTime:create(2.5),cc.CallFunc:create(callback)))
   else    
      image = ccui.ImageView:create('game/game_win.png',ccui.TextureResType.plistType)         
      image:setName('show_WinImage')
      image:setAnchorPoint(0.5,0.5)
      local posx,posy = parent:getChildByName('Image_chip'):getPosition() 
      parent:addChild(image)   
      image:setPosition(posx,posy)  
      image:setLocalZOrder(25)
      --local fadeOut = cc.FadeOut:create(2.5)
      local function callback() 
         image:removeFromParent()
      end 
      image:runAction(cc.Sequence:create(cc.DelayTime:create(3.5),cc.CallFunc:create(callback)))   
   end 
end 

function UIGameTableDeZhou:preGameOver()
    --self:preShowButton()
    self['Panel_operate']:setVisible(false)
    self['Panel_preOperate']:setVisible(false)  
    self['Image_endShow']:setVisible(false)
    self['Panel_main']:getChildByName('hall_light_effect'):setVisible(false) 
    for key,var in pairs(self.pos_tab) do 
        if  var:getChildByName('Image_chip') then 
            var:getChildByName('Image_chip'):setVisible(false)
        end 
    end     
end 

--游戏结束 gameOver
function UIGameTableDeZhou:RespCMD_GAME_OVER(info)
    self:preGameOver()
    local function theEnding()
        local endPlayers = {}   
        local endPlayersId = {}   
        local PoolMoney = {['0']={},['1']={},['2']={},['3']={},['4']={},['5']={},['6']={},['7']={},['8']={}}
        
        if self['CheckBox_show']:isSelected() then 
            self:butEndShowCard() 
        end     
        
        if  info.playerCount > 0 and info.playerCount ==#info.PlayerInfoList then 
            for key ,var in pairs(info.PlayerInfoList) do 
                local card_value,max_value =var.HandCards ,var.MaxCards  
                local card1,card2 = self.PlayerData:getCard(card_value[1]),self.PlayerData:getCard(card_value[2])
                if self.mySeat_id == var.SeatId then 
                    --self['Text_Mychips']:setString(var.WinLossChip)
                    self.myCarry = var.TotalChip
                    --self['Text_myName']:setString(var.WinLossChip>0  and 'win~~~' or 'lose~~~')
                    self['Image_myZh']:setVisible(false)  
                    --self.PlayerData.coin = var.TotalCoin
                    
                    if #card_value < 1 then 
                        if  self.myRoundState ~= 0 then 
                            self['Button_endShow']:setVisible(true)      
                            local function callback2()
                                self['Button_endShow']:setVisible(false) 
                            end
                            self['Button_endShow']:runAction(cc.Sequence:create(cc.DelayTime:create(3),cc.CallFunc:create(callback2)))
                        end  
                    end 

                    if var.WinLossChip > 0 then --赢钱了
                        self.tool:addParticles("res/dealer/game_win.plist",self["Image_myLight"],5) 
                        self['Image_cardTypeBg']:loadTexture('game/game_card_bg1.png',ccui.TextureResType.plistType)
                        self['Image_cardTypeBg']:getChildByName('Image_mycardtype'):setColor(cc.c3b(255,222,0))
                        if var.CardType >= 8 then 
                            audio.playSound(Sound.SoundTable['Texus']['SpecialWin'] , false)
                        else 
                            audio.playSound(Sound.SoundTable['Texus']['Win'] , false)
                        end                                           
                        for i,j in pairs(var.WinPoolIds) do 
                            local temp1   = {} 
                            temp1.parent  = self['Panel_me']
                            temp1.money   = var.WinPoolChips[i] 
                            temp1.maxCard = max_value
                            temp1.handCard= card_value
                            table.insert(PoolMoney[tostring(j)],temp1)
                        end      
                    else
                        self['Text_myMoney']:setString(var.TotalChip) 
                    end                    
                else 
                    local par = self:compareData(var.SeatId)   
                    if par:getChildByName('Image_model') then 
                        table.insert(endPlayersId,var.SeatId)
                        if var.WinLossChip > 0 then --赢钱了
                            local child = par:getChildByName('Image_model'):getChildByName('Image_light')
                            self.tool:addParticles("res/dealer/game_win.plist",child,5) 
                            local tem_a = par:getChildByName('Image_model'):getChildByName('Panel_endCard')
                            tem_a:getChildByName('Image_endCardBG'):loadTexture('game/game_card_bg1.png',ccui.TextureResType.plistType)
                            tem_a:getChildByName('Image_endCardBG'):getChildByName('Card_type'):setColor(cc.c3b(255,222,0))  
                            for i,j in pairs(var.WinPoolIds) do 
                                local temp1  = {} 
                                temp1.parent = par
                                temp1.money  = var.WinPoolChips[i]
                                temp1.maxCard = max_value
                                temp1.handCard= card_value
                                table.insert(PoolMoney[tostring(j)],temp1)
                            end  
                        else 
                            if par:getChildByName('Image_model') then 
                                par:getChildByName('Image_model'):getChildByName('Text_money'):setString(var.TotalChip)  
                            end    
                        end 

                        par:getChildByName('Image_card1'):setVisible(false)
                        par:getChildByName('Image_card2'):setVisible(false)
                        table.insert(endPlayers,par)
                        if  card_value[1] and card_value[2] then 
                            local endCard = par:getChildByName('Image_model'):getChildByName('Panel_endCard')
                            endCard:setVisible(true)    
                            self:rotateCard(endCard:getChildByName('Image_endCard1'),card1) 
                            self:rotateCard(endCard:getChildByName('Image_endCard2'),card2)  

                            local function cardType1()
                                endCard:getChildByName('Image_endCardBG'):setVisible(true)
                                endCard:getChildByName('Image_endCardBG'):getChildByName('Card_type'):setString(self.PlayerData.cardType[self.langeageType][var.CardType])                                      
                            end 
                            endCard:runAction(cc.Sequence:create(cc.DelayTime:create(1.2),cc.CallFunc:create(cardType1)))
                        end
                        --par:getChildByName('Image_model'):getChildByName('Text_name'):setString(var.WinLossChip>0  and 'win~~~' or 'lose~~~')
                    end 
                end    
            end       
            local time1,time2 = self.poolNum,0
            local function endMoveChip() 
                self['Text_antes']:setString('')
                if self.poolNum == 1 then 
                    self['Panel_Pool1']:setVisible(false)
                    self['Panel_Pool1']:getChildByName('Text_total'):setString('')
                    self:gameOverChip(PoolMoney['0'],1)
                else 
                    local temp_aaa = self.poolNum-1
                    local function endingChipCall()
                        self['Panel_Pool'..(temp_aaa+1)]:setVisible(false) 
                        self['Panel_Pool'..(temp_aaa+1)]:getChildByName('Text_total'):setString('')
                        self:gameOverChip(PoolMoney[tostring(temp_aaa)],temp_aaa+1) 
                        temp_aaa = temp_aaa-1 
                        if temp_aaa < 0 then 
                            self:stopSchedule('gameEndingChip')
                        end    
                    end 
                    self:createSchedule('gameEndingChip', endingChipCall, 1)  
                end  
                self:showPlayersName(endPlayersId)            
                if self.inviteFriendTag then           
                    self.inviteFriendTag:removeChildByName('inviteFriend')
                    self.inviteFriendTag = nil 
                end    
                self['Text_antes']:setString('') 
                self:initMyCardInfo()
            end         
            self['Panel_main']:runAction(cc.Sequence:create(cc.DelayTime:create(1.2),cc.CallFunc:create(endMoveChip)))
                --cc.DelayTime:create(time1+1),cc.CallFunc:create(callback)))
        end
    end         
    self:runAction(cc.Sequence:create(cc.DelayTime:create(1),cc.CallFunc:create(theEnding)))  
end

--强制站起  forceToLeave 
function UIGameTableDeZhou:RespCMD_FORCE_STANDUP(data)
    print('强制站起')
    dump(data)
    self.mySeat_id = 200  
    self['Panel_me']:setVisible(false)
    self['Panel_operate']:setVisible(false)
    self['Button_mySitDown']:setVisible(true)
    self['Panel_preOperate']:setVisible(false) 
    if  tonumber(data.ForceStandStr) == 0 then 
        if self.PlayerData.coin == 0 then 
            if self.PlayerData.gem == 0 then 
                self.app:addView('UIShopDiamond',self:getLocalZOrder()+20)  
                --self.app:callMethod('UIShop','showView',1)   
            else 
                self.app:addView('UIQuickBuy',self:getLocalZOrder()+20)
            end    
        else 
            local max = (self.maxCarry >= self.PlayerData.coin) and self.PlayerData.coin or self.maxCarry  
            self.app:addView('UIAddChips',self:getLocalZOrder()+20,self.minCarry,max,self.bigBlind*2,self.TableType) 
        end  
    end 
end

--结束后亮牌 endingShow
function UIGameTableDeZhou:RespCMD_SHOW_CARD(data)  
    print('进入了亮牌')
    if data.SeatId == self.mySeat_id  then 
        --        local a,b = self['Panel_me']:getChildByName('Image_endCard1'),self['Panel_me']:getChildByName('Image_endCard2')
        --        local card1,card2 = self.PlayerData:getCard(data.Card1),self.PlayerData:getCard(data.Card2) 
        --        self:rotateCard(a,card1)   
        --        self:rotateCard(b,card2)  
        --        print('走了没有222')
    else 
        local par = self:compareData(data.SeatId)   
        if  par:getChildByName('Image_model') then 
            local endCard = par:getChildByName('Image_model'):getChildByName('Panel_endCard')
            endCard:setVisible(true)
            endCard:getChildByName('Image_endCardBG'):setVisible(false)
            local card1 ,card2 = self.PlayerData:getCard(data.Card1),self.PlayerData:getCard(data.Card2)
            self:rotateCard(endCard:getChildByName('Image_endCard1'),card1) 
            self:rotateCard(endCard:getChildByName('Image_endCard2'),card2) 
        end 
    end 
end  

function UIGameTableDeZhou:addChatBg(tag,info,Playerid,musicId)
    local par ,temp1,temp2,move  
    local temp = {self['Panel_right1'],self['Panel_right2'],self['Panel_right3'],self['Panel_right4'],self['Panel_left4'],self['Panel_left3'],self['Panel_left2'],self['Panel_left1'],self['Panel_centerOne'],self['Panel_me']}
    local talk_tag 
    local sex = 0  
    for key,var in pairs(self.playerSexTab) do 
        if tonumber(var.uid) == tonumber(Playerid) then 
           sex =  var.sex 
        end 
    end 
    for key,var in pairs(temp) do 
        if Playerid == var:getTag() then 
            par = var
            if par == self['Panel_right1'] or par == self['Panel_right2'] or par == self['Panel_right3'] or par == self['Panel_right4'] then 
               talk_tag = 2 
            elseif par == self['Panel_me']  then 
               talk_tag = 3 
            else
               talk_tag = 1 
            end 
            break 
        end    
    end  
    
    if tag ~= 2     then 
        local name = ( tonumber(Playerid) == tonumber(self.PlayerData.uid) and '我' or Playerid ) 
        local log = name.."："..info   --self.faceIconRecord
        table.insert(self.PlayerData.faceIconRecord,log)  
    end 
    if not par then return end   

    if  par == self['Panel_me']  then  
        temp1 = self['Panel_MytalkPos']
        temp2 = self['Text_MytalkPos']
    else 
        temp1 = par:getChildByName('Image_model'):getChildByName('Panel_talk'..talk_tag)
        temp2 = temp1:getChildByName('Text_talk')
    end 
    temp2:setPosition(self.talkPosX,self.talkPoxY)   

    local size = temp1:getContentSize()

    local function callback()
        temp1:setVisible(false) 
        temp2:setString('')
    end 
    if  tag ~= 2     then  --文字聊天   常用语聊天
        temp1:setVisible(true) 
        temp2:setVisible(true)  
        
        local word =  LuaTools.splitStringByTag(info,14)
        if tag == 3 and musicId then 
            local music = (sex ==0 and string.format('Common_f%d',musicId) 
                or string.format('Common_m%d',musicId) )
            --self.sound:playEffect(music) 
        end    
        if #word == 1 then 
           temp2:setString(word[1])
           local function callback2()
                temp1:setVisible(false) 
           end 
           temp2:runAction(cc.Sequence:create(cc.DelayTime:create(2),cc.CallFunc:create(callback2)))
        else 
           local count = 1 
           temp2:setString(word[count])          
           local function moveTips()
               temp2:setString(word[count])
               local move = cc.MoveBy:create(0.3,cc.p(0,size.height)) 
               local function call1() 
                    temp2:setPosition(self.talkPosX,self.talkPoxY)
                    temp2:setString('')
               end 
               temp2:runAction(cc.Sequence:create(cc.DelayTime:create(1.2),move,cc.CallFunc:create(call1)))
               if count > #word then 
                    self:stopSchedule('TalkMove') 
                    temp1:setVisible(false)
               end 
               count = count + 1  
           end      
           self:createSchedule('TalkMove', moveTips, 1.6)                   
        end 
    else                  --表情聊天 
        local music = (sex ==0 and string.format('Expression_f%d',info) 
            or string.format('Expression_m%d',info))
        --self.sound:playEffect(music) 
        local image_name = ccui.ImageView:create(string.format('res_chat/faceicon%d.png',info),ccui.TextureResType.plistType)
        --image_name:setScale(2)
        par:addChild(image_name)
        image_name:setLocalZOrder(35)
        local size = par:getContentSize()
        image_name:setPosition(size.width/2,size.height/2)
        image_name:setName('image_face')
        local function callback()
            image_name:removeFromParent()
        end 
        par:runAction(cc.Sequence:create(cc.DelayTime:create(1),cc.CallFunc:create(callback))) 
    end 
end 

--文字聊天  wordChat
function UIGameTableDeZhou:RespCMD_CHAT_STR(info) 
    self:addChatBg(1,info.chatStr,info.playerId)
end 

--表情聊天 faceChat     
function UIGameTableDeZhou:RespCMD_FACE_ID(info)
    self:addChatBg(2,info.chatExpId,info.playerId)
end 

--常用语聊天  commonChat
function UIGameTableDeZhou:RespCMD_COMMON_ID(info) 
    local text_table = {'哎，我说你丫能快点么','不要吵啦，专心游戏吧','不要走，决战到天亮',
        '大家好，很高兴见到各位','交个朋友，能告诉我你的联系方式么',
        '快点吧，我等的花儿都谢了','又断线了，网络怎么这么差啊','再见了，我会想念大家的','这年头，谁怕谁呀'}  
    self:addChatBg(3,text_table[info.chatStrId],info.playerId,info.chatStrId) 
end 

--送礼物 giveGift
function UIGameTableDeZhou:RespCMD_SENDGIFT(info) 
    --info.PlayerId  info.BePlayerId  info.giftId   --送礼物玩家，收礼物玩家 ，礼物id
    if self.app:getView('UISendGift') then 
        G_BASEAPP:removeView('UISendGift')
    end 
    if self.app:getView('UIFriendBrief') then 
        G_BASEAPP:removeView('UIFriendBrief')
    end    
    
    if info.playerId == info.BePlayerId  then 
       return 
    end  
    local temp= self.pos_tab
    table.insert(temp,self['Panel_me'])
    local from,to,image ,a,b
    for key ,var in pairs(temp) do 
        if info.playerId == var:getTag() then 
           from = var 
           a=key
        end 
        if info.BePlayerId == var:getTag() then    
           to =   var
           b=key
        end 
    end 
    if not from or not to then return end 
    local gift = {'common/gift1.png','common/gift2.png','common/gift3.png','common/gift4.png',
                  'common/gift5.png','common/gift6.png','common/gift7.png'}
    local animationTab = {'Animation_gift_flower.csb','Animation_gift_egg.csb','Animation_gift_car.csb',
           'Animation_gift_boat.csb','Animation_gift_aircraft.csb','Animation_gift_villa.csb','Animation_gift_beach.csb'}
    local image = ccui.ImageView:create(gift[info.giftId],ccui.TextureResType.plistType)
 
    local x1,y1 = from:getPosition()
    local x2,y2 = to:getPosition()
    self['Panel_main']:addChild(image,110)
    image:setPosition(x1,y1)

    -- if info.giftId == 2 then 
    --    image:setScale(0.5)
    -- end     

    -- local text_num = ccui.Text:create('x'..info.giftNum,'',24) 
    -- text_num:setAnchorPoint(0,0.5)
    -- local size2 = image:getContentSize()
    -- image:addChild(text_num)
    -- text_num:setPosition(size2.width*1.1,size2.height/2)

    local move -- = cc.MoveTo:create(0.5,cc.p(x2,y2))

    if info.giftId ~= 2 then 
       move = cc.MoveTo:create(1,cc.p(x2,y2))  
    else 
       move = cc.Spawn:create(cc.MoveTo:create(1,cc.p(x2,y2)),
            cc.RotateBy:create(1,1080))
    end  

   local function bbbb()
        if not to then return end 
        image:removeFromParent() 

        if info.giftId ~= 2 then 
            audio.playSound(Sound.SoundTable['sfx']['SendGift'],false)
        else 
            audio.playSound(Sound.SoundTable['sfx']['Market_egg'],false)
        end 

        local size = to:getContentSize()          
        local giftSendNode = cc.CSLoader:createNode(animationTab[info.giftId]) 
        local action = cc.CSLoader:createTimeline(animationTab[info.giftId])
        giftSendNode:runAction(action)
        action:gotoFrameAndPlay(0,false)
        local function cb1() 
            if not to then  return end 
            giftSendNode:removeFromParent()
        end     
        self:addChild(giftSendNode,99999)  
        giftSendNode:setPosition(x2,y2)

        to:runAction(cc.Sequence:create(cc.DelayTime:create(2.5),cc.CallFunc:create(cb1)))
   end  
   image:runAction(cc.Sequence:create(move,cc.CallFunc:create(bbbb)))   
end 

--踢人卡 letGo
function UIGameTableDeZhou:RespCMD_KICK_PEOPLE(info)
--info.PlayerId   info.BeKickPlayerId  --踢人   被踢
    --print('收到了踢人协议')
    local from,to ,parent
    if info.PlayerId == tonumber(self.PlayerData.uid) then 
       from = '您'
    else 
       for key,var in pairs(self.playerName) do    
           parent = self:compareData(var[1])            
           if parent and  parent:getTag() == tonumber(info.PlayerId) then 
              from = var[2]
              break
           end 
       end 
    end 
      
    if info.BeKickPlayerId == tonumber(self.PlayerData.uid) then 
       to = '您'
       local str = '玩家'..from..'将您踢出房间'
       --self.app:addView('UIForceLeave',150,str)
        G_BASEAPP:addView('UIDialog',self:getLocalZOrder()+20,1)
        G_BASEAPP:callMethod('UIDialog','setupDialog', '',str,
                    function() 
                        self:closeTexusTcp()
                        self.PlayerData.coin = self.PlayerData.coin + self.myCarry
                        G_BASEAPP:callMethod('UIMain','updateWealth')
                        G_BASEAPP:callMethod('UIMain','showEnterMainActions')
                        G_BASEAPP:removeView('UIGameTableDeZhou')
                        self:startOrEndTime(2)
                    end,
                    function() 
                        print('cancle LeaveTexusRoom')
                    end)
    else 
       for key,var in pairs(self.playerName)  do    
           parent = self:compareData(var[1]) 

           if parent  and  parent:getTag() == info.BeKickPlayerId then 
              to = var[2]
              self:leaveTab(2,info.BeKickPlayerId) 
              break
           end 
       end 
       self.tool:showTips(from..'将'..to..'踢出房间')   
    end  
   
end 

--打赏 giveServiceFee
function UIGameTableDeZhou:RespCMD_GIVE_FEE(data)   
    print('进入打赏')
    dump(data)
    local parent  
    if data.uid == self.mySeat_id then 
       parent = self['Panel_me']
       self.PlayerData.coin= self.PlayerData.coin - self.littleBlind
        audio.playSound(Sound.SoundTable['Texus']['GiveFee'] , false)
        local text = self['BitmapFontLabel_fee']:clone() 
        text:setString('-'..self.littleBlind)
        local x,y = self['BitmapFontLabel_fee']:getPosition() 
        parent:addChild(text)
        text:setPosition(x,y)       
        local  fadeOut = cc.FadeOut:create(1.5)
        local  move    = cc.MoveBy:create(1.5,cc.p(0,80))
        local  spawn   = cc.Spawn:create(fadeOut,move)
        local function callback1() 
            text:removeFromParent()
        end  
        text:runAction(cc.Sequence:create(spawn,cc.CallFunc:create(callback1)))
    else 
       parent = self:compareData(data.uid)
    end 
    local image = ccui.ImageView:create('card/chip_1_bet.png',ccui.TextureResType.plistType)     
    local x,y   = self['Image_cardAction']:getPosition() 
    local x1,y1 = parent:getPosition() 
    local action = cc.MoveTo:create(0.4,cc.p(x,y+50)) 
    self['Panel_main']:addChild(image,10)
    image:setPosition(x1,y1)
    local function callback()
        image:removeFromParent()
        audio.playSound(Sound.SoundTable['Texus']['GiveFee'] , false)
        local armature  = self['Panel_main']:getChildByName('Armature_dealer')
        armature:getAnimation():play('kiss')
    end 
    image:runAction(cc.Sequence:create(action,cc.CallFunc:create(callback)))
end 

--系统通知 systemInfo
function UIGameTableDeZhou:RespCMD_SYS_INFOS(info)
   
end 

--网络堵塞 netBlock
function UIGameTableDeZhou:RespCMD_NET_PRO(info)

end 

--请求添加好友  askForFriend  PlayerId
function UIGameTableDeZhou:RespCMD_ASK_FRIEND(info)
    -- if not self.app:getView('UIAddFriendTcp') then 
    --    self.app:addView('UIAddFriendTcp',338,info.PlayerId)
    -- end    
    local str = 'Uid:'..info.PlayerId..'的玩家请求加您为好友'
    G_BASEAPP:addView('UIDialog',self:getLocalZOrder()+20)
    G_BASEAPP:callMethod('UIDialog','setupDialog', '',str,
                    function() 
                        self:reqSock_RES_FRI(info.PlayerId,1)
                    end,
                    function() 
                        self:reqSock_RES_FRI(info.PlayerId,0)
                    end)
end 

--响应添加好友   resqFriend firePlayerId 发起请求，    agreePlayerId --被请求    ，agree  --是否同意
function UIGameTableDeZhou:RespCMD_RESQ_FRIEND(info)
    if self.app:getView('UIFriendBrief') then 
        self.app:removeView('UIFriendBrief')
    end   

    local str 
    if info.firePlayerId == tonumber(self.PlayerData.uid) then 
       if info.agree == 0 then 
          str = 'Uid:'..info.agreePlayerId..'的玩家拒绝成为您的好友'
       else 
          str = 'Uid:'..info.agreePlayerId..'的玩家已成为您的好友'    
            table.insert(self.PlayerData.friendUid,info.agreePlayerId)
 
       end     
   end 
   if  info.agreePlayerId == tonumber(self.PlayerData.uid) then 
       if info.agree == 0 then   
            str = '您拒绝了Uid:'..info.firePlayerId..'的好友邀请'
       else   
            str = '您通过了Uid:'..info.firePlayerId..'的好友邀请'
            table.insert(self.PlayerData.friendUid,info.firePlayerId)
       end 
    end    
    self.tool:showTips(str)    
end 

--经验  addExp  seatId totalExp  addExpiriendce
function UIGameTableDeZhou:RespCMD_EXP_ADD(data)
    if #data.info ~= tonumber(data.Popple) then 
        return 
    else 
        for key,var in pairs(data.info)  do 
            local par = self:compareData(var.seatId)
            if not par  then   par= self['Panel_me'] end  
            local size = par:getContentSize()
            local child  
            if par == self['Panel_me'] then 
                child =  var.addExp >0 and  (par:getChildByName('BitmapFontLabel_addExp')) or (par:getChildByName('BitmapFontLabel_lessExp'))
            else 
                child =  var.addExp >0 and  (par:getChildByName('Image_model'):getChildByName('BitmapFontLabel_addExp')) 
                    or (par:getChildByName('Image_model'):getChildByName('BitmapFontLabel_lessExp')) 
            end 
            if not child then return end 
            child:setString(var.addExp > 0 and ('EXP+'..var.addExp) or ('EXP'..var.addExp))
            local x,y = child:getPosition()
            --child:setVisible(true)
            local move = cc.MoveBy:create(0.8,cc.p(0,size.height/2))
            local function callback()
                child:setString('')
                child:setPosition(x,y)
            end 
            child:runAction(cc.Sequence:create(move,cc.CallFunc:create(callback)))
        end 
    end    
end 

---------------------------------------------------------------------------

return UIGameTableDeZhou
