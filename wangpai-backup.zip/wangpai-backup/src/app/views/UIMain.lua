
local UIMain = class("UIMain", cc.load("mvc").ViewBase)
-------------------------------------------------------------
require "cocos.cocos2d.json"
UIMain.hallTcpInstance = nil

local GameTableCommon = require("app.models.GameTableCommon")
local TCPConnector = require('app.network.TCPConnector')
local DataPacker = require('app.network.DataPacker')
local DataUnpacker = require('app.network.DataUnpacker')
local HttpHandler = require("app.network.HttpHandler")
--printWarning
local scheduler = require("app.models.QScheduler")
-------------------------------------------------------------
UIMain.RESOURCE_FILENAME = "UIMain.csb"
--UIMain.RESOURCE_PRELOADING = {"main.png"}
--UIMain.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg1"}}}

UIMain.RESOURCE_BINDING = {

}
UIMain.HALLCMD = DataUnpacker.CMD[DataUnpacker.Type.HALL]['REQ'] 



local winSize = cc.Director:getInstance():getWinSize()
 

function UIMain:showFirstCharge(b) 
    self.mainTop:showFirstCharge(b) 
end
 

function UIMain:onCreate()
    printf('UIMain:onCreate G_LOADINGVIEW:%s',G_LOADINGVIEW)
    if G_LOADINGVIEW then
        -- G_BASEAPP:removeView('UILoading')
        G_BASEAPP:removeView('UILoading') 
        G_LOADINGVIEW = nil
    end
    ISINIT = false
    self.isShowingMainEnterAction = false
    local app = self:getApp()
    self.app = app
 
    --在大厅里按返回键回调
    local function recruFunc() 
        LuaTools.playBtSound()
        -- print("=========================overrided==========================") 
        -- print("=========================overrided==========================") 
        -- print("=========================overrided==========================") 
        local function cb()
            -- print("AKIAJA")
            LuaTools.playBtSound()
            self.app:addView('UIDialog', 65535)
            self.app:callMethod('UIDialog','setupDialog', '', '是否确定退出游戏？', 
            function()
                cc.Director:getInstance():endToLua()
            end) 
        end
        if G_CHANNEL_CONFIG.isSdkLogin or G_CHANNEL_CONFIG.isOurOnlyAutoLogin then
            cb()
        else
            if self.pData.modify_pw == 0 and self.pData.isBindAccountDlgShowed == false then
                self.app:addView('UIBindAccountDialog',111,cb)
            else
                cb()
            end
        end

        self:addGobackEventAction(function() recruFunc() end) 
    end
    self:addGobackEventAction(function()
        recruFunc() 
    end)
    self.pData = self.app:getData('PlayerData') 
    --local time1 =  (self.pData.isFirstLoginGame == 1 and 10 or 1)    
    --self:runAction(cc.Sequence:create(cc.DelayTime:create(time1),cc.CallFunc:create(function() self:playBgdSound() end))) 
    self.sx, self.sy = self.app:getModel('Tools'):getUIScale()
    self.Main = app:getModel("Main")
    self.tool = app:getModel('Tools')
    -- --self.sound = app:getModel('Sound')
    self.config = app:getData('Config')
    self.LuaTools = LuaTools

    --初始化大厅UI
    self:initViews()

    self:HideRedPoint() 
    self:loadAvatar()
 
    --if self.pData.firstCharge == 0 then
    self:showFirstCharge(true)
    --end
    
    --读UIMainSocketTable
    if #self.pData.UIMainSocketTable == 0 then
        for k,v in pairs(DataUnpacker.CMD) do 
            if string.find(k,"HALLR") == 1 then
                self.pData.UIMainSocketTable[v] = k
            end
        end
        
    end
         
    --建立tcp链接
   self:setupHallTCP()

    ------------------------------------------
    --获取本地聊天记录
    UserCache.readCSFriendChat() 
    local time_temp = cc.UserDefault:getInstance():getStringForKey("SpreeTagBuy") 

    if time_temp ~= '' then 
        local time_now = os.date("*t") 
        local SpreeTagBuy = time_now.year..time_now.month..time_now.day
        if time_temp == SpreeTagBuy then 
              self.pData.isShowSpreeView = false  
        end 
    end          
    ---- self.pData.isShowSpreeView = true 
    --------------------------------------------
    --金币为0 申请破产补助
    if tonumber(self.pData.coin) <= 2000 then
        if  tonumber(self.pData.bank)== 0 and self.pData.gem == 0 then  
            local paTable =     {
                ['uid']   = G_UID,
                ['token'] = G_TOKEN,
                ['cmd']   = HttpHandler.CMDTABLE.GET_FREE_COIN  }  
            local function succ(arg) 
                if arg.msg then 
                    LuaTools.showAlert(arg.msg)
                end        
                if arg.coin then 
                    self.pData.coin = tonumber(arg.coin)
                    if G_BASEAPP:getView('UIMainTop') then 
                       G_BASEAPP:callMethod('UIMainTop','updateWealth')      
                    end 
                end     
            end    
            local function fail()
                if self.pData.gpackFlag <4 then      
                    G_BASEAPP:addView('UISpree',111111)
                else 
                    G_BASEAPP:addView('UIShopDiamond',111111)
                end     
            end     
            LuaTools.fastRequest(paTable,succ,fail)
        end    
    end

    --------------------------------------------
    
    --执行进入大厅动作，结束后，执行参数里的函数
	if G_UPDATEINFO.baseupdate and tonumber(G_UPDATEINFO.baseupdate.vername) > tonumber(VERNAME) then
		--apk更新
		self:showEnterMainActions(function()
			self.mainRank:setTouchState(false)
			self.app:addView('UIVerUpdate',111,function() 
				self.app:addView('UIRegistration',111)
			end) 
			end)
	else 
		self:showEnterMainActions(function()
			self.mainRank:setTouchState(false)
               if self.pData.signStadus ~= 0  and (self.pData.signStadus.regular == 0 or 
               (self.pData.signStadus.vip == 0 and tonumber(self.pData.vipvalid) > 0) ) then 
			      self.app:addView('UIRegistration',111,nil,self.pData.signStadus) 
               end 
			end)
	end

    audio.stopAllSounds()
    audio.stopMusic(true)  

    if G_CHANNEL_CONFIG.isSdkShowAdv then
        local ThirdSDKHandler = require('app.network.ThirdSDKHandler')
        ThirdSDKHandler.doShowAdv()
    end
		

end

--得到公告
function UIMain:requestAnnouncement()
    local dataTable =     {
        ['uid']       = self.pData.uid,
        ['unionid']   = G_CHANNELID,
        ['cmd']       = HttpHandler.CMDTABLE.ACT_ANNOUNCE,
        }
        local function succ(arg)    
            dump(arg)
        end
        local function fail(arg)
            if arg.msg then
                self.tool:showTips(arg.msg)
            end
        end
        self.tool:fastRequest(dataTable,succ, fail,false)
end
 

 --隐藏小红点
function UIMain:HideRedPoint()
    self.mainBottom:HideRedPoint()
end 

--播放背景音乐
function UIMain:playBgdSound()
    local snd = Sound.SoundTable['bgm']['MusicEx_Doudizhu']
    audio.playMusic(snd , true)
end

--进入大厅动作
function UIMain:showEnterMainActions(_cb)
    if self.isShowingMainEnterAction == true then --为了避免重复多次动作
        return
    end
    self.isShowingMainEnterAction = true
    self:resetViewsPosition()
    --self.mainRank:setTouchState(true)
    self.mainGame:showEnterActions()
    self.mainTop:showEnterActions()

    self.mainGame:showOrHideAward(true)

    self.mainBottom:showEnterActions()
    self.objBroadCast:showEnterActions()
    self.mainRank:showEnterActions()
	
    --给总体动作一个时间
    self:runAction(cc.Sequence:create(cc.DelayTime:create(1.2),
        cc.CallFunc:create(
            function() 
                if _cb then _cb() end
                cc.Director:getInstance():getTextureCache():removeUnusedTextures()
                self.isShowingMainEnterAction = false
                self.mainRank:setTouchState(false)
            end)
        ,nil))
	self:loadTarget()
end

--退出大厅动作
function UIMain:showExitMainActions(_cb)
    self.mainRank:setTouchState(true)
    --if self.pData.showOneGame == 0 then 
       self.mainGame:showExitActions()
    --end 
    self.mainTop:showExitActions()
    self.mainBottom:showExitActions()
    
    self.mainGame:showOrHideAward(false)

    self.objBroadCast:showExitActions()
    self.mainRank:showExitActions()
    
    self:runAction(cc.Sequence:create(cc.DelayTime:create(0.6),
        cc.CallFunc:create(
            function() 
				
                if _cb then _cb() end
                cc.Director:getInstance():getTextureCache():removeUnusedTextures()
                self.mainRank:setTouchState(false)
            end)
        ,nil))
end

--初始化游戏模式按钮
function UIMain:initViews()  
    self.mainGame = self.app:addView("UIMainGames",2)
    self.mainTop = self.app:addView("UIMainTop",3)
    self.mainBottom = self.app:addView("UIMainBottom",4)
    self.objBroadCast = self.app:addView({
                uiName = 'UIBroadcast',
                uiInstanceName = 'UIBroadcastMain'},5, true)
    self.mainRank = self.app:addView("UIMainRank",6)
    self.mainBottom:initTouchHandler(self.mainRank)
    -- self['Image_bg']:loadTexture("background/bg_ddz.png", ccui.TextureResType.localType)
	    self['Image_bg']:loadTexture("background/bg_ddzNormal.png", ccui.TextureResType.localType)

end

--当打开全屏的二级界面，执行以下切换动作动作
function UIMain:transitionViewAction(_action)
   self:runAction(_action:clone())
   self.mainGame:runAction(_action:clone())
   self.mainBottom:runAction(_action:clone())
   self.mainTop:runAction(_action:clone())
   self.objBroadCast:runAction(_action:clone())
   self.mainRank:runAction(_action:clone())
   
end

function UIMain:resetViewsPosition()
   self:setPositionX(0)
   self.mainGame:setPositionX(0)
   self.mainBottom:setPositionX(0)
   self.mainTop:setPositionX(0)
   self.objBroadCast:setPositionX(0)
   self.mainRank:setPositionX(0)
end

--每个10s发送一个心跳包
function UIMain:sendHeartbeat()
    self:stopSchedule('heartbeat')
    self:createSchedule('heartbeat', function()   
        self:reqSock_HeartBeat() 
    end,25)  
end
 
function  UIMain:proccessCMD_onConnected()
    print('UIMain proccessCMD_onConnected')
    UIMain.hallTcpInstance:sendData(self:reqSock_Login())
    self:sendHeartbeat()
     
end
 
function  UIMain:setupHallTCP()
      UIMain.hallTcpInstance = TCPGearbox.buildInstance({
            unpackerType = DataUnpacker.Type.HALL, 
            delegate = self,  
            callbackPrefix = "proccessCMD_",
            name = 'HallTCP'
        })
end

function UIMain:killSelf()
    -- body
end

--关闭Tcp连接
function UIMain:closeHallTcp()
    --print('Closing Hall Tcp') 
        self:reqSock_Logout()           --登出
        UIMain.hallTcpInstance:closeAndRelease()
        self:stopSchedule('heartbeat')   
end 
 
--[[ ------------------- BEGIN SOCKET HALL REQUEST FUNCTIONS -------------------- ]]--

function UIMain:reqSock_Login() 
    local bufferHnd = DataPacker.new(UIMain.HALLCMD['HALL_LOGIN'],{protocalVersion = 3})
--    print("self.pData.uid:",self.pData.uid,"self.pData.token：",self.pData.token)
    bufferHnd:writeData(self.pData.uid,DataPacker.INT)
    bufferHnd:writeData(self.pData.token,DataPacker.STRING)
    bufferHnd:writeData(1,DataPacker.BYTE)          --Network Type
    local buffer = bufferHnd:doPack()
    return buffer
end

function UIMain:reqSock_Logout() 
    local bufferHnd = DataPacker.new(UIMain.HALLCMD['HALL_LOGOUT'])
    local buffer = bufferHnd:doPack()
    UIMain.hallTcpInstance:sendData(buffer)
end

function UIMain:reqSock_getOnliner() 
    local bufferHnd = DataPacker.new(UIMain.HALLCMD['HALL_GET_ONLINE_PLAYERS_COUNT'])
    local buffer = bufferHnd:doPack()
    UIMain.hallTcpInstance:sendData(buffer)
end

function UIMain:reqSock_speakerBroadcast(msg,uid,type)  
    if not uid then uid = 0 end 
    --print("MSG BROADCAST: "..msg)
    local bufferHnd = DataPacker.new(UIMain.HALLCMD['HALL_SEND_SPEAKER'])
    bufferHnd:writeData(msg,DataPacker.STRING) --Msg To Broadcast
    local tabHex = {'FF',}
    for i, v in ipairs(self.pData.broadcastColor) do
        table.insert(tabHex, string.format('%0.2X',v))
    end
    --dump(tabHex)
    local hexString = '0x'..table.concat(tabHex)
    local intColor = tonumber(hexString)

    bufferHnd:writeData(intColor,DataPacker.LONG)
    bufferHnd:writeData(uid,DataPacker.INT)
    bufferHnd:writeData(type,DataPacker.BYTE)
    local buffer = bufferHnd:doPack()
    UIMain.hallTcpInstance:sendData(buffer)

end

function UIMain:reqSock_SEND_MSG_FRIEND(uid,msg) 
    local bufferHnd = DataPacker.new(UIMain.HALLCMD['HALL_SEND_MSG_FRIEND'])
    bufferHnd:writeData(uid,DataPacker.INT)          --Friend ID
    bufferHnd:writeData(msg,DataPacker.STRING)       --MSG to Friend
    local buffer = bufferHnd:doPack()
    UIMain.hallTcpInstance:sendData(buffer)
    -- print('发送了没有啊1111111111')
    
end

function UIMain:reqSock_queryNewbie() 
    local bufferHnd = DataPacker.new(UIMain.HALLCMD['HALL_QUERY_NEWBIE'])--(DataUnpacker.CMD['HALL_SEND_MSG_SERVICE'])
     local buffer = bufferHnd:doPack()
    UIMain.hallTcpInstance:sendData(buffer)
end

function UIMain:reqSock_sendMsgService(str) 
    local bufferHnd = DataPacker.new(UIMain.HALLCMD['HALL_SEND_MSG_SERVICE'])--(DataUnpacker.CMD['HALL_SEND_MSG_SERVICE'])
    bufferHnd:writeData(str,DataPacker.STRING)  --Msg to Service
    local buffer = bufferHnd:doPack()
    UIMain.hallTcpInstance:sendData(buffer)
    print('已发送反馈：'..str)
end 

function UIMain:reqSock_inviteFriend(uid,roomType,roomId) 
    local bufferHnd = DataPacker.new(UIMain.HALLCMD['HALL_INVITE_FRIEND'])
    bufferHnd:writeData(uid,DataPacker.INT)           -- Friend ID
    bufferHnd:writeData(roomType,DataPacker.INT)      -- ROOM Type
    bufferHnd:writeData(roomId,DataPacker.INT)        -- ROOM ID
    local buffer = bufferHnd:doPack() 
    UIMain.hallTcpInstance:sendData(buffer)
end

function UIMain:reqSock_HeartBeat() 
    local bufferHnd = DataPacker.new(UIMain.HALLCMD['HALL_HEARTBEAT'])
    local buffer = bufferHnd:doPack()
    UIMain.hallTcpInstance:sendData(buffer)
end


--[[ ------------------- END SOCKET HALL REQUEST FUNCTIONS -------------------- ]]--


--[[ ------------------- BEGIN SOCKET HALL RESPONSE FUNCTIONS -------------------- ]]--

function UIMain:proccessCMD_LOGIN_SUCC(data)
    self.pData.gamePorts = json.decode(data.Ports) or {}
    local onliner = data.onlinePlayers
    local lastGameID = data.lastGameUID
	
    dump(data,'大厅tcp登录成功')
	if G_CHANNELID == "dch_tx_02" then
		dump(G_TXLOGININFO,"登录参数")
		--腾讯登录的时候需要获取一下支付查询
		local pay_conf = LuaTools.getPayData()
		pay_conf['openid'] = G_TXLOGININFO['uuid']
		pay_conf['openkey'] = G_TXLOGININFO['password']
		pay_conf['pay_token'] = G_TXLOGININFO['payToken']
		pay_conf['pf'] = G_TXLOGININFO['pf']
		pay_conf['pfkey'] = G_TXLOGININFO['pf_key']
		pay_conf['token'] = G_TOKEN
		dump(pay_conf,"查询支付参数")
		if _G.next(pay_conf) ~= nil and _G.next(G_TXLOGININFO) ~= nil then
			LuaTools.fastRequest(pay_conf,function() 
				--成功情况
				print("腾讯充值登录回金币成功")
			end,function() 
				--失败情况
				print("腾讯充值登录回金币失败")
			end,{ 
				disableAlert =true,
				disableWaiting =true
			})
		end
	end
    --self['Text_OnlineCount']:setString('在线人数: '..self.tool:convertToText(onliner))   

    --更新在线人数
   -- self:createSchedule('updateCount', function()  
    --    self:reqSock_getOnliner()
    --end,3)  
end

function UIMain:proccessCMD_QUERY_NEWBIE(data)
    -- dump(data,"proccessCMD_QUERY_NEWBIE") 
    self.newbieProgress =   data.newbieProgress or 0 
    if self.newbieProgress == 5 and self.pData.bitcheckCaiNiao == 0 then 
        self.pData.bitcheckCaiNiao = 1
        --LuaTools.showAlert('恭喜你已完成菜鸟任务！')
    end
    if G_BASEAPP:getView('UIGameTable') then 
        G_BASEAPP:callMethod('UIGameTable','updateNewieProgress',data.newbieProgress) 
    end  
end

function UIMain:proccessCMD_GET_ONLINE_PLAYERS_COUNT(data)
    dump(data,'当前的人数')
    local onliner = data.onlinePlayers
    local others = json.decode(data.othersCount)
    --self['Text_OnlineCount']:setString('在线人数: '..self.tool:convertToText(onliner))
     
    self.pData.onlinePlayerNumber = others 
    local matchRooms = self.app:getView('UIMatchRoomDDZBooms') or self.app:getView('UIMatchRoomDouniuZJH') or 
        self.app:getView('UIMatchRoomDDZClassic') or self.app:getView('UIMatchRoomRunFast') 
    if matchRooms then 
        matchRooms:updatePlayerCounts(others)
    elseif self.mainGame then
        self.mainGame:updatePeopleCounts(others)
    end
end

--老版本的广播协议
function UIMain:proccessCMD_SYS_OLDBOARDCAST(data) 
    local msgType = data.msgType
    local msgStr = data.msgContent
    local uid = data.uid
    local color = data.color
    local gameType = data.gameType
    local name = data.name or '' 
    local typeLaba = data.type 
    local num   = data.num 
    --table.insert(self.pData.listBroadcastMsg,msgStr)

    dump(data)
    local ccColor
    if msgType == 0x01 then   --系统发广播
        ccColor = cc.c3b(255,0,0)
        name = '系统消息'    
    -- else  --0x02 // 用户发广播
    --     local hexColor = string.format('%0.2x',color)  --ffffffff
    --     hexColor = string.sub(hexColor, 3)      --去掉两个ff
    --     printf('HEx Color: %s', hexColor)
        
    --     local arrByteColor = LuaTools.hexStr2ByteArr(hexColor)
    --     dump(arrByteColor)
    --     ccColor = cc.c3b(arrByteColor[1],arrByteColor[2],arrByteColor[3])
    end
    if color ~= 0 and  color ~= 0xD54B00 then 
        local hexColor = string.format('%0.2x',color)  --ffffffff
        hexColor = string.sub(hexColor, 3)      --去掉两个ff
        printf('HEx Color: %s', hexColor)
        
        local arrByteColor = LuaTools.hexStr2ByteArr(hexColor)
        dump(arrByteColor)
        ccColor = cc.c3b(arrByteColor[1],arrByteColor[2],arrByteColor[3])
    end 

    if uid == tonumber(self.pData.uid) then
        self.pData.prop[2] = self.pData.prop[2]-num
        if self.app:getView('UIChat') then 
           self.app:callMethod('UIChat','updateHornCount') 
           LuaTools.showAlert('喇叭发送成功')
        end 
    end

    local temp = {} 
    temp.uid    = uid 
    temp.color  = ccColor 
    temp.name   = name
    temp.str    = msgStr
    if #self.pData.broadcastRecord >=30 then 
       local newRecord = {} 
       for key = 10,#self.pData.broadcastRecord do 
           local v = self.pData.broadcastRecord[key]          
           table.insert(newRecord, v)
       end 
       self.pData.broadcastRecord = newRecord
    end     
    table.insert(self.pData.broadcastRecord, temp)
    
    if self.app:getView('UIChat') then 
        print('UPDATE UICHAT')
        self.app:callMethod('UIChat','updateWorld',msgStr,ccColor,uid,name)
    end  
    local str
     if name == '' then
        str = msgStr
    else
        str = name..":"..msgStr
     end
    for i,v in ipairs(self.pData.braodCastObject) do
        if v.startBroadcast then 
            v:startBroadcast(str, ccColor)
        end

    end

    --if self.objBroadCast then
       -- self.objBroadCast:startBroadcast(data.msgContent, ccColor)
    --end
end

--新版本的广播协议
function UIMain:proccessCMD_SYS_NEWBOARDCAST(data) 
    -- dump(data,'新版本喇叭')
    local msgType = data.msgType
    local msgStr = data.msgContent
    local uid = data.uid
    local color = data.color
    local gameType = data.gameType
    local name = data.name 
    local isBright = data.isBright 
    local altUid = data.altUid  
    local altName = data.altName  
    local typeLaba = data.type 
    local num   = data.num 
    --table.insert(self.pData.listBroadcastMsg,msgStr)
    -- print('新版本1111111111111111111')
    -- dump(data)
    local ccColor
    if msgType == 0x01 then   --系统发广播
        ccColor = cc.c3b(213,75,0)
        name = '系统消息'    
    -- else  --0x02 // 用户发广播
    --     local hexColor = string.format('%0.2x',color)  --ffffffff
    --     hexColor = string.sub(hexColor, 3)      --去掉两个ff
    --     printf('HEx Color: %s', hexColor)
        
    --     local arrByteColor = LuaTools.hexStr2ByteArr(hexColor)
    --     dump(arrByteColor)
    --     ccColor = cc.c3b(arrByteColor[1],arrByteColor[2],arrByteColor[3])
    end
    if color ~= 0 and color ~= 0xD54B00  then 
        local hexColor = string.format('%0.2x',color)  --ffffffff
        hexColor = string.sub(hexColor, 3)      --去掉两个ff
        printf('HEx Color: %s', hexColor)
        
        local arrByteColor = LuaTools.hexStr2ByteArr(hexColor)
        dump(arrByteColor)
        ccColor = cc.c3b(arrByteColor[1],arrByteColor[2],arrByteColor[3])
    end 

    if uid == tonumber(self.pData.uid) then
        self.pData.prop[2] = self.pData.prop[2]-num
        if self.app:getView('UIChat') then 
           self.app:callMethod('UIChat','updateHornCount') 
           LuaTools.showAlert('喇叭发送成功')
        end 
    end

    local temp = {} 
    temp.uid    = uid 
    temp.color  = ccColor 
    temp.name   = name
    temp.str    = msgStr
    
    if #self.pData.broadcastRecord >=30 then 
       local newRecord = {} 
       for key = 10,#self.pData.broadcastRecord do 
           local v = self.pData.broadcastRecord[key]          
           table.insert(newRecord, v)
       end 
       self.pData.broadcastRecord = newRecord
    end  

    table.insert(self.pData.broadcastRecord, temp)
    
    if self.app:getView('UIChat') then 
        print('UPDATE UICHAT')
        self.app:callMethod('UIChat','updateWorld',msgStr,ccColor,uid,name)
    end  
    
    dump(self.pData.braodCastObject, "OBJETS BROADCAST")
    for i,v in ipairs(self.pData.braodCastObject) do
        if v.startBroadcast then 
            v:startBroadcast(name..":"..msgStr, ccColor)
        end
    end

    --if self.objBroadCast then
       -- self.objBroadCast:startBroadcast(data.msgContent, ccColor)
    --end
end

function UIMain:compareUID(UID)
    -- dump(UserCache.csFriendChat,'嘿嘿嘿嘿')
    print('uid='..UID)
    for key , var in pairs(UserCache.csFriendChat) do 
        if  key == tostring(UID) then 
            return true 
        end 
    end 
end 

function UIMain:proccessCMD_FRIEND_MSG(data)  
    local time = os.date("%Y-%m-%d %H:%M:%S")  
    -- dump(data)
    -- print('已收到好友消息111111111111')

    local tab = {}
    local temp = self:compareUID(data.uid) 
    tab.msg  =  data.msg 
    tab.time =  time
    tab.uid  =  data.uid 
    if temp then  
        table.insert(UserCache.csFriendChat[tostring(data.uid)],tab)       
    else 
        UserCache.csFriendChat[tostring(data.uid)] = {} 
        table.insert(UserCache.csFriendChat[tostring(data.uid)],tab)       
    end   
    UserCache.writecsFriendChat() 

    if not self.app:getView('UIChat')  then     
        self.pData.chatLogNumber = self.pData.chatLogNumber + 1              
        self:HideRedPoint()
        if temp  and self.pData.chatLogTable[tostring(data.uid)] then 
           self.pData.chatLogTable[tostring(data.uid)] =  self.pData.chatLogTable[tostring(data.uid)] + 1
        else 
           self.pData.chatLogTable[tostring(data.uid)] =  1
        end     
        if self.app:getView('UIFriend') then 
           for key,var in pairs(self.pData.chatLogTable) do 
               if var ~= 0 then 
                  self.app:callMethod('UIFriend','updateRedPoint',key)
               end 
           end        
        end    
    else       
        self.app:callMethod('UIChat','AddRecord',data)
    end                                                                                                                   
end

function UIMain:proccessCMD_SYS_INFO(data)
    dump(data,'收到系统消息')
    local infoType = data.infotype
    local msg = data.infoContent
    --if infoType == 66 then          --发喇叭时间限制10秒 
    self.tool:showTips(msg)
   -- end
      
end

function UIMain:proccessCMD_INVITE_FRIEND(data)
    printf("proccessCMD_INVITE_FRIEND:")
    local gameId = tonumber(data.gameUid)
    local roomId = data.roomUid
    local fuid = data.friendUid
    local fNick = data.friendNickname
    if gameId == 14 then  --婚礼邀请 
        G_BASEAPP:addView('UIDialog', 500)
        G_BASEAPP:callMethod('UIDialog','setupDialog', '', '您的好友'..fNick..'邀请您参加婚礼？',
            function() 
            if  G_BASEAPP:getView('UIFriendWeddingRoom') then 
                G_BASEAPP:getView('UIFriendWeddingRoom'):closeWeddingTcp()
                G_BASEAPP:getView('UIFriendWeddingRoom'):setupWeddingTCP(fuid,fNick)   
            elseif  GameTableCommon.getLastDelegate()  then 
                GameTableCommon.quitComfirm(GameTableCommon.getLastDelegate(),true)
                G_BASEAPP:addView('UIFriendWeddingRoom',130,fuid,fNick)    
            else 
                G_BASEAPP:addView('UIFriendWeddingRoom',130,fuid,fNick)    
            end     
        end)
    --elseif gamaId==     
    --     local load = G_BASEAPP:addView("UILoading",100)  
    -- G_LOADINGVIEW = load
    -- load:setLoadingType(true)
    -- load:setNextAction(function()
    --     G_BASEAPP:addView("UIGameTable",200,{
    --         friendID =  fuid
    --         })  
    -- end)
    -- load:startProgress()
    end     

    -- self.app:addView('UIDialog', 500)
    --     self.app:callMethod('UIDialog','setupDialog', '好友邀请', '您的好友'..fNick..'邀请您游戏，要参加吗？',
    --         function() 
    --         self:requestSocketData(nil,tonumber(fuid),tonumber(roomId))        
    --     end)
end

function UIMain:proccessCMD_SERVICE_MSG(data)
   dump(data,'收到客服数据')
    local msgType = data.infotype
    local msgStr  = data.infoContent
      local tbl = {
    msg = data.infoContent,
    date = os.date("%c"),
    who = 'cs'
  }
  if not UserCache.csHistory[tostring(self.pData.uid)] then 
     UserCache.csHistory[tostring(self.pData.uid)] = {} 
  end 
  table.insert(UserCache.csHistory[tostring(self.pData.uid)],tbl) 
  UserCache.writeCSHistory()
  if G_BASEAPP:getView('UIChatOnline') then
     G_BASEAPP:callMethod('UIChatOnline','appendCell',tbl)
     UserCache.scRespondedToUser = true
  else 
      if G_BASEAPP:getView('UIMainTop') then 
         G_BASEAPP:callMethod('UIMainTop','showOrHideChatDot',true)
      end      
  end
end    


function UIMain:proccessCMD_NEW_MAIL(data) 
    if  data.CMD == 0x56 then 
        if data.type == 3 then    --其他玩家购买了您的金币
             self.tool:showTips(data.msg) 
             local market = self.app:getView('UIShopTradeMarket')
             if market then
                market:onRefresh()
             end
        end
        if not self then --uimain 已经被销毁了 所有self都会为nil
            G_BASEAPP:getData('PlayerData').newMailCount = G_BASEAPP:getData('PlayerData').newMailCount + 1 
            return
        end
        self.pData.newMailCount = self.pData.newMailCount + 1 
        self.tool:showTips(data.msg) 
        if not self.app:getView('UIMail')  then 
             self.mainBottom:updateMailDot()
        else 
            local mail = self.app:getView('UIMail') 
            if tonumber(data.type) == mail.lastSelectedIndex then  
                mail:requestMail(data.type,1,1) 
            else 
                mail:SetRedPoint(data.type)
            end     
        end     
    end   
end


function UIMain:proccessCMD_SYNC_INFO(data)
     dump(data,"proccessCMD_SYNC_INFO")
    local msgStr = unicode_to_utf8(data.encodedjsonData)        
    local tbl = json.decode(msgStr)

     print(data.encodedjsonData)
     dump(tbl,'FFFFFFFFFFFFFFFFFFFFFFFFFFFFF')
    if tbl then 
        if tbl.msg then  
           LuaTools.showAlert(tbl.msg)
        end     

        self.pData.vip_level= tbl.vip_level or self.pData.vip_level
        -- self.pData.charm = tbl.charm or self.pData.charm 
        -- self.pData.vip_day = tbl.vipexpired or self.pData.vip_day 
        -- self.pData.level = tbl.level or self.pData.level 
        -- self.pData.exp = tbl.exp or self.pData.exp 
        self.pData.coin = tbl.coin or self.pData.coin 
        self.pData.gem = tbl.gem or self.pData.gem 
        self.pData.accu = tbl.accu or self.pData.accu 
        -- self.pData.wins = tbl.wins or self.pData.wins 
        -- self.pData.fails = tbl.fails or self.pData.fails
        self.pData.bank = tbl.bank or self.pData.bank
        self.pData.vipvalid = tbl.vipvalid or self.pData.vipvalid 


        self.pData.bitcheck   = tonumber(tbl.bitcheck)  or self.pData.bitcheck  
        if self.pData.bitcheck then 
            self.pData.bitcheckCaiNiao = (bit._and(self.pData.bitcheck,1) == 1) and  0 or  1 
            self.pData.bitcheckFund    = (bit._and(self.pData.bitcheck,2) == 2) and  1  or 0 
        end 
        self.pData.gpackFlag  = tonumber(tbl.gpackFlag)  or self.pData.gpackFlag    

        self.pData.paytotal = tbl.paytotal or  self.pData.paytotal 

        -- if tbl.max_cards and tbl.max_cards ~= false and tbl.max_cards ~= "" then
        --     self.pData.bestHand = json.decode(info.max_cards)
        -- end 
        self.pData.growth = tbl.growth or self.pData.growth 
        if tbl.gift then
            for k = 1, #tbl.gift do
                self.pData.gift[k] = tbl.gift[tostring(k)]
            end
        end

        if tbl.prop then 
            self.pData.prop[1] = tbl.prop['4']
            self.pData.prop[2] = tbl.prop['7']
            self.pData.prop[3] = tbl.prop['1']
        end     
        -- print('此时的vip='..self.pData.vip_level)

        if G_BASEAPP:getView('UIFund') then 
           G_BASEAPP:callMethod('UIFund','UpdateInfo') 
        end  
        
        if G_CHANNEL_CONFIG.isSdkPay then
			if G_PAYINFO then
				local sendumeng = {}
				sendumeng['type'] = 'pay'
				sendumeng['price'] = G_PAYINFO.price
				sendumeng['gold'] = G_PAYINFO.gem
				sendumeng['pricetype'] = 1
				LuaTools.setUmeng(sendumeng)
			end
        else
            if G_BASEAPP:getView('UICharge') then 
				if G_PAYINFO then
					local sendumeng = {}
					sendumeng['type'] = 'pay'
					sendumeng['price'] = G_PAYINFO.price
					sendumeng['gold'] = G_PAYINFO.gem
					sendumeng['pricetype'] = 1
					LuaTools.setUmeng(sendumeng)
				end
				G_BASEAPP:removeView('UICharge')
            end  
        end   

        if G_BASEAPP:getView('UISpreeLimit') then 
            G_BASEAPP:removeView('UISpreeLimit') 
            G_BASEAPP:callMethod('UIMainTop','HideLimitSpree')
        end    


        if G_BASEAPP:getView('UIDailypacks') then 
            G_BASEAPP:removeView('UIDailypacks') 
            self.pData.dailyProduct = 0
            G_BASEAPP:callMethod('UIMainTop','hideDailyPacks')
        end   
 
        -- if tbl.tool then      GameTableCommon.REQ_UPDATE_PLAYER(delegate)
        --     for k = 1, #tbl.tool do
        --         self.pData.prop[k] = tbl.tool[tostring(k)]
        --     end
        -- end  

        --如果在游戏场内 ,通知tcp更新金币信息
        if  GameTableCommon.getLastDelegate() and not G_BASEAPP:getView('UIGameTableMatch')  then 
                GameTableCommon.REQ_UPDATE_PLAYER(GameTableCommon.getLastDelegate())
        end         

        if G_BASEAPP:getView('UISpree') then 
             G_BASEAPP:removeView('UISpree')
        end 

        if G_BASEAPP:getView('UIShopDiamond') then 
             G_BASEAPP:removeView('UIShopDiamond')
        end
        
        if G_BASEAPP:getView('UIShop') then 
           G_BASEAPP:callMethod('UIShop','updateContent') 
        end

        if G_BASEAPP:getView('UIMainTop') then 
           G_BASEAPP:callMethod('UIMainTop','updateWealth') 
           G_BASEAPP:callMethod('UIMainTop','updateGpack') 
        end  

        if G_BASEAPP:getView('UIGameTable') then 
           G_BASEAPP:callMethod('UIGameTable','updateMyMoney',self.pData.coin,self.pData.gem) 
        end 

        if G_BASEAPP:getView('UIGameTableDouniu') then 
           G_BASEAPP:callMethod('UIGameTableDouniu','updateMyMoney',self.pData.coin,self.pData.gem) 
        end  

        -- 更新换场金币
        if G_BASEAPP:getView('UIMatchRoomDDZBooms') then 
           G_BASEAPP:callMethod('UIMatchRoomDDZBooms','enterChargeDiamond') 
        end      

        if G_BASEAPP:getView('UIMatchRoomDouniuZJH')  then 
           G_BASEAPP:callMethod('UIMatchRoomDouniuZJH','updatePlayerCoin')  
        end    

    end
end

--更新所有界面的金币 元宝 等信息
function UIMain:updateAllPageInfo()
    if G_BASEAPP:getView('UIShop') then 
       G_BASEAPP:callMethod('UIShop','updateContent') 
    end
    if G_BASEAPP:getView('UIMainTop') then 
       G_BASEAPP:callMethod('UIMainTop','updateWealth') 
       G_BASEAPP:callMethod('UIMainTop','updateGpack') 
    end  

    if G_BASEAPP:getView('UIGameTable') then 
       G_BASEAPP:callMethod('UIGameTable','updateMyMoney',self.pData.coin,self.pData.gem) 
    end 

    if G_BASEAPP:getView('UIGameTableDouniu') then 
       G_BASEAPP:callMethod('UIGameTableDouniu','updateMyMoney',self.pData.coin,self.pData.gem) 
    end  

    -- 更新换场金币
    if G_BASEAPP:getView('UIMatchRoomDDZBooms') then 
       G_BASEAPP:callMethod('UIMatchRoomDDZBooms','updatePlayerCoin') 
    end      

    if G_BASEAPP:getView('UIMatchRoomDouniuZJH')  then 
       G_BASEAPP:callMethod('UIMatchRoomDouniuZJH','updatePlayerCoin')  
    end  
    if G_BASEAPP:getView('UIMatchRoomDDZClassic')  then 
       G_BASEAPP:callMethod('UIMatchRoomDDZClassic','updatePlayerCoin')  
    end

    if G_BASEAPP:getView('UIMatchRoomRunFast')  then 
       G_BASEAPP:callMethod('UIMatchRoomRunFast','updatePlayerCoin')  
    end

    if G_BASEAPP:getView('UIAwards') then 
       G_BASEAPP:callMethod('UIAwards','updateWealth')  
    end     

end     

function UIMain:proccessCMD_OFFLINE_MSG(data)  
    dump(data,'有离线消息')
    if data.msgContent  and  data.msgLength and  #data.msgContent ~= data.msgLength then  
       print('离线消息解析错误')
       return 
    end 
    if not data.msgContent then 
        return 
    else
        self.mainBottom.Image_friendDot:setVisible(true)
        self.mainBottom.Image_friendDot:getChildByName('Text_num'):setString(data.msgLength)  
    end 
    for key,var in pairs(data.msgContent) do 
        local value = json.decode(var) 
        local temp = self:compareUID(value.uid)
        local tab = {} 
        tab.msg  =  value.msg
        tab.time =  value.date
        tab.uid  =  value.uid 
        if tonumber(value.uid) == 10000 then 
              local tbl = {
                    msg = value.msg,
                    date = os.date("%c"),
                    who = 'cs',}
              if not UserCache.csHistory[tostring(self.pData.uid)] then 
                 UserCache.csHistory[tostring(self.pData.uid)] = {} 
              end 
              table.insert(UserCache.csHistory[tostring(self.pData.uid)],tbl) 
              if G_BASEAPP:getView('UIMainTop') then 
                 G_BASEAPP:callMethod('UIMainTop','showOrHideChatDot',true)
              end   
        else 
            self.pData.chatLogNumber = self.pData.chatLogNumber + 1         
            if temp  and self.pData.chatLogTable[tostring(value.uid)] then  
                self.pData.chatLogTable[tostring(value.uid)] = self.pData.chatLogTable[tostring(value.uid)] + 1
                table.insert(UserCache.csFriendChat[tostring(value.uid)],tab)
            else 
                self.pData.chatLogTable[tostring(value.uid)] = 1            
                UserCache.csFriendChat[tostring(value.uid)] = {}
                table.insert(UserCache.csFriendChat[tostring(value.uid)],tab)
            end 
            UserCache.writecsFriendChat() 
            self:HideRedPoint()
        end     
    end 
end

function UIMain:proccessCMD_HEARTBEAT(data)
    
end

function UIMain:proccessCMD_FORCE_OFFLINE(data)
    local msgLen = data.errCode
    local msgStr = data.errContent
    print("MSGLEN: "..msgLen.."   MSGSTR: "..msgStr)
    --dump(G_BASEAPP)
    self:closeHallTcp()  
     for k,v in pairs(G_BASEAPP._views) do
      --for k,vv in pairs(v) do 
         -- G_BASEAPP:removeView(k)   
         if k ~= "UIDummyScene" and tolua.isnull(v) == false then
            G_BASEAPP:removeView(k) 
         end
     --  end 
   end 
    G_BASEAPP:enumerateScene(function(var)

     end) 
    G_BASEAPP:addView('UILogin',101,1)
    G_BASEAPP:addView('UIAlert',10000)
          :setupDialog('Infomation',data.errContent)
end

-- 
function UIMain:proccessCMD_MISSION_ONCHANGE(data)
    -- print('收到任务完成')
    local temp = json.decode(data.data)
    dump(temp,'收到任务完成')
    local id = temp.TaskId
    -- if id>=141 then 
    --     if G_BASEAPP:getView('UIGameTableDeZhou') and (id>=61 and id<= 80) then  
    --         G_BASEAPP:callMethod('UIGameTableDeZhou','showOrHideTask',1)
    --     elseif  GameTableCommon.getLastDelegate() and ((id>=1 and id<= 60) or (id>=81 and id<= 140)) then 
    --         GameTableCommon.showTastRedPoint(GameTableCommon.getLastDelegate())
    --     elseif (id>=141 and id <=160)  then --if G_BASEAPP:getView('UIGameHall') then       
    --         G_BASEAPP:callMethod('UIMainTop','updateFundRedPoint',true)
    --     end 
    --     G_BASEAPP:callMethod('UIMainTop','updateTaskRedPoint',true)
    -- end 
    if id>=141 and id <=160  then
        G_BASEAPP:callMethod('UIMainTop','updateFundRedPoint',true)
    elseif  id>=161 and id <=170  then
        G_BASEAPP:callMethod('UIMainTop','updateTaskRedPoint',true)
        if  GameTableCommon.getLastDelegate()  then 
            GameTableCommon.showTastRedPoint(GameTableCommon.getLastDelegate())
        end     
    end     
end 


--通知比赛场开始进入比赛   --matchId  matchType extend
function UIMain:proccessCMD_TIP_MATCH_BEGIN(data) 
    dump(data,'通知比赛场开始进入比赛')
    if data.matchId  then 
        if  G_BASEAPP:getView('UIGameTable')  then 
            G_BASEAPP:addView('UIDialog', 99999)
            G_BASEAPP:callMethod('UIDialog','setupDialog', '', '您报名的比赛场即将开赛吗,是否立即前往？',
            function() 
                  G_BASEAPP:removeView('UIDialog')  
                  G_BASEAPP:callMethod('UIGameTable','quitTable')
                  G_BASEAPP:addView('UIAwards',999)
                  if G_BASEAPP:getView('UIGameTableMenu') then 
                     G_BASEAPP:removeView('UIGameTableMenu')  
                  end   
            end)   
        elseif  G_BASEAPP:getView('UIGameTableClassic')  then    
            G_BASEAPP:addView('UIDialog', 99999)
            G_BASEAPP:callMethod('UIDialog','setupDialog', '', '您报名的比赛场即将开赛,是否立即前往？',
            function() 
                  G_BASEAPP:removeView('UIDialog') 
                  G_BASEAPP:callMethod('UIGameTableClassic','quitTable')
                  G_BASEAPP:addView('UIAwards',999)
                  if G_BASEAPP:getView('UIGameTableMenu') then 
                     G_BASEAPP:removeView('UIGameTableMenu')  
                  end 
            end)  
        elseif G_BASEAPP:getView('UIGameTableWanren') or G_BASEAPP:getView('UIGameTablePaodekuai')  
               or G_BASEAPP:getView('UIGameTableSanzhang')   or G_BASEAPP:getView('UIGameTableDouniu') then 
            G_BASEAPP:addView('UIDialog', 99999)
            G_BASEAPP:callMethod('UIDialog','setupDialog', '', '您报名的比赛场即将开赛，请尽快入场',
            function() 
                G_BASEAPP:removeView('UIDialog') 
            end)  
        elseif not G_BASEAPP:getView('UIGameTableMatch') and not  G_BASEAPP:getView('UIAwards')   then 
            G_BASEAPP:addView('UIDialog', 99999,1)
            G_BASEAPP:callMethod('UIDialog','setupDialog', '', '您报名的比赛场即将开赛,是否立即前往？',
            function() 
                 G_BASEAPP:removeView('UIDialog') 
                 if G_BASEAPP:getView('UIShop') then 
                     G_BASEAPP:callMethod('UIShop','onClose')                      
                 end    
                 G_BASEAPP:addView('UIAwards',999)
            end)  
        end
    end   
end     
--55 54 牌局数统计
function UIMain:proccessCMD_GAME_COUNT(data) 
   if data.info and #data.info > 0 then 
      local temp = json.decode(data.info)
      dump(temp,'牌局数统计')
      if  temp.SiteId and temp.WinCount and temp.ChipType then 
          self.pData.gameRedPackets[tostring(temp.SiteId)][tonumber(temp.ChipType)+1] = temp.WinCount
      end   
      if G_BASEAPP:getView('UIGameTable') then 
                 G_BASEAPP:callMethod('UIGameTable','updateRedPackets')
      elseif  G_BASEAPP:getView('UIGameTableClassic')  then 
         G_BASEAPP:callMethod('UIGameTableClassic','updateRedPackets')
      end   
   end  
end 


--[[ ------------------- END SOCKET HALL RESPONSE FUNCTIONS -------------------- ]]--



function UIMain:getLoginBuffer(tableType,friendID,RoomId) 
     local bufferHnd = DataPacker.new(self.pData.ROOM_LOGIN,{protocalVersion = 3})
     bufferHnd:writeData(self.pData.uid,DataPacker.INT)
     bufferHnd:writeData(self.pData.token,DataPacker.STRING)
     bufferHnd:writeData(tableType,DataPacker.INT) 
     bufferHnd:writeData(friendID,DataPacker.INT)
     bufferHnd:writeData(RoomId,DataPacker.INT)
     bufferHnd:writeData(0,DataPacker.BYTE)
     return bufferHnd:doPack()
 end

function UIMain:killAllSchedulers()
    
--    printf('00000000000000000000000000000000')
--    printf('UIMain:killAllSchedulers')
--    printf('00000000000000000000000000000000')
    self:stopSchedule('checkNetwork')
    self:stopSchedule('ReloginAttempt')
    self:stopSchedule('checkTcpConnection')
    self:stopSchedule('heartbeat')
    self:stopSchedule('preTimeWait')
    self:stopSchedule('reqTcpCon')
    self:stopSchedule('whatthe')
    self:stopSchedule('delayMusic')  
end
  
  

function UIMain:updatePlayerInfos()
    self.mainTop:updatePlayerInfos()
end

function UIMain:updateVipStatus()
    self.mainTop:updateVipStatus()
end

function UIMain:loadAvatar()
    self.mainTop:loadAvatar()
end


function UIMain:updateHead(iconPath)
    self.mainTop:updateHead(iconPath)
end

function UIMain:swithImageBg(img)
    print("Load img: "..img)
    if not img then return end 
    self['Image_bg']:loadTexture(img, ccui.TextureResType.localType)
end

--根据已选择的游戏类型加载游戏场次的数据
--@params: 1.游戏类型信息（可在Config.lua 查询） 2.成功获取对应的场次数去回到   3.没有获取到该游戏的场次数据回调
function UIMain:loadGameRoomsInfos(_dataGame, _onSucc, _onFail)
    dump(_dataGame,"Game Data")
    local dataName = _dataGame.dataName

    --拷贝数据（可避免）
    local function parseTableIntoArray(_table)
        local i = 1
        -- dump(_table,"所有场次配置信息")
        for k, v in pairs(_table.list) do
            local item = _table.list[tostring(i)]
            local subList = {}
            subList.name = item.name
            subList.base = item.base
            subList.port = item.port
            subList.max = item.max
            subList.siteid = item.siteid
            subList.roomid = item.room or 0
            subList.min = item.min
            subList.hot = item.hot
            subList.activity = item.activity
            subList.awardbox = item.awardbox
            table.insert(self.pData.GameTypes[dataName], subList)
            i = i + 1
        end
         dump(self.pData.GameTypes,'所有场次配置信息')
         UserCache.setCommonDataByKey(dataName, self.pData.GameTypes[dataName])
         if _onSucc then 
            _onSucc()
         end 
    end

    --向服务器请求游戏场次的数据
    local function requestRoomsData()
         local dataTable =     {
            ['uid']   = self.pData.uid,
            ['token']  = self.pData.token,
            ['type']   = _dataGame.requestServerKey,
            ['cmd']       = HttpHandler.CMDTABLE.MATCH_ROOMS,
        }
        local function succ(arg)    
            parseTableIntoArray(arg)
            UserCache.setCommonDataByKey('API_VER', self.pData.API_VER)  
        end
        local function fail(arg)
            if arg.msg then
                self.tool:showTips(arg.msg)
            end
            if _onFail then 
               _onFail()
            end    
        end
        self.tool:fastRequest(dataTable,succ, fail,true)
    end

   -- dump(self.pData.GameTypes[dataName])
   --先检测内存里是否已经拥有了场次数据
   if  self.pData.GameTypes[dataName] and  #self.pData.GameTypes[dataName] > 0 then
       dump(self.pData.GameTypes[dataName])
       if _onSucc then 
          _onSucc()
       end
       return
   else
       --内存里没有找到该游戏场次数据，测本地是否已经保存到了此数据
      local ver = UserCache.getCommonDataByKey('API_VER')
      if ver then print('Local VER: '..ver..' API_VER: '..self.pData.API_VER) end

       if ver == nil or (tonumber(ver) ~= self.pData.API_VER) then
           --执行到这里就说明在本地里该游戏场次数据不存在, 或者本地的API_VER 和当前登录获取的API_VER不一致
           --我们就需要执行所有场次的数据更新
            print('New Version of data, Request ['..dataName..'] data from server...')
            for k,game in pairs(self.config.keyDataGames) do
                UserCache.setCommonDataByKey(game.dataName,{})  --Erase all old datas
            end
            requestRoomsData()  --向服务器请求新的场次数据表
           return
       else
           --在本地里找到了对应的数据并且，API_VER没有变化。在本地里读取数据
           print('Read ['..dataName..'] data from file...')
           self.pData.GameTypes[dataName] = UserCache.getCommonDataByKey(dataName)
           if self.pData.GameTypes[dataName] and #self.pData.GameTypes[dataName] > 0 then
               _onSucc()
               return
           end
       end  
   end

    --再次检测一下数据是否已经保存到内存里，没有的话就执行请求
   if self.pData.GameTypes[dataName] == nil or #self.pData.GameTypes[dataName] == 0 then
       print('Request ['..dataName..'] data from server...')
       self.pData.GameTypes[dataName] = {}
       requestRoomsData()
   end
   dump(self.pData.GameTypes,'所有场次配置信息')
end

--[[加载指定项]]
function UIMain:loadTarget()
    self.mainBottom:loadTarget()
	self.mainTop:loadTarget()
end

--[[释放指定项]]
function UIMain:clearTarget()
    self.mainBottom:clearTarget()
    self.mainTop:clearTarget()
end

return UIMain
