local UIHelpGetChips= class("UIHelpGetChips", cc.load("mvc").ViewBase)
UIHelpGetChips.RESOURCE_FILENAME = "UIHelpGetChips.csb"
local HttpHandler = require("app.network.HttpHandler")

UIHelpGetChips.RESOURCE_BINDING = { 
}

--初始化获取金币
function UIHelpGetChips:onCreate()
    local app = self:getApp()
    self.app = app
    self.config = app:getData('Config')
    self.tool = app:getModel('Tools')
    self.pData = app:getData('PlayerData')
    self.account = app:getModel('Account')
	self:setSkipGoBack(true )
    self.pContentSel = self['Panel_3']
    self:initGetChipsView()
end

function UIHelpGetChips:getPanelMain()
    return self['Panel_main']
end

function UIHelpGetChips:transitionViewAction(_action)
   self:runAction(_action:clone())
end

function UIHelpGetChips:initGetChipsView()
    local function onInviteFriend(event)         --推荐好友
        if event.name == 'began' then
      
        elseif event.name == 'ended' then
            self.app:addView('UIFriendRecommend',self:getLocalZOrder()+1)
        end
    end
    local function onBuyCoins(event)      --购买金币
        if event.name == 'began' then
   
        elseif event.name == 'ended' then
            --调用购买金币接口
            self.app:addView('UIShop',self:getLocalZOrder()+1,1, 'help')
        end
    end
    local function onTaskReward(event)        --任务奖励
        if event.name == 'began' then
    
        elseif event.name == 'ended' then
            --调用任务接口
            self.app:addView('UITask',self:getLocalZOrder()+1)
        end
    end
    self.pContentSel:getChildByName('Button_inviteFriend'):onTouch(onInviteFriend)
    self.pContentSel:getChildByName('Button_buyCoins'):onTouch(onBuyCoins)
    self.pContentSel:getChildByName('Button_taskReward'):onTouch(onTaskReward)
	if G_CHANNELID == "vivo_02" or G_CHANNELID == "hyl_xm_02" or G_CHANNELID == "sl-oppo" then
		self.pContentSel:getChildByName('Button_inviteFriend'):setVisible(false)
	end
	
end

return UIHelpGetChips








