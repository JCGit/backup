local UIMatchPrivate = class("UIMatchPrivate", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
UIMatchPrivate.RESOURCE_FILENAME = "UIMatchPrivate.csb"
--UIMatchPrivate.RESOURCE_PRELOADING = {"main.png"}
--UIMatchPrivate.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIMatchPrivate.RESOURCE_BINDING = { 
    ["Button_back"]           = {["ended"]                  = "onBack"},    
    ["Button_CreateRoom"]           = {["ended"]            = "onCreateRoom"},
    ["Button_search"]           = {["ended"]            = "onSearchRoom"},
    ["Button_RefreshTables"]           = {["ended"]            = "onRefreshRooms"},
    ["Button_charge"]           = {["ended"]            = "onCharge"},
    ["Button_chooseGame"]           = {["ended"]            = "onChooseGame"},
}

local GAME_DDZ = "斗地主"
local GAME_DOUNIU = "斗牛"
local GAME_ZJH = "欢乐赢三张"

local GAMETYPE_DDZ = 7
local GAMETYPE_ZZH = 66

local MAX_PLAYER_DDZ = 3
local MAX_PLAYER_ZZH = 5

--根据游戏类型获取游戏最大玩家个数
function UIMatchPrivate:getMaxCountFromGameType(_gameType)
    if _gameType == GAMETYPE_DDZ then
        return MAX_PLAYER_DDZ
    elseif _gameType == GAMETYPE_ZZH then
        return MAX_PLAYER_ZZH
    end
end

--获取游戏场的标题图片
function UIMatchPrivate:getImageGameFromGameType(_gameType)
    if _gameType == GAMETYPE_DDZ then
        return "res_private/img_label_3.png"
    elseif _gameType == GAMETYPE_ZZH then
        return "res_private/img_label_5.png"
    end
end

--获取游戏类型标签
function UIMatchPrivate:getGameType(_gameName)
    if _gameName == GAME_DDZ then
        return GAMETYPE_DDZ
    elseif _gameName == GAME_ZJH then
        return GAMETYPE_ZZH
    elseif _gameName == GAME_DOUNIU then
        return 0
    end
end

--进入游戏房间
function UIMatchPrivate:enterRoom(_tableType, _tableId)
    local viewName = ""
    print("TableType: ".._tableType.. "   TableID: ".._tableId)
    if tonumber(_tableType) == GAMETYPE_DDZ then
        viewName = self.config.keyDataGames.ddz.viewName
    elseif tonumber(_tableType) == GAMETYPE_ZZH then
        viewName = self.config.keyDataGames.zjh.viewName
    end
    local port = self.pData:getGamePort(_tableType)

    if #viewName > 0 then
        -- local load = G_BASEAPP:addView("UILoading",self:getLocalZOrder() +1)  
        -- G_LOADINGVIEW = load
        -- load:setLoadingType(true)
        -- load:setNextAction(function()
        --     G_BASEAPP:addView(viewName,500,{
        --         tableType =  tonumber(_tableType),
        --         RoomId = tonumber(_tableId),
        --         port = port,
        --         })  
        -- end)
        -- load:startProgress()


        G_BASEAPP:addView(viewName,500,{
                tableType =  tonumber(_tableType),
                RoomId = tonumber(_tableId),
                port = port,
                })  
        self.app:callMethod('UIMain', 'showExitMainActions')
        self:removeSelf()
    else
        self.tool:showTips("暂时无法进入该游戏场")
    end
end

--初始化
function UIMatchPrivate:onCreate()
    local app = self:getApp()
    self.app = app
    self.tool = app:getModel('Tools')
    self.pData = app:getData('PlayerData')
    self.config = app:getData('Config')
    --self.sound = app:getModel('Sound')
    self.account = app:getModel('Account')
    self['Panel_Top']:setLocalZOrder(10)
    self.isCreateRoomInit = false
    self.isPanelViewInit = false
    
    LuaTools.viewAction2(self['Panel_main'], function()self:requestGetRoomsList() end, {"UIMain"})
    
    self['Button_chooseGame']:setTouchEnabled(self.pData.gameFilter.zjh == 1 )
    self['TextField_Search']:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    self['TextField_Search']:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    self.account:handleTxfControl(self['TextField_Search'],nil, 'num')
    
    self.listView = self['ListView_rooms']

    self.gameAvailables = {GAME_DDZ}

    self:initChooseGameView()

    self:initBackAction(self)
    --self:initRooms(self.listRooms)
end

--按返回键回调
function UIMatchPrivate:initBackAction(_target)
    _target:addGobackEventAction(function()
        LuaTools.playBtSound()
        self:onBack()
        local function loop()
            _target:addGobackEventAction(loop)
        end
        _target:addGobackEventAction(loop)
    end)
end

function UIMatchPrivate:getGameAvailables()
    return self.gameAvailables
end

--选择游戏类型
function UIMatchPrivate:initChooseGameView()
    local games = self.gameAvailables
    -- if self.pData.gameFilter.dnc > 0 then 
    --     --table.insert(games, GAME_DOUNIU)
    -- end
    if self.pData.gameFilter.zjh and  self.pData.gameFilter.zjh > 0 then 
        table.insert(games, GAME_ZJH)
    end

    self.indexGameSel = 1
    self.panelChoose = self['Panel_ChooseGame']
    self['Text_gameName']:setString(games[self.indexGameSel])

    local function onSelectGame(event)
        if event.name == 'ended' then
            local index = event.target:getTag()
            self.panelChoose:setVisible(false)
            self.indexGameSel = index
            self['Text_gameName']:setString(games[index])
            local gameType = self:getGameType(games[index])
            print("SEARCHING FOR GAME: "..games[index]..'...Game Type: '..gameType)
            self:onSearchRoomByGame(gameType)  --只显示对应的游戏房间
        end
    end
    
    local listView = self.panelChoose:getChildByName('ListView_amount')
    local defaultItem = self.panelChoose:getChildByName('Panel_amount')
    listView:setItemModel(defaultItem)
    local panel
    for key, var in ipairs(games) do
        listView:pushBackDefaultItem()
        panel = listView:getItem(key-1)
        panel:getChildByName('Text_amount'):setString(var)
        panel:onTouch(onSelectGame)
        panel:setTag(key)
        if key == #games then
            panel:getChildByName('Image_botborder'):setVisible(false)
        end
    end
    defaultItem:setVisible(false)
    self.panelChoose:setVisible(false)
end

--初始化房间UI
function UIMatchPrivate:initRooms(datas)
    dump(datas,'当前的房间列表数据')
    
    local function onEnterRoom(event)
        local index = event.target:getTag()
        if event.name == 'began' then
            self.isTryingDissmiss = false
            self.isEnterRoom = false
            --can only do scale to dismiss room if same uid
            
                event.target:runAction(cc.ScaleTo:create(0.1,1.1))
                self.scaleRoom = true
                if datas[index].roomId == tostring(self.pData.uid) then
                self:createSchedule('countDismiss', function()  
                    self.isTryingDissmiss = true
                    --if datas[index][5] ~= self.pData.uid then
                   --     self.tool:showTips("不能解散不属于自己的房间。")
                    --else
                        if self.isEnterRoom == true then return end
                        local function onOk()
                            self:requestDismissRoom(datas[index].roomId)
                        end
                        local dialog = self.app:addView('UIDialog', 202)
                        dialog:setupDialog( '', '您确定要解散该房间吗 ？',onOk)
                    --end
                    self:stopSchedule('countDismiss')
                end,1) 
                end
            
        end
        if event.name == 'moved' then
            if self.scaleRoom == true then
                event.target:runAction(cc.ScaleTo:create(0.1,1))
                self.scaleRoom = false
            end  
            self:stopSchedule('countDismiss')
        end
        if event.name == 'ended' then  
            if self.isTryingDissmiss == true then 
                self:stopSchedule('countDismiss') 
                return 
            end
            self.isEnterRoom = true
        	local index = event.target:getTag()
        	local roomId = datas[index].roomId
            event.target:runAction(cc.ScaleTo:create(0.1,1))
            print('ENTER ROOMID: '..roomId)

            if tonumber(self.pData.coin) < tonumber(datas[index].minCarry) then
                local function onConfirm()
                    if self.pData.gem > 0 then 
                        self:enterChargeDiamond()
                    else 
                        self:enterCharge() 
                    end  
                end
                local dlg = self.app:addView('UIDialog', self:getLocalZOrder() + 1, nil, true)
                dlg:setupDialog('金币不足', "您的金币不足进入私人场，是否去充值？", onConfirm, nil, false)
                return
            end
            
            if #datas[index].pwd > 0  and tostring(datas[index].roomId) ~= tostring(G_UID)  then
                self.app:addView('UIMatchPrivateSubviews', self:getLocalZOrder() + 20,{instance = self, stype = "pwd", index = index,  data = self.listRooms }) 
            else

                --进入房间
                self:enterRoom(datas[index].gameType, roomId) 
            end
            
        end
    end
    
    local defaultItem = self['Panel_Item']
    defaultItem:setBackGroundColorOpacity(0)
    defaultItem:setVisible(true)
    
    self.listView:setScrollBarEnabled(false)
    self.listView:removeAllChildren()
    self.listView:setItemModel(defaultItem)
    local item
    local countItem = math.ceil(#datas/3)
    local dataSize = #datas
    local countData = 0
    
    for i = 1, countItem do
        self.listView:pushBackDefaultItem()
        local childCount = self.listView:getChildrenCount()
        item = self.listView:getItem(childCount-1)
        
        for j = 1, 3 do
            countData = countData + 1
            local panel = item:getChildByName('Panel_table_'..j)
            panel:setTag(countData)
            panel:setTouchEnabled(true)
            panel:onTouch(onEnterRoom)
            --panel:setAnchorPoint(cc.p(0.5,0.5))
            if countData > dataSize then
                panel:setVisible(false)
            else
                panel:setVisible(true)
                panel:getChildByName('Text_name'):setString(datas[countData].name)
                panel:getChildByName('Text_count'):setString(datas[countData].count..'/'..self:getMaxCountFromGameType(datas[countData].gameType))
                panel:getChildByName('Text_blinds'):setString(datas[countData].blind)
                panel:getChildByName('Text_minCoins'):setString(self.tool:convertAmountChinese(datas[countData].minCarry))
                panel:getChildByName('Text_roomID'):setString('ID:'..datas[countData].roomId)
                panel:getChildByName('Image_game'):loadTexture(self:getImageGameFromGameType(datas[countData].gameType) ,ccui.TextureResType.plistType)
                if #datas[countData].pwd > 0 then
                	else
                    panel:getChildByName('Image_lock'):setVisible(false)
                end

            end 
        end

    end
    defaultItem:setVisible(false)
end

--进入充值砖石
function UIMatchPrivate:enterChargeDiamond()
    G_BASEAPP:addView('UIQuickBuy', 1200) 
end



function UIMatchPrivate:enterCharge() 
    if not G_BASEAPP:getView('UIShopDiamond') then 
        G_BASEAPP:addView('UIShopDiamond', 1200) 
    end   
end 

--点击创建房间按钮
function UIMatchPrivate:onCreateRoom()
    
    self.app:addView('UIMatchPrivateSubviews', self:getLocalZOrder() + 20, {instance = self, stype = "create"}) 
end

--点击搜索房间按钮
function UIMatchPrivate:onSearchRoom()
    local enterId = self['TextField_Search']:getString()
    for key, var in ipairs( self.listRooms ) do
        if var.roomId == enterId then
            self:initRooms({var})
    		return
    	end
    end
    self.tool:showTips("没有搜索到该房间。。。")
end

--根据游戏类型搜索房间
function UIMatchPrivate:onSearchRoomByGame(_gameType)
    --dump(self.listRooms)
    local tableRooms = {}
    for key, var in ipairs( self.listRooms ) do
        if tonumber(var.gameType) == _gameType then
            table.insert(tableRooms, var)
        end
    end
    self:initRooms(tableRooms)
end

--刷新房间
function UIMatchPrivate:onRefreshRooms()
    -- self:initRooms(self.listRooms)
    self:requestGetRoomsList()
end

--点击充值按钮
function UIMatchPrivate:onCharge()
    self.app:addView('UIShop',self:getLocalZOrder() + 1,1)  
end

--返回
function UIMatchPrivate:onBack(event) 
    LuaTools.viewAction2Over(self['Panel_main'],'UIMatchPrivate',nil, {"UIMain"})
end

--点击选择游戏按钮
function UIMatchPrivate:onChooseGame()
    self.panelChoose:setVisible(not self.panelChoose:isVisible())
    if self.panelChoose:isVisible() == true then
        self['Button_chooseGame']:loadTextureNormal('res_private/img_down.png', ccui.TextureResType.plistType)
        self['Button_chooseGame']:loadTexturePressed('res_private/img_down.png', ccui.TextureResType.plistType)
    else
        self['Button_chooseGame']:loadTextureNormal('res_private/img_up.png', ccui.TextureResType.plistType)
        self['Button_chooseGame']:loadTexturePressed('res_private/img_up.png', ccui.TextureResType.plistType)
    end
end

--拷贝数据（可以不用这种方法）
function UIMatchPrivate:parseList(list)
    self.listRooms = {}
    for k,v in pairs(list.room) do
        print(k)
        local subList = {}
        subList.name = v.name
        subList.roomId = v.rid
        subList.count = v.number
        subList.gameType = tonumber(v.gameType)
        subList.blind = v.bpour
        subList.pwd = v.pw
        subList.minCarry = v.carry
        self.listRooms[k] = subList
    end
    self:initRooms(self.listRooms)
end

--请求私人房房间列表
function UIMatchPrivate:requestGetRoomsList()
    local dataTable =     {
        ['uid']   = self.pData.uid,
        ['token']  = self.pData.token,
        ['page']      = 1,
        ['unionid']   = self.config.unionID,
        ['cmd']       = HttpHandler.CMDTABLE.PRIVATE_GETLIST,
    }
    local function succ(arg)
        self:parseList(arg)
    end
    local function fail(arg)
        if arg.msg then
            self.tool:showTips(arg.msg)
        end
        self:removeSelf()
    end
    self.tool:fastRequest(dataTable,succ, fail)
end

--删除自己创建的房间
function UIMatchPrivate:requestDismissRoom(_roomId)
    local dataTable =     {
        ['uid']   = self.pData.uid,
        ['token']  = self.pData.token,
        ['rid']      = _roomId,
        ['cmd']       = HttpHandler.CMDTABLE.PRIVATE_DELETE,
    }
    local function succ(arg)    
        self.app:removeView('UIDialog')
        self:requestGetRoomsList()
    end
    local function fail(arg)
        if arg.msg then
            self.tool:showTips(arg.msg)
        end
        self:onBack()
    end
    self.tool:fastRequest(dataTable,succ, fail)
end


return UIMatchPrivate 
