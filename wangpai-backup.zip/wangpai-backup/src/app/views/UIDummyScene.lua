local UIDummyScene = class("UIDummyScene", cc.load("mvc").ViewBase)
UIDummyScene.RESOURCE_FILENAME = "UIDummyScene.csb"




    
  

    



function UIDummyScene:onCreate() 
-- LOOK INTO LuaTools.bindBackCallback(obj,app) , THIS IS NOW DEPRECATED!!
 --    local app = self:getApp()
 --    self.app  = app
 --    self.tool = app:getModel('Tools') 
 --    -- dump(self.tool,"self.tool")

 --        -- 维尼到此一游，这个事实验性的android back按键和场景之间的管理，其他人别碰
 --        -- 还存在些BUG，正在调试。
 --    print('UIDummyScene:onCreate() ')
	-- if true then --experimental manage views with android back button system.
 --        local function onKeyReleased(keyCode, event) 
 --            print("keyCode："..keyCode)
 --            printf("keyCode:%s,app:%s,app.lastAddedView:%s,size:%s",keyCode,app,app.lastAddedView,app.lastAddedView:getSize())
 --            -- app.lastAddedView:dump()
 --            app.lastAddedView:iterator( function(k,v)
 --                printf("k:%s,v:%s,(%s)",k,v,v:getName())
 --            end )
 --            local lastView = app.lastAddedView:getItemAt(app.lastAddedView:getSize())
 --            if lastView.isLockGoback == true then
 --                printf("%s is locked.",lastView.name_)
 --                return
 --            end
 --        	local lastViewQueue =  lastView:getApp():getGoBackActionQueue()
 --        	if lastViewQueue and lastViewQueue:getSize() > 0 then 

 --                lastViewQueue:dump()
 --                print('lastViewQueue and lastViewQueue:getSize() > 0 ')
 --        	    lastViewQueue:pop()()
 --                return
 --        	elseif app.lastAddedView:getSize() > 0 then
 --                print('app.lastAddedView:getSize() > 2 ')
 --        	    -- if keyCode == cc.KeyCode.KEY_BACK or keyCode == 7 then 
 --        	        local view = app.lastAddedView:pop()
 --        	        while view:getSkipGoBack() do 
 --        	           printf("View #########=>>>>[%s]<<<<=###### should be removed by now.",view:getName())
 --        	           view:removeSelf()
 --        	           view = app.lastAddedView:pop()
 --        	        end
 --        	        printf("View #########=>>>>[%s]<<<<=###### should be removed by now.",view:getName())
 --        	        view:removeSelf() 
 --                return
 --        	    -- end
 --        	else  
 --                printf("LAST VIEW!")
 --        	    G_BASEAPP:addView('UIDialog', 65530)
 --        	    G_BASEAPP:callMethod('UIDialog','setupDialog', '退出游戏', '是否确定退出游戏？', 
 --        	    function() 
 --        	        cc.Director:getInstance():endToLua()
 --        	    end) 
 --                return
 --        	end
 --    	end 

 --        local listener = cc.EventListenerKeyboard:create()
 --        listener:registerScriptHandler(onKeyReleased, cc.Handler.EVENT_KEYBOARD_RELEASED ) 
 --        local eventDispatcher = self:getEventDispatcher()
 --        eventDispatcher:addEventListenerWithSceneGraphPriority(listener, self)

	-- end
end

return UIDummyScene