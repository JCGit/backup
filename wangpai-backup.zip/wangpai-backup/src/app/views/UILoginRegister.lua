local UILoginRegister = class("UILoginRegister", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
--printWarning

UILoginRegister.RESOURCE_FILENAME = "UILoginRegister.csb"
--UILoginRegister.RESOURCE_PRELOADING = {"main.png"}
--UILoginRegister.RESOURCE_LOADING  = {["res/background/login_bg.png"] = {names = {"Image_bg"}} }

UILoginRegister.RESOURCE_BINDING = {
    ["Button_cancel"]  = {["ended"] = "remView"},
    ["Button_confirm"] = {["ended"] = "confirm"},
    ["Button_question"]  = {["ended"] = "onOpenListQuestion"},
}

function  UILoginRegister:remView()
    
    self.app:removeView('UILoginRegister')
end


function UILoginRegister:confirm() 
    
    local account =  self['TextField_account']:getString()
    local newPwd    =  self['TextField_psw']:getString()
    local confPwd    =  self['TextField_conPsw']:getString()
    -- local answer = self['TextField_answer']:getString()
    -- local area = self['TextField_homeTown']:getString()
    
    --检测账号长度是否合格
    if #account< self.account.accMinLen or #account > self.account.accMaxLen then
        self.tool:showTips(self.account.accLenght)
        return
    end
    --检测账号内容是否合格
    if false == self.account:strContainOnlyNumAndChar(account) then
        self.tool:showTips(self.account.accError)
        return
    end
    --检测密码长度是否合格
    if #newPwd< self.account.pwdMinLen or #newPwd > self.account.pwdMaxLen then
        self.tool:showTips(self.account.pwdLenght)
        return
    end
    --检测密码内容是否合格
    if false == self.account:strContainOnlyNumAndChar(newPwd) then
        self.tool:showTips(self.account.pwdError)
        return
    end
    --检测两次输入的密码是否一致
    if newPwd ~= confPwd then
        self.tool:showTips(self.account.pwdNotMatched)
        return
    end
    -- if self.indexQuestSel == 0 then
    --     self.tool:showTips('请选择一个密保问题')
    --     return
    -- end

    local deviceInfos = LuaTools.getAllInfomationYouNeeded()
    
    local dataTable =     {
        ['account']  = account,
        ['password'] = newPwd,
        ['pv']       = '4',
        ['unionid']   = self.config.unionID,
        ['imsi']      = deviceInfos.imsi,
        ['imei']      = deviceInfos.imei,
        ['mac']       = deviceInfos.mac,
        ['type']      = 'reg',
        ['pmodel']    = deviceInfos.model,
        ['did']       = UserCache.csDID,
        ['cmd']      = HttpHandler.CMDTABLE.REGISTER,

    }
    local function succ(arg)
        UserCache.setCommonDataByKey("account", account)
        UserCache.setCommonDataByKey("password", newPwd)
        self.tool:showAlert(arg.msg)

        local function cb() 
            self.app:callMethod('UILogin','autoLogin')
            self.app:callMethod('UILogin','updateAccountInfos',account, newPwd)
            self.app:removeView('UILoginRegister')
        end
        self:runAction(cc.Sequence:create(cc.DelayTime:create(1.5), cc.CallFunc:create(function() cb()  end),nil))
    end
    
    local function fail(arg)
        if arg.msg then
        	self.tool:showTips(arg.msg)
        end
    end
    self.tool:fastRequest(dataTable,succ, fail)
end

function UILoginRegister:onCreate()
    local app = self:getApp()
    self.app = app
    self.tool = app:getModel('Tools') 
    self.account = app:getModel('Account')
    self.config = app:getData('Config')
    self.pdata = app:getData('PlayerData')

    self:initTextField(self['TextField_account'])
    self:initTextField(self['TextField_psw'])
    self:initTextField(self['TextField_conPsw'])

    self.account:handleTxfControl(self['TextField_account'],{"@"})
    self.account:handleTxfControl(self['TextField_psw'])
    self.account:handleTxfControl(self['TextField_conPsw'])
    
    self:setTextfieldPwdControl(self['Image_eye1'], self['TextField_psw'])
    self:setTextfieldPwdControl(self['Image_eye2'], self['TextField_conPsw'])
end

function UILoginRegister:initTextField(_txf)
    _txf:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    _txf:setTextColor(self.config.Txf_textColorLogin)
end

function UILoginRegister:setTextfieldPwdControl(widget, textf)
    local isShowPwd = false
    local function onEyeSwitchState(event)
        if event.name == 'ended' then
            if isShowPwd then
                event.target:setColor(self.config.ColorEyeOpen)
            else
                event.target:setColor(self.config.ColorEyeClose)
            end
            textf:setPasswordEnabled(isShowPwd)
            textf:setString(textf:getString())
            isShowPwd = not isShowPwd
        end
    end
    widget:setColor(self.config.ColorEyeOpen)
    widget:onTouch(onEyeSwitchState)
    widget:setTouchEnabled(true)
end
return UILoginRegister
