local UIRankWaiting = class("UIRankWaiting", cc.load("mvc").ViewBase)
UIRankWaiting.RESOURCE_FILENAME = "UIRankWaiting.csb"
UIRankWaiting.RESOURCE_BINDING = {

}

--UIWaiting.RESOURCE_FILENAME = "UIWaiting.csb"

function UIRankWaiting:onCreate()

    local function callback_()
         G_BASEAPP:removeView('UIRankWaiting')
    end   
    self['Image_rotation']:runAction(cc.RepeatForever:create(cc.RotateBy:create(1, 360)))
    self['Panel_loading']:runAction(cc.Sequence:create(cc.DelayTime:create(2),
                                                        cc.CallFunc:create(callback_)
                                                        ))
end


return UIRankWaiting  
