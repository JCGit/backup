 
local UIGameTable = require('app.views.UIGameTable')
local scheduler = require("app.models.QScheduler")
UIGameTable.RESOURCE_FILENAME = "UIGameTablePaodekuai.csb"
local UIGameTablePaodekuai = clone(UIGameTable)

-- scheduler.performWithDelayGlobal(function()  
-- 	local UIGameTable = require('app.views.UIGameTable') 
-- 	UIGameTable.RESOURCE_FILENAME = "UIGameTable.csb"
-- end,1)
return UIGameTablePaodekuai
