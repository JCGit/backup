local UIChatOnline = class("UIChatOnline", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
UIChatOnline.RESOURCE_FILENAME = "UIOnline.csb"
--UIActivity.RESOURCE_PRELOADING = {"main.png"}
--UIActivity.RESOURCE_LOADING  = { ["res/background/mohuBg.png"] = {names = {"Image_bgAll"}} }

UIChatOnline.RESOURCE_BINDING = { 
    ["Button_close"]  = {["ended"] = "closeNow"},
    --["ListView_Activities"]     = {["ON_SELECTED_ITEM_END"] = "selectEvent"},   
        ["Button_sendchat"]       = {["ended"] = "sendChat"},

    }


function UIChatOnline:closeNow()
   -- self.app:removeView('UIChatOnline')
    LuaTools.viewAction1Over(self['Panel_main'],"UIChatOnline",nil)
end    


function UIChatOnline:sendChat()
  
  if #self['TextField_chat_kf']:getString() <= 0 then 
       self.app:addView('UIAlert',1000)
           :setupDialog('Infomation',"聊天内容不能为空")
    return 
  end
  self:sendMsg(self['TextField_chat_kf']:getString())

  -- local function callback()
  --       local tbl = {
  --         msg = '已经收到您的反馈，我们将在1个工作日内为您解答，请您耐心等待，不便之处敬请见谅，祝您游戏愉快！',
  --         date = os.date("%Y-%m-%d %H:%M"),
  --         who = 'cs'
  --       } 
  --       self:appendCell(tbl)
  -- end   
  -- self['ListView_cs']:runAction(cc.Sequence:create(cc.DelayTime:create(2),cc.CallFunc:create(callback)))
end

function UIChatOnline:sendMsg( str )
  local tbl = {
    msg = str,
    date = os.date("%Y-%m-%d %H:%M"),
    who = 'me'
  } 
  -- self.app:callMethod('UIMain','reqSock_SEND_MSG_FRIEND','10000',str)

  self:appendCell(tbl)
  self['TextField_chat_kf']:setString('')

  if not UserCache.csHistory[tostring(self.playerdata.uid)] then 
     UserCache.csHistory[tostring(self.playerdata.uid)] = {} 
  end  
  table.insert(UserCache.csHistory[tostring(self.playerdata.uid)],tbl) 
  UserCache.writeCSHistory() 
  self.app:callMethod('UIMain','reqSock_sendMsgService',str)  
end

function UIChatOnline:onCreate()
    
    local app = self:getApp()
    self.app = app
    self.config = app:getData('Config')
    self.tool  = app:getModel('Tools')
    self.playerdata = self.app:getData('PlayerData')
    self.config = app:getData('Config')
    self.tool = app:getModel('Tools')

    local tags = false 
     if G_BASEAPP:getView('UIMainTop') then 
         tags =  G_BASEAPP:getView('UIMainTop'):getChatDotStatus()
     end 

    UserCache.readCSHistory()  
    self['TextField_chat_kf']:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    LuaTools.enterActionScaledWithMask(self['Panel_main'],function()     
       self:initChatList(tags) 
       if G_BASEAPP:getView('UIMainTop') then 
         G_BASEAPP:callMethod('UIMainTop','showOrHideChatDot',false)
       end 
    end)

end     

function UIChatOnline:appendCell( infoTable )
   local cell = nil
   if infoTable.who == "me" then
      cell = self['Panel_model2']:clone() 
      local spr
      local oldAvatar = UserCache.getUserDataByKey('icon')
      if oldAvatar and #oldAvatar > 0 then
          spr = cc.Sprite:create(oldAvatar)
      else
          spr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[self.playerdata.sex+1])
      end 
      LuaTools.makeSpriteRounded(spr, cell:getChildByName('Image_head'), self.config.maskSprite, true)
   else 
      cell = self['Panel_model']:clone()  
   end
      cell:setVisible(true)
      local msg = infoTable.msg or " "
      msg = LuaTools.splitStringByNumber(msg,21)
      local heightDiff = cell:getChildByName('Text_chat'):getContentSize().height
      cell:getChildByName('Text_chat'):setString(msg)
      heightDiff = cell:getChildByName('Text_chat'):getContentSize().height - heightDiff  
      cell:setContentSize(cell:getContentSize().width,cell:getContentSize().height+heightDiff)
      
      cell:getChildByName('Text_time'):setString(infoTable.date) 
      self['ListView_cs']:pushBackCustomItem(cell)
      
      cell:getChildByName('Text_time'):setPositionY(cell:getChildByName('Text_time'):getPositionY()+ heightDiff)
      cell:getChildByName('Image_sbg'):setPositionY(cell:getChildByName('Image_sbg'):getPositionY()+ heightDiff)

      cell:getChildByName('Image_bg'):setPositionY(cell:getChildByName('Image_bg'):getPositionY()+ heightDiff)
      cell:getChildByName('Text_chat'):setPositionY(cell:getChildByName('Text_chat'):getPositionY()+ heightDiff-8)

      local chatBGheight = cell:getChildByName('Image_bg'):getContentSize().height+heightDiff
      local chatBGWidth = cell:getChildByName('Image_bg'):getContentSize().width
      
      if cell:getChildByName('Image_bg'):getContentSize().width < cell:getChildByName('Text_chat'):getContentSize().width+40 then
        chatBGWidth = cell:getChildByName('Text_chat'):getContentSize().width +50
      end

      cell:getChildByName('Image_bg'):setContentSize(chatBGWidth,chatBGheight)
      if infoTable.who == "me" then
         cell:getChildByName('Text_chat'):setPositionX(cell:getChildByName('Image_bg'):getPositionX() - chatBGWidth + 20)
      end

      self:createSchedule('updateCount', function()  

      self["ListView_cs"]:scrollToBottom(0.5, true) 
        self:stopSchedule('updateCount')
      end,0.1)
end


function UIChatOnline:initChatList(tags) 
   if  UserCache.csHistory[tostring(self.playerdata.uid)] and  #UserCache.csHistory[tostring(self.playerdata.uid)] > 0  then 
       for i=1,#UserCache.csHistory[tostring(self.playerdata.uid)] do
           self:appendCell(UserCache.csHistory[tostring(self.playerdata.uid)][i])
       end 
   end     
   if not tags then 
      local tbl = {
      msg = '您好,请问有什么可以帮到您?(如遇紧急情况,联系客服QQ:2851656976)',
      date = os.date("%Y-%m-%d %H:%M"),
      who = 'cs'} 
      self:appendCell(tbl)
      UserCache.saidHelloToUser = true
   end 
end

return UIChatOnline
