local UIRegistration= class("UIRegistration", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
UIRegistration.RESOURCE_FILENAME = "UIRegistration.csb"
--UIRegistration.RESOURCE_PRELOADING = {"lottery.png"}


UIRegistration.RESOURCE_BINDING = {
    ["Button_close"]     = {["ended"] = "backEvent"},
    ["Button_getReward"] = {["ended"] = "getNormalReward"},
    ['Button_getVip']    = {["ended"] = "getVipReward"},
    ["PageView_bg"]   = { ["SCROLLING"] = "callbacks" }, 
    }
UIRegistration.bt_LotteryNode = nil
function UIRegistration:getNormalReward(event)
    
    self:onGetReward('s') 
    
    local parent = self['Panel_six']:getChildByName('Panel_0'..self.condays)
    parent:getChildByName('Image_ok'):setVisible(true)
    parent:getChildByName('Image_hide'):setVisible(true)
    parent:getChildByName('Image_ok'):setScale(3)
    parent:getChildByName('Image_ok'):runAction(cc.ScaleTo:create(0.2,1))
    parent:getChildByName('Image_ok'):setLocalZOrder(10)

	--if UIRegistration.bt_LotteryNode ~= nil then
		--UIRegistration.bt_LotteryNode:removeFromParent()
		--UIRegistration.bt_LotteryNode = nil
	--end
    local bt_LotteryNode = cc.CSLoader:createNode('Animation_reward_bomb.csb') 
    bt_LotteryNode:setPosition(cc.p(parent:getContentSize().width/2,parent:getContentSize().height/2))
    local action = cc.CSLoader:createTimeline('Animation_reward_bomb.csb')
    bt_LotteryNode:runAction(action)
    action:gotoFrameAndPlay(0,false)
    parent:addChild(bt_LotteryNode,9)

    audio.playSound(Sound.SoundTable['sfx']['Register_P'] , false)
end 

function UIRegistration:getVipReward(event)
     local str = self['Button_getVip']:getTitleText()
     if str == '领取' then 
        self:onGetReward('v')
        audio.playSound(Sound.SoundTable['sfx']['Box_Shake'] , false)

		--if UIRegistration.bt_LotteryNode ~= nil then
			--UIRegistration.bt_LotteryNode:removeFromParent()
			--UIRegistration.bt_LotteryNode = nil
		--end
        local bt_LotteryNode = cc.CSLoader:createNode('Animation_vip_gift.csb') 
        bt_LotteryNode:setPosition(cc.p(self['Panel_rightAct3']:getContentSize().width/2,self['Panel_rightAct3']:getContentSize().height/2))

        local action = cc.CSLoader:createTimeline('Animation_vip_gift.csb')
        local function cb1() 
            local child = self['Panel_VipModel']:clone()
            audio.playSound(Sound.SoundTable['sfx']['Box_Show'] , false)

            child:setVisible(true)
            child:getChildByName('Text_money'):setString('金币x'..self['Text_vipMoney']:getString())
            self['Panel_rightAct3']:addChild(child,1000)
            child:setName('vipModelCoin')
            child:setPosition(cc.p(self['Panel_rightAct3']:getContentSize().width/2,self['Panel_rightAct3']:getContentSize().height/2))
        end     
        local function cb2()
             bt_LotteryNode:removeFromParent()
			 bt_LotteryNode = nil
             self['Panel_rightAct3']:removeChildByName('vipModelCoin')
        end  
        bt_LotteryNode:runAction(action)
        action:gotoFrameAndPlay(0,false)
        
        self['Panel_rightAct3']:addChild(bt_LotteryNode,1) 
        self['Panel_rightAct3']:runAction(cc.Sequence:create(cc.DelayTime:create(1),cc.CallFunc:create(cb1),
            cc.DelayTime:create(1),cc.CallFunc:create(cb2)))

        self['Button_getVip']:setTitleText('明天再来')
     elseif  str == '成为VIP' then 
        local app = self.app 
        G_BASEAPP:addView('UIShop',112,3,'profile')
        G_BASEAPP:removeView('UIRegistration') 
     elseif  str == '明天再来'  then 
        G_BASEAPP:removeView('UIRegistration') 
     end    
end     

function UIRegistration:onCreate(_cb,info)
    local app  = self:getApp()
    self.app   = app
    self['Panel_layer_all']:setVisible(false)
    self.tool  = app:getModel('Tools')
    self.pData = self.app:getData('PlayerData')
    self.config = app:getData('Config')
    self.cb = _cb
	
    self.isAutoShow = (_cb == nil and true) or false -- 判断是否自动关闭界面
	-- self.isNetworkNormal = false --网络数据是否正常拿下来
	-- self.isNetworklink = true --网络连接中
	
	--if UIRegistration.bt_LotteryNode ~= nil then
		--UIRegistration.bt_LotteryNode:removeFromParent()
		--UIRegistration.bt_LotteryNode = nil
	--end
		
    local bt_LotteryNode = cc.CSLoader:createNode('Animation_reward_light.csb') 
    bt_LotteryNode:setPosition(cc.p(self['Image_vipImg']:getContentSize().width/3,self['Image_vipImg']:getContentSize().height/6))
    local action = cc.CSLoader:createTimeline('Animation_reward_light.csb')
    bt_LotteryNode:runAction(action)
    action:gotoFrameAndPlay(0,true)
    self['Image_vipImg']:addChild(bt_LotteryNode,1)
	
    self['Panel_rightAct1']:setVisible(true)
    self['ListView_announced1']:setItemModel(self['Panel_modAnn'])
    self['ListView_6']:setScrollBarEnabled(false)
    self['ListView_announced1']:setScrollBarEnabled(false)
    self['ListView_point']:setScrollBarEnabled(false)
    self.poster = nil
    self.pointTag = 1 
    self.lastSelected = 1 

    self.nowVipRewardStatus = info.vip   or  1 
    self.nowNorRewardStatus = info.regular or 1
    self:updateRedDot()
    self.isReqLoginReward  = false  --是否请求过登陆奖励

    for key=1,4 do 
         local function switchPage(event)
             if event.name == 'ended' then 
				self:switchBut(self.lastSelected,key)
             end  
         end 
         self['Button_leftBut'..key]:onTouch(switchPage)
         self['Button_leftBut'..key]:setPressedActionEnabled(false)
    end     
    self.noticeAnn = 0 

	self['Panel_layer_all']:setVisible(true)
	LuaTools.enterActionScaledWithMask(self['Panel_layer_all'],function()   self:onGetAdsImage()   end )


end

function UIRegistration:reqLoginReward()
        local dataTable =     {
        ['uid']       = self.pData.uid,
        ['token']     = self.pData.token,
        ['cmd']       = HttpHandler.CMDTABLE.SIGN_REWARD,
        }
        local function succ(arg)
            dump(arg,'请求登录奖励成功')
            self.isReqLoginReward  = true
            -- self.isNetworkNormal = true
            -- self.isNetworklink = false
            local getTime = os.date("%x", os.time())
            arg['getTime'] = getTime
            arg['uid'] = self.pData.uid
            -- UserCache.setRegistration(arg)
           self.pData.vip_reward = arg.vip['award'].coin or 0
           self.pData.vipSigned = arg.vip['status'] or 0   

           self['Button_getVip']:setTitleText( tonumber(self.pData.vipvalid) == 0 and '成为VIP' or (arg.vip.status == 0 and '领取' or '明天再来'))
           self['Text_vipMoney']:setString('恭喜您获得'..LuaTools.convertAmountChinese(arg.vip.award.coin)..'金币')
           self.vipMoneyGet = arg.vip.award.coin
            if tonumber(arg.signdays) < 1 then  
               self.pData.isFirstLoginGame = 1  
               self.pData.isfirstLoginShow = 1 
               if self.pData.playGuidingMusic == false  then 
                  audio.playMusic(Sound.SoundTable['sfx']['LoadingGame'],false)
                  self.pData.playGuidingMusic = true 
               end    
               local function a1()
                 audio.playMusic(Sound.SoundTable['bgm']['MusicEx_Doudizhu'] , true)   
               end 
                self:runAction(cc.Sequence:create(cc.DelayTime:create(8),cc.CallFunc:create(a1))) 
            else
                audio.playMusic(Sound.SoundTable['bgm']['MusicEx_Doudizhu'] , true)   
            end   
            
            if (arg.signStatus and  self.nowNorRewardStatus == 0) 
               or self.cb 
               or (arg.preDays and arg.preDays.status ==0 ) or (arg.vip.status == 0 and tonumber(self.pData.vipvalid) > 0) then  
               
               self['Panel_layer_all']:setVisible(true)
               self.allData = arg
               self['Panel_more']:setVisible(tonumber(self.allData.theday)> 6)
               self['Panel_six']:setVisible(tonumber(self.allData.theday) <= 6)           
               self.tag = (tonumber(self.allData.theday) <= 6 and 1 or 2 )
               self.condays = self.allData.theday
                self.image_Reward = {}
                self.initButton = {1,2,3,4,5,6}
                self:initUI()
            end 
        end
        local function fail(arg)
            -- self.isNetworkNormal = false
            -- self.isNetworklink = false
            app:removeView('UIRegistration')
            --LuaTools.showAlert("网络连接失败") 
        end
        self.tool:fastRequest(dataTable,succ, fail,false)
end     



function UIRegistration:switchBut(from,to)
   if (not to or from == to ) then  return  end 
   local butTab1 = 'res_reward/btn_new2.png'
   local butTab2 = 'res_reward/btn_new1.png'
   if from then  
     self['Button_leftBut'..from]:loadTextures(butTab1,butTab1,butTab1,ccui.TextureResType.plistType)
     self['Panel_rightAct'..from]:setVisible(false)
   end 
   self['Panel_rightAct'..to]:setVisible(true)
   self['Button_leftBut'..to]:loadTextures(butTab2,butTab2,butTab2,ccui.TextureResType.plistType) 
   self.lastSelected = to 
   if (to ==2 or to== 3) and self.isReqLoginReward == false then 
      self:reqLoginReward()
   end  

   if to == 4 then 
        self:reqAnnouced()
   end  
end  

function UIRegistration:rotateCardS(par,image,num,abc)
    local temp = 'res_reward/new3.png'
    local function callback2()
        par:loadTextures(temp,temp,temp,ccui.TextureResType.plistType)
        par:getChildByName('Text_numReward'):setString(num)
        local a = ccui.ImageView:create(image,ccui.TextureResType.plistType)
        par:addChild(a)
        local size = par:getContentSize()
        a:setPosition(size.width/2,size.height*0.55)
        a:setLocalZOrder(9)
    end
    audio.playSound(Sound.SoundTable['sfx']['Register_N'] , false)
    local orbit1 = cc.OrbitCamera:create(0.3,1, 0, 0, -90, 0, 0)
    local move = cc.OrbitCamera:create(0.75,1, 0, 0, 0, 0, 0)
    if not abc then 
       par:runAction(cc.Sequence:create(orbit1,cc.CallFunc:create(callback2),move))
    else  
        local function cb()
            local image3 = ccui.ImageView:create('res_reward/lingqu.png',ccui.TextureResType.plistType)
            par:addChild(image3,10)

            image3:setPosition(par:getContentSize().width/2,par:getContentSize().height*0.5)
            image3:setScale(3)
            image3:runAction(cc.ScaleTo:create(0.2,1))

            local image1 = ccui.ImageView:create('res_reward/img_bg.png',ccui.TextureResType.plistType)
            par:addChild(image1,9)
            image1:setScale(1.1)
            image1:setPosition(par:getContentSize().width/2,par:getContentSize().height*0.5)
			--if UIRegistration.bt_LotteryNode ~= nil then
				--UIRegistration.bt_LotteryNode:removeFromParent()
				--UIRegistration.bt_LotteryNode = nil
			--end
            local bt_LotteryNode = cc.CSLoader:createNode('Animation_reward_bomb.csb') 
            bt_LotteryNode:setPosition(cc.p(par:getContentSize().width/2,par:getContentSize().height/2))
            local action = cc.CSLoader:createTimeline('Animation_reward_bomb.csb')
            bt_LotteryNode:runAction(action)
            action:gotoFrameAndPlay(0,false)
            par:addChild(bt_LotteryNode,9)
        end 
        par:runAction(cc.Sequence:create(orbit1,cc.CallFunc:create(callback2),cc.Spawn:create(move,cc.CallFunc:create(cb))))
    end   
end 

function UIRegistration:addRewardModel(par,info)
    local types = (info.coin==0 and 2 or (info.telfee == 0  and 1  or 3 ))
     
    local image_tab = {'res_reward/1.png','res_reward/2.png','res_reward/3.png'}
    local model = self['Panel_model_type'..types]:clone()
    model:setVisible(true)
    local temp  = par:getChildByName('Panel_add')
    par:getChildByName('Image_ok'):setVisible(false)
    if types == 1 then  
        model:getChildByName('Text_coin'):setString('金币x'..info.coin) 
    elseif types == 2 then  
        model:getChildByName('Text_fee'):setString('话费券x'..info.telfee)     
    else      
        model:getChildByName('Text_coin'):setString('金币x'..info.coin) 
        model:getChildByName('Text_fee'):setString('话费券x'..info.telfee)     
    end 
    par:getChildByName('Image_30'):loadTexture(image_tab[types],ccui.TextureResType.plistType)
    temp:addChild(model) 
    local size = temp:getContentSize() 
    model:setPosition(size.width/2,size.height/2)     
end 


function UIRegistration:initUI()  
    self['Panel_six']:setVisible(self.tag  == 1)
    self['Panel_more']:setVisible(self.tag  == 2)
    if self.tag  == 1 then  
        for k, v in ipairs(self.allData.preDays.award) do
            local panel = self['Panel_six']:getChildByName('Panel_0'..k)
            self:addRewardModel(panel,{coin=v.coin,telfee=v.telfee})
        end
        self['Panel_six']:getChildByName('Panel_0'..self.condays):getChildByName('Image_di'):loadTexture('res_reward/card.png',ccui.TextureResType.plistType)
        if self.condays ~= 1 then 
            for k=1 ,self.condays-1 do 
                self['Panel_six']:getChildByName('Panel_0'..k):getChildByName('Image_ok'):setVisible(true)
                self['Panel_six']:getChildByName('Panel_0'..k):getChildByName('Image_hide'):setVisible(true)
            end     
        end 

        --local temp = self['Panel_six']:getChildByName('Panel_0'..self.condays)
        --self.particleLight:setVisible(true)
        --self.particleLight:setPosition(cc.p(temp:getPosition()))
        if self.allData.preDays.status == 1 then 
           self['Panel_six']:getChildByName('Panel_0'..self.condays):getChildByName('Image_ok'):setVisible(true)
           self['Panel_six']:getChildByName('Panel_0'..self.condays):getChildByName('Image_hide'):setVisible(true)
           self['Button_getReward']:setTouchEnabled(false)
           self['Button_getReward']:setBright(false)
           --self['Button_getReward']:setColor(cc.c3b(55,55,55))
        end   

    else 
		
        self.rIndexLength = #self.allData.random['rIndexs'] 
		
        for key = 1 ,6 do 
            self['Button_card_'..key]:setPressedActionEnabled(false)
            local temp = {}
            if self.allData.random['award'][key].coin  then 
               temp.image = 'res_reward/1.png' 
               temp.num = '金币x'..self.allData.random['award'][key].coin
            elseif  self.allData.random['award'][key]['prop']  then 
                if self.allData.random['award'][key]['prop']['4']  then  
                    temp.image =  'res_reward/tirenka.png' 
                    temp.num = '踢人卡x'..self.allData.random['award'][key]['prop']['4']
                elseif self.allData.random['award'][key]['prop']['7']  then  
                    temp.image =  'res_reward/laba.png' 
                    temp.num = '喇叭x'..self.allData.random['award'][key]['prop']['7']
                end     
            end 
            
            table.insert(self.image_Reward,temp)    
        end             
		
        if  self.rIndexLength  and self.rIndexLength~= 2 then 
            for key = 1, 6 do 
                local function turnCard(event)
                    if event.name == 'ended' then 
                        self.rIndexLength = self.rIndexLength + 1 
                        if  self.rIndexLength <= 2 then                             
                            self['Button_card_'..key]:setTouchEnabled(false)
                            self:clearButtonTab(key)
                            self:onGetReward('s',key-1)
                            self:rotateCardS(self['Button_card_'..key],self.image_Reward[key].image,self.image_Reward[key].num,true)
                            if self.rIndexLength == 2 then         
                                local function callback()
                                    self:showAllCard()
                                end     
                                self['Panel_more']:runAction(cc.Sequence:create(cc.DelayTime:create(0.8),cc.CallFunc:create(callback)))
                            end
                        end     
                    end 
                end 
                self['Button_card_'..key]:onTouch(turnCard)                
            end    
            if self.rIndexLength == 1 then 
                local v= self.allData.random['rIndexs'][1]
                self:clearButtonTab(v+1)
                self['Button_card_'..v+1]:setTouchEnabled(false)
                local image = ccui.ImageView:create('res_reward/lingqu.png',ccui.TextureResType.plistType)
                self['Button_card_'..v+1]:addChild(image,10)
                local size = self['Button_card_'..v+1]:getContentSize()
                image:setPosition(size.width/2,size.height*0.5)

                self['Button_card_'..v+1]:getChildByName('Text_numReward'):setString(self.image_Reward[v+1].num)
                local a = ccui.ImageView:create(self.image_Reward[v+1].image,ccui.TextureResType.plistType)
                self['Button_card_'..v+1]:addChild(a)
                a:setPosition(size.width/2,size.height*0.55)
                a:setLocalZOrder(9)

                local image1 = ccui.ImageView:create('res_reward/img_bg.png',ccui.TextureResType.plistType)
                image1:setScale(1.1)
                self['Button_card_'..v+1]:addChild(image1,9)
                image1:setPosition(size.width/2,size.height*0.5)

                local temp = 'res_reward/new3.png'
                self['Button_card_'..v+1]:loadTextures(temp,temp,temp,ccui.TextureResType.plistType)
            end     
        else 
            for key =1 ,6 do 
                local switch_img =  'res_reward/new3.png'
                self['Button_card_'..key]:setTouchEnabled(false)
                self['Button_card_'..key]:loadTextures(switch_img,switch_img,switch_img,ccui.TextureResType.plistType)
                local a = ccui.ImageView:create(self.image_Reward[key].image,ccui.TextureResType.plistType)
                self['Button_card_'..key]:addChild(a)
                local size = self['Button_card_'..key]:getContentSize()
                self['Button_card_'..key]:getChildByName('Text_numReward'):setString(self.image_Reward[key].num)
                a:setPosition(size.width/2,size.height*0.55) 
                a:setLocalZOrder(9)  
            end     
            if self.allData.random['rIndexs']  and #self.allData.random['rIndexs'] >0 then 
                for k,v in pairs(self.allData.random['rIndexs']) do 
                    local image = ccui.ImageView:create('res_reward/lingqu.png',ccui.TextureResType.plistType)
                    self['Button_card_'..v+1]:addChild(image,10)
                    local size = self['Button_card_'..v+1]:getContentSize()
                    image:setPosition(size.width/2,size.height*0.5)


                    local image1 = ccui.ImageView:create('res_reward/img_bg.png',ccui.TextureResType.plistType)
                    image1:setScale(1.1)
                    self['Button_card_'..v+1]:addChild(image1,9)
                    image1:setPosition(size.width/2,size.height*0.5)
                end   
            end       
        end 

        -- if self.allData.status == 1 then 
        --    self:showAllCard()
        -- end   
         -------------------------------
    end
end

function UIRegistration:clearButtonTab(tag)
    for key,var in pairs(self.initButton) do 
        if var == tag then 
            table.remove(self.initButton,key)
            break
        end     
    end     
end     

function UIRegistration:showAllCard()
    for key = 1,6 do 
        self['Button_card_'..key]:setTouchEnabled(false)
    end     
    
    for k,v in pairs(self.initButton) do 
        self:rotateCardS(self['Button_card_'..v],self.image_Reward[v].image,self.image_Reward[v].num)
    end     
end 

function UIRegistration:backEvent(event)
    if self.cb then self.cb() end 
    LuaTools.viewAction1Over(self['Panel_layer_all'],"UIRegistration")
end

function UIRegistration:onGetReward(kind,index)
    if not index then index = 0 end 
    ------------------------------------
    local app = self.app 
    local dataTable =     {
        ['uid']       = self.pData.uid,
        ['token']     = self.pData.token,
        ['type']      = kind, 
        ['rindex']    = index, 
        ['cmd']       = HttpHandler.CMDTABLE.GET_SIGN_REWARD,
        }
        local function succ(arg)    
            -- print('领取签到奖励成功')
            if not self then return end 
			local getTime = os.date("%x", os.time())
			arg['getTime'] = getTime
			arg['uid'] = self.pData.uid
			-- UserCache.setRegistration(arg)
            if  kind == 'v' then 
                self.pData.vipSigned = 1
                self.nowVipRewardStatus = 1 
                self.pData.signStadus.vip  = 1 
                local function cb123()
                    self['Image_vipBgLog']:setVisible(true)
                    local move = cc.MoveBy:create(2,cc.p(0,125))
                    local function cs() 
                      self['Image_vipBgLog']:setVisible(false)
                    end     
                    self['Image_vipBgLog']:runAction(cc.Sequence:create(move,cc.CallFunc:create(cs)))
                end
                self['Image_vipImg']:runAction(cc.Sequence:create(cc.DelayTime:create(1.5),cc.CallFunc:create(cb123)))
            end      
            self.pData.coin = arg.coin 
            self.pData.telfee = arg.telfee
            if kind == 's' then 
                self['Button_getReward']:setTouchEnabled(false)
                self['Button_getReward']:setBright(false)    
                self.nowNorRewardStatus = 1      
                self.pData.signStadus.regular = 1    
            end 
            if app:getView('UIMainTop') then 
                app:callMethod('UIMainTop','updateWealth' ) 
            end  
            self:updateRedDot()
        end
        local function fail(arg)
        end
    self.tool:fastRequest(dataTable,succ, fail,false)
end


function UIRegistration:updateRedDot()
    self['Button_leftBut3']:getChildByName('Image_dot'):setVisible(self.nowVipRewardStatus  and  
    self.nowVipRewardStatus == 0  and tonumber(self.pData.vipvalid) > 0 )
    self['Button_leftBut2']:getChildByName('Image_dot'):setVisible(self.nowNorRewardStatus  and  self.nowNorRewardStatus == 0 )
end     

function UIRegistration:onGetAdsImage()
    local paTable ={
    ['uid']   = tonumber(self.pData.uid),
    ['unionid'] = G_CHANNELID,
    ['cmd']   = HttpHandler.CMDTABLE.ACTIVITY_ANNOUNCEMENT,
    ['type']  = 1
            } 
    self.img = {}
    self.activeJumpTo = {}
    self.allHadDownload = false
    self.downloadIndex = 0
    self['Panel_join']:setVisible(true)
    self['Panel_rightAct1']:getChildByName('Image_circle'):runAction(cc.RepeatForever:create(cc.RotateBy:create(1, 360)))
    self['PageView_bg']:setVisible(false)
    local function succ(arg)
        -- dump(arg,'广告请求')
        for i = 1,#arg.announcement do
            local argTable = {
                url = arg.announcement[i].poster,
                destFile = nil,
                onFinishTable = function(status,downloadedSize,dst)
                    if status == 'success' then
                        if not self.img  or (not self.activeJumpTo) then return end 
                        table.insert(self.img,dst)
                        table.insert(self.activeJumpTo,arg.announcement[i].jumpto)
                        self.downloadIndex = self.downloadIndex + 1
                        if self.downloadIndex >= #arg.announcement then
                            self.allHadDownload = true
                        end 
                    else
                        print('下载背景图片失败!')
                    end
                end
            }
            LuaTools.getFileFromUrl(argTable)
        end
        local function cbs() 
            if  self.allHadDownload and (#self.img > 0) then
                self:updateActiveBg()
                self['PageView_bg']:setVisible(true)
                self['Panel_join']:setVisible(false)
                self:stopSchedule('adsAdd')
                self['Panel_rightAct1']:getChildByName('Image_circle'):stopAllActions() 
                self['Panel_rightAct1']:getChildByName('Image_circle'):setVisible(false)
                self['Panel_rightAct1']:getChildByName('Text_3'):setVisible(false)
            end
        end
        if self then 
           self:createSchedule('adsAdd',cbs,1)
        end 
    end
    local function fail(arg) 
       -- dump(arg,'广告请求失败') 
    end     
    self.tool:fastRequest(paTable,succ,fail) 
end


--加载活动背景图
function UIRegistration:updateActiveBg()
        if  #self.img >0 then
            self['PageView_bg']:removeAllPages()
            for i=1,#self.img do 
                local tempPanel = self['Panel_modeImages']:clone()
                tempPanel:setBackGroundImage(self.img[i],ccui.TextureResType.localType)
                tempPanel:setVisible(true)
                tempPanel:setName("P_"..tostring(i))
                self['PageView_bg']:addPage(tempPanel)
            end
            --红点
            if #self.img>1 and #self.img <7 then 
                self['ListView_point']:setVisible(true) 
                for k=7,(#self.img+1),-1 do 
                    self['ListView_point']:getChildByName('Image_point'..k):setVisible(false)
                end     
                self['ListView_point']:getChildByName('Image_point1'):setColor(cc.c3b(0,255,0))
            end     
        end
end

--翻滚页面后的回调
function UIRegistration:callbacks(args)
    if #self.img >1 then
        -- self["Button_jion"]:setVisible(false)
        local action = cc.Sequence:create(
               cc.DelayTime:create(0.3),
               cc.CallFunc:create(
               function() 
                    local num = self['PageView_bg']:getCurrentPageIndex()
                    if( num+1 ~= self.pointTag ) then
                        self['ListView_point']:getChildByName('Image_point'..(num+1)):setColor(cc.c3b(0,255,0))  
                        self['ListView_point']:getChildByName('Image_point'..self.pointTag):setColor(cc.c3b(255,255,255))
                        self.pointTag = num+1
                        -- self["Button_jion"]:setVisible(not (self.activeJumpTo[num+1]==""))
                    end
              end))
         self:runAction(action)
    else
      print("不用翻页")
    end
end


--请求公告
function UIRegistration:reqAnnouced() 
    if self.noticeAnn == 0 then 
        local paTable ={
         ['uid']   = tonumber(self.pData.uid),
         ['unionid'] = G_CHANNELID,
         ['cmd']   = HttpHandler.CMDTABLE.ACTIVITY_ANNOUNCEMENT,
         ['type']  = 0
                    } 
        local function succ(arg) 
              dump(arg,'当前的公告')
              if  #arg.announcement > 0 then
                  local count = 0 
                  self.noticeAnn = arg.announcement
                  self['ListView_announced1']:removeAllChildren() 
                  for k,v in pairs(arg.announcement) do
                      self['ListView_announced1']:pushBackDefaultItem()     
                      local contentMode  = self['ListView_announced1']:getItem(count)
                      contentMode:setVisible(true)
                      local size = contentMode:getContentSize()
                      contentMode:getChildByName('Text_titles'):setString(v.title)
                      local function showMore()
                          if self['Panel_detailsAnn']:isVisible() then 
                              self['Panel_detailsAnn']:setVisible(false)
                              local posY1 = k == 1 and  0 or -(8+size.height)*(k-1)
                              local move = cc.MoveBy:create(0.2,cc.p(0,posY1) )
                              self['ListView_announced1']:runAction(cc.Sequence:create(cc.DelayTime:create(0.2),move))
                          else   
                              local function cb1() 
                                 self['Panel_detailsAnn']:setVisible(true)
                              end   
                              local posY1 = k == 1 and  0 or (size.height+8)*(k-1)
                              self:updateAnnounced(v.content)
                              local  move = cc.MoveBy:create(0.2,cc.p(0,posY1) )
                              self['ListView_announced1']:runAction(cc.Sequence:create(move,cc.DelayTime:create(0.2),
                                cc.CallFunc:create(cb1)))
                          end  
                          LuaTools.freezeWidget(contentMode:getChildByName('Button_getDitailsAnn'), 0.6)      
                      end
                      contentMode:getChildByName('Button_getDitailsAnn'):onTouch(showMore)
                      count = count + 1 
                  end
              end  
        end
        local function fails(arg)
           dump(arg,'请求公告失败')
           self['ListView_announced1']:setVisible(false)
           self['Text_noAnnounced']:setVisible(true)
        end   
        self.tool:fastRequest(paTable,succ,fails) 
    end 
end    

function UIRegistration:updateAnnounced(info)
    self['ListView_6']:removeAllChildren()
    local text =  ccui.Text:create()
    local posx,posy = self['Panel_detailsAnn']:getChildByName('Text_neirong'):getPosition()
    text:setFontSize(24)
    text:setString(info) 
    val1 = text:getVirtualRendererSize().width
    local b = math.floor(val1/(self['Panel_detailsAnn']:getContentSize().width-60))+1 
    local textArea = ccui.Text:create()
    textArea:ignoreContentAdaptWithSize(false)
    textArea:setContentSize(cc.size(self['Panel_detailsAnn']:getContentSize().width-60, b*24+400))
    textArea:setAnchorPoint(0,1) 
    textArea:setFontSize(24)
    textArea:setPosition(cc.p(posx,posy))
    textArea:setString(info) 
    textArea:setColor(cc.c3b(150,69,32))
    textArea:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_LEFT)
    textArea:setTextVerticalAlignment(cc.VERTICAL_TEXT_ALIGNMENT_TOP)
    textArea:setName('newTextNow')
    self['ListView_6']:addChild(textArea)
end  

return UIRegistration