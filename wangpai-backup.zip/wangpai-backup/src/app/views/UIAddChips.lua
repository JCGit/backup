local UIAddChips = class("UIAddChips", cc.load("mvc").ViewBase)
UIAddChips.RESOURCE_FILENAME = "UIAddChips.csb"
--UIAddChips.RESOURCE_PRELOADING = {"hall.png"}

UIAddChips.RESOURCE_BINDING = {
    ["Button_close"]      = {["ended"] = "backEvent"},
    ["Button_buy"]        = {["ended"] = "buyChip"},
    
    ["Slider_chip"]       = {["ON_PERCENTAGE_CHANGED"] = "addChipsSlider"}, 

    }

function UIAddChips:backEvent(event) 
    self.app:removeView("UIAddChips")
end

function UIAddChips:buyChip(event) 
    local app = self.app
    local str = self['Text_addChip']:getString()
    local least = self['TextField_least']:getString() 


    local temp = self['CheckBox_remember']:isSelected() and 1 or 0
    G_BASEAPP:callMethod('UIGameTableDeZhou','reqSock_AUTO_BUY',temp,least,str) 
    G_BASEAPP:callMethod('UIGameTableDeZhou','reqSock_SIT_DOWN',str)  
    G_BASEAPP:callMethod('UIGameTableDeZhou','reqSock_BUY_CHIP',str)
    G_BASEAPP:removeView('UIAddChips')

    if self['CheckBox_remember']:isSelected()  then 
        UserCache.setUserDataByKey(self.type, least.."_"..str)      
    else
        UserCache.setUserDataByKey(self.type, '')                
    end     

end

function UIAddChips:addChipsSlider(event)
    local percent = event.target:getPercent()
    local num = (self.max-self.min)/100*percent+self.min
    self['Image_move']:setPosition(self["Slider_chip"]:getContentSize().width*percent/100,self['Image_move']:getPositionY())  
    self['Text_addChip']:setString(math.floor(num))
    self['Text_most']:setString(math.floor(num))
    local least = self['TextField_least']:getString() 
    if math.floor(num)<= tonumber(least) then 
       self['TextField_least']:setString(math.floor(num))
    end    
end

function UIAddChips:changci(type)
       local temp = {'primary9','middle9','senior9','primary6','middle6','senior6'}
       local last  
       if type >= 71 and type <=76 then 
          last =temp[1] 
       elseif type >= 77 and type<=82 then 
          last   = temp[2]
       elseif type >= 83 and type<= 88 then 
          last  = temp[3]
       elseif type >= 89 and type<= 94 then 
          last  = temp[4]
       elseif type >= 95 and type<= 100 then 
          last  = temp[5]
       else   --if type >= 101 and type<= 106 then 
          last  = temp[6]   
       end     
       return last
end    


function UIAddChips:onCreate(min,max,less,type)
    self.type= self:changci(type)
    local app = self:getApp()
    self.app = app
    self.PlayerData =app:getData('PlayerData')
    self.main = app:getModel('Tools')
    local str,info

    self["Button_close"]:setPressedActionEnabled(false)
    --self["Button_buy"]:setPressedActionEnabled(false)
    self['Text_minCoin']:setString(min)
    self['Text_maxCoin']:setString(max)
    self.min = min 
    self.max = max 

    self['Image_move']:setAnchorPoint(cc.p(0.5,0.5))
    local sx, sy = self.app:getModel('Tools'):getUIScale()
         
    self.width = self["Panel_model"]:getContentSize().width * sx
    self['Text_total']:setString(self.PlayerData.coin)
    str  =  UserCache.getUserDataByKey(self.type)
    
    if str and  str ~= '' then 
        info =  self.main:getStringTab(str)
        self['CheckBox_remember']:setSelected(true) 
        self['TextField_least']:setString(info[1]) 
        self['Text_addChip']:setString(info[2])
        self['Text_most']:setString(info[2])
        self["Slider_chip"]:setPercent(tonumber(info[2])/max*100) 
    else 
        self["Slider_chip"]:setPercent(50) 
        self['Text_addChip']:setString(self.max/2)
        self['Text_most']:setString(self.max/2)
        self['TextField_least']:setString(less) 
        self['CheckBox_remember']:setSelected(false) 
    end 
    
    local function onEditSign(event)
        if event.name == 'ATTACH_WITH_IME' then      -- attach IME

        elseif event.name == 'DETACH_WITH_IME' then  -- detach IME
--            local text = tonumber(self['TextField_least']:getString())
--            local most = tonumber(self['Text_most']:getString())     
--            if not text then text = 0 end       
--            if text>most then 
--               self['TextField_least']:setString(most) 
--            end    
        elseif event.name == 'INSERT_TEXT' then  -- insert text          
   
        elseif event.name == 'DELETE_BACKWARD' then  -- delete text
            local text = tonumber(self['TextField_least']:getString())
            local most = tonumber(self['Text_most']:getString())          
            if text > most then 
                self['TextField_least']:setString(most)           
            elseif text <less then 
                self['TextField_least']:setString(less)
            end  
        end
    end
    self['TextField_least']:onEvent(onEditSign)
end

return UIAddChips

