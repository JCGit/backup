local UIFriendThanks = class("UIFriendThanks", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
UIFriendThanks.RESOURCE_FILENAME = "UIFriendThanks.csb"
--UIFriendThanks.RESOURCE_PRELOADING = {"main.png"}
--UIFriendThanks.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIFriendThanks.RESOURCE_BINDING = { 

    ["Button_Close"] = {["ended"] = "close"},
    ["Button_confirm"] = {["ended"] = "onOk"},

    }

function UIFriendThanks:onCreate()
    local app = self:getApp()
    self.app = app
    self.tool = app:getModel('Tools')
    self.pData = app:getData('PlayerData')
    LuaTools.viewAction1(self['Panel_main'])
    self.config = app:getData('Config')
    self['TextField_text']:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
end

function UIFriendThanks:close()
    -- body
    -- self:removeSelf()
    
    LuaTools.viewAction1Over(self['Panel_main'],"UIFriendThanks")
end

function UIFriendThanks:onOk()  
     
    local text = self['TextField_text']:getString()
    if #text > 0 then
        self.tool:showTips('请输入答谢码')
        return
    end
    local deviceInfos = LuaTools.getAllInfomationYouNeeded()

    local function onSucc(arg)
        self.tool:showTips(arg.msg)
    end
    local dataTable =     {
        ['uid']   = self.pData.uid,
        ['token']  = self.pData.token,
        ['imei']      = deviceInfos.imei,
        ['imsi']      = deviceInfos.imsi,
        ['mac']      = deviceInfos.mac,
        ['unionid']   = self.config.unionID,
        ['code']    = text,
        ['cmd']       = HttpHandler.CMDTABLE.THANKSFRIEND,
    }
    self.tool:fastRequest(dataTable, onSucc)
end


return UIFriendThanks
