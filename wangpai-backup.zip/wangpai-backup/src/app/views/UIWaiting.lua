local UIWaiting = class("UIWaiting", cc.load("mvc").ViewBase)
UIWaiting.RESOURCE_FILENAME = "UIWaiting.csb"
UIWaiting.RESOURCE_BINDING = {

        ["Button_back"]  = {["ended"] = "backEvent"}, 
        ["Panel_main"]  = {["ended"] = "hideNow"} ,

}

--UIWaiting.RESOURCE_FILENAME = "UIWaiting.csb"
function UIWaiting:hideNow()
    G_BASEAPP:removeView('UIWaiting')
end  


function UIWaiting:onCreate(networkFailureMode,str,time,immMode)
--    local layer = display.newLayer():addTo(self)
--    self:setResourceNode(layer)
--    local image = ccui.ImageView:create("icon/waiting.png")
--    local winSize = self:getApp():getWinSize()
--    image:setPosition(cc.pMul(cc.pFromSize(winSize),0.5)):addTo(layer) 
    local function recruFunc()  
         G_BASEAPP:removeView('UIWaiting')
    end
    self:addGobackEventAction(function()
        recruFunc() 
    end)
	
    local act1 = cc.RotateBy:create(0.5,180)
    local delay = 3
    if immMode == true then 
      delay = 0 
    end
	
	if ISINITTIP then
		ISINITTIP = false
		self['Image_rotation']:setVisible(false)
		self['Image_1']:setVisible(false)
		self['Panel_1']:setVisible(false)
		self['Button_back']:setTitleText("退出游戏")
	else
		self['Button_back']:setTitleText("重新登录")
	end
	
    local function callback_()
		self['Panel_main']:setVisible(true)
		self['Image_rotation']:runAction(cc.RepeatForever:create(cc.RotateBy:create(1, 360)))
    self['Panel_main']:setTouchEnabled(true)
 
    end   
    self['Panel_main']:runAction(cc.Sequence:create(cc.DelayTime:create(delay),
                                                        cc.CallFunc:create(callback_)
                                                  ))
	
	
    if networkFailureMode == true then
    	self['Text_show']:setString(str)
    	time = time or 3
    	str = str or '当前网络状态不稳定，正尝试重连中' 

    	self['Text_show']:setString(str)
    	local count = 1 
    	local function countTime() 
    	    count = count+ 1 
    	    if count > time then 
    	       self:stopSchedule('counting')
    	       self['Button_back']:setVisible(true)
    	    end    
    	end 
    	self:createSchedule('counting',countTime,1)
	  else
  		-- if str == nil then
  		-- 	self['Text_show']:setString("网络连接中...")
  		-- end
    end
 
	  self:setLockGoback(true) 
end

function UIWaiting:backEvent(event)
  ISINITTIP = false
  if ISINIT and G_CHANNEL_CONFIG.isSdkLogin then
	cc.Director:getInstance():endToLua()
  else
	LuaTools.softMasterReset()
  end
  
   --   G_BASEAPP:removeView('UINetProblem') 
   --  dump(G_BASEAPP.views_)
   --  for _,v in pairs(G_BASEAPP.views_) do
   --    for k,vv in pairs(v) do 
   --       -- G_BASEAPP:removeView(k)   
   --       if k ~= "UIDummyScene" and tolua.isnull(vv) == false then
   --          G_BASEAPP:removeView(k) 
   --       end
   --     end 
   -- end 
   --  G_BASEAPP:enumerateScene(function(var)
   --   printf("enumerateScene:%s",var:getName())
   -- --    if var:getName() ~= "UIDummyScene" then
   -- --      -- self.app:removeView('UIFriend') 
   -- --      self.app:back() 
   -- --    end
   --   end) 
   --  G_BASEAPP:addView('UILogin',101,1)
end

return UIWaiting
