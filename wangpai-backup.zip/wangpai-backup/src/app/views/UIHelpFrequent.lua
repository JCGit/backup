local UIHelpFrequent= class("UIHelpFrequent", cc.load("mvc").ViewBase)
UIHelpFrequent.RESOURCE_FILENAME = "UIHelpFrequent.csb"
local HttpHandler = require("app.network.HttpHandler")

UIHelpFrequent.RESOURCE_BINDING = { 
}

--初始化常见问题
function UIHelpFrequent:onCreate()
    local app = self:getApp()
    self.app = app
    self.config = app:getData('Config')
    self.tool = app:getModel('Tools')
    self.pData = app:getData('PlayerData')
    self.account = app:getModel('Account')
    self:setSkipGoBack(true )
    self.pContentSel = self['Panel_1']
end

function UIHelpFrequent:getPanelMain()
    return self['Panel_main']
end

function UIHelpFrequent:transitionViewAction(_action)
   self:runAction(_action:clone())
end

return UIHelpFrequent








