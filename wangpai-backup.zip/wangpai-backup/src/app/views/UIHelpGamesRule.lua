local UIHelpGamesRule= class("UIHelpGamesRule", cc.load("mvc").ViewBase)
UIHelpGamesRule.RESOURCE_FILENAME = "UIHelpGamesRule.csb"
local HttpHandler = require("app.network.HttpHandler")

UIHelpGamesRule.RESOURCE_BINDING = { 
}

--初始化游戏规则
function UIHelpGamesRule:onCreate()
    local app = self:getApp()
    self.app = app
    self.config = app:getData('Config')
    self.tool = app:getModel('Tools')
    self.pData = app:getData('PlayerData')
    self.account = app:getModel('Account')
	self:setSkipGoBack(true )
    self.pContentSel = self['Panel_4']
    self:initAboutView()
    -- self['Panel_main']:setVisible(false)
end

function UIHelpGamesRule:getPanelMain()
    return self['Panel_main']
end

function UIHelpGamesRule:transitionViewAction(_action)
   self:runAction(_action:clone())
end

function UIHelpGamesRule:initAboutView()
    local btPanel = self.pContentSel:getChildByName('Panel_bt')
    local contentPanel = self.pContentSel:getChildByName('Panel_contents')
    local btIndexSelected = 0
    local function showBt(index)
        if index == btIndexSelected then return end
        if btIndexSelected > 0 then
            btPanel:getChildByName('Panel_bt_'..btIndexSelected):getChildByName('Image_select'):setVisible(false)
        end
        btPanel:getChildByName('Panel_bt_'..index):getChildByName('Image_select'):setVisible(true)
        btIndexSelected = index
    end

    local function showView(index)
        if index == btIndexSelected then return end
        local panelView = contentPanel:getChildByName('Panel_content_'..index):setVisible(true)
        if btIndexSelected > 0 then
            contentPanel:getChildByName('Panel_content_'..btIndexSelected):setVisible(false)
        end
    end

    local function onSwitchBt(event)
        if event.name == 'began' then
        elseif event.name == 'ended' then
            local tag = event.target:getTag()
            if tag == btIndexSelected then return end
            showView(tag)
            showBt(tag)
        end
    end
    
    for i = 1, 5 do
        local bt = btPanel:getChildByName("Panel_bt_"..i)
        bt:onTouch(onSwitchBt)
        bt:setTag(i)
        bt:getChildByName('Image_select'):setVisible(false)
        contentPanel:getChildByName('Panel_content_'..i):setVisible(false)
    end

    showView(1)
    showBt(1)


end

return UIHelpGamesRule








