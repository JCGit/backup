
local UIFriendWeddingCreate = class("UIFriendWeddingCreate", cc.load("mvc").ViewBase)
UIFriendWeddingCreate.RESOURCE_FILENAME = "UIFriendWeddingCreate.csb"
--UIFriendWeddingCreate.RESOURCE_PRELOADING = {"social.png"}
--UIFriendWeddingCreate.RESOURCE_LOADING  = {["res/background/mohuBg.png"] = {names = {"Image_bgAll"}}}
UIFriendWeddingCreate.RESOURCE_BINDING = {
    ["Button_back"] = {["ended"] = "backEvent"}, 
    ["Button_create"]  = {["ended"] = "createWeddingRoom"},
    ["Button_choosemode"]  = {["ended"] = "choosemode"}, 
    ['Button_model1']   = {["ended"] = "ButModel1"}, 
    ['Button_model2']   = {["ended"] = "ButModel2"}, 
    ['Button_model3']   = {["ended"] = "ButModel3"}, 
    ['Panel_main']   = {["ended"] = "touchSelect"}, 

    
}
local HttpHandler = require("app.network.HttpHandler")

function UIFriendWeddingCreate:choosemode() 
  
  self.Panel_selection:setVisible(true)
  local size = self.Panel_selection:getContentSize() 
  self.ListView_mode:runAction(cc.MoveBy:create(0.1,cc.p(0,-size.height)))
  self["Button_choosemode"]:setTouchEnabled(false)
end

function UIFriendWeddingCreate:touchSelect()
    self.Panel_selection:setVisible(false)
    self.ListView_mode:setPosition(self.posX,self.posY)
    self["Button_choosemode"]:setTouchEnabled(true)
end 

function UIFriendWeddingCreate:ButModel1()
  
   self.type = 99
   self:modelTouch(1) 
end 


function UIFriendWeddingCreate:ButModel2()
  
   self.type = 520
   self:modelTouch(2) 
end 

function UIFriendWeddingCreate:ButModel3()
  
   self.type = 1314
   self:modelTouch(3) 
end 

function UIFriendWeddingCreate:modelTouch(tag) 
    local temp = {'浪漫: 99元宝','豪华: 520元宝','至尊: 1314元宝'}
    self['Button_choosemode']:getChildByName('Text_Butkand'):setString(temp[tag])
    self.Panel_selection:setVisible(false)
    self.ListView_mode:setPosition(self.posX,self.posY)
    self["Button_choosemode"]:setTouchEnabled(true)
end 

function UIFriendWeddingCreate:createWeddingRoom() 
  
    local str = self['TextField_name']:getString() 
    if str == '' or #str == 0 then 
       self.app:addView('UIAlert',10000)
         :setupDialog('Infomation','房间名字不能为空')
         return 
    end       

    local paTable =     {
        ['uid']   = tonumber(self.pData.uid),
        ['token'] = G_TOKEN,
        ['name']  = str,
        ['level'] = self.type,
        ['pw']    = '',
        ['cmd']   = HttpHandler.CMDTABLE.CREATE_WED ,}  
    local function succ(arg) 
        G_BASEAPP:addView('UIFriendWeddingRoom',131,self.pData.uid,self.pData.nick)
    end     
    self.tool:fastRequest(paTable,succ)
end 

function UIFriendWeddingCreate:backEvent(arg)
    -- self.app:removeView('UIFriendWeddingCreate')
    
    LuaTools.viewAction1Over(self['Panel_main'],"UIFriendWeddingCreate")
end


function UIFriendWeddingCreate:onCreate()
    local app = self:getApp() 
    self.model = app:getModel("Social") 
    self.tool = app:getModel('Tools')
    self.app = app   
    self.pData = app:getData('PlayerData')
    LuaTools.viewAction1(self['Panel_main'])
    self['TextField_name']:setString(self.pData.nick..'的婚礼')
    self.posX,self.posY = self.ListView_mode:getPosition()
    self.type = 520

    self['TextField_name']:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
end


return UIFriendWeddingCreate

