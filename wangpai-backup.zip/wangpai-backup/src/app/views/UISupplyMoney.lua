local UISupplyMoney = class("UISupplyMoney", cc.load("mvc").ViewBase)
UISupplyMoney.RESOURCE_FILENAME = "UISupplyMoney.csb"
--UISupplyMoney.RESOURCE_PRELOADING = {"hall.png"}

UISupplyMoney.RESOURCE_BINDING = {
    ["Button_back"]      = {["ended"] = "backEvent"},
    --["Button_bankWithdraw"]       = {["ended"] = "onWithdraw"},

}
local HttpHandler = require("app.network.HttpHandler")

function UISupplyMoney:backEvent(event) 
    self.app:removeView("UISupplyMoney")
end



function UISupplyMoney:onCreate(callback)
 
    local app = self:getApp()
    self.app = app
    self.pData =app:getData('PlayerData')
    self.config = app:getData('Config')
    self.tool = app:getModel('Tools')
    self["Button_back"]:setPressedActionEnabled(false)

    self['Text_bankChips']:setString(self.tool:convertAmountChinese(self.pData.bank))


    self.callbacks = callback
    self.diffValue = 10000
    self.lastValidValue = 1
    self.txfVal = self['TextField_bankChooseVal']
    self.txfVal:setString(self.lastValidValue)
    local MAXNUMBER = 9999

    --增加+
    local function onAdd(event)
        if event.name == 'ended' then

            local num = tonumber(self.txfVal:getString())
            if num < MAXNUMBER then 
                self.lastValidValue = self.lastValidValue + 1
                self.txfVal:setString(self.lastValidValue)
                
            end 
        end
    end

    --减-
    local function onMinus(event)
        if event.name == 'ended' then
           local num = tonumber(self.txfVal:getString())
           if num > 1 then 
              self.lastValidValue = self.lastValidValue -1
              self.txfVal:setString(self.lastValidValue)
           end
        end
    end

    --手动输入数字
    local function onSetNumber(event)
        local str = tonumber(event.target:getString())
        if event.name == "ATTACH_WITH_IME" then
             event.target:setString("")
        elseif event.name == "DETACH_WITH_IME" then
            if event.target:getString() == "" or str == nil then
                self.lastValidValue = 1
                event.target:setString(self.lastValidValue)
            end
        elseif event.name == "INSERT_TEXT" then
           if str == nil then
                event.target:setString(self.lastValidValue)
            elseif str >= MAXNUMBER then 
                event.target:setString(MAXNUMBER)
                self.lastValidValue = MAXNUMBER
            else 
                event.target:setString(str)
                self.lastValidValue = str
            end
        elseif event.name == "DELETE_BACKWARD" then
            if event.target:getString() == "" then
                self.lastValidValue = 1
                event.target:setString(self.lastValidValue)
            else
                event.target:setString(str)
                self.lastValidValue = str
            end
        end
    end

    --取
    local function onWithdraw(event)
        if event.name == 'ended' then
            if self.txfVal:getString() == "" then return end
            local val = self.lastValidValue*self.diffValue
            if val > self.pData.bank then
                self.tool:showTips("金币数量大于保险箱的金币。取钱失败！")
                return
            else if self.lastValidValue == 0 then
                return
            end
            end
            if self.pData.isBankProtect == 1 and #self.pData.bankPwd == 0 then
                self.app:addView('UIProfileSubViews', self:getLocalZOrder() +1, 2, val)
            else
                self:requestWithdraw(val)
            end
        end
    end

    --初始化
    self['Button_bankPlus']:onTouch(onAdd)
    self['Button_bankMinus']:onTouch(onMinus)
    self['Button_bankWithdraw']:onTouch(onWithdraw)
    self.txfVal:onEvent(onSetNumber)
    self.txfVal:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    self.txfVal:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
end

function UISupplyMoney:requestWithdraw(sum)
    local function onSucc(arg)
        self.tool:showTips('取钱成功 ！')
        self.pData.coin = arg.coin
        self.pData.bank = arg.bank
        self:updateMoney()
        local temp = {} 
        temp.coin = sum
        if self.callbacks  then 
            self.callbacks(temp)
        end       
    end
    local function fail(arg)
        if arg.msg then
            self.tool:showAlert(arg.msg)
        end
    end
    local dataTable =     {
        ['uid']   = self.pData.uid,
        ['token']  = self.pData.token,
        ['money']      = sum,
        ['bankPwd']    = self.pData.bankPwd,
        ['cmd']       = HttpHandler.CMDTABLE.BANK_DRAWMONEY,
    }
    self.tool:fastRequest(dataTable, onSucc, fail)
end

--更新宝箱信息
function UISupplyMoney:updateMoney()
    self['Text_bankChips']:setString(self.tool:convertAmountChinese(self.pData.bank))
    self.app:callMethod('UIMainTop','updateWealth')
    self.lastValidValue = 1
    self.txfVal:setString(self.lastValidValue) 
end

return UISupplyMoney

