local UIGameTableResult = class("UIGameTableResult", cc.load("mvc").ViewBase)


local GameTableCommon = require("app.models.GameTableCommon") 
local scheduler = require("app.models.QScheduler") 
UIGameTableResult.RESOURCE_FILENAME = "UIGameTableResult.csb"
--UIGameTableResult.RESOURCE_PRELOADING = {"main.png"} 

UIGameTableResult.RESOURCE_BINDING = {
    ["Button_close"]  = {["ended"] = "backEvent"}, 
    ["Button_cancelOtherGame"]  = {["ended"] = "hidePanelOth"}, 
    ["Button_confirmOtherGame"]  = {["ended"] = "goOtherGame"}, 

}
UIGameTableResult.animNode = nil
function UIGameTableResult:backEvent()

	--if UIGameTableResult.animNode ~= nil then
		--UIGameTableResult.animNode:removeFromParent()
		--UIGameTableResult.animNode = nil
	--end

    self.delegate['Button_readyup']:setVisible(true)
    self.delegate['Button_readyup']:setEnabled(true) 
    self.delegate['Button_changeTable']:setVisible(true)
    self:removeSelf()
end


function UIGameTableResult:hidePanelOth()
    self['Panel_otherGame']:setVisible(false)
end     
 
function UIGameTableResult:goOtherGame()
	--if UIGameTableResult.animNode ~= nil then
		--UIGameTableResult.animNode:removeFromParent()
		--UIGameTableResult.animNode = nil
	--end
    GameTableCommon.quitComfirm(self.delegate)
    G_BASEAPP:callMethod('UIMain','quickEnterWanren')
    self:removeSelf()
end     


function UIGameTableResult:onCreate(argTable) 
    dump(argTable,"UIGameTableResult argTable")
    local animNodePath = 'Animation_account_lose.csb'
    local sfx = Sound.SoundTable['sfx']['Game_Lose']
    local nowPdata = G_BASEAPP:getData('PlayerData')
    self.delegate = argTable.delegate
    if argTable.isWon == true then
        sfx = Sound.SoundTable['sfx']['Game_Win']
        -- self['Image_bg']:loadTexture('tableresult/bgwin.png',ccui.TextureResType.plistType)
        self['Image_bg']:loadTexture('background/bgwin.png',ccui.TextureResType.localType)
        animNodePath = 'Animation_account_win.csb'
        LuaTools.coinRain(self)
    end
    argTable.cardsNodeTable = argTable.cardsNodeTable or {}
    
    -- local temp = cc.Sprite:createWithSpriteFrameName('common/dealer.png')
    scheduler.performWithDelayGlobal(function()
        UIGameTableResult.animNode = cc.CSLoader:createNode(animNodePath)
        self['Node_titleAnimation']:addChild(UIGameTableResult.animNode) 
        local action = cc.CSLoader:createTimeline(animNodePath)
        UIGameTableResult.animNode:runAction(action)
        action:gotoFrameAndPlay(0,false)
        audio.playSound(sfx, false) 
    end,0.1) 

    -- animNode:setPositionX(self['Node_titleAnimation']:getPositionX())
    -- animNode:setPositionY(self['Node_titleAnimation']:getPositionY()) 
    local function readyCallback(event)
       if event.name == 'ended' then 
       
            self.delegate['Button_readyup']:setVisible(true)
            self.delegate['Button_changeTable']:setVisible(true)
            self.delegate['Button_readyup']:setEnabled(true)
           if argTable.readyCallback then
                argTable.readyCallback()
           end
       end    
    end 
    local function ctCallback(event)
       if event.name == 'ended' then  

            self.delegate['Button_readyup']:setVisible(true)
            self.delegate['Button_changeTable']:setVisible(true)
            self.delegate['Button_readyup']:setEnabled(true)
           if argTable.ctCallback then
                argTable.ctCallback()
           end
       end    
    end 

    self['Button_ready']:onTouch(readyCallback)
    self['Button_changetable']:onTouch(ctCallback)
    if argTable.type ~= 'dn' then 
        if G_BASEAPP:getView('UIFriendBrief') then 
            G_BASEAPP:removeView('UIFriendBrief')
        end     

        if G_BASEAPP:getView('UIFund') then 
            G_BASEAPP:removeView('UIFund')
        end 
        if G_BASEAPP:getView('UITask') then 
            G_BASEAPP:removeView('UITask')
        end 
        if G_BASEAPP:getView('UIFaceicon') then 
            G_BASEAPP:removeView('UIFaceicon')
        end 
        if G_BASEAPP:getView('UIChat') then 
            G_BASEAPP:removeView('UIChat')
        end 
    end     

    local panel  
    if argTable.type == 'ddz' then
        self['Panel_ddz']:setVisible(true)
        panel = self['Panel_ddz'] 
        panel:getChildByName('Text_mulText'):setString(argTable.mulText.."倍"  or "0倍")
        self['Button_ready']:setVisible(true)
        self['Button_changetable']:setVisible(true)
        for k=1,3 do 
            self['Image_ddz_'..k..'_label']:setLocalZOrder(56)
        end 
 
        if argTable.isPaodekuai == true then 
            for i=1,3 do
                self['Image_ddz_'..i..'_label']:setVisible(false)
            end
        end

    elseif argTable.type == 'dn' then
        panel = self['Panel_dn']
        if argTable.cardsNode and not tolua.isnull(argTable.cardsNode) then  
            self['Panel_cardBG']:addChild(argTable.cardsNode) 
            argTable.cardsNode:setScaleX(self['Image_cardphd']:getScaleX())
            argTable.cardsNode:setScaleY(self['Image_cardphd']:getScaleY())
        else
            -- printError('argTable.cardsNode is null!') 
            dump(argTable,'argTable')
        end
 
        self['Panel_dn']:setVisible(true)
        self['Button_ready']:setVisible(true)
        self['Button_changetable']:setVisible(true)
    else 

        panel = self['Panel_zjh']
        self['Panel_zjh']:setVisible(true)
        self['Button_ready']:setVisible(true)
        self['Button_changetable']:setVisible(true)
    end 

    if self.delegate.isPrivateMatch then
        self['Button_changetable']:setEnabled(false)
        self['Button_changetable']:setTouchEnabled(false)
        self['Button_changetable']:setBright(false)
    end

    for i = 1 , 5 do  
        local p = panel:getChildByName('Panel_player_'..i)
        if p then
            if p:getChildByName('Image_winlosebg') then 
                p:getChildByName('Image_winlosebg'):setLocalZOrder(10000)
            end
            if p:getChildByName('Text_mulText') then 
                p:getChildByName('Text_mulText'):setLocalZOrder(10100)
            end
        end
        
        if  argTable.infoTable[i] == nil then
            if p then 
                p:setVisible(false)
            end
        else 
            

            local info = argTable.infoTable[i]
            local cardsNode = info.cardsNode
            dump(cardsNode,'cardsNode')
            if cardsNode and not tolua.isnull(cardsNode) then  
                local originalCardNode = p:getChildByName('Image_cardNode') 
                originalCardNode:getParent():addChild(cardsNode) 
                cardsNode:setScaleX(originalCardNode:getScaleX())
                cardsNode:setScaleY(originalCardNode:getScaleY()) 
                cardsNode:setPositionX(originalCardNode:getPositionX())
                cardsNode:setPositionY(originalCardNode:getPositionY())
            else
                -- printError('cardsNode is null!') 
                dump(cardsNode,'cardsNode')
            end 

            p:setVisible(true)
            if panel:getChildByName('Image_bg_'..i) and panel:getChildByName('Image_bg_'..i):getChildByName('Text_empty') then
                panel:getChildByName('Image_bg_'..i):getChildByName('Text_empty'):setVisible(false)
            end
            local function onFinishTable(status,downloadedSize,dst)
                if status == "success" then
                    print("onFinishTable getChildByName:dst",dst,"status",status)
                    -- p:getChildByName('Image_avatar'):loadTexture(dst,ccui.TextureResType.localType)
                    local newSprite = cc.Sprite:create(dst)
                    local maskSprite = cc.Sprite:createWithSpriteFrameName('common/circle.png') 
                    local spriteItem = LuaTools.createMaskedSprite(newSprite, maskSprite) 
                    -- self:addChild(spriteItem) 
                    spriteItem:setScaleX(p:getChildByName('Image_avatar'):getContentSize().width / spriteItem:getContentSize().width)
                    spriteItem:setScaleY(p:getChildByName('Image_avatar'):getContentSize().height / spriteItem:getContentSize().height)
                    spriteItem:setAnchorPoint(0,0)
                    p:getChildByName('Image_avatar'):addChild(spriteItem)

                else 
                    print('UIGameTableResult 获取好友头像失败')
                end
            end 
    
            if info.iconUrl ~= "" then
                LuaTools.getFileFromUrl({
                url =  info.iconUrl,
                destFile = ( info.iconUrl:gsub("/","_")),
                onFinishTable = onFinishTable
                }) 
            else
                local path = 'common/default_avater_man.png'
                if info.sex == 1 then --female
                    path = 'common/default_avater_woman.png'
                end
                 -- p:getChildByName('Image_avatar'):loadTexture(path,ccui.TextureResType.plistType)
  
                local newSprite = cc.Sprite:createWithSpriteFrameName(path)
                local maskSprite = cc.Sprite:createWithSpriteFrameName('common/circle.png') 
                local spriteItem = LuaTools.createMaskedSprite(newSprite, maskSprite) 
            
                spriteItem:setScaleX(p:getChildByName('Image_avatar'):getContentSize().width / spriteItem:getContentSize().width)
                spriteItem:setScaleY(p:getChildByName('Image_avatar'):getContentSize().height / spriteItem:getContentSize().height)
                spriteItem:setAnchorPoint(0,0)
                p:getChildByName('Image_avatar'):addChild(spriteItem)

            end 
            if  info.isMyself == true then 
                local lens = cc.Sprite:createWithSpriteFrameName('tableresult/selfLens.png') 
                local avatar = p:getChildByName('Image_avatar')
                if avatar then 
                    avatar:getParent():addChild(lens)
                    lens:setLocalZOrder(55)
                    lens:setPositionX(avatar:getPositionX())
                    lens:setPositionY(avatar:getPositionY()) 
                    lens:setScaleX(avatar:getScaleX())
                    lens:setScaleY(avatar:getScaleY()) 
                end 
                -- if info.coins >= 300000 and  argTable.type == 'ddz' and nowPdata.showWinMoreMoney == false  then 
                --     nowPdata.showWinMoreMoney = true 
                --     self['Panel_otherGame']:setVisible(true)
                -- end     
            end
            p:getChildByName('Text_name'):setString(info.name or 'UNNAMEDPLAYER')
            p:getChildByName('Text_coins'):setString(LuaTools.convertAmountChinese(info.coins or 0) ) 
            if i == 1 and info.coins < 0 then
                self['Text_curroundstat']:setString('本局亏损') 
            end
            local nType =  p:getChildByName('Image_ntype')
            if nType and argTable.type == 'dn' then
                local path = "tableresult/"..GameTableCommon.DoniuTypeTable[info.nType+1 or 5]
                print('path:',path)
                nType:loadTexture(path,ccui.TextureResType.plistType)
            end
    
            local mulText =  p:getChildByName('Text_mulText')
            if mulText and info.mulText then 
                mulText:setString(info.mulText.."倍" or '0倍')
                if info.isDealer == true then
                    mulText:setString(argTable.thisRoundMulti.."倍" or '0倍')
                end
            end
            
            -- printf("RESULT:=====>>>>  \n dealer:%s,\ntype:%s",info.isDealer,argTable.type)
            if info.isDealer == true and argTable.type ~= 'ddz' then
                local dealer = cc.Sprite:createWithSpriteFrameName('common/dealer.png')
                p:getChildByName('Image_frame'):addChild(dealer)
                dealer:setPositionY(p:getChildByName('Image_frame'):getContentSize().height - 15)  
                dealer:setPositionX(15)
            end
        
    
            if  argTable.type == 'zjh' then 
                -- p:getChildByName('Image_ntypebg'):setVisible(false)
                -- p:getChildByName('Image_ntype'):setVisible(false)
                -- p:getChildByName('Text_mulText'):setVisible(false)
                
                local wonPath = 'tableresult/lose.png'
                if info.won == true then
                    wonPath = 'tableresult/win.png'
                end
                -- print('wonPath:==>>',wonPath)
                p:getChildByName('Image_winlosebg'):loadTexture(wonPath,ccui.TextureResType.plistType)
                
            end

        end--argTable.infoTable[i] ~= nil

    end
    
    self['Image_bg']:getChildByName('Button_changetable'):setEnabled(argTable.changeTabState)


    local function recruFunc()  
        self:addGobackEventAction(function() recruFunc() end) 
    end
    self:addGobackEventAction(function()
        recruFunc() 
    end)

    if argTable.type == 'dn' then 
        self:createSchedule("DOUNIUREMOVE",function() 
            self:stopSchedule("DOUNIUREMOVE")
            self:backEvent()
        end,1)
    end
    if self['Panel_otherGame'] then
        self['Panel_otherGame']:setVisible(false)
    end
end

return UIGameTableResult
