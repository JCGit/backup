local UIMatchRoomDouniuZJH = class("UIMatchRoomDouniuZJH", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
UIMatchRoomDouniuZJH.RESOURCE_FILENAME = "UIMatchRoomDouniuZJH.csb"
--UIMatchRoomDouniuZJH.RESOURCE_PRELOADING = {"main.png"}
--UIMatchRoomDouniuZJH.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIMatchRoomDouniuZJH.RESOURCE_BINDING = {  
    ["Button_QuickStart"] = {["ended"] = "onQuickStart"},
    ["Button_chargeGem"]     = {["ended"] = "enterChargeDiamond"},
} 

--[=================三张牌，斗牛场次================]--
--更新金币
function UIMatchRoomDouniuZJH:updatePlayerCoin(_coin)
    _coin = _coin or self.pData.coin
    self['Text_myMoney']:setString(LuaTools.convertAmountChinese(self.pData.coin))
end


--进入充值砖石
function UIMatchRoomDouniuZJH:enterChargeDiamond()
    G_BASEAPP:addView('UIQuickBuy', 1200,function(arg) 
        dump(arg,"arg")
        -- self.pData.coin = arg.coin 
        self['Text_myMoney']:setString(LuaTools.convertAmountChinese(self.pData.coin))
    end) 
end

function UIMatchRoomDouniuZJH:enterCharge() 
    if not G_BASEAPP:getView('UIShopDiamond') then 
        G_BASEAPP:addView('UIShopDiamond', 1200,function(arg) 
            self['Text_myMoney']:setString(LuaTools.convertAmountChinese(self.pData.coin))
        end) 
    end   
end     

--检测金币对否小于0，并且是否该弹出充值
function UIMatchRoomDouniuZJH:checkChips()
    if tonumber(self.pData.coin) <= 0 then
        local function onConfirm()
            if self.pData.gem > 0 then 
                self:enterChargeDiamond()
            else 
                self:enterCharge() 
            end  
        end
        local dlg = self.app:addView('UIDialog', self:getLocalZOrder() + 1, nil, true)
        dlg:setupDialog('金币不足', Constants.STRING_NO_MONEY, onConfirm, nil, false)
        return false
    end
    return true
end

--退出后回调
function UIMatchRoomDouniuZJH:onExit() 
    if self.onExiting == nil then 
        self.onExiting = true
        if self.isEnterGameRoom == nil then
            self.app:callMethod('UIMain', 'showEnterMainActions') 
        end
    end
end

--点击快速开始
function UIMatchRoomDouniuZJH:onQuickStart()    
    if self:checkChips() == false then return end
    --判断该进入哪一个场次
    local dataRoom = self:getDataRoomsSelected()
    local myChips = tonumber(self.pData.coin)
    local indexRoom = 0
    dump(dataRoom,'场次信息')
    local sizeTable = #dataRoom   --场次个数
    print("keyGame  "..self.gameDataSel.dataName)
    if self.keyGame == Constants.KEY_ZJH then
        sizeTable = #dataRoom-1    --不能进入秒杀场和道具场
    end
    --倒数循环可进入的场次
    for i = sizeTable, 1, -1 do
        local max = dataRoom[i].max 
        local min = dataRoom[i].min
        indexRoom = i
         print("My Chips: "..myChips.." min: "..min.." max: "..max)
       if myChips >= min and max < 0 then     
            break
       elseif max > 0 and myChips <= max and myChips >= min then 
            break
       end
    end
    --获取到该进入场次的下标
    self:enterRoom(indexRoom)
end

--检测金币是否足够进入该场次
function UIMatchRoomDouniuZJH:checkEnabledEnterRoom(_index)
    local myChips = tonumber(self.pData.coin)
    local dataRoom = self:getDataRoomsSelected()
    local max = dataRoom[_index].max
    local min = dataRoom[_index].min
      if myChips >= min and max < 0 then     
            return 'ok'
       elseif max > 0 and myChips <= max and myChips >= min then 
            return 'ok'
        elseif max > 0 and myChips > max then 
            return 'tooMuch'
        elseif min > 0 and myChips < min then
            return 'notEnough'
       end
    return 'notOk'
end

--根据已选择的场次进入对应的游戏
function UIMatchRoomDouniuZJH:enterRoom(_index)
    if self.pData.gamePorts and  #self.pData.gamePorts[tostring(1)] == 0 then
        self.tool:showTips("无法获取房间信息。")
        print("NO PORTS FOUND.")
        return
    end
   local dataRoomName = self.gameDataSel.dataName
   local dataRoom = self:getDataRoomsSelected()
   local viewName = self.gameDataSel.viewName 
   local siteid = dataRoom[_index].siteid
   local roomId = dataRoom[_index].roomid
    -- if self.keyGame  == Constants.KEY_DN then 
    --     if self.pData.coin <=50000 then 
    --        roomId = 0 
    --     elseif  self.pData.coin > 50000 and self.pData.coin <=200000 then   
    --        roomId = 1  
    --     elseif  self.pData.coin > 200000 and self.pData.coin <=1000000 then   
    --        roomId = 2  
    --     elseif  self.pData.coin > 1000000 then   
    --        roomId = 3             
    --     end        
    -- end   

   local port =  self.pData:getGamePort(siteid)

   if self.keyGame == Constants.KEY_ZJH then
        roomId = -1
    end
    self:printRoomData(dataRoomName, viewName, siteid, roomId, port)

    local table = {}

    if dataRoomName == 'GameType_DN' then
        table['RoomLevel'] = roomId
    elseif  dataRoomName == 'GameType_ZJH' then
        table['tableType'] = siteid
    end
    table['port'] = port

   if #viewName > 0 then
   -- local load = G_BASEAPP:addView("UILoading",200)  
   --  G_LOADINGVIEW = load
   --  load:setLoadingType(true)
   --  load:setNextAction(function()
   --      G_BASEAPP:addView(viewName,500,table)  
   --  end)
   --  load:startProgress()
        G_BASEAPP:addView(viewName,500,table)  
    else
         self.tool:showTips("暂时无法进入该游戏场")
    end
end

--打印数据
function UIMatchRoomDouniuZJH:printRoomData(dataname, viewname, siteId, roomId, port)
    local tb = {
        dataname = dataname,
        viewname = viewname,
        siteId = siteId,
        roomId = roomId,
        port = port,
    }
    dump(tb,"斗牛 扎金花")
end

--获取已选择的场次的数据表
function UIMatchRoomDouniuZJH:getDataRoomsSelected()
    local dataRoomName =  self.gameDataSel.dataName
    return self.pData.GameTypes[dataRoomName]
end 

--展示进入动作
function UIMatchRoomDouniuZJH:showEnterActions()
    --background actions
    local maskLayer = cc.LayerColor:create(cc.c4b(255,255,255,0))
    self['Panel_main']:addChild(maskLayer,-1)
    maskLayer:runAction(cc.Sequence:create(
        cc.FadeTo:create(0.5, 80),
        cc.FadeTo:create(0.2, 0),
        cc.CallFunc:create(function() maskLayer:removeFromParent() end)
        ,nil))

    self['Panel_bgd']:setOpacity(0)
    self['Panel_bgd']:runAction(cc.FadeTo:create(0.6,255))

    --widgets actions
    local btstart = self['Button_QuickStart']
    local moveIn = cc.MoveTo:create(0.6,cc.p(btstart:getPositionX(),72))
    local move_ease_out = cc.EaseBackOut:create(moveIn)
    btstart:runAction(move_ease_out)

    local panelTop = self['Panel_top']
    local moveIn2 = cc.MoveTo:create(0.6,cc.p(panelTop:getPositionX(),cc.Director:getInstance():getWinSize().height))
    local move_ease_out2 = cc.EaseBackOut:create(moveIn2)
    panelTop:runAction(move_ease_out2)

    --listview items actions
    local listview = self['ListView_type']
    local function moveBackAfter(delay, byX)
        local backVal = 80
        if byX < 0 then
            backVal = -backVal
        end
         local moveIn = cc.MoveBy:create(delay,cc.p(byX+backVal,0))
         local moveOff = cc.MoveBy:create(0.2,cc.p(-backVal,0))
         return cc.Sequence:create(moveIn, moveOff)
    end
    for i,item in ipairs(listview:getChildren()) do
        --local moveIn = cc.MoveBy:create(0.47,cc.p(-self.winWidth,0))
        --local move_ease_in = cc.EaseBackOut:create(moveIn)
        --item:runAction(cc.Sequence:create(cc.DelayTime:create(i/10+0.2),move_ease_in,nil))
        item:runAction(cc.Sequence:create(cc.DelayTime:create(i/10+0.2),moveBackAfter(0.2,-self.winWidth),nil))
    end
end

function UIMatchRoomDouniuZJH:onCreate(keyGame)
    self['ListView_type']:setScrollBarEnabled(false)
    local app = self:getApp()
    self.app = app
    --LuaTools.viewAction2(self['Panel_main'])
    self.pData = app:getData('PlayerData')
    self.tool = app:getModel('Tools')
    --self.sound = app:getModel('Sound')
    self.config = app:getData('Config')
    cc.SpriteFrameCache:getInstance():addSpriteFrames("res_gametypes.plist")
    print('穿进来的keyname='..keyGame)
    self.winWidth = cc.Director:getInstance():getWinSize().width
    self.keyGame = keyGame
    self['Panel_bgd']:setOpacity(0)
    if self.keyGame == Constants.KEY_ZJH then
        local act = cc.Sequence:create(
            cc.DelayTime:create(0.1),
            cc.CallFunc:create(function()
                self['Image_bgdMain']:loadTexture("background/bg_zjhc.png", ccui.TextureResType.localType)
             end),nil)
        self:runAction(act)
        self['Image_title']:loadTexture("res_gametypes/title_zjh.png", ccui.TextureResType.plistType)
    end

    self['Button_QuickStart']:setPressedActionEnabled(false)
    
    self.games = {
        dn = self.config.keyDataGames.dn,
        zjh = self.config.keyDataGames.zjh,
    }

    self.gameDataSel = self.games[keyGame]

    local function onClose(event)
        if event.name == 'began' then
        elseif event.name == 'ended' then 
           -- self.app:callMethod('UIMain', 'showEnterMainActions')
            --self.isClosing = true
            
            self:removeSelf()

            --LuaTools.viewAction2Over(self['Panel_main'],'UIMatchRoomDouniuZJH')
        end
    end
    -- self['Button_QuickStart']:setPressedActionEnabled(false)
    self['Button_close']:onTouch(onClose)
    self['Text_myMoney']:setString(LuaTools.convertAmountChinese(self.pData.coin))


     self.app:callMethod("UIMain", "loadGameRoomsInfos", self.gameDataSel,
        function() 
            self:initRooms(self:getDataRoomsSelected())
            self:startUpdateCounts()
            self:showEnterActions()
        end,
        function()
            -- self.app:callMethod('UIMain', 'showEnterMainActions')
            -- self:removeSelf()
        end)

    if self.pData.onlinePlayerNumber ~= 0 then 
       self:updatePlayerCounts(self.pData.onlinePlayerNumber)
    end   
end

--初始化场次UI
function UIMatchRoomDouniuZJH:initRooms(_array)
    dump(_array, self.gameDataSel.dataName)
    local listview = self['ListView_type']
    local itemModel
   
    if self.keyGame == Constants.KEY_ZJH then
        itemModel = self['Panel_ZJH']
        self["Button_QuickStart"]:loadTextures("res_gametypes/zjh_btStart.png","res_gametypes/zjh_btStart1.png","res_gametypes/zjh_btStart.png",ccui.TextureResType.plistType)
    else
        itemModel = self['Panel_DN']
    end
    itemModel:setVisible(false)
    itemModel:setBackGroundColorOpacity(0)

    listview:setItemModel(itemModel)
    listview:setBounceEnabled(false)
    listview:setScrollBarEnabled(false)
    listview:setBackGroundColorOpacity(0)
    itemModel:setBackGroundColorOpacity(0)
    listview:removeAllChildren()

    local function onEnterRoom(event)
        if event.name == 'began' then
        elseif event.name == 'ended' then
            if self:checkChips() == false then return end
           local tag = event.target:getTag()
           local result = self:checkEnabledEnterRoom(tag)
           if result == 'ok' then
                self:enterRoom(tag)
            elseif result == 'tooMuch' then
                self.tool:showTips('金币超限，请移步更高级场次游戏')
            elseif result == 'notEnough' then
                self.tool:showTips('进入房间失败，金币不足')
                local function myRefresh() 
                    self['Text_myMoney']:setString(LuaTools.convertAmountChinese(self.pData.coin)) 
                end
                if self.pData.bank and tonumber(self.pData.bank)> 0 then 
                    G_BASEAPP:addView('UISupplyMoney',self:getLocalZOrder()+1, myRefresh)
                else     
                    G_BASEAPP:addView('UIQuickBuy', 1200, myRefresh)
                end 
            else
                self.tool:showTips('您的金币不符合进入房间的条件！')
           end
        end
    end

    dump(_array,'斗牛和三张牌的场次信息')

    for key ,var in ipairs(_array) do
        listview:pushBackDefaultItem()
        local item = listview:getItem(key-1) 
        local dataRoom = self:getDataRoomsSelected()
        local infos = dataRoom[key]

        local desc
        if infos.max > 0 and infos.min < 0 then     
            desc = LuaTools.convertAmountChinese(infos.max).."以下"
        elseif infos.max < 0 and infos.min > 0 then
            desc = LuaTools.convertAmountChinese(infos.min).."以上"
        elseif infos.max > 0 and infos.min > 0 then
            desc = LuaTools.convertAmountChinese(infos.min)..'-'..LuaTools.convertAmountChinese(infos.max).."准入"
        else
            desc = "无限制"
        end
        item:getChildByName('Text_count'):setString('0')
        item:getChildByName('Text_desc'):setString(desc)
        
        item:setTag(key)
        item:setTouchEnabled(true)
        item:onTouch(onEnterRoom)

        print("KEY: "..key)
        if self.keyGame == Constants.KEY_ZJH then
            item:getChildByName('Image_type'):loadTexture("res_gametypes/img_zjh_type"..key..".png", ccui.TextureResType.plistType)
            item:getChildByName('Image_cards'):loadTexture("res_gametypes/img_zjh_img"..key..".png", ccui.TextureResType.plistType)
            item:getChildByName('Text_difen'):setString("底分:"..infos.base)
        else
           item:getChildByName('Image_character'):loadTexture("res_gametypesDN/img_dn_"..key..".png", ccui.TextureResType.plistType)
           item:getChildByName('Image_roomName'):loadTexture("res_gametypesDN/img_dnc_"..key..".png", ccui.TextureResType.plistType)
           item:getChildByName('Text_difen'):setString(infos.base)
        end

        --item:setPositionX(item:getPositionX() + 200)
        
        item:runAction(cc.Sequence:create(
         cc.MoveBy:create(0.1,cc.p(self.winWidth,0)),
         cc.CallFunc:create(function() item:setVisible(true) end)
         ,nil))
    end 

end

--启动更新玩家个数
function UIMatchRoomDouniuZJH:startUpdateCounts()
    self.app:callMethod('UIMain','reqSock_getOnliner')
    self:createSchedule("updateCounts",function()
        self.app:callMethod('UIMain','reqSock_getOnliner')
    end,self.config.refreshPlayerCountsDelay)
end

--更新玩家个数
function UIMatchRoomDouniuZJH:updatePlayerCounts(_table)
   -- dump(_table)
   -- print("Updating "..self.gameDataSel.dataName.." rooms players count...")
     local items = self['ListView_type']:getChildren()
    for i,v in ipairs(self:getDataRoomsSelected()) do
        local count
        if self.keyGame == Constants.KEY_ZJH then  --扎金花
            count = _table['60'][tostring(i-1)]
        else
            count = _table[tostring(v.siteid)][tostring(i-1)]
        end
        items[i]:getChildByName('Text_count'):setString(count)
    end
end


return UIMatchRoomDouniuZJH
