local UIShop = class("UIShop", cc.load("mvc").ViewBase)
UIShop.RESOURCE_FILENAME = "UIShop.csb"
--UIShop.RESOURCE_PRELOADING = {"shop.png"}
--UIShop.RESOURCE_LOADING  = {    ["res/background/mohuBg.png"] = {names = {"Image_bgAll"}}}
UIShop.RESOURCE_BINDING = {
    ["Button_callService"] = {["ended"] = "onCallService"},

}

local scheduler = require("app.models.QScheduler")

--初始化
function UIShop:onCreate(index, uiview)
    local app = self:getApp()
    self.app = app
    self.tool = app:getModel('Tools')
    cc.SpriteFrameCache:getInstance():addSpriteFrames("common.plist")

    self.pData = app:getData('PlayerData')
    self.config = app:getData('Config')
    self.indexViewSelected = 0
    self.viewSelected = nil
    self.textColorUnsel = cc.c3b(255,233,178)
    self['Panel_main']:setVisible(false)
    self.uiview = uiview
    if uiview and uiview == 'profile' then
        self.extraViewAction = "UIProfileMain"
        self.tempDayLeft = self.pData.vipvalid
    elseif uiview and uiview == 'help' then
        self.extraViewAction = "UIHelps"
    elseif uiview and uiview  == 'chat' then
        self.extraViewAction = "UIChat"
    end

    self:initBackAction(self)
    
    self:updateContent()
    
    self.layerTarget = {
        'UIShopVip',
        'UIShopChips',
        'UIShopItems',
        'UIShopTradeMarket',
        'UIShopAccu',
    }

    local mtop = self.app:addView("UIShopTop",40001)
    mtop:addGobackEventAction(function()end)
    
    --切换商场里的view
    local function onSwitchView(event)
        if event.name == 'began' then
        elseif event.name == 'ended' then
            
        	local tag = event.target:getTag()
            if tag ==  self.indexViewSelected  then
                return
            end
            self:showView(tag)
            for i, var in pairs(self.layerTarget) do
                self.tool:freezeWidget(self['Panel_Type_'..i], 0.3)
            end
        end
    end
    
    for key,var in pairs(self.layerTarget) do
        local panel = self['Panel_Type_'..key]
        panel:setTag(key)
        panel:onTouch(onSwitchView)
        panel:getChildByName('Image_blur'):setVisible(false)
        panel:getChildByName('Text_title'):setColor(self.textColorUnsel)
    end

    
    self:showView(index, false)
    LuaTools.viewAction2(self['Panel_main'], function() self.viewSelected:init() end, {"UIMain", self.extraViewAction})
    LuaTools.viewAction2(self.viewSelected, nil, false)
    self['Panel_main']:setVisible(true)
    self.viewSelected:setVisible(true)
    if G_BASEAPP:getView('UIProfileMain') then 
       G_BASEAPP:removeView('UIProfileMain')
    end     
end

function UIShop:showView(index, _show)
    -- scheduler.performWithDelayGlobal(function()
		
        if index < 1 or index > #self.layerTarget then return end
        if self.indexViewSelected == 0 then 
            self.viewSelected = self.app:addView(self.layerTarget[index],40000 )
        else
            local oldpanel = self['Panel_Type_'..self.indexViewSelected]
            oldpanel:getChildByName('Text_title'):setColor(self.textColorUnsel)
            oldpanel:getChildByName('Image_blur'):setVisible(false)
            self.viewSelected:removeSelf()
            self.viewSelected = self.app:addView(self.layerTarget[index],40000)
            self.viewSelected:init()
        end
        local newpanel = self['Panel_Type_'..index]
        newpanel:getChildByName('Text_title'):setColor(self.config.ColorTextSelect)
        newpanel:getChildByName('Image_blur'):setVisible(true)
        self.indexViewSelected = index
        if _show then
            self.viewSelected:setVisible(_show)
        end
        self:initBackAction(self.viewSelected)
    -- end,0.01) 
end

--返回键回调
--@param: 目标
function UIShop:initBackAction(_target)
    _target:addGobackEventAction(function()
        print("=========================overrided==========================") 
        print("=========================overrided==========================") 
        print("=========================overrided==========================") 
        LuaTools.playBtSound()
        self:onClose()
        self.app:callMethod('UIShopTop' ,'onExitAction')
        local function loop()
            _target:addGobackEventAction(loop)
        end
        _target:addGobackEventAction(loop)
    end)
end

--更新用户财富信息
function UIShop:updateContent()
    self['Text_Chips']:setString(self.tool:convertAmountChinese(self.pData.coin))
    self['Text_Diamond']:setString(self.tool:convertAmountChinese(self.pData.gem))
    self['Text_TelFee']:setString(self.tool:convertAmountChinese(self.pData.telfee))
    self['Text_JiFen']:setString(self.tool:convertAmountChinese(self.pData.accu))
end

--点击关闭按钮事件
function UIShop:onClose()
    if self.uiview  and self.uiview  == 'profile' then
        if self.tempDayLeft ~= self.pData.vipvalid then  --VIP 有了变化
            self.app:callMethod('UIProfileVip','updateVipView')
            self.app:callMethod('UIProfileInfos','updateUserVip')
            self.app:callMethod('UIProfileBag','updateOnVipChange')
        end
    elseif self.uiview and self.uiview  == 'chat' then
        self.app:callMethod('UIChat','updateHornCount')
    end
    self.app:callMethod('UIMainTop','updatePlayerInfos')
    self.app:callMethod('UIMainTop','updateVipStatus')
    --self.viewSelected:removeSelf()
    --self.app:removeView('UIShop')
    printf("VIEW SEL: %s,  NAME: %s", self.viewSelected, self.layerTarget[self.indexViewSelected])
    LuaTools.viewAction2Over(self.viewSelected:getPanelMain(),self.layerTarget[self.indexViewSelected])
    LuaTools.viewAction2Over(self['Panel_main'],'UIShop', nil, {"UIMain","UIMainTop",self.extraViewAction})
end

--退出商城回调
function UIShop:onExit1() 
    -- if self.viewSelected and self.viewSelected.removeSelf then 
    --     self.viewSelected:removeSelf()
    -- end
    if G_BASEAPP:getView(self.viewSelected) then
        G_BASEAPP:removeView(self.viewSelected)
    end
end

--拨打客服电话
function UIShop:onCallService()
    LuaTools.dialPhone("tel://4008362606")
end

return UIShop

