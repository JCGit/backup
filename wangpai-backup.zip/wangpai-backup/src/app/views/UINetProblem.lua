local UINetProblem = class("UINetProblem", cc.load("mvc").ViewBase)
UINetProblem.RESOURCE_FILENAME = "UIWaiting.csb"
UINetProblem.RESOURCE_BINDING = {

        ["Button_back"]  = {["ended"] = "backEvent"} 

}

function UINetProblem:onCreate(str,time)  --'当前网络状态不稳定，正尝试重连中..'
    -- self.app = self:getApp()
    
    --[[str = str or '当前网络状态不稳定，正尝试重连中' 
    time = time or 3
    local action = cc.RotateBy:create(0.5,180)
    self['Image_rotation']:runAction(cc.RepeatForever:create(action))
    self['Text_show']:setString(str)
    local count = 1 
    local function countTime() 
        count = count+ 1 
        if count > time then 
           self:stopSchedule('counting')
           self['Button_back']:setVisible(true)
        end    
    end 
    self:createSchedule('counting',countTime,1)]]
    -- self:setLockGoback(true)
end

function UINetProblem:backEvent(event)
  LuaTools.softMasterReset()
   --   G_BASEAPP:removeView('UINetProblem') 
   --  dump(G_BASEAPP.views_)
   --  for _,v in pairs(G_BASEAPP.views_) do
   --    for k,vv in pairs(v) do 
   --       -- G_BASEAPP:removeView(k)   
   --       if k ~= "UIDummyScene" and tolua.isnull(vv) == false then
   --          G_BASEAPP:removeView(k) 
   --       end
   --     end 
   -- end 
   --  G_BASEAPP:enumerateScene(function(var)
   --   printf("enumerateScene:%s",var:getName())
   -- --    if var:getName() ~= "UIDummyScene" then
   -- --      -- self.app:removeView('UIFriend') 
   -- --      self.app:back() 
   -- --    end
   --   end) 
   --  G_BASEAPP:addView('UILogin',101,1)
end
return UINetProblem
