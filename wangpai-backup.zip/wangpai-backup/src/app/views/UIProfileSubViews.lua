local UIProfileSubViews = class("UIProfileSubViews", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
local GameTableCommon = require("app.models.GameTableCommon")
require "cocos.cocos2d.json"
UIProfileSubViews.RESOURCE_FILENAME = "UIProfileSubViews.csb"
--UIShop.RESOURCE_PRELOADING = {"shop.png"}
--UIShop.RESOURCE_LOADING  = {    ["res/background/mohuBg.png"] = {names = {"Image_bgAll"}}}
UIProfileSubViews.RESOURCE_BINDING = {
    
}

--初始化
function UIProfileSubViews:onCreate(index, val, cb,tcpCallBack)
    local app = self:getApp()
    self.app = app
    self.tool = app:getModel('Tools')
    self.pData = self.app:getData('PlayerData')
    self.config = app:getData('Config')
    self.account = app:getModel('Account')
    printf('tcpCallBack:%s',tcpCallBack)
    self.TcpCallBacks = tcpCallBack
    print('Show sub view: '..index)
    self.indexSel = index
    self.onCloseCB = cb

    LuaTools.enterActionScaledWithMask(self['Panel_Sub'])

    self.listSubView = {
        'Panel_ClearEgg', 
        'Panel_Password',
        'Panel_SellGift', 
        'Panel_FindPwd', 
        'Panel_ChangePwd',
        'Panel_SetBankPwd',
    }
    
    self:initSubView()
    
    if index == 1 then
    	self:initClearEggPanel()
    end
    if index == 3 then
        self:initSellGiftPanel()
    end
    if index == 2 then
        --初始化输入钱包密码
        self.chipsVal = val
        self:initEnterPwdPanel()
    end
    if index == 4 then
        self:initFindPwdPanel()
    end
    if index == 5 then
        self:initChangePwdPanel()
    end
    if index == 6 then
    	self:initSetPwdPanel()
    end
end

function UIProfileSubViews:initTextField(_txf)
    _txf:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    _txf:setTextColor(self.config.Txf_textColor)
end

--初始化清理鸡蛋界面
function UIProfileSubViews:initClearEggPanel()
    local parentPanel = self['Panel_ClearEgg']
    parentPanel:getChildByName('Text_eggCount'):setString(self.pData.gift[2])
    local txf_ce = parentPanel:getChildByName('TextField_ClearEgg')
    self:initTextField(txf_ce)
    self.account:handleTxfControl(txf_ce, nil, 'num')
end

--初始化输入保险密码界面
function UIProfileSubViews:initEnterPwdPanel()
    local parentPanel = self['Panel_Password']
    local txf_pwd = parentPanel:getChildByName('TextField_pwd')
    self:initTextField(txf_pwd)
    self.account:handleTxfControl(txf_pwd)
end

--初始化找回宝箱密码界面
function UIProfileSubViews:initFindPwdPanel()
    local parentPanel = self['Panel_FindPwd']
    local quest = self.config.listQuestions[self.pData.bankQuestion]
    print('PPPP'..self.pData.bankQuestion)
    parentPanel:getChildByName('Text_secretQuestion'):setString(quest)

    local txf_secret = parentPanel:getChildByName('TextField_secretAnswer')
    local txf_newpwd = parentPanel:getChildByName('TextField_newpwd')
    local txf_confPwd = parentPanel:getChildByName('TextField_confirmPwd')
    self:initTextField(txf_secret)
    self:initTextField(txf_newpwd)
    self:initTextField(txf_confPwd)

    -- self.account:handleTxfControl(txf_secret)
    self.account:handleTxfControl(txf_newpwd)
    self.account:handleTxfControl(txf_confPwd)
end

--初始化修改宝箱密码界面
function UIProfileSubViews:initChangePwdPanel()
    local parentPanel = self['Panel_ChangePwd']

    local txf_oldpwd = parentPanel:getChildByName('TextField_oldPwd')
    local txf_newpwd = parentPanel:getChildByName('TextField_NewPwd')
    local txf_confPwd = parentPanel:getChildByName('TextField_ConfirmPwd')
    
    self:initTextField(txf_oldpwd)
    self:initTextField(txf_newpwd)
    self:initTextField(txf_confPwd)

    self.account:handleTxfControl(txf_oldpwd)
    self.account:handleTxfControl(txf_newpwd)
    self.account:handleTxfControl(txf_confPwd)
end

--初始化设置宝箱密码界面
function UIProfileSubViews:initSetPwdPanel()
    local parentPanel = self['Panel_SetBankPwd']
    local panel_option = parentPanel:getChildByName('Panel_Option')
    local listview = panel_option:getChildByName('ListView_question')
    local panelItem = panel_option:getChildByName('Panel_Question')
    local img_arrow = parentPanel:getChildByName('Image_arrow')
    self.indexQuestion = 0
    local function onSelectQuestion(event)
        if event.name == 'ended' then
            local tag = event.target:getTag()
            self.indexQuestion = tag
            parentPanel:getChildByName('Text_ChooseQuest'):setString(self.config.listQuestions[tag])
            parentPanel:getChildByName('Text_ChooseQuest'):setColor(cc.c3b(255,255,255))
            panel_option:setVisible(false)
            img_arrow:loadTexture("res_profile/img_arrow_bot.png", ccui.TextureResType.plistType)
        end
    end
    
    listview:setItemModel(panelItem)
    local item
    for key ,var in pairs(self.config.listQuestions) do
        listview:pushBackDefaultItem()
        item = listview:getItem(key-1)
        --item:setColor(cc.c3b(30,144,255))
        item:getChildByName('Text_Question'):setString(var)
        item:setTag(key)
        item:onTouch(onSelectQuestion)
        if key == #self.config.listQuestions then
            item:getChildByName('Image_botline'):setVisible(false)
        end
    end
    panelItem:setVisible(false)
    panel_option:setVisible(false)
    
    local function openQuestions(event)
        if event.name == 'ended' then
            panel_option:setVisible(not panel_option:isVisible())
            if panel_option:isVisible() == true then
                img_arrow:loadTexture("res_profile/img_arrow_up.png", ccui.TextureResType.plistType)
            else
                img_arrow:loadTexture("res_profile/img_arrow_bot.png", ccui.TextureResType.plistType)
            end
        end
    end
    
    local panelOpenQuest = parentPanel:getChildByName('Image_secureQuestions')
    panelOpenQuest:onTouch(openQuestions)
    panelOpenQuest:setTouchEnabled(true)

    local txf_bankpwd = parentPanel:getChildByName('TextField_setbankpwd')
    local txf_answer = parentPanel:getChildByName('TextField_answer')
    self:initTextField(txf_bankpwd)
    self:initTextField(txf_answer)

    self.account:handleTxfControl(txf_bankpwd)
    self.account:handleTxfControl(txf_answer, {' '},'banc')

end

--初始化售卖礼物界面
function UIProfileSubViews:initSellGiftPanel()
    local isIMEAttached = false
    local function onAdd(event)
        if event.name == 'ended' then
            if isIMEAttached == true then return end
            local tag = event.target:getTag()
            local textCount = event.target:getParent():getChildByName('TextField_count')
            local gainChips = event.target:getParent():getChildByName('Text_price')
            
            if tonumber(textCount:getString()) < self.pData.gift[tag+2] then 
                local newVal = textCount:getString()+1
                textCount:setString(newVal)
                gainChips:setString(self.tool:convertAmountChinese(newVal * self.config.listSellGifts[tag]*80/100))
            end
        end
    end

    local function onMinus(event)
        if event.name == 'ended' then
            if isIMEAttached == true then return end
            local tag = event.target:getTag()
            local textCount = event.target:getParent():getChildByName('TextField_count')
            local gainChips = event.target:getParent():getChildByName('Text_price')
            if  tonumber(textCount:getString()) > 0 then
                local newVal = textCount:getString()-1
                textCount:setString(newVal)
                gainChips:setString(self.tool:convertAmountChinese(newVal * self.config.listSellGifts[tag]*80/100))
            end
        end
    end
    
    local function onSetNumber(event)
        local index = event.target:getTag()
        if event.name == "ATTACH_WITH_IME" then
            isIMEAttached = true
            if event.target:getString() == "0" then
                event.target:setString("")
            end    
        elseif event.name == "DETACH_WITH_IME" then
            isIMEAttached = false
            if event.target:getString() == "" then
                event.target:setString("0")
            end
            local numEntered = tonumber(event.target:getString())
            local gainChips = event.target:getParent():getChildByName('Text_price')
            local countGift = event.target:getParent():getChildByName('Text_count')
            if  numEntered and numEntered > 0 and numEntered <= tonumber(countGift:getString()) then
                gainChips:setString(self.tool:convertAmountChinese(numEntered * self.config.listSellGifts[index]*80/100))
            else 
                event.target:setString("0")
                gainChips:setString("0")
            end
        elseif event.name == "INSERT_TEXT" then
            if self.account:strContainOnlyNum(event.target:getString()) == false then
                event.target:setString(event.target:getString())
            end
        elseif event.name == "DELETE_BACKWARD" then
            
        end
    end


    for i, var in pairs(self.config.listSellGifts) do
        local item = self['Panel_SellGift']:getChildByName('Panel_Item_'..i)
        item:getChildByName('Text_count'):setString(self.pData.gift[i+2])
        item:getChildByName('Text_price'):setString('0')
        
        local txf_count = item:getChildByName('TextField_count')
        txf_count:setString('0') 
        txf_count:setTag(i)
        txf_count:onEvent(onSetNumber)
        txf_count:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
        txf_count:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
        
        local button_add = item:getChildByName('Button_Add')
        local button_Minus = item:getChildByName('Button_Minus')
        button_add:setTag(i)
        button_Minus:setTag(i)
        button_add:onTouch(onAdd)
        button_Minus:onTouch(onMinus)
    end

end

--初始化2级窗口
function UIProfileSubViews:initSubView()
    self['Panel_Sub']:setVisible(true)

    local function onCloseSubView(event)
        if event.name == 'ended' then
            --self.app:removeView('UIProfileSubViews')
            if self.onCloseCB then self.onCloseCB() end
            LuaTools.viewAction1Over(self['Panel_Sub'],"UIProfileSubViews")
        end
    end
    -- hide all subview
    for i, var in ipairs(self.listSubView) do
        print(var)
        self[var]:setVisible(false)
    end
    
    local panel = self[self.listSubView[self.indexSel]]
    panel:setVisible(true)
    --bind close button
    local button_close =  panel:getChildByName('Button_Close')
    button_close:onTouch(onCloseSubView)
    
    local function onConfirm(event)
        if event.name == 'ended' then
            if self.indexSel == 1 then          --Panel_ClearEgg
                self:inPanelClearEgg(panel)
            elseif self.indexSel == 2 then         --Panel_Password
                self:inPanelPassword(panel)
            elseif self.indexSel == 3 then             --Panel_SellGift
                self:inPanelSellGift(panel)
            elseif self.indexSel == 4 then             --Panel_FindPwd
                self:inPanelFindPwd(panel)
            elseif self.indexSel == 5 then             --Panel_ChangePwd
                self:inPanelChangePwd(panel)
            elseif self.indexSel == 6 then             --Panel_SetPwd
                self:inPanelSetPwd(panel)
            end
        end
    end
    --bind confirm button
    self[self.listSubView[self.indexSel]]:getChildByName('Button_Confirm'):onTouch(onConfirm)
end

--请求清理鸡蛋
function UIProfileSubViews:inPanelClearEgg(panel)
    local countEgg = panel:getChildByName('TextField_ClearEgg'):getString()
    if countEgg == "" or countEgg == nil then
        self.tool:showTips('输入的鸡蛋个数')
        return
    end
    if self.account:strContainOnlyNum(countEgg) == false then
        self.tool:showTips('输入的鸡蛋个数有错误。')
        panel:getChildByName('TextField_ClearEgg'):setString("")
        return
    end
    
    if tonumber(countEgg) > self.pData.gift[2] then
        self.tool:showTips('你没有那么多鸡蛋。。。')
        return
    end

    local function onSucc(arg)
        
        self.pData.charm = arg.charm
        self.pData.coin = arg.coin
        self.pData.gift[2] = arg.gift['2']
        self.app:callMethod('UIProfileBag', 'updateGiftsCount')
        self.app:callMethod('UIProfileBag', 'updateBankMoney')
        self.app:callMethod('UIProfileBag','updateMoney')
        local parentPanel = self['Panel_ClearEgg']
        parentPanel:getChildByName('Text_eggCount'):setString(self.pData.gift[2])
        self.tool:showTips("清理鸡蛋成功！")
        if app:getView('UIMainTop') then 
            app:callMethod('UIMainTop','updateWealth' ) 
        end  
        self.app:removeView('UIProfileSubViews')
    end
    local function fail(arg)
        if arg.msg then
            self.tool:showAlert(arg.msg)
        end
    end
    local dataTable =     {
        ['uid']   = self.pData.uid,
        ['token']  = self.pData.token,
        ['num']      = countEgg,
        ['cmd']       = HttpHandler.CMDTABLE.GIFT_CLEAREGGS,
    }
    self.tool:fastRequest(dataTable, onSucc, fail)
end

--请求取钱
function UIProfileSubViews:inPanelPassword(panel)
    local pwd = panel:getChildByName('TextField_pwd'):getString()
    
    local function onSucc(arg)
                     --withdraw
            self.tool:showTips('取钱成功！')
            self.pData.bankPwd = pwd
            self.pData.coin = arg.coin
            self.pData.bank = arg.bank
            if self.app:getView('UIProfileBag') then
                self.app:callMethod('UIProfileBag','updateMoney')
            end
            self.app:callMethod('UIProfileInfos','updateProgressInfos')
            local viewNames = {
                'UIGameTable',
                'UIGameTableClassic',
                'UIGameTableDeZhou',
                'UIGameTableDouniu',
                'UIGameTablePaodekuai',
                'UIGameTableSanzhang',
                'UIGameTableShengji',
                'UIGameTableWanren',
            }
            for k,v in pairs(viewNames) do
                local view = self.app:getView(v)
                if view then
                    GameTableCommon.updatePlayerCoins(view, view.mySeatID, self.pData.coin, false, true)
                end
            end
            self.app:removeView('UIProfileSubViews')
    end
    local function fail(arg)
        if arg.msg then
            self.tool:showAlert(arg.msg)
        end
    end
	local dataTable =     {
    ['uid']   = self.pData.uid,
    ['token']  = self.pData.token,
    ['money']      = self.chipsVal,
    ['bankPwd']    = pwd,
    ['cmd']       = HttpHandler.CMDTABLE.BANK_DRAWMONEY,
    }
    self.tool:fastRequest(dataTable, onSucc, fail)

end

--请求售卖礼物
function UIProfileSubViews:inPanelSellGift(panel)
    local tab = {}
    local error = false
    for k = 1, #self.config.listSellGifts do
        local item = panel:getChildByName('Panel_Item_'..k)
        local count = item:getChildByName('TextField_count'):getString()
        local num = tonumber(count)
        if num and num > 0 then
            tab[tostring(k+2)] = num
        end  
        if num == nil then
        	error = true
        end  
    end
    if error == true then
        self.tool:showTips('输入的礼物个数有误。')
        return
    end
    local jsonTab = json.encode(tab)
    print("JSON.."..jsonTab)
    local function onSucc(arg)
        --withdraw
        self.tool:showTips("变卖礼物成功！")
        self.pData.coin = arg.coin
        dump(arg)
        --local value = json.decode(arg.gift)
        for i=1,#self.pData.gift do
            self.pData.gift[i] = arg.gift[tostring(i)]
        end
        --dump(self.pData.gift)
        if self.TcpCallBacks then 
            self.TcpCallBacks(arg.coin) 
        end     
        self.app:callMethod('UIProfileBag','updateGiftsCount')
        self.app:callMethod('UIProfileBag','updateMoney')
        self.app:callMethod('UIMainTop','updateWealth')
        self.app:removeView('UIProfileSubViews')
    end
    local function fail(arg)
        if arg.msg then
            self.tool:showAlert(arg.msg)
        end
    end
    local dataTable =     {
        ['uid']   = self.pData.uid,
        ['token']  = self.pData.token,
        ['gifts']      = jsonTab,
        ['cmd']       = HttpHandler.CMDTABLE.GIFT_SELL,
    }
    self.tool:fastRequest(dataTable, onSucc, fail)
end

--请求找回密码
function UIProfileSubViews:inPanelFindPwd(panel)
    local ans = panel:getChildByName('TextField_secretAnswer'):getString()
    local newpwd = panel:getChildByName('TextField_newpwd'):getString()
    local confpwd = panel:getChildByName('TextField_confirmPwd'):getString()
    --检测密码长度是否合格
    if #newpwd< 4 or #newpwd > self.account.pwdMaxLen then
        self.tool:showTips(self.account.pwdLenght4)
        return
    end
    --检测密码内容是否合格
    if false == self.account:strContainOnlyNumAndChar(newpwd) then
        self.tool:showTips(self.account.pwdError)
        return
    end
    --检测两次输入的密码是否一致
    if newpwd ~= confpwd then
        self.tool:showTips(self.account.pwdNotMatched)
        return
    end
    local function onSucc(arg)
        self.tool:showTips(arg.msg)
        self.pData.bankPwd = ''
        self.app:removeView('UIProfileSubViews')
    end
    local function fail(arg)
        if arg.msg then
            self.tool:showAlert(arg.msg)
        end
    end
    local dataTable =     {
        ['uid']   = self.pData.uid,
        ['token']  = self.pData.token,
        ['question']      = self.pData.bankQuestion,
        ['answer']    = ans,
        ['bankPwd']      = newpwd,
        ['phone']    = "",
        ['cmd']       = HttpHandler.CMDTABLE.BANK_FINDPWD,
    }
    self.tool:fastRequest(dataTable, onSucc, fail)
end

--请求修改密码
function UIProfileSubViews:inPanelChangePwd(panel)
    local oldpwd = panel:getChildByName('TextField_oldPwd'):getString()
    local newpwd = panel:getChildByName('TextField_NewPwd'):getString()
    local confirmpwd = panel:getChildByName('TextField_ConfirmPwd'):getString()
    
    --检测密码长度是否合格
    if #newpwd< 4 or #newpwd > self.account.pwdMaxLen then
        self.tool:showTips(self.account.pwdLenght4)
        return
    end
    --检测密码内容是否合格
    if false == self.account:strContainOnlyNumAndChar(newpwd) then
        self.tool:showTips(self.account.pwdError)
        return
    end
    --检测两次输入的密码是否一致
    if newpwd ~= confirmpwd then
        self.tool:showTips(self.account.pwdNotMatched)
        return
    end

    local function onSucc(arg)
        self.pData.bankPwd = ''
        self.tool:showTips(arg.msg)
        self.app:removeView('UIProfileSubViews')
    end
    local function fail(arg)
        if arg.msg then
            self.tool:showAlert(arg.msg)
        end
    end
    local dataTable =     {
        ['uid']   = self.pData.uid,
        ['token']  = self.pData.token,
        ['oldBankPwd']      = oldpwd,
        ['newBankPwd']    = newpwd,
        ['cmd']       = HttpHandler.CMDTABLE.BANK_CHANGEPWD,
    }
    self.tool:fastRequest(dataTable, onSucc, fail)
end

--请求设置密码
function UIProfileSubViews:inPanelSetPwd(panel)
    
    local pwd = panel:getChildByName('TextField_setbankpwd'):getString()
    local quest = panel:getChildByName('Text_ChooseQuest'):getString()
    local answ = panel:getChildByName('TextField_answer'):getString()
    
    --检测密码长度是否合格
    if #pwd< 4 or #pwd > self.account.pwdMaxLen then
        self.tool:showTips(self.account.pwdLenght4)
        return
    end
    --检测密码内容是否合格
    if false == self.account:strContainOnlyNumAndChar(pwd) then
        self.tool:showTips(self.account.pwdError)
        return
    end
    if self.indexQuestion == 0 then
        self.tool:showTips('请选择一个密保问题。')
        return
    end
    local function onSucc(arg)
        self.pData.isBankProtect = 1
        self.pData.bankPwd = ''
        self.pData.bankQuestion = self.indexQuestion
        self.tool:showTips(arg.msg)
        self.app:callMethod('UIProfileBag','switchBankState')
        self.app:removeView('UIProfileSubViews')
    end
    local function fail(arg)
        if arg.msg then
            self.tool:showAlert(arg.msg)
        end
    end
    local dataTable =     {
        ['uid']   = self.pData.uid,
        ['token']  = self.pData.token,
        ['bankPwd']    = pwd,
        ['question'] = self.indexQuestion,
        ['answer'] = answ,
        ['cmd']       = HttpHandler.CMDTABLE.BANK_SETPWD,
    }
    self.tool:fastRequest(dataTable, onSucc, fail)
    
end

return UIProfileSubViews