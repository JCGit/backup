local UIGiftExchange = class("UIGiftExchange", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
UIGiftExchange.RESOURCE_FILENAME = "UIGiftExchange.csb"
--UIGiftExchange.RESOURCE_PRELOADING = {"main.png"}
--UIGiftExchange.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIGiftExchange.RESOURCE_BINDING = {
    ["Button_close"] = {["ended"] = "backEvent"},
    ["Button_confirm"] = {["ended"] = "onOk"},
    }
function UIGiftExchange:backEvent(event)
    -- self:removeSelf()
    
    LuaTools.viewAction1Over(self['Panel_bg'],"UIGiftExchange")
end

function UIGiftExchange:onOk(event)
    
	local str = self['TextField_gcode']:getString()
	if #str == 0 then
		self.tool:showTips("兑换码不能为空！")
    	return 
	end
	self:requestExchangeGift(str)
end

function UIGiftExchange:onCreate()
    local app = self:getApp()
    self.app = app
    self.tool = app:getModel('Tools')
    self.pData = app:getData('PlayerData')
    self.config = app:getData('Config')
    self.account = app:getModel('Account')

    LuaTools.enterActionScaledWithMask(self['Panel_bg'])

    self['TextField_gcode']:setTextHorizontalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    self['TextField_gcode']:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    self['TextField_gcode']:setTextColor(self.config.Txf_textColor)
    self.account:handleTxfControl(self['TextField_gcode'])
end

function UIGiftExchange:requestExchangeGift(_code)
    local dataTable =     {
        ['uid']   = self.pData.uid,
        ['token']  = self.pData.token,
        ['code']      = _code,
        ['unionid']   = self.config.unionID,
        ['cmd']       = HttpHandler.CMDTABLE.GIFT_EXCHANGE,
    }
    local function succ(arg)
        local function cb()
            self:removeSelf()
        end
        local tips = self.app:addView("UITips", 65534,1)
        tips:setupDialog("提示","兑换成功！我们会在5个工作日内充值到对应的手机号码。祝您游戏愉快！", cb, cb)
    end
    local function fail(arg)
        if arg.msg then
            self.tool:showTips(arg.msg)
        end
        self.app:removeView('UIDialog')
    end
    self.tool:fastRequest(dataTable,succ, fail)
end

return UIGiftExchange