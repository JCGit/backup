local UIActivityAds = class("UIActivityAds", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
UIActivityAds.RESOURCE_FILENAME = "UIActivityAds.csb"

UIActivityAds.RESOURCE_BINDING = { 
    ["Button_close"]  = {["ended"] = "onClose"},
    ["PageView_bg"]   = { ["SCROLLING"] = "callback" }, 
   ["Button_jion"]    = {["ended"] = "jumpTo"},
    }

function UIActivityAds:onClose(event)
    self.app:removeView('UIActivityAds')

end

function UIActivityAds:onCreate(img, activeJumpTo)
    local app = self:getApp()
    self.app = app
    self.config = app:getData('Config')
    self.tool  = app:getModel('Tools')
    self.pData = self.app:getData('PlayerData')
    self.img = img
    self.poster = nil
    self.pointTag = 1
    self.activeJumpTo = activeJumpTo
    self:updateActiveBg()
    LuaTools.enterActionScaledWithMask(self['Panel_root'],function() print("打开成功")  end)
end    

--加载活动背景图
function UIActivityAds:updateActiveBg()
        if #self.img == 0 then
           self['Panel_1']:setVisible(true)
            print("暂无活动")
            return
        elseif  #self.img >0 then
            self['PageView_bg']:removeAllPages()
            for i=1,#self.img do 
                local tempPanel = self['Panel_mode']:clone()
                tempPanel:setBackGroundImage(self.img[i],ccui.TextureResType.localType)
                tempPanel:setVisible(true)
                tempPanel:setName("P_"..tostring(i))
                self['PageView_bg']:addPage(tempPanel)
            end
            --红点
            if #self.img>1 and #self.img <7 then 
                self['ListView_point']:setVisible(true) 
                for k=7,(#self.img+1),-1 do 
                    self['ListView_point']:getChildByName('Image_point'..k):setVisible(false)
                end     
                self['ListView_point']:getChildByName('Image_point1'):setColor(cc.c3b(255,0,0))
            end     
        end
end

--翻滚页面后的回调
function UIActivityAds:callback(args)
    if #self.img >1 then
        self["Button_jion"]:setVisible(false)
        print("正在进行翻页")
        local action = cc.Sequence:create(
               cc.DelayTime:create(0.3),
               cc.CallFunc:create(
               function() 
                    local num = self['PageView_bg']:getCurrentPageIndex()
                    if( num+1 ~= self.pointTag ) then
                        self['ListView_point']:getChildByName('Image_point'..(num+1)):setColor(cc.c3b(255,0,0))  
                        self['ListView_point']:getChildByName('Image_point'..self.pointTag):setColor(cc.c3b(255,255,255))
                        self.pointTag = num+1
                        -- self["Button_jion"]:setVisible(not (self.activeJumpTo[num+1]==""))
                    end
              end))
         self:runAction(action)
    else
      print("不用翻页")
    end
end

function UIActivityAds:jumpTo() 
    self.app:addView(self.activeJumpTo[self.pointTag],110) 
    LuaTools.viewAction1Over(self['Panel_Layer'],'UIActivityAds')
end

return  UIActivityAds