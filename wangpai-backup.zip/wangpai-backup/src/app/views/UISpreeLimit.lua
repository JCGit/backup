
local UISpreeLimit = class("UISpreeLimit", cc.load("mvc").ViewBase)
UISpreeLimit.RESOURCE_FILENAME = "UIPackage.csb"

local HttpHandler = require("app.network.HttpHandler")
UISpreeLimit.RESOURCE_PRELOADING = {"res_fund.png"}
UISpreeLimit.bt_LotteryNode = nil
--UISpreeLimit.RESOURCE_LOADING  = {["res/background/mohuBg.png"] = {names = {"Image_bgAll"}}}
UISpreeLimit.RESOURCE_BINDING = {
    ["Button_close"] = {["ended"] = "backEvent"}, 

    ["Image_touch"] = {["began"] = "touchFade"}, 

}

--printWarning
 

function UISpreeLimit:backEvent()
    --self:removeFromParent()   
	--if UISpreeLimit.bt_LotteryNode ~= nil then
		--UISpreeLimit.bt_LotteryNode:removeFromParent()
		--UISpreeLimit.bt_LotteryNode = nil
	--end
    self:stopSchedule('limitSpreeTime1')
    LuaTools.viewAction1Over(self['Panel_main'],'UISpreeLimit')  

end



function  UISpreeLimit:touchFade() 
    self.Image_touch:setTouchEnabled(false)
    self['Image_vipBubble']:setVisible(true)
    local fadeAction = cc.Sequence:create(
        cc.DelayTime:create(2),
        --cc.FadeOut:create(2),
        cc.CallFunc:create(function() self['Image_vipBubble']:setVisible(false)
            self.Image_touch:setTouchEnabled(true)
    end))

    self['Image_vipBubble']:runAction(fadeAction)
end

function UISpreeLimit:initUI(data)
    self.Image_touch:setTouchEnabled(true)
    local panelLottery = self['Panel_buyPos']
    panelLottery:onTouch(function(event) if event.name == 'ended' then         
      self.app:addView('UICharge',self:getLocalZOrder()+10,data)
    end end)
    UISpreeLimit.bt_LotteryNode = cc.CSLoader:createNode('Animation_Package.csb') 
    UISpreeLimit.bt_LotteryNode:setPosition(cc.p(panelLottery:getContentSize().width/2,panelLottery:getContentSize().height/2))
    
    local action = cc.CSLoader:createTimeline('Animation_Package.csb')
    UISpreeLimit.bt_LotteryNode:runAction(action)
    action:gotoFrameAndPlay(0,true)
    panelLottery:addChild(UISpreeLimit.bt_LotteryNode,1)


   self['Text_value']:setString(data.name or '') 
   self['BitmapFontLabel_now']:setString(data.price..'元')
   self['BitmapFontLabel_pre']:setString(data.oldprice..'元')

   self['Image_vipBubble']:getChildByName('Text_desc'):setString(data.description)
   self['Image_vipBubble']:getChildByName('Text_name'):setString(data.name)
   if data.icon and data.icon ~= '' then 
      local function onFinishTable(status,downloadedSize,dst)
        if status == "success" then
           --local  image  = ccui.ImageView:create(dst)  --cc.Sprite:create(dst)--
           self['Image_model']:loadTexture(dst,ccui.TextureResType.localType)
        end
      end
      local newName = data.icon
      LuaTools.getFileFromUrl({
         url = data.icon,
         destFile = (newName:gsub("/","_")),
         onFinishTable = onFinishTable
         })
   end 
end

function UISpreeLimit:onCreate(time) 
    self.app = self:getApp() 
    self.tool = self.app:getModel('Tools')
    self.config = self.app:getData('Config')

    self.PlayerData = self.app:getData('PlayerData')

    self.Image_touch:setPressedActionEnabled(false)
    local function  cb()
      local dataTable =     {
          ['uid']    = self.PlayerData.uid,
          ['token']  = self.PlayerData.token,
          ['cid']    = 7,
          ['cmd']    = HttpHandler.CMDTABLE.GET_PRODUCT,
      }
      local function succ(arg)
          --self:parseProductData(arg)
          -- dump(arg,'礼包内容')
          self.chargeInfo = arg.products[1]
          self:initUI(self.chargeInfo)
      end
      local function fail(arg)
          if arg.msg then
              self.tool:showAlert(arg.msg)
          end
      end
      self.tool:fastRequest(dataTable,succ, fail)
    end     
    LuaTools.enterActionScaledWithMask(self['Panel_main'],cb)

    local function  callback()    
            local hour   = math.floor(time/3600)   
            local minute = math.floor( (time-hour*3600)/60)
            local second = time - minute*60 - 3600*hour
            local temp = string.format("%02d:%02d:%02d",hour,minute,second) 
            self['FontLabel_time']:setString(temp)
            --delegate['Button_rewardBox']:setEnabled(time<=0)
            time = time -1
            self.limitSpreeTimeLeft = time 
            if time <= 0 then 
               self:stopSchedule('limitSpreeTime1')
            end  
    end 
    self:createSchedule("limitSpreeTime1", callback, 1)  


 end
 

return UISpreeLimit
