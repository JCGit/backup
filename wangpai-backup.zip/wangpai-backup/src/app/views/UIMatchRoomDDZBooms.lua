local UIMatchRoomDDZBooms = class("UIMatchRoomDDZBooms", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
UIMatchRoomDDZBooms.RESOURCE_FILENAME = "UIMatchRoomDDZBooms.csb"
UIMatchRoomDDZBooms.RESOURCE_PRELOADING = {"res_gametypes.png"}
--UIMatchRoomDDZBooms.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIMatchRoomDDZBooms.RESOURCE_BINDING = {  
    ["Button_QuickStart"] = {["ended"] = "onQuickStart"},
    ["Button_switchLeft"] = {["ended"] = "onSwitchLeft"},
    ["Button_switchRight"] = {["ended"] = "onSwitchRight"},
    ["Button_chargeGem"]     = {["ended"] = "enterChargeDiamond"},
}

--[=================斗地主场次================]--

local MOVE_DURATION = 0.2 

--进入充值砖石
function UIMatchRoomDDZBooms:enterChargeDiamond()
    if not G_BASEAPP:getView('UIQuickBuy') then 
        G_BASEAPP:addView('UIQuickBuy', 1200,function(arg) 
            self['Text_myMoney']:setString(LuaTools.convertAmountChinese(self.pData.coin))
        end) 
    end     
end

function UIMatchRoomDDZBooms:enterCharge() 
    if not G_BASEAPP:getView('UIShopDiamond') then 
        G_BASEAPP:addView('UIShopDiamond', 1200,function(arg) 
            self['Text_myMoney']:setString(LuaTools.convertAmountChinese(self.pData.coin))
        end) 
    end   
end     


--检测金币对否小于0，并且是否该弹出充值
function UIMatchRoomDDZBooms:checkChips()
    if tonumber(self.pData.coin) <= 0 then
        local function onConfirm()
            if self.pData.gem > 0 then 
                self:enterChargeDiamond()
            else 
                self:enterCharge() 
            end  
        end
        local dlg = self.app:addView('UIDialog', self:getLocalZOrder() + 1, nil, true)
        dlg:setupDialog('金币不足', Constants.STRING_NO_MONEY, onConfirm, nil, false)
        return false
    end
    return true
end

--点击快速开始
function UIMatchRoomDDZBooms:onQuickStart()   
    if self.startMove == true then return end 
    if self:checkChips() == false then return end
    --判断该进入哪一个场次
    local dataRoom = self:getDataRoomsSelected()
    local myChips = tonumber(self.pData.coin)
    local indexRoom = 0
    local data = self:getDataRoomsSelected()
    if data == nil then return end
    for i = #data, 1, -1 do
        local max = dataRoom[i].max
        local min = dataRoom[i].min
        indexRoom = i
       if myChips >= min and max < 0 then     
            break
       elseif max > 0 and myChips <= max and myChips >= min then 
            break
       end
    end
    self:enterRoom(indexRoom)
end

--检测金币是否足够进入该场次
function UIMatchRoomDDZBooms:checkEnabledEnterRoom(_index)
    local myChips = tonumber(self.pData.coin)
    local dataRoom = self:getDataRoomsSelected()
    local max = dataRoom[_index].max
    local min = dataRoom[_index].min
     if myChips >= min and max < 0 then     
            return 'ok'
       elseif max > 0 and myChips <= max and myChips >= min then 
            return 'ok'
        elseif max > 0 and myChips > max then 
            return 'tooMuch'
        elseif min > 0 and myChips < min then
            return 'notEnough'
       end
    return 'notOk'
end

--根据已选择的场次进入对应的游戏
function UIMatchRoomDDZBooms:enterRoom(_index)
    if #self.pData.gamePorts[tostring(1)] == 0 then
        self.tool:showTips("无法获取房间信息。")
        print("NO PORTS FOUND.")
        return
    end
    local dataRoomName = self.gameDataSel.dataName
    local dataRoom = self:getDataRoomsSelected()
    --dump(dataRoom,'ppppppppppppppppppppppppppppp')
   local viewName = self.gameDataSel.viewName --UIGameTable
   local siteid = dataRoom[_index].siteid
   local roomId = dataRoom[_index].roomid
   local port =  self.pData:getGamePort(siteid)
    
    self:printRoomData(dataRoomName, viewName, siteid, roomId, port)
    
    local table = {}

    if dataRoomName == 'GameType_DDZ' then
        -- if self.pData.bitcheckCaiNiao == 0 and self.pData.vip_level < 1  then 
        --     roomId = -1 
        -- end    
        table['tableType'] = siteid
        table['RoomLevel'] = roomId
    elseif  dataRoomName == 'GameType_QDZ' then
        table['tableType'] = siteid
        table['RoomLevel'] = roomId
    end
    table['port'] = port
   if #viewName > 0 then
   -- local load = G_BASEAPP:addView("UILoading",200)  
   --  G_LOADINGVIEW = load
   --  load:setLoadingType(true)
   --  load:setNextAction(function()
   --      G_BASEAPP:addView(viewName,500,table)  
   --  end)
   --  load:startProgress()
        G_BASEAPP:addView(viewName,500,table)  

    else
         self.tool:showTips("暂时无法进入该游戏场")
    end
end

--打印数据
function UIMatchRoomDDZBooms:printRoomData(dataname, viewname, siteId, roomId, port)
    local tb = {
        dataname = dataname,
        viewname = viewname,
        siteId = siteId,
        roomId = roomId,
        port = port,
    }
    dump(tb,"RoomData")
end

--获取已选择的场次的数据表
function UIMatchRoomDDZBooms:getDataRoomsSelected()
    local dataRoomName = self.gameDataSel.dataName
    return self.pData.GameTypes[dataRoomName]
end

--展示进入动作
function UIMatchRoomDDZBooms:showEnterActions()
    if self.actionShowed == true then return end
    self.actionShowed = true
    --background actions
    local maskLayer = cc.LayerColor:create(cc.c4b(255,255,255,0))
    self['Panel_main']:addChild(maskLayer)
    maskLayer:runAction(cc.Sequence:create(
        cc.FadeTo:create(0.4, 50),
        cc.FadeTo:create(0.2, 0),
        cc.CallFunc:create(function() maskLayer:removeFromParent() end)
        ,nil))

    
    self['Panel_bgd']:runAction(cc.FadeTo:create(0.6,255))

    --widgets actions
    local btstart = self['Button_QuickStart']
    local moveIn = cc.MoveTo:create(0.6,cc.p(btstart:getPositionX(),72))
    local move_ease_out = cc.EaseBackOut:create(moveIn)
    btstart:runAction(move_ease_out)

    local panelTop = self['Panel_top']
    local moveIn2 = cc.MoveTo:create(0.6,cc.p(panelTop:getPositionX(),cc.Director:getInstance():getWinSize().height))
    local move_ease_out2 = cc.EaseBackOut:create(moveIn2)
    panelTop:runAction(move_ease_out2)

    --buttons actions
    local acts = {
        {obj = self['Panel_qdz'], x = 267.7},
        {obj = self['Panel_bsc'], x = 875.5},
        {obj = self['Button_switchLeft'], x = 59.5},
        {obj = self['Button_switchRight'], x = 1089},
    }
    for i,v in ipairs(acts) do
        local moveIn = cc.MoveTo:create(0.9,cc.p(v.x,v.obj:getPositionY()))
        local move_ease_out = cc.EaseBackOut:create(moveIn)
        v.obj:runAction(move_ease_out)
    end 
    
    local panelDdz = self['Panel_jd']
    local act = cc.Sequence:create(
        cc.ScaleTo:create(0.01, 0),
        cc.CallFunc:create(function() panelDdz:setVisible(true) end),
        cc.ScaleTo:create(0.5, 1.1),
        cc.ScaleTo:create(0.24,1)
        ,nil)
    panelDdz:runAction(act)

    
end

function UIMatchRoomDDZBooms:showListviewEnterActions()
        --listview items actions
       

    local listview = self['ListView_type']

    local function moveBackAfter(delay, byX)
        local backVal = 80
        if byX < 0 then
            backVal = -backVal
        end
         local moveIn = cc.MoveBy:create(delay,cc.p(byX+backVal,0))
         local moveOff = cc.MoveBy:create(0.2,cc.p(-backVal,0))
         return cc.Sequence:create(moveIn, moveOff)
    end

    for i,item in ipairs(listview:getChildren()) do
        local moveIn = cc.MoveBy:create(0.4,cc.p(-self.winWidth,0))
        local move_ease_in = cc.EaseBackOut:create(moveIn)
    --    item:runAction(cc.Sequence:create(cc.DelayTime:create(i/10+0.13),move_ease_in,nil))
        item:runAction(cc.Sequence:create(cc.DelayTime:create(i/10+0.2),moveBackAfter(0.25,-self.winWidth),nil))
    end
end

function UIMatchRoomDDZBooms:onExit()
    -- body
    printf('UIMatchRoomDDZBooms:onExit() self.onExiting:%s, self.isEnterGameRoom:%s',self.onExiting, self.isEnterGameRoom)
    if self.onExiting == nil then 
        self.onExiting = true
        if self.isEnterGameRoom == nil then
            self.app:callMethod('UIMain', 'showEnterMainActions')
        end
    end
end

function UIMatchRoomDDZBooms:onCreate()
    local app = self:getApp()
    self.app = app
    --LuaTools.viewAction2(self['Panel_main'])
    self.pData = app:getData('PlayerData')
    self.tool = app:getModel('Tools')
    --self.sound = app:getModel('Sound')
    self.config = app:getData('Config')
    self.winWidth = cc.Director:getInstance():getWinSize().width
    self.startMove = false
    self.gameDataSel = {}

    self.typeSelected = 0
    self.actionShowed = false
	
    --cc.SpriteFrameCache:getInstance():addSpriteFrames("res_gametypes.plist")

    self.imgTypes = {qdz = "res_gametypesDDZ/img_qdz_", jdc = "res_gametypesDDZ/img_jd_"}
    self.roomTitle = "res_gametypesDDZ/img_room_"
 
    self.buttons = {
        {obj = self["Panel_qdz"],  data = self.config.keyDataGames.qdz},
        {obj = self["Panel_jd"],     data = self.config.keyDataGames.ddz},
        {obj = self["Panel_bsc"],       data = {}},
    }


    self:initUI()
    if self.pData.onlinePlayerNumber ~= 0 then 
        self:updatePlayerCounts(self.pData.onlinePlayerNumber)
    end     
end

--初始化场次UI
function UIMatchRoomDDZBooms:initUI()
	cc.SpriteFrameCache:getInstance():addSpriteFrames("res_gametypes.plist")
    self['ListView_type']:setScrollBarEnabled(false)
    local function onSwithType(event)
        if event.name == 'began' then
        elseif event.name == 'ended' then
            local index = event.target:getTag()
            if index == self.typeSelected or self.startMove == true then
                return
            end
            if event.target:getName() == "bsc" then
                LuaTools.showAlert("比赛场还没有开放哦")
                return
            end
            self.startMove = true
            self:showType(index)
        end
    end
    local function onClose(event)
        if event.name == 'began' then
        elseif event.name == 'ended' then
             
            -- self.app:callMethod('UIMain', 'showEnterMainActions')
            self:removeSelf()
            --LuaTools.viewAction2Over(self['Panel_main'],'UIMatchRoomDDZBooms')
        end
    end
    self['Button_close']:onTouch(onClose)
    self['Panel_main']:setTouchEnabled(true)
    self['Panel_main']:onTouch(onClose)
    self['Text_myMoney']:setString(LuaTools.convertAmountChinese(self.pData.coin))
    self['Button_QuickStart']:setPressedActionEnabled(false)
    self['Panel_jd']:setVisible(false)
    self['Panel_bgd']:setOpacity(0)

    local names = {"qdz", "jdc", "bsc"}
    for i, v  in ipairs(self.buttons) do
        local bt = v.obj
        bt:onTouch(onSwithType)
        bt:setTag(i)
        bt:setName(names[i])
        bt:setLocalZOrder(2)
        bt:setScale(0.8)  --初始化大小
        --bt:setColor(cc.c3b(125,125,125)) --初始化颜色
    end

    self:showType(2)
    self:highlightItem()
end

function UIMatchRoomDDZBooms:moveButtons(_index)
    local function updateTag()
        for i, v  in ipairs(self.buttons) do
            v.obj:setTag(i)
        end
    end
    local function switchTableOrder(_left) --update tag of each items
        if _left == true then
            local temp = self.buttons[1]
             for i=1, #self.buttons do
                if i == #self.buttons then 
                    self.buttons[i] = temp
                else
                    self.buttons[i] = self.buttons[i+1]
                end
            end
        else
             local temp, temp2
             for i=1, #self.buttons do
                if i == 1 then 
                    temp = self.buttons[i]
                    self.buttons[i] = self.buttons[#self.buttons]
                else
                    temp2 = self.buttons[i]
                    self.buttons[i] = temp
                    temp = temp2
                end
            end
        end
        
    end
    local function move(_left)
        for i, v  in ipairs(self.buttons) do
        local moveto
        local bt
        if _left == true then 
            bt = self.buttons[#self.buttons - i +1].obj
            if i== #self.buttons then
                bt:setLocalZOrder(1)
                moveto = cc.MoveTo:create(MOVE_DURATION, cc.p(self.buttons[#self.buttons].obj:getPositionX(),bt:getPositionY()))
            else
                bt:setLocalZOrder(2)
                moveto = cc.MoveTo:create(MOVE_DURATION, cc.p(self.buttons[#self.buttons - i].obj:getPositionX(),bt:getPositionY()))
            end
        else
            bt = v.obj
            if i== #self.buttons then
                bt:setLocalZOrder(1)
                moveto = cc.MoveTo:create(MOVE_DURATION, cc.p(self.buttons[1].obj:getPositionX(),bt:getPositionY()))
            else
                bt:setLocalZOrder(2)
                moveto = cc.MoveTo:create(MOVE_DURATION, cc.p(self.buttons[i+1].obj:getPositionX(),bt:getPositionY()))
            end
        end
        bt:runAction(moveto)
        end
        self:runAction(
            cc.Sequence:create(
            cc.DelayTime:create(MOVE_DURATION), 
            cc.CallFunc:create(function() 
                self.startMove = false 
                self:highlightItem()
                end),nil)
            )
    end
    if _index < self.typeSelected then --move selected item to the right
        move(false)
        switchTableOrder(false)
    elseif _index > self.typeSelected then --move selected item to the left
        move(true)
        switchTableOrder(true)
    end
    updateTag()
end

--点亮已选中的按钮
function UIMatchRoomDDZBooms:highlightItem()
    self.typeSelected = 2
    local bt = self.buttons[self.typeSelected].obj
    bt:setScale(1)
    --bt:setColor(cc.c3b(255,255,255))
    bt:getChildByName('Image_title'):setColor(cc.c3b(255,0,0))
    self.gameDataSel = self.buttons[self.typeSelected].data
    --dump(self.gameDataSel)
    if self.gameDataSel.dataName == nil or #self.gameDataSel.dataName == 0 then
        self['ListView_type']:removeAllChildren()
        return
    end
    self.app:callMethod("UIMain", "loadGameRoomsInfos", self.gameDataSel,
        function() 
            self:initRooms(self:getDataRoomsSelected())
            self:startUpdateCounts()
            self:showEnterActions()
        end,
        function()
            -- self.app:callMethod('UIMain', 'showEnterMainActions')
            -- self:removeSelf()
        end)
end

--显示按钮
function UIMatchRoomDDZBooms:showType(_index)
    print('index: '.._index..'  typeSel: '..self.typeSelected)

    if self.typeSelected > 0 then 
        local bt = self.buttons[self.typeSelected].obj
        bt:setScale(0.8)
        --bt:setColor(cc.c3b(125,125,125))
        bt:getChildByName('Image_title'):setColor(cc.c3b(255,255,255))
        self:moveButtons(_index)
        --dump(self.buttons[self.typeSelected].data, "JAJAJA")
        
    end 
end

--向左切换按钮
function UIMatchRoomDDZBooms:onSwitchLeft()
    if self.startMove == true then return end
    if self.buttons[self.typeSelected-1].obj:getName() == "bsc" then
        LuaTools.showAlert("比赛场还没有开放哦")
        return
    end
    self.startMove = true
    self:showType(self.typeSelected-1)
end

--向右切换按钮
function UIMatchRoomDDZBooms:onSwitchRight()
    if self.startMove == true then return end
    if self.buttons[self.typeSelected+1].obj:getName() == "bsc" then
        LuaTools.showAlert("比赛场还没有开放哦")
        return
    end
    self.startMove = true
    self:showType(self.typeSelected+1)
end

--初始化场次UI
function UIMatchRoomDDZBooms:initRooms(_array)
    --dump(_array,self.gameDataSel.dataName
    self['ListView_type']:setScrollBarEnabled(false)
    local listview = self['ListView_type']
    local itemModel
    local roomType = self.buttons[self.typeSelected].obj:getName()
    --"qdz", "jdc", "bsc"
    if roomType == 'qdz' then
        itemModel = self['Panel_Item_qdz']
    elseif roomType == 'jdc' then
        itemModel = self['Panel_Item_jdc']
    else

    end
    itemModel:setVisible(false)
    print("ROOM TYPE: "..roomType)
    listview:setItemModel(itemModel)
    listview:setBounceEnabled(false)
    listview:setScrollBarEnabled(false)
    listview:setBackGroundColorOpacity(0)
    itemModel:setBackGroundColorOpacity(0)
    listview:removeAllChildren()

    local function onEnterRoom(event)
        if event.name == 'began' then
        elseif event.name == 'ended' then
           if self:checkChips() == false then return end
           local tag = event.target:getTag()
           local result = self:checkEnabledEnterRoom(tag)
           if result == 'ok' then
                self:enterRoom(tag)
            elseif result == 'tooMuch' then
                self.tool:showTips('金币超限，请移步更高级场次游戏')
            elseif result == 'notEnough' then
                self.tool:showTips('进入房间失败，快去商城里购买金币吧')
                G_BASEAPP:callMethod('UIMainBottom','showDifferentView',function() self['Text_myMoney']:setString(LuaTools.convertAmountChinese(self.pData.coin)) end )
            else
                self.tool:showTips('您的金币不符合进入房间的条件！')
           end
        end
    end
    -- print('aaaaaaaaaaaaaaaaaaaaaaaa')
     dump(_array,'斗地主场次配置信息')

    local positionTemp = {}
    local showTemp = {}

    for key ,var in ipairs(_array) do
        listview:pushBackDefaultItem()
        local item = listview:getItem(key-1) 
        local dataRoom = self:getDataRoomsSelected()
        local infos = dataRoom[key]
        item:getChildByName('Image_character'):loadTexture(self.imgTypes[roomType]..key..'.png', ccui.TextureResType.plistType)
        item:getChildByName('Image_roomName'):loadTexture(self.roomTitle..key..'.png', ccui.TextureResType.plistType)
      --  item:getChildByName('Image_show1'):loadTexture('common/hd.png',ccui.TextureResType.plistType)
        item:getChildByName('Image_character'):setScale(1,1)
        item:getChildByName('Text_difen'):setString('底分: '..infos.base)
        local desc
        if infos.max > 0 and infos.min < 0 then     
            desc = LuaTools.convertAmountChinese(infos.max).."以下"
        elseif infos.max < 0 and infos.min > 0 then
            desc = LuaTools.convertAmountChinese(infos.min).."以上"
        elseif infos.max > 0 and infos.min > 0 then
            desc = LuaTools.convertAmountChinese(infos.min)..'-'..LuaTools.convertAmountChinese(infos.max).."准入"
        else
            desc = "无限制"
        end
        item:getChildByName('Text_count'):setString('人数: 0')
        item:getChildByName('Text_desc'):setString(desc)
        item:setTag(key)
       
        --wxyTest
        
        item:getChildByName('Image_hot'):setVisible(infos.hot)
        item:getChildByName('Image_activity'):setVisible(infos.activity)
        item:getChildByName('Image_awardbox'):setVisible(infos.awardbox)

        table.insert(positionTemp,item:getChildByName('Image_hot'):getPositionY())
        table.insert(positionTemp,item:getChildByName('Image_activity'):getPositionY())
        table.insert(positionTemp,item:getChildByName('Image_awardbox'):getPositionY())
      
        if infos.hot then
            table.insert(showTemp,"hot")
        end
        if infos.activity then
            table.insert(showTemp,"activity")
        end
        if infos.awardbox then
            table.insert(showTemp,"awardbox")
        end

        for i=1,#showTemp do
            local temp ="Image_"..showTemp[i]
            item:getChildByName(temp):setPositionY(positionTemp[i])
        end
        showTemp = {}
        positionTemp ={}

        item:setTouchEnabled(true)
        item:onTouch(onEnterRoom)
        self['Text_task']:setVisible(false)

        -- if self.pData.bitcheckCaiNiao == 1 or  tonumber(self.pData.vip_level) > 0 then 
        --     if key == 1 then 
        --        item:setTouchEnabled(false) 
        --        item:getChildByName('Image_character'):setColor(cc.c3b(127,127,127))
        --        item:getChildByName('Image_bgd'):setColor(cc.c3b(127,127,127))
        --        item:getChildByName('Image_roomName'):setColor(cc.c3b(127,127,127))
        --        item:getChildByName('Image_4'):setColor(cc.c3b(127,127,127))
        --        item:getChildByName('Text_difen'):setColor(cc.c3b(127,127,127))
        --        item:getChildByName('Text_count'):setColor(cc.c3b(127,127,127))
        --        item:getChildByName('Text_desc'):setColor(cc.c3b(127,127,127))

        --        item:getChildByName('Image_hot'):setColor(cc.c3b(127,127,127))
        --        item:getChildByName('Image_activity'):setColor(cc.c3b(127,127,127))
        --        item:getChildByName('Image_awardbox'):setColor(cc.c3b(127,127,127))
        --     else 
        --        item:setTouchEnabled(true)
        --        item:onTouch(onEnterRoom)
        --     end    
        --     self['Text_task']:setVisible(false)
        -- else 
        --     self['Text_task']:setVisible(true)
        --     if key == 1 then 
        --        item:setTouchEnabled(true)
        --        item:onTouch(onEnterRoom)
        --     else 
        --        item:setTouchEnabled(false) 
        --        item:getChildByName('Image_character'):setColor(cc.c3b(127,127,127))
        --        item:getChildByName('Image_bgd'):setColor(cc.c3b(127,127,127))
        --        item:getChildByName('Image_roomName'):setColor(cc.c3b(127,127,127))
        --        item:getChildByName('Image_4'):setColor(cc.c3b(127,127,127))
        --        item:getChildByName('Text_difen'):setColor(cc.c3b(127,127,127))
        --        item:getChildByName('Text_count'):setColor(cc.c3b(127,127,127))
        --        item:getChildByName('Text_desc'):setColor(cc.c3b(127,127,127))

        --        item:getChildByName('Image_hot'):setColor(cc.c3b(127,127,127))
        --        item:getChildByName('Image_activity'):setColor(cc.c3b(127,127,127))
        --        item:getChildByName('Image_awardbox'):setColor(cc.c3b(127,127,127))

        --     end    
        -- end     


        item:runAction(cc.Sequence:create(
         cc.MoveBy:create(0.1,cc.p(self.winWidth,0)),
         cc.CallFunc:create(function() item:setVisible(true) end)
         ,nil))
    end 

    self:showListviewEnterActions()


end

--启动更新玩家个数
function UIMatchRoomDDZBooms:startUpdateCounts()
    self.app:callMethod('UIMain','reqSock_getOnliner')
    self:createSchedule("updateCounts",function()
        self.app:callMethod('UIMain','reqSock_getOnliner')
    end,self.config.refreshPlayerCountsDelay)
end

--更新玩家个数
function UIMatchRoomDDZBooms:updatePlayerCounts(_table)
   -- dump(_table)
   -- _table['1']['0'] = 10
   -- _table['1']['3'] = 88
   -- _table['18']['0'] = 55
   -- _table['18']['3'] = 11
   -- dump(self.pData.GameTypes[self.type])
   print("Updating DDZ rooms players count...")
   local items = self['ListView_type']:getChildren()
   local data = self:getDataRoomsSelected()
   if data == nil then return end
    for i,v in ipairs(data) do
        local count = _table[tostring(v.siteid)][tostring(i-1)]
        --print('counts: '..count)
        --self['Panel_main']:getChildByTag(i):getChildByName('Text_count'):setString(count)
        items[i]:getChildByName('Text_count'):setString('人数: '..count)
    end
end

--更新金币
function UIMatchRoomDDZBooms:updatePlayerCoin(_coin)
    _coin = _coin or self.pData.coin
    self['Text_myMoney']:setString(LuaTools.convertAmountChinese(self.pData.coin))
end

return UIMatchRoomDDZBooms
