local UIHelpSanzhang= class("UIHelpSanzhang", cc.load("mvc").ViewBase)
UIHelpSanzhang.RESOURCE_FILENAME = "UIHelpSanzhang.csb"
local HttpHandler = require("app.network.HttpHandler")

UIHelpSanzhang.RESOURCE_BINDING = { 
      ["Panel_main"] = {["ended"] = "hideAll"}, 

}

function UIHelpSanzhang:onCreate()
    local app = self:getApp()
    self.app = app
    self.config = app:getData('Config')
    self.tool = app:getModel('Tools')
    self.pData = app:getData('PlayerData') 
    
    self.sizes = self['Panel_root']:getContentSize()
    local move = cc.MoveBy:create(0.3,cc.p(self.sizes.width,0))
    self['Panel_root']:runAction(move)

end

function UIHelpSanzhang:hideAll()
    self.app:removeView('UIHelpSanzhang')
end     

return UIHelpSanzhang








