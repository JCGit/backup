local UIHelpPointRule= class("UIHelpPointRule", cc.load("mvc").ViewBase)
UIHelpPointRule.RESOURCE_FILENAME = "UIHelpPointRule.csb"
local HttpHandler = require("app.network.HttpHandler")

UIHelpPointRule.RESOURCE_BINDING = { 
}

--初始化积分规则
function UIHelpPointRule:onCreate()
    local app = self:getApp()
    self.app = app
    self.config = app:getData('Config')
    self.tool = app:getModel('Tools')
    self.pData = app:getData('PlayerData')
    self.account = app:getModel('Account')
	self:setSkipGoBack(true )
    self.pContentSel = self['Panel_2']
    self:initAccuRulesView()
end

function UIHelpPointRule:getPanelMain()
    return self['Panel_main']
end

function UIHelpPointRule:transitionViewAction(_action)
   self:runAction(_action:clone())
end

function UIHelpPointRule:initAccuRulesView()
    local str_1 = "每充值1元获取10个积分\n连续5天以上登陆获取2个积分其他送1个积分\n铜卡VIP用户每次登陆额外奖励2个积分\n金卡VIP用户每次登陆额外奖励4个积分\n白金卡VIP用户每次登陆额外奖励6个积分"
    local str_2 = "积分商城可以兑换VIP卡及喇叭卡等道具.\n根据物品不同,兑换物品所需积分值也有所区别."
    local scrollView = self.pContentSel:getChildByName('ScrollView_content')
    scrollView:getChildByName('Text_1'):setString(str_1)
    scrollView:getChildByName('Text_2'):setString(str_2)
end

return UIHelpPointRule








