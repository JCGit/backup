local UIShopVip = class("UIShopVip", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
UIShopVip.RESOURCE_FILENAME = "UIShopVip.csb"
--UIShopVip.RESOURCE_PRELOADING = {"main.png"}
--UIShopVip.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIShopVip.RESOURCE_BINDING = {
    --["Button_start"] = {["ended"] = "enterTest"},
}


function UIShopVip:onCreate()
    local app = self:getApp()
    self.app = app
    self.tool = app:getModel('Tools')
    self.pData = self.app:getData('PlayerData')
    self:setSkipGoBack(true )
    self['Image_bgd']:setVisible(false)
    self.panelMain = self['Panel_main']
    self.panelMain:setVisible(false)
    self:setVisible(false)
end

function UIShopVip:getPanelMain()
    return self['Panel_main']
end

function UIShopVip:init()
    if #self.pData.shopVip == 0 then
        self:requestGetProduct()
    else
        self:initProductList()
    end
    self:setVisible(true)
end

function UIShopVip:initProductList()
    local function onBuy(event)
        if event.name == 'ended' then
            local indexSel = event.target:getTag()
            local data = self.pData.shopDiamonds[indexSel]
            if self.pData.paytotal and tonumber(self.pData.paytotal) > 0 then 
                data.rate = 0 
            end     
            local isCoins =  tonumber(data.gem > 0) and false or true 
            payValue = nil

            local function onPaySuccess()
                self['Text_myDiamond']:setString(self.tool:convertAmountChinese(self.pData.gem))
                if self.onSuccCb then
                    self.onSuccCb()
                end
            end
            self.app:addView('UICharge',self:getLocalZOrder()+10, data, onPaySuccess)
        end
    end
    local  logoBg = {'res_shop/01.png','res_shop/new9.png','res_shop/02.png','res_shop/03.png',
                     'res_shop/04.png','res_shop/05.png','res_shop/06.png','res_shop/07.png'}

    local extraBg = {'res_shop/new7.png','res_shop/new8.png'}
    self.ListView_Items:setItemModel(self['Panel_Row'])
    local logoTag = 3
    for i = 1,(#self.pData.shopDiamonds/4+1) do  
        self.ListView_Items:pushBackDefaultItem()
        local model = self.ListView_Items:getItem(i-1)
        model:setVisible(true)
        model:setBackGroundColorOpacity(0)
        for key = 1,4 do 
            if self.pData.shopDiamonds[i*4+key-4] then 
                local item = model:getChildByName('Panel_Item_'..key)
                item:setVisible(true)
                local var = self.pData.shopDiamonds[i*4+key-4]
                local bt = item:getChildByName('Button_buy')
                bt:setTitleText('¥'..var.price)
                bt:onTouch(onBuy)  
                bt:setTag(i*4+key-4)
                item:getChildByName('Image_hot'):setVisible(tonumber(var.gem) > 0 and (var.isFirst)) 
                
                local newImage  = ''
                local nameMoney,extraName,isFir  = '','',''
                if tonumber(var.coins) > 0 then
                    newImage = logoBg[1]
                    nameMoney = var.coins
                    if tonumber(var.active) > 0 then 
                        item:getChildByName('Text_more'):setString(self.tool:convertAmountChinese(var.active))
                        item:getChildByName('Image_showCoin'):loadTexture(extraBg[1],ccui.TextureResType.plistType)
                    end     
                    item:getChildByName('AtlasLabel_chipsCount'):setString(var.coins)
                    if var.isFirst and var.first > 0 then 
                       isFir = '(首购加赠'..self.tool:convertAmountChinese(var.first)..'金币)'
                    end     
                elseif tonumber(var.gem) > 0 then
                    newImage  = logoBg[logoTag] or logoBg[8]
                    logoTag   = logoTag + 1 
                    nameMoney = var.gem..'元宝'
                    if tonumber(var.active) > 0 then 
                        item:getChildByName('Text_more'):setString(var.active)
                        item:getChildByName('Image_showCoin'):loadTexture(extraBg[2],ccui.TextureResType.plistType)
                    end 
                    if var.isFirst and var.first >0  then 
                       isFir = '(首购加赠'..var.first..'元宝)'
                    end 
                elseif var.ticket and  tonumber(var.ticket) > 0 then 
                    nameMoney = var.ticket..'张'
                    newImage  = logoBg[2]
                    item:getChildByName('Text_more_0'):setString('')
                    item:getChildByName('Text_more'):setString('大奖赛使用')
                    item:getChildByName('Image_showCoin'):setVisible(false)  
                end
                item:getChildByName('Image_chips'):loadTexture(newImage, ccui.TextureResType.plistType)
                item:getChildByName('AtlasLabel_chipsCount'):setString(nameMoney)
                item:getChildByName('Text_first'):setString(isFir) 
                item:getChildByName('Image_first'):setVisible(isFir ~= '') 
                item:getChildByName('Image_hot'):setVisible(var.rate >0) 

                
                local vipTab = {'VIP周卡x1','VIP月卡x1','VIP半年卡x1'}
                if tonumber(var.vip)> 0 then                     --  
                    local str1,str2,str3 = vipTab[tonumber(var.vip)] ,'踢人卡x'..var.tiren,'喇叭卡x'..var.laba
                    self:addExtraBg(str1,str2,str3,item)
                end 
            end     
        end     
    end
    self.panelMain:setVisible(true)

end


function UIShopVip:addExtraBg(t1,t2,t3,pan)
    local model = self['Panel_addBg']:clone()
    model:getChildByName('Text_reward1'):setString(t1)
    model:getChildByName('Text_reward2'):setString(t2)
    model:getChildByName('Text_reward3'):setString(t3)
    pan:addChild(model)
    local size = pan:getContentSize()
    model:setPosition(cc.p(size.width*0.46,size.height*0.87))
end     

function UIShopVip:parseProductData(data)
    self.pData.shopDiamonds = { --desc, name, pid, amount, price, oldprice, hot
        }
    for k, v in ipairs(data.products) do
        local subList = {}
        local str = v.description or '12-14点 19-22点'

        subList.vip  = 0 
        subList.tiren = 0 
        subList.laba  = 0 
        subList.ticket = 0
        if v.vip then 
           for s,ss in pairs(v.vip) do 
               subList.vip = s 
           end 
        end 

        if v.prop and  v.prop['4']  and tonumber(v.prop['4'])>0  then 
            subList.tiren = v.prop['4']
        end      

        if v.prop and v.prop['7']  and tonumber(v.prop['7'])>0  then 
            subList.laba = v.prop['7']
        end      
        if v.prop and v.prop['1']  and tonumber(v.prop['1'])>0  then 
            subList.ticket = v.prop['1']
        end  
        subList.first = 0   --首充
        if v.discount and v.discount.first then 
          subList.first  = v.discount['first']['gem']  or  v.discount['first']['coin'] 
        end   
        if tonumber(self.pData.paytotal) > 0 then 
            subList.first = 0 
        end     
         
        subList.active = 0  --活动
        if v.discount and v.discount.active then 
          subList.active  = v.discount['active']['gem']  or  v.discount['active']['coin'] 
        end    
        subList.name = v.name
        subList.pid = v.pid 
        subList.gem = v.gems
        subList.price = v.price
        subList.coins = v.coins
        subList.hot = v.hot
        subList.rate = v.rate
        subList.isFirst = v.firstCharge or false 
        self.pData.shopDiamonds[k] = subList
    end

    dump(self.pData.shopDiamonds,'请求的元宝列表')
    self:initProductList()
end

function UIShopVip:requestGetProduct()
    local dataTable =     {
        ['uid']   = self.pData.uid,
        ['token']  = self.pData.token,
        ['cid']      = 4,
        ['ver']    = 1,
        ['cmd']       = HttpHandler.CMDTABLE.GET_PRODUCT,
    }
    local function succ(arg)
        dump(arg,'finalResult')
        self:parseProductData(arg)
    end
    local function fail(arg)
        if arg.msg then
            self.tool:showAlert(arg.msg)
        end
    end

    if LuaTools.isPlatformIOS() then
        dataTable.cid = 9
        dataTable.cmd = HttpHandler.CMDTABLE.IOS_SHOP
    end
    self.tool:fastRequest(dataTable,succ, fail)
end
--请求购买金币
function UIShopVip:requestBuyProduct()

end

return UIShopVip
