local UIRank = class("UIRank", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
UIRank.RESOURCE_FILENAME = "UIRank.csb"
UIRank.RESOURCE_PRELOADING = {"res_rank.png"}
--UIRank.RESOURCE_LOADING  = {["res/background/mohuBg.png"] = {names = {"Image_bgAll"}} }

UIRank.RESOURCE_BINDING = {
    ["Button_back"]       = {["ended"] = "backEvent"},
    ["ListView_left"]       = {["ON_SELECTED_ITEM_END"] = "selectEvent"},   

   }

UIRank.nameTable = {"魅力", "财富",  "赚金",  "元宝"}



function UIRank:backEvent()
  
    LuaTools.viewAction1Over(self['Panel_main'],'UIRank')
end



function UIRank:getRankByType(_type)
   
end

function UIRank:selectEvent(event)
    LuaTools.playBtSound()
    local index = event.target:getCurSelectedIndex()+1
    self:swithchPage(self.lastSelectedIndex,index)  
    self['Text_nowWord']:setString(UIRank.nameTable[index])
end 

function UIRank:swithchPage(from,to)
    if not to or to== 0 then return end 
    -- if self.allowSwitch == false and    type(self.playerdata.rankInfo[to]) ~='table' then 
    --     G_BASEAPP:addView('UIRankWaiting',999999)
    --     --self.allowSwitch = true
    --     return  
    -- end   
    local butTab  = {self['Button_type_1'],self['Button_type_2'],self['Button_type_3'],self['Button_type_4']} 
    local ListTab  = {self['RankList_my_1'],self['RankList_my_2'],self['RankList_my_3'],self['RankList_my_4']} 

    if from and from ~= 0 then 
       butTab[from]:loadTextures('res_rank/btn_unselect.png','res_rank/btn_unselect.png','res_rank/btn_unselect.png',ccui.TextureResType.plistType)
       butTab[from]:setTitleColor(cc.c3b(255,233,178))
       ListTab[from]:setVisible(false)
    end 

    butTab[to]:loadTextures('res_rank/btn_select.png','res_rank/btn_select.png','res_rank/btn_select.png',ccui.TextureResType.plistType)
    butTab[to]:setTitleColor(cc.c3b(255,255,255))
    self.lastSelectedIndex = to 
    ListTab[to]:setVisible(true)

    if from ~= to then 
       if #ListTab[to]:getItems() == 0 then        
            self:initContent(to)
       end      
       -- self.allowSwitch = false
    end    
end  

function UIRank:onCreate()
    local app = self:getApp()
    self.tool = app:getModel('Tools')
    self.app  = app

    self.isGlobalRank = true
    self.Button_cell:setVisible(false)
    self.cellTable = {}
    self.config = app:getData('Config')
    self.lastSelectedIndex = 1 
    self.indexPage = {1,1,1,1} 
    self.playerdata = self.app:getData('PlayerData')
    -- self.allowSwitch = true 

    for key =1 ,4 do 
        if self.playerdata.rankInfo[key] and type(self.playerdata.rankInfo[key]) =='table' then 
           self.indexPage[key] = (#self.playerdata.rankInfo[key] / 10 ) 
        end 
        self['Button_type_'..key]:setPressedActionEnabled(false)
    end  

    local  function cb()
        self:swithchPage(0,1) 
        local spr   
        local oldAvatar = UserCache.getUserDataByKey('icon')
        if oldAvatar and #oldAvatar > 0 then
            spr = cc.Sprite:create(oldAvatar)
        else
            spr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[self.playerdata.sex+1])
        end 
        LuaTools.makeSpriteRounded(spr, self['Image_myavatar'], self.config.maskSprite, true)
        self['Image_myavatar']:setLocalZOrder(7)
        self['Image_myNewVip']:setLocalZOrder(11)
    end 

    LuaTools.enterActionScaledWithMask(self['Panel_main'],cb)
    
    -- local info = {}
    -- info.rank   = 1
    -- info.uid    = self.playerdata.uid
    -- info.name   = self.playerdata.nick
    -- info.avatar  = self.playerdata.icon
    -- info.score   = self.playerdata.coin
    -- info.sex     = self.playerdata.sex
    -- info.vipLevel= self.playerdata.vip_level
    -- info.vipType = self.playerdata.vip_type
    -- info.vipDay  = self.playerdata.vipvalid
    -- self.personalInfo = info 

    for i = 1,4 do 
      local function onScrolled(event)
          if event.name == "BOUNCE_BOTTOM" then
              local _type =  self.lastSelectedIndex
              if #self.playerdata.rankInfo[_type] < 10*self.indexPage[_type] or (self.indexPage[_type] >= 5) then
                  return
              end
              self['RankList_my_'..i]:setTouchEnabled(false)
              self['RankList_my_'..i]:setBounceEnabled(false)

              self.indexPage[_type] = self.indexPage[_type] + 1
              self:requestGetProduct(_type)
          end
      end
      self['RankList_my_'..i]:onScroll(onScrolled)  
    end 
end

function UIRank:requestGetProduct(_type)       
        local paTable =     {
            ['uid']    = tonumber(self.playerdata.uid),
            ['type']   = _type,
            ['page']   = self.indexPage[tonumber(_type)],
            ['date']   = os.time(),
            ['token']  = G_TOKEN,
            ['cmd']    = HttpHandler.CMDTABLE.GET_RANKS  }
        local function succ(arg)
            local tsize = #self.playerdata.rankInfo[_type] or 0
            self['RankList_my_'.._type]:setTouchEnabled(true)
            self['RankList_my_'.._type]:setBounceEnabled(true)
            self:arrangeSort(arg,_type)
        end
        local function fail(arg)
        end   
        self.tool:fastRequest(paTable,succ,fail)

end

function UIRank:hideEmpty()
  self['Panel_noData']:setVisible(false)
end

function UIRank:showEmpty()
  self['Panel_noData']:setVisible(true)
end

function UIRank:initContent(_type)
  
  --self['RankList_my']:removeAllItems()
  local textName = self.Text_myname
  local textModel =  "一二三四五三四五"
  LuaTools.cropLabel(textModel,self.playerdata.nick , textName)

  self.myRank = -1      
  self.Text_myranknum:setVisible(true)
  self['Image_myNewVip']:setVisible(self.playerdata.vipvalid ~=0) 
  self['Text_myVip']:setString('V'..self.playerdata.vip_level)  
  local vip_day = tonumber(self.playerdata.vipvalid) or 0 
  self['Image_myNewVip']:loadTexture(vip_day<=7 and 'common/icon_vip_bg_0.png' or 
        (vip_day>30 and 'common/icon_vip_bg_2.png' or 'common/icon_vip_bg_1.png') ,ccui.TextureResType.plistType)
  self['Text_myranktype']:setString(_type == 1 and UIRank.nameTable[1] or (_type == 2 and UIRank.nameTable[2] or ''))
  if self.playerdata.sex == 1 then
     self['Image_mySex']:loadTexture("res_rank/female.png",ccui.TextureResType.plistType)
  end
  
  self['Text_myrankval']:setString(_type == 1 and LuaTools.convertAmountChinese(self.playerdata.charm) or 
    (_type == 2 and  LuaTools.convertAmountChinese(self.playerdata.coin) or ''))

  if  self.playerdata.rankInfo and self.playerdata.rankInfo[_type] == 0 then 
        local paTable =     {
            ['uid']    = tonumber(self.playerdata.uid),
            ['type']   = _type,
            ['page']   = self.indexPage[tonumber(_type)],
            ['date']   = os.time(),
            ['token']  = G_TOKEN,
            ['cmd']    = HttpHandler.CMDTABLE.GET_RANKS}
        local function succ(arg)
            self:arrangeSort(arg,_type)
            dump(arg,'排行榜数据')
        end
        local function fail(arg)
            self:showEmpty()
        end   
        self.tool:fastRequest(paTable,succ,fail)
  else   
        local info = self.playerdata.rankInfo[_type]
        self['Text_myrankval']:setString(_type == 1 and LuaTools.convertAmountChinese(self.playerdata.charm) or (_type == 2 and LuaTools.convertAmountChinese(self.playerdata.coin) or ''))

        --self['Text_nowWord']:setString(UIRank.nameTable[_type])

          for key = 1 ,#info do   
              local argTabl = {}
              local v = info[key]
              argTabl.rank      = key 
              argTabl.uid       = v.uid
              argTabl.name      = v.name
              argTabl.avatar    = v.icon
              argTabl.score     = v.money
              argTabl.vipLevel  = v.vip_level     
              argTabl.vipType   = v.vip_type
              argTabl.vipDay    = v.vipvalid 
              argTabl.trend     = v.trend
              argTabl.status    = v.status
              argTabl.sex       = v.sex 

              if tonumber(argTabl.uid) == tonumber(self.playerdata.uid) then  
                  self.Text_myranknum1:setString(argTabl.rank) 
                  self.Text_myranknum:setVisible(false)
              end
              self:addCell(argTabl,_type)
              -- if key == #info then 
              --    self.allowSwitch = true 
              -- end    
          end     
  end  
end

function UIRank:arrangeSort(arg,_type)
      if  arg.result == 1 then
          self.app:addView('UIAlert',65530):setupDialog('Infomation',arg.msg)
      else
          if #arg.list>= 1 then 
              self:hideEmpty()
              if self.indexPage[_type] == 1 then 
                  self.playerdata.rankInfo[_type] = arg.list 
              else 
                  for key = 1 ,#arg.list do   
                      local v = arg.list[key]
                      table.insert(self.playerdata.rankInfo[_type],v)
                  end
              end     
              --for k, v in ipairs(arg.list) do
              for key = 1 ,#arg.list do   
                  local argTabl = {}
                  local v = arg.list[key]
                  argTabl.rank      = key+(self.indexPage[_type]-1)*10
                  argTabl.uid       = v.uid
                  argTabl.name      = v.name
                  argTabl.avatar    = v.icon
                  argTabl.score     = v.money
                  argTabl.vipLevel  = v.vip_level     
                  argTabl.vipType   = v.vip_type
                  argTabl.vipDay    = v.vipvalid
                  argTabl.trend     = v.trend
                  argTabl.status    = v.status
                  argTabl.sex       = v.sex 
                  if tonumber(argTabl.uid) == tonumber(self.playerdata.uid) then  
                      self.Text_myranknum1:setString(argTabl.rank) 
                      self.Text_myranknum:setVisible(false)
                  end
                  --cc.SpriteFrameCache:getInstance():addSpriteFrames("common.plist")
                  self:addCell(argTabl,_type)
                 -- if key == #arg.list then 
                 --   self.allowSwitch = true 
                 -- end  

              end
              self['Text_myrankval']:setString(_type == 1 and LuaTools.convertAmountChinese(self.playerdata.charm) or (_type == 2 and LuaTools.convertAmountChinese(self.playerdata.coin) or ''))

              self['RankList_my_'.._type]:jumpToItem(#self.playerdata.rankInfo[_type]-9, cc.p(0,0), cc.p(0,0))
          end
      end
end   

function UIRank:addCell(_argTable,types)
    local argTable    =  _argTable or {}
    local _rank       =  tonumber(argTable.rank)       or 1
    local _name       =  argTable.name                 or 'Unnamedplayer'
    local _avatar     =  argTable.avatar
    local _vipLevel   =  tonumber(argTable.vipLevel)   or 0
    local _vipType    =  tonumber(argTable.vipType)    or 1
    local _sex        =  tonumber(argTable.sex)        or 0
    local _uid        =  argTable.uid                  or 0
    local _score      =  tonumber(argTable.score)      or 0
    local _vipDay     =  argTable.vipDay      or 0

    local _isFriend   =  false --argTable.isfriend 

    local item = self['Button_cell']:clone()
    item:setVisible(true)
    item:setPressedActionEnabled(false)
    self['RankList_my_'..types]:pushBackCustomItem(item)

    item:getChildByName('Text_name'):setString(_name)

    local textName = item:getChildByName('Text_name')
    local textModel =  "一二三四五三四五"
    LuaTools.cropLabel(textModel, _name, textName)

    item:getChildByName('Image_vipframe'):setVisible(_vipDay > 0)
    item:getChildByName('Image_vipframe'):setLocalZOrder(101)
    item:getChildByName('Image_vipframe'):loadTexture(_vipDay<=7 and 'common/icon_vip_bg_0.png' or 
      (_vipDay>30 and 'common/icon_vip_bg_2.png' or 'common/icon_vip_bg_1.png') ,ccui.TextureResType.plistType)
    item:getChildByName('Image_vipframe'):getChildByName('Text_viplevel'):setString('V'.._vipLevel)
    
    -- item:getChildByName('Image_vipframe'):setVisible(_vipLevel> 0)
    -- item:getChildByName('Image_vipframe'):getChildByName('Text_viplevel'):setString('V'.._vipLevel)


    item:getChildByName('Text_score'):setString(LuaTools.convertAmountChinese(_score))

    if  tonumber(_uid) == tonumber(self.playerdata.uid) then 
         self['Text_myranktype']:setString(UIRank.nameTable[self.lastSelectedIndex])
         self['Text_myrankval']:setString(LuaTools.convertAmountChinese(_score))
    end   

    item:getChildByName('Text_ranknumber'):setString(_rank)
    item:getChildByName('Text_ranknumber'):setVisible(_rank >= 4)
    item:getChildByName('Image_trophy_1'):setVisible(_rank < 4)
    if _rank == 2     then  
       item:getChildByName('Image_trophy_1'):loadTexture("res_rank/2.png",ccui.TextureResType.plistType)
    elseif _rank == 3 then 
       item:getChildByName('Image_trophy_1'):loadTexture("res_rank/3.png",ccui.TextureResType.plistType)
    end 

    if _sex == 1 then
        item:getChildByName('Image_sex'):loadTexture("res_rank/female.png",ccui.TextureResType.plistType)
    end
    local newHeadSpr 
    if _avatar and _avatar ~= "" then
      local function onFinishTable(status,downloadedSize,dst)
          if status == "success" then
             --item:getChildByName('Image_avatar'):loadTexture(dst,ccui.TextureResType.localType)
             newHeadSpr = cc.Sprite:create(dst)
          else 
             newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[_sex+1])   
          end
          LuaTools.makeSpriteRounded(newHeadSpr, item:getChildByName('Image_avatar'), self.config.maskSprite, false)
      end
      local newName = _avatar
      LuaTools.getFileFromUrl({url = _avatar, destFile =(newName:gsub("/","_")), onFinishTable = onFinishTable })
    else 
      newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[_sex+1])
      LuaTools.makeSpriteRounded(newHeadSpr, item:getChildByName('Image_avatar'), self.config.maskSprite, false)   
    end
    item:getChildByName('Image_myavatar_0'):setLocalZOrder(11)
    item:getChildByName('Image_avatar'):setLocalZOrder(10)

    -- if  _isFriend or  not self.isGlobalRank then
    --      item:getChildByName('Button_add'):setVisible(false)
    -- end

    -- item:getChildByName('Button_add'):onTouch(function (event)
    --     if event.name == 'ended' then
    --        self.app:addView('UIAddFriend',102,_uid)
    --     end
    -- end)

    local function touchItem(event)
        if event.name == 'ended' then
            local tab = {} 
            tab.uid = _uid 
            tab.tag = 3
            self.app:addView('UIFriendBrief',102,tab)
        end
    end
    item:onTouch(touchItem)

    -- if   type(self.playerdata.rankInfo[types]) =='table' then 
    --     if _rank == #self.playerdata.rankInfo[types]  then 
    --        self.allowSwitch = true 
    --     end  
    -- end 
end

return UIRank
