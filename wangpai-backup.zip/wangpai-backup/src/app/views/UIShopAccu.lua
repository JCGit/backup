local UIShopAccu = class("UIShopAccu", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
UIShopAccu.RESOURCE_FILENAME = "UIShopAccu.csb"
--UIShopFee.RESOURCE_PRELOADING = {"main.png"}
--UIShopFee.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIShopAccu.RESOURCE_BINDING = {
  
    }

local NUMBER_ITEM_PER_ROW = 4

--初始化
function UIShopAccu:onCreate()
    local app = self:getApp()
    self.app = app
    self.tool = app:getModel('Tools')
    self:setSkipGoBack(true )
    self.pData = self.app:getData('PlayerData')
    self['Image_bgd']:setVisible(false)
    self.mainListView = self['ListView_Items']
    self.panelItem = self['Panel_Item']
    self.panelItem:setBackGroundColorOpacity(0)
    self.mainListView:setItemModel(self['Panel_Item'])
    self.indexViewSel = 0
    
    self:setVisible(false)
end

function UIShopAccu:getPanelMain()
    return self['Panel_main']
end

--初始化UI
function UIShopAccu:init()
    self:initButtons()
     
    if #self.pData.shopAccu == 0 then
        self:requestGetAccuProduct()
    else
        dump(self.pData.shopAccu)
        self:showView(1)
    end
    self:setVisible(true)
end

--初始化切换按钮
function UIShopAccu:initButtons()
    local function onTouchButtons(event)
        if event.name == 'began' then
            
            local index = event.target:getTag()
            if index == self.indexViewSel then 
                return
            end
            self:showView(index)
        end
    end

    self.panelButtons = {
        {"Panel_bt_accu", "initTelExchange"},
        {"Panel_bt_tel", "initAccuExchange"},
    }
    for k, v in ipairs(self.panelButtons) do
        local panel = self[v[1]]
        panel:setBackGroundColorOpacity(0)
        panel:onTouch(onTouchButtons)
        panel:setTag(k)
        panel:getChildByName("Image_Select"):setVisible(false)
        panel:getChildByName("Image_textSel"):setVisible(false)
    end
end

--显示对应的界面
function UIShopAccu:showView(_index)
    if self.indexViewSel > 0  and self.indexViewSel ~= _index then 
        local olPanel = self[self.panelButtons[self.indexViewSel][1]]
        olPanel:getChildByName("Image_Select"):setVisible(false)
        olPanel:getChildByName("Image_textSel"):setVisible(false)
        olPanel:getChildByName("Image_textUnsel"):setVisible(true)
    end
    local panel = self[self.panelButtons[_index][1]]
    panel:getChildByName("Image_Select"):setVisible(true)
    panel:getChildByName("Image_textSel"):setVisible(true)
    panel:getChildByName("Image_textUnsel"):setVisible(false)
    self[self.panelButtons[_index][2]](self)
    self.indexViewSel = _index
end

--初始化积分兑换UI
function UIShopAccu:initAccuExchange()
    local function onBuy(event)
        if event.name == 'ended' then
            if self.pData.accu == 0 then 
                self.tool:showAlert("积分不足")
                return
            end
            local indexSel = event.target:getTag()          
            self:requestAccuExchange(self.pData.shopAccu[indexSel].pid,1)
        end
    end
    self.imageChips = {'res_shop/img_kick.png','res_shop/img_horn.png','res_shop/img_vipcard1.png',
        'res_shop/img_vipcard2.png','res_shop/img_vipcard3.png'}

    self.mainListView:removeAllChildren()
    self.mainListView:setScrollBarEnabled(false)
    
    dump(self.pData.shopAccu)
    for k, var in ipairs(self.pData.shopAccu) do
        self.mainListView:pushBackDefaultItem()
        local item = self.mainListView:getItem(k-1)
        item:getChildByName('Text_cost'):setString("消耗:"..var.count.."积分")
        item:getChildByName('Text_title'):setString(var.name)
        local tempImg = item:getChildByName('Image_item')
        tempImg:setVisible(false)
        local img = ccui.ImageView:create(self.imageChips[k], ccui.TextureResType.plistType)
        img:setPosition(tempImg:getPosition())
        item:addChild(img,1)
        local btbuy = item:getChildByName('Button_buy')
        btbuy:onTouch(onBuy)
        btbuy:setTag(k)
        
        item:setBackGroundColorOpacity(0)
    end
    --[[local countRow = math.ceil(#self.pData.shopAccu/NUMBER_ITEM_PER_ROW)
    local count = 1
    for i = 1, countRow do
        self.mainListView:pushBackDefaultItem()
        local row = self.mainListView:getItem(i-1)
        for j = 1, NUMBER_ITEM_PER_ROW do
            local item = row:getChildByName('Panel_Item_'..j)
            if count > #self.pData.shopAccu then 
                item:setVisible(false)
            else
                item:setBackGroundColorOpacity(0)
                local var = self.pData.shopAccu[count]
                
                item:getChildByName('Text_desc'):setString(var.name)
                local img 
                if count > #self.imageChips then
                    img = self.imageChips[#self.imageChips]
                else
                    img = self.imageChips[count]
                end
                item:getChildByName('Image_chips'):loadTexture(img, ccui.TextureResType.plistType)
                item:getChildByName('Panel_descTelfee'):setVisible(false)
                local textAtlas = item:getChildByName('Panel_descAccu'):getChildByName('AtlasLabel_chipsCount')
                textAtlas:setString(var.count)
                local posX = textAtlas:getPositionX()+textAtlas:getContentSize().width*(1-0.8)
                item:getChildByName('Panel_descAccu'):getChildByName('Image_jifen'):setPositionX(posX)
                local bt = item:getChildByName('Button_exchange')
                bt:onTouch(onBuy)
                bt:setTag(count)
            end
            count = count + 1
        end
    end
    ]]--

end

--初始化话费兑换UI
function UIShopAccu:initTelExchange()
    local function onBuy(event)
        if event.name == 'ended' then
            
            local indexSel = event.target:getTag()     
            local tInfo = {}
            tInfo.price = self.dataTelfee[indexSel]*10
            tInfo.pid = self.dataTelfee[indexSel]
            tInfo.imgPath = self.imageTelFee[indexSel]
            self.app:addView('UIShopSubviews', self:getLocalZOrder() + 1, 2, tInfo)
        end
    end
    self.imageTelFee = {'res_shop/img_telcard30.png','res_shop/img_telcard50.png','res_shop/img_telcard100.png',}
    self.dataTelfee = {30, 50, 100}
    self.mainListView:removeAllChildren()
    self.mainListView:setScrollBarEnabled(false)

    for k, var in ipairs(self.dataTelfee) do
        self.mainListView:pushBackDefaultItem()
        local item = self.mainListView:getItem(k-1)
        item:getChildByName('Text_cost'):setString("消耗:"..(var*10).."话费卷")
        item:getChildByName('Text_title'):setString(var.."话费")

        local img 
            if k > #self.imageTelFee then
                img = self.imageTelFee[#self.imageTelFee]
            else
                img = self.imageTelFee[k]
            end
        local tempImg = item:getChildByName('Image_item')
        tempImg:setVisible(false)
        local img = ccui.ImageView:create(img, ccui.TextureResType.plistType)
        img:setPosition(tempImg:getPosition())
        item:addChild(img,1)
        local btbuy = item:getChildByName('Button_buy')
        btbuy:onTouch(onBuy)
        btbuy:setTag(k)
        
        item:setBackGroundColorOpacity(0)
    end

    --[[local countRow = math.floor(#self.dataTelfee/NUMBER_ITEM_PER_ROW + 1)
    local count = 1
    for i = 1, countRow do
        self.mainListView:pushBackDefaultItem()
        local row = self.mainListView:getItem(i-1)
        for j = 1, NUMBER_ITEM_PER_ROW do
            local item = row:getChildByName('Panel_Item_'..j)
            if count > #self.dataTelfee then 
                item:setVisible(false)
            else
                item:setBackGroundColorOpacity(0)
                item:getChildByName('Text_desc'):setString((self.dataTelfee[count]*10).."话费券")
                local img 
                if count > #self.imageTelFee then
                    img = self.imageTelFee[#self.imageTelFee]
                else
                    img = self.imageTelFee[count]
                end
                item:getChildByName('Image_chips'):loadTexture(img, ccui.TextureResType.plistType)
                item:getChildByName('Panel_descAccu'):setVisible(false)
                local bt = item:getChildByName('Button_exchange')
                bt:onTouch(onBuy)
                bt:setTag(count)
            end
            count = count + 1
        end
    end]]--
end

--拷贝数据（可避免）
function UIShopAccu:parseProductData(data)
    self.pData.shopAccu = { -- name, pid, price, icon
        }

    for k, v in ipairs(data.products) do
        local subList = {}
        subList.name = v.name
        subList.pid = v.apid 
        subList.count = v.count
        self.pData.shopAccu[k] = subList
    end
    dump(self.pData.shopAccu)
    self:showView(1)
end

--获取积分列表
function UIShopAccu:requestGetAccuProduct()
    local dataTable =     {
        ['uid']   = self.pData.uid,
        ['token']  = self.pData.token,
        ['version']    = 1,
        ['cmd']       = HttpHandler.CMDTABLE.SHOP_ACCU,
    }
    local function succ(arg)
        self:parseProductData(arg)
    end
    local function fail(arg)
        if arg.msg then
            self.tool:showAlert(arg.msg)
        end
    end
    self.tool:fastRequest(dataTable,succ, fail)
end

--请求兑换物品
function UIShopAccu:requestAccuExchange(pid)
    local dataTable =     {
        ['uid']   = self.pData.uid,
        ['token']  = self.pData.token,
        ['apid']      = pid,
        ['cmd']       = HttpHandler.CMDTABLE.ACCU_EXCHANGE,
    }
    local function succ(arg)
        self.pData.accu = tonumber( arg.accu ) or 0
        self.pData.coin = tonumber( arg.coin ) or 0
        self.pData.gem = tonumber( arg.gem ) or 0
        self.pData.prop[1] = arg.prop['4']
        self.pData.prop[2] = arg.prop['7']
        self.pData.vip_type = arg.vip_type
        self.pData.vip_level = arg.vip_level
        self.pData.vip_day = arg.vip_day
        self.pData.vipvalid = arg.vipvalid
        self.tool:showAlert(arg.msg)
        self.app:callMethod('UIShop','updateContent')
    end
    local function fail(arg)
        if arg.msg then
            self.tool:showAlert(arg.msg)
        end
    end
    self.tool:fastRequest(dataTable,succ, fail)
end


return UIShopAccu 
