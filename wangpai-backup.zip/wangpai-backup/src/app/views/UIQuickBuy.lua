local UIQuickBuy = class("UIQuickBuy", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")

UIQuickBuy.RESOURCE_FILENAME = "UIQuickBuy.csb"
--UIQuickBuy.RESOURCE_PRELOADING = {"main.png"}
--UIQuickBuy.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIQuickBuy.RESOURCE_BINDING = {
    ["Button_Close"]  = {["ended"] = "backEvent"},
    ["ListView_select"] = {["ON_SELECTED_ITEM_END"] = "selectEvent"},      


}

function UIQuickBuy:backEvent(event)
    -- self.app:removeView('UIQuickBuy')
    LuaTools.viewAction1Over(self["Panel_layer_all"],"UIQuickBuy")
end

function UIQuickBuy:selectEvent(event)
    local index = event.target:getCurSelectedIndex()+1
    self:swithchPage(self.lastSelectedIndex,index)  
end

function UIQuickBuy:swithchPage(from,to) 

    local image1_tab = {'res_profile/btn_head_z1.png','res_profile/btn_head_y1.png'}
    local image2_tab = {'res_profile/btn_head_z.png','res_profile/btn_head_y.png'}
    local temp = {self['Button_touch1'],self['Button_touch2']}
    local temp1 = {self['ListView_item'],self['ListView_item2']}
    if from ~= 0 then 
        temp[from]:loadTextures(image2_tab[from],image2_tab[from],image2_tab[from],ccui.TextureResType.plistType)
        temp1[from]:setVisible(false)
        temp[from]:setTitleColor(cc.c3b(172,147,128))
    end    
    temp[to]:loadTextures(image1_tab[to],image1_tab[to],image1_tab[to],ccui.TextureResType.plistType)
    temp1[to]:setVisible(true)
    temp[to]:setTitleColor(cc.c3b(255,255,255))
    self.lastSelectedIndex = to 
    
    if to == 1  and from~= to  then 
        self['Image_noData']:setVisible(false)
    end  

    if to == 2  and from~= to  then 
       self:requestPersonal(1, false)
    end 
end 



function UIQuickBuy:onCreate(onSuccCallback)
    local app = self:getApp()
    self.onSuccCallback = onSuccCallback
    self.app = app
    self.tool = app:getModel('Tools')
    self.pData = self.app:getData('PlayerData')
    
    self.tool = app:getModel('Tools')
    self:swithchPage(2,1)
    self['Button_touch1']:setPressedActionEnabled(false)
    self['Button_touch2']:setPressedActionEnabled(false)
    self:expendPageForView()

    LuaTools.viewAction1(self["Panel_layer_all"],function()     
        if #self.pData.showChipsQuick == 0 then
            self:requestGetProduct()
        else
            self:initProductList()
        end 
    end)
end
-------------------------------------------------
--商城
function UIQuickBuy:requestGetProduct()
    local dataTable =     {
        ['uid']    = self.pData.uid,
        ['token']  = self.pData.token,
        ['cid']    = 1,
        ['ver']    = 1,
        ['cmd']    = HttpHandler.CMDTABLE.GET_PRODUCT,
    }
    local function succ(arg)
        self:parseProductData(arg)
    end
    self.tool:fastRequest(dataTable,succ)
end

function UIQuickBuy:parseProductData(data)
    self.pData.showChipsQuick = { --desc, name, pid, price, icon
        }
    for k, v in ipairs(data.products) do
        local subList = {}
        subList[1] = v.description
        subList[2] = v.name
        subList[3] = v.pid 
        subList[4] = v.price
        subList[5] = v.coins
        self.pData.showChipsQuick[k] = subList
    end
    self:initProductList()
end

function UIQuickBuy:requestBuyProduct(pid, num,moneys)
    local dataTable =     {
        ['uid']      = self.pData.uid,
        ['token']    = self.pData.token,
        ['pid']      = pid,
        ['number']   = num,
        ['cmd']      = HttpHandler.CMDTABLE.BUY_PRODUCT,
    }
    local function succ(arg)
        self.pData.coin = arg.coin
        self.pData.gem = arg.gem
        self.tool:showAlert(arg.msg)
        local temp = arg 
        temp.coin = tonumber(moneys)
        if self.onSuccCallback then 
            self.onSuccCallback(temp) 
        end

       if self.app:getView('UIMainTop') then 
          self.app:callMethod('UIMainTop','updateWealth')
       end 
        --self['Text_money']:setString(arg.gem)
    end
    local function fail(arg)
        if arg.msg == "元宝不足" then 
            G_BASEAPP:addView('UIShopDiamond',self:getLocalZOrder()+1)
        end      
    end    
    self.tool:fastRequest(dataTable,succ,fail)
end

function UIQuickBuy:initProductList()   

    local function onBuy(event)
        if event.name == 'ended' then
            local indexSel = event.target:getTag()
            local chips = self.pData.showChipsQuick[indexSel][2]
            local diamond = self.pData.showChipsQuick[indexSel][4]
            self:requestBuyProduct(self.pData.showChipsQuick[indexSel][3],1,self.pData.showChipsQuick[indexSel][5])
        end
    end
    self['Panel_Item']:getChildByName('Image_2'):setVisible(true)
    self['Panel_Item']:getChildByName('Image_1'):setVisible(false)
    self.mainListView = self['ListView_item']
    self.mainListView:setItemModel(self['Panel_Item'])
    local item
    for key ,var in pairs(self.pData.showChipsQuick) do
        self.mainListView:pushBackDefaultItem()
        item = self.mainListView:getItem(key-1)
        item:setVisible(true)
        item:getChildByName('Image_2'):getChildByName('Text_coin'):setString(var[2])
        item:getChildByName('Image_mid'):getChildByName('Text_price'):setString(var[4])
        item:getChildByName('Text_danjia'):setString('1元宝='..math.floor(tonumber(var[5])/tonumber(var[4]))..'金币')

        item:getChildByName('Button_buy'):onTouch(onBuy)
        item:getChildByName('Button_buy'):setTag(key)
    end
    
end
----------------------------------------------------
--交易市场
--
function UIQuickBuy:expendPageForView()
    local function onScrolled(event)
        if event.name == "BOUNCE_BOTTOM" then
            if #self.listData < 10*self.indexPage then
                return
            end
            self['ListView_item2']:setTouchEnabled(false)
            self['ListView_item2']:setBounceEnabled(false)
            self.indexPage = self.indexPage + 1
            self:requestPersonal(self.indexPage, true)
        end
    end

    self['ListView_item2']:onScroll(onScrolled)
end

function UIQuickBuy:requestPersonal(page, isAppend)
    if isAppend == false then
        self.indexForServer = -1
    end

    local dataTable =     {
        ['uid']    = self.pData.uid,
        ['token']  = self.pData.token,
        ['index']   = self.indexForServer,
        ['type']   = 0,
        ['gems']    = 0,
        ['cmd']    = HttpHandler.CMDTABLE.TRADE_MARKET,
    }
    local function succ(arg)
        self.indexForServer = arg.index
        if isAppend == false then
            self.listData = {}
            self.indexPage = 1
            self:parseBuyPersonal(arg)  --第一次此初始化买金币商品
        else
            self:appendBuyProductData(arg)  --扩展买金币商品
            self.indexPage = page
            self['ListView_item2']:setTouchEnabled(true)
            self['ListView_item2']:setBounceEnabled(true)
        end
    end
    local function fail()
        self['Image_noData']:setVisible(true)
        self['ListView_item2']:removeAllChildren()
    end     
    self.tool:fastRequest(dataTable,succ)
end

--扩展购买筹码列表
function UIQuickBuy:appendBuyProductData(data)
    self:initListData(data)
    local function onBuy(event)
        if event.name == 'ended' then
            local indexSel = event.target:getTag()
            --self:requestBuyPersonalProduct(self.listData[indexSel][3])           
            G_BASEAPP:addView('UIDialog',999999)
            G_BASEAPP:callMethod('UIDialog','setupDialog', '','确定购买?',
                    function() 
                       self:requestBuyPersonalProduct(self.listData[indexSel][3])
                    end)            
        end
    end

    self['Panel_Item']:setVisible(true)
    local item
    for k, v in pairs(data.market) do
        self['ListView_item2']:pushBackDefaultItem()
        local childCount = self['ListView_item2']:getChildrenCount()
        item = self['ListView_item2']:getItem(childCount-1)
        item:setVisible(true)
        -- item:getChildByName('Text_itemCount'):setString(var[1])
        item:getChildByName('Image_1'):getChildByName('Text_coin'):setString(LuaTools.convertAmountChinese(v.coin))
        --item:getChildByName('Text_desc'):setString('1 Diamond = '..math.floor(v.coin/v.gem)..' Chips')
        --item:getChildByName('Image_1'):getChildByName('Text_name'):setString('卖家:'..v.name)
    
        local textName = item:getChildByName('Image_1'):getChildByName('Text_name')
        local textModel =  "一二三四五三四五四"
        LuaTools.cropLabel(textModel, ('卖家:'..v.name), textName)

        item:getChildByName('Image_mid'):getChildByName('Text_price'):setString(v.gem)
        item:getChildByName('Text_danjia'):setString('1元宝='..math.floor(tonumber(v.coin)/tonumber(v.gem))..'金币')
        local bt = item:getChildByName('Button_buy')

        if v.uid == self.pData.uid then
            bt:setTouchEnabled(false)
            bt:setEnabled(false)
            bt:setBright(true)
            bt:setTitleText('自己')
        else
            bt:onTouch(onBuy)
            bt:setTag(childCount)
        end

    end
    self['Panel_Item']:setVisible(false)
end

function UIQuickBuy:parseBuyPersonal(data)
    self:initListData(data)
    self:initOnBuyPersonal()
end

--解析内容
function UIQuickBuy:initListData(data)
    for k, v in ipairs(data.market) do
        local subList = {}
        subList[1] = v.coin
        subList[2] = v.gem
        subList[3] = v.mid 
        subList[4] = v.name
        subList[5] = v.uid
        table.insert(self.listData, subList)
    end
end

--购买金币
function UIQuickBuy:requestBuyPersonalProduct(pid,money)
    local dataTable =     {
        ['uid']   = self.pData.uid,
        ['token']  = self.pData.token,
        ['mid']      = pid,
        ['cmd']       = HttpHandler.CMDTABLE.BUY_COINS,
    }
    local function succ(arg)
        self.pData.coin = arg.coin
        self.pData.gem = arg.gem
        --self['Text_money']:setString(arg.gem)
        local temp = arg 
        temp.coin = tonumber(money)
        if self.onSuccCallback then 
            self.onSuccCallback(temp) 
        end
        self.tool:showAlert(arg.msg)
        self:requestPersonal(1, false)
        if not arg.market or #arg.market == 0 then 
           self['Image_noData']:setVisible(true)
           self['ListView_item2']:removeAllChildren()
        end     
    end
    local function fail(arg)
        if string.find(arg.msg,'不足') then 
            G_BASEAPP:addView('UIShopDiamond',self:getLocalZOrder()+1)
        end      
        -- self['Image_noData']:setVisible(true)
        -- self['ListView_item2']:removeAllChildren()
    end
    self.tool:fastRequest(dataTable,succ,fail)
end

function UIQuickBuy:initOnBuyPersonal()

    if #self.listData == 0 then   
        self['Image_noData']:setVisible(true)
    else
        self['Image_noData']:setVisible(false)
    end

    local function onBuy(event)
        if event.name == 'ended' then
            -- dump(self.listData[indexSel],'进入了购买金币')
            -- dump(self.listData)
            local indexSel = event.target:getTag()
            G_BASEAPP:addView('UIDialog',999999)
            G_BASEAPP:callMethod('UIDialog','setupDialog', '','确定购买?',
                    function() 
                       self:requestBuyPersonalProduct(self.listData[indexSel][3],self.listData[indexSel][1])
                    end)
        end
    end
    if #self.listData > 0 then 
        self['Panel_Item']:getChildByName('Image_2'):setVisible(false)
        self['Panel_Item']:getChildByName('Image_1'):setVisible(true)
        
        self['ListView_item2']:setItemModel(self['Panel_Item'])
        self['ListView_item2']:removeAllChildren()
        self['Panel_Item']:setVisible(true)
        local item
        for key ,var in ipairs(self.listData) do
            self['ListView_item2']:pushBackDefaultItem()
            item = self['ListView_item2']:getItem(key-1)
            item:setVisible(true)
            -- item:getChildByName('Text_itemCount'):setString(var[1])
            item:getChildByName('Image_1'):getChildByName('Text_coin'):setString(LuaTools.convertAmountChinese(var[1]))
            --item:getChildByName('Text_desc'):setString('1 Diamond = '..math.floor(var[1]/var[2])..' Chips')
            item:getChildByName('Image_1'):getChildByName('Text_name'):setString('卖家:'..var[4])
            item:getChildByName('Image_mid'):getChildByName('Text_price'):setString(var[2])
            item:getChildByName('Text_danjia'):setString('1元宝='..math.floor(tonumber(var[1])/tonumber(var[2]))..'金币')

            local bt = item:getChildByName('Button_buy')

            if var[5] == self.pData.uid then
                bt:setTouchEnabled(false)
                bt:setEnabled(false)
                bt:setBright(true)
                bt:setTitleText('自己')
            else
                bt:onTouch(onBuy)
                bt:setTag(key)
            end

        end
        self['Panel_Item']:setVisible(false)
    end 
end

return UIQuickBuy
