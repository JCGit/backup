local UILoginFindPwd = class("UILoginFindPwd", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")

UILoginFindPwd.RESOURCE_FILENAME = "UILoginFindPwd.csb"
--UILoginChangePsw.RESOURCE_PRELOADING = {"main.png"}
--UILoginChangePsw.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}},

UILoginFindPwd.RESOURCE_BINDING = { 
    ["Button_Close"]  = {["ended"] = "onClose"},
    ["Button_confirm"]  = {["ended"] = "onConfirm"},
    ["Button_GetSms"] = {["ended"] = "onGetSms"},
}

function UILoginFindPwd:onCreate(_account)
    local app = self:getApp()
    self.app = app
    self.config = app:getData('Config')
    self.account = app:getModel('Account')
    self.pData = app:getData('PlayerData')
    self.tool = app:getModel('Tools') 
    --self['Panel_Question']:setVisible(false)

    self:initTextField(self['TextField_account'])
    self:initTextField(self['TextField_newPwd1'])
    self:initTextField(self['TextField_newPwd2'])
    self:initTextField(self['TextField_phone'])
    self:initTextField(self['TextField_codeSms'])

    self.account:handleTxfControl(self['TextField_account'],{"@"})
    self.account:handleTxfControl(self['TextField_newPwd1'])
    self.account:handleTxfControl(self['TextField_newPwd2'])
    self.account:handleTxfControl(self['TextField_phone'],nil, 'num')
    self.account:handleTxfControl(self['TextField_codeSms'], nil, 'num')


    if _account and #tostring(_account) > 0 then
        self['TextField_account']:setString(_account)
    end
    --init Get Sms code Enable time
    if self.pData.smsCodeTimeEnable > 0 then
        self.timeLast = self.config.getSmsDelayTime - (os.time() - self.pData.smsCodeTimeEnable)
        if self.timeLast > 0 then
            self['Button_GetSms']:setEnabled(false)
            self['Button_GetSms']:setTitleText('('..self.timeLast..')获取')
            self:createSchedule('updateCount', function()  
                self.timeLast = self.timeLast - 1
                self['Button_GetSms']:setTitleText('('..self.timeLast..')获取')
                if self.timeLast == 0 then
                    self:stopSchedule('updateCount')
                    self['Button_GetSms']:setEnabled(true)
                    self['Button_GetSms']:setTitleText('获取')
                end
            end,1)
        else
            self['Button_GetSms']:setEnabled(true)
            self['Button_GetSms']:setTitleText('获取')
        end
    end
end

function UILoginFindPwd:initTextField(_txf)
    _txf:setTextVerticalAlignment(cc.TEXT_ALIGNMENT_CENTER)
    _txf:setTextColor(self.config.Txf_textColorLogin)
end

function UILoginFindPwd:onGetSms()
    
    local acc = self['TextField_account']:getString()
    local phone = self['TextField_phone']:getString()
    
    if #acc == 0 then 
        self.tool:showTips(self.account.accNotFind)
        return
    end
    
    if #phone == 0 then 
        self.tool:showTips(self.account.phoneError1)
         return
    elseif (false == self.account:strContainOnlyNum(phone)) or #phone ~= 11 then
         self.tool:showTips(self.account.phoneError)
         return
    end

    local dataTable =     {
        ['type']   = 2,
        ['account']   = acc,
        ['uid']   = '',
        ['phone']   = phone,
        ['cmd']       = HttpHandler.CMDTABLE.GET_SMS,
    }
    local function succ(arg)
        self.tool:showTips(arg.msg)
        self.pData.smsCodeTimeEnable = os.time()
        self.timeLast = self.config.getSmsDelayTime
        self['Button_GetSms']:setEnabled(false)
        self:createSchedule('updateCount', function()  
        self.timeLast = self.timeLast - 1
        self['Button_GetSms']:setTitleText('('..self.timeLast..')获取')
        if self.timeLast == 0 then
            self:stopSchedule('updateCount')
            self['Button_GetSms']:setEnabled(true)
            self['Button_GetSms']:setTitleText('获取')
        end
        end,1) 
    end

    local function fail(arg)
        self.tool:showTips(arg.msg)
    end
    self.tool:fastRequest(dataTable,succ, fail)
end

function UILoginFindPwd:onConfirm()
    
    local acc = self['TextField_account']:getString()
    self.pwd = self['TextField_newPwd1']:getString()
    local confPwd = self['TextField_newPwd2']:getString()
    local phone = self['TextField_phone']:getString()
    local codeSms = self['TextField_codeSms']:getString()

    if #acc == 0 then 
        self.tool:showTips(self.account.accNotFind)
        return
    end
    
    --检测密码长度是否合格
    if #self.pwd< self.account.pwdMinLen or #self.pwd > self.account.pwdMaxLen then
        self.tool:showTips(self.account.pwdLenght)
        return
    end
    --检测密码内容是否合格
    if false == self.account:strContainOnlyNumAndChar(self.pwd) then
        self.tool:showTips(self.account.pwdError)
        return
    end
    --检测两次输入的密码是否一致
    if self.pwd ~= confPwd then
        self.tool:showTips(self.account.pwdNotMatched)
        return
    end

    if #phone == 0 then 
        self.tool:showTips(self.account.phoneError1)
        return
    elseif (false == self.account:strContainOnlyNum(phone)) or #phone ~= 11 then
         self.tool:showTips(self.account.phoneError)
        return
    end

    if (false == self.account:strContainOnlyNum(codeSms)) or #codeSms == 0 then
        self.tool:showTips(self.account.smsCodeError)
        return
    end
    
    local dataTable =     {
        ['account']   = acc,
        ['pwd']  = self.pwd,
        ['phone']      = phone,
        ['msgCode']       = codeSms,
        ['cmd']       = HttpHandler.CMDTABLE.FIND_PWD,
    }
    local function succ(arg)
        self.tool:showTips('密码重置成功！')
        self.app:callMethod('UILogin','updatePwd', self.pwd,acc) 
        self:onClose()
    end
    self.tool:fastRequest(dataTable,succ)
end

function UILoginFindPwd:onClose()
    
    self:stopSchedule('updateCount')
    self.app:removeView('UILoginFindPwd')
end

return UILoginFindPwd
