local UIWanrRenTender = class("UIWanrRenTender", cc.load("mvc").ViewBase)

UIWanrRenTender.RESOURCE_FILENAME = "UIWanrRenTender.csb"

UIWanrRenTender.RESOURCE_BINDING = { 
  ["Panel_main"]   = {["ended"] = "PlayerCtrl_Touch"}, 
} 

local SHOW_DIS_TIME = 0.3
function UIWanrRenTender:PlayerCtrl_Touch()
    local function cb()
        self.app:removeView("UIWanrRenTender")
    end
    local closeAction = cc.MoveTo:create(SHOW_DIS_TIME,cc.p(1700,self["Panel_root"]:getPositionY()))
    local seq = cc.Sequence:create(closeAction,cc.CallFunc:create(cb),nil)
    self["Panel_root"]:runAction(seq)
end

function UIWanrRenTender:onCreate(data)
    local app = self:getApp()
    self.app = app
    local bigListView = self["ListView_1"]
    bigListView:setScrollBarEnabled(false)
    local smallListView = self["ListView_2"]
    smallListView:setScrollBarEnabled(false)
    bigListView:setItemModel(smallListView)
    if type(data) =='table' and #data > 0 then 
        for i=1,#data do
            local oneData = data[#data+1-i]
            if i > 1 then
                bigListView:pushBackDefaultItem()
            end
            local row = bigListView:getItem(i-1)
            for j=1,4 do
                local img = row:getItem(j-1)
                if oneData[j] == 0 then
                    img:loadTexture("wanren/lose2.png",ccui.TextureResType.plistType) 
                else
                    img:loadTexture("wanren/win2.png",ccui.TextureResType.plistType) 
                end
            end
        end
    end 
    local moveRight = cc.MoveTo:create(SHOW_DIS_TIME, cc.p(1280,self["Panel_root"]:getPositionY()))
    self["Panel_root"]:runAction(moveRight)
end

return UIWanrRenTender
