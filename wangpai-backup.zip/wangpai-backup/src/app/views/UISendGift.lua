local UISendGift = class("UISendGift", cc.load("mvc").ViewBase)

UISendGift.RESOURCE_FILENAME = "UISendGift.csb"
--UIAlert.RESOURCE_PRELOADING = {"main.png"}
--UIAlert.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

local HttpHandler = require("app.network.HttpHandler")
UISendGift.RESOURCE_BINDING = {
     --["Panel_main"] = {["ended"] = "exitRoom"},
     ["Button_Close"] = {["ended"] = "exitRoom"},
    }

function UISendGift:exitRoom()
    -- self.app:removeView('UISendGift')
    
    LuaTools.viewAction1Over(self["Panel_main"],"UISendGift")
end


function UISendGift:doGive(idx)
    if self.pVersion and self.pVersion < 300000 and (idx==6 or idx==7) then 
        LuaTools.showAlert('该玩家当前游戏版本过低，无法赠送此礼物')
        return
    end 

    local num = tonumber(self['ListView_gift']:getItem(idx-1):getChildByName('Text_num'):getString()) 
    local dataTable =     {
    ['uid']     = G_UID,
    ['token']   = G_TOKEN,
    ['ruid']    = self.uid,
    ['gid']     = idx,
    ['num']     = num, 
    ['cmd']     = HttpHandler.CMDTABLE.GIFT_GIVE,
  }
  local function succ(arg)
      self.tool:showTips('赠送礼物成功')
      self.pData.coin = arg.coin 
      if G_BASEAPP:getView('UIMainTop') then 
          G_BASEAPP:callMethod('UIMainTop','updateWealth') 
      end  
      G_BASEAPP:removeView('UISendGift')
  end
  local function fail()
        G_BASEAPP:removeView('UISendGift')
  end
  self.tool:fastRequest(dataTable,succ,fail)
end

function UISendGift:tcpGive(i) 
                 
    local num = tonumber(self['ListView_gift']:getItem(i-1):getChildByName('Text_num'):getString())   or  1  
    if self.pVersion and self.pVersion < 300000 and (i==6 or i==7) then 
        LuaTools.showAlert('该玩家当前游戏版本过低，无法赠送此礼物')
        return
    end 
    if G_BASEAPP:getView('UIFriendWeddingRoom') then 
        G_BASEAPP:callMethod('UIFriendWeddingRoom','reqSock_SENDGIFT',self.uid,i,num)   
    else 
        if tonumber(self.pData.coin) < self.price[i]*10 then 
           self.tool:showTips('为了游戏公平性，准备或游戏中金币必须高于礼物价格10倍才可赠送')
           return 
        else 
           if self.SendGiftcb then 
              self.SendGiftcb(self.uid,i) 
           end   
        end 
    end 
    if G_BASEAPP:getView('UISendGift') then 
        G_BASEAPP:removeView('UISendGift')
    end 

    if G_BASEAPP:getView('UIFriendBrief') then 
        G_BASEAPP:removeView('UIFriendBrief')
    end 

end 

function UISendGift:giftMore(idx)
    local num = tonumber(self['ListView_gift']:getItem(idx-1):getChildByName('Text_num'):getString())
    local new 
    if num>= 10 then 
       new = 10
    else 
       new = num + 1 
    end        
    self['ListView_gift']:getItem(idx-1):getChildByName('Text_num'):setString(new)  
end 

function UISendGift:giftLess(idx)
    local num = tonumber(self['ListView_gift']:getItem(idx-1):getChildByName('Text_num'):getString())
    local new 

    if num<=1 then 
        new = 1
    else 
        new = num - 1 
    end        
    self['ListView_gift']:getItem(idx-1):getChildByName('Text_num'):setString(new)
end 


function UISendGift:onCreate(UID,tag,cb,version)

    local app = self:getApp()
    self.tool = app:getModel('Tools')
    self.app = app
    self.uid = UID

    self.pVersion = version 
    self.SendGiftcb = cb
    LuaTools.viewAction1(self["Panel_main"])
    self.pData = app:getData('PlayerData')
    self['ListView_gift']:setScrollBarEnabled(false)
    self['ListView_gift']:removeAllItems()
    if self.SendGiftcb then 
        self['Panel_Item_model']:getChildByName('Image_5'):setVisible(false)
        self['Panel_Item_model']:getChildByName('Button_Add'):setVisible(false)
        self['Panel_Item_model']:getChildByName('Button_Minus'):setVisible(false)
        self['Panel_Item_model']:getChildByName('Text_num'):setVisible(false)
        self['Text_tips']:setVisible(false)
    end     
    self['ListView_gift']:setItemModel(self['Panel_Item_model'])

    self.price = {3000,3000,60000,300000,500000,800000,5000000}
    local gift_imageTab = {'common/gift1.png','common/gift2.png','common/gift3.png','common/gift4.png',
                            'common/gift5.png','common/gift6.png','common/gift7.png'} 
                               
    for key =1 ,#gift_imageTab do  
         self['ListView_gift']:pushBackDefaultItem() 
         local model = self['ListView_gift']:getItem(key-1)
         model:setVisible(true)

         model:getChildByName('Text_count'):setString(self.price[key])
         model:getChildByName('Image_gift'):loadTexture(gift_imageTab[key],ccui.TextureResType.plistType)
         ----------------------       
         local function more(event)
             if event.name == 'ended' then 
                self:giftMore(key)
             end    
         end 
         model:getChildByName('Button_Add'):onTouch(more)
         -------------------------------
         local function less(event)
             if event.name == 'ended' then         
                self:giftLess(key)
             end   
         end 
         model:getChildByName('Button_Minus'):onTouch(less)
         local function give(event)
            if event.name == 'ended' then 
                if tag and tag == 2 then 
                   self:tcpGive(key)
                else   
                   self:doGive(key)
                end    
            end 
         end 
         model:getChildByName('Button_send'):onTouch(give)
         -------------------------------
    end 
end

return UISendGift
