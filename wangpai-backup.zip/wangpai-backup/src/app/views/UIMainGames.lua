
local UIMainGames = class("UIMainGames", cc.load("mvc").ViewBase)

UIMainGames.RESOURCE_FILENAME = "UIMainGames.csb"
UIMainGames.RESOURCE_PRELOADING = {"res_lobby.png"}
--UIMainGames.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIMainGames.RESOURCE_BINDING = { 

    ['Button_awardsGame']  = {["ended"] = "enterAwardGame"},

    } 


---------------------------------------------------
local SCROLL_DURATION = 0.12   --time in sec to scroll 100 pixel
--local SCALE_DURATION = 0.3    --time in sec to complete a scale, scale effect for selected item
local FADE_DURATION = 0.3  --time in sec for items border and contents to fade in/out
local START_SCROLL_MIN_DISTANCE = 10 --distance minimal to move before beeing counted as a scroll
local OUTOFVIEWVALUETOBEREMOVED = 150  -- item must be farther than this distance of the screen before switching position
local COUNT_AS_SCROLL_MIN_VAL = 7   --last move distance must be highter than this value to count as a scroll
local AUTOSCROLL_VELO_FACTOR = 1.5  --value to control the speed/duration of auto scroll
local AUTOSCROLL_DISTANCE_FACTOR = 5 --value to control the speed/duration of auto scroll
local AUTOSCROLL_ACCELERATION_ENABLE = true --enable autoscroll acceleration
local SCALE_MIN = 0.6  --scale value of the wheel effect



--点击某个游戏Panel会执行这里
--TODO: Add new game views
function UIMainGames:onOpenGameRooms(_gameType)
    local keyGame = self.keyname[_gameType]
    local viewName
    -- print("KEYGAME: "..keyGame)
    if keyGame == Constants.KEY_POKER then 
        viewName = 'UIMatchRoomPoker'
    elseif keyGame == Constants.KEY_RUNFAST then  --进入跑得快
        -- self.tool:showTips("即将开放，敬请期待")
        -- return
        viewName = 'UIMatchRoomRunFast'                       
    elseif keyGame == Constants.KEY_MATCH then    --进入比赛场
        viewName = 'UIAwards' 
		local sendumeng = {}
		sendumeng['type'] = 'event'
		sendumeng['eventId'] = 'uiawardslist'
		LuaTools.setUmeng(sendumeng)
    elseif keyGame == Constants.KEY_DDZNOR then    
        -- self.tool:showTips("即将开放，敬请期待")
        -- return
        viewName = 'UIMatchRoomDDZClassic'
    elseif keyGame == Constants.KEY_DN then
       viewName = 'UIMatchRoomDouniuZJH'
    elseif keyGame == Constants.KEY_DDZ then

       viewName = 'UIMatchRoomDDZBooms'
    elseif keyGame == Constants.KEY_ZJH then
        viewName = 'UIMatchRoomDouniuZJH'
    elseif keyGame == Constants.KEY_WANREN then 
        viewName = 'UIGameTableWanren'  
    end

    -- viewName= 'UIMatchRoomDDZClassic'
    --打开对应的场次房间并且隐藏的执行退出大厅的动作
    if keyGame ~= Constants.KEY_WANREN then 
       self.app:callMethod('UIMain', 'showExitMainActions', function() self.app:addView(viewName,101,keyGame) end)
    else 
       self.app:callMethod("UIMain", "loadGameRoomsInfos", self.config.keyDataGames.wrdn,
       function() 
          self.app:callMethod('UIMain', 'showExitMainActions', function() self.app:addView(viewName,101,keyGame) end)
       end) 
    end    
end
 
--比赛场单个按钮 
function UIMainGames:enterAwardGame()
    self.app:callMethod("UIMain", "showExitMainActions",function()
        G_BASEAPP:addView('UIAwards',500)  
		local sendumeng = {}
		sendumeng['type'] = 'event'
		sendumeng['eventId'] = 'uiawardsbtn'
		LuaTools.setUmeng(sendumeng)
    end)
end 

function UIMainGames:showOrHideAward(tag)
    if self.Button_awardsGame then 
       if  self.pData.gameFilter.match == 1 then 
           self.Button_awardsGame:setVisible(tag)
       else 
           self.Button_awardsGame:setVisible(false)  
       end     
    end
end 

--单个游戏玩家个数更新
function UIMainGames:updatePeopleCount(_item, _gameType)
    local keyGame = self.keyname[_gameType]
    _item:getChildByName("Text_count"):setString(self.peopleCount[keyGame])
end

--更新全部游戏玩家个数
function UIMainGames:updatePeopleCounts(_table)
    -- dump(_table,'更新全部游戏玩家个数')
    local function getSumCount(_key)
        local countDn = 0
       -- dump(_table[_key], "Key: ".._key)
        for k,count in pairs(_table[_key]) do
            countDn = countDn + count
        end 
        return countDn
    end
    
    self.peopleCount.dn = getSumCount('49')
    self.peopleCount.ddz = getSumCount('1') +  getSumCount('18')
    if self['Panel_onlyOne'] then 
       self['Panel_onlyOne']:getChildByName('Text_count'):setString(self.peopleCount.ddz)
    end 
    self.peopleCount.zjh = getSumCount('60')
     self.peopleCount.wrdn = getSumCount('9')
    
    --self.peopleCount.poker = 0
    self.peopleCount.pdk = getSumCount('107')
    --self.peopleCount.sj = 0
    self.peopleCount.ddzNor =getSumCount('122')
    
    print("updating Main games players count...")
    for i,item in ipairs(self.pageInstances) do
        local keyGame = self.keyname[item:getTag()]
        item:getChildByName("Text_count"):setString(self.peopleCount[keyGame])
    end
end

--启动更新玩家个数
function UIMainGames:startUpdateCounts()
    self.app:callMethod('UIMain','reqSock_getOnliner')
    self:createSchedule("updateCounts",function()
        --测，这些VIEW是否存在，如果存在，不请求更新大厅人数
        local view = self.app:getView('UIMatchRoomDDZBooms') or self.app:getView('UIMatchRoomDouniuZJH') or self.app:getView('UIGameTableMenu')
        if view == nil then
            self.app:callMethod('UIMain','reqSock_getOnliner')
        end
    end,self.config.refreshPlayerCountsDelay)
end

--获取在大厅里可看到的游戏UI
function UIMainGames:getVisiblePanels(_show)
    local tabl = {}
    for i,item in ipairs(self.pageInstances) do
        local pos = self.mainStaticPanel:convertToNodeSpace(self.contentPanel:convertToWorldSpace(cc.p(item:getPosition())))
       -- print("PPPPPOSY: "..pos.y)
        if pos.y > 0 and pos.y < self.winHeight then   
            table.insert(tabl, item)
            if _show and _show == true then 
                item:setVisible(_show)
            end
        else
            item:setVisible(_show)
        end
    end
    return tabl
end

--进入大厅执行的动作
function UIMainGames:showEnterActions()
    local pData = G_BASEAPP:getData('PlayerData') 
    if pData.showOneGame == 0 then 
        local function callback() 
            if self.defaultItem ~=nil  then 
                self:stopSchedule('getIteam') 
                 local defaultWidth = self.defaultItem:getContentSize().width
                local defaultPosX = self.itemDefaultPosX
                local tabl = self:getVisiblePanels(true)
                self.panelMat = {
                    p1 = {obj = tabl[1], dur = 0.5},
                    p2 = {obj = tabl[2], dur = 0.1},
                    p3 = {obj = tabl[3], dur = 0.3},
                    p4 = {obj = tabl[4], dur = 0.6},
                }
                local obj = 0
                for k,panel in pairs(self.panelMat) do
                     obj = panel.obj
                    if obj then 
                        obj:setPosition(defaultPosX + defaultWidth + 10, obj:getPositionY())
                        local openAction = cc.MoveTo:create(panel.dur,cc.p(defaultPosX, obj:getPositionY()))
                        local move_ease_out = cc.EaseBackOut:create(openAction)
                        obj:runAction(move_ease_out)
                    end 
                end  
                self:hideLight(true)
            end
        end
        self:createSchedule('getIteam',callback,0.1) 
    else 

       if  self['Panel_onlyOne'] then 
           local size = self['Panel_onlyOne']:getContentSize()
           local x,y = self['Panel_onlyOne']:getPosition()
           local size1 =  cc.Director:getInstance():getWinSize() 
           local action = cc.MoveTo:create(0.3,cc.p(size1.width-10,y)) 
           self['Panel_onlyOne']:runAction(action)
           self['Panel_onlyOne']:getChildByName('Image_game'):setTouchEnabled(true)
       end 
    end  
end

--function UIMainGames:showEnterActions()
--    local action = cc.Sequence:create(
--        cc.DelayTime:create(0.3),
--        cc.CallFunc:create(function() 
--            local defaultWidth = self.defaultItem:getContentSize().width
--            local defaultPosX = self.itemDefaultPosX
--            local tabl = self:getVisiblePanels(true)
--            self.panelMat = {
--                p1 = {obj = tabl[1], dur = 0.5},
--                p2 = {obj = tabl[2], dur = 0.1},
--                p3 = {obj = tabl[3], dur = 0.3},
--                p4 = {obj = tabl[4], dur = 0.6},
--            }
--            local obj = 0
--            for k,panel in pairs(self.panelMat) do
--                 obj = panel.obj
--                if obj then 
--                    obj:setPosition(defaultPosX + defaultWidth + 10, obj:getPositionY())
--                    local openAction = cc.MoveTo:create(panel.dur,cc.p(defaultPosX, obj:getPositionY()))
--                    local move_ease_out = cc.EaseBackOut:create(openAction)
--                    obj:runAction(move_ease_out)
--                end 
--            end  
--            self:hideLight(true)
--         end)
--        ,nil)
--    self:runAction(action)
--end 

--退出大厅需要执行的动作
function UIMainGames:showExitActions()
    local pData = G_BASEAPP:getData('PlayerData') 
    if pData.showOneGame == 0 then 
        self:hideLight(false)
        local tabl = self:getVisiblePanels(false)
        --dump(tabl, "ITEMS")
        self.panelMat = {
            p1 = {obj = tabl[1], dur = 0.6},
            p2 = {obj = tabl[2], dur = 0.6},
            p3 = {obj = tabl[3], dur = 0.6},
            p4 = {obj = tabl[4], dur = 0.6},
        }
        local defaultWidth = self.defaultItem:getContentSize().width
        local defaultPosX = self.itemDefaultPosX
        local obj = 0
        for k,panel in pairs(self.panelMat) do
            obj  = panel.obj
            if obj then 
                --if  not obi then return end 
                local openAction = cc.MoveTo:create(panel.dur-0.3,cc.p(defaultPosX + defaultWidth + 10, obj:getPositionY()))
                local move_ease_in = cc.EaseBackIn:create(openAction)
                obj:runAction(move_ease_in)
            end 
        end
    else 
       local size = self['Panel_onlyOne']:getContentSize()
       local x,y = self['Panel_onlyOne']:getPosition()
       local size1 =  cc.Director:getInstance():getWinSize() 
       local action = cc.MoveTo:create(0.3,cc.p(size.width+size1.width,y)) 
       self['Panel_onlyOne']:runAction(action)
    end     
end

--点击游戏Panel的音效
function UIMainGames:playSound()
    audio.playSound(self.soundTap, false)
end

-- [[ -----------------   一下是关于Panels 的滚动的逻辑 --------------------]] --


function UIMainGames:onCreate()
    local app = self:getApp()
    self.app = app
    self.pData = self.app:getData('PlayerData') 
    self.Main = app:getModel("Main")
    self.tool = app:getModel('Tools')

    --self.sound = app:getModel('Sound')     
    
    self['Button_awardsGame']:setVisible(self.pData.gameFilter.match == 1)
    self['Panel_onlyOne']:setVisible(self.pData.showOneGame == 1)
    self['Panel_Games']:setVisible( self.pData.showOneGame == 0)
    self['Panel_Games']:setEnabled(self.pData.showOneGame == 0)
    if self.pData.showOneGame == 1 then 
         local  panelLight = self['Panel_onlyOne']:getChildByName("Panel_light")
         panelLight:setTouchEnabled(false)
         local animNode = cc.CSLoader:createNode('Animation_bnt_light.csb') 
         animNode:setPosition(cc.p(panelLight:getContentSize().width/2,panelLight:getContentSize().height/2))
         local action = cc.CSLoader:createTimeline('Animation_bnt_light.csb')
         animNode:runAction(action)
         animNode:setName('anim_light')
         animNode:setVisible(true)
         action:gotoFrameAndPlay(0,true)
         panelLight:addChild(animNode,1)
         panelLight:setVisible(false)
         local function goOneGame() 
            self.app:callMethod('UIMain', 'showExitMainActions', function() self.app:addView('UIMatchRoomDDZBooms',101,Constants.KEY_DDZ) end)
            self['Panel_onlyOne']:getChildByName('Image_game'):setTouchEnabled(false)
         end    
         self['Panel_onlyOne']:getChildByName('Image_game'):onTouch(goOneGame)
     end


    cc.SpriteFrameCache:getInstance():addSpriteFrames("res_gametypes.plist")
    self.config = app:getData('Config')
    self.winHeight = cc.Director:getInstance():getWinSize().height
    self.mainStaticPanel = self['Panel_Games']
    self.contentPanel = self['Panel_Contents']
    self.defaultItem = self['Panel_Item']
    self.panelTouchControl = self['Panel_TouchControl']
    self.panelTouchControl:setBackGroundColorOpacity(0)
    self.mainStaticPanel:setBackGroundColorOpacity(0)
    self.contentPanel:setBackGroundColorOpacity(0)
    self.allowMoveFinger = false 
    --------------------------------------------------------------------------------
    --[ 游戏场的图片路径，Key名，玩家个数，如果需要改变顺序，图片就在这里改]--
    self.imgBg = {
        -- -- "background/bg_dn.png",
        -- "background/bg_ddz.png",
        -- -- "background/bg_zjh.png",
        -- "background/bg_poker.png",
        -- "background/bg_runFast.png",
        -- "background/bg_shengJi.png",
        -- "background/bg_ddzNormal.png",
    }
    self.pathImg = {
        -- -- "res_lobby/bt_game_dn.png",
        -- "res_lobby/bt_game_ddz.png",
        -- -- "res_lobby/bt_game_zjh.png",
        -- "res_lobby/bt_game_poker.png",
        -- "res_lobby/bt_game_runfast.png",
        -- "res_lobby/bt_game_shengJi.png",
        -- "res_lobby/bt_game_ddzNormal.png",
    }
    self.keyname = {
       --   -- Constants.KEY_DN, 
       --   Constants.KEY_DDZ, 
       -- --  Constants.KEY_ZJH, 
       --   Constants.KEY_POKER, 
       --   Constants.KEY_RUNFAST, 
       --   Constants.KEY_SHENGJI,
       --   Constants.KEY_DDZNOR,
    }    --这些Key名需要在Config.lua里对应才行  
    local temp_keyWord = {['dd']=Constants.KEY_DDZNOR,['ddz']=Constants.KEY_DDZ,['dn']= Constants.KEY_DN,
                          ['dz']=Constants.KEY_POKER,['pdk']=Constants.KEY_RUNFAST,['match']=Constants.KEY_MATCH,
                          ['zjh']=Constants.KEY_ZJH, ['wrdn']=Constants.KEY_WANREN} 

    local temp_imgBg   = {['dd']="background/bg_ddzNormal.png",['ddz']="background/bg_ddz.png",['dn']= "background/bg_dn.png",
                          ['dz']="background/bg_poker.png",['pdk']="background/bg_runFast.png",['match']="background/bg_ddzNormal.png",
                          ['zjh']="background/bg_zjh.png", ['wrdn']="background/bg_wrnn.png"}
    
    local temp_imgPath = {['dd']="res_lobby/bt_game_ddzNormal.png",['ddz']="res_lobby/bt_game_ddz.png",['dn']= "res_lobby/bt_game_dn.png",
                          ['dz']="res_lobby/bt_game_poker.png",['pdk']="res_lobby/bt_game_runfast.png",['match']="res_lobby/bt_game_reward.png",
                          ['zjh']="res_lobby/bt_game_zjh.png",['wrdn']="res_lobby/bt_game_wrnn.png"}

    for key,var in pairs(self.pData.gameFilter) do 
        if var == 1 then
           table.insert(self.keyname,temp_keyWord[key]) 
           table.insert(self.imgBg,temp_imgBg[key])
           table.insert(self.pathImg,temp_imgPath[key]) 
        end 
    end       
     
    -- dump(self.keyname,"######")
    
    for key,var in pairs(self.keyname) do 
        if var == "ddzNor" and self.keyname[#self.keyname] ~= "ddzNor"then 
           local temp = self.keyname[key]
               self.keyname[key] = self.keyname[#self.keyname]  
               self.keyname[#self.keyname]  = temp
           local temp1 =  self.imgBg[key]
                self.imgBg[key] = self.imgBg[#self.imgBg]  
                self.imgBg[#self.imgBg]  = temp1
           local  temp2 = self.pathImg[key]
                self.pathImg[key] = self.pathImg[#self.pathImg]
                self.pathImg[#self.pathImg] = temp2
        end 
    end    
  

    for key,var in pairs(self.keyname) do 
        if var == "ddz" and self.keyname[#self.keyname-1] ~= "ddz"then 
           local temp = self.keyname[key]
               self.keyname[key] = self.keyname[#self.keyname-1]  
               self.keyname[#self.keyname-1]  = temp
           local temp1 =  self.imgBg[key]
                self.imgBg[key] = self.imgBg[#self.imgBg-1]  
                self.imgBg[#self.imgBg-1]  = temp1
           local  temp2 = self.pathImg[key]
                self.pathImg[key] = self.pathImg[#self.pathImg-1]
                self.pathImg[#self.pathImg-1] = temp2
        end 
    end     

    for key,var in pairs(self.keyname) do 
        if var == "dn" and self.keyname[#self.keyname-2] ~= "dn"then 
           local temp = self.keyname[key]
               self.keyname[key] = self.keyname[#self.keyname-2]  
               self.keyname[#self.keyname-2]  = temp
           local temp1 =  self.imgBg[key]
                self.imgBg[key] = self.imgBg[#self.imgBg-2]  
                self.imgBg[#self.imgBg-2]  = temp1
           local  temp2 = self.pathImg[key]
                self.pathImg[key] = self.pathImg[#self.pathImg-2]
                self.pathImg[#self.pathImg-2] = temp2
        end 
    end    
    
    for key,var in pairs(self.keyname) do 
        if var == "zjh" and self.keyname[1]~= "zjh"then 
           local temp = self.keyname[key]
               self.keyname[key] = self.keyname[1]  
               self.keyname[1]  = temp
           local temp1 =  self.imgBg[key]
                self.imgBg[key] = self.imgBg[1]  
                self.imgBg[1]  = temp1
           local  temp2 = self.pathImg[key]
                self.pathImg[key] = self.pathImg[1]
                self.pathImg[1] = temp2
        end 
    end    
     

    self.distance_item  = (self.pData.gameFilterNumber>3 and 6 or 50 )
    self.peopleCount = {
        dn = "0", 
        ddz = "0", 
        zjh = "0", 
        poker = "0", 
        pdk = "0", 
        sj = "0",
        ddzNor = '0',
        wrdn   = '0',
    }  --在线人数

    --数组里保存的是要在大厅里显示的游戏的排序（根据下标)
    local nowData = {{2,1,2},{2,1,2},{3,1,2,3,1},{4,1,2,3,4,1},{5,1,2,3,4,5,1},{6,1,2,3,4,5,6,1},{7,1,2,3,4,5,6,7,1},{8,1,2,3,4,5,6,7,8,1}}
    self.pageViewData =nowData[self.pData.gameFilterNumber]
    self.pageViewDataScale = {0.85,1,0.85,0.7,0.7,0.65,0.85,0.7}  --{0.85,1,0.85,0.7,0.7,0.6,0.85}
    ------------------------------------------------------------------------------ 
    
     

    self.soundTap = Sound.SoundTable['sfx']['Tab_Switch']
    --逻辑变量
    self.canScrollStart = false     --是否可以开始滚动
    self.isScrolling = false        --是否在滚动中
    self.canDoZoom = false          --是否可以进行缩放
    self.isSelectItem = false       --是否是点击了Panels
    self.enableTouchItem = true     --是否可以点击Panels
    self.isOutOfBoundary = false    --是否在滚动区域外
    self.enableUpdateScale = false  --是否允许Panels的缩放
    self.autoScrolling = false      --是否在自动滚动中
    self.canAccuMoveTime = false    --是否可以叠加手指在移动的时间
    self.touchStartLocation = nil   --开始点击的坐标
    self.touchMovedLocation = nil   --移动手指的新坐标
    self.lastItemHighlighted = nil  --上一次被点亮的Panel
    self.totalMoveTime = 0          --手指移动的时间，用来计算自动滚动的时间和速度
    self.touchMovedDistance = 0     --手指移动的距离
    self.touchMovedValue = 0        --新坐标 【减】 上一针保留的坐标值
    self.maxDistanceScale = 0       --原Scale+ 这个值就是Panel最大可缩放的值
    
    self.pageInstances = {}         --use to store panels instance
    self.firstPlaySound = true      --第一次进入游戏时，不要播放按钮音效

    --常量
    self.itemDefaultHeight = self.defaultItem:getBoundingBox().height
    self.itemDefaultScale = self.defaultItem:getScale()
    self.itemDefaultPosX = self.defaultItem:getPositionX()
    self.itemAnchorPoint = cc.p(0.5,0.5)  
    self.initialPosY =  self.winHeight--first item position Y
    self.highlightedPosY = self.initialPosY*(self.pData.gameFilterNumber>3 and 0.64 or 0.56)    --点亮位置
    self.unHighlightedColor = cc.c3b(128,128,128)
    self.highlightedColor = cc.c3b(255,255,255)
    self.highlightitemScaleAddValue = 0
    self.hightlightItemIndex = self.pageViewData[1]--默认点亮的图片标签
   -- self.hightlightItemIndex = #self.pageViewData-2 or 2 --默认点亮的图片标签
    self:initMaxDistanceScale()




    --初始化Panels
    for i,v in ipairs(self.pageViewData) do
        self:pushItem(v,false)
    end

   -- local function cbLight()
--        local animNode = cc.CSLoader:createNode('Animation_bnt_light.csb') 
--        animNode:setPosition(cc.p(self.itemDefaultPosX,self.highlightedPosY))
--        local action = cc.CSLoader:createTimeline('Animation_bnt_light.csb')
--        animNode:runAction(action)
--        animNode:setName('anim_lightOn')
--        animNode:setVisible(false)
--        animNode:setAnchorPoint(0.5,0.5)
--        action:gotoFrameAndPlay(0,true)
--        self['Panel_Games']:addChild(animNode,9999999)  
   -- end 
  --  self['Panel_Games']:runAction(cc.Sequence:create(cc.DelayTime:create(0.5),cc.CallFunc:create(cbLight)))    
    
    
    --默认点亮一个panel
    self:setItemHighlight(self.hightlightItemIndex)
    
    
   -- self:updatesFramesColor(self.pageViewData[self.hightlightItemIndex])

    --Touch Handlers
    local listener = cc.EventListenerTouchOneByOne:create()
	--listener:setSwallowTouches(true)
    listener:registerScriptHandler(function(touch, event) return self:onTouchBegan(touch, event) end,cc.Handler.EVENT_TOUCH_BEGAN )
    listener:registerScriptHandler(function(touch, event) self:onTouchMoved(touch, event) end,cc.Handler.EVENT_TOUCH_MOVED )
    listener:registerScriptHandler(function(touch, event) self:onTouchEnd(touch, event) end,cc.Handler.EVENT_TOUCH_ENDED )
    local eventDispatcher = cc.Director:getInstance():getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener, self.panelTouchControl)
    --eventDispatcher:addEventListenerWithFixedPriority(listener, -128)

    --Scroll update Handler
    -- local scheduler = cc.Director:getInstance():getScheduler()

    --维尼改动：
    --这种全局的scheduler 记得使用完要释放掉。 否则当前view释放之后 scheduler还在运行，会报错。
    --另外不建议使用全局scheduler，尤其是继承与CCNode的类。
    -- scheduler:scheduleScriptFunc(function(event) self:updateAutoScrolling(event) end,0, false)
    --可以使用以下方法实现同样功能，并且scheduler会自动释放。

    self:createSchedule("updateAutoScrolling",function()
        local delta = cc.Director:getInstance():getDeltaTime()
        self:updateAutoScrolling(delta)
    end,0)

    self.contentPanel:setTouchEnabled(false)
    self:runAction(cc.Sequence:create(
       cc.DelayTime:create(0.1),
       cc.CallFunc:create(function() 
     --       self:adjustItemsScale()
              self.pageInstances[#self.pageInstances]:setScale(0.72) 
              self.pageInstances[#self.pageInstances-1]:setScale(0.8)
              self.pageInstances[#self.pageInstances-2]:setScale(1)
              self.pageInstances[#self.pageInstances-3]:setScale(0.8)
           end),
    cc.CallFunc:create(function()  
       if G_BASEAPP:getView('UIPreLoading') then 
          G_BASEAPP:removeView('UIPreLoading') 
       end  
    end)
    ))

    self:startUpdateCounts()

end

function UIMainGames:onEnterTransitionFinish()

    local ThirdSDKHandler = require('app.network.ThirdSDKHandler')
    -- 进入主界面，查看本地是否有未完成的支付订单
    ThirdSDKHandler.reCallServerPay()



end

function UIMainGames:setItemHighlight(_index)
    local item = self.pageInstances[_index]
    local NSPose = self.mainStaticPanel:convertToNodeSpace(self.contentPanel:convertToWorldSpace(cc.p(item:getPosition())))
    local distance = self.highlightedPosY - NSPose.y
    --print("Item pos: "..NSPose.y)
    --print("distance: "..distance)
    
    self.contentPanel:runAction(cc.MoveBy:create(0.1, cc.p(0,distance)))
    self:zoomIn(item)
    self.lastItemHighlighted = item
end

function UIMainGames:setItemHighlightWithDetails(_item, _delay, _distance)
    --printf("Move Item to distance: %0.2f  with delay: %0.2f",_distance, _delay)
    --self:playSound()
    self.contentPanel:runAction(cc.Sequence:create(
        cc.MoveBy:create(_delay, cc.p(0,_distance)),
        cc.CallFunc:create(function() 
            self.contentPanel:stopAllActions() 
            --self.panelTouchControl:setTouchEnabled(false)
            self:zoomIn(_item)
            end) ,nil))
    
    self.lastItemHighlighted = _item
end

function UIMainGames:adjustItemToHighlightLocation()
    local lastNearDistance = -1
    local itemToHL = nil
    local nearestItemPosY = 0
    --search for the nearest item to the highlightArea
    for i,item in ipairs(self.pageInstances) do
        local NSPose = self.mainStaticPanel:convertToNodeSpace(self.contentPanel:convertToWorldSpace(cc.p(item:getPosition())))
        local nearDistance = math.abs(self.highlightedPosY - NSPose.y)
        if lastNearDistance > 0 and lastNearDistance > nearDistance then
            lastNearDistance = nearDistance  --copy the new nearest distance
            itemToHL = item
            nearestItemPosY = NSPose.y
        elseif lastNearDistance > 0 and nearDistance > lastNearDistance then
            --do nothing
        else
            lastNearDistance = nearDistance
        end
    end
    local delay = math.abs(lastNearDistance)*SCROLL_DURATION/100
    self:setItemHighlightWithDetails(itemToHL, delay, self.highlightedPosY - nearestItemPosY)
end

function UIMainGames:zoomIn(_item)
    if self.canDoZoom == false then 

        if self.firstPlaySound == false then
            self:playSound()
        end
        self.firstPlaySound = false

        
        local gameType = _item:getTag()
        _item:runAction(cc.Sequence:create(
            cc.CallFunc:create(function() 
            self.panelTouchControl:setTouchEnabled(false)
            self.enableTouchItem = true
            self.isSelectItem = false
            self.enableUpdateScale = false
            end)
            ,nil))
        _item:setColor(self.highlightedColor)
        
        local keyGame = self.keyname[gameType]
        local panel_light = _item:getChildByName("Panel_light")
        panel_light:setVisible(true)

        self:hideLight(true)
        _item:setLocalZOrder(2)
        self.app:callMethod('UIMain','swithImageBg', self.imgBg[_item:getTag()])  
        local keyGame = self.keyname[gameType]
        self.app:callMethod('UIMainBottom', 'setQuickStart', keyGame)
        self.canDoZoom = true
		
		--新增修改
		if self.lastItemHighlighted ~= _item then self.lastItemHighlighted = _item end
		if self.isScrolling == true then 
            self.isScrolling = false 
        end
    else
        --print('CANNOT DO ZOOM !')
    end 
	
end

function UIMainGames:hideLight(tag)
    if not tag then tag = false  end  
    if self['Panel_Games']:getChildByName('anim_lightOn') then 
       self['Panel_Games']:getChildByName('anim_lightOn'):setVisible(tag)
    end    
end     

function UIMainGames:zoomOut(_item)
    if self.canDoZoom == true then 
        --print("Zooming Out !!!")
         --_item:runAction(cc.ScaleTo:create(SCALE_DURATION,self.itemDefaultScale))
         _item:setColor(self.unHighlightedColor)
        local panel_light = _item:getChildByName("Panel_light")
        panel_light:setVisible(false)
        self:hideLight(false)
        -- _item:getChildByName("Image_border"):setVisible(false)
         -- _item:getChildByName("Image_enter"):runAction(cc.FadeTo:create(FADE_DURATION,0))
         -- _item:getChildByName("Image_border"):runAction(cc.FadeTo:create(FADE_DURATION,0))
         _item:setLocalZOrder(1)
         self.canDoZoom = false
    end
end

function UIMainGames:onTouchItem(event)
    if event.name == 'began' then
        if self.autoScrolling == true then
            self.enableTouchItem = false
            self.isSelectItem = false
            self.autoScrolling = false
        else
            self.isSelectItem = true
        end
        print("Touch view Item BEGAN")
    end
    if event.name == 'ended' then
        print("Touch view Item ENDED")
        self.allowMoveFinger = false
        if self.enableTouchItem == false or self.canScrollStart == false then return end
        if self.isScrolling == true then 
            self.isScrolling = false 
            return 
        end
        local item = event.target
        local gameType = item:getTag()

        if self.lastItemHighlighted == item then  
            self:onOpenGameRooms(gameType)  -- 再次点击同样的Item: 弹出游戏场次
            return
        end
        
        self.panelTouchControl:setTouchEnabled(true)
        --move item to highlighted pos
        local NSPose = self.mainStaticPanel:convertToNodeSpace(self.contentPanel:convertToWorldSpace(cc.p(item:getPosition())))
        local distance = self.highlightedPosY - NSPose.y
        local time = math.abs(distance)*SCROLL_DURATION/100
        --print("time :"..time)
        --print("Item pos: "..NSPose.y)
        --print("distance: "..distance)
        self:zoomOut(self.lastItemHighlighted)

        self.contentPanel:runAction(cc.Sequence:create((cc.MoveBy:create(time, cc.p(0,distance))), 
            cc.CallFunc:create(function() 
                self:zoomIn(item)
                --self.panelTouchControl:setTouchEnabled(false) 
                self.lastItemHighlighted = item
                end),nil)) 

         --check the item position toward the highlighted position
        local val = math.floor(NSPose.y - self.highlightedPosY)
        --print("VAL: "..val)
        if val == 0 then 
            return
        elseif val > 0 then
            self:checkItemsToBeReplaced(false)
        else
            self:checkItemsToBeReplaced(true)
        end
        self.enableUpdateScale = true
        --dump(self.pageViewData)
        --dump(self.pageInstances)
        --print("Items count in view: "..self.contentPanel:getChildrenCount())
    end
end

function UIMainGames:pushItem(_gameType, _isTop)
    local newItem = self.defaultItem:clone()
    local img = self.pathImg[tonumber(_gameType)]
    --print("IMG: "..img)
    newItem:getChildByName("Image_game"):loadTexture(img,ccui.TextureResType.plistType)
  
    --set light animation
     if self.pData.showOneGame == 0 then 
         local panelLight = newItem:getChildByName("Panel_light")
         panelLight:setTouchEnabled(false)
         local animNode = cc.CSLoader:createNode('Animation_bnt_light.csb') 
         animNode:setPosition(cc.p(panelLight:getContentSize().width/2,panelLight:getContentSize().height/2))
         local action = cc.CSLoader:createTimeline('Animation_bnt_light.csb')
         animNode:runAction(action)
         animNode:setName('anim_light')
         animNode:setVisible(true)
         action:gotoFrameAndPlay(0,true)
         panelLight:addChild(animNode,1)
         panelLight:setVisible(false)
    end      

--     newItem:getChildByName("Image_border"):setVisible(false)
--     newItem:getChildByName("Image_enter"):setVisible(false)
    local newPos
    if _isTop == true then 
        local firstItem = self.pageInstances[1]
        --printf("top item: %s", firstItem)
        if firstItem then
            newPos = firstItem:getPositionY() + self.itemDefaultHeight + self.distance_item 
        else
            --the initial position depand on the anchor point of the item 
            newPos = self.initialPosY - (self.itemDefaultHeight - self.itemDefaultHeight*self.itemAnchorPoint.y)
        end
        table.insert(self.pageInstances ,1, newItem)
    else
        local lastItem = self.pageInstances[#self.pageInstances]
        if lastItem then
            newPos = lastItem:getPositionY() - self.itemDefaultHeight - self.distance_item
        else
            print("minus: "..(self.itemDefaultHeight - self.itemDefaultHeight*self.itemAnchorPoint.y))
            print("ad: "..self.itemDefaultHeight)
            newPos = self.initialPosY -(self.itemDefaultHeight - self.itemDefaultHeight*self.itemAnchorPoint.y)
        end
        table.insert(self.pageInstances, newItem)
    end
    newItem:setPositionY(newPos)
    --print("PosY: "..newPos)
    newItem:setVisible(false)
    --newItem:runAction(cc.Sequence:create(cc.DelayTime:create(0.1),cc.CallFunc:create(function() newItem:setVisible(true) end),nil))
    newItem:setBackGroundColorOpacity(0)
    newItem:setColor(self.unHighlightedColor)
    newItem:setCascadeColorEnabled(true)
    newItem:setTouchEnabled(true)
    newItem:setTag(_gameType)
    newItem:onTouch(function(event) self:onTouchItem(event)
      end, true)

    self.contentPanel:addChild(newItem)

    self:updatePeopleCount(newItem, _gameType)
end

function UIMainGames:switchUserData(_array, _isEndToBegin, _index)
    local temp = self.pageInstances[_index]
    if _isEndToBegin == true then  --end to 1 
        table.remove(_array, _index)
        table.insert(_array, 1, temp)
    else --1 to end
        table.remove(_array, _index)
        table.insert(_array,  #_array+1, temp)
    end
end
function UIMainGames:switchGameTypeData(_array, _isEndToBegin, _gameType)
    if _isEndToBegin == true then  --end to 1 
        table.remove(_array, #_array)
        table.insert(_array, 1, _gameType)
    else --1 to end
        table.remove(_array, 1)
        table.insert(_array,  #_array+1, _gameType)
    end
end
function UIMainGames:replaceItemDataWith(_index, _gameType, _toTop)
    self:switchGameTypeData(self.pageViewData, _toTop, _gameType)
    self:switchUserData(self.pageInstances, _toTop, _index)
    --dump(self.pageInstances)
end

function UIMainGames:replaceItemImage(item, _gameType)
   -- print("new GameType: ".._gameType)
    local keyGame = self.keyname[_gameType]
    item:getChildByName("Image_game"):loadTexture(self.pathImg[tonumber(_gameType)],ccui.TextureResType.plistType)
    self:updatePeopleCount(item, _gameType)
    item:setTag(_gameType)
end

function UIMainGames:checkItemsToBeReplaced(_isDirTop)
    --print("=======BREAK=======")
    for i,item in ipairs(self.pageInstances) do
        local nodePos = self.mainStaticPanel:convertToNodeSpace(self.contentPanel:convertToWorldSpace(cc.p(item:getPosition())))
        --printf("ITEM %d  PosY: %0.2f   ud: %s",i,nodePos.y,item)
        if _isDirTop == true then 
            if nodePos.y > (self.winHeight +self.itemDefaultHeight*self.itemAnchorPoint.y + OUTOFVIEWVALUETOBEREMOVED)  then
                self:moveItem(item ,i, false)
                self:checkItemsToBeReplaced(true)
                return
            end
        else
            if nodePos.y < (0 -   OUTOFVIEWVALUETOBEREMOVED) then
                self:moveItem(item ,i, true)
                self:checkItemsToBeReplaced(false)
                return
            end
        end
    end
end

function UIMainGames:moveItem(_item, _index, _toTop)
    local newPosY, nextGT
    if _toTop == false then
        newPosY = self.pageInstances[#self.pageInstances]:getPositionY() - self.itemDefaultHeight - self.distance_item
        nextGT = self:getNextGametype(self.pageViewData[#self.pageViewData], true)
        --printf("Moving Item[%s] to Bottom: %0.2f   GameType: ",_item,newPosY,nextGT)
    else
        newPosY = self.pageInstances[1]:getPositionY() + self.itemDefaultHeight + self.distance_item
        nextGT = self:getNextGametype(self.pageViewData[1], false)
        --printf("Moving Item[%s] to Top: %0.2f   GameType: ",_item,newPosY,nextGT)
    end
    _item:setPositionY(newPosY)
    self:replaceItemImage(_item, nextGT)
    self:replaceItemDataWith(_index, nextGT, _toTop)
end

function UIMainGames:getNextGametype(index, isIncr)
    if isIncr == true then     --1,2,3,4,1,2
        if index == #self.pathImg then
            return 1
        else
            index = index + 1
            return index
        end
    else                --4,3,2,1,4,3
        if index == 1 then
            return #self.pathImg
        else
            index = index - 1
            return index
        end
    end
end

function UIMainGames:checkDistanceForMove(dis)
    if math.abs(dis) < START_SCROLL_MIN_DISTANCE then
        return false
    end
    return true
end

function UIMainGames:checkIsOutOfBoundary(loc)
    self.isOutOfBoundary = not cc.rectContainsPoint(self.mainStaticPanel:getBoundingBox(), cc.p(loc.x, loc.y))
    return self.isOutOfBoundary 
end

function UIMainGames:compareMovedValue(newVal)
    if self.touchMovedValue >= 0 and newVal >= 0 then
        return true
    elseif self.touchMovedValue <= 0 and newVal <= 0 then
        return true
    else
        print("DIR Has Changed...last val: "..self.touchMovedValue..' new val: '..newVal)
        return false
    end
end

function UIMainGames:initMaxDistanceScale()
    local dmax1 = math.abs(self.highlightedPosY - self.winHeight)
    local dmax2 = math.abs(self.highlightedPosY - 0)
    if (dmax1) > (dmax2) then self.maxDistanceScale = dmax1 else self.maxDistanceScale = dmax2 end
end

--function UIMainGames:calculateItemScale(itemPosY)
--    if (itemPosY > self.winHeight) or (itemPosY<0) then return nil end
--    local maxScaleVal = self.itemDefaultScale+ self.highlightitemScaleAddValue
--    local diffScale = maxScaleVal - SCALE_MIN
--    local dist =math.floor(math.abs(itemPosY - self.highlightedPosY))
--    local scaleAdd = diffScale * (1.00 - ((dist)/self.maxDistanceScale))
--    return SCALE_MIN + scaleAdd 
--end

--function UIMainGames:adjustItemsScale()
--    for i,item in ipairs(self.pageInstances) do
--        local NSPose = self.mainStaticPanel:convertToNodeSpace(self.contentPanel:convertToWorldSpace(cc.p(item:getPosition())))
--        local scale = self:calculateItemScale(NSPose.y)        
--        if scale then 
--             item:setScale(scale)
--        end
--    end
--end

function UIMainGames:calculateItemScale(itemPosY)
    local distToHighlight = math.abs(itemPosY - self.highlightedPosY) - self.itemDefaultHeight/2
   -- print("self.maxDistanceScale: "..self.maxDistanceScale.."  distToHighlight: "..distToHighlight)
    if distToHighlight > self.maxDistanceScale then return nil end
    local scale = 0
    local maxScaleVal = self.itemDefaultScale+self.highlightitemScaleAddValue
    local diffScale = maxScaleVal - SCALE_MIN
    --print("self.itemDefaultScale: "..self.itemDefaultScale.."   diffScale:"..diffScale)
    local scaleAdd = 0
    if itemPosY >= self.highlightedPosY then 
        local dist = itemPosY - self.highlightedPosY
        --print("Dist: "..dist)
        scaleAdd = diffScale * (1 - (dist/self.maxDistanceScale))
    else
        scaleAdd = diffScale * (itemPosY/self.maxDistanceScale)
    end
    scale = SCALE_MIN + scaleAdd
    return scale
end

function UIMainGames:adjustItemsScale()
    for i,item in ipairs(self.pageInstances) do
        local NSPose = self.mainStaticPanel:convertToNodeSpace(self.contentPanel:convertToWorldSpace(cc.p(item:getPosition())))
        local scale = self:calculateItemScale(NSPose.y)
        -- dump(scale,"##############")
        if scale then 
             item:setScale(scale)
            --print("Scaling to: "..scale)
        end
    end
end


 function UIMainGames:dontWantScroll()
    --print("***********self.touchMovedValue: "..self.touchMovedValue)
    if math.abs(self.touchMovedValue) < COUNT_AS_SCROLL_MIN_VAL then 
        return true 
    else
        return false
    end
 end

function UIMainGames:doAutoScroll(loc)
    self.touchMovedDistance = self.touchStartLocation.y - loc.y
    
    local velocity = (math.abs(self.touchMovedDistance)/self.totalMoveTime)
    local time = math.sqrt(math.sqrt(velocity)/AUTOSCROLL_VELO_FACTOR)
    self.contentPanel:stopAllActions()
    printf("Distance moved: %d  Speed: %0.2f   newTime: %0.2f", self.touchMovedDistance, velocity, time)
    self.autoScrolling = true
    self.canAccuMoveTime = false
    self.contentPanel:runAction(
        cc.Sequence:create(
        cc.EaseExponentialOut:create(
        cc.MoveBy:create(time, cc.p(0,-self.touchMovedDistance*AUTOSCROLL_DISTANCE_FACTOR))),nil)) 

     self.contentPanel:runAction(
        cc.Sequence:create(
        cc.DelayTime:create(time*0.55),
        cc.CallFunc:create(function() 
            self.autoScrolling = false
            self.contentPanel:stopAllActions() 
            self:adjustItemToHighlightLocation()
            self.canScrollStart = false
            end),nil))
     self:zoomOut(self.lastItemHighlighted)
end

function UIMainGames:updateAutoScrolling(delta)
	
    if self.canAccuMoveTime == true then 
        self.totalMoveTime = self.totalMoveTime + delta
       -- print("Dtime: "..self.totalMoveTime)
    end
    if self.autoScrolling == true then
       if self.touchMovedDistance > 0 then
            self:checkItemsToBeReplaced(false)
        else
            self:checkItemsToBeReplaced(true)
        end
    end
    if self.enableUpdateScale == true then 
        self:adjustItemsScale()
    end 
end

local isBegan = false
function UIMainGames:onTouchBegan(touch, event)
	if self:checkIsOutOfBoundary(touch:getLocation()) == true  then 
		return
	end
	if self.canScrollStart == false and isBegan then  isBegan = false end
	if isBegan == false then
		isBegan = true
		self.touchStartLocation = touch:getLocation()
		self.touchMovedLocation = touch:getLocation()
		self.canAccuMoveTime = true


		if self.autoScrolling == true then 
			self.contentPanel:stopAllActions()
		else
			self.canScrollStart  = true
		end

		if AUTOSCROLL_ACCELERATION_ENABLE == false then
			self.totalMoveTime = 0
		end
		return true
	else
		return false
	end
end

function UIMainGames:onTouchMoved(touch, event)
   if self.isOutOfBoundary == true or self.canScrollStart == false then return end
    local loc = touch:getLocation()
   -- printf("Touch MOVED location x: %d  y:%d", loc.x, loc.y)
    
    if self:checkIsOutOfBoundary(loc) == true then  --check if the moved position is in the boundary
        self.canScrollStart = false
        self:doAutoScroll(loc)
        return
    end
    local distanceMoved = self.touchMovedLocation.y - loc.y
   -- print("TOUCH MOVED Distance from last point: "..distanceMoved)
    
    if self.isScrolling == false and self:checkDistanceForMove(distanceMoved) == false then
        return   --dont scroll if distance is too small
    end 
    self.enableUpdateScale = true

    self.isSelectItem = false 
    self.isScrolling = true
    if self:compareMovedValue(distanceMoved) == false then  --direction of the touch has changed
        self.totalMoveTime = 0
        self.touchStartLocation = loc
        self.isScrolling = false
    end
    self.touchMovedValue = distanceMoved
    self.contentPanel:setPositionY(self.contentPanel:getPositionY()-distanceMoved)
    self.touchMovedLocation.y = loc.y
    

    self:zoomOut(self.lastItemHighlighted)

    --check items position 
    if distanceMoved > 0 then
        self:checkItemsToBeReplaced(false)
    else
        self:checkItemsToBeReplaced(true)
    end

end


function UIMainGames:onTouchEnd(touch, event)
    --if self:checkIsOutOfBoundary(touch:getLocation()) == true or self.canScrollStart == false then 
        --printf("TOUCH ENDED: b1:%s   b2:%s",self.isOutOfBoundary, self.canScrollStart)
        --return 
    --end
	isBegan = false
    if self.isSelectItem == true then print("ITem Selected !!!") return end
    local loc = touch:getLocation()

    if self:dontWantScroll() == true then 
        print("DONT WANT SCROLL !")
        self:adjustItemToHighlightLocation()
        return
    end
   -- printf("Touch ENDED  lastY: %d  endY:%d", self.touchStartLocation.y, loc.y)
   if self:checkDistanceForMove(self.touchStartLocation.y - loc.y) == true then  --do not do scroll if distance moved is too small
      self:doAutoScroll(loc)
   else
      self.canAccuMoveTime = false
      --if self.canDoZoom == false then
      self:adjustItemToHighlightLocation()
   end
end

--[[加载指定项]]
function UIMainGames:loadTarget()
	--[[local scheduler = require("app.models.QScheduler")
	local scheduler_hand = nil
    local function settime()
		scheduler.unscheduleGlobal(scheduler_hand)
		
	end
	scheduler_hand = scheduler.scheduleGlobal(settime,0.01)
	]]
end

--[[释放指定项]]
function UIMainGames:clearTarget()
	
end

---------------------------------------------
---------------------------------------------

return UIMainGames
