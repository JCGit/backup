
local UIGameTableMatch = class("UIGameTableMatch", cc.load("mvc").ViewBase)
----------------------------------------------------------------
local TCPConnector = require('app.network.TCPConnector')
local DataPacker = require('app.network.DataPacker')
local DataUnpacker = require('app.network.DataUnpacker')
local HttpHandler = require("app.network.HttpHandler")
local GameTableCommon = require("app.models.GameTableCommon")
local scheduler = require("app.models.QScheduler")
--printWarning
require("app.models.cardutl")
UIGameTableMatch.CMD = DataUnpacker.CMD[DataUnpacker.Type.MATCH_GAME]['REQ']
----------------------------------------------------------------

UIGameTableMatch.RESOURCE_FILENAME = "UIGameTableAwards.csb"
UIGameTableMatch.RESOURCE_PRELOADING = {"game.png",'faceicon.png','card.png','friendrank.png','/background/game_tables1.png'}
UIGameTableMatch.RESOURCE_LOADING  = {
    ["res/background/game_bg.png"]     = {names = {"Image_bg"}},
    ["res/background/game_tables.png"] = {names = {"Image_bg2"}} 
} 

UIGameTableMatch.RESOURCE_BINDING = { 
    ["Button_pass"]   = {["ended"] = "PlayerCtrl_pass"}, 
    ["Button_hint"]   = {["ended"] = "PlayerCtrl_showHint"}, 
    ["Button_reset"]   = {["ended"] = "PlayerCtrl_resetSelectedCards"}, 
    ["Button_playcard"]   = {["ended"] = "PlayerCtrl_playCards"}, 
    -- ["Button_readyup"]   = {["ended"] = "PlayerCtrl_readyUp"}, 
    -- ["Button_changeTable"]   = {["ended"] = "PlayerCtrl_changeTable"}, 

    ["Button_wantlord"]   = {["ended"] = "PlayerCtrl_wantlord"}, 
    ["Button_dont_wantlord"]   = {["ended"] = "PlayerCtrl_dont_wantlord"}, 

    ["Button_doublebet"]   = {["ended"] = "PlayerCtrl_doublebet"}, 
    ["Button_dont_doublebet"]   = {["ended"] = "PlayerCtrl_dont_doublebet"}, 
    ["Button_calcelAutoplay"]   = {["ended"] = "PlayerCtrl_setAutoplay"}, 
    ["Button_autoplay"]   = {["ended"] = "PlayerCtrl_setAutoplay"}, 

    ["Button_dont_grab_lord"]   = {["ended"] = "PlayerCtrl_dont_grab_lord"  }, 
    ["Button_grab_lord"]        = {["ended"] = "PlayerCtrl_grab_lord"       }, 

    ["Button_dont_call_lord"]   = {["ended"] = "PlayerCtrl_dont_call_lord"  }, 
    ["Button_call_lord"]        = {["ended"] = "PlayerCtrl_call_lord"       }, 
    
    ["Button_back"]        = {["ended"] = "PlayerCtrl_back"       }, 
    ["Button_test"]        = {["ended"] = "PlayerCtrl_test"       }, 

}


UIGameTableMatch.STATUS = {
    NONE                    = 0,
    -- READY                   = 1,
    PASS                    = 2,
    DOUBLE_BET              = 13,
    DONT_DOUBLE_BET         = 14,
    DONT_WANT_TO_BE_LORD    = 15,

    CALL_LORD    = 4,
    NO_CALL_LORD = 3, 
    GRAB_LORD    = 5,
    DONT_GRAB_LORD  = 6,
}



local function invertStatusTable()
    UIGameTableMatch.STATUS_INVERT = {}
    for k,v in pairs(UIGameTableMatch.STATUS) do
        UIGameTableMatch.STATUS_INVERT[v]=k 
    end
end
invertStatusTable()

UIGameTableMatch.displayIDTable = 
{
    true,
    false,
    false,
}

UIGameTableMatch.GameTableName = 
{
    level = 
    {
        "初级场",
        "中级场",
        "高级场",
        "大师场",
    },
    name = 
    {

        [1] = '普通场',
        [18]= '抢地主',
        [33]= '大奖赛场',
        [19]= '斗牛',
    }
}

 
UIGameTableMatch.ARRANGE_MIDDLE = 1
UIGameTableMatch.ARRANGE_LEFT = 2
UIGameTableMatch.ARRANGE_RIGHT = 3

UIGameTableMatch.BUTTON_DISABLE_COLOR = cc.c3b(125, 125, 125)
UIGameTableMatch.BUTTON_ENABLE_COLOR = cc.c3b(255, 255, 255)

UIGameTableMatch.TIP_NORMAL_PLAYER_TOAST = 0x30  -- 客户端Toast弹窗
UIGameTableMatch.TIP_NORMAL_PLAYER_POP = 0x31 -- 客户端Pop弹窗


UIGameTableMatch.PLAYER_ROLE_LORD        = 0x01  -- 地主
UIGameTableMatch.PLAYER_ROLE_FARMER      = 0x02  -- 农民
UIGameTableMatch.SEX_MALE        = 0x01  -- 男
UIGameTableMatch.SEX_FEMALE      = 0x02  -- 女
UIGameTableMatch.PLAYER_ACTION_TIMEOUT = 20  
 

UIGameTableMatch.ROOM_STATE_IDLE = 0        --房间等待
UIGameTableMatch.ROOM_STATE_WANT_LORD = 1   --等待要地主
UIGameTableMatch.ROOM_STATE_DOUBLE = 2      --等待加倍
UIGameTableMatch.ROOM_STATE_PLAYING = 3     --房间正在游戏(出牌)
UIGameTableMatch.ROOM_STATE_CALL_LORD = 4   --等待叫地主
UIGameTableMatch.ROOM_STATE_GRAB_LORD = 5   --等待抢地主


 UIGameTableMatch.pickedCardsHeight = 20

function UIGameTableMatch:PlayerCtrl_dont_grab_lord()
    self:PlayerCtrl_NotGrabLord()
end


function UIGameTableMatch:PlayerCtrl_test()
    printf('PlayerCtrl_test')
end


function UIGameTableMatch:PlayerCtrl_back()
    -- self:quitComfirm()
   GameTableCommon.quitComfirm(self)
end

function UIGameTableMatch:PlayerCtrl_grab_lord() 
    self:PlayerCtrl_grabLordOrNot()
end
 
--抢地主 
function UIGameTableMatch:PlayerCtrl_grabLordOrNot() 
    local bufferHnd = DataPacker.new(UIGameTableMatch.CMD['USER_GRAB_LORD'])  
    self.tcpGear:sendData(bufferHnd:doPack())
    self["Button_dont_grab_lord"]:setVisible(false)
    self["Button_grab_lord"]:setVisible(false)
    print('发送了抢地主')
end

--不抢地主
function UIGameTableMatch:PlayerCtrl_NotGrabLord() 
    local bufferHnd = DataPacker.new(UIGameTableMatch.CMD['NO_DROP_LORD'])  
    self.tcpGear:sendData(bufferHnd:doPack())
    self["Button_dont_grab_lord"]:setVisible(false)
    self["Button_grab_lord"]:setVisible(false)
     print('发送了不抢地主')
end


function UIGameTableMatch:PlayerCtrl_dont_call_lord()
    self:PlayerCtrl_NotCallLord()
end

function UIGameTableMatch:PlayerCtrl_call_lord() 
    self:PlayerCtrl_callLordOrNot()
end

--叫地主
function UIGameTableMatch:PlayerCtrl_callLordOrNot() 
    local bufferHnd = DataPacker.new(UIGameTableMatch.CMD['USER_CALL_LORD'])  
    self.tcpGear:sendData(bufferHnd:doPack())
    self["Button_dont_call_lord"]:setVisible(false)
    self["Button_call_lord"]:setVisible(false)
end

--不叫地主
function UIGameTableMatch:PlayerCtrl_NotCallLord() 
    local bufferHnd = DataPacker.new(UIGameTableMatch.CMD['NO_CALL_LORD'])  
    self.tcpGear:sendData(bufferHnd:doPack())
    self["Button_dont_call_lord"]:setVisible(false)
    self["Button_call_lord"]:setVisible(false)
end



function UIGameTableMatch:PlayerCtrl_changeTable()   
    if self.isChangeTableLockDown == true then 
        local blah = ""..cc.Director:getInstance():getTotalFrames()
        G_BASEAPP:addView({
           uiName =  'UIAlert',
           uiInstanceName = blah
            },1000)
        :setupDialog('Infomation',"更换平率过快，低于1秒限制。")
        return
    end
    self.isChangeTableLockDown = true
    self:createSchedule("changeTableLockDown",function()
        self:stopSchedule("changeTableLockDown")
        self.isChangeTableLockDown = nil
    end,1)

    local bufferHnd = DataPacker.new(UIGameTableMatch.CMD['CHANGE_TABLE'])  
    self.tcpGear:sendData(bufferHnd:doPack()) 
    LuaTools.beginWaiting(true)  
end

function UIGameTableMatch:PlayerCtrl_readyUp() 

    -- self['Button_readyup']:setEnabled(false)
    local bufferHnd = DataPacker.new(UIGameTableMatch.CMD['USER_READY'])  
    self.tcpGear:sendData(bufferHnd:doPack()) 

    -- -- yeah, i AM lazy, bite me will ya??     <---- nah, it won't work. <<---- still won't work, because it'll re-login!
    -- local displayID = self.playerData[self.mySeatID].displayID
    self['Image_status_1']:setVisible(true)
    self['Image_status_1']:loadTexture("room/RoomPlayerSatus_1.png",ccui.TextureResType.plistType)
end
--Image_mystatus

--托管
function UIGameTableMatch:PlayerCtrl_setAutoplay(status,whereFrom) 
    printf("PlayerCtrl_setAutoplay : self.autoPlayStatus :%s",self.autoPlayStatus ) 
    if self.currentRoomState ==  UIGameTableMatch.ROOM_STATE_IDLE  then 
        return
    end

    if status and type(status) == "number" then
        self.autoPlayStatus = status
    else
        self.autoPlayStatus = self.autoPlayStatus + 1
        self.autoPlayStatus = 2 - self.autoPlayStatus % 2 
    end

    printf("PlayerCtrl_setAutoplay :after: self.autoPlayStatus :%s",self.autoPlayStatus ) 
    if whereFrom == nil then
        local bufferHnd = DataPacker.new(UIGameTableMatch.CMD['UPDATE_AUTOPLAY'])  
        bufferHnd:writeData(self.autoPlayStatus,DataPacker.BYTE)
        self.tcpGear:sendData(bufferHnd:doPack()) 
    else 
        if self.autoPlayStatus == 1 then 
            self['Button_calcelAutoplay']:setVisible(true)
            self:darkenHandCards( true)
            self:PlayerCtrl_resetSelectedCards()
        else 
            self['Button_calcelAutoplay']:setVisible(false)
            self:darkenHandCards( false )
        end 
    end

end

--加倍
function UIGameTableMatch:PlayerCtrl_doublebetOrNot()
    self['Button_doublebet']:setVisible(false)
    self['Button_dont_doublebet']:setVisible(false)
    local bufferHnd = DataPacker.new(UIGameTableMatch.CMD['ACCEPT_DOUBLE'])
    self.tcpGear:sendData(bufferHnd:doPack()) 
    self:updatePlayerStatus(self.mySeatID,UIGameTableMatch.STATUS.DOUBLE_BET)
end 

----不加倍
function UIGameTableMatch:PlayerCtrl_Notdoublebet()
    self['Button_doublebet']:setVisible(false)
    self['Button_dont_doublebet']:setVisible(false)
    local bufferHnd = DataPacker.new(UIGameTableMatch.CMD['NO_DOUBLE'])
    self.tcpGear:sendData(bufferHnd:doPack()) 
    self:updatePlayerStatus(self.mySeatID,UIGameTableMatch.STATUS.DONT_DOUBLE_BET)
end 

--加倍
function UIGameTableMatch:PlayerCtrl_doublebet()
    self:PlayerCtrl_doublebetOrNot()
end 

--不加倍
function UIGameTableMatch:PlayerCtrl_dont_doublebet() 
    self:PlayerCtrl_Notdoublebet() 
end 

 
function UIGameTableMatch:PlayerCtrl_playCards()
    -- print('UIGameTableMatch:PlayerCtrl_playCards()') 
    self['Image_nolarger']:setVisible(false)
    local cardsReadyToSend = self:getSelectedCards()
    if #cardsReadyToSend<=0 then
        return
    end

    self.lastCardsStatus = self:getAllHandCardsValues()
    local cardValid,cardType = Cardutl.checkCardOut(cardsReadyToSend , self.lastPlayedCards or {})   
    -- dump(cardsReadyToSend,"Original cardsReadyToSend")
    self.lastSentCards = cardsReadyToSend
    print("cardValid:",cardValid)
    if cardValid then 
        local bufferHnd = DataPacker.new(UIGameTableMatch.CMD['PLAY_CARD']) 
        bufferHnd:writeData(#cardsReadyToSend,DataPacker.BYTE)
        for i=1,#cardsReadyToSend do
            local temp = cardsReadyToSend[i]
            if temp == 0x01 then
                temp = 0x50
            end
            if temp == 0x02 then
                temp = 0x51
            end
            bufferHnd:writeData(temp,DataPacker.BYTE)
        end

        self.tcpGear:sendData(bufferHnd:doPack())  
        local ct =  Cardutl.getOriginalCardType(  Cardutl.getCardAssamblyType(cardsReadyToSend))
        printf('PlayerCtrl_playCards => cardType converted:%s',ct) 
        self:playAnimation(ct,1)  
        self:playSoundByCard(ct,cardsReadyToSend[1],self.mySeatID)
        self:disableAllBUttonsAndClock() 
        local startPositionTable = self:getCardPosByVal( cardsReadyToSend )
        self:setPlayedCards(self.mySeatID,cardsReadyToSend,nil,startPositionTable)
        self:removePickedCards() 
        self.povPlayedCard = true
    else 
        self:pickCards({},true)
        self['Image_play_wrongly']:setVisible(true)
        self['Image_nolarger']:setVisible(false)
        self:stopSchedule("wrong_card")
        self:createSchedule("wrong_card",function()
            self['Image_play_wrongly']:setVisible(false)
            self:stopSchedule("wrong_card")
        end,2) 
        -- local len1 = #cardsReadyToSend
        -- local len2 = #self.lastPlayedCards
        -- local len = len1
        -- if len2 > len1 then 
        --     len = len2
        -- end 
        -- for i=1,len do
        --     printf("mycard:%s => lastcard:%s",cardsReadyToSend[i],self.lastPlayedCards[i])
        -- end
    end
    -- dump(cardsReadyToSend,"Changed cardsReadyToSend")
    -- dump(self.lastPlayedCards,"self.lastPlayedCards")
    
end

function UIGameTableMatch:PlayerCtrl_resetSelectedCards()
    self:pickCards({},true)
    self['Image_nolarger']:setVisible(false)
end

function UIGameTableMatch:PlayerCtrl_pass() 
    local bufferHnd = DataPacker.new(UIGameTableMatch.CMD['PASS']) 
    self.tcpGear:sendData(bufferHnd:doPack()) 
    self:showPlayOptions(false)
    self:pickCards({},true)
    self['Image_nolarger']:setVisible(false)
end

function UIGameTableMatch:PlayerCtrl_showHint() 
    
    if self.hintBigger == nil then
        printf('=============== BEGIN OF SHOW HINT LOGICS ==========')
        -- dump(self.lastPlayedCardsType,"self.lastPlayedCardsType")
        -- dump(self.lastPlayedCards,"self.lastPlayedCards")
        -- dump(self:getAllHandCardsValues(),"self:getAllHandCardsValues()")
        local hint = CardHints.new({
            lastPlayedCardsType = self.lastPlayedCardsType  ,
            lastPlayedCardValues = self.lastPlayedCards ,
            handCardTable = self:getAllHandCardsValues()
            })
        hint:tip(false) 
        hint:getBigger()
        self.hintBigger = hint.bigger
        self.hintIndex  = 0
        -- dump(self.hintBigger,"hint")

        if #self.hintBigger == 0 then
            self:PlayerCtrl_pass()
            self['Image_nolarger']:setVisible(true) 
            self['Image_play_wrongly']:setVisible(false) 
            local function disCall()
                self['Image_nolarger']:setVisible(false)
            end
            local delay = cc.DelayTime:create(1.0)
            local sequence = cc.Sequence:create(delay, cc.CallFunc:create(disCall))
            self:runAction(sequence)
            return
        end
    end

    self.hintIndex = self.hintIndex + 1
    if self.hintIndex > #self.hintBigger then 
       self.hintIndex  = 1
    end
    printf('current big index:%s',self.hintIndex)
    if self.hintBigger and type(self.hintBigger) == 'table' and #self.hintBigger >0 then 
        self:pickCards(self.hintBigger[self.hintIndex],true)
    else
        self['Image_nolarger']:setVisible(true) 
        self['Image_play_wrongly']:setVisible(false)  
    end
end

function UIGameTableMatch:PlayerCtrl_wantlord()
    self:PlayerCtrl_wantLordOrNot(1) 
end

function UIGameTableMatch:PlayerCtrl_dont_wantlord()
    self:PlayerCtrl_wantLordOrNot(0) 
end

function UIGameTableMatch:PlayerCtrl_wantLordOrNot( want ) 
    self['Button_wantlord']:setVisible(false)
    self['Button_dont_wantlord']:setVisible(false)
    local bufferHnd = DataPacker.new(UIGameTableMatch.CMD['WANT_TO_BELORD'])
     bufferHnd:writeData(want,DataPacker.BYTE)
    self.tcpGear:sendData(bufferHnd:doPack()) 
    if want == 0 then  
        self:updatePlayerStatus(self.mySeatID,UIGameTableMatch.STATUS.DONT_WANT_TO_BE_LORD)
    end
end
   
--[==[---------------------DISPLAY FUNCTIONS START-----------------]==]

function UIGameTableMatch:quitTable()
    if G_BASEAPP:getView('UIGameTableMenu') then
        G_BASEAPP:removeView('UIGameTableMenu')
    end
    self.Broadcast:removeSelf()
    local bufferHnd = DataPacker.new(UIGameTableMatch.CMD['TABLE_DISCONNECT'])   
    self.tcpGear:sendData(bufferHnd:doPack()) 
    self.tcpGear:closeAndRelease() 
    self:removeSelf()
end



function UIGameTableMatch:quitComfirm()
    -- body 
    local d = G_BASEAPP:addView('UIDialog', 65530)
    d:setupDialog('', '是否确定退出房间？', 
    function()  
        d:removeSelf()
        self:quitTable()
    end) 

end

function UIGameTableMatch:getSelectedCards()
    local ret = {}
    for k,card in pairs(self.handCardTable) do
        if self.handCardTable[k].isPicked then
            table.insert(ret,card.val)
        end
    end
    return ret
    
end

function UIGameTableMatch:enableWarningNode(enable,seatID ) 
    local display = self.playerData[seatID].display
    if self['Panel_player_'..display]:getChildByName('Node_warning') then 
        self['Panel_player_'..display]:getChildByName('Node_warning'):setVisible(enable) 
    end
end

function UIGameTableMatch:showWarningAnimation( seatID )
    local display = self.playerData[seatID].displayID
    if self['warningNode_'..display] then 
        self['warningNode_'..display]:removeFromParent()
        self['warningNode_'..display] = nil
    end
    if self['Panel_player_'..display]:getChildByName('Node_warning') then 
        self['warningNode_'..display] = GameTableCommon.createAnimationNode('Animation_ddz_warning.csb',onFinish,true)
        self['Panel_player_'..display]:getChildByName('Node_warning'):setVisible(true)
        self['Panel_player_'..display]:getChildByName('Node_warning'):addChild(self['warningNode_'..display])
    end

end

function UIGameTableMatch:updatePlayerStatus(seatID,status,clear)
    -- printf("Calling updatePlayerStatus")
    for k,v in pairs(self.playerData) do
        local suffix = v.displayID  
        -- print("user status:",v.status)
        -- print("user displayStatus:",v.displayStatus)

        -- printf('scanning... v.seatID:%s, seatID:%s',v.seatID,seatID)
        if v.seatID ~= seatID then   
            if clear then
                self['Image_status_' .. suffix]:setVisible(false)
            end
        else 
            printf('setting %s to status:%s',seatID,status)
            if status == UIGameTableMatch.STATUS.NONE then
                -- printf('self[%s]:setVisible(false)','Image_status_' .. suffix)
                self['Image_status_' .. suffix]:setVisible(false)
                return
            end
            local imgPath = "room/RoomPlayerSatus_"..status..".png"
            print("suffix = "..suffix)
            print("status = "..status)
            self['Image_status_' .. suffix]:setVisible(true)
            self['Image_status_' .. suffix]:loadTexture(imgPath,ccui.TextureResType.plistType)

            if  status == UIGameTableMatch.STATUS.READY then 
                if self.playerData[seatID] and self.playerData[seatID].displayID then 
                    local d  = self.playerData[seatID].displayID 
                    if  self['playedCardNode_'..d] ~= nil then
                        self['playedCardNode_'..d]:removeFromParent()
                        self['playedCardNode_'..d] = nil
                    end 
                end
            end
            if seatID == self.mySeatID and status == UIGameTableMatch.STATUS.READY then 
                -- self['Button_readyup']:setEnabled(false) 
                self['Image_status_1']:setVisible(true)
                self['Image_status_1']:loadTexture("room/RoomPlayerSatus_1.png",ccui.TextureResType.plistType) 
            end 
            if UIGameTableMatch.STATUS_INVERT[status] == nil then
                self['Image_status_' .. suffix]:setVisible(false)
            end
        end
    end 
end



function UIGameTableMatch:setupCardSelection()
   ----------------------------------------------------
    local startPositionX = 0
    local currPositionX = 0 
    function checkSlided(startPos,endPos,status)
        local height =  UIGameTableMatch.pickedCardsHeight 
        local dist = math.abs(startPos - endPos)
        for k,v in pairs(self.handCardTable) do
            local worldPos = v:convertToWorldSpaceAR(cc.p(0,0)) 
            local realPosX = worldPos.x  - v:getContentSize().width * v:getAnchorPoint().x
            worldPos.y = worldPos.y + v:getContentSize().height * v:getAnchorPoint().y
            local ac1 = math.abs(startPos - realPosX)   --left edge of card.
            local c1b =  math.abs(realPosX - endPos) 
            
            local diff = v:getContentSize().width - v.paddingX
            local ac2 = math.abs(startPos - (realPosX + diff))   --right edge of card.
            local c2b =  math.abs((realPosX+diff) - endPos ) 
            
            local rect = cc.rect(realPosX,worldPos.y,v:getContentSize().width - v.paddingX, v:getContentSize().height)
            if self.handCardTable[k+1] == nil then--this is the last card, must make different touch region.
                rect.width=rect.width+v.paddingX
            end
           self.handCardTable[k].isPicked = self.handCardTable[k].isPickedLast
            v:setColor(UIGameTableMatch.BUTTON_ENABLE_COLOR) 
            if  dist >= ac1+c1b or  dist >= ac2+c2b or cc.rectContainsPoint(rect, cc.p(startPos,worldPos.y)) then  
                self.handCardTable[k].isPicked = not self.handCardTable[k].isPickedLast 
                v:setColor(UIGameTableMatch.BUTTON_DISABLE_COLOR) 
            end

            if status == 'ended' or status == 'cancelled'   then --confirmed selection
                self.handCardTable[k].isPickedLast = self.handCardTable[k].isPicked
                self.handCardTable[k]:setPositionY(self.handCardTable[k].OriginalPositionY) 
                if self.handCardTable[k].isPicked == true then
                    self.handCardTable[k]:setPositionY(height+self.handCardTable[k].OriginalPositionY)
                end
                v:setColor(UIGameTableMatch.BUTTON_ENABLE_COLOR) 
            end        
        end
    end 
 
    local function aa(event)  
        -- printf("selecting cards,self.isDealingCards:%s",self.isDealingCards)
        if self.isDealingCards == true or (self.autoPlayStatus == 1) then return end
 
        if event.name == 'began' then 
            startPositionX =  event.pos.x
            currPositionX =  event.pos.x
        elseif event.name == 'moved' then
            currPositionX =  event.pos.x
        elseif event.name == 'ended' then 
            currPositionX =  event.pos.x
        elseif event.name == 'cancelled' then 
        end
        checkSlided(startPositionX,currPositionX,event.name)
    end 

    local function resetCardSelection()
        if self.isDealingCards == true or (self.autoPlayStatus == 1) then return end
        for k,v in pairs(self.handCardTable) do
            self.handCardTable[k]:setPositionY(self.handCardTable[k].OriginalPositionY)
            v:setColor(UIGameTableMatch.BUTTON_ENABLE_COLOR) 
            self.handCardTable[k].isPicked , self.handCardTable[k].isPickedLast = false,false
        end 
    end
    self.handCardLayer:onTouch(aa) 
    self.handCardLayer:getParent():onTouch(resetCardSelection) 
    ----------------------------------------------------
end

function UIGameTableMatch:resetDisplayTable() 
     print("resetDisplayTable...")
    for k,v in pairs(UIGameTableMatch.displayIDTable) do
        UIGameTableMatch.displayIDTable[k]=false
    end
    UIGameTableMatch.displayIDTable[1] = true
end

function UIGameTableMatch:cleanTable()

    print("cleanTable...")
    self.isGameStarted = nil
    self:stopSchedule('GAMEOVER_DELAY')
    self:stopSchedule('resetCards')
    LuaTools.stopWaiting()    
    self:hideAllPlayersStatus()
    for k,v in pairs(UIGameTableMatch.displayIDTable) do
        -- UIGameTableMatch.displayIDTable[k]=false
        self['BitmapFontLabel_score_'..k]:setVisible(false)  
        -- self['Image_status_'..k]:setVisible(false)  

        if  self['playedCardNode_'..k] ~= nil then
            self['playedCardNode_'..k]:removeFromParent()
            self['playedCardNode_'..k] = nil
        end 
        if self['Panel_player_'..k]:getChildByName('Node_warning') then 
            self['Panel_player_'..k]:getChildByName('Node_warning'):setVisible(false)
        end
        if self['warningNode_'..k] then 
            self['warningNode_'..k]:removeFromParent()
            self['warningNode_'..k] = nil
        end
        local role = self['Panel_player_'..k]:getChildByName("Image_role")
        role:setVisible(false)
        role:loadTexture("room/Room_farmer_hat.png",ccui.TextureResType.plistType) 
    end
    if self.springAnimNode and not tolua.isnull(self.springAnimNode) then 
        self.springAnimNode:removeFromParent()
        self.springAnimNode = nil 
    end 

    if self.doubleAmountNode  then 
        if tolua.isnull(self.doubleAmountNode ) == false then 
            self.doubleAmountNode:removeFromParent()
        end
        self.doubleAmountNode = nil
    end
    
    for k,v in pairs(self.playerData or {}) do 
        self.playerData[k].remaining_2 = nil
        self.playerData[k].remaining_1 = nil 
        self.playerData[k].isSat = nil
        self:showAutoplayAnimation( k , false) 
    end
    if self.myCardMenuRoot then 
        self.myCardMenuRoot:removeFromParent()
        self.myCardMenuRoot = nil 
    end
    for i=1,4 do

        self['Image_lordcard_'..i]:setVisible(false)
    end

    self.povPlayedCard = nil
    self.isDealingCards = nil
    self.lastOriginalCardType = nil
    self.isNewRound = nil 
    self['Text_multiply']:setString(self.globalMultiply)--(self.loginData.roomExtend.multi or 1)
    ----申翰兴
    -- self.globalMultiply = self.loginData.roomExtend.multi 
    
    self:showPlayOptions(false)  
end

function UIGameTableMatch:resetTable()

    LuaTools.stopWaiting()    
    self:cleanTable()
    self:resetDisplayTable() 
    self['Image_nolarger']:setVisible(false)

    UIGameTableMatch.displayIDTable[1]=true
    self.autoPlayStatus = 2 
    self.playerData = {}
    self.mySeatID = -1
    self.playerCount = 0
    -- self['Button_readyup']:setEnabled(true)
    self['Panel_player_3']:setVisible(false)
    self['Panel_player_2']:setVisible(false)

end
 

function UIGameTableMatch:setupPlayer(data)
    local v = data 
    --显示该玩家相关组件
    printf('setting displayID%s to visible',v.displayID)
    self['Panel_player_'..v.displayID]:setVisible(true)

    --设置地主/农民

    local role = self['Panel_player_'..v.displayID]:getChildByName("Image_role") 
    local roleImagePath = "room/Room_farmer_hat.png"

    if v.role == UIGameTableMatch.PLAYER_ROLE_LORD then 
        role:setVisible(true)
        roleImagePath = "room/Room_lord_hat.png" 
    end

    role:loadTexture(roleImagePath,ccui.TextureResType.plistType) 
    --设置性别 
    printf('setting avatar:url:%s,did:%s,sex:%s',v.iconUrl,v.displayID,v.sex)
    GameTableCommon.setAvatar(self,v.iconUrl,v.displayID,v.sex)
    GameTableCommon.setVIP(self, v.vipLevel,v.vipType,v.displayID ) 
    --设置昵称
    if v.nickName then
        local nick = self['Panel_player_'..v.displayID]:getChildByName("Text_nickname")
        if nick then
            nick:setString( v.nickName) 
        end
    end
    --设置金币
    if v.coins then
        local coin = self['Panel_player_'..v.displayID]:getChildByName("Text_coins")
        if coin then 
            coin:setString(LuaTools.convertAmountChinese(v.coins,10000)) 
        end
    end

end


function UIGameTableMatch:setupAllPlayers()
    for k,v in pairs(self.playerData) do
        self:setupPlayer(v)
    end --for k,v in pairs(self.playerData) do
end


function UIGameTableMatch:insertPlayerToDisplayTable(data)
    GameTableCommon.insertPlayerToDisplayTable(self,data)
end


function UIGameTableMatch:clearMyCards() 
    if self.myCardMenuRoot then
        if not tolua.isnull(self.myCardMenuRoot) then
            self.myCardMenuRoot:removeFromParent() 
        end
        self.myCardMenuRoot = nil
    end

    self.myCardInstanceTable = {} 
    self.handCardTable = {}
end

function UIGameTableMatch:alignItemsHorizontallyWithPadding(padding,childredTable) 
    local width = -padding; 
    for k,child in pairs(childredTable) do
        width  = width + child:getContentSize().width * child:getScaleX() + padding;
    end
    local x = -width / 2.0 ;
    for k,child in pairs(childredTable) do
        child:setPosition(x + child:getContentSize().width * child:getScaleX() / 2.0 , 0);
        x  = x+ child:getContentSize().width * child:getScaleX() + padding;
    end 
end

function UIGameTableMatch:updateHandCards(argTable) 
    -- dump(argTable, "UIGameTableMatch:updateHandCards")
    local paddingX = (self:getContentSize().width - 100) / 21  -- 21 cards max
    local paddingCard = paddingX
    if argTable then
        self:clearMyCards()
        if self.myCardMenuRoot then 
            self.myCardMenuRoot:removeFromParent()
            self.myCardMenuRoot = nil 
        end
        if argTable.cards and #argTable.cards > 0 then
            self.myCardMenuRoot = display.newNode() 
            self.myCardMenuRoot:setPosition(self['Image_positionalCard']:getPosition())
            self.handCardLayer:addChild(self.myCardMenuRoot) 
            local handCards = argTable.cards or {}
            Cardutl.SortHandCards(handCards) 
            for k,cardVal in pairs(handCards) do  
                local spritePath = Cardutl.getPathForCard( cardVal )
                print(spritePath)
                local bk = cc.Sprite:createWithSpriteFrameName(spritePath) 
                local card = cc.MenuItemSprite:create(bk, bk) 
                if self.autoplayStatus == 1 then 
                    card:setColor(UIGameTableMatch.BUTTON_DISABLE_COLOR)
                end
                card.val = cardVal 
                card.isPicked = false
                card.isPickedLast = false
                card.OriginalPositionY = card:getPositionY()
                paddingCard = (card:getContentSize().width  - paddingX)
                card.paddingX = paddingCard
                 self.myCardMenuRoot:addChild(card)
                table.insert(self.handCardTable,card) 
            end
            self:alignItemsHorizontallyWithPadding(-paddingCard,self.handCardTable)  
        end
        if argTable.fastDeal == false then
            GameTableCommon.dealCardAnimation( self.handCardTable,argTable.onFinish )
        else 
            self.isDealingCards = false 
        end 
        self.lastCardsStatus = self:getAllHandCardsValues()
        self:darkenHandCards( self.autoPlayStatus == 1 )
    end
end

function UIGameTableMatch:hideAllPlayersStatus()
     for k,v in pairs(self.playerData or {}) do
        local suffix = v.displayID  
        self['Image_status_' .. suffix]:setVisible(false)
    end
end
--用户倒计时
function UIGameTableMatch:startPlayerCountdownBySeatID(seatID,timeLeft)
    -- body
    self['Image_clock_1']:setVisible(false)
    self['Image_clock_2']:setVisible(false)
    self['Image_clock_3']:setVisible(false)
    for k,v in pairs(self.playerData) do
        local displayID = v.displayID
        self:stopSchedule("player_countdown_"..displayID)
        if v.seatID == seatID then
            self['Image_clock_'..displayID]:setVisible(true)
            self['Image_clock_'..displayID]:getChildByName("AtlasLabel_counter"):setString((timeLeft or UIGameTableMatch.PLAYER_ACTION_TIMEOUT).."")
            self:createSchedule("player_countdown_"..displayID,function()
                local timer = tonumber(self['Image_clock_'..displayID]:getChildByName("AtlasLabel_counter"):getString())
                if timer <= 0 then
                    self['Image_clock_'..displayID]:setVisible(false)
                    self:stopSchedule("player_countdown_"..displayID)
                    return
                end
                timer=timer-1
                self['Image_clock_'..displayID]:getChildByName("AtlasLabel_counter"):setString(timer)
                end,1)
        else
            self['Image_clock_'..displayID]:setVisible(false)
        end
    end
end

--玩家是否要地主
function UIGameTableMatch:showWantLord()
    self['Button_wantlord']:setVisible(true)
    self['Button_dont_wantlord']:setVisible(true)
end


function UIGameTableMatch:arrangeCards(arrangeType,cardCalueTable,isLord,ignoreLaizi,startPositionTable)
    if not cardCalueTable or #cardCalueTable <= 0 then return end 
    local parent = display.newNode() 
    local middleNode = nil
    local spritePath = 'newcard/back.png'  
    local card = cc.Sprite:createWithSpriteFrameName(spritePath)
    local padding = card:getContentSize().width * 0.4
    local width =   padding * #cardCalueTable + card:getContentSize().width * card:getScaleX() 
    local aPoint = cc.p(0,0.5) 
    if arrangeType == UIGameTableMatch.ARRANGE_RIGHT then 
        aPoint = cc.p(0,0.5)
    elseif  arrangeType == UIGameTableMatch.ARRANGE_MIDDLE then 
        aPoint = cc.p(0.5,0.5)
    end

    local cardInstanceTable = {}
    for i = 1, #cardCalueTable do 
        local v = cardCalueTable[i]
        local k = i
        local checkLaizi = true
        if ignoreLaizi == true then
            checkLaizi = false
        end
        checkLaizi = false
        local spritePath,laizi = Cardutl.getPathForCard(v,nil,checkLaizi ) 
        local card = cc.Sprite:createWithSpriteFrameName(spritePath)
        parent:addChild(card)  
        card:setAnchorPoint(aPoint) 
        if isLord == true and i == #cardCalueTable then
            local lordTag = cc.Sprite:createWithSpriteFrameName('newcard/label.png')
            lordTag:setAnchorPoint(cc.p(0,0))
            card:addChild(lordTag)
        end

        if arrangeType == UIGameTableMatch.ARRANGE_LEFT then
            card:setPosition(tonumber(k) * padding  - padding, 0); 
        elseif  arrangeType == UIGameTableMatch.ARRANGE_RIGHT  then  
            card:setPosition((tonumber(k)) * padding - width , 0); 
        end 
        if k == math.floor(#cardCalueTable*0.5) then 
            middleNode = card  
        end
        card.val = v
        table.insert(cardInstanceTable,card)

    end 
    if arrangeType == UIGameTableMatch.ARRANGE_MIDDLE  then
        self:alignItemsHorizontallyWithPadding(-80,cardInstanceTable)
    end

    for i,card in pairs(cardInstanceTable) do  
        card:setVisible(false)
        card.originalPos = cc.p(card:getPosition())
    end

    local totalMoveTime = 1
    local dealTime = totalMoveTime/#cardInstanceTable
    if dealTime <= 0.3 then 
        dealTime = 0.3
    end
    for i,card in pairs(cardInstanceTable) do 
        card:setVisible(true)
        local cardAnimationOriginalPosition = card.originalPos
        if startPositionTable then 
            cardAnimationOriginalPosition = startPositionTable[card.val]
        end 

        if cardAnimationOriginalPosition then
            local nodeSpace = card:convertToNodeSpace(cardAnimationOriginalPosition) 
            local offsetX = 300
            if arrangeType == UIGameTableMatch.ARRANGE_LEFT then 
                nodeSpace.x = card.originalPos.x - offsetX
                nodeSpace.y = card.originalPos.y
            elseif arrangeType == UIGameTableMatch.ARRANGE_RIGHT  then  
                nodeSpace.x = card.originalPos.x + offsetX
                nodeSpace.y = card.originalPos.y 
            elseif arrangeType == UIGameTableMatch.ARRANGE_MIDDLE  then  
                nodeSpace.x = card.originalPos.x 
                nodeSpace.y = card.originalPos.y - 100    
            end
            card:setPosition(nodeSpace)
            local mov = cc.EaseExponentialOut:create(cc.MoveTo:create(dealTime,card.originalPos))
            local delayTime = cc.DelayTime:create(i*0.01)
            local act = cc.Sequence:create(delayTime,mov)
            card:runAction(act) 
        end 
    end

    return parent,middleNode
end

--显示地主牌
function UIGameTableMatch:showLordCards(cards)
    for k,card in pairs(cards) do
        self['Image_lordcard_'..k]:setVisible(true)
        local filename = Cardutl.getPathForCard( card ,true)
        print("loading:",filename)
        self['Image_lordcard_'..k]:loadTexture(filename,ccui.TextureResType.plistType)
    end
end

--设置地主
function UIGameTableMatch:setLord(seatID)
    -- body
    if self.playerData[seatID] then 
        self.playerData[seatID].role = UIGameTableMatch.PLAYER_ROLE_LORD 
    end

    local lordDisplayID = -1
    local v2 = self.playerData[seatID]
    if v2 then
        self.playerData[seatID].role = UIGameTableMatch.PLAYER_ROLE_LORD  
        local role = self['Panel_player_'..v2.displayID]:getChildByName("Image_role") 
        lordDisplayID = v2.displayID
        role:setVisible(true)
        role:loadTexture("room/Room_lord_hat.png",ccui.TextureResType.plistType)
    end

    for i=1,3 do
        if i ~= lordDisplayID then
            local role = self['Panel_player_'..i]:getChildByName("Image_role") 
            role:setVisible(true)
            role:loadTexture("room/Room_farmer_hat.png",ccui.TextureResType.plistType)
        end
    end
end

function UIGameTableMatch:showDoubleBets()
    self['Button_doublebet']:setVisible(true)
    self['Button_dont_doublebet']:setVisible(true)
end

function UIGameTableMatch:showPlayOptions(_show,isNewRound)
    self['Button_pass']:setVisible(_show)
    self['Button_hint']:setVisible(_show)
    self['Button_reset']:setVisible(_show)
    self['Button_playcard']:setVisible(_show)
    self['Button_pass']:setEnabled(not (type(isNewRound) == 'number' and isNewRound == 1 ))
    self['Button_hint']:setEnabled(not (type(isNewRound) == 'number' and isNewRound == 1 ))
    if _show then
        self.hintBigger = nil
        self.hintIndex  = 0
    end
end

--[[
TODO:
    出牌分开处理。
    先找isPicked 把手牌弄出去。
    然后实际打出的牌由服务器制定。
]]
function UIGameTableMatch:removeCards(srcCards,cardsForRemoval)
    local ret = clone(srcCards)
    local rm = clone(cardsForRemoval) 
    local i = 1
    local len = #ret
    local rlen = #rm
    for i=1,len do 
        for j=1,rlen do 
            printf("rm[%d]=%s ret[%s] = %s",j,rm[j],i,ret[i]) 
            if rm[j] then
                local retType = Cardutl.GetCardType(ret[i])
                local rmType = Cardutl.GetCardType(rm[j])
                if  ret[i] == rm[j] or (retType == Cardutl.CARD_SWT_TYPE and retType ==  rmType ) then 
                    ret[i] = nil
                    rm[j] = nil 
                    break
                end
            end
        end  
    end 
    local final = {}
    for k,v in pairs(ret) do
        table.insert(final,v)
    end 
    return final
end


function UIGameTableMatch:removeCardsOLD(srcCards,cardsForRemoval)
    local ret = {}
    for k,v in pairs(srcCards) do
        local flag = true
        for k1,v1 in pairs(cardsForRemoval) do
            if v1 == v then  
                flag = false 
                break
            end 
        end 
        if flag == true then
            table.insert(ret,v)
        end
    end 
    Cardutl.SortHandCards(ret) 
    return ret
end

function UIGameTableMatch:removePickedCards()
    local remainingCards = {}
    for k,card in pairs(self.handCardTable) do
        if card.isPicked == false then
            table.insert(remainingCards,card.val)
        end
    end
    self:updateHandCards({cards = remainingCards})
end


function UIGameTableMatch:getPickCardsValue()
    local ret = {}
    for k,card in pairs(self.handCardTable) do
        if card.isPicked == true then
            table.insert(ret,card.val)
        end
    end
    return ret
end


function UIGameTableMatch:getAllHandCardsValues()
    local ret = {}
    for k,card in pairs(self.handCardTable) do
        table.insert(ret,card.val)
    end
    return ret
end

function UIGameTableMatch:convertLaiziCards()
    -- body
end

function UIGameTableMatch:pickCardsEX(pickedCards,clear)
   local clonedCardsTable = clone(pickCards)
   local handCardLen = #self.handCardTable
   local cardTableLen = #clonedCardsTable
   local i , j = 1 , 1
   while i <= self.handCardLen do 
        local card =  self.handCardTable[i]
        if clear == true then 
            card.isPicked = false 
            card.isPickedLast = false 
            card:setPositionY(card.OriginalPositionY) 
        end

        while j <= cardTableLen do 
            local val = clonedCardsTable[j]
            if val ~= -999 and  val == card.val then
                clonedCardsTable[j] = -999
                card.isPicked = true 
                card.isPickedLast = true 
                card:setPositionY(UIGameTableMatch.pickedCardsHeight + card.OriginalPositionY) 
                i=1
                j=1
                break
            end 
            j=j+1
        end
        i=i+1
   end
end

function UIGameTableMatch:pickCards(pickedCards,clear)
    for k,card in pairs(self.handCardTable) do
        local isPicked = false
        for _,val in pairs(pickedCards) do
            if val == card.val then
                isPicked = true
                break
            end
        end
        if isPicked then
            card.isPicked = true 
            card.isPickedLast = true 
            card:setPositionY(UIGameTableMatch.pickedCardsHeight + card.OriginalPositionY) 
        elseif clear == true  then
            card.isPicked = false 
            card.isPickedLast = false 
            card:setPositionY(card.OriginalPositionY) 
        end
    end
end


function UIGameTableMatch:compareTable(src,dst)
    local _src = clone(src)
    local _dst = clone(dst)
    Cardutl.SortOutCards(_src)  
    Cardutl.SortOutCards(_dst)  
    -- dump(_src,"_src")
    -- dump(_dst,"_dst")
    if #_dst ~= #_src then return false end
    local ret = true 
    for k,v in pairs(_src) do
        if v ~= _dst[k] then
            ret = false
            break
        end
    end
    return ret 
end

function UIGameTableMatch:clearPlayedCards()
    for k,v in pairs(UIGameTableMatch.displayIDTable) do
        local displayID = k
        if  self['playedCardNode_'..displayID] ~= nil then
            self['playedCardNode_'..displayID]:removeFromParent()
            self['playedCardNode_'..displayID] = nil
        end
    end
end


function UIGameTableMatch:clearPlayedCardsBySeatID(seatID) 
    if self.playerData[seatID] then
        local displayID = self.playerData[seatID].displayID
        if  self['playedCardNode_'..displayID] ~= nil then
            self['playedCardNode_'..displayID]:removeFromParent()
            self['playedCardNode_'..displayID] = nil
        end
    end
end


function UIGameTableMatch:setPlayedCards(seatID,cards,isRoundOver,startPositionTable) 
    if self.playerData[seatID] and cards and next(cards) then
        local displayID = self.playerData[seatID].displayID
        if  self['playedCardNode_'..displayID] ~= nil then
            self['playedCardNode_'..displayID]:removeFromParent()
            self['playedCardNode_'..displayID] = nil
        end
        local suffix = ''
        if isRoundOver == true then 
            suffix = '_end'
        end
        local posX = self['Image_played_card_'..displayID..suffix]:getPositionX()
        local posY = self['Image_played_card_'..displayID..suffix]:getPositionY()
        local scaleX = self['Image_played_card_'..displayID..suffix]:getScaleX() 
        local scaleY = self['Image_played_card_'..displayID..suffix]:getScaleY() 
        local arrange = UIGameTableMatch.ARRANGE_MIDDLE
        if displayID == 3 then
            arrange = UIGameTableMatch.ARRANGE_LEFT
        elseif displayID == 2 then
            arrange = UIGameTableMatch.ARRANGE_RIGHT
        end
        printf("seatID:%s == self.lordSeatID:%s",seatID , self.lordSeatID)
        local _isRoundOver = false
        if _isRoundOver then 
            _isRoundOver = isRoundOver
        end
        local node,mid =  self:arrangeCards(arrange,cards,(seatID == self.lordSeatID),_isRoundOver,startPositionTable)

        self['playedCardNode_'..displayID] = node
        if self['Image_played_card_'..displayID..suffix].middleNode and tolua.isnull(self['Image_played_card_'..displayID..suffix].middleNode) == false then 
            self['Image_played_card_'..displayID..suffix].middleNode:removeFromParent()
            self['Image_played_card_'..displayID..suffix].middleNode = nil
        end
        self['Image_played_card_'..displayID..suffix].middleNode = mid

        self['playedCardNode_'..displayID]:setPositionX(posX)
        self['playedCardNode_'..displayID]:setPositionY(posY)
        self['playedCardNode_'..displayID]:setScaleX(scaleX)
        self['playedCardNode_'..displayID]:setScaleY(scaleY)
        self['Image_played_card_'..displayID..suffix]:getParent():addChild(self['playedCardNode_'..displayID])
    end
end

function UIGameTableMatch:handleSentCards(playedCards)

     if self:compareTable(self.lastSentCards or {},playedCards) == true then--出的牌和服务器返回的是一致的，说明出牌有效。
        -- self:removePickedCards()-- 在用户点击出牌按钮的时候就已经预先处理了。
     else--出的牌和服务器不一致，恢复打出去的牌，再使用服务器的牌。 
        local cards = self:removeCards(self.lastCardsStatus,playedCards)
        self:updateHandCards({cards = cards}) 
     end
        self.lastCardsStatus = self:getAllHandCardsValues()

end

function UIGameTableMatch:disableAllBUttonsAndClock()
    self["Button_wantlord"]:setVisible(false)
    self["Button_dont_wantlord"]:setVisible(false) 
    self["Button_doublebet"]:setVisible(false)
    self["Button_dont_doublebet"]:setVisible(false) 
    self:showPlayOptions(false)  
    self["Button_dont_call_lord"]:setVisible(false)
    self["Button_call_lord"]:setVisible(false) 
    self["Button_dont_grab_lord"]:setVisible(false)
    self["Button_grab_lord"]:setVisible(false)
    self:startPlayerCountdownBySeatID(-1,0)
end

function UIGameTableMatch:showButtonsByRoomStatus(roomStatus,forceAction,isNewRound)  
    self["Button_wantlord"]:setVisible(false)
    self["Button_dont_wantlord"]:setVisible(false) 
    self["Button_doublebet"]:setVisible(false)
    self["Button_dont_doublebet"]:setVisible(false) 
    self:showPlayOptions(false)  
    self["Button_dont_call_lord"]:setVisible(false)
    self["Button_call_lord"]:setVisible(false) 
    self["Button_dont_grab_lord"]:setVisible(false)
    self["Button_grab_lord"]:setVisible(false)

    self["Button_dont_wantlord"]:setEnabled(true)
    self["Button_dont_doublebet"]:setEnabled(true)
    self["Button_dont_call_lord"]:setEnabled(true)
    self["Button_dont_grab_lord"]:setEnabled(true)
    
    printf("showButtonsByRoomStatus:%s self.autoPlayStatus:%s",roomStatus,self.autoPlayStatus)
    if self.autoPlayStatus == 1 then
        self["Button_calcelAutoplay"]:setVisible(true)
        return 
    end 
    
    local disableDeny = (forceAction and forceAction == 1) 

    if roomStatus == UIGameTableMatch.ROOM_STATE_WANT_LORD then
        self["Button_wantlord"]:setVisible(true)
        self["Button_dont_wantlord"]:setVisible(true)
        if disableDeny == true then  
            self["Button_dont_wantlord"]:setEnabled(false)
        end
    elseif roomStatus == UIGameTableMatch.ROOM_STATE_DOUBLE then
        self["Button_doublebet"]:setVisible(true)
        self["Button_dont_doublebet"]:setVisible(true)
        if disableDeny == true then  
            self["Button_dont_doublebet"]:setEnabled(false)
        end
    elseif roomStatus == UIGameTableMatch.ROOM_STATE_PLAYING then 
        self:showPlayOptions(true) 
    elseif roomStatus == UIGameTableMatch.ROOM_STATE_CALL_LORD then
        self["Button_dont_call_lord"]:setVisible(true)
        self["Button_call_lord"]:setVisible(true)
        if disableDeny == true then  
            self["Button_dont_call_lord"]:setEnabled(false)
        end
    elseif roomStatus == UIGameTableMatch.ROOM_STATE_GRAB_LORD then  
        self["Button_dont_grab_lord"]:setVisible(true)
        self["Button_grab_lord"]:setVisible(true)
        if disableDeny == true then  
            self["Button_dont_grab_lord"]:setEnabled(false)
        end
    end  

    self['Button_pass']:setEnabled(not (type(isNewRound) == 'number' and isNewRound == 1))
    self['Button_hint']:setEnabled(not (type(isNewRound) == 'number' and isNewRound == 1))
end

function UIGameTableMatch:setCardLetfs(seatID,cardCount) 
    if self.playerData[seatID] then
        local displayID = self.playerData[seatID].displayID  
        if self['Image_cardleft_'..displayID] then
            if cardCount <= 0 then
                self['Image_cardleft_'..displayID]:setVisible(false)
            else
                self['Image_cardleft_'..displayID]:setVisible(true)
            end
            self['Image_cardleft_'..displayID]:getChildByName('AtlasLabel_text'):setString((cardCount or -1).."")
        end
    end 
end


--[==[---------------------DISPLAY FUNCTIONS END-----------------]==]

--[==[-------------------TCP FUNCTIONS START-----------------------]==]

function UIGameTableMatch:TCP_FORCE_KICK(data) 
    GameTableCommon.forceKickHandler(self,data)
end

function UIGameTableMatch:TCP_SERVER_FAIL(data)
    dump(data,'TCP_SERVER_FAIL')
    if data.actionId == 0x05 then
        if data.cards then
            self:updateHandCards({cards = data.cards})
            LuaTools.showAlert("出牌超时")
            self.playerData[self.mySeatID].cards = data.cards
        end     
    else
        GameTableCommon.handleExceptionMsg(self,data)
    end
end

function UIGameTableMatch:TCP_PLAYER_KICK(data)
    -- dump(data,'TCP_KIKPLAYER') 
    data.playerUID  =   self.playerData[data.sentSeatID].UID
    data.BePlayerUID =   self.playerData[data.receiveID].UID
    if data.status ~= 2 then 
        GameTableCommon.kickPlayer( self,data )
    else
        LuaTools.showAlert('踢人失败')
    end
end

function UIGameTableMatch:TCP_ROUND_OVER(data) 
    dump(data,'本局游戏结束')
    self.isGameStarted = nil
    if G_BASEAPP:getView('UIMain') then 
        G_BASEAPP:callMethod('UIMain','reqSock_queryNewbie') 
    end
    
    local isDealerWon = false
    local argTable = {}
    argTable.infoTable = {}
    argTable.delegate = self

    local tempIsMyself = false 
    local function playSprintAnimation(isDealerWon)
        local path = 'Animation_fonts_spring.csb'
        if isDealerWon == false then 
            path = 'Animation_fonts_fanspring.csb'
        end
        printf('SPRING --->>> path:%s',path)
        if self.springAnimNode and not tolua.isnull(self.springAnimNode) then 
            self.springAnimNode:removeFromParent()
            self.springAnimNode = nil 
        end 
        self.springAnimNode  = GameTableCommon.createAnimationNode(path,onFinish)
        self.springAnimNode:setPosition(display.center)
        self:addChild(self.springAnimNode) 
    end

    for k,v in pairs(data.results) do
        local info = {}
        local curPlayer = self.playerData[v.seatID] 
        self:showAutoplayAnimation( v.seatID , false) 

        local displayID = curPlayer.displayID
        if self['Panel_player_'..displayID]:getChildByName('Node_warning') then 
            self['Panel_player_'..displayID]:getChildByName('Node_warning'):setVisible(false)
        end 

        info.iconUrl  = curPlayer.iconUrl
        info.name  = curPlayer.nickName 
        if curPlayer.seatID == self.mySeatID then
             info.name = "自己"
             info.isMyself = true
             tempIsMyself =true 
        end

        info.coins  = v.currenWinAmount
        info.sex  = curPlayer.Sex


        if v.seatID == self.lordSeatID then 
            info.isDealer = true
            if v.currenWinAmount >= 0 then 
                isDealerWon = true 
            end
        end 

        if v.seatID ~= self.mySeatID then 
            self:setPlayedCards(v.seatID,v.cards,true)
            local coinText = self['Panel_player_'..self.playerData[v.seatID].displayID]:getChildByName("Text_coins")
            coinText:setString(v.totalCoins.."")
        else
            self:updateMyAccu(v.totalCoins)
            if v.currenWinAmount >= 0 then 
                argTable.isWon = true
            end
        end 
        table.insert(argTable.infoTable,info)

        self:setCardLetfs(v.seatID,0)
    end

    for k,v in pairs(argTable.infoTable) do
        if v.isDealer and k ~= 2 then
            argTable.infoTable[k] , argTable.infoTable[2] = argTable.infoTable[2] , argTable.infoTable[k] 
            break
        end
    end
    self['Button_calcelAutoplay']:setVisible(false)  
    argTable.type = 'ddz'
    -- argTable.readyCallback = function() 
    --     self:PlayerCtrl_readyUp()  
    --     if self.resultPage and self.resultPage.removeSelf then 
    --         self.resultPage:removeSelf()
    --         self.resultPage = nil
    --     end
    -- end
    -- argTable.ctCallback = function() 
    --     self:PlayerCtrl_changeTable() 
    --     if self.resultPage and self.resultPage.removeSelf then 
    --         self.resultPage:removeSelf()
    --         self.resultPage = nil
    --     end
    -- end
    self:DoubleAmount(data.doubleAmount)
    argTable.mulText = data.doubleAmount
    self:updatePlayerStatus(data.seatID,UIGameTableMatch.STATUS.NONE,true) 
     
    local function callBack()
         
    end
    self:createSchedule("RoundOver",function()
            self:stopSchedule("RoundOver")
            self:clearMyCards()  
            self:resetTable()
            self['Text_roomType']:setVisible(true)
            self['Panel_title']:getChildByName('Image_291'):setVisible(true)
            if tempIsMyself then 
                self.isRoundOver = true
            else 
            end
        end,2) 
    self.autoPlayStatus = 2

    self.currentRoomState = UIGameTableMatch.ROOM_STATE_IDLE 
    if data.Extra and data.Extra.spring then 
        local spr = tonumber(data.Extra.spring) 
        if spr and spr == 1 then
            playSprintAnimation(isDealerWon) 
        end
    end
end

function UIGameTableMatch:showAutoplayAnimation( seatID , show)
    if self.playerData[seatID] then 
        local displayID = self.playerData[seatID].displayID
        if self['Panel_robotNode_'..displayID].robotAnimationNode == nil then 
            self['Panel_robotNode_'..displayID].robotAnimationNode = GameTableCommon.createAnimationNode('Animation_robot.csb',nil,true)
            self['Panel_robotNode_'..displayID]:addChild(self['Panel_robotNode_'..displayID].robotAnimationNode)
        end 
        self['Panel_robotNode_'..displayID]:setVisible(show or false)
    end
end

function UIGameTableMatch:darkenHandCards( b )
    for i = 1 , #self.handCardTable do
        local card = self.handCardTable[i] 
            card:setColor(UIGameTableMatch.BUTTON_ENABLE_COLOR)
        if b == true then 
            card:setColor(UIGameTableMatch.BUTTON_DISABLE_COLOR)
        end
    end
end

--用户托管   seatId  state
function UIGameTableMatch:TCP_PLAYER_AUTOPLAY(data) 
    dump(data,'用户托管')
    if data.seatId == self.mySeatID then
        self.autoPlayStatus = data.state 
        self:PlayerCtrl_setAutoplay(data.state,0) 
        if self.autoPlayStatus == 1 then 
            self:showButtonsByRoomStatus(nil) 
        else
            if self.currentPlayerSeatID == self.mySeatID then
                if self.lastPlayedCards and #self.lastPlayedCards > 0 then
                    self:showButtonsByRoomStatus(self.currentRoomState,nil,nil)
                else
                    self:showButtonsByRoomStatus(self.currentRoomState,nil,1)
                end  
            end
        end
    end
    self:showAutoplayAnimation( data.seatId ,data.state == 1)
end

--用户不出
function UIGameTableMatch:TCP_PLAYER_PASS(data)
        dump(data,'用户不出')

    local clear = nil 
    self.isNewRound = nil
    if data.isNewRound == 1 then
        clear = true
        self.lastPlayedCards = nil
        self:clearPlayedCards()  
        self.isNewRound = true
    end    
    if data.nextID ~= -1 --[[and data.seatID ~= -1]] then 
        self:updatePlayerStatus(data.seatID,UIGameTableMatch.STATUS.PASS--[[,clear]])
        GameTableCommon.playSound(self,data.seatID, string.format('_buyao%s',math.random(1,3)))   
    end 

    self:showPlayOptions(false) 
    self.currentPlayerSeatID = data.nextID

    if data.nextID == self.mySeatID and self.autoPlayStatus == 2 then 
        self.povPlayedCard = nil
        self:showPlayOptions(true,data.isNewRound) 
    end
    if data.nextID >= 0 then 
        local displayID_next = self.playerData[data.nextID].displayID
        if self['Panel_player_'..displayID_next]:getChildByName('Node_warning') then 
            self['Panel_player_'..displayID_next]:getChildByName('Node_warning'):setVisible(false)
        end
    end

    self:clearPlayedCardsBySeatID(data.nextID) 
    self:startPlayerCountdownBySeatID(data.nextID)  
    self:updatePlayerStatus(data.nextID,UIGameTableMatch.STATUS.NONE)
    self.currentRoomState = UIGameTableMatch.ROOM_STATE_PLAYING 
end
UIGameTableMatch.sndTable = 
{
    [0x01] =    '_',
    [0x02] =    '_dui',
    [0x03] =    '_sange', 
    [0x04] =    '_sandaiyi', 
    [0x05] =    '_sandaiyidui', 
    [0x06] =    '_shunzi', 
    [0x07] =    '_liandui', 
    [0x08] =    '_feiji', 
    [0x09] =    '_feiji', 
    [0x0A] =    '_feiji', 
    [0x0B] =    '_sidaier', 
    [0x0C] =    '_sidaier', 
    [0x0D] =    '_zhadan', 
    [0x0E] =    '_wangzha',
}
function UIGameTableMatch:playSoundByCard(  cardType,cardVal,seatID )
    local sex = self.playerData[seatID].sex
    local prefix = Sound.SoundTable['prefix'][sex]
    local suffix =  UIGameTableMatch.sndTable[cardType]

    if cardType == 1 or cardType == 2 then 
        local val = Cardutl.GetCardValue(cardVal)
        if val > 13 then
            val=val-13
        end
        if cardVal == Cardutl.CARD_KING_B then --大王
            val = 15
        elseif cardVal == Cardutl.CARD_KING_S then --小王 
            val = 14
        end 
        suffix = string.format("%s%s",suffix , val)  
    end
    local sexStr = 'male' 
    if sex == GameTableCommon.SEX_FEMALE then 
        sexStr = 'female' 
    end

    if cardType == self.lastOriginalCardType and self.isNewRound ~= true and cardType ~= 1 and cardType ~= 2 then  
        suffix = string.format('_dani%s',math.random(1,3)) 
    end
    local sndPath = Sound.SoundTable['voice'][sexStr][string.format('%s%s',prefix,suffix)] 
    self.lastOriginalCardType = cardType
    audio.playSound(sndPath, false)
end

UIGameTableMatch.animTable = 
{ 
    
    anim = 
    {
        [0x08] =    'Animation_airplane.csb', 
        [0x09] =    'Animation_airplane.csb', 
        [0x0A] =    'Animation_airplane.csb', 
        [0x0D] =    'Animation_bomb.csb', 
        [0x0E] =    'Animation_rocket.csb', 


    },
    text = 
    {
        [0x06] =    'Animation_fonts_shunzi.csb', 
        [0x07] =    'Animation_fonts_liandui.csb', 
        [0x08] =    'Animation_fonts_airplane.csb', 
        [0x09] =    'Animation_fonts_airplane.csb', 
        [0x0A] =    'Animation_fonts_airplane.csb',  
    },
    snd = 
    {
        [0x08] = 'Cardtype_aircraft',
        [0x09] = 'Cardtype_aircraft',
        [0x0A] = 'Cardtype_aircraft',
        [0x0D] = 'Cardtype_bomb',
        [0x07] = 'Cardtype_double_line',
        [0x0E] = 'Cardtype_missile',
        [0x06] = 'Cardtype_one_line',
    }

}



function UIGameTableMatch:playAnimation( cardType,displayID )

    local function createAnimationNode(nodeName,onFinish)
       return GameTableCommon.createAnimationNode(nodeName,onFinish,false,0.5)
    end
    local textNode = UIGameTableMatch.animTable['text'][cardType]
    local animNode = UIGameTableMatch.animTable['anim'][cardType]

    if textNode then 
        local node = createAnimationNode(textNode)
        self:addChild(node)
        local pos = self['Image_played_card_'..displayID]:convertToWorldSpaceAR(cc.p(0,0))

        if displayID ~= 1 
        and self['Image_played_card_'..displayID] 
        and self['Image_played_card_'..displayID].middleNode 
        and tolua.isnull(self['Image_played_card_'..displayID].middleNode) == false 
        then

            local offsetX = self['Image_played_card_'..displayID].middleNode:convertToWorldSpaceAR(cc.p(0,0)).x
            if offsetX then  
                if displayID == 2 then  
                    pos.x =   offsetX - 80 
                else 
                    pos.x =   offsetX + 160 
                end     
            end  
        end
        pos.y = pos.y - 25
        node:setPosition(pos)
    end 
    if animNode then  
        local node = createAnimationNode(animNode)
        self:addChild(node)
        node:setPosition(display.center)
    end 
    audio.playSound(Sound.SoundTable['sfx'][UIGameTableMatch.animTable['snd'][cardType]] , false)
end

function UIGameTableMatch:getCardPosByVal( valTable )
    local ret = {} 
    local str = "BEGIN SEARCHING POS BY VAL\n"
    for i = 1 , #self.handCardTable do
        local card = self.handCardTable[i]
        str = str.."searching i["..i.."]:val("..card.val..") =========================\n"
        for j=1,#valTable do 
            str = str.."check j("..valTable[j]..") == i("..card.val..")\n" 
            ret[card.val]= card:convertToWorldSpaceAR(cc.p(0,0))  
        end 
    end
    return ret
end

--用户出牌
function UIGameTableMatch:TCP_PLAYER_PLAY_CARD(data)
            dump(data,'用户出牌')
    self:runAction(cc.Sequence:create(cc.DelayTime:create(1),
                cc.CallFunc:create(function() 
                    self['Image_status_1']:setVisible(false)
                    self['Image_status_2']:setVisible(false)
                    self['Image_status_3']:setVisible(false)
                 end) ))

    self.currentRoomState = UIGameTableMatch.ROOM_STATE_PLAYING 
    self:startPlayerCountdownBySeatID(data.nextID)  
    self:updatePlayerStatus(data.nextID,UIGameTableMatch.STATUS.NONE)
    Cardutl.SortOutCards(data.cards)
    self.lastPlayedCards = data.cards
    self.lastPlayedCardsType = Cardutl.TypeConvert[data.cardType]
    if self.lastPlayedCardsType == Cardutl.TYPE_BOMB_KING 
        or self.lastPlayedCardsType == Cardutl.TYPE_BOMB_4 then 
        self:DoubleAmount()
    end
    
    self:showPlayOptions(false) 
    self.currentPlayerSeatID = data.nextID
    self:clearPlayedCardsBySeatID(data.nextID)
    if data.seatID >= 0 then 
      self.playerData[data.seatID].cardLen = self.playerData[data.seatID].cardLen  - data.cardLen
    end

    if data.seatID >= 0  and  self.playerData[data.seatID].cardLen == 2 then
        if self.playerData[data.seatID].remaining_2 == nil then  
            self.playerData[data.seatID].remaining_2 = true
            audio.playSound(Sound.SoundTable['sfx']['Warning'] , false)
            GameTableCommon.playSound(self,data.seatID, '_baojing2' )
        end
        self:showWarningAnimation(data.seatID)
    end

    if data.seatID >= 0  and self.playerData[data.seatID].cardLen == 1 then 
        if  self.playerData[data.seatID].remaining_1 == nil then 
            self.playerData[data.seatID].remaining_1 = true
            audio.playSound(Sound.SoundTable['sfx']['Warning'] , false)
            GameTableCommon.playSound(self,data.seatID, '_baojing1' )
        end
        self:showWarningAnimation(data.seatID)
    end
    local displayID_curr
    if data.seatID >= 0  then 
        displayID_curr = self.playerData[data.seatID].displayID
        if self['Panel_player_'..displayID_curr]:getChildByName('Node_warning') then 
            self['Panel_player_'..displayID_curr]:getChildByName('Node_warning'):setVisible(true)
        end 
    end 
    if data.nextID >= 0 then 
        local displayID_next = self.playerData[data.nextID].displayID
        if self['Panel_player_'..displayID_next]:getChildByName('Node_warning') then 
            self['Panel_player_'..displayID_next]:getChildByName('Node_warning'):setVisible(false)
        end
    end
        
    if (self.autoPlayStatus == 1 or self.povPlayedCard ~= true) and data.seatID == self.mySeatID  then   
        local startPositionTable = self:getCardPosByVal( data.cards )
        self:setPlayedCards(self.mySeatID,data.cards,nil,startPositionTable)
        self:playSoundByCard(  data.cardType,data.cards[1],data.seatID) 
        self:playAnimation( data.cardType,displayID_curr )
    end
    if data.seatID >= 0  then  
       self:setCardLetfs(data.seatID,self.playerData[data.seatID].cardLen)
       print("setCardLetfs = "..self.playerData[data.seatID].cardLen)
    end
    if data.nextID == self.mySeatID and self.autoPlayStatus ~= 1 then
        if #self.lastPlayedCards > 0 then
            self:showButtonsByRoomStatus(self.currentRoomState,nil,nil)
        else
            self:showButtonsByRoomStatus(self.currentRoomState,nil,1)
        end
        self.povPlayedCard = nil
    end
    if data.seatID == self.mySeatID then 
        self:handleSentCards(data.cards)
    end
 

    if data.seatID  < 0 then --data.isNewRound == 1 then
        clear = true
        self.lastPlayedCards = nil
        self.lastOriginalCardType = nil
        self:clearPlayedCards()
        self['Button_pass']:setEnabled(false)
    end   

    if data.seatID >= 0  and  data.seatID ~= self.mySeatID then
        self:playSoundByCard(  data.cardType,data.cards[1],data.seatID)
        self:setPlayedCards(data.seatID,data.cards) 
        self:playAnimation( data.cardType,displayID_curr )
    end

    self.isNewRound = nil
end

function UIGameTableMatch:playDoubleAmination( amount,onfinish )
    self['BitmapFontLabel_multiAnimation']:stopAllActions()
    self['BitmapFontLabel_multiAnimation']:setPosition(display.center)
    self['BitmapFontLabel_multiAnimation']:setPositionY(display.center.y + 130)
    self['BitmapFontLabel_multiAnimation']:setVisible(true) 
    self['BitmapFontLabel_multiAnimation']:setString(string.format('x%s倍',amount))
    self['BitmapFontLabel_multiAnimation']:setOpacity(0)
    self['BitmapFontLabel_multiAnimation']:setScale(3)
    self['BitmapFontLabel_multiAnimation']:setLocalZOrder(10000)
    local imgActTime = 0.3
    local imgSclDown = cc.ScaleTo:create(imgActTime*0.5,1)
    local imgtnt = cc.FadeTo:create(imgActTime*0.5,255)
    local imgSpawn= cc.Spawn:create(imgSclDown,imgtnt)
    local imgSclUp = cc.ScaleTo:create(imgActTime*0.25,1.5)
    local imgSclDownFinal = cc.ScaleTo:create(imgActTime*0.25,1)
    local movementDst = self['Text_multiply']:convertToWorldSpaceAR(cc.p(0,0))

    local delay = cc.DelayTime:create(0.5)
    local movement = cc.MoveTo:create(imgActTime,movementDst)
    local tempScale = cc.ScaleTo:create(imgActTime,0.5)
    local movementAndScale = cc.Spawn:create(movement,tempScale)
    local imgtntzero = cc.FadeTo:create(imgActTime*0.5,0)

    local onfinishAct = cc.CallFunc:create(function()
        self['BitmapFontLabel_multiAnimation']:setPosition(display.center)
        self['BitmapFontLabel_multiAnimation']:setPositionY(display.center.y + 130)
        self['BitmapFontLabel_multiAnimation']:setVisible(false) 
            if self.doubleAmountNode  then 
                if tolua.isnull(self.doubleAmountNode ) == false then 
                    self.doubleAmountNode:removeFromParent()
                end
                self.doubleAmountNode = nil
            end

            self.doubleAmountNode = GameTableCommon.createAnimationNode('Animation_jiabei.csb',function() 
                if onfinish then 
                    onfinish()
                end
            end)
            self.doubleAmountNode:setPosition(movementDst)  
            self:addChild(self.doubleAmountNode)
    end)
    self['BitmapFontLabel_multiAnimation']:runAction(cc.Sequence:create(imgSpawn,imgSclUp,imgSclDownFinal,delay,movementAndScale,imgtntzero,onfinishAct))
end

function UIGameTableMatch:DoubleAmount(amount)
    if amount then 
            self.globalMultiply = amount
            self['Text_multiply']:setString(self.globalMultiply)
        return
    end
    self.globalMultiply=self.globalMultiply*2
        print('进入了加倍='..self.globalMultiply)

    self:playDoubleAmination( self.globalMultiply ,function()
        self['Text_multiply']:setString(""..self.globalMultiply)
    end)
end

--广播用户加倍  seatId
function UIGameTableMatch:TCP_WHO_DOUBLED(data)
    dump(data,'广播用户加倍')
    self.currentRoomState = UIGameTableMatch.ROOM_STATE_DOUBLE 
    local dontDoubleBet = UIGameTableMatch.STATUS.DOUBLE_BET
    self:DoubleAmount()
    GameTableCommon.playSound(self,data.seatId, '_jiabei')  
    self:updatePlayerStatus(data.seatId,dontDoubleBet)

end

--广播用户不加倍  '_bujiabei'
function UIGameTableMatch:TCP_PLAY_NO_DOUBLE_RES(data)
    dump(data,'广播用户不加倍')
    self.currentRoomState = UIGameTableMatch.ROOM_STATE_DOUBLE 
    local dontDoubleBet = UIGameTableMatch.STATUS.DONT_DOUBLE_BET
    GameTableCommon.playSound(self,data.seatId, '_bujiabei')  
    self:updatePlayerStatus(data.seatId,dontDoubleBet)
end     

--确定地主
function UIGameTableMatch:TCP_LORD_SATTLED_WHOS_DOUBLE(data)
    dump(data,"广播确定地主")
    self:showLordCards(data.cards)
    -- self:startPlayerCountdownBySeatID(data.firstDoubledSeatID)
    print("data.lordSeatID == " .. data.lordSeatID)
    self:setLord(data.lordSeatID) 
    self.lordSeatID = data.lordSeatID  
    self.currentRoomState = UIGameTableMatch.ROOM_STATE_DOUBLE 

    self:showButtonsByRoomStatus(nil)
    self:showButtonsByRoomStatus(self.currentRoomState,data.forceAction)
    if data.lordSeatID ~= self.mySeatID  then 
        self:createSchedule('hideDoubleButton',function()
            self:stopSchedule('hideDoubleButton')
            if self['Button_doublebet']:isVisible() then 
                self:PlayerCtrl_Notdoublebet() 
            end     
        end,5)
    end
    self.playerData[data.lordSeatID].cardLen = self.playerData[data.lordSeatID].cardLen + #data.cards

    if data.lordSeatID ~= self.mySeatID then 
        self:setCardLetfs(data.lordSeatID,21)
    end
    if data.lordSeatID == self.mySeatID  then 
        local cards = table.appendArray(self:getAllHandCardsValues(),data.cards)
        self:updateHandCards({cards = cards})
        self:pickCards(data.cards,true)
        self:createSchedule('resetCards',function()
            self:stopSchedule('resetCards')
            self:PlayerCtrl_resetSelectedCards()
        end,1)
    end  
    self['Image_status_1']:setVisible(false)
    self['Image_status_2']:setVisible(false)
    self['Image_status_3']:setVisible(false)

    self['Image_clock_1']:setVisible(false)
    self['Image_clock_2']:setVisible(false)
    self['Image_clock_3']:setVisible(false)
end

--有人退出房间
function UIGameTableMatch:TCP_PLAYER_DISCONNECTED(data) 
    dump(data,'有人退出房间')
    if self.playerData and self.playerData[data.seatID] then
        local displayID = self.playerData[data.seatID].displayID
        self['Panel_player_'..displayID]:setVisible(false)
        if  self['playedCardNode_'..displayID] ~= nil then
            self['playedCardNode_'..displayID]:removeFromParent()
            self['playedCardNode_'..displayID] = nil
        end
        if self['Panel_player_'..displayID]:getChildByName('Node_warning') then 
            self['Panel_player_'..displayID]:getChildByName('Node_warning'):setVisible(false)
        end
        if self['warningNode_'..displayID] then 
            self['warningNode_'..displayID]:removeFromParent()
            self['warningNode_'..displayID] = nil
        end
        self:showAutoplayAnimation(data.seatID , false)
        self.playerData[data.seatID ].isSat = nil
        self['Image_status_' .. displayID]:setVisible(false)
        UIGameTableMatch.displayIDTable[self.playerData[data.seatID].displayID]=false
        self.playerData[data.seatID]=nil
    end
end

--广播用户叫地主  NextSeatId
function UIGameTableMatch:TCP_WHO_DECIDE_TO_CALL_LORD(data)
    --NextSeatId  seatId
    dump(data,'广播用户叫地主')
    if self.resultPage and self.resultPage.removeSelf then     
        self.resultPage:removeSelf()
        self.resultPage = nil
    end
    -- dump(data,"广播该谁叫地主 ")\
    if data.seatId >= 0 then 
        GameTableCommon.playSound(self,data.seatId, '_Order')  
        self:updatePlayerStatus(data.seatId,4)
        self.currentRoomState = UIGameTableMatch.ROOM_STATE_GRAB_LORD 
    else 
        self.currentRoomState = UIGameTableMatch.ROOM_STATE_CALL_LORD 
    end 
    if data.NextSeatId >= 0  then 
        self:startPlayerCountdownBySeatID(data.NextSeatId, self.callLordTime)
        self:showButtonsByRoomStatus(nil)
        if data.NextSeatId == self.mySeatID   then 
            self:showButtonsByRoomStatus(self.currentRoomState,nil)
            self['Image_status_1']:setVisible(false)
        end 
    end
end

--广播用户不叫地主
function UIGameTableMatch:TCP_NO_CALL_LORD_RES(data)
        dump(data,'广播用户不叫地主')

    if self.resultPage and self.resultPage.removeSelf then     
        self.resultPage:removeSelf()
        self.resultPage = nil
    end
    if data.seatId >= 0  then 
        GameTableCommon.playSound(self,data.seatId, '_NoOrder')  
        self:updatePlayerStatus(data.seatId,3)
        self.currentRoomState = UIGameTableMatch.ROOM_STATE_CALL_LORD 
    end 
    if data.NextSeatId >= 0  then 
        self:startPlayerCountdownBySeatID(data.NextSeatId)
        self:showButtonsByRoomStatus(nil)
        if data.NextSeatId == self.mySeatID   then 
            self:showButtonsByRoomStatus(self.currentRoomState,nil)
            self['Image_status_1']:setVisible(false)
        end 
    end 
end

--广播用户抢地主
function UIGameTableMatch:TCP_WHO_DECIDE_TO_GRAB_LORD(data)
    --NextSeatId  seatId
            dump(data,'广播用户抢地主')
    print('self.mySeatID='..self.mySeatID)
    if self.resultPage and self.resultPage.removeSelf then     
        self.resultPage:removeSelf()
        self.resultPage = nil
    end
    -- dump(data,"广播该谁抢地主")

    if data.seatId >= 0  then 
        GameTableCommon.playSound(self,data.seatId, ('_Rob'..math.random(1,3)))   
        self:updatePlayerStatus(data.seatId,5)
         self:DoubleAmount()
    end 
    self.currentRoomState = UIGameTableMatch.ROOM_STATE_GRAB_LORD  
    if data.NextSeatId >= 0  then 
       self:startPlayerCountdownBySeatID(data.NextSeatId, self.dropLordTime)  
       self:showButtonsByRoomStatus(nil)
       if data.NextSeatId == self.mySeatID    then
          self:showButtonsByRoomStatus(self.currentRoomState,nil)
          self['Image_status_1']:setVisible(false)
       end 
    end    
end


--广播用户不抢地主
function UIGameTableMatch:TCP_NO_DROP_LORD_RES(data) 
                dump(data,'广播用户不抢地主')

    if self.resultPage and self.resultPage.removeSelf then     
        self.resultPage:removeSelf()
        self.resultPage = nil
    end
    if data.seatId >= 0  then 
        GameTableCommon.playSound(self,data.seatId, '_NoRob')   
        self:updatePlayerStatus(data.seatId,6)
    end 
    self.currentRoomState = UIGameTableMatch.ROOM_STATE_GRAB_LORD  
    if data.NextSeatId >= 0  then 
       self:startPlayerCountdownBySeatID(data.NextSeatId)  
       self:showButtonsByRoomStatus(nil)
       if data.NextSeatId == self.mySeatID    then
          self:showButtonsByRoomStatus(self.currentRoomState,nil)
          self['Image_status_1']:setVisible(false)
       end 
    end    
end     

--有人进入房间
function UIGameTableMatch:TCP_PLAYER_CONNECTED(data) 
    dump(data,'有人进入房间')
    data.status = 0 
    self.playerData[data.seatID]=data  
    self.playerData[data.seatID].totalAccu = data.coins
    self:insertPlayerToDisplayTable(self.playerData[data.seatID])
    data.role = 0--force erase role
    self:setupPlayer(data)     
    self:updatePlayerStatus(data.seatID,data.status)
end



--广播发牌
function UIGameTableMatch:TCP_DEAL_CARDS(data)
    dump(data,'广播发牌')
    self['Image_waitingTable']:setVisible(false)
    self['Image_waitingOutOff']:setVisible(false)
    local function tempFunc()
        self:stopSchedule("RoundOver")
        self['Text_roomType']:setVisible(false)
        self['Panel_title']:getChildByName('Image_291'):setVisible(false)
        
        self:cleanTable() 
        self.isGameStarted = true
        self['Image_waitingTable']:setVisible(false) 
        self:hideAllPlayersStatus()
        
        data.fastDeal = false
        self.autoplayStatus = 2
        self.isDealingCards = true
        data.onFinish = function() 
            self.isDealingCards = false
        end
        self:updateHandCards(data) 
        self.currentRoomState = UIGameTableMatch.ROOM_STATE_PLAYING 

        for k,v in pairs(UIGameTableMatch.displayIDTable) do 
            self:setCardLetfs((k-1),17)
            self.playerData[k-1].cardLen = 17
        end

        for k=1,4 do
            self['Image_lordcard_'..k]:setVisible(true)
            self['Image_lordcard_'..k]:loadTexture('newcard/jx_back.png',ccui.TextureResType.plistType)
        end
    end
    if self.isRoundOver == true then
        local function  callback()       
            tempFunc()
            self.isRoundOver = false
        end 
        local as = cc.Sequence:create(cc.DelayTime:create(1),cc.CallFunc:create(callback))
        self:runAction(as)
    else
        local function  callback()       
            tempFunc()
            self.isRoundOver = false
        end 
        local as = cc.Sequence:create(cc.DelayTime:create(1),cc.CallFunc:create(callback))
        self:runAction(as)  
    end
end


function UIGameTableMatch:TCP_PLAYER_READY(data) 
    self:updatePlayerStatus(data.seatID,UIGameTableMatch.STATUS.READY)
    if data.seatID == self.mySeatID then  
        self['Image_status_1']:setVisible(true)
        self['Image_status_1']:loadTexture("room/RoomPlayerSatus_1.png",ccui.TextureResType.plistType)
    end 
end


--更新等待时间
function UIGameTableMatch:updateWaitingMatchBegin(time,info)
    print("time = "..time)
    local par = self['Panel_waitingMatchBegin']
    if time and time>=0 and time<=1800 then 
        par:setVisible(true)
        local function  callback()       
            local minute = math.floor(time/60)
            local second = time - minute*60

            par:getChildByName('BitmapFontLabel_time'):setString(string.format("%02d:%02d",minute,second) )       
            time = time -1
            if time < 0 then 
                self:stopSchedule('WaitingMatchBeginSche')
                par:setVisible(false)
            end  
        end 
        self:createSchedule('WaitingMatchBeginSche', callback, 1)   
    end

    self['Text_matchType']:setString(info.Name)
    self['ListView_LastReward']:removeAllChildren()
    self['ListView_LastReward']:setItemModel(self['Panel_rewardItem'])     
    local count = 0 
    local cupKind = {'res_awards/top_01.png','res_awards/top_02.png','res_awards/top_03.png'}
    local newReward = {}  
    for k,v in pairs(info.Reward) do  
       if k and  v then 
          newReward[tonumber(k)] = v 
       end    
    end     
    self.nowRewardInfo = {} 
    local function testSort(a,b)
        return tonumber(a.level)< tonumber(b.level)
    end

    -- dump(info,'传进来的列表信息')  
    table.sort(newReward,testSort)

    -- dump(newReward,'奖励列表')
    for  k=1,#newReward do 
        local var = newReward[k] 
        self.nowRewardInfo[k] = {} 
        self['ListView_LastReward']:pushBackDefaultItem()
        local item = self['ListView_LastReward']:getItem(count)
        item:getChildByName('Image_cup'):setVisible(var.level <= 3 )
        if var.level <=3 then 
           item:getChildByName('Image_cup'):loadTexture(cupKind[var.level],ccui.TextureResType.plistType)
           item:getChildByName('Text_rank'):setVisible(false)
        end 
        if var.minRank == var.maxRank then 
           item:getChildByName('Text_rank'):setString(var.minRank)
        else 
           item:getChildByName('Text_rank'):setString(var.minRank..'-'..var.maxRank)
        end     
        self.nowRewardInfo[k].minRank = var.minRank 
        self.nowRewardInfo[k].maxRank = var.maxRank  
        
        local posX,posY =  item:getChildByName('Text_reward'):getPosition()
        local reward = ''


        if var.coin ~= 0 then  
           local childReward = self['Panel_waitingMatchBegin']:getChildByName('Panel_initLoginReward1'):clone() 
           item:addChild(childReward)
           childReward:setPosition(posX,posY)
           childReward:setVisible(true)
           childReward:getChildByName('Text_2'):setString(LuaTools.convertAmountChinese(var.coin))
           posX = posX + (childReward:getContentSize().width) 
           reward = reward..LuaTools.convertAmountChinese(var.coin)..'金币'..'+'  
        end 
        
        if var.gem ~=  0 then 
           local childReward = self['Panel_waitingMatchBegin']:getChildByName('Panel_initLoginReward2'):clone() 
           item:addChild(childReward)
           childReward:setVisible(true)
           childReward:setPosition(posX,posY)
           childReward:getChildByName('Text_2'):setString(LuaTools.convertAmountChinese(var.gem))
           posX = posX + (childReward:getContentSize().width) 

           reward = reward..var.gem..'个元宝'..'+' 
        end    

        if var.telfee ~=  0 then 
           local childReward = self['Panel_waitingMatchBegin']:getChildByName('Panel_initLoginReward4'):clone() 
           item:addChild(childReward)
           childReward:setVisible(true)
           childReward:setPosition(posX,posY)
           childReward:getChildByName('Text_2'):setString(LuaTools.convertAmountChinese(var.telfee))
           posX = posX + (childReward:getContentSize().width) 

           reward = reward..var.telfee..'张话费券'..'+' 
        end   

        if var.ticket and var.ticket.count > 0 then 
           local childReward = self['Panel_waitingMatchBegin']:getChildByName('Panel_initLoginReward3'):clone() 
           item:addChild(childReward)
           childReward:setVisible(true)
           childReward:setPosition(posX,posY)
           childReward:getChildByName('Text_2'):setString(LuaTools.convertAmountChinese(var.ticket.count))
           posX = posX + (childReward:getContentSize().width)     

           reward = reward..var.ticket.count..'张'..self.ticketKind[var.ticket.type]..'+'    
        end  

        if var.name and var.name ~= '' then 
            local textArea = ccui.Text:create()
            textArea:setAnchorPoint(0,0.5) 
            textArea:setString(' '..var.name)
            textArea:setFontSize(20)
            textArea:setColor(cc.c3b(255,0,0))
            item:addChild(textArea)
            textArea:setPosition(posX,posY)
            reward = reward..var.name..'+' 
        end 


        self.nowRewardInfo[k].reward = string.sub(reward,1,(#reward-1)) 
        -- item:getChildByName('Text_reward'):setString(reward)
        item:setVisible(true)
        count = count + 1 
   end  

end  

--设置头像 vip
function UIGameTableMatch:setAvatarAndVIP(_avatar,par,sex,viptype,viplvl)
    if _avatar and _avatar ~= "" then
      local function onFinishTable(status,downloadedSize,dst)
          if status == "success" then
             --item:getChildByName('Image_avatar'):loadTexture(dst,ccui.TextureResType.localType)
             newHeadSpr = cc.Sprite:create(dst)
          else 
             newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[sex+1])   
          end
          LuaTools.makeSpriteRounded(newHeadSpr, par:getChildByName('Image_avatar'), self.config.maskSprite, false)
      end
      local newName = _avatar
      LuaTools.getFileFromUrl({url = _avatar, destFile =(newName:gsub("/","_")), onFinishTable = onFinishTable })
    else 
      newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[sex+1])
      LuaTools.makeSpriteRounded(newHeadSpr, par:getChildByName('Image_avatar'), self.config.maskSprite, false)   
    end
    par:getChildByName('Image_avatar'):setLocalZOrder(20)
    par:getChildByName('Image_vip'):setLocalZOrder(30)

    --VIP
    local vipNode = par:getChildByName("Image_vip") 
    vipNode:setVisible(false)
    if viptype > 0 and viplvl > 0 then 
        vipNode:setVisible(true)
        local vipBG = 'common/icon_vip_bg_'..(viptype - 1 )..'.png'
        local viplv = "V"..viplvl
        vipNode:loadTexture(vipBG,ccui.TextureResType.plistType)
        vipNode:getChildByName("BitmapFontLabel_lvl"):setString(viplv) 
    end
end

--网络阻塞 seatId  type
function UIGameTableMatch:TCP_NET_TROUBLE(data)
    dump(data,'网络阻塞')
end    

--新的回合开始执行动画
function UIGameTableMatch:newRoundAction(round) 
    if round >=1 and round <=3 then 
        local name = 'Animation_awards_0'..round..'.csb'
        local bt_LotteryNode = cc.CSLoader:createNode(name) 

        bt_LotteryNode:setPosition(cc.p(self['Panel_tales']:getContentSize().width/2,self['Panel_tales']:getContentSize().height*0.68))
        
        local action = cc.CSLoader:createTimeline(name)
        bt_LotteryNode:runAction(action)
        action:gotoFrameAndPlay(0,true)
        self['Panel_tales']:addChild(bt_LotteryNode,99999)
        bt_LotteryNode:setName('lotteryLogo')
        
        local function cb() 
           bt_LotteryNode:removeFromParent(true)  
        end     
        self['Panel_tales']:runAction(cc.Sequence:create(cc.DelayTime:create(2.5),cc.CallFunc:create(cb))) 
    end     
end 


--广播新一轮比赛开始   INFO
function UIGameTableMatch:TCP_NEW_ROUND(data)
    dump(data,'新一轮比赛开始 ')
    self['Panel_waitingMatchBegin']:setVisible(false)
    self.round = data.round
    self.passNum = data.passNum
    if self.round > 3 then
        self.round = 3
    end
    self:newRoundAction(data.round) 
    self['Image_waitingTable']:setVisible(true)
    self.allThisRoundTime = self.AllMatchInfo.Stage[self.round].time * 60
    self:startNextRound()
end

function UIGameTableMatch:startNextRound()
    if self.round<=0 or self.round>3 then
        self['Panel_']:setVisible(false)
        return
    end 
    -- print("dssssssssssssss")
    self['Panel_']:setVisible(true)
    self['LoadingBar_3']:setPercent(100/3 * self.round)
    self['Panel_waitingResult']:setVisible(false)
    self.startRoundTime = os.time()
    if self.round > 0 and self.round <= 3 then
        local base = self.AllMatchInfo.Stage[self.round].base
        print("base = " .. base)
        self['Panel_title']:getChildByName('Text_betpool'):setString(base)
    end
    if self.round+1 <= 3 then
        self['Image_3']:setVisible(true)
        self['BitmapFontLabel_nowNumber']:setVisible(true)
        self['BitmapFontLabel_nowNumber']:setString("第"..self.passNum.."名")
    else
        self['Image_3']:setVisible(false)
        self['BitmapFontLabel_nowNumber']:setVisible(false)
    end
    self:stopSchedule('UpdateRoundTime')
    self['Panel_']:getChildByName('Text_time'):setString("00:00")
    local function  callback()
        local AllText = {
            "预赛",
            "复赛",
            "决赛"
        }
        local par = self['Panel_']
        par:setVisible(true)
        local lunText = par:getChildByName("Text_time_0")
        lunText:setString(AllText[self.round].."淘汰倒计时")
        local lefTime = self.allThisRoundTime - (os.time() - self.startRoundTime)    
        local minute = math.floor(lefTime/60)
        local second = lefTime - minute*60

        -- par:getChildByName('Text_time'):setVisible(false)
        par:getChildByName('Text_time'):setString(string.format("%02d:%02d",minute,second) )       
        if lefTime <= 0 then 
            self:stopSchedule('UpdateRoundTime')
            par:getChildByName('Text_time'):setString("00:00")       
        end  
    end 
    self:createSchedule('UpdateRoundTime', callback, 1) 
end

--广播一轮比赛结束，等待其他玩家结束牌局
function UIGameTableMatch:TCP_ONE_ROUND_OVER(data)
    dump(data,'广播一轮比赛结束，等待其他玩家结束牌局')
    if self.round > 0 then 
        self['Panel_waitingMatchBegin']:setVisible(false)
        self['Panel_waitingResult']:setVisible(true)
        self['Image_waitingTable']:setVisible(false)
        self['Image_waitingOutOff']:setVisible(false)
        self['Panel_waitingResult']:getChildByName('BitmapFontLabel_14'):setString("第"..self.myRank.."名")
    end
end    

--比赛结束
function UIGameTableMatch:TCP_MATCH_OVER(data)
    dump(data,'比赛结束') 
    self['Panel_waitingResult']:setVisible(false)
    self.Broadcast:removeSelf()
    G_BASEAPP:removeView('UIGameTableMenu')
    local function goHall(event)
       if event.name == 'ended' then 
            self:removeSelf()
       end 
    end  

    local function compareRank(idx)
        local rankReward = '' 
        for k, v in pairs(self.nowRewardInfo) do 
            if idx >= v.minRank and idx <= v.maxRank then  
               rankReward = v.reward 
               break
            end 
        end     
        return rankReward     
    end     
    local imageTab1 = {'res_awards/top_win_txt1.png','res_awards/top_win_txt2.png','res_awards/top_win_txt3.png','res_awards/top_win_txt4.png'}
    local imageTab2 = {'res_awards/top_win_01.png','res_awards/top_win_02.png','res_awards/top_win_03.png',}
    local tempTag = compareRank(data.rank)
    self['Panel_winFinals']:setVisible(tempTag ~= '')
    self['Panel_loseFinals']:setVisible(tempTag == '') 
    local time1,time2 = string.sub(self.AllMatchInfo.StartTime,12,16),string.sub(self.AllMatchInfo.StartTime,1,10)



    if tempTag ~= '' then 
        local par = self['Panel_winFinals']:getChildByName('Panel_main')
        local function hideOther()
            par:getChildByName('Image_30'):setVisible(false) 
            par:getChildByName('Image_29'):setVisible(false) 
            par:getChildByName('Text_51'):setVisible(false) 
            par:getChildByName('Text_51_0'):setVisible(false) 
            par:getChildByName('Text_51_0_0'):setVisible(false) 
        end    
        if data.otherInfo and data.otherInfo ~= '' then  --排名信息
             local _rewardInfo = json.decode(data.otherInfo)
             local rewardInfos = {} 
             for k,v in pairs(_rewardInfo.ranks) do 
                rewardInfos[tonumber(k)] = v 
             end    
             if #rewardInfos > 0 then 
                self['ListView_endRankList']:setItemModel(self['Panel_endRankModel'])
                for k=1,#rewardInfos do 
                    local value = rewardInfos[k]
                    local uid  =  string.sub(value,1,(string.find(value,'_')-1))
                    local name =  string.sub(value,(string.find(value,'_')+1))
                    self['ListView_endRankList']:pushBackDefaultItem()
                    local mod = self['ListView_endRankList']:getItem(k-1)
                    mod:getChildByName('Text_ranks'):setString(k)
                    mod:getChildByName('Text_uids'):setString(uid)
                    mod:getChildByName('Text_names'):setString(name)
                    if k%2 == 1 then 
                       mod:setBackGroundColorOpacity(0)
                    end     
                end   
             else 
                 hideOther()  
             end    
        else  
           hideOther()     
        end 
        for k, v in pairs(self.nowRewardInfo) do 
            if data.rank >= v.minRank and data.rank <= v.maxRank then 
               par:getChildByName('Text_rewardFinal'):setString(v.reward) 
               -- par:getChildByName('Image_cup'):setVisible(data.rank<=3)
               local titleImage = imageTab1[data.rank] or imageTab1[4] 
               par:getChildByName('Image_head'):loadTexture(titleImage,ccui.TextureResType.plistType)
               -- if k<=3 then 
               --    par:getChildByName('Image_cup'):loadTexture(imageTab2[k],ccui.TextureResType.plistType)
               -- end  
               break
            end     
        end     
        par:getChildByName('Text_endName'):setString(self.PlayerData.nick..':')
        par:getChildByName('BitmapFontLabel_finalRankNum'):setString(data.rank)
        par:getChildByName('Button_returnHall'):onTouch(goHall)
        par:getChildByName('Text_endTime'):setString(time1)
        par:getChildByName('Text_endTitle'):setString(self.AllMatchInfo.Name)
        par:getChildByName('Text_time'):setString(time2)
    else 
        local par = self['Panel_loseFinals']:getChildByName('Panel_main')
        par:getChildByName('BitmapFontLabel_20'):setString('第'..data.rank..'名')
        par:getChildByName('Button_goFail'):onTouch(goHall)    
        par:getChildByName('Text_endTime'):setString(time1)
        par:getChildByName('Text_endTitle'):setString(self.AllMatchInfo.Name)
    end     

    self.myRank = data.rank
    self['AtlasLabel_nowPlayerNumber']:setString(""..self.myRank)
    -- self['AtlasLabel_totalNumber']:setString("/"..data.totalNumber)
    self['Panel_waitingResult']:getChildByName('BitmapFontLabel_14'):setString(self.myRank)

    self.round = nil
    self.myRank = nil
    self:stopSchedule('UpdateRoundTime')
    local bufferHnd = DataPacker.new(UIGameTableMatch.CMD['TABLE_DISCONNECT'])   
    self.tcpGear:sendData(bufferHnd:doPack()) 
    self.tcpGear:closeAndRelease() 
end     


-- MatchWheelWaitOne int8          = 0//正在等待进行第一轮比赛
-- MatchWheelOne int8          = 1//第一轮比赛中
-- MatchWheelOneWaitTwo int8   = 2//正在等待进行第二轮比赛
-- MatchWheelTwo int8          = 3//第二轮比赛中
-- MatchWheelTwoWaitThree int8 = 4//正在等待进行第三轮比赛
-- MatchWheelThree int8        = 5//第三轮比赛中
-- MatchWheelThreeWaitEnd int8 = 6//正在等待比赛结束
-- MatchWheelThreeEnd int8 = 7//比赛已结束
--首次登录
function UIGameTableMatch:TCP_TABLE_LOGIN_SUCESS(data)
    dump(data,'首次登录成功')
    LuaTools.stopWaiting() 
    self.matchType = data.matchId
    --if self.restTime  and  self.restTime > 0 and self.restTime <= 1800 then  --显示等待时间
    self:updateWaitingMatchBegin(self.restTime,self.AllMatchInfo) 
    --end  

    self.callLordTime = data.CallLordTime
    self.dropLordTime = data.DropLordTime
    self.doubleTime   = data.DoubleTime
    self.giveCardTime = data.SendCardTime


    if data.round > 0 and data.round <= 6 then
        self.round = math.floor((data.round+1)/2)
        self.allThisRoundTime = data.thisRoundLefTime
        self.passNum = data.passNum
        self:startNextRound()
    end
    if data.myRank > 0 then
        self.myRank = data.myRank
        self.totalNumber = data.allNum
        self:updateMyRank()
    end
     
    if data.info then 
        self.myTableInfo = data.info  --我自己的初始所有信息
        self['AtlasLabel_myCoins']:setString(data.info.coin)
        self:setAvatarAndVIP(data.info.icon,self['Panel_player_1'],data.info.sex,data.info.vipType,data.info.vip_level)
    end 
    
    if data.round == 2 or data.round == 4 then
        self['Image_waitingTable']:setVisible(true)
    elseif data.round == 6 then
        self['Panel_waitingMatchBegin']:setVisible(false)
        self['Panel_waitingResult']:setVisible(true)
        self['Image_waitingTable']:setVisible(false)
        self['Image_waitingOutOff']:setVisible(false)
        self['Panel_waitingResult']:getChildByName('BitmapFontLabel_14'):setString("第"..self.myRank.."名")
    end
end


--比赛取消
function UIGameTableMatch:TCP_MATCH_FAIL(data)
    dump(data,'比赛取消')
    local d = G_BASEAPP:addView('UIDialog', 65530, 1)
    d:setupDialog('', data.msg, 
    function()
        d:removeSelf()
        self:quitTable()
    end) 
end    

--通知当前排名  
function UIGameTableMatch:TCP_MATCH_RANK(data)
   -- data.rank   当前排名
   dump(data, "当前排名")
   if data.rank then
       self.myRank = data.rank
       self.totalNumber = data.totalNumber
       self:updateMyRank()
   end
end     

function UIGameTableMatch:updateMyRank()
    self['AtlasLabel_nowPlayerNumber']:setVisible(true)
    self['AtlasLabel_totalNumber']:setVisible(true)
    self['AtlasLabel_nowPlayerNumber']:setString(""..self.myRank)
    self['AtlasLabel_totalNumber']:setString("/"..self.totalNumber)
    self['Panel_waitingResult']:getChildByName('BitmapFontLabel_14'):setString("第"..self.myRank.."名")
end

--等待匹配其他玩家
function UIGameTableMatch:TCP_WAITING_OTHERS(data)
    dump(data,'等待匹配其他玩家')
    -- self:resetTable()
    self['Image_waitingTable']:setVisible(true)
end

--二次登录
function UIGameTableMatch:TCP_LOGIN_TABLE_SUCC(data)
    dump(data,'second login')
    LuaTools.stopWaiting()  
    self['Panel_waitingMatchBegin']:setVisible(false) 
    if G_BASEAPP:getView('UIMain') then 
        G_BASEAPP:callMethod('UIMain','reqSock_queryNewbie') 
    end 
    self.loginData = data 
    self['Text_multiply']:setString(data.doubleAmount or 1)--(data.roomExtend.multi or 1)
    self.globalMultiply = data.doubleAmount or 1 --data.roomExtend.multi
    -- self['Text_betpool']:setString(data.diZhu)
    if self.giveCardTime then
        UIGameTableMatch.PLAYER_ACTION_TIMEOUT = self.giveCardTime
    end
    --bpour
    LuaTools.stopWaiting() 
    self:resetTable()
    self:resetDisplayTable() 
    if self.resultPage and self.resultPage.removeSelf then 
        self.resultPage:removeSelf()
        self.resultPage = nil
    end

    local isMyPlaying = false
    if data then 
        if data.selfSeat then
           self.mySeatID  = data.selfSeat  
        end 

        self['AtlasLabel_nowPlayerNumber']:setVisible(true)
        self['AtlasLabel_totalNumber']:setVisible(true)

        if not self.myRank then
            self.myRank = data.totalNumber
            self['AtlasLabel_nowPlayerNumber']:setString(""..data.totalNumber)
            self['AtlasLabel_totalNumber']:setString("/"..data.totalNumber)
            self['Panel_waitingResult']:getChildByName('BitmapFontLabel_14'):setString("第"..self.myRank.."名")
        end

        self['Button_calcelAutoplay']:setVisible(false)
        self.currentRoomState = data.roomState

        for k,v in pairs(data.userData) do
            self.playerData[v.seatID] = v 
            self.playerData[v.seatID].cardLen = v.nowCardLen
            if v.seatID == self.mySeatID then--force my displayID to 1
                print("v.seatID == self.mySeatID ")
                self.playerData[v.seatID].displayID = 1
                if data.roomState ~= UIGameTableMatch.ROOM_STATE_IDLE  then
                    local tbl = {}
                    tbl['cards'] = v.userCards
                    self:updateHandCards(tbl) 
                    self.isGameStarted = true
                end
            else
                self:setPlayedCards(v.seatID,v.userCards)
                self:insertPlayerToDisplayTable(self.playerData[v.seatID])--self.playerData[v.seatID]) 
            end
            self.playerData[v.seatID].totalAccu = v.coins
            if v.seatID == self.mySeatID then
                self:updateMyAccu(v.coins)
            else
                local coinText = self['Panel_player_'..self.playerData[v.seatID].displayID]:getChildByName("Text_coins")
                coinText:setString(v.coins.."")
            end
            
            if data.roomState == UIGameTableMatch.ROOM_STATE_IDLE then
                self.playerData[v.seatID].role = 0 --we're not playing game, clear player's role
            else 
                self:setCardLetfs(v.seatID,v.nowCardLen)
            end

            self:updatePlayerStatus(v.seatID,self.playerData[v.seatID].status)
            if v.autoPlayStatus == 1 and v.seatID == self.mySeatID then
                self.autoPlayStatus = v.autoPlayStatus 
                self['Button_calcelAutoplay']:setVisible(true) 
                self:darkenHandCards( true )
            end
            if v.autoPlayStatus == 1 then
                self:showAutoplayAnimation( v.seatID , true)
            end
        end 

        print("data.lordSeatID = "..data.lordSeatId)
        print("data.roomState = "..data.lordSeatId)
        if data.lordSeatId >= 0 then
            if data.roomState == UIGameTableMatch.ROOM_STATE_DOUBLE or      --等待加倍           --|__________________________
            data.roomState == UIGameTableMatch.ROOM_STATE_PLAYING  then     --房间正在游戏(出牌) --|  [这俩状态地主已经确定了]
                self:setLord(data.lordSeatId) 
                self['Text_roomType']:setVisible(false)
                self['Panel_title']:getChildByName('Image_291'):setVisible(false)
            end
            self.lordSeatID = data.lordSeatId 
        end
        if data.lastPlayerSeatID then
            self.lastSentCards = data.lastPlayerCards
            self.lastPlayedCardsType = Cardutl.TypeConvert[data.lastPlayerCardType] 
            self.lastPlayedCards = data.lastPlayerCards
            self:setPlayedCards(data.lastPlayerSeatID ,data.lastPlayerCards)
        end 
        if data.currentSeat == self.mySeatID   then 
           self:showButtonsByRoomStatus(self.currentRoomState)
        end 
        self:startPlayerCountdownBySeatID(data.currentSeat,data.outTimeOut)

        if data.lordCards then
            self:showLordCards(data.lordCards)
        end
        if data.roomState ~= UIGameTableMatch.ROOM_STATE_IDLE then
            self['Image_waitingOutOff']:setVisible(false)
            self['Panel_goOnGame']:setVisible(false)
            self['Image_waitingTable']:setVisible(false)
            self['Text_roomType']:setVisible(false)
            self['Panel_title']:getChildByName('Image_291'):setVisible(false)
        end
    end

    self:setupAllPlayers() 
    if data and data.roomState == UIGameTableMatch.ROOM_STATE_PLAYING then
        self['Image_status_1']:setVisible(false)
        self['Image_status_2']:setVisible(false)
        self['Image_status_3']:setVisible(false)
    end    
end



function UIGameTableMatch:TCP_MESSAGE_POPUP(data)
    LuaTools.stopWaiting()
    if data.msgType == 4 then
        self['Image_waitingTable']:setVisible(false)
        self['Image_waitingOutOff']:setVisible(true)
    else
        GameTableCommon.showMsgByMsgType(self,data.msgType,data.msg,data)
    end
end


function UIGameTableMatch:TCP_HEARTBEAT(data)
end

function UIGameTableMatch:TCP_onConnected()
    --默认 斗地主 然后房间传-1 服务器分配
    if G_LOADINGVIEW then
        G_LOADINGVIEW:removeSelf()
        G_LOADINGVIEW = nil
    end
    local buffer = self:getLoginBuffer()
    self.tcpGear:sendData(buffer) 

        self:REQ_heartbeat() 
    self:scheduleHeartbeat()
end


function UIGameTableMatch:REQ_TABLE_DISCONNECT() 
    local bufferHnd = DataPacker.new(self.CMD['TABLE_DISCONNECT'])   
    self.tcpGear:sendData(bufferHnd:doPack())
end

function UIGameTableMatch:REQ_KICK_PLAYER( uid ) 

    local player = GameTableCommon.getPlayerByUid(self, uid )
    local bufferHnd = DataPacker.new(self.CMD['USER_KICK'])   
    bufferHnd:writeData(player.seatID,DataPacker.BYTE) 
    self.tcpGear:sendData(bufferHnd:doPack()) 
end


function UIGameTableMatch:REQ_FRIENDREQUEST(toUID ) 
    local player = GameTableCommon.getPlayerByUid(self, toUID )
    local bufferHnd = DataPacker.new(self.CMD['FRIEND_REQUEST'])   
    bufferHnd:writeData(player.seatID,DataPacker.BYTE) 
    self.tcpGear:sendData(bufferHnd:doPack()) 
end

function UIGameTableMatch:REQ_FRIENDREQUEST_RESULT(uid,res )  
    local bufferHnd = DataPacker.new(self.CMD['ACCEPT_OR_DENY'])   
    bufferHnd:writeData(uid,DataPacker.INT) 
    bufferHnd:writeData(res,DataPacker.BYTE) 
    self.tcpGear:sendData(bufferHnd:doPack()) 

end



function UIGameTableMatch:REQ_SENDGIFT(toSeatID, giftID ) 
    local bufferHnd = DataPacker.new(self.CMD['SEND_GIFT'])   
    bufferHnd:writeData(giftID,DataPacker.BYTE)
    bufferHnd:writeData(toSeatID,DataPacker.BYTE)
    self.tcpGear:sendData(bufferHnd:doPack()) 
end

function UIGameTableMatch:REQ_CHAT(str)   
    local bufferHnd = DataPacker.new(self.CMD['CHAT'])   
    bufferHnd:writeData(str,DataPacker.STRING)
    self.tcpGear:sendData(bufferHnd:doPack())
end

function UIGameTableMatch:REQ_CHAT_TEXT_CONSTANCE(tbl)
    local bufferHnd = DataPacker.new(self.CMD['CHAT_TEXT_CONSTANCE'])   
    bufferHnd:writeData(tbl.msgType,DataPacker.BYTE)
    bufferHnd:writeData(tbl.msg,DataPacker.BYTE)
    self.tcpGear:sendData(bufferHnd:doPack()) 

end
 




function UIGameTableMatch:CHAT_TEXT_CONSTANCE(tbl)  
    local bufferHnd = DataPacker.new(self.CMD['CHAT_TEXT_CONSTANCE'])   
    bufferHnd:writeData(tbl.msgType,DataPacker.BYTE) 
    bufferHnd:writeData(tbl.msg,DataPacker.BYTE)
    self.tcpGear:sendData(bufferHnd:doPack())
end

function UIGameTableMatch:REQ_heartbeat()  
    if self.heartBeatBuffer == nil then 
        local bufferHnd = DataPacker.new(UIGameTableMatch.CMD['HEARTBEAT'])
        self.heartBeatBuffer = bufferHnd:doPack()
    end
    self.tcpGear:sendData(self.heartBeatBuffer) 
end

function UIGameTableMatch:TCP_CMDB_HEARTBEAT(data)
end

function UIGameTableMatch:scheduleHeartbeat()
    self:stopSchedule('heartbeat')
    self:createSchedule('heartbeat', function()   
        self:REQ_heartbeat() 
    end,20)  
end

function UIGameTableMatch:getPortByTableID(tableID)
    for k,v in pairs(TCPGearbox.serverConfig.config.sites.site) do 
        if tonumber(v.siteid) == tonumber(tableID) then 
            return v
        end
    end
    -- body
end

function UIGameTableMatch:automodeCalback()
    self:PlayerCtrl_setAutoplay()
end


function UIGameTableMatch:getLoginBuffer() 
    -- self.matchID = 1
    -- self.matchType = 1
    print("self.matchID = "..self.matchID)
    print("self.matchType = "..self.matchType)
    local bufferHnd = DataPacker.new(UIGameTableMatch.CMD['TABLE_LOGIN'])
    bufferHnd:writeData(G_UID,DataPacker.INT)
    bufferHnd:writeData(G_TOKEN,DataPacker.STRING)
    bufferHnd:writeData(self.matchType,DataPacker.INT)
    bufferHnd:writeData(self.matchID,DataPacker.INT)
    return bufferHnd:doPack()
 end

--[==[-------------------END OF TCP FUNCTIONS ---------------------]==]

function UIGameTableMatch:onCreate(info,types,time,sb)
    dump(info,"UIGameTableMatch:onCreate")
    print("types = "..types)
    local allText = {
        "金币赛",
        "话费赛",
        "大奖赛"
    }
    self['Text_roomType']:setString(allText[types])
    self['Image_3']:setVisible(false)
    self['BitmapFontLabel_nowNumber']:setVisible(false)

    self.globalMultiply = 2
    argTable = argTable or {} 
    self.tableType  =  -1
    self.friendID   =  -1
    self.RoomId     =  -1
    self.RoomLevel  =  5
    self.isFirstLoginReady = true 
    self.isGameTableMatch = true 
    self.restTime = time 
    self.AllMatchInfo = info 
    self.matchID = info.Id 
    self.matchType = types 
    self.isRoundOver = true
    self.ticketKind = {'门票','门票','门票','门票','门票'} 
    if sb then sb() end 
    self.handCardLayer = self['Panel_cardlayout']
    self['Panel_cardlayout'].zorder = self['Panel_cardlayout']:getLocalZOrder()
    self.handCardTable = {}
    self:setupCardSelection()
    self.currentPlayerSeatID = nil
    self.lordSeatID = -1
    self.currentRoomState = UIGameTableMatch.ROOM_STATE_IDLE 
    self['LoadingBar_3']:setPercent(0)
    local par = self['Panel_']
    par:setVisible(false)
    self['AtlasLabel_nowPlayerNumber']:setVisible(false)
    self['AtlasLabel_totalNumber']:setVisible(false)

    self.PlayerData = G_BASEAPP:getData('PlayerData')
    self.config     = G_BASEAPP:getData('Config')

    local unpackerType = DataUnpacker.Type.MATCH_GAME
    local tableName = 'UIGameTableMatch TCP'
    
    self.isGameMatch = true 
    self.taskGameType = 1

    -- if  not G_BASEAPP:getView('UIGameTableMenu')  then 
    --       G_BASEAPP:addView('UIGameTableMenu',self:getLocalZOrder()+20,self)
    --       print('ssssssssss5555555555')
    -- end     
 
    self.tcpGear = TCPGearbox.buildInstance({
            unpackerType = unpackerType, 
            delegate = self,  
            callbackPrefix = "TCP_",
            name = tableName,
            port = info.port 
        })

    GameTableCommon.setupBasics( self ) 
    self:setButtonSoundStatus()

    -- if self.PlayerData.isfirstLoginShow == 1 then 
    --    self['Panel_firstLoginShow']:setVisible(true)
    -- end     


    local function recruFunc()  
        self:addGobackEventAction(function() recruFunc() end) 
    end
    self:addGobackEventAction(function()
        recruFunc() 
    end)
end

function UIGameTableMatch:setButtonSoundStatus()
    self["Button_pass"]:setDontPlayDefaultSFX(true)
    self["Button_hint"]:setDontPlayDefaultSFX(true)
    self["Button_reset"]:setDontPlayDefaultSFX(true)
    self["Button_playcard"]:setDontPlayDefaultSFX(true)
    self["Button_wantlord"]:setDontPlayDefaultSFX(true)
    self["Button_dont_wantlord"]:setDontPlayDefaultSFX(true)
    self["Button_doublebet"]:setDontPlayDefaultSFX(true)
    self["Button_dont_doublebet"]:setDontPlayDefaultSFX(true)
    self["Button_dont_grab_lord"]:setDontPlayDefaultSFX(true)
    self["Button_grab_lord"]:setDontPlayDefaultSFX(true)
    self["Button_dont_call_lord"]:setDontPlayDefaultSFX(true)
    self["Button_call_lord"]:setDontPlayDefaultSFX(true)
end

function UIGameTableMatch:updateMyAccu(accu)
    self['AtlasLabel_myCoins']:setString(LuaTools.convertAmountChinese(accu,10000))
end 

---------------------------------------------------------------------------

return UIGameTableMatch
