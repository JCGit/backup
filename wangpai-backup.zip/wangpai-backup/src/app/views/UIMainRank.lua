local UIMainRank = class("UIMainRank", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
UIMainRank.RESOURCE_FILENAME = "UIMainRank.csb"
--UIMainRank.RESOURCE_PRELOADING = {"main.png"}
--UIMainRank.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIMainRank.RESOURCE_BINDING = { 
     ["Button_closeRank"]   = {["ended"] = "onOpenCloseView"},
     ["Button_openRank"]   = {["ended"] = "onOpenCloseView"},
    } 

local MAX_PAGES = 50   --最大只请求5页
local ONE_PAGE = 10   --一页为10个数据
local OPEN_CLOSE_VIEW_DURATION = 0.4  --打开/关闭窗口时间
local ITEMCOUNT_ACTION = 4    --每一页的前4个items会执行动作
local spritePlist = nil
--初始化
function UIMainRank:onCreate()
    local app = self:getApp()
    self.app = app
    self.pData = app:getData('PlayerData')
    self.tool = app:getModel('Tools')
    self.config = app:getData('Config')
    spritePlist = cc.SpriteFrameCache:getInstance():addSpriteFrames("common.plist")

    self.winSize = cc.Director:getInstance():getWinSize()
    self.isViewOpen = false
    self.btSelected = nil
    self.indexPage = 1
    self.indexRank = 1
    self.lastIndexRank = -1
    self.mainListView = self['ListView_rank']
    self.defaultItem = self['Panel_Item']
    self['Panel_rank']:setBackGroundColorOpacity(0)
    self['Button_closeRank']:setPressedActionEnabled(false)
    
    self.panelDefaultPosX = self['Panel_rank']:getPositionX()

    self.textureCrown = {'res_lobby/main_gold_crown.png', 'res_lobby/main_silver_crown.png', 'res_lobby/main_bronze_crown.png'}
    self.textureRank = {'res_lobby/champion_icon.png', 'res_lobby/second_icon.png', 'res_lobby/third_icon.png'}
    self.btList = {'Panel_btCharm', 'Panel_btFortune'}

    --1.魅力值旁  2.财富旁
    self.ranks = {self.pData.MainRanks[1], self.pData.MainRanks[2]}

    self:init()

  --self:updateListViewForView(self.ranks[1])
end

--控制整个大厅的点击事件
function UIMainRank:setTouchState(_enable)
  self['Panel_TouchControl']:setTouchEnabled(_enable)
end

--进入大厅动作
function UIMainRank:showEnterActions()
    local moveTop = cc.MoveTo:create(0.5, cc.p(0,self["Button_openRank"]:getPositionY()))
    self["Button_openRank"]:runAction(moveTop)
    --self['Panel_rank']:setPositionX(self.panelDefaultPosX)
end

--退出大厅动作
function UIMainRank:showExitActions()
  if self.isViewOpen == false then
    local moveTop = cc.MoveTo:create(0.5, cc.p(-100,self["Button_openRank"]:getPositionY()))
    self["Button_openRank"]:runAction(moveTop)
  else
    local closeAction = cc.MoveTo:create(0.2,cc.p(-self['Panel_rank']:getContentSize().width - 60,self['Panel_rank']:getPositionY()))
    --local move_ease_in = cc.EaseBackIn:create(closeAction)
    self['Panel_rank']:runAction(closeAction)
    self.isViewOpen = false
  end
end

--执行排行榜items的动作
function UIMainRank:showListviewEnterActions()
        --listview items actions
    self.mainListView:setTouchEnabled(false)
    local function moveBackAfter(delay, byY)
        local backVal = 30
        if byY < 0 then
            backVal = -backVal
        end
         local moveIn = cc.MoveBy:create(delay,cc.p(0,byY+backVal))
         local moveOff = cc.MoveBy:create(0.2,cc.p(0,-backVal))
         return cc.Sequence:create(moveIn, moveOff)
    end
    if self.mainListView:getChildrenCount() == 0 then return end
    for i = 0, ITEMCOUNT_ACTION-1 do
        local item = self.mainListView:getItem(i)
       -- local moveIn = cc.MoveBy:create(0.3,cc.p(0,400))
        --local move_ease_in = cc.EaseBackOut:create(moveIn)
       -- item:runAction(cc.Sequence:create(cc.DelayTime:create(0.1+(0.1*i)),move_ease_in,nil))
        item:runAction(cc.Sequence:create(cc.DelayTime:create(0.1+(0.1*i)),moveBackAfter(0.2,400),nil))
    end
    self:runAction(cc.Sequence:create(
      cc.DelayTime:create(1),
      cc.CallFunc:create(function() self.mainListView:setTouchEnabled(true) end)
      ,nil))
end

--初始化UI
function UIMainRank:init()
    self:initSwitchButtons()
    local function onScrolled(event)
        if event.name == "BOUNCE_BOTTOM" then
            if (#self.ranks[self.indexRank] < ONE_PAGE*self.indexPage) or (ONE_PAGE*self.indexPage == MAX_PAGES) then
                --print("Rank index: "..self.indexRank..'  Size array: '..#self.ranks[self.indexRank].." Page index: "..self.indexPage)
                return
            end
            self.mainListView:setTouchEnabled(false)
            self.mainListView:setBounceEnabled(false)
            print(#self.ranks[self.indexRank] )
            print('EXPENDING PAGE...')
            self.indexPage = self.indexPage + 1
            self:requestGetRank(self.indexRank, self.indexPage, true)
        end
    end
    self.mainListView:onScroll(onScrolled)
    self.mainListView:setItemModel(self.defaultItem)
    --self.mainListView:setBounceEnabled(false) 
    self.defaultItem:setVisible(false)
    self.defaultItem:setBackGroundColorOpacity(0)
end

--更新UI色彩
function UIMainRank:updateFrameColor(_color)
    self.colorBgd = _color
    self['Image_mainBg']:setColor(_color)
    --self['Button_rank']:setColor(_color)
    self['Panel_btCharm']:getChildByName('Image_bgUnselect'):setColor(_color)
    self['Panel_btFortune']:getChildByName('Image_bgUnselect'):setColor(_color)
    self:updateItemsbgdColor()
end

--更新Items色彩
function UIMainRank:updateItemsbgdColor()
  for i,item in ipairs(self.mainListView:getChildren()) do
      item:getChildByName('Image_bg'):setColor(self.colorBgd)
    end
end

--更新VIP框
function UIMainRank:updateVipBorder(dayleft, target)
    local texture
    local vday = tonumber(dayleft)
    if vday <= 7 then
        texture = self.config.vipBorder.bronze
    elseif vday > 7 and vday <= 31 then 
        texture = self.config.vipBorder.silver
    elseif  vday > 31 then
        texture = self.config.vipBorder.gold
    end 
    print("TEXTURE: "..texture)
    target:loadTexture(texture,ccui.TextureResType.plistType)
end

--
function UIMainRank:updateListViewForView(_array)
  local function onSelectItem(event)
    if event.name == 'ended' then
       local uid = event.target:getTag()
       local tab = {} 
       tab.uid = uid 
       tab.tag = 3
       self.app:addView('UIFriendBrief',self:getLocalZOrder() + 10,tab)
    end
  end
  for i,data in pairs(_array) do
      self.mainListView:pushBackDefaultItem()
      local childCount = self.mainListView:getChildrenCount()
      local item = self.mainListView:getItem(childCount-1)
      item:setTag(data.uid)
      item:onTouch(onSelectItem)
      item:setTouchEnabled(true)
      local viewHead = item:getChildByName('Panel_head')
      local viewDesc = item:getChildByName('Panel_description')
      --viewHead:getChildByName('Image_head')
      local img_vip = viewHead:getChildByName('Text_viplevel')
      local img_vipbgd = viewHead:getChildByName('Image_UserVipBgd')
      viewHead:getChildByName('Image_border'):setLocalZOrder(2)
      img_vip:setLocalZOrder(3)
      img_vipbgd:setLocalZOrder(2)
      if tonumber(data.vipLevel) > 0 then
         img_vip:setString("V"..data.vipLevel)
         img_vipbgd:setVisible(true)
         self:updateVipBorder(data.vipvalid ,img_vipbgd)
      else
         img_vip:setVisible(false)
         img_vipbgd:setVisible(false)
      end
      
      local imgRanking = viewDesc:getChildByName('Image_ranking')
      if childCount < 4 then
        imgRanking:loadTexture(self.textureRank[i], ccui.TextureResType.plistType)
        viewDesc:getChildByName('AtlasLabel_num'):setVisible(false)
      else
        imgRanking:setVisible(false)
        viewDesc:getChildByName('AtlasLabel_num'):setString(data.rank)
      end
      
      --viewDesc:getChildByName('Text_name'):setString(data.name)

      local textName = viewDesc:getChildByName('Text_name')
      local textModel =  "一二三四五六"
      LuaTools.cropLabel(textModel, data.name, textName)

      viewDesc:getChildByName('Text_value'):setString(LuaTools.convertAmountChinese(tonumber(data.score)))
      --viewHead:getChildByName('Image_gift'):
      local imgHead = viewHead:getChildByName('Image_head')
      local newHeadSpr = nil
      local spr = nil
      local newName = data.avatar
      print("TEXUURE SEX: "..data.sex)
      if #data.avatar > 1  then
          local argTable = {
              url = data.avatar,
              destFile = (newName:gsub("/","_")),
              --useCache = false,
              onFinishTable = function(status,downloadedSize,dst)
              if status == 'success' then
                  print('Avartar Found: '..dst)
                  newHeadSpr = cc.Sprite:create(dst)
              else
                  print('获取头像失败1 !')
                  newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[data.sex+1])
              end
              spr = LuaTools.makeSpriteRounded(newHeadSpr, imgHead, self.config.maskSprite, false)
              end
          }
          print('url: '..argTable.url)
          LuaTools.getFileFromUrl(argTable)  
      else

          newHeadSpr = cc.Sprite:createWithSpriteFrameName(self.config.defaultHeadTexture[data.sex+1])
          spr = LuaTools.makeSpriteRounded(newHeadSpr, imgHead, self.config.maskSprite, false)
      end
      if childCount < ITEMCOUNT_ACTION+1 then 
      item:runAction(cc.Sequence:create(
         cc.MoveBy:create(0.1,cc.p(0,-400)),
         cc.CallFunc:create(function() item:setVisible(true) end)
         ,nil))
      else
         item:setVisible(true)
      end
  end

  if self.lastIndexRank ~= self.indexRank then
    self:showListviewEnterActions()
    self.lastIndexRank = self.indexRank
  end
  --self:updateItemsbgdColor()
end

function UIMainRank:initSwitchButtons( )
    local function onSwithRankView(event)
      if event.name == 'ended' then
        local bt = event.target
        local index = bt:getTag()
        if self.lastIndexRank == index then
          return
        end
        self:showRankButton(bt)
        self.mainListView:removeAllChildren()
        self.mainListView:jumpToTop()
        self.indexRank = index
        if #self.ranks[index] > 0 then
          self:updateListViewForView(self.ranks[index])
          self.indexPage = math.ceil(#self.ranks[index]/10)
          print("ACTUAL INDEXPAGE: "..self.indexPage)
        else
          self:requestGetRank(index, 1, false) 
        end
        --self:updateListViewForView(self.ranks[bt:getTag()])
      end
    end
    for i,name in ipairs(self.btList) do
         self[name]:setTouchEnabled(true)
         self[name]:onTouch(onSwithRankView)
         self[name]:setTag(i)
         self[name]:getChildByName('Image_bgSelect'):setVisible(false)
         --self[name]:getChildByName('Image_bgUnselect'):setVisible(true)
    end
    
    self:showRankButton(self['Panel_btCharm'])
end

function UIMainRank:resetView() 
   --self.btSelected = nil
   local bts = {self['Panel_btCharm'], self['Panel_btFortune']}
   self:showRankButton(bts[self.indexRank])
  -- self:initSwitchButtons()
end

function UIMainRank:showRankButton(_bt)
    if self.btSelected and self.btSelected == _bt then
       return
    end
    if self.btSelected then 
      self.btSelected:getChildByName('Image_bgSelect'):setVisible(false)
    --  self.btSelected:getChildByName('Image_bgUnselect'):setVisible(true)
    end
    _bt:getChildByName('Image_bgSelect'):setVisible(true)
    --_bt:getChildByName('Image_bgUnselect'):setVisible(false)
    self.btSelected = _bt
end

function UIMainRank:setBtEnabled(_en)
  self['Button_closeRank']:setTouchEnabled(_en)
  self['Button_openRank']:setTouchEnabled(_en)
end

function UIMainRank:onOpenCloseView()
  btRank = self['Button_openRank']
  pRank = self['Panel_rank']
  if self.isViewOpen == false then
    local function cb()
	  --[[if spritePlist == nil then
		spritePlist = cc.SpriteFrameCache:getInstance():addSpriteFrames("common.plist")
	  end]]
      self:setBtEnabled(true)
      dump(self.ranks[self.indexRank], "IndexRank: "..self.indexRank)
      if self.ranks[self.indexRank] ~= nil and #self.ranks[self.indexRank] > 0 then
        --self.mainListView:removeAllChildren()
        if self.mainListView:getChildrenCount() == 0 then 
          self:updateListViewForView(self.ranks[self.indexRank])
          self.indexPage = math.ceil(#self.ranks[self.indexRank]/10)
          print("ACTUAL INDEXPAGE: "..self.indexPage)
        else
          
        end
      else
        self:requestGetRank(self.indexRank, 1, false)
      end
    end

    local moveIn = cc.MoveTo:create(OPEN_CLOSE_VIEW_DURATION-0.3,cc.p(-btRank:getContentSize().width - 60,btRank:getPositionY()))
    local move_ease_in = cc.EaseBackIn:create(moveIn)
    btRank:runAction(move_ease_in)

    local openAction = cc.MoveTo:create(OPEN_CLOSE_VIEW_DURATION,cc.p(25,pRank:getPositionY()))
    local move_ease_out = cc.EaseBackOut:create(openAction)
    local seq = cc.Sequence:create(move_ease_out,cc.CallFunc:create(cb),nil)
    pRank:runAction(seq)

    self:setBtEnabled(false)
    self.isViewOpen = true
	
	--[[apk下载
	
	if tonumber(G_UPDATEINFO.baseupdate.vername) > tonumber(VERNAME) then
		if G_UPDATEINFO.baseupdate.isForce == 1 then
			--强行更新
		else
			--非强行更新
		end
		local numRead = 0;
		LuaTools.getOpenFile(function(data) 
				local data = json.decode(data)
				if data.type == 0 then
					--下载结束
				elseif data.type == 1 then
					numRead = tonumber(numRead) + tonumber(data.numRead)
					print("@@@@@@@@@@@@@@@@@@")
					print("下载进度"..(numRead))
					print("@@@@@@@@@@@@@@@@@@")
				elseif data.type == -1 then
					--下载失败
				end
			end,G_UPDATEINFO.baseupdate.apk)
		
	end
	]]
	
  else
	--[[if spritePlist ~= nil then
		cc.SpriteFrameCache:getInstance():removeSpriteFramesFromFile("common.plist")
		spritePlist = nil
	end
]]
    local moveout = cc.MoveTo:create(OPEN_CLOSE_VIEW_DURATION-0.2,cc.p(0,btRank:getPositionY()))
   -- local move_ease_out = cc.EaseBackOut:create(moveout)
    local seq = cc.Sequence:create(cc.DelayTime:create(0.3),moveout, nil)
    btRank:runAction(seq)

    local closeAction = cc.MoveTo:create(OPEN_CLOSE_VIEW_DURATION,cc.p(-pRank:getContentSize().width - 60,pRank:getPositionY()))
    local move_ease_in = cc.EaseBackIn:create(closeAction)
    pRank:runAction(cc.Sequence:create(move_ease_in, cc.CallFunc:create(function()
          self:resetView() 
          self:setBtEnabled(true)
      end), nil))

    self:setBtEnabled(false)
    self.isViewOpen = false
	
  end
   
end

function UIMainRank:updateRankData(listData, data)
    for key = 1 ,#data.list do   
        local argTabl = {}
        local v = data.list[key]
        argTabl.rank      = key + ((self.indexPage-1)*10)
        argTabl.uid       = v.uid or ""
        argTabl.name      = v.name or ""
        argTabl.avatar    = v.icon or ""
        argTabl.score     = v.money or 0
        argTabl.vipLevel  = v.vip_level or 0
        argTabl.vipType   = v.vip_type or 0
        argTabl.vipDate   = v.vip_day or 0
        argTabl.vipvalid  = v.vipvalid or 0
        argTabl.status    = v.status or 0
        argTabl.sex       = v.sex or 0
        table.insert(listData, argTabl)
    end
   -- dump(listData)
end

--扩展listview的元素
function UIMainRank:appendRanksContent(_data) 
    self:updateRankData(self.ranks[self.indexRank], _data)
    local newData = {}
    self:updateRankData(newData, _data)
    self:updateListViewForView(newData)
end

function UIMainRank:parseRanksData(_data)
    self:updateRankData(self.ranks[self.indexRank],_data)
    self:updateListViewForView(self.ranks[self.indexRank])
end

--请求排行榜数据
function UIMainRank:requestGetRank(_type, _page, _isAppend, _cb)
    local dataTable =     {
        ['uid']    = tonumber(self.pData.uid),
            ['type']   = _type,
            ['date']   = os.time(),
            ['page']   = _page,
            ['token']  = G_TOKEN,
            ['cmd']    = HttpHandler.CMDTABLE.GET_RANKS
    }
    local function succ(arg)
        if arg.result == 1 then 
          self.tool:showTips(arg.msg)
          return
        end
        if _isAppend == false then
            self.indexPage = 1
            self.indexRank = _type
            self.ranks[self.indexRank] = { }
            self.mainListView:removeAllChildren()
            self:parseRanksData(arg)
        else
            local tzize = #self.ranks[self.indexRank]
            self.indexPage = _page
            self:appendRanksContent(arg)
            if MAX_PAGES > tzize then
               self.mainListView:jumpToItem((self.indexPage-1)*ONE_PAGE-1, cc.p(0,0), cc.p(0,0))
            end
            self.mainListView:setBounceEnabled(true)
            self.mainListView:setTouchEnabled(true)
        end
        if _cb then _cb() end
    end
    
    local function fail(arg)
        self.tool:showTips(arg.msg)
    end
    
    self.tool:fastRequest(dataTable,succ)
end

return UIMainRank
