local UIBroadcast = class("UIBroadcast", cc.load("mvc").ViewBase)

UIBroadcast.RESOURCE_FILENAME = "UIBroadcast.csb"
--UIBroadcast.RESOURCE_PRELOADING = {"main.png"}
--UIBroadcast.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIBroadcast.RESOURCE_BINDING = { 

    } 

--初始化
function UIBroadcast:onCreate(_playAction)
    local app = self:getApp()
    self.app = app
    self.tool = app:getModel('Tools')
    self.config = app:getData('Config')
    self.pData = self.app:getData('PlayerData') 
    self:setSkipGoBack(true )
    self["Panel_main"]:setBackGroundColorOpacity(0)
    self:initBroadcastUI()
    self['Panel_bgd']:setVisible(false)
    --self:initAnimations()
    table.insert(self.pData.braodCastObject, self)
    self.outOfViewPositionY = self["Panel_main"]:getPositionY()
    if _playAction == nil then
        local moveIn = cc.MoveTo:create(0.1, cc.p(0,585))
        self["Panel_main"]:runAction(moveIn)
    end
end

--进入此界面动作
function UIBroadcast:showEnterActions()
    local moveIn = cc.MoveTo:create(0.4, cc.p(0,585))
    self["Panel_main"]:runAction(moveIn)
end

function UIBroadcast:showOrHide(tag)
    self['Panel_chat']:setVisible(tag)
end     

--退出动作
function UIBroadcast:showExitActions()
    local moveOut = cc.MoveTo:create(0.4, cc.p(0,self.outOfViewPositionY))
    self["Panel_main"]:runAction(moveOut)
end

function UIBroadcast:onExit()
    --printf('Removing userdata: %s',self.pData.braodCastObject[#self.pData.braodCastObject])
    --table.remove(self.pData.braodCastObject, #self.pData.braodCastObject)
end

--初始化广播UI
function UIBroadcast:initBroadcastUI()
    local function onEnterChat(event)
        if event.name == 'ended' then 
            self.app:addView('UIChat',self:getLocalZOrder() + 20, false) 
        end  
    end
    self['Text_broad']:setVisible(false)
    self['Panel_LimitB']:setEnabled(false)
    self['Panel_LimitB']:setTouchEnabled(false)
    self['Panel_chat']:setTouchEnabled(true)
    self['Panel_chat']:onTouch(onEnterChat)
    self['Panel_horn']:onTouch(onEnterChat)
end

--初始化动画
function UIBroadcast:initAnimations()
    local panelHorn = self['Panel_horn']
    local animHorn = cc.CSLoader:createNode('Animation_laba.csb') 
    animHorn:setPosition(cc.p(panelHorn:getContentSize().width/2,panelHorn:getContentSize().height/2))
    local action = cc.CSLoader:createTimeline('Animation_laba.csb')
    animHorn:runAction(action)
    action:gotoFrameAndPlay(0,true)
    panelHorn:addChild(animHorn,4)
end

--开始广播
--@params: 1.内容  2.cc.c3b颜色
function UIBroadcast:startBroadcast(_string, _color) 
    print('BEGIN BROADCAST: '.._string)
    local limit = self['Panel_LimitB']
    local text = self['Text_broad']
    local copyText = self['Text_broadNext']
    local limitWidth = limit:getContentSize().width
    local textWidth = 0
    text:setColor(_color)
    copyText:setColor(_color)
    text:stopAllActions()
    copyText:stopAllActions()
    copyText:setVisible(false)
    copyText:setString(_string) 
    text:setVisible(true)
    text:setString(_string) 
    text:setPositionX(limitWidth/2) 
    text:setPositionY(limit:getContentSize().height/2)
    textWidth = text:getLayoutSize().width
    --print('Text Broadcast size: '..textWidth..'   limit view size: '..limitWidth)
    if textWidth > limitWidth then  --如果广播的内容大于广播的区域，执行广播滚动
        local perLimit = 70/100   --main text reach this percentage of limit width before copy text begin
        local function moveByStart()
            local function moveNextText()
                local moveBy = cc.MoveBy:create(self.config.broadcastTime*2, cc.p(-limitWidth, 0))
                copyText:setPositionX(limitWidth + copyText:getContentSize().width/2)
                copyText:setVisible(true)
                copyText:runAction(cc.Sequence:create(moveBy, cc.DelayTime:create(1.5), cc.CallFunc:create(moveByStart), nil)) --再次循环
            end
             copyText:setVisible(false)
             text:setPositionX(limitWidth/2 + (textWidth-limitWidth)/2)      
             local movePart_1 = cc.MoveBy:create(self.config.broadcastTime*2*(textWidth-limitWidth*perLimit)/limitWidth, cc.p(-(textWidth-limitWidth*perLimit), 0))
             local movePart_2 = cc.MoveBy:create(self.config.broadcastTime*2*(textWidth-limitWidth*(1-perLimit))/limitWidth, cc.p(-(textWidth-limitWidth*(1-perLimit)), 0))
             text:runAction(cc.Sequence:create(movePart_1, cc.CallFunc:create(moveNextText), movePart_2, nil))
        end
        moveByStart()            
    else
        text:setPositionX(limitWidth/2)
    end
end


return UIBroadcast
