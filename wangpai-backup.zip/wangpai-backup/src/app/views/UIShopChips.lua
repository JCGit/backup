local UIShopChips = class("UIShopChips", cc.load("mvc").ViewBase)
local HttpHandler = require("app.network.HttpHandler")
UIShopChips.RESOURCE_FILENAME = "UIShopChips.csb"
--UIShopCoin.RESOURCE_PRELOADING = {"main.png"}
--UIShopCoin.RESOURCE_LOADING  = {["res/background/main_bg.png"] = {names = {"Image_bg"}}}

UIShopChips.RESOURCE_BINDING = {



}
local NUMBER_ITEM_PER_ROW = 4

--初始化
function UIShopChips:onCreate()
    local app = self:getApp()
    self:setSkipGoBack(true )
    self.app = app
    self.tool = app:getModel('Tools')
    self.pData = self.app:getData('PlayerData')
    
    self.imageChips = {'res_shop/img_coin1.png','res_shop/img_coin2.png','res_shop/img_coin3.png',
        'res_shop/img_coin4.png', 'res_shop/img_coin5.png'}
    
    self:setVisible(false)
end

function UIShopChips:getPanelMain()
    return self['Panel_main']
end

function UIShopChips:init()
    if #self.pData.shopChips == 0 then
        self:requestGetProduct()
        else
        self:initProductList()
    end
    self:setVisible(true)
end

--初始化产品
function UIShopChips:initProductList()
    local function onBuy(event)
        if event.name == 'ended' then
            
            local indexSel = event.target:getTag()
            local chips = self.pData.shopChips[indexSel].name
            local diamond = self.pData.shopChips[indexSel].price
			--友盟购买金币记录事件
			if tonumber(indexSel) <= 5 then
				local sendumeng = {}
				sendumeng['type'] = 'event'
				sendumeng['eventId'] = 'buygold_'..indexSel
				LuaTools.setUmeng(sendumeng)
			end
			
            print('I bought '..chips..' chips for '..diamond..' diamonds')
            
            self:requestBuyProduct(self.pData.shopChips[indexSel].pid,1)
        end
    end
    self.mainListView = self['ListView_Items']
    self.panelRow = self['Panel_Row']
    self.mainListView:setScrollBarEnabled(false)
    self.panelRow:setBackGroundColorOpacity(0)
    self.mainListView:setItemModel(self['Panel_Row'])

    local countRow = math.ceil(#self.pData.shopChips/NUMBER_ITEM_PER_ROW)
    local count = 1
    for i = 1, countRow do
        self.mainListView:pushBackDefaultItem()
        local row = self.mainListView:getItem(i-1)
        --row:runAction(cc.MoveBy:create(0.1,cc.p(0,-40)))
        if i == 1 then
            local ctsize = row:getContentSize()
            row:setContentSize(cc.size(ctsize.width, ctsize.height + 40))
        end
        for j = 1, NUMBER_ITEM_PER_ROW do
            local item = row:getChildByName('Panel_Item_'..j)
            if count > #self.pData.shopChips then 
                item:setVisible(false)
            else
                item:setBackGroundColorOpacity(0)
                local var = self.pData.shopChips[count]
                
                local img 
                if count > #self.imageChips then
                    img = self.imageChips[#self.imageChips]
                else
                    img = self.imageChips[count]
                end
                item:getChildByName('Image_chips'):loadTexture(img, ccui.TextureResType.plistType)
                local panelbt = item:getChildByName('Panel_button')
                panelbt:getChildByName('Text_price'):setString(var.price)
                local bt =  panelbt:getChildByName('Button_buy')
                bt:onTouch(onBuy)
                bt:setTag(count)
                local isHot = false
                if var.hot == 1 then isHot = true end
                item:getChildByName('Image_hot'):setVisible(isHot)

                if var.rate > 0 then
                    item:getChildByName('Text_desc'):setString('')--('多送'..(var.rate*100)..'%')
                    item:getChildByName('Image_desc'):setVisible(false)
                    item:getChildByName('AtlasLabel_chipsCount'):setString(var.coin)
                else
                    
                    item:getChildByName('Text_desc'):setVisible(false)
                    item:getChildByName('Image_desc'):setVisible(false)
                    item:getChildByName('AtlasLabel_chipsCount'):setString(var.coin)
                end
            end
            count = count + 1
        end
    end

end

--拷贝数据（可避免）
function UIShopChips:parseProductData(data)
    self.pData.shopChips = { --desc, name, pid, price, coins, rate, hot
        }

    for k, v in ipairs(data.products) do
        local subList = {}
        subList.desc = v.description
        subList.name = v.name
        subList.pid = v.pid 
        subList.price = v.price
        subList.coin = v.coins
        subList.rate = v.rate
        subList.hot = v.hot
        self.pData.shopChips[k] = subList
    end
    dump(self.pData.shopChips)
    self:initProductList()
end

--请求获取产品列表
function UIShopChips:requestGetProduct()
    local dataTable =     {
        ['uid']     = self.pData.uid,
        ['token']   = self.pData.token,
        ['cid']     = 1,
        ['ver']     = 1,
        ['cmd']       = HttpHandler.CMDTABLE.GET_PRODUCT,
    }
    local function succ(arg)
        self:parseProductData(arg)
    end
    local function fail(arg)
        if arg.msg then
            self.tool:showAlert(arg.msg)
        end
    end
    self.tool:fastRequest(dataTable,succ, fail)
end

--请求购买金币
function UIShopChips:requestBuyProduct(pid, num)
    local dataTable =     {
        ['uid']   = self.pData.uid,
        ['token']  = self.pData.token,
        ['pid']      = pid,
        ['number']    = num,
        ['cmd']       = HttpHandler.CMDTABLE.BUY_PRODUCT,
    }
    local function succ(arg)
        self.pData.coin = tonumber(arg.coin) or 0
        self.pData.gem = tonumber(arg.gem) or 0
        self.tool:showAlert(arg.msg)
        self.app:callMethod('UIShop','updateContent')
    end
    local function fail(arg)
        if arg.msg then
            self.tool:showAlert(arg.msg)
            -- if string.find(arg.msg,'不足') then 
            --    G_BASEAPP:addView('UIShopDiamond',self:getLocalZOrder()+1)
            -- end  
        end
    end
    self.tool:fastRequest(dataTable,succ, fail)
end

return UIShopChips
