
local UIGameTable = class("UIGameTable", cc.load("mvc").ViewBase)
--55张斗地主，54张斗地主，跑得快代码都是用这个类
----------------------------------------------------------------
local TCPConnector = require('app.network.TCPConnector')
local DataPacker = require('app.network.DataPacker')
local DataUnpacker = require('app.network.DataUnpacker')
local HttpHandler = require("app.network.HttpHandler")
local GameTableCommon = require("app.models.GameTableCommon")
local scheduler = require("app.models.QScheduler")
--printWarning
require("app.models.cardutl")
UIGameTable.CMD = DataUnpacker.CMD[DataUnpacker.Type.GAME]['REQ']
----------------------------------------------------------------

UIGameTable.RESOURCE_FILENAME = "UIGameTable.csb"
UIGameTable.RESOURCE_PRELOADING = {"game.png",'faceicon.png','card.png','friendrank.png','tableresult.png'}
UIGameTable.RESOURCE_LOADING  = {
    ["res/background/game_bg.png"]     = {names = {"Image_bg"}},
    ["res/background/game_tables.png"] = {names = {"Image_bg2"}} 
} 

UIGameTable.RESOURCE_BINDING = { 
    ["Button_pass"]   = {["ended"] = "PlayerCtrl_pass"}, 
    ["Button_hint"]   = {["ended"] = "PlayerCtrl_showHint"},--提示 
    ["Button_reset"]   = {["ended"] = "PlayerCtrl_resetSelectedCards"},--重置 
    ["Button_playcard"]   = {["ended"] = "PlayerCtrl_playCards"}, --出牌
    ["Button_readyup"]   = {["ended"] = "PlayerCtrl_readyUp"}, 
    ["Button_changeTable"]   = {["ended"] = "PlayerCtrl_changeTable"}, 


    ["Button_wantlord"]   = {["ended"] = "PlayerCtrl_wantlord"}, 
    ["Button_dont_wantlord"]   = {["ended"] = "PlayerCtrl_dont_wantlord"},


    ["Button_doublebet"]   = {["ended"] = "PlayerCtrl_doublebet"}, --双倍
    ["Button_dont_doublebet"]   = {["ended"] = "PlayerCtrl_dont_doublebet"}, --不双倍
    ["Button_calcelAutoplay"]   = {["ended"] = "PlayerCtrl_setAutoplay"}, 
    ["Button_autoplay"]   = {["ended"] = "PlayerCtrl_setAutoplay"}, 


    ["Button_dont_grab_lord"]   = {["ended"] = "PlayerCtrl_dont_grab_lord"  }, 
    ["Button_grab_lord"]        = {["ended"] = "PlayerCtrl_grab_lord"       }, 

    ["Button_dont_call_lord"]   = {["ended"] = "PlayerCtrl_dont_call_lord"  }, 
    ["Button_call_lord"]        = {["ended"] = "PlayerCtrl_call_lord"       }, 
    
 
     ["Button_firstLoginShow"]   = {["ended"] = "hideFirstLoginShow"}, 

    ["Button_back"]        = {["ended"] = "PlayerCtrl_back"       }, 
    ["Button_test"]        = {["ended"] = "PlayerCtrl_test"       }, 
    ["Button_getPackets"]  = {["ended"] = "getRedPackets"       }, 

}


UIGameTable.STATUS = {
    NONE                    = 0,
    READY                   = 1,
    PASS                    = 2,
    CALL_LORD               = 3,--叫地主
    NO_CALL_LORD            = 4,
    GRAB_LORD               = 5,--要地主
    NO_GRAB_LORD            = 6,
    DOUBLE_BET              = 13,
    DONT_DOUBLE_BET         = 14,
    DONT_WANT_TO_BE_LORD    = 15,


    GRAB_LORD    = 5,
    DONT_GRAB_LORD  = 6,
}

UIGameTable.isonEnterBackground = false
UIGameTable.onEnterForGround = false

local function invertStatusTable()
    UIGameTable.STATUS_INVERT = {}
    for k,v in pairs(UIGameTable.STATUS) do
        UIGameTable.STATUS_INVERT[v]=k 
    end
end
invertStatusTable()

UIGameTable.displayIDTable = 
{
    true,
    false,
    false,
}

UIGameTable.GameTableName = 
{
    level = 
    {
        "初级场",
        "中级场",
        "高级场",
        "大师场",
    },
    name = 
    {

        [1] = '普通场',
        [18]= '抢地主',
        [33]= '大奖赛场',
        [19]= '斗牛',
    }
}

 
UIGameTable.ARRANGE_MIDDLE = 1
UIGameTable.ARRANGE_LEFT = 2
UIGameTable.ARRANGE_RIGHT = 3

UIGameTable.BUTTON_DISABLE_COLOR = cc.c3b(125, 125, 125)
UIGameTable.BUTTON_ENABLE_COLOR = cc.c3b(255, 255, 255)

UIGameTable.TIP_NORMAL_PLAYER_TOAST = 0x30  -- 客户端Toast弹窗
UIGameTable.TIP_NORMAL_PLAYER_POP = 0x31 -- 客户端Pop弹窗


UIGameTable.PLAYER_ROLE_LORD        = 0x01  -- 地主
UIGameTable.PLAYER_ROLE_FARMER      = 0x02  -- 农民
UIGameTable.SEX_MALE        = 0x01  -- 男
UIGameTable.SEX_FEMALE      = 0x02  -- 女
UIGameTable.PLAYER_ACTION_TIMEOUT = 20  
 

UIGameTable.ROOM_STATE_IDLE = 0        --房间等待
UIGameTable.ROOM_STATE_WANT_LORD = 1   --等待要地主
UIGameTable.ROOM_STATE_DOUBLE = 2      --等待加倍
UIGameTable.ROOM_STATE_PLAYING = 3     --房间正在游戏(出牌)
UIGameTable.ROOM_STATE_CALL_LORD = 4   --等待叫地主
UIGameTable.ROOM_STATE_GRAB_LORD = 5   --等待抢地主


 UIGameTable.pickedCardsHeight = 20

function UIGameTable:PlayerCtrl_dont_grab_lord()
    self:PlayerCtrl_grabLordOrNot(0)
end


function UIGameTable:PlayerCtrl_test()
    printf('PlayerCtrl_test')
end

--退出游戏场
function UIGameTable:PlayerCtrl_back()
    -- self:quitComfirm()
   GameTableCommon.quitComfirm(self)
end

function UIGameTable:PlayerCtrl_grab_lord() 
    self:PlayerCtrl_grabLordOrNot(1)
end
 
function UIGameTable:PlayerCtrl_grabLordOrNot(grab) 
    local bufferHnd = DataPacker.new(UIGameTable.CMD['USER_GRAB_LORD'])  
    bufferHnd:writeData(grab,DataPacker.BYTE)
    self.tcpGear:sendData(bufferHnd:doPack())
    self["Button_dont_grab_lord"]:setVisible(false)
    self["Button_grab_lord"]:setVisible(false)
end


function UIGameTable:PlayerCtrl_dont_call_lord()
    self:PlayerCtrl_callLordOrNot(0)
end

function UIGameTable:PlayerCtrl_call_lord() 
    self:PlayerCtrl_callLordOrNot(1)
end

function UIGameTable:PlayerCtrl_callLordOrNot(call) 
    local bufferHnd = DataPacker.new(UIGameTable.CMD['USER_CALL_LORD'])  
    bufferHnd:writeData(call,DataPacker.BYTE)
    self.tcpGear:sendData(bufferHnd:doPack())
    self["Button_dont_call_lord"]:setVisible(false)
    self["Button_call_lord"]:setVisible(false)
end


function UIGameTable:PlayerCtrl_changeTable()
    if self.isChangeTableLockDown == true then 
        local blah = ""..cc.Director:getInstance():getTotalFrames()
        G_BASEAPP:addView({
           uiName =  'UIAlert',
           uiInstanceName = blah
            },1000)
        :setupDialog('Infomation',"更换平率过快，低于1秒限制。")
        return
    end
    self.isChangeTableLockDown = true
    self:createSchedule("changeTableLockDown",function()
        self:stopSchedule("changeTableLockDown")
        self.isChangeTableLockDown = nil
    end,1)

    if self.isPaodekuai then 
       self['Image_cardleft_3']:setVisible(false)
       self['Image_cardleft_2']:setVisible(false)
    end     

    local bufferHnd = DataPacker.new(UIGameTable.CMD['CHANGE_TABLE'])  
    self.tcpGear:sendData(bufferHnd:doPack()) 
    LuaTools.beginWaiting(true)  
end

function UIGameTable:PlayerCtrl_readyUp() 
    self['Button_readyup']:setEnabled(false)
    local bufferHnd = DataPacker.new(UIGameTable.CMD['USER_READY'])  
    self.tcpGear:sendData(bufferHnd:doPack()) 

    -- -- yeah, i AM lazy, bite me will ya??     <---- nah, it won't work. <<---- still won't work, because it'll re-login!
    -- local displayID = self.playerData[self.mySeatID].displayID
    self['Image_status_1']:setVisible(true)
    self['Image_status_1']:loadTexture("room/RoomPlayerSatus_1.png",ccui.TextureResType.plistType)
end
--Image_mystatus

--托管
function UIGameTable:PlayerCtrl_setAutoplay(status,whereFrom) 
    printf("PlayerCtrl_setAutoplay : self.autoPlayStatus :%s",self.autoPlayStatus ) 
    if self.currentRoomState ==  UIGameTable.ROOM_STATE_IDLE  then 
        return
    end

    if status and type(status) == "number" then
        self.autoPlayStatus = status
    else
        self.autoPlayStatus = self.autoPlayStatus + 1
        self.autoPlayStatus = 2 - self.autoPlayStatus % 2 
    end

    printf("PlayerCtrl_setAutoplay :after: self.autoPlayStatus :%s",self.autoPlayStatus ) 
    if whereFrom == nil then
        local bufferHnd = DataPacker.new(UIGameTable.CMD['UPDATE_AUTOPLAY'])  
        bufferHnd:writeData(self.autoPlayStatus,DataPacker.BYTE)
        self.tcpGear:sendData(bufferHnd:doPack()) 
    else 
        if self.autoPlayStatus == 1 then --是托管
            self['Button_calcelAutoplay']:setVisible(true)
            self:darkenHandCards( true)
            self:PlayerCtrl_resetSelectedCards()
        else 
            self['Button_calcelAutoplay']:setVisible(false)
            self:darkenHandCards( false )
        end 
    end

end

--加倍
function UIGameTable:PlayerCtrl_doublebetOrNot(doubleBet)

    self['Button_doublebet']:setVisible(false)
    self['Button_dont_doublebet']:setVisible(false)
    local bufferHnd = DataPacker.new(UIGameTable.CMD['ACCEPT_DOUBLE'])
    bufferHnd:writeData(doubleBet,DataPacker.BYTE)
    self.tcpGear:sendData(bufferHnd:doPack()) 
    local status = UIGameTable.STATUS.DOUBLE_BET
    if doubleBet == 0 then   
        status = UIGameTable.STATUS.DONT_DOUBLE_BET
    end
    self:updatePlayerStatus(self.mySeatID,status)
end 

--加倍
function UIGameTable:PlayerCtrl_doublebet()
    self:PlayerCtrl_doublebetOrNot(1)
end 

--不加倍
function UIGameTable:PlayerCtrl_dont_doublebet() 
    self:PlayerCtrl_doublebetOrNot(0) 
end 

 
function UIGameTable:PlayerCtrl_playCards()
    self['Image_nolarger']:setVisible(false)
    local cardsReadyToSend = self:getSelectedCards()
    if #cardsReadyToSend<=0 then
        return
    end

    local cardValid,cardType = Cardutl.checkCardOut(cardsReadyToSend , self.lastPlayedCards or {})   
    self.lastSentCards = cardsReadyToSend
    if cardValid then 
        local bufferHnd = DataPacker.new(UIGameTable.CMD['PLAY_CARD']) 
        bufferHnd:writeData(#cardsReadyToSend,DataPacker.BYTE)
        for i=1,#cardsReadyToSend do
            bufferHnd:writeData(cardsReadyToSend[i],DataPacker.BYTE)
        end

        self.tcpGear:sendData(bufferHnd:doPack())  
        local ct =  Cardutl.getOriginalCardType(Cardutl.getCardAssamblyType(cardsReadyToSend))
        self:playAnimation(ct,1)  
        self:playSoundByCard(ct,cardsReadyToSend[1],self.mySeatID)
        self:disableAllBUttonsAndClock() 
        local startPositionTable = self:getCardPosByVal( cardsReadyToSend )
        self:setPlayedCards(self.mySeatID,cardsReadyToSend,nil,startPositionTable)
        self:removePickedCards() 
        self.povPlayedCard = true
    else 
        self:pickCards({},true)
        self['Image_play_wrongly']:setVisible(true)
        self['Image_nolarger']:setVisible(false)
        self:stopSchedule("wrong_card")
        self:createSchedule("wrong_card",function()
            self['Image_play_wrongly']:setVisible(false)
            self:stopSchedule("wrong_card")
        end,2) 
    end
end

function UIGameTable:PlayerCtrl_resetSelectedCards()
    self:pickCards({},true)
    self['Image_nolarger']:setVisible(false)
end

function UIGameTable:PlayerCtrl_pass() 
    local bufferHnd = DataPacker.new(UIGameTable.CMD['PASS']) 
    self.tcpGear:sendData(bufferHnd:doPack()) 
    self:showPlayOptions(false)
    self:pickCards({},true)
    self['Image_nolarger']:setVisible(false)
end

function UIGameTable:PlayerCtrl_showHint() 
    
    if self.hintBigger == nil then
        -- printf('=============== BEGIN OF SHOW HINT LOGICS ==========')
        -- dump(self.lastPlayedCardsType,"self.lastPlayedCardsType")
        -- dump(self.lastPlayedCards,"self.lastPlayedCards")
        -- dump(self:getAllHandCardsValues(),"self:getAllHandCardsValues()")
        local hint = CardHints.new({
            lastPlayedCardsType = self.lastPlayedCardsType  ,
            lastPlayedCardValues = self.lastPlayedCards ,
            handCardTable = self:getAllHandCardsValues()
            })
        hint:tip(false) 
        hint:getBigger()
        self.hintBigger = hint.bigger
        self.hintIndex  = 0
        -- dump(self.hintBigger,"hint")

        if #self.hintBigger == 0 then
            self:PlayerCtrl_pass()
            self['Image_nolarger']:setVisible(true) 
            self['Image_play_wrongly']:setVisible(false) 
            local function disCall()
                self['Image_nolarger']:setVisible(false)
            end
            local delay = cc.DelayTime:create(1.0)
            local sequence = cc.Sequence:create(delay, cc.CallFunc:create(disCall))
            self:runAction(sequence)
            return
        end
    end

    self.hintIndex = self.hintIndex + 1
    if self.hintIndex > #self.hintBigger then 
       self.hintIndex  = 1
    end
    printf('current big index:%s',self.hintIndex)
    if self.hintBigger and type(self.hintBigger) == 'table' and #self.hintBigger >0 then 
        self:pickCards(self.hintBigger[self.hintIndex],true)
    else
        self['Image_nolarger']:setVisible(true) 
        self['Image_play_wrongly']:setVisible(false)  
    end
    printf('=============== END OF SHOW HINT LOGICS ==========')
end

function UIGameTable:PlayerCtrl_wantlord()
    self:PlayerCtrl_wantLordOrNot(1) 
end

function UIGameTable:PlayerCtrl_dont_wantlord()
    self:PlayerCtrl_wantLordOrNot(0) 
end

function UIGameTable:PlayerCtrl_wantLordOrNot( want ) 
    self['Button_wantlord']:setVisible(false)
    self['Button_dont_wantlord']:setVisible(false)
    local bufferHnd = DataPacker.new(UIGameTable.CMD['WANT_TO_BELORD'])
     bufferHnd:writeData(want,DataPacker.BYTE)
    self.tcpGear:sendData(bufferHnd:doPack()) 
    if want == 0 then  
        self:updatePlayerStatus(self.mySeatID,UIGameTable.STATUS.DONT_WANT_TO_BE_LORD)
    end
end
   
--[==[---------------------DISPLAY FUNCTIONS START-----------------]==]

function UIGameTable:quitTable()
        self.Broadcast:removeSelf()
        local bufferHnd = DataPacker.new(UIGameTable.CMD['TABLE_DISCONNECT'])   
        self.tcpGear:sendData(bufferHnd:doPack()) 
        self.tcpGear:closeAndRelease() 
        self:removeSelf()
end



function UIGameTable:quitComfirm()
    -- body 
    local d = G_BASEAPP:addView('UIDialog', 65530)
    d:setupDialog('', '是否确定退出房间？', 
    function()  
        d:removeSelf()
        self:quitTable()
    end) 

end

function UIGameTable:getSelectedCards()
    local ret = {}
    for k,card in pairs(self.handCardTable) do
        if self.handCardTable[k].isPicked then
            table.insert(ret,card.val)
        end
    end
    return ret
    
end

function UIGameTable:enableWarningNode(enable,seatID ) 
    local display = self.playerData[seatID].display
    if self['Panel_player_'..display]:getChildByName('Node_warning') then 
        self['Panel_player_'..display]:getChildByName('Node_warning'):setVisible(enable) 
    end
end

function UIGameTable:showWarningAnimation( seatID )
    local display = self.playerData[seatID].displayID
    if self['warningNode_'..display] then 
        self['warningNode_'..display]:removeFromParent()
        self['warningNode_'..display] = nil
    end
    if self['Panel_player_'..display]:getChildByName('Node_warning') then 
        self['warningNode_'..display] = GameTableCommon.createAnimationNode('Animation_ddz_warning.csb',onFinish,true)
        self['Panel_player_'..display]:getChildByName('Node_warning'):setVisible(true)
        self['Panel_player_'..display]:getChildByName('Node_warning'):addChild(self['warningNode_'..display])
    end

end

function UIGameTable:updatePlayerStatus(seatID,status,clear)
    -- printf("Calling updatePlayerStatus")
    -- dump(self.playerData,'当前的玩家数据')
    for k,v in pairs(self.playerData) do
        local suffix = v.displayID  

        -- printf('scanning... v.seatID:%s, seatID:%s',v.seatID,seatID)
        if v.seatID ~= seatID then   
            if clear then
                self['Image_status_' .. suffix]:setVisible(false)
            end
        else 
            print('setting %s to status:%s',seatID,status)
            if status == UIGameTable.STATUS.NONE then

                -- printf('self[%s]:setVisible(false)','Image_status_' .. suffix)
                self['Image_status_' .. suffix]:setVisible(false)
                return
            end

            -- printf('self[%s]:setVisible(true)','Image_status_' .. suffix)
            local imgPath = "room/RoomPlayerSatus_"..status..".png"
            -- printf('loading image:%s',imgPath)
            self['Image_status_' .. suffix]:setVisible(true)
            self['Image_status_' .. suffix]:loadTexture(imgPath,ccui.TextureResType.plistType)

            if  status == UIGameTable.STATUS.READY then 
                if self.playerData[seatID] and self.playerData[seatID].displayID then 
                    local d  = self.playerData[seatID].displayID 
                    if  self['playedCardNode_'..d] ~= nil then
                        self['playedCardNode_'..d]:removeFromParent()
                        self['playedCardNode_'..d] = nil
                    end 
                end
            end
            if seatID == self.mySeatID and status == UIGameTable.STATUS.READY then 
                self['Button_readyup']:setEnabled(false) 
                self['Image_status_1']:setVisible(true)
                self['Image_status_1']:loadTexture("room/RoomPlayerSatus_1.png",ccui.TextureResType.plistType) 
            end 
            if UIGameTable.STATUS_INVERT[status] == nil then
                printf('UIGameTable.STATUS_INVERT[%s] == nil ',status)
                self['Image_status_' .. suffix]:setVisible(false)
            end
        end
    end 
end



function UIGameTable:setupCardSelection()
   ----------------------------------------------------
    local startPositionX = 0
    local currPositionX = 0 
    function checkSlided(startPos,endPos,status)
        local height =  UIGameTable.pickedCardsHeight 
        local dist = math.abs(startPos - endPos)
        -- print('=======================================================')
        for k,v in pairs(self.handCardTable) do
            local worldPos = v:convertToWorldSpaceAR(cc.p(0,0)) 
            local realPosX = worldPos.x  - v:getContentSize().width * v:getAnchorPoint().x
            worldPos.y = worldPos.y + v:getContentSize().height * v:getAnchorPoint().y
            -- printf("startPos:%.2f - realPosX:%.2f = %.2f",startPos,realPosX,math.abs(realPosX - startPos))
            local ac1 = math.abs(startPos - realPosX)   --left edge of card.
            local c1b =  math.abs(realPosX - endPos) 
            
            local diff = v:getContentSize().width - v.paddingX
            local ac2 = math.abs(startPos - (realPosX + diff))   --right edge of card.
            local c2b =  math.abs((realPosX+diff) - endPos ) 
            
            local rect = cc.rect(realPosX,worldPos.y,v:getContentSize().width - v.paddingX, v:getContentSize().height)
            if self.handCardTable[k+1] == nil then--this is the last card, must make different touch region.
                rect.width=rect.width+v.paddingX
            end
            -- printf("rect=> x:%.2f,y:%.2f,w:%.2f,h:%.2f (P:%.2f)",rect.x,rect.y,rect.width,rect.height,v.paddingX) 
            -- end
           self.handCardTable[k].isPicked = self.handCardTable[k].isPickedLast
            v:setColor(UIGameTable.BUTTON_ENABLE_COLOR) 
            if  dist >= ac1+c1b or  dist >= ac2+c2b or cc.rectContainsPoint(rect, cc.p(startPos,worldPos.y)) then  
                self.handCardTable[k].isPicked = not self.handCardTable[k].isPickedLast 
                v:setColor(UIGameTable.BUTTON_DISABLE_COLOR) 
            end

            if status == 'ended' or status == 'cancelled'   then --confirmed selection
                self.handCardTable[k].isPickedLast = self.handCardTable[k].isPicked
                self.handCardTable[k]:setPositionY(self.handCardTable[k].OriginalPositionY) 
                if self.handCardTable[k].isPicked == true then
                    self.handCardTable[k]:setPositionY(height+self.handCardTable[k].OriginalPositionY)
                end
                v:setColor(UIGameTable.BUTTON_ENABLE_COLOR) 
            end

            

            
        end
    end 
 
    local function aa(event)  
        -- printf("selecting cards,self.isDealingCards:%s",self.isDealingCards)
        if self.isDealingCards == true or (self.autoPlayStatus == 1) then return end
 
        if event.name == 'began' then 
            startPositionX =  event.pos.x
            currPositionX =  event.pos.x
        elseif event.name == 'moved' then
            currPositionX =  event.pos.x
        elseif event.name == 'ended' then 
            currPositionX =  event.pos.x
        elseif event.name == 'cancelled' then 
        end
        checkSlided(startPositionX,currPositionX,event.name)
    end 

    local function resetCardSelection()
        if self.isDealingCards == true or (self.autoPlayStatus == 1) then return end
        for k,v in pairs(self.handCardTable) do
            self.handCardTable[k]:setPositionY(self.handCardTable[k].OriginalPositionY)
            v:setColor(UIGameTable.BUTTON_ENABLE_COLOR) 
            self.handCardTable[k].isPicked , self.handCardTable[k].isPickedLast = false,false
        end 
    end
    self.handCardLayer:onTouch(aa) 
    self.handCardLayer:getParent():onTouch(resetCardSelection) 
    ----------------------------------------------------
end

function UIGameTable:resetDisplayTable() 
     print("resetDisplayTable...")
    for k,v in pairs(UIGameTable.displayIDTable) do
        UIGameTable.displayIDTable[k]=false
    end
    UIGameTable.displayIDTable[1] = true
end

function UIGameTable:cleanTable()

    print("cleanTable...")
    self.isGameStarted = nil
    self:stopSchedule('GAMEOVER_DELAY')
    self:stopSchedule('resetCards')
    LuaTools.stopWaiting()    
    self:hideAllPlayersStatus()
    for k,v in pairs(UIGameTable.displayIDTable) do
        -- UIGameTable.displayIDTable[k]=false
        self['BitmapFontLabel_score_'..k]:setVisible(false)  
        -- self['Image_status_'..k]:setVisible(false)  

        if  self['playedCardNode_'..k] ~= nil then
            self['playedCardNode_'..k]:removeFromParent()
            self['playedCardNode_'..k] = nil
        end 
        if self['Panel_player_'..k]:getChildByName('Node_warning') then 
            self['Panel_player_'..k]:getChildByName('Node_warning'):setVisible(false)
        end
        if self['warningNode_'..k] then 
            self['warningNode_'..k]:removeFromParent()
            self['warningNode_'..k] = nil
        end
        local role = self['Panel_player_'..k]:getChildByName("Image_role") 
        role:loadTexture("room/Room_farmer_hat.png",ccui.TextureResType.plistType) 
        if self.isPaodekuai == true then 
            role:setVisible(false)
        end
    end
    if self.springAnimNode and not tolua.isnull(self.springAnimNode) then 
        self.springAnimNode:removeFromParent()
        self.springAnimNode = nil 
    end 

    if self.doubleAmountNode  then 
        if tolua.isnull(self.doubleAmountNode ) == false then 
            self.doubleAmountNode:removeFromParent()
        end
        self.doubleAmountNode = nil
    end
    
    for k,v in pairs(self.playerData or {}) do 
        self.playerData[k].remaining_2 = nil
        self.playerData[k].remaining_1 = nil 
        self.playerData[k].isSat = nil
        self:showAutoplayAnimation( k , false) 
    end
    if self.myCardMenuRoot then 
        self.myCardMenuRoot:removeFromParent()
        self.myCardMenuRoot = nil 
    end
    for i=1,4 do

        self['Image_lordcard_'..i]:setVisible(false)
    end
    self['Image_roomtype']:setVisible(true)

    self.povPlayedCard = nil
    self.isDealingCards = nil
    self.lastOriginalCardType = nil
    self.isNewRound = nil 
    self['Text_multiply']:setString(self.globalMultiply)--(self.loginData.roomExtend.multi or 1)
    self.globalMultiply = self.loginData.roomExtend.multi 
    
    self:showPlayOptions(false)  
    -- UIGameTable.displayIDTable[1] = true

end

function UIGameTable:resetTable()

    LuaTools.stopWaiting()    
    self:cleanTable()
    self:resetDisplayTable() 
    self['Image_roomtype']:setVisible(true) 
    self['Image_nolarger']:setVisible(false)

    UIGameTable.displayIDTable[1]=true
    self.autoPlayStatus = 2 
    self.playerData = {}
    self.mySeatID = -1
    self.playerCount = 0
    self['Button_readyup']:setEnabled(true)
    self['Panel_player_3']:setVisible(false)
    self['Panel_player_2']:setVisible(false)

end
 

function UIGameTable:setupPlayer(data)
    local v = data 
    --显示该玩家相关组件
    printf('setting displayID%s to visible',v.displayID)
    self['Panel_player_'..v.displayID]:setVisible(true)

    --设置地主/农民

    local role = self['Panel_player_'..v.displayID]:getChildByName("Image_role") 
    local roleImagePath = "room/Room_farmer_hat.png"

    if self.isPaodekuai == true then 
        role:setVisible(false)
    end
    if v.role == UIGameTable.PLAYER_ROLE_LORD then 
        role:setVisible(true)
        roleImagePath = "room/Room_lord_hat.png" 
        if self.isPaodekuai == true then  
            roleImagePath = "common/dealer.png"  
        end
    end

    role:loadTexture(roleImagePath,ccui.TextureResType.plistType) 
    --设置性别 
    printf('setting avatar:url:%s,did:%s,sex:%s',v.iconUrl,v.displayID,v.sex)
    GameTableCommon.setAvatar(self,v.iconUrl,v.displayID,v.sex)
    GameTableCommon.setVIP(self, v.vipLevel,v.vipType,v.displayID ) 
    -- local sex = self['Panel_player_'..v.displayID]:getChildByName("Image_avatar") 
    -- sex:loadTexture("common/Room_male_head.png",ccui.TextureResType.plistType) 
    -- if v.sex == UIGameTable.SEX_FEMALE then 
    --     local sex = self['Panel_player_'..v.displayID]:getChildByName("Image_avatar") 
    --     sex:loadTexture("common/Room_female_head.png",ccui.TextureResType.plistType) 
    -- end
    -- --设置头像
    -- if v.iconUrl and v.iconUrl~="" then
    --     local iconUrl = self['Panel_player_'..v.displayID]:getChildByName("Image_avatar")  
    --     local newName = self.icon
    --     local function onFinishTable(status,downloadedSize,dst)
    --         if status == "success" then
    --             iconUrl:loadTexture(dst,ccui.TextureResType.localType)
    --         else 
    --             print('获取好友头像失败')
    --         end
    --     end 
    --     LuaTools.getFileFromUrl({
    --         url =  v.iconUrl,
    --         destFile = ( v.iconUrl:gsub("/","_")),
    --         onFinishTable = nFinishTable
    --         }) 
    -- end
    --设置昵称
    if v.nickName then
        local nick = self['Panel_player_'..v.displayID]:getChildByName("Text_nickname")
        if nick then
            nick:setString( v.nickName) 
        end
    end
    --设置金币
    if v.coins then
        local coin = self['Panel_player_'..v.displayID]:getChildByName("Text_coins")
        if coin then 
            coin:setString(LuaTools.convertAmountChinese(v.coins,10000)) 
        end
    end

end


function UIGameTable:setupAllPlayers()
    for k,v in pairs(self.playerData) do
        self:setupPlayer(v)
    end --for k,v in pairs(self.playerData) do
end


function UIGameTable:insertPlayerToDisplayTable(data)
    GameTableCommon.insertPlayerToDisplayTable(self,data)
    -- -- dump(UIGameTable.displayIDTable,"UIGameTable.displayIDTable")
    -- for i=1,#UIGameTable.displayIDTable do
    -- -- for k,v in pairs(UIGameTable.displayIDTable) do
    --     local v = UIGameTable.displayIDTable[i]
    --     if v == false then
    --         -- dump(data,"before display inserted table") 
    --         UIGameTable.displayIDTable[i] = true
    --         data.displayID = i 
    --         -- dump(data,"after display inserted table")
    --         -- printf("^^^ the %s has been inserted to table ^^^",i)
    --         -- dump(UIGameTable.displayIDTable,"UIGameTable.displayIDTable AFTER")
    --         return i
    --     end
    -- end
    -- -- dump(UIGameTable.displayIDTable,"UIGameTable.displayIDTable AFTER")
    -- -- printError("insertPlayerToDisplayTable: seats are full!")
end

function UIGameTable:showFirstCard(card) 
    self['Image_firstcard']:loadTexture(Cardutl.getPathForCard( card ),ccui.TextureResType.plistType)
    self['Image_firstcard']:setVisible(true)
    local killTime = 1
    self:createSchedule('killFirstCard',function()
        self:stopSchedule('killFirstCard')
        self['Image_firstcard']:setVisible(false)
    end,killTime)

end

-- function UIGameTable:getCardClickCallback()
--     local height = 20
--     return function (tag,sender) 
--         sender.isPicked = not sender.isPicked 
--         sender:setPositionY(height+sender.OriginalPositionY)
--         if sender.isPicked == false then
--             sender:setPositionY(sender.OriginalPositionY)
--         end
--     end
-- end

-- function UIGameTable:getCardSlidePickCallback()

--     return function (event)

--     end
-- end

function UIGameTable:getRedPackets()
    if tonumber(self.totalRedPackets) <= tonumber(self.finishRedPackets) then 
        local tempId = self.isWangPaiDDZ and 122 or 1 
        local paTable =     {
            ['uid']   = G_UID,
            ['token'] = G_TOKEN,
            ['type']  = 1,
            ['id']    = 1,
            ['siteid'] = tempId,
            ['rlevel'] = self.RoomLevel,
            ['cmd']   = HttpHandler.CMDTABLE.REDPACKETS_GET  
        }  
        local function succ(arg) 
            dump(arg,'领取红包succ')    
            if  arg.process.round and arg.process.round>= 3  then 
                self.Button_getPackets:setVisible(false)
            elseif arg.process.count and arg.process.finish then 
                self.totalRedPackets = arg.process.count
                self.finishRedPackets = arg.process.finish
                self.Button_getPackets:setVisible(true)
                self.Button_getPackets:getChildByName('Text_getPackets'):setString(arg.process.finish..'/'..arg.process.count)            
            end      
            self['Panel_getRedPacketsPar']:setVisible(false)
            if arg.msg then 
                LuaTools.showAlert(arg.msg)
            end    
            self.PlayerData.coin = arg.info.coin or self.PlayerData.coin 
            self.PlayerData.gem  = arg.info.gem  or self.PlayerData.gem 
            self.PlayerData.telfee = arg.info.telfee or self.PlayerData.telfee 
            self:updateMyMoney(self.PlayerData.coin, self.PlayerData.gem)
        end    
        local function fail(arg)
            dump(arg,'领取红包失败')    
        end     
        LuaTools.fastRequest(paTable,succ,fail)
    else     
        G_BASEAPP:addView('UIRedPackets',self:getLocalZOrder()+20000,self.totalRedPackets-self.finishRedPackets)
    end 
end     

function UIGameTable:reqRedPackets()
    local tempId = self.isWangPaiDDZ and 122 or 1 
    local paTable =     {
        ['uid']   = G_UID,
        ['token'] = G_TOKEN,
        ['type']  = 1,
        ['id']    = 1,
        ['siteid'] = tempId,
        ['rlevel'] = self.RoomLevel,
        ['cmd']   = HttpHandler.CMDTABLE.REDPACKETS_LIST  
    }  
    local function succ(arg) 
        dump(arg,'请求红包进度succ')    
        if  arg.round and arg.round>= 3  then 
            self.Button_getPackets:setVisible(false)
        elseif arg.count and arg.finish then 
            self.totalRedPackets = arg.count
            self.finishRedPackets = arg.finish
            self.Button_getPackets:setVisible(true)
            self.Button_getPackets:getChildByName('Text_getPackets'):setString(arg.finish..'/'..arg.count)            
        end        
    end    
    local function fail(arg)
        dump(arg,'请求红包进度失败')    
    end     
    LuaTools.fastRequest(paTable,succ,fail)
end     

function UIGameTable:updateRedPackets()
   if  self.totalRedPackets then 
      local tempId = self.isWangPaiDDZ and '122' or '1' 
      self.finishRedPackets = self.PlayerData.gameRedPackets[tempId][self.RoomLevel+1]
      self.Button_getPackets:getChildByName('Text_getPackets'):setString(self.PlayerData.gameRedPackets[tempId][self.RoomLevel+1]..'/'..self.totalRedPackets)            
      self['Panel_getRedPacketsPar']:setVisible(self.finishRedPackets ==self.totalRedPackets)
      if self.finishRedPackets == 1 then 
           self.Button_getPackets:getChildByName('Image_getPacket'):setVisible(true)
           self.Button_getPackets:runAction(cc.Sequence:create(cc.DelayTime:create(6),
            cc.CallFunc:create(function() 
               self.Button_getPackets:getChildByName('Image_getPacket'):setVisible(false)
                end )))
      end   
   end  
end 

function UIGameTable:clearMyCards() 
    print('UIGameTable:clearMyCards() ') 
    printf(' self.myCardMenuRoot = %s', self.myCardMenuRoot)
    if self.myCardMenuRoot then
        printf('tolua.isnull(self.myCardMenuRoot) = %s', tolua.isnull(self.myCardMenuRoot))
        if not tolua.isnull(self.myCardMenuRoot) then
            self.myCardMenuRoot:removeFromParent() 
            print('removing self.myCardMenuRoot') 
        end
        self.myCardMenuRoot = nil
    end

    -- self['Panel_cardlayout']:setLocalZOrder(self['Panel_cardlayout'].zorder)
    -- self['Panel_cardlayout']:setLocalZOrder(self['Panel_cardlayout']:getLocalZOrder()-1)
    self.myCardInstanceTable = {} 
    -- self.handCards = {}
    self.handCardTable = {}
end

function UIGameTable:alignItemsHorizontallyWithPadding(padding,childredTable) 
    local width = -padding; 
    for k,child in pairs(childredTable) do
        width  = width + child:getContentSize().width * child:getScaleX() + padding;
    end

    local x = -width / 2.0 ;
    
    for k,child in pairs(childredTable) do
        child:setPosition(x + child:getContentSize().width * child:getScaleX() / 2.0 , 0);
        x  = x+ child:getContentSize().width * child:getScaleX() + padding;
    end 
end

function UIGameTable:updateHandCards(argTable) 
    local paddingX = (self:getContentSize().width - 100) / 21  -- 21 cards max
    local paddingCard = paddingX
    if argTable then
        self:clearMyCards()
        dump(argTable,"argTable")
        if self.myCardMenuRoot then 
            self.myCardMenuRoot:removeFromParent()
            self.myCardMenuRoot = nil 
        end
        if argTable.cards and #argTable.cards > 0 then
            printf("argTable.cards:%s",#argTable.cards)
            self.myCardMenuRoot = display.newNode() 
            self.myCardMenuRoot:setPosition(self['Image_positionalCard']:getPosition())
            self.handCardLayer:addChild(self.myCardMenuRoot) 
            local handCards = argTable.cards or {}
            Cardutl.SortHandCards(handCards) 
            for k,cardVal in pairs(handCards) do  
                local spritePath = Cardutl.getPathForCard( cardVal )
                print(spritePath)
                local bk = cc.Sprite:createWithSpriteFrameName(spritePath) 
                local card = cc.MenuItemSprite:create(bk, bk) 
                if self.autoplayStatus == 1 then 
                    card:setColor(UIGameTable.BUTTON_DISABLE_COLOR)
                end
                card.val = cardVal 
                card.isPicked = false
                card.isPickedLast = false
                card.OriginalPositionY = card:getPositionY()
                paddingCard = (card:getContentSize().width  - paddingX)
                card.paddingX = paddingCard
                 self.myCardMenuRoot:addChild(card)
                table.insert(self.handCardTable,card) 
            end
            self:alignItemsHorizontallyWithPadding(-paddingCard,self.handCardTable)  
        end
        if argTable.fastDeal == false then
            -- self.handCardTable
            GameTableCommon.dealCardAnimation( self.handCardTable,argTable.onFinish )
        else 
            self.isDealingCards = false 
        end 
        self.lastCardsStatus = self:getAllHandCardsValues()
        self:darkenHandCards( self.autoPlayStatus == 1 )
    end
end

function UIGameTable:hideAllPlayersStatus()
    -- printError('UIGameTable:hideAllPlayersStatus')
     for k,v in pairs(self.playerData or {}) do
        local suffix = v.displayID  
        self['Image_status_' .. suffix]:setVisible(false)
    end
end
--用户倒计时
function UIGameTable:startPlayerCountdownBySeatID(seatID,timeLeft)
    -- body
    for k,v in pairs(self.playerData) do
        local displayID = v.displayID
        self:stopSchedule("player_countdown_"..displayID)
        -- print("v.seatID: "..v.seatID.." ,seatID: "..seatID.." ,displayID: "..displayID.." ,mySeatID: "..self.mySeatID)
        if v.seatID == seatID then
            print("startPlayerCountdownBySeatID： v.seatID == seatID：")
            self['Image_clock_'..displayID]:setVisible(true)
            self['Image_clock_'..displayID]:getChildByName("AtlasLabel_counter"):setString((timeLeft or UIGameTable.PLAYER_ACTION_TIMEOUT).."")
            self:createSchedule("player_countdown_"..displayID,function()
                local timer = tonumber(self['Image_clock_'..displayID]:getChildByName("AtlasLabel_counter"):getString())
                -- print("player_countdown_"..displayID,"timer:",timer)
                if timer <= 0 then
                    self['Image_clock_'..displayID]:setVisible(false)
                    self:stopSchedule("player_countdown_"..displayID)
                    return
                end
                timer=timer-1
                self['Image_clock_'..displayID]:getChildByName("AtlasLabel_counter"):setString(timer)
                end,1)
        else
            self['Image_clock_'..displayID]:setVisible(false)
        end

    end
end

--玩家是否要地主
function UIGameTable:showWantLord()
    self['Button_wantlord']:setVisible(true)
    self['Button_dont_wantlord']:setVisible(true)
end


function UIGameTable:arrangeCards(arrangeType,cardCalueTable,isLord,ignoreLaizi,startPositionTable)
    if not cardCalueTable or #cardCalueTable <= 0 then return end 
    local parent = display.newNode() 
    local middleNode = nil
    local spritePath = 'newcard/back.png'  
    -- print("arrangeCards spritePath：",spritePath)
    local card = cc.Sprite:createWithSpriteFrameName(spritePath)
    local padding = card:getContentSize().width * 0.4
    local width =   padding * #cardCalueTable + card:getContentSize().width * card:getScaleX() 
    local aPoint = cc.p(0,0.5) 
    if arrangeType == UIGameTable.ARRANGE_RIGHT then 
        aPoint = cc.p(0,0.5)
    elseif  arrangeType == UIGameTable.ARRANGE_MIDDLE then 
        aPoint = cc.p(0.5,0.5)
    end

    local cardInstanceTable = {}
    for i = 1, #cardCalueTable do 
        local v = cardCalueTable[i]
        local k = i
        -- print("arrangeCards v:",v)
        local checkLaizi = true
        if ignoreLaizi == true then
            checkLaizi = false
        end
        local spritePath,laizi = Cardutl.getPathForCard(v,nil,checkLaizi ) 
        local card = cc.Sprite:createWithSpriteFrameName(spritePath)
        parent:addChild(card)  
        card:setAnchorPoint(aPoint) 
        -- printf("isLord:%s",isLord)
        -- printf("laizi:%s",laizi)
        if isLord == true and i == #cardCalueTable then
            local lordTag = cc.Sprite:createWithSpriteFrameName('newcard/label.png')
            lordTag:setAnchorPoint(cc.p(0,0))
            card:addChild(lordTag)
        end
    
        if laizi == true then 
            local lz = cc.Sprite:createWithSpriteFrameName('newcard/label_flower.png')
            lz:setAnchorPoint(cc.p(0,0)) 
            card:addChild(lz)
        end


        if arrangeType == UIGameTable.ARRANGE_LEFT then
            card:setPosition(tonumber(k) * padding  - padding, 0); 
        elseif  arrangeType == UIGameTable.ARRANGE_RIGHT  then  
            card:setPosition((tonumber(k)) * padding - width , 0); 
        end 
        if k == math.floor(#cardCalueTable*0.5) then 
            middleNode = card  
            printf("choosen node:%s if total %s, floored val:%s",k,#cardCalueTable,math.floor(#cardCalueTable*0.5))
        end
        card.val = v
        table.insert(cardInstanceTable,card)

    end 
    if arrangeType == UIGameTable.ARRANGE_MIDDLE  then
        self:alignItemsHorizontallyWithPadding(-80,cardInstanceTable)
    end
    -- printf('args arrangeType:%s,cardCalueTable:%s,isLord:%s,ignoreLaizi:%s,startPositionTable:%s',arrangeType,cardCalueTable,isLord,ignoreLaizi,startPositionTable)
    -- dump(startPositionTable,"startPositionTable")
    -- dump(cardInstanceTable,"cardInstanceTable")

    for i,card in pairs(cardInstanceTable) do  
        card:setVisible(false)
        card.originalPos = cc.p(card:getPosition())
    end

    local totalMoveTime = 1
    local dealTime = totalMoveTime/#cardInstanceTable
    if dealTime <= 0.3 then 
        dealTime = 0.3
    end
    for i,card in pairs(cardInstanceTable) do 
        card:setVisible(true)
        local cardAnimationOriginalPosition = card.originalPos
        if startPositionTable then 
            cardAnimationOriginalPosition = startPositionTable[card.val]
        end 

        if cardAnimationOriginalPosition then
            local nodeSpace = card:convertToNodeSpace(cardAnimationOriginalPosition) 
            local offsetX = 300
            if arrangeType == UIGameTable.ARRANGE_LEFT then 
                nodeSpace.x = card.originalPos.x - offsetX
                nodeSpace.y = card.originalPos.y
            elseif arrangeType == UIGameTable.ARRANGE_RIGHT  then  
                nodeSpace.x = card.originalPos.x + offsetX
                nodeSpace.y = card.originalPos.y 
            elseif arrangeType == UIGameTable.ARRANGE_MIDDLE  then  
                nodeSpace.x = card.originalPos.x 
                nodeSpace.y = card.originalPos.y - 100    
            end
            card:setPosition(nodeSpace)
            local mov = cc.EaseExponentialOut:create(cc.MoveTo:create(dealTime,card.originalPos))
            local delayTime = cc.DelayTime:create(i*0.01)
            local act = cc.Sequence:create(delayTime,mov)
            card:runAction(act) 
        end 
    end

    -- local function myCallback()

    -- end

    -- local delay = cc.DelayTime:create(0.05)
    -- local sequence = cc.Sequence:create(delay, cc.CallFunc:create(myCallback))
    -- self:runAction(sequence)  

    return parent,middleNode

end

--显示地主牌
function UIGameTable:showLordCards(cards)
    if self.isPaodekuai == true then return end
    self['Image_roomtype']:setVisible(false)
    for k,card in pairs(cards) do
        -- print(k,v)
        self['Image_lordcard_'..k]:setVisible(true)
        local filename = Cardutl.getPathForCard( card ,true)
        print("loading:",filename)
        self['Image_lordcard_'..k]:loadTexture(filename,ccui.TextureResType.plistType)
    end
end

--设置地主
function UIGameTable:setLord(seatID)
    -- body
    if self.playerData[seatID] then 
        self.playerData[seatID].role = UIGameTable.PLAYER_ROLE_LORD 
    end

    if self.isPaodekuai == true then
        for k,v in pairs( self.playerData) do  
            local role = self['Panel_player_'..v.displayID]:getChildByName("Image_role") 
            if k == seatID then 
                role:loadTexture("common/dealer.png",ccui.TextureResType.plistType) 
                role:setVisible(true)
            else 
                role:setVisible(false)
            end 
        end 
 
    else  
        if self.lastLordID then
            local v = self.playerData[self.lastLordID]  
            local role = self['Panel_player_'..v.displayID]:getChildByName("Image_role") 
            role:loadTexture("room/Room_farmer_hat.png",ccui.TextureResType.plistType)
        end
        local v2 = self.playerData[seatID]
        if v2 then
            self.playerData[seatID].role = UIGameTable.PLAYER_ROLE_LORD  
            local role = self['Panel_player_'..v2.displayID]:getChildByName("Image_role") 
            role:loadTexture("room/Room_lord_hat.png",ccui.TextureResType.plistType)
            self.lastLordID = seatID
        end
    end
end

function UIGameTable:showDoubleBets()
    self['Button_doublebet']:setVisible(true)
    self['Button_dont_doublebet']:setVisible(true)
end

function UIGameTable:showPlayOptions(_show,isNewRound)
    self['Button_pass']:setVisible(_show)
    self['Button_hint']:setVisible(_show)
    self['Button_reset']:setVisible(_show)
    self['Button_playcard']:setVisible(_show)
    self['Button_pass']:setEnabled(not (type(isNewRound) == 'number' and isNewRound == 1 ))
    self['Button_hint']:setEnabled(not (type(isNewRound) == 'number' and isNewRound == 1 ))
    if _show then
        self.hintBigger = nil
        self.hintIndex  = 0
    end
end


-- function UIGameTable:playCard(cards)
--     for k,v in pairs(table_name) do
--         print(k,v)
--     end
-- end
--[[
3       1
3       1
3       1
3       1 
1
1
1
1
1
1
1
1



]]
--[[
TODO:
    出牌分开处理。
    先找isPicked 把手牌弄出去。
    然后实际打出的牌由服务器制定。
]]


function UIGameTable:removeCards(srcCards,cardsForRemoval)
    local ret = clone(srcCards)
    local rm = clone(cardsForRemoval) 
    local i = 1
    local len = #ret
    local rlen = #rm
    for i=1,len do 
        print("------------------------")
        for j=1,rlen do 
            printf("rm[%d]=%s ret[%s] = %s",j,rm[j],i,ret[i]) 
            if rm[j] then
                local retType = Cardutl.GetCardType(ret[i])
                local rmType = Cardutl.GetCardType(rm[j])
                if  ret[i] == rm[j] or (retType == Cardutl.CARD_SWT_TYPE and retType ==  rmType ) then 
                    print("^^^ triggered!")
                    ret[i] = nil
                    rm[j] = nil 
                    break
                end
            end
        end  
    end 
    local final = {}
    for k,v in pairs(ret) do
        table.insert(final,v)
    end 
    return final
end


function UIGameTable:removeCardsOLD(srcCards,cardsForRemoval)
    local ret = {}
    for k,v in pairs(srcCards) do
        local flag = true
        for k1,v1 in pairs(cardsForRemoval) do
            if v1 == v then  
                flag = false 
                break
            end 
        end 
        if flag == true then
            table.insert(ret,v)
        end
    end 
    dump(srcCards,"srcCards")
    dump(cardsForRemoval,"cardsForRemoval")
    dump(ret,"ret")
    Cardutl.SortHandCards(ret) 
    return ret
end

function UIGameTable:removePickedCards()
    local remainingCards = {}
    for k,card in pairs(self.handCardTable) do
        if card.isPicked == false then
            table.insert(remainingCards,card.val)
        end
    end
    self:updateHandCards({cards = remainingCards})
end


function UIGameTable:getPickCardsValue()
    local ret = {}
    for k,card in pairs(self.handCardTable) do
        if card.isPicked == true then
            table.insert(ret,card.val)
        end
    end
    return ret
end


function UIGameTable:getAllHandCardsValues()
    local ret = {}
    for k,card in pairs(self.handCardTable) do
        table.insert(ret,card.val)
    end
    return ret
end

function UIGameTable:convertLaiziCards()
    -- body
end

function UIGameTable:pickCardsEX(pickedCards,clear)
   local clonedCardsTable = clone(pickCards)
   local handCardLen = #self.handCardTable
   local cardTableLen = #clonedCardsTable
   local i , j = 1 , 1
   while i <= self.handCardLen do 
        local card =  self.handCardTable[i]
        if clear == true then 
            card.isPicked = false 
            card.isPickedLast = false 
            card:setPositionY(card.OriginalPositionY) 
        end

        while j <= cardTableLen do 
            local val = clonedCardsTable[j]
            if val ~= -999 and  val == card.val then
                clonedCardsTable[j] = -999
                card.isPicked = true 
                card.isPickedLast = true 
                card:setPositionY(UIGameTable.pickedCardsHeight + card.OriginalPositionY) 
                i=1
                j=1
                break
            end 
            j=j+1
        end
        i=i+1
   end
end

function UIGameTable:pickCards(pickedCards,clear)
    -- self:pickCardsEX(pickedCards,clear)
    for k,card in pairs(self.handCardTable) do
        local isPicked = false
        for _,val in pairs(pickedCards) do
            if val == card.val then
                isPicked = true
                break
            end
        end
        if isPicked then
            card.isPicked = true 
            card.isPickedLast = true 
            card:setPositionY(UIGameTable.pickedCardsHeight + card.OriginalPositionY) 
        elseif clear == true  then
            card.isPicked = false 
            card.isPickedLast = false 
            card:setPositionY(card.OriginalPositionY) 
        end
    end
end


function UIGameTable:compareTable(src,dst)
    local _src = clone(src)
    local _dst = clone(dst)
    Cardutl.SortOutCards(_src)  
    Cardutl.SortOutCards(_dst)  
    dump(_src,"_src")
    dump(_dst,"_dst")
    if #_dst ~= #_src then return false end
    local ret = true 
    for k,v in pairs(_src) do
        if v ~= _dst[k] then
            ret = false
            break
        end
    end
    return ret 
end

function UIGameTable:clearPlayedCards()
    for k,v in pairs(UIGameTable.displayIDTable) do
        local displayID = k
        if  self['playedCardNode_'..displayID] ~= nil then
            self['playedCardNode_'..displayID]:removeFromParent()
            self['playedCardNode_'..displayID] = nil
        end
    end
end


function UIGameTable:clearPlayedCardsBySeatID(seatID) 
    if self.playerData[seatID] then
        local displayID = self.playerData[seatID].displayID
        if  self['playedCardNode_'..displayID] ~= nil then
            self['playedCardNode_'..displayID]:removeFromParent()
            self['playedCardNode_'..displayID] = nil
        end
    end
end


function UIGameTable:setPlayedCards(seatID,cards,isRoundOver,startPositionTable) 
    if self.playerData[seatID] and cards and next(cards) then
        local displayID = self.playerData[seatID].displayID
        if  self['playedCardNode_'..displayID] ~= nil then
            self['playedCardNode_'..displayID]:removeFromParent()
            self['playedCardNode_'..displayID] = nil
        end
        dump(self.playerData[seatID],'当前的位置信息')
        print(seatID)
        -- print('Image_played_card_'..displayID)
        -- printf('Image_played_card_'..displayID..":%s",self['Image_played_card_'..displayID])
        local suffix = ''
        if isRoundOver == true then 
            suffix = '_end'
        end
        local posX = self['Image_played_card_'..displayID..suffix]:getPositionX()
        local posY = self['Image_played_card_'..displayID..suffix]:getPositionY()
        local scaleX = self['Image_played_card_'..displayID..suffix]:getScaleX() 
        local scaleY = self['Image_played_card_'..displayID..suffix]:getScaleY() 
        local arrange = UIGameTable.ARRANGE_MIDDLE
        if displayID == 3 then
            arrange = UIGameTable.ARRANGE_LEFT
        elseif displayID == 2 then
            arrange = UIGameTable.ARRANGE_RIGHT
        end
        printf("seatID:%s == self.lordSeatID:%s",seatID , self.lordSeatID)
        -- isRoundOver
        -- (arrangeType,cardCalueTable,isLord,ignoreLaizi,startPositionTable)
        local _isRoundOver = false
        if _isRoundOver then 
            _isRoundOver = isRoundOver
        end
        dump(startPositionTable,"startPositionTable setPlayedCards")
        local node,mid =  self:arrangeCards(arrange,cards,(seatID == self.lordSeatID),_isRoundOver,startPositionTable)

        self['playedCardNode_'..displayID] = node
        if self['Image_played_card_'..displayID..suffix].middleNode and tolua.isnull(self['Image_played_card_'..displayID..suffix].middleNode) == false then 
            self['Image_played_card_'..displayID..suffix].middleNode:removeFromParent()
            self['Image_played_card_'..displayID..suffix].middleNode = nil
        end
        self['Image_played_card_'..displayID..suffix].middleNode = mid
        printf("MIDDLE POSITION X:%s",mid)


        self['playedCardNode_'..displayID]:setPositionX(posX)
        self['playedCardNode_'..displayID]:setPositionY(posY)
        -- if isRoundOver == true then 
        --     self['playedCardNode_'..displayID]:setPositionY(posY -  self['playedCardNode_'..displayID]:getContentSize().height)
        -- end
        self['playedCardNode_'..displayID]:setScaleX(scaleX)
        self['playedCardNode_'..displayID]:setScaleY(scaleY)
        self['Image_played_card_'..displayID..suffix]:getParent():addChild(self['playedCardNode_'..displayID])
    end
end

function UIGameTable:handleSentCards(playedCards)

     if self:compareTable(self.lastSentCards or {},playedCards) == true then--出的牌和服务器返回的是一致的，说明出牌有效。
        -- self:removePickedCards()-- 在用户点击出牌按钮的时候就已经预先处理了。
     else--出的牌和服务器不一致，恢复打出去的牌，再使用服务器的牌。 
        --self.lastCardsStatus 
        dump(self.lastCardsStatus,"self.lastCardsStatus")
        local cards = self:removeCards(self.lastCardsStatus,playedCards)
        self:updateHandCards({cards = cards}) 
     end
        self.lastCardsStatus = self:getAllHandCardsValues()

end

function UIGameTable:disableAllBUttonsAndClock()
    self["Button_wantlord"]:setVisible(false)
    self["Button_dont_wantlord"]:setVisible(false) 
    self["Button_doublebet"]:setVisible(false)
    self["Button_dont_doublebet"]:setVisible(false) 
    self:showPlayOptions(false)  
    self["Button_dont_call_lord"]:setVisible(false)
    self["Button_call_lord"]:setVisible(false) 
    self["Button_dont_grab_lord"]:setVisible(false)
    self["Button_grab_lord"]:setVisible(false)
    self:startPlayerCountdownBySeatID(-1,0)
end

function UIGameTable:showButtonsByRoomStatus(roomStatus,forceAction,isNewRound)  
    self["Button_wantlord"]:setVisible(false)
    self["Button_dont_wantlord"]:setVisible(false) 
    self["Button_doublebet"]:setVisible(false)
    self["Button_dont_doublebet"]:setVisible(false) 
    self:showPlayOptions(false)  
    self["Button_dont_call_lord"]:setVisible(false)
    self["Button_call_lord"]:setVisible(false) 
    self["Button_dont_grab_lord"]:setVisible(false)
    self["Button_grab_lord"]:setVisible(false)

    self["Button_dont_wantlord"]:setEnabled(true)
    self["Button_dont_doublebet"]:setEnabled(true)
    self["Button_dont_call_lord"]:setEnabled(true)
    self["Button_dont_grab_lord"]:setEnabled(true)
    
    printf("showButtonsByRoomStatus:%s self.autoPlayStatus:%s",roomStatus,self.autoPlayStatus)
    if self.autoPlayStatus == 1 then
        self["Button_calcelAutoplay"]:setVisible(true)
       -- printError("Calling showButtonsByRoomStatus from...")
        return 
    end 
    
    local disableDeny = (forceAction and forceAction == 1) 

    if roomStatus == UIGameTable.ROOM_STATE_WANT_LORD then
        self["Button_wantlord"]:setVisible(true)
        self["Button_dont_wantlord"]:setVisible(true)
        if disableDeny == true then  
            self["Button_dont_wantlord"]:setEnabled(false)
        end
    elseif roomStatus == UIGameTable.ROOM_STATE_DOUBLE and not self.isPaodekuai then
        self["Button_doublebet"]:setVisible(true)
        self["Button_dont_doublebet"]:setVisible(true)
        if disableDeny == true then  
            self["Button_dont_doublebet"]:setEnabled(false)
        end
    elseif roomStatus == UIGameTable.ROOM_STATE_PLAYING then 
        self:showPlayOptions(true) 
    elseif roomStatus == UIGameTable.ROOM_STATE_CALL_LORD and not self.isPaodekuai then
        self["Button_dont_call_lord"]:setVisible(true)
        self["Button_call_lord"]:setVisible(true)
        if disableDeny == true and  not self.isWangPaiDDZ  then  
            self["Button_dont_call_lord"]:setEnabled(false)
        end
    elseif roomStatus == UIGameTable.ROOM_STATE_GRAB_LORD then  
        self["Button_dont_grab_lord"]:setVisible(true)
        self["Button_grab_lord"]:setVisible(true)
        if disableDeny == true and  not self.isWangPaiDDZ then  
            self["Button_dont_grab_lord"]:setEnabled(false)
        end
    end  

    self['Button_pass']:setEnabled(not (type(isNewRound) == 'number' and isNewRound == 1))
    self['Button_hint']:setEnabled(not (type(isNewRound) == 'number' and isNewRound == 1))
        --printError("Calling showButtonsByRoomStatus from...")
end

function UIGameTable:setCardLetfs(seatID,cardCount) 
    -- printError('setCardLetfs:seatID%s,cardCount:%s',seatID,cardCount)
    printf('setCardLetfs:self.playerData[%s]:%s',seatID,self.playerData[seatID])
    printf('setCardLetfs:self.playerData[%s]:%s',seatID,self.playerData[seatID])
    -- dump(self.playerData[seatID],"self.playerData["..seatID.."]")
    if self.playerData[seatID] then
        local displayID = self.playerData[seatID].displayID  
        printf('self[ Image_cardleft_%s]:%s',displayID,self['Image_cardleft_'..displayID])
        if self['Image_cardleft_'..displayID] then
            if cardCount <= 0 then
                self['Image_cardleft_'..displayID]:setVisible(false)
            else
                self['Image_cardleft_'..displayID]:setVisible(true)
            end
            self['Image_cardleft_'..displayID]:getChildByName('AtlasLabel_text'):setString((cardCount or -1).."")
        end
    end 
end


--[==[---------------------DISPLAY FUNCTIONS END-----------------]==]

--[==[-------------------TCP FUNCTIONS START-----------------------]==]

function UIGameTable:TCP_FORCE_KICK(data) 
	GameTableCommon.forceKickHandler(self,data)
	
    -- self.tcpGear:closeAndRelease() 
    -- local d
    -- local function func() 
    --     if self.Broadcast then
    --         self.Broadcast:removeSelf()
    --     end
    --     d:removeSelf()
    --     self:removeSelf()
    -- end
    -- dump(data,"TCP_FORCE_KICK") 
    -- d = G_BASEAPP:addView('UIDialog', 65530)
    -- d:setupDialog('注意', data.msg, 
    -- func,func)
end

function UIGameTable:TCP_SERVER_FAIL(data)
    dump(data,'TCP_SERVER_FAIL')  
	
	if data.actionId == 0x05 then
	else
		GameTableCommon.handleExceptionMsg(self,data)
	end
	
    
end

function UIGameTable:TCP_PLAY_CARD_ERROR(data)
    dump(data,'PLAY_CARD_ERROR')  
	
	if data.cards then
		self:updateHandCards({cards = data.cards})
		LuaTools.showAlert("出牌超时")
		self.playerData[self.mySeatID].cards = data.cards
	end
	
    
end

function UIGameTable:TCP_PLAYER_KICK(data)
    dump(data,'TCP_KIKPLAYER') 
	
	data.playerUID  =   self.playerData[data.sentSeatID].UID
	data.BePlayerUID =   self.playerData[data.receiveID].UID
	if data.status ~= 2 then 
		GameTableCommon.kickPlayer( self,data )
	else
		LuaTools.showAlert('踢人失败')
	end
	
    
end

-- function UIGameTable:TCP_ROUND_OVER( data )
--     dump(data,"TCP_ROUND_OVER")  
--     self.roundOverData = data
--     self:createSchedule('GAMEOVER_DELAY',function()
--         self:stopSchedule('GAMEOVER_DELAY')
--         self:handleGameOver(self.roundOverData) 
--     end,1)
--     -- body
-- end

function UIGameTable:TCP_ROUND_OVER(data) 
    dump(data,'TCP_ROUND_OVER') 
    
	self.isGameStarted = nil
	if G_BASEAPP:getView('UIMain') then 
		G_BASEAPP:callMethod('UIMain','reqSock_queryNewbie') 
	end
	
	
	local isDealerWon = false
	local argTable = {}
	argTable.infoTable = {}
	argTable.delegate = self

	argTable.isPaodekuai = self.isPaodekuai
	local tempIsMyself = false 
	local function playSprintAnimation(isDealerWon)
		local path = 'Animation_fonts_spring.csb'
		if isDealerWon == false then 
			path = 'Animation_fonts_fanspring.csb'
		end
		printf('SPRING --->>> path:%s',path)
		if self.springAnimNode and not tolua.isnull(self.springAnimNode) then 
			self.springAnimNode:removeFromParent()
			self.springAnimNode = nil 
		end 
		self.springAnimNode  = GameTableCommon.createAnimationNode(path,onFinish)
		self.springAnimNode:setPosition(display.center)
		self:addChild(self.springAnimNode) 
	end

	for k,v in pairs(data.results) do
		GameTableCommon.updatePlayerCoins(self, v.seatID,v.totalCoins )
		local info = {}
		local curPlayer = self.playerData[v.seatID] 
		self:showAutoplayAnimation( v.seatID , false) 

		local displayID = curPlayer.displayID
		if self['Panel_player_'..displayID]:getChildByName('Node_warning') then 
			self['Panel_player_'..displayID]:getChildByName('Node_warning'):setVisible(false)
		end 


		info.iconUrl  = curPlayer.iconUrl
		info.name  = curPlayer.nickName 
		if curPlayer.seatID == self.mySeatID then
			 info.name = "自己"
			 info.isMyself = true
			 tempIsMyself =true 
		end

		info.coins  = v.currenWinAmount
		info.sex  = curPlayer.Sex


		if v.seatID == self.lordSeatID then 
			info.isDealer = true
			if v.currenWinAmount >= 0 then 
				isDealerWon = true 
			end
		end 
		--关闭跑得快反春天动画
		--  if v.isSpring == 1 and self.isPaodekuai == true and v.seatID == self.mySeatID then  
		--     playSprintAnimation(isDealerWon)  
		-- end

		-- self['BitmapFontLabel_score_'..displayID]:setVisible(true)
		-- local fntFile = "fonts/gameOverNum_title_win.fnt"
		-- if v.currenWinAmount < 0 then 
		--     fntFile = "fonts/gameOverNum_title_lose.fnt"
		-- end
		-- self['BitmapFontLabel_score_'..displayID]:setFntFile(fntFile) 
		-- self['BitmapFontLabel_score_'..displayID]:setString(v.currenWinAmount) 



		if v.seatID ~= self.mySeatID then 
			self:setPlayedCards(v.seatID,v.cards,true) 
		else
			if v.currenWinAmount >= 0 then 
				argTable.isWon = true
			end
		end 
		table.insert(argTable.infoTable,info)

		self:setCardLetfs(v.seatID,0)

		-- if curPlayer.seatID == self.mySeatID then
		--    self.PlayerData.coin = v.TotalChip
		-- end
	end

	for k,v in pairs(argTable.infoTable) do
		if v.isDealer and k ~= 2 then
			argTable.infoTable[k] , argTable.infoTable[2] = argTable.infoTable[2] , argTable.infoTable[k] 
			break
		end
	end
	-- self:setPlayedCards(seatID,cards,isRoundOver) 
	self['Button_calcelAutoplay']:setVisible(false)  
	argTable.type = 'ddz'
	argTable.readyCallback = function() 
		self:PlayerCtrl_readyUp()  
		if self.resultPage and self.resultPage.removeSelf then 
			self.resultPage:removeSelf()
			self.resultPage = nil
		end
	end
	argTable.ctCallback = function() 
		self:PlayerCtrl_changeTable() 
		if self.resultPage and self.resultPage.removeSelf then 
			self.resultPage:removeSelf()
			self.resultPage = nil
		end
	end
	self:DoubleAmount(data.doubleAmount)
	argTable.mulText = data.doubleAmount
	self:updatePlayerStatus(data.seatID,UIGameTable.STATUS.NONE,true) 
	 
	self:stopSchedule("ROUND_OVER_DELAY")
	self:createSchedule("ROUND_OVER_DELAY",function() 
		self:stopSchedule("ROUND_OVER_DELAY")
		self:clearMyCards()   
		self['Button_readyup']:setVisible(false)
		self['Button_changeTable']:setVisible(false)
		self['Button_readyup']:setEnabled(true) 
		-- self['Button_readyup']:setVisible(true)
		-- self['Button_readyup']:setEnabled(true)
		-- self['Button_changeTable']:setVisible(true) 

		if tempIsMyself then 
		   argTable.changeTabState = true 
		   self.resultPage = G_BASEAPP:addView('UIGameTableResult',5000,argTable) 
		else 
				self['Button_readyup']:setVisible(true)
				self['Button_changeTable']:setVisible(true)
				self['Button_readyup']:setEnabled(true)    
		end 
		-- self.handCardLayer:setTouchEnabled(false) 
		-- self.handCardLayer:getParent():setTouchEnabled(false) 
		self:cleanTable()  
		-- self['Button_readyup']:setVisible(true)
		-- self['Button_readyup']:setEnabled(true)
		-- self['Button_changeTable']:setVisible(true)
		-- self:updateHandCards({cards = {}}) 
	end,1.5)
	self.autoPlayStatus = 2

	self.currentRoomState = UIGameTable.ROOM_STATE_IDLE 
	if data.Extra and data.Extra.spring and self.isPaodekuai ~= true then 
		local spr = tonumber(data.Extra.spring) 
		if spr and spr == 1 then
			playSprintAnimation(isDealerWon) 
		end
	end
	
    
end

function UIGameTable:showAutoplayAnimation( seatID , show)
    -- printError('seatID:%s',seatID)
    if self.playerData[seatID] then 
        local displayID = self.playerData[seatID].displayID
        if self['Panel_robotNode_'..displayID].robotAnimationNode == nil then 
            self['Panel_robotNode_'..displayID].robotAnimationNode = GameTableCommon.createAnimationNode('Animation_robot.csb',nil,true)
            self['Panel_robotNode_'..displayID]:addChild(self['Panel_robotNode_'..displayID].robotAnimationNode)
        end 
        self['Panel_robotNode_'..displayID]:setVisible(show or false)
    end
end

function UIGameTable:darkenHandCards( b )
    dump(self.handCardTable, "self.handCardTable")
    for i = 1 , #self.handCardTable do
        local card = self.handCardTable[i] 
		if card then
			card:setColor(UIGameTable.BUTTON_ENABLE_COLOR)
		end
        if b == true then 
            card:setColor(UIGameTable.BUTTON_DISABLE_COLOR)
        end
    end
end

function UIGameTable:TCP_PLAYER_AUTOPLAY(data) 
    dump(data,"TCP_PLAYER_AUTOPLAY")
	
	printf("self.mySeatID:%s",self.mySeatID)
	if data.seatID == self.mySeatID then
		self.autoPlayStatus = data.autoplayStatus 
		self:PlayerCtrl_setAutoplay(data.autoplayStatus,0) 
		if data.autoplayStatus == 1 then 
			self:showButtonsByRoomStatus(nil) 
		else
			if self.currentPlayerSeatID == self.mySeatID then
				self:showButtonsByRoomStatus(self.currentRoomState)  
			end
		end
	end
	self:showAutoplayAnimation( data.seatID , data.autoplayStatus == 1 )

end

function UIGameTable:TCP_PLAYER_PASS(data)
    -- dump(data,"TCP_PLAYER_PASS")  
    -- print("mdSeatID:",self.mySeatID)
	
	local clear = nil 
	self.isNewRound = nil
	if data.isNewRound == 1 then
		clear = true
		self.lastPlayedCards = nil
		self:clearPlayedCards()  
		self.isNewRound = true
	end    
	if data.nextID ~= -1 --[[and data.seatID ~= -1]] then 
		-- printf('===================PLAYER(%s) @ DISPLAYID:%s PASS.',data.nextID,self.playerData[data.nextID].displayID)
		self:updatePlayerStatus(data.seatID,UIGameTable.STATUS.PASS--[[,clear]])
		GameTableCommon.playSound(self,data.seatID, string.format('_buyao%s',math.random(1,3)))   
	end 

	self:showPlayOptions(false) 
	-- print("self.autoPlayStatus:",self.autoPlayStatus)
	self.currentPlayerSeatID = data.nextID

	if data.nextID == self.mySeatID and self.autoPlayStatus == 2 then 
		self.povPlayedCard = nil
		self:showPlayOptions(true,data.isNewRound) 
	end
	if data.nextID >= 0 then 
		local displayID_next = self.playerData[data.nextID].displayID
		if self['Panel_player_'..displayID_next]:getChildByName('Node_warning') then 
			self['Panel_player_'..displayID_next]:getChildByName('Node_warning'):setVisible(false)
		end
	end

	self:clearPlayedCardsBySeatID(data.nextID) 
	self:startPlayerCountdownBySeatID(data.nextID)  
	self:updatePlayerStatus(data.nextID,UIGameTable.STATUS.NONE)

	self.currentRoomState = UIGameTable.ROOM_STATE_PLAYING
	 

end
UIGameTable.sndTable = 
{
    [0x01] =    '_',
    [0x02] =    '_dui',
    [0x03] =    '_sange', 
    [0x04] =    '_sandaiyi', 
    [0x05] =    '_sandaiyidui', 
    [0x06] =    '_shunzi', 
    [0x07] =    '_liandui', 
    [0x08] =    '_feiji', 
    [0x09] =    '_feiji', 
    [0x0A] =    '_feiji', 
    [0x0B] =    '_sidaier', 
    [0x0C] =    '_sidaier', 
    [0x0D] =    '_zhadan', 
    [0x0E] =    '_wangzha',
}
function UIGameTable:playSoundByCard(  cardType,cardVal,seatID )
    local sex = self.playerData[seatID].sex

    local prefix = Sound.SoundTable['prefix'][sex]
    local suffix =  UIGameTable.sndTable[cardType]

    -- printError('cardType in playSoundByCard :%s',cardType)
    if cardType == 1 or cardType == 2 then 
        local val = Cardutl.GetCardValue(cardVal)
        if val > 13 then
            val=val-13
        end
        -- local cardType = Cardutl.GetCardType(cardVal) 
        if cardVal == Cardutl.CARD_KING_B then --大王
            val = 15
        elseif cardVal == Cardutl.CARD_KING_S then --小王 
            val = 14
        end 
        suffix = string.format("%s%s",suffix , val)  
    end
    local sexStr = 'male' 
    if sex == GameTableCommon.SEX_FEMALE then 
        sexStr = 'female' 
    end

    if cardType == self.lastOriginalCardType and self.isNewRound ~= true and cardType ~= 1 and cardType ~= 2 then  
        suffix = string.format('_dani%s',math.random(1,3)) 
    end
    local sndPath = Sound.SoundTable['voice'][sexStr][string.format('%s%s',prefix,suffix)] 
    -- printf(string.format('%s%s',prefix,suffix))
    -- printf(string.format('sexStr:%s',sexStr))
    -- printf('sex:%s',sex) 
    -- printf('sndPath:%s',sndPath)
    self.lastOriginalCardType = cardType
    audio.playSound(sndPath, false)
end

UIGameTable.animTable = 
{ 
    
    anim = 
    {
        [0x08] =    'Animation_airplane.csb', 
        [0x09] =    'Animation_airplane.csb', 
        [0x0A] =    'Animation_airplane.csb', 
        [0x0D] =    'Animation_bomb.csb', 
        [0x0E] =    'Animation_rocket.csb', 


    },
    text = 
    {
        [0x06] =    'Animation_fonts_shunzi.csb', 
        [0x07] =    'Animation_fonts_liandui.csb', 
        [0x08] =    'Animation_fonts_airplane.csb', 
        [0x09] =    'Animation_fonts_airplane.csb', 
        [0x0A] =    'Animation_fonts_airplane.csb',  
        -- [0x0D] =    'Animation_fonts_bomb.csb', 
        -- [0x0E] =    'Animation_fonts_rocket.csb',
    },
    snd = 
    {
        [0x08] = 'Cardtype_aircraft',
        [0x09] = 'Cardtype_aircraft',
        [0x0A] = 'Cardtype_aircraft',
        [0x0D] = 'Cardtype_bomb',
        [0x07] = 'Cardtype_double_line',
        [0x0E] = 'Cardtype_missile',
        [0x06] = 'Cardtype_one_line',
    }

}




function UIGameTable:playAnimation( cardType,displayID )

    local function createAnimationNode(nodeName,onFinish)
       return GameTableCommon.createAnimationNode(nodeName,onFinish,false,0.5)
    end

    local textNode = UIGameTable.animTable['text'][cardType]
    local animNode = UIGameTable.animTable['anim'][cardType]

    if textNode then 
        local node = createAnimationNode(textNode)
        self:addChild(node)
        local pos = self['Image_played_card_'..displayID]:convertToWorldSpaceAR(cc.p(0,0))

        if displayID ~= 1 
        and self['Image_played_card_'..displayID] 
        and self['Image_played_card_'..displayID].middleNode 
        and tolua.isnull(self['Image_played_card_'..displayID].middleNode) == false 
        then

            local offsetX = self['Image_played_card_'..displayID].middleNode:convertToWorldSpaceAR(cc.p(0,0)).x
            if offsetX then  
                if displayID == 2 then  
                    pos.x =   offsetX - 80 
                else 
                    if self.isPaodekuai or self.isWangPaiDDZ then 
                       pos.x =   offsetX + 160
                    else     
                       pos.x =   offsetX + 80 
                    end 
                end     
            end  
        end
        pos.y = pos.y - 25
        node:setPosition(pos)
    end 
    if animNode then  
        local node = createAnimationNode(animNode)
        self:addChild(node)
        node:setPosition(display.center)
    end 
    audio.playSound(Sound.SoundTable['sfx'][UIGameTable.animTable['snd'][cardType]] , false)



    


end




function UIGameTable:getCardPosByVal( valTable )
    local ret = {} 
    local str = "BEGIN SEARCHING POS BY VAL\n"
    for i = 1 , #self.handCardTable do
        local card = self.handCardTable[i]
        str = str.."searching i["..i.."]:val("..card.val..") =========================\n"
        for j=1,#valTable do 
            str = str.."check j("..valTable[j]..") == i("..card.val..")\n" 
            ret[card.val]= card:convertToWorldSpaceAR(cc.p(0,0))  
            -- if Cardutl.GetCardType(card.val) == Cardutl.CARD_SWT_TYPE then --laizi
            --     str = str.."^^^ laizi found ^^^\n"
            --     ret[card.val]=cc.p(card:getPosition()) 
            -- elseif card.val == valTable[j] then
            --     str = str.."^^^ found ^^^\n"
            --     local t = {val=card.val,pos=cc.p(card:getPosition())}
            --     table.insert(ret,t)
            -- end
        end 
    end
    printf(str)
    return ret
    -- body
end

function UIGameTable:TCP_PLAYER_PLAY_CARD(data)
    dump(data,"TCP_PLAYER_PLAY_CARD")
	
	-- if data.nextID >= 0 then 
		-- printf('==================PLAYER(%s) @ DISPLAYID:%s PLAY CARD.',data.nextID,self.playerData[data.nextID].displayID)
	-- end

	self['Image_status_1']:setVisible(false)
	self['Image_status_2']:setVisible(false)
	self['Image_status_3']:setVisible(false)
	self.currentRoomState = UIGameTable.ROOM_STATE_PLAYING 
	self:startPlayerCountdownBySeatID(data.nextID)  
	self:updatePlayerStatus(data.nextID,UIGameTable.STATUS.NONE)
	self.lastPlayedCards = data.cards
	dump(Cardutl.TypeConvert,"Cardutl.TypeConvert")
	print("data.cardType:",data.cardType)
	self.lastPlayedCardsType = Cardutl.TypeConvert[data.cardType]
	if self.lastPlayedCardsType == Cardutl.TYPE_BOMB_KING 
		or self.lastPlayedCardsType == Cardutl.TYPE_BOMB_4 then 
		self:DoubleAmount()
	end
	
	-- self:playSoundByCard(  data.cardType,data.cards[1],data.seatID, (data.isNewRound == 1 ))

	self:showPlayOptions(false) 
	self.currentPlayerSeatID = data.nextID
	self:clearPlayedCardsBySeatID(data.nextID)
    dump(self.playerData, "self.playerData")
    dump(data, "data self.playerData")
	self.playerData[data.seatID].cardLen = self.playerData[data.seatID].cardLen  - data.cardLen

	if self.playerData[data.seatID].cardLen == 2 then
		if self.playerData[data.seatID].remaining_2 == nil then  
			self.playerData[data.seatID].remaining_2 = true
			audio.playSound(Sound.SoundTable['sfx']['Warning'] , false)
			GameTableCommon.playSound(self,data.seatID, '_baojing2' )
		end
		self:showWarningAnimation(data.seatID)
	end

	if self.playerData[data.seatID].cardLen == 1 then 
		if  self.playerData[data.seatID].remaining_1 == nil then 
			self.playerData[data.seatID].remaining_1 = true
			audio.playSound(Sound.SoundTable['sfx']['Warning'] , false)
			GameTableCommon.playSound(self,data.seatID, '_baojing1' )
		end
		self:showWarningAnimation(data.seatID)
	end

	local displayID_curr = self.playerData[data.seatID].displayID

	if self['Panel_player_'..displayID_curr]:getChildByName('Node_warning') then 
		self['Panel_player_'..displayID_curr]:getChildByName('Node_warning'):setVisible(true)
	end 
	if data.nextID >= 0 then 
		local displayID_next = self.playerData[data.nextID].displayID
		if self['Panel_player_'..displayID_next]:getChildByName('Node_warning') then 
			self['Panel_player_'..displayID_next]:getChildByName('Node_warning'):setVisible(false)
		end
	end
		
	-- showWarningAnimation( seatID )

	if (self.autoPlayStatus == 1 or self.povPlayedCard ~= true) and data.seatID == self.mySeatID  then   
		local startPositionTable = self:getCardPosByVal( data.cards )
		self:setPlayedCards(self.mySeatID,data.cards,nil,startPositionTable)
		self:playSoundByCard(  data.cardType,data.cards[1],data.seatID) 
		self:playAnimation( data.cardType,displayID_curr )
	end
	
	self:setCardLetfs(data.seatID,self.playerData[data.seatID].cardLen)
	if data.nextID == self.mySeatID  then
		self:showButtonsByRoomStatus(self.currentRoomState,nil,data.isNewRound)
		self.povPlayedCard = nil
	end
	if data.seatID == self.mySeatID then 
		self:handleSentCards(data.cards)
	end

	if data.isNewRound == 1 then
		clear = true
		self.lastPlayedCards = nil
		self.lastOriginalCardType = nil
		self:clearPlayedCards()
	end   
	

	if data.seatID ~= self.mySeatID then
		self:playSoundByCard(  data.cardType,data.cards[1],data.seatID)
		self:setPlayedCards(data.seatID,data.cards) 
		self:playAnimation( data.cardType,displayID_curr )
	end


	self.isNewRound = nil
	
end

function UIGameTable:playDoubleAmination( amount,onfinish )
    -- body
    self['BitmapFontLabel_multiAnimation']:stopAllActions()
    self['BitmapFontLabel_multiAnimation']:setPosition(display.center)
    self['BitmapFontLabel_multiAnimation']:setPositionY(display.center.y + 130)
    self['BitmapFontLabel_multiAnimation']:setVisible(true) 
    self['BitmapFontLabel_multiAnimation']:setString(string.format('x%s倍',amount))
    self['BitmapFontLabel_multiAnimation']:setOpacity(0)
    self['BitmapFontLabel_multiAnimation']:setScale(3)
    self['BitmapFontLabel_multiAnimation']:setLocalZOrder(10000)
    local imgActTime = 0.3
    local imgSclDown = cc.ScaleTo:create(imgActTime*0.5,1)
    local imgtnt = cc.FadeTo:create(imgActTime*0.5,255)
    local imgSpawn= cc.Spawn:create(imgSclDown,imgtnt)
    local imgSclUp = cc.ScaleTo:create(imgActTime*0.25,1.5)
    local imgSclDownFinal = cc.ScaleTo:create(imgActTime*0.25,1)
    local movementDst = self['Text_multiply']:convertToWorldSpaceAR(cc.p(0,0))

    local delay = cc.DelayTime:create(0.5)
    local movement = cc.MoveTo:create(imgActTime,movementDst)
    local tempScale = cc.ScaleTo:create(imgActTime,0.5)
    local movementAndScale = cc.Spawn:create(movement,tempScale)
    local imgtntzero = cc.FadeTo:create(imgActTime*0.5,0)

    local onfinishAct = cc.CallFunc:create(function()
        self['BitmapFontLabel_multiAnimation']:setPosition(display.center)
        self['BitmapFontLabel_multiAnimation']:setPositionY(display.center.y + 130)
        self['BitmapFontLabel_multiAnimation']:setVisible(false) 
            if self.doubleAmountNode  then 
                if tolua.isnull(self.doubleAmountNode ) == false then 
                    self.doubleAmountNode:removeFromParent()
                end
                self.doubleAmountNode = nil
            end

            self.doubleAmountNode = GameTableCommon.createAnimationNode('Animation_jiabei.csb',function() 
                if onfinish then 
                    onfinish()
                end
            end)
            self.doubleAmountNode:setPosition(movementDst)  
            self:addChild(self.doubleAmountNode)
    end)
    -- Text_multiply
    self['BitmapFontLabel_multiAnimation']:runAction(cc.Sequence:create(imgSpawn,imgSclUp,imgSclDownFinal,delay,movementAndScale,imgtntzero,onfinishAct))

end

function UIGameTable:DoubleAmount(amount)

    if amount then 
        -- self:playDoubleAmination( amount,function() 
            self.globalMultiply = amount
            self['Text_multiply']:setString(self.globalMultiply)
        -- end )
        return
    end
    -- local n = tonumber(self['Text_multiply']:getString())
    -- n=n*2 
    self.globalMultiply=self.globalMultiply*2
    self:playDoubleAmination( self.globalMultiply ,function()
        self['Text_multiply']:setString(""..self.globalMultiply)
    end)
end
 
function UIGameTable:TCP_WHO_DOUBLED(data)
    -- dump(data,"TCP_WHO_DOUBLED")
	
	self.currentRoomState = UIGameTable.ROOM_STATE_DOUBLE 
	local dontDoubleBet = UIGameTable.STATUS.DOUBLE_BET
	local snd = '_jiabei'
	if data.isDoubled == 0 then 
		dontDoubleBet = UIGameTable.STATUS.DONT_DOUBLE_BET
		snd = '_bujiabei'
	else 
		self:DoubleAmount()
	end
	-- printf("[[[[[[[  %s",snd)
	GameTableCommon.playSound(self,data.seatID, snd)  
	self:updatePlayerStatus(data.seatID,dontDoubleBet)
	self:startPlayerCountdownBySeatID(data.nextID) 

	self:showButtonsByRoomStatus(nil)
	if data.nextID == self.mySeatID    then
		self:showButtonsByRoomStatus(self.currentRoomState,data.forceAction)
		self.povPlayedCard = nil
	end

	if data.nextID >= 0 then
		local displayID = self.playerData[data.nextID].displayID
		self['Image_status_'..displayID]:setVisible(false)
	end
	
    
end
-- "TCP_LORD_SATTLED_WHOS_DOUBLE" = {
--     "CMD"                = 65
--     "HEXCMD"             = "0x41"
--     "cardLen"            = 4
--     "cards" = {
--         1 = 51
--         2 = 35
--         3 = 19
--         4 = 1
--     }
--     "firstDoubledSeatID" = 1
--     "lordSeatID"         = 0
-- }
function UIGameTable:TCP_LORD_SATTLED_WHOS_DOUBLE(data)
    dump(data,"广播确定地主+该谁加倍")
	
	self:showLordCards(data.cards)
	self:startPlayerCountdownBySeatID(data.firstDoubledSeatID)
	self:updatePlayerStatus(data.firstDoubledSeatID, 0)
	self:setLord(data.lordSeatID) 
	self.lordSeatID = data.lordSeatID  
	self.currentRoomState = UIGameTable.ROOM_STATE_DOUBLE 
	-- printf("TCP_LORD_SATTLED_WHOS_DOUBLE,data.firstDoubledSeatID:%s,self.mySeatID:%s",data.firstDoubledSeatID , self.mySeatID)

	self:showButtonsByRoomStatus(nil)
	if data.firstDoubledSeatID == self.mySeatID  then 
		self:showButtonsByRoomStatus(self.currentRoomState,data.forceAction)
	end
	self.playerData[data.lordSeatID].cardLen = self.playerData[data.lordSeatID].cardLen + #data.cards

	if data.lordSeatID ~= self.mySeatID then 
		self:setCardLetfs(data.lordSeatID,21)
	end
	if data.lordSeatID == self.mySeatID  then 
		local cards = table.appendArray(self:getAllHandCardsValues(),data.cards)
		self:updateHandCards({cards = cards})
		self:pickCards(data.cards,true)
		self:createSchedule('resetCards',function()
			self:stopSchedule('resetCards')
			self:PlayerCtrl_resetSelectedCards()
		end,1)

	end  
	-- if self.isWangPaiDDZ then 
	--    GameTableCommon.playSound(self,data.lordSeatID, '_Rob'..math.random(1,3)) 
	-- end    

	if data.firstDoubledSeatID >= 0 then
		local displayID = self.playerData[data.firstDoubledSeatID].displayID
		self['Image_status_'..displayID]:setVisible(false)
	end

	-- self['Image_status_2']:setVisible(false)
	-- self['Image_status_3']:setVisible(false)
	
end


function UIGameTable:TCP_PLAYER_DISCONNECTED(data) 
	
	if self.playerData and self.playerData[data.seatID] then
		local displayID = self.playerData[data.seatID].displayID
		self['Panel_player_'..displayID]:setVisible(false)
		if  self['playedCardNode_'..displayID] ~= nil then
			self['playedCardNode_'..displayID]:removeFromParent()
			self['playedCardNode_'..displayID] = nil
		end
		if self['Panel_player_'..displayID]:getChildByName('Node_warning') then 
			self['Panel_player_'..displayID]:getChildByName('Node_warning'):setVisible(false)
		end
		if self['warningNode_'..displayID] then 
			self['warningNode_'..displayID]:removeFromParent()
			self['warningNode_'..displayID] = nil
		end
		self:showAutoplayAnimation(data.seatID , false)
		self.playerData[data.seatID ].isSat = nil
		self['Image_status_' .. displayID]:setVisible(false)
		UIGameTable.displayIDTable[self.playerData[data.seatID].displayID]=false
		self.playerData[data.seatID]=nil
	end
	
end

function UIGameTable:TCP_WHO_DECIDE_TO_CALL_LORD(data)
	
	if self.resultPage and self.resultPage.removeSelf then     
		self.resultPage:removeSelf()
		self.resultPage = nil
	end
	dump(data,"广播该谁叫地主 ")
	self.currentRoomState = UIGameTable.ROOM_STATE_CALL_LORD 
	self:startPlayerCountdownBySeatID(data.seatID)
	self:updatePlayerStatus(data.seatID, 0)
  
	self:showButtonsByRoomStatus(nil)
	if data.seatID and data.seatID ~= -1 and  data.seatID == self.mySeatID   then 
		self:showButtonsByRoomStatus(self.currentRoomState,data.forceAction)
	end 
	
	if data.prevSeatID and  data.prevSeatID ~= -1 then
		self:updatePlayerStatus(data.prevSeatID,data.prevSeatStatus)
		if data.prevSeatStatus == 3 then
			self:updatePlayerStatus(data.prevSeatID, 4)
		end
		if data.prevSeatStatus == 4 then
			self:updatePlayerStatus(data.prevSeatID, 3)
		end
	end 

	-- GameTableCommon.playSound(self,data.seatID, snd)  
	if data.prevSeatStatus == 4 then 
		printf('不叫 bujiao')
		GameTableCommon.playSound(self,data.prevSeatID, '_NoOrder') 
	end 
	
end

function UIGameTable:TCP_WHO_DECIDE_TO_GRAB_LORD(data)
	
	if self.resultPage and self.resultPage.removeSelf then     
		self.resultPage:removeSelf()
		self.resultPage = nil
	end
	dump(data,"广播该谁抢地主")
	self.currentRoomState = UIGameTable.ROOM_STATE_GRAB_LORD  
	self:startPlayerCountdownBySeatID(data.seatID)
	self:updatePlayerStatus(data.seatID, 0)  
	self:showButtonsByRoomStatus(nil)
	print("self.autoPlayStatus:",self.autoPlayStatus)
	if data.seatID == self.mySeatID    then
		self:showButtonsByRoomStatus(self.currentRoomState,data.forceAction)
	end 

	local snd = '_NoRob'
	local helper = '不抢'
	if data.prevSeatStatus == 5 or data.prevSeatStatus == 3 then 
		-- self:DoubleAmount()
		if data.prevSeatStatus == 3 then 
			snd = '_Order'
			helper = '叫地主'
		end
		if data.prevSeatStatus == 5 then 
			snd = '_Rob'..math.random(1,3)
			helper = '抢地主'
            self:DoubleAmount()
		end
	-- elseif data.prevSeatStatus == 6 then     
	end 
	printf('snd:%s',helper)
	if data.nextID ~= data.seatID then
		self:updatePlayerStatus(data.prevSeatID,data.prevSeatStatus)
		if data.prevSeatStatus == 3 then
			self:updatePlayerStatus(data.prevSeatID, 4)
		end
		if data.prevSeatStatus == 4 then
			self:updatePlayerStatus(data.prevSeatID, 3)
		end
	end 
	-- if data.seatID == -1 then 
	--    GameTableCommon.playSound(self,data.prevSeatID, snd)  
	-- else     
	   GameTableCommon.playSound(self,data.prevSeatID, snd)  
	-- end    

	dump(self.playerData,'玩家数据')
	
end

function UIGameTable:TCP_WHO_DECIDE_TO_BE_LORD(data)
	
	if self.resultPage and self.resultPage.removeSelf then     
		self.resultPage:removeSelf()
		self.resultPage = nil
	end
	-- dump(data,"广播该谁要地主")
	self:startPlayerCountdownBySeatID(data.seatID)  
	if data.seatID == self.mySeatID    then
		self:showWantLord()
	end

	self:showButtonsByRoomStatus(nil)
	if data.seatID == self.mySeatID    then
		self:showButtonsByRoomStatus(self.currentRoomState,data.forceAction)
	end 

	if data.nextID ~= data.seatID then
		self:updatePlayerStatus(self.lastDudeThatDecedeToBeLord,UIGameTable.STATUS.DONT_WANT_TO_BE_LORD) 
		GameTableCommon.playSound(self,data.prevSeatID, '_buyao1')   
	end 
	self.lastDudeThatDecedeToBeLord = data.seatID 
	self.currentRoomState = UIGameTable.ROOM_STATE_WANT_LORD 
	-- GameTableCommon.playSound(self,data.seatID, '_Rob'..math.random(1,3)) 
	
end

function UIGameTable:TCP_PLAYER_CONNECTED(data) 
	
	-- dump(data,"TCP_PLAYER_CONNECTED")
	self.playerData[data.seatID]=data  
	self.playerData[data.seatID].totalCoins = data.coins
	self:insertPlayerToDisplayTable(self.playerData[data.seatID])
	data.role = 0--force erase role
	self:setupPlayer(data)     
	dump(self.playerData,"TCP_PLAYER_CONNECTED")
	self:updatePlayerStatus(data.seatID,data.status)
	
end

function UIGameTable:TCP_CURRENT_TASKS(data)
    dump(data)
end

function UIGameTable:TCP_DEAL_CARDS(data)
	
	-- dump(data,"TCP_DEAL_CARDS")
	self:cleanTable() 
	if  self.isPaodekuai ~= true then 
		self.isGameStarted = true
	end
	self:hideAllPlayersStatus()
	
	data.fastDeal = false
	self.autoplayStatus = 2
	self.isDealingCards = true
	printf("BEGIN DEALING CARDS")
	data.onFinish = function() 
		self.isDealingCards = false
		printf("END DEALING CARDS")
	end
	self:updateHandCards(data) 
	self['Button_readyup']:setVisible(false)
	self['Button_changeTable']:setVisible(false) 
	self.currentRoomState = UIGameTable.ROOM_STATE_WANT_LORD 
	self:showFirstCard(data.first) 


	if self.isPaodekuai == false then 
		for k,v in pairs(UIGameTable.displayIDTable) do 
			self:setCardLetfs((k-1),17)
			self.playerData[k-1].cardLen = 17
		end
	else
		for k,v in pairs(data.ingamePlayers) do
			self.playerData[v].isSat = true
			self:setCardLetfs(v,18)
			self.playerData[v].cardLen = 18
		end
		if #data.cards == 0 then  --我不在牌桌
			self['Button_readyup']:setVisible(true)
			self['Button_changeTable']:setVisible(true) 
			self['Button_readyup']:setEnabled(false)
		end     
	end 

	self['Image_roomtype']:setVisible(false)
	for k=1,4 do
		self['Image_lordcard_'..k]:setVisible(true)
		self['Image_lordcard_'..k]:loadTexture('newcard/jx_back.png',ccui.TextureResType.plistType)
	end
	
end


function UIGameTable:TCP_PLAYER_READY(data) 
    -- dump(data) 
	
	self:updatePlayerStatus(data.seatID,UIGameTable.STATUS.READY)
	if data.seatID == self.mySeatID then  
		self['Button_readyup']:setEnabled(false)
		self['Image_status_1']:setVisible(true)
		self['Image_status_1']:loadTexture("room/RoomPlayerSatus_1.png",ccui.TextureResType.plistType)

	end 
	
end

function UIGameTable:updateNewieProgress( curr )
    -- body

    self['Text_newbie']:setVisible(false)
    self['Image_newbie']:setVisible(false)

    --关闭了菜鸟任务 所以先暂时注释掉  以后还会用到   7-26 syj
    -- if curr == 5 then 
    --     self.PlayerData.bitcheckCaiNiao = 1
    --     return
    -- end
    -- if self.PlayerData.bitcheckCaiNiao == 0 and self.PlayerData.vip_level <= 0  then 
    --     self['Text_newbie']:setVisible(true)
    --     self['Image_newbie']:setVisible(true)
    --     self['Text_newbie']:setString(string.format('新手任务进度:%s/%s',curr,5))
    -- end
end

function UIGameTable:TCP_TABLE_LOGIN_SUCESS(data)
    dump(data,'斗地主房间登录成功')
    -- print(self.isPaodekuai)
	
	LuaTools.stopWaiting()  
	-- LuaTools.showAlert('准备后开始匹配玩家') 

	if G_BASEAPP:getView('UIMain') then 
		G_BASEAPP:callMethod('UIMain','reqSock_queryNewbie') 
	end 
	data.roomExtend = data.roomExtend or {}
	data.roomExtend.multi = data.roomExtend.multi or 1
    if not self.isPaodekuai then  
       self:reqRedPackets()
    end    
	self.loginData = data 
	-- dump(data.roomExtend,'进入斗地主初始化的信息')
	-- print(data.doubleAmount)
	self['Text_multiply']:setString(data.doubleAmount or 1)--(data.roomExtend.multi or 1)
	self.globalMultiply = data.doubleAmount or 1 --data.roomExtend.multi
	self['Text_betpool']:setString(data.bpour)
	UIGameTable.PLAYER_ACTION_TIMEOUT = data.waitTimeOut
	if self.isPaodekuai == true then 
		UIGameTable.PLAYER_ACTION_TIMEOUT = data.outTimeOut
	end
	GameTableCommon.handleLoginSuccess( self,data )
	-- local roomName = UIGameTable.GameTableName.name[data.roomType]..UIGameTable.GameTableName.level[tonumber(data.roomExtend.roomLevel)]
	self['Text_roomType']:setString('')   
	--bpour
	-- LuaTools.stopWaiting() 
	self:resetTable()
	self:resetDisplayTable() 
	if self.resultPage and self.resultPage.removeSelf then 
		self.resultPage:removeSelf()
		self.resultPage = nil
	end

	local isMyPlaying = false
 

	if data then 
		if data.selfSeat then
		   self.mySeatID  = data.selfSeat  
		end 

		self['Button_calcelAutoplay']:setVisible(false)
		if data.autoPlayStatus then
			self.autoPlayStatus = data.autoPlayStatus
		end
		-- if data.autoPlayStatus == 1 then
		-- 	self['Button_calcelAutoplay']:setVisible(true) 
		-- 	self:darkenHandCards( true )
		-- end
		self.currentRoomState = data.roomState

		for k,v in pairs(data.userData) do
			self.playerData[v.seatID] = v 
			if v.seatID == self.mySeatID then--force my displayID to 1
				print("v.seatID == self.mySeatID ")
				self.playerData[v.seatID].displayID = 1
			else
				self:insertPlayerToDisplayTable(self.playerData[v.seatID])--self.playerData[v.seatID]) 
			end
			 self.playerData[v.seatID].totalCoins = v.coins
			
			
			 if data.roomState == UIGameTable.ROOM_STATE_IDLE then
				self.playerData[v.seatID].role = 0 --we're not playing game, clear player's role
				-- self:cleanTable()        <---- I'm not sure if comment this line will be ok.
				self['Button_readyup']:setVisible(true)
				self['Button_changeTable']:setVisible(true)
			 else 
				if self.isPaodekuai  then 
				   self:setCardLetfs(v.seatID,v.cardLen) 
				   if  data.roomState == UIGameTable.ROOM_STATE_DOUBLE  then  --正在对局
					   if G_UID == v.UID then 
						  if v.status == 3 then
							  isMyPlaying = true
						  end
						  if v.status == 0 then  --我没玩
							 self['Button_readyup']:setVisible(true)
							 self['Button_changeTable']:setVisible(true) 
							 self['Button_readyup']:setEnabled(false)
						  else  
							 self['Button_readyup']:setVisible(false)
							 self['Button_changeTable']:setVisible(false) 
						  end
					   end 
					else 
						self['Button_readyup']:setVisible(true)
						self['Button_changeTable']:setVisible(true) 
					end          
				else 
					self['Button_readyup']:setVisible(false)
					self['Button_changeTable']:setVisible(false) 
					self:setCardLetfs(v.seatID,v.cardLen)
				end     
			 end
			 -- printf('self.playerData[%s].status == %s',v.seatID, self.playerData[v.seatID].status)
			if self.playerData[v.seatID].status == 1 then
				self:updatePlayerStatus(v.seatID,self.playerData[v.seatID].status)
			end
		end 

		if data.lordSeatID then
			if data.roomState == UIGameTable.ROOM_STATE_DOUBLE or      --等待加倍           --|__________________________
			data.roomState == UIGameTable.ROOM_STATE_PLAYING  then     --房间正在游戏(出牌) --|  [这俩状态地主已经确定了]
				self:setLord(data.lordSeatID) 
			end
			self.lordSeatID = data.lordSeatID 
		end
		if data.lastPlayerSeatID then
			self.lastSentCards = data.lastPlayerCards
			-- dump(Cardutl.TypeConvert,"Cardutl.TypeConvert")
			print("data.cardType:",data.cardType)
			self.lastPlayedCardsType = Cardutl.TypeConvert[data.lastPlayerCardType] 
			self.lastPlayedCards = data.lastPlayerCards
			self:setPlayedCards(data.lastPlayerSeatID ,data.lastPlayerCards)
			self:updatePlayerStatus(data.lastPlayerSeatID, 0)
		end 
		if data.currentSeat == self.mySeatID   then 
		   self:showButtonsByRoomStatus(self.currentRoomState)
		end 
		self:startPlayerCountdownBySeatID(data.currentSeat,data.outTimeOut)
		self:updatePlayerStatus(data.currentSeat, 0)

		if data.roomState ~= UIGameTable.ROOM_STATE_IDLE  then
			local tbl = {}
			tbl['cards'] = data.userCards
			self:updateHandCards(tbl) 
			if  self.isPaodekuai ~= true then 
				self.isGameStarted = true
			end
		end 
		if data.lordCards then
			self:showLordCards(data.lordCards)
		end
	end  
	self:setupAllPlayers() 
	if data.autoPlayStatus == 1 then 
		self:showAutoplayAnimation( self.mySeatID , true)
		self:darkenHandCards( true ) 
        self['Button_calcelAutoplay']:setVisible(true) 
	end
	-- dump(self.playerData,"self.playerData")

	if self.isPaodekuai == true then  
		self['Image_roomtype']:setVisible(true)  
		self['Image_roomtype']:loadTexture(string.format("room/pdk_%s.png",data.roomType),ccui.TextureResType.plistType) 
	end

	if data.roomExtend and data.roomExtend.roomLevel then         
		local roomLevelStingTable = {
			[0] = '初级场',
			[1] = '中级场',
			[2] = '高级场',
			[3] = '血战场',
			[4] = '私人场',
			-- '初级场',
			-- '初级场',
			-- '初级场',
		}
		self['Text_roomType']:setString(roomLevelStingTable[data.roomExtend.roomLevel] or '') 
		self['Image_roomtype']:setVisible(true)
		self['Image_gamttype']:setVisible(true) 
		self['Image_roomtype']:loadTexture(string.format("tableresult/tt%s.png",data.roomExtend.roomLevel),ccui.TextureResType.plistType) 
		if  data.roomType == 122 then 
		   self['Panel_tales']:setBackGroundImage("background/game_tables4.png",ccui.TextureResType.localType) 
		elseif not  self.isWangPaiDDZ  and not self.isPaodekuai then 
		   self['Panel_tales']:getChildByName('Image_newBg'):loadTexture(string.format("background/bb%s.png",data.roomExtend.roomLevel),ccui.TextureResType.localType) 
		end    
		-- if data.roomType == 1 or data.roomType == 18 then 
		--     self['Image_gamttype']:loadTexture(string.format("common/gt%s.png",data.roomType),ccui.TextureResType.plistType) 
		-- end
	end
	if data.roomExtend and data.roomExtend.expire then 
		self['Image_roomtype']:setVisible(true) 
		self['Image_roomtype']:loadTexture('tableresult/tt6.png',ccui.TextureResType.plistType)  
		self['Text_roomType']:setString('私人场')       
		self.isPrivateMatch = true 
	end

	if self.isPaodekuai and isMyPlaying == true then
		if data.currentSeat == self.mySeatID and data.autoPlayStatus ~= 1 then
			self:showPlayOptions(true)
		end
	end
	-- self:startPlayerCountdownBySeatID(0) 
	if self.isFirstLoginReady and data.roomState == 0 and  data.roomExtend.roomLevel and data.roomExtend.roomLevel == 0  then 
		 self:PlayerCtrl_readyUp()
		 self.isFirstLoginReady = false 
	end
	
          
end



function UIGameTable:TCP_MESSAGE_POPUP(data)

	LuaTools.stopWaiting()
	-- dump(data,'哈哈哈大哥第三个三等功三等功三等功')
	if self.isPaodekuai == false then 
		GameTableCommon.showMsgByMsgType(self,data.msgType,data.msg,data)
	end
	-- local blah = ""..cc.Director:getInstance():getTotalFrames()
	-- if data.msgType == UIGameTable.TIP_NORMAL_PLAYER_TOAST then
	--     G_BASEAPP:addView({
	--        uiName =  'UIAlert',
	--        uiInstanceName = blah
	--         },5000)
	--     :setupDialog('Infomation',data.msg)
	-- else  
	--     local b = G_BASEAPP:addView({
	--        uiName =  'UIDialog',
	--        uiInstanceName = blah
	--         }, 5200)
	--     b:setupDialog("信息",data.msg)    
	-- end
	-- dump(data)
	
    
end


function UIGameTable:TCP_HEARTBEAT(data)
    -- dump(data)
end

function UIGameTable:TCP_onConnected()

	--默认 斗地主 然后房间传-1 服务器分配
	if G_LOADINGVIEW then
		G_LOADINGVIEW:removeSelf()
		G_LOADINGVIEW = nil
	end
    printf('UIGameTable:TCP_onConnected() self.RoomId:%s',self.RoomId)
    printf('UIGameTable:TCP_onConnected() self.friendID:%s',self.friendID)
	printf('UIGameTable:TCP_onConnected() self.tableType:%s',self.tableType)
	local buffer = self:getLoginBuffer(self.tableType,self.friendID,self.RoomId)
	self.tcpGear:sendData(buffer) 

		self:REQ_heartbeat() 
	self:scheduleHeartbeat()
	
    
end


function UIGameTable:REQ_TABLE_DISCONNECT() 
    local bufferHnd = DataPacker.new(self.CMD['TABLE_DISCONNECT'])   
    self.tcpGear:sendData(bufferHnd:doPack())
end

function UIGameTable:REQ_KICK_PLAYER( uid ) 

    local player = GameTableCommon.getPlayerByUid(self, uid )
    local bufferHnd = DataPacker.new(self.CMD['USER_KICK'])   
    bufferHnd:writeData(player.seatID,DataPacker.BYTE) 
    self.tcpGear:sendData(bufferHnd:doPack()) 
end


function UIGameTable:REQ_FRIENDREQUEST(toUID ) 
    local player = GameTableCommon.getPlayerByUid(self, toUID )
    local bufferHnd = DataPacker.new(self.CMD['FRIEND_REQUEST'])   
    bufferHnd:writeData(player.seatID,DataPacker.BYTE) 
    self.tcpGear:sendData(bufferHnd:doPack()) 
end

function UIGameTable:REQ_FRIENDREQUEST_RESULT(uid,res )  
    local bufferHnd = DataPacker.new(self.CMD['ACCEPT_OR_DENY'])   
    bufferHnd:writeData(uid,DataPacker.INT) 
    bufferHnd:writeData(res,DataPacker.BYTE) 
    self.tcpGear:sendData(bufferHnd:doPack()) 

end



function UIGameTable:REQ_SENDGIFT(toSeatID, giftID ) 
    local bufferHnd = DataPacker.new(self.CMD['SEND_GIFT'])   
    bufferHnd:writeData(giftID,DataPacker.BYTE)
    bufferHnd:writeData(toSeatID,DataPacker.BYTE)
    self.tcpGear:sendData(bufferHnd:doPack()) 
end

function UIGameTable:REQ_CHAT(str)   
    printf('SENDING CHAT MEG:%s',str)
    local bufferHnd = DataPacker.new(self.CMD['CHAT'])   
    bufferHnd:writeData(str,DataPacker.STRING)
    self.tcpGear:sendData(bufferHnd:doPack()) 
    printf('DONE SENDING CHAT MEG:%s',str)
end

function UIGameTable:REQ_CHAT_TEXT_CONSTANCE(tbl)
    dump(tbl,'SENDING REQ_CHAT_TEXT_CONSTANCE') 
    local bufferHnd = DataPacker.new(self.CMD['CHAT_TEXT_CONSTANCE'])   
    bufferHnd:writeData(tbl.msgType,DataPacker.BYTE)
    bufferHnd:writeData(tbl.msg,DataPacker.BYTE)
    self.tcpGear:sendData(bufferHnd:doPack()) 
    printf('DONE SENDINGREQ_CHAT_TEXT_CONSTANCE')

end
 




function UIGameTable:CHAT_TEXT_CONSTANCE(tbl)  
    local bufferHnd = DataPacker.new(self.CMD['CHAT_TEXT_CONSTANCE'])   
    bufferHnd:writeData(tbl.msgType,DataPacker.BYTE) 
    bufferHnd:writeData(tbl.msg,DataPacker.BYTE)
    self.tcpGear:sendData(bufferHnd:doPack())
end

function UIGameTable:REQ_heartbeat()  
    if self.heartBeatBuffer == nil then 
        local bufferHnd = DataPacker.new(UIGameTable.CMD['HEARTBEAT'])
        self.heartBeatBuffer = bufferHnd:doPack()
    end
    self.tcpGear:sendData(self.heartBeatBuffer) 
end

function UIGameTable:TCP_CMDB_HEARTBEAT(data)
    print('TCP_CMDB_HEARTBEAT')
end

function UIGameTable:scheduleHeartbeat()
    self:stopSchedule('heartbeat')
    self:createSchedule('heartbeat', function()   
        self:REQ_heartbeat() 
    end,25)  
end

function UIGameTable:getPortByTableID(tableID)
    -- dump(TCPGearbox.serverConfig) 
    for k,v in pairs(TCPGearbox.serverConfig.config.sites.site) do 
        if tonumber(v.siteid) == tonumber(tableID) then 
            return v
        end
    end
    -- body
end

function UIGameTable:automodeCalback()
    self:PlayerCtrl_setAutoplay()
end


function UIGameTable:getLoginBuffer(tableType,friendID,RoomId) 
    printf('UIGameTable:getLoginBuffer tableType:%s,RoomLevel:%s self.isPaodekuai:%s',tableType,self.RoomLevel,self.isPaodekuai)
    local bufferHnd = DataPacker.new(UIGameTable.CMD['TABLE_LOGIN'])
    bufferHnd:writeData(G_UID,DataPacker.INT)
    bufferHnd:writeData(G_TOKEN,DataPacker.STRING)
    bufferHnd:writeData(tableType,DataPacker.INT) 
    bufferHnd:writeData(RoomId,DataPacker.INT) 
    bufferHnd:writeData(friendID,DataPacker.INT)

    if self.isPaodekuai == false then 
        bufferHnd:writeData(self.RoomLevel,DataPacker.INT) 
    end

     return bufferHnd:doPack()
 end

--[==[-------------------END OF TCP FUNCTIONS ---------------------]==]

function UIGameTable:onCreate(argTable)

-- Image_roomtype
-- Image_gamttype
	UIGameTable.isonEnterBackground = false
	UIGameTable.onEnterForGround = false
    self.globalMultiply = 2
    self.argTable = argTable or {}  
    self.tableType  = self.argTable.tableType    or -1
    self.friendID   = self.argTable.friendID     or -1
    self.RoomId     = self.argTable.RoomId       or -1
    self.RoomLevel  = self.argTable.RoomLevel    or 5
    self.isPaodekuai  = self.argTable.isPaodekuai    or false
    self.isWangPaiDDZ = self.argTable.isWangPaiDDZ  or false
    self.isFirstLoginReady = true 

    self.handCardLayer = self['Panel_cardlayout']
    self['Panel_cardlayout'].zorder = self['Panel_cardlayout']:getLocalZOrder()
    self.handCardTable = {}
    self:setupCardSelection()
    self.currentPlayerSeatID = nil
    self.lordSeatID = -1
    self.currentRoomState = UIGameTable.ROOM_STATE_IDLE 

    self.PlayerData = G_BASEAPP:getData('PlayerData')

    self['AtlasLabel_myCoins']:setString(LuaTools.convertAmountChinese(self.PlayerData.coin,10000))
    self['AtlasLabel_myDimonds']:setString(LuaTools.convertAmountChinese(self.PlayerData.gem,10000))
    self.unpackerType = DataUnpacker.Type.GAME
    self.tableName = 'UIGameTable TCP'
	self.port = self.argTable.port
    self.taskGameType =( self.isPaodekuai and 4 or 1 ) 
 
    if G_BASEAPP:getView({uiName = 'UIBroadcast', uiInstanceName = "forGameWanren"}) then 
        G_BASEAPP:removeView({uiName = 'UIBroadcast', uiInstanceName = "forGameWanren"})
    end   
 
    if self.isPaodekuai == true then 
        self.unpackerType = DataUnpacker.Type.GAME_Paodekuai
        self.tableName = 'UIGameTablePaodekuai TCP'
    end
    self.tcpGear = TCPGearbox.buildInstance({
            unpackerType = self.unpackerType, 
            delegate = self,  
            callbackPrefix = "TCP_",
            name = self.tableName,
            port = self.port-- argTable.port or DEFAULT_TCP_PORT
        })

    GameTableCommon.setupBasics( self ) 
    self:setButtonSoundStatus()    

    if self.PlayerData.isfirstLoginShow == 1 and self.isWangPaiDDZ  == false  and self.isPaodekuai == false  then 
       self['Panel_firstLoginShow']:setVisible(true)
    end     


    local function recruFunc()  
        self:addGobackEventAction(function() recruFunc() end) 
    end
    self:addGobackEventAction(function()
        recruFunc() 
    end)
end

function UIGameTable:onEnterBackground()
    -- cc.Director:getInstance():stopAnimation();
    if UIGameTable.isonEnterBackground == false and self and self.tcpGear then
        UIGameTable.isonEnterBackground = true
        -- self:resetTable()
        -- self:resetDisplayTable()
        local bufferHnd = DataPacker.new(UIGameTable.CMD['TABLE_DISCONNECT'])   
        self.tcpGear:sendData(bufferHnd:doPack()) 
        self.tcpGear:closeAndRelease() 
    end
end

function UIGameTable:onEnterForGround()
    -- cc.Director:getInstance():startAnimation();
	if UIGameTable.isonEnterBackground then
		UIGameTable.isonEnterBackground = false
		UIGameTable.onEnterForGround = true
		self.globalMultiply = 2
            self.tableType  = self.argTable.tableType    or -1
            self.friendID   = self.argTable.friendID     or -1
            self.RoomId     = self.argTable.RoomId       or -1
            self.RoomLevel  = self.argTable.RoomLevel    or 5
            self.isPaodekuai  = self.argTable.isPaodekuai    or false
            self.isWangPaiDDZ = self.argTable.isWangPaiDDZ  or false
            self.isFirstLoginReady = true 

            self.handCardLayer = self['Panel_cardlayout']
            self['Panel_cardlayout'].zorder = self['Panel_cardlayout']:getLocalZOrder()
            self.handCardTable = {}
            self:setupCardSelection()
            self.currentPlayerSeatID = nil
            self.lordSeatID = -1
            self.currentRoomState = UIGameTable.ROOM_STATE_IDLE 

            self.PlayerData = G_BASEAPP:getData('PlayerData')

            self['AtlasLabel_myCoins']:setString(LuaTools.convertAmountChinese(self.PlayerData.coin,10000))
            self['AtlasLabel_myDimonds']:setString(LuaTools.convertAmountChinese(self.PlayerData.gem,10000))
            self.unpackerType = DataUnpacker.Type.GAME
            self.tableName = 'UIGameTable TCP'
            self.port = self.argTable.port
            self.taskGameType =( self.isPaodekuai and 4 or 1 ) 
         
            if self.isPaodekuai == true then 
                self.unpackerType = DataUnpacker.Type.GAME_Paodekuai
                self.tableName = 'UIGameTablePaodekuai TCP'
            end
            self.tcpGear = TCPGearbox.buildInstance({
                    unpackerType = self.unpackerType, 
                    delegate = self,  
                    callbackPrefix = "TCP_",
                    name = self.tableName,
                    port = self.port-- argTable.port or DEFAULT_TCP_PORT
                })

            GameTableCommon.setupBasics( self ) 
            self:setButtonSoundStatus()    

            if self.PlayerData.isfirstLoginShow == 1 and self.isWangPaiDDZ  == false  and self.isPaodekuai == false  then 
               self['Panel_firstLoginShow']:setVisible(true)
            end     


            local function recruFunc()  
                self:addGobackEventAction(function() recruFunc() end) 
            end
            self:addGobackEventAction(function()
                recruFunc() 
            end)
			UIGameTable.onEnterForGround = false
        self:createSchedule("changeTableLockDown",function()
            self:stopSchedule("changeTableLockDown")
			
	
			-- local buffer = self:getLoginBuffer(self.tableType,self.friendID,self.RoomId)
			-- self.tcpGear:sendData(buffer) 
		end,1)
		
	end
end

function UIGameTable:hideFirstLoginShow() 
   self['Panel_firstLoginShow']:setVisible(false)   
end     

function UIGameTable:setButtonSoundStatus()
    self["Button_pass"]:setDontPlayDefaultSFX(true)
    self["Button_hint"]:setDontPlayDefaultSFX(true)
    self["Button_reset"]:setDontPlayDefaultSFX(true)
    self["Button_playcard"]:setDontPlayDefaultSFX(true)
    self["Button_wantlord"]:setDontPlayDefaultSFX(true)
    self["Button_dont_wantlord"]:setDontPlayDefaultSFX(true)
    self["Button_doublebet"]:setDontPlayDefaultSFX(true)
    self["Button_dont_doublebet"]:setDontPlayDefaultSFX(true)
    self["Button_dont_grab_lord"]:setDontPlayDefaultSFX(true)
    self["Button_grab_lord"]:setDontPlayDefaultSFX(true)
    self["Button_dont_call_lord"]:setDontPlayDefaultSFX(true)
    self["Button_call_lord"]:setDontPlayDefaultSFX(true)
end

function UIGameTable:updateMyMoney(coin,gem)
    self['AtlasLabel_myCoins']:setString(LuaTools.convertAmountChinese(coin,10000))
    self['AtlasLabel_myDimonds']:setString(LuaTools.convertAmountChinese(gem,10000))
end 
---------------------------------------------------------------------------

return UIGameTable
