
-- 0 - disable debug info, 1 - less debug info, 2 - verbose debug info
DEBUG =0


-- use framework, will disable all deprecated API, false - use legacy API
CC_USE_FRAMEWORK = true

G_USE_DEBUG_PANEL = false
-- show FPS on screen
CC_SHOW_FPS = false

-- disable create unexpected global variable
CC_DISABLE_GLOBAL = false

G_SERVER_CONFIG =
{

	ONLINE_SERVER_ADDR	= 
	{
		addr = 'http://ddz.217play.com:17179/',--'http://114.67.59.58:17179/'	,  
        paySeverAddr ='http://ddz.217play.com:9090/',--'http://114.67.59.58:9090/',
		ver = 'live'
	},
	DEV_SERVER_ADDR 	= 
	{
		addr = 'http://183.61.183.197:17179/', 
        paySeverAddr ='http://183.61.183.197:9090/',
		ver = 'dev'
	}
}

G_SELECTED_SERVER_CONFIG = G_SERVER_CONFIG['ONLINE_SERVER_ADDR'] 
G_IF_FORCE_UPDATE = true    --是否强制热更    

  
DEFAULT_HTTP_URL = G_SELECTED_SERVER_CONFIG.addr 
SHARED_KEY="0391591aafc5db68b08787645b837b4f"--'0391591aafc5db68b08787645b837b4f'
DEFAULT_TCP_ADDRESS ='113.105.142.170'  --'192.168.0.221'
DEFAULT_TCP_PORT = 18700
G_TOKEN = ''
G_IMIP = ''
G_UID = ''


G_CHANNELID ='yztest' --'yztest'--'dchc_gdt_07' --'lzw_gdt_04'--'ljf_gdt_04'--'988wan_01'--  wp_baidu_01 




G_VERSION = '3.0.0000(4592)' 
G_CURVER = 10026

-- BASE VER:3640vg   
VERNAME = 300000--apk下载标示
G_WRITE_LOG_TO_DEVICE = false
G_WRITE_LOG_TO_DEVICE_ENCRYPT = false
G_WRITE_LOG_SDCARD = false
G_PAYINFO = {}
G_SIGN_WN = 
[[  

                  ____ __   _    ______   ____   ______  ____    __   __   ___  ___  __ 
                / ___ |  \_/ \  /_   _/  / ___\ /  ___ \/ __ \  /  \_/  / /   //   ||  |
               / /__/ | |\_/| \___| |___/ /____/  /__/ / /__\ \/  /\   / /   //    ||  |
               \______|_|   |_/\________\_____/__/  _\_\______/__/__\_/ /   //     ||  |
                            /  _  \  /  /  _____\  /  _____\  / ______ \\   \\     ||  |
                           /  / \  \/  /  ____]___/  /____--\/ /__  __\ \\   \\    ||  |
                          /__/   \____/\_________/\_________/\___/  \___/ \___\\___||__|
                                                                                   ©2016

                                                                                   
]] 

G_CHANNEL_CONFIG = {
	
}

JAVAMETHODCONFIG = 	{['getCurrentNetworkType']                  = "getCurrentNetworkType",--默认可调用Java中静态方法集合,配置方法Java中方法必须存在，否则会崩溃
					 ["openURL"]                                = "openURL",
					 ["getAvatar"]                              = "getAvatar",
					 ["getAvatars"]                             = "getAvatars",
					 ["getBatteryStatus"]                       = "getBatteryStatus",
					 ["listFiles"]                              = "listFiles",
					 ["getAllInfomationYouNeeded"]              = "getAllInfomationYouNeeded",
					 ["registerBatteryCallback"]                = "registerBatteryCallback",
					 ["registerNetworkCallback"]                = "registerNetworkCallback",
					 ["unregisterNetworkCallback"]              = "unregisterNetworkCallback",
					 ["unregisterBatteryCallback"]              = "unregisterBatteryCallback",
					 ["getAndroidRoot"]                         = "getAndroidRoot",
					 ["openWebURL"]                             = "openWebURL",
					 ["dialPhone"]                              = "dialPhone",
					 ["shares"]                                 = "shares",
					 ["copyToClipboard"]                        = "copyToClipboard",
					 ["restartApplication"]                     = "restartApplication",
					 ["getChannelID"]                           = "getChannelID",
					 ["getPackNames"]                           = "getPackNames",
					 ["SDKSetup"]                               = "SDKSetup",
					 ["SDKLogin"]                               = "SDKLogin",
					 ["SDKDoAds"]                               = "SDKDoAds",
					 ["SDKPay"]                                 = "SDKPay",
					 ["SDKExitGame"]                            = "SDKExitGame",
					 ["SDKShare"]                               = "SDKShare",
					 ["thirdSDKDoLogin"]                        = "thirdSDKDoLogin",
					 ["thirdSDKDoPay"]                          = "thirdSDKDoPay",
					 ["thirdSDKInit"]                           = "thirdSDKInit",
					 ["thirdSDKExitGame"]                       = "thirdSDKExitGame",
					 ["thirdSDKShowAdv"]                        = "thirdSDKShowAdv"
					 }

					 
--友盟统计界面打开次数需要友盟事件中设置才能生效					 
UMENGUICOUNT = {["UIActivity"]              = 1,--活动界面
			  ["UIAddFriend"]               = 1,--添加好友界面
			  ["UIAwards"]                  = 1,--大奖赛场外界面
			  ["UIChat"]                    = 1,--消息窗口
			  ["UIFriend"]                  = 1,--好友界面
			  ["UIFriendBrief"]             = 1,--用户信息
			  ["UIFriendWeddingRoom"]       = 1,--婚礼界面
			  ["UIFund"]                    = 1,--王牌基金
			  ["UIGameTable"]               = 1,--55张斗地主界面
			  ["UIGameTableAwards"]         = 1,--比赛场场内
			  ["UIGameTableClassic"]        = 1,--54张斗地主
			  ["UIGameTableDouniu"]         = 1,--5人牛牛
			  ["UIGameTablePaodekuai"]      = 1,--跑得快场内
			  ["UIGameTableSanzhang"]       = 1,--三张牌
			  ["UIGameTableWanren"]         = 1,--万人牛牛
			  ["UIGiftExchange"]            = 1,--打开兑换界面
			  ["UILottery"]                 = 1,--大转盘
			  ["UIMail"]                    = 1,--消息
			  ["UIMain"]                    = 1,--大厅
			  ["UIMatchPrivate"]            = 1,--私人房
			  ["UIMatchRoomDDZBooms"]       = 1,--斗地主55房间
			  ["UIMatchRoomDDZClassic"]     = 1,--斗地主54房间
			  ["UIMatchRoomDouniuZJH"]      = 1,--斗牛和扎金花房间
			  ["UIMatchRoomRunFast"]        = 1,--跑得快房间
			  ["UIPackage"]                 = 1,--限时礼包
			  ["UIProfileMain"]             = 1,--个人信息
			  ["UIRank"]                    = 1,--排行榜
			  ["UIRedeemPoints"]            = 1,--赢积分兑大奖
			  ["UIRegistration"]            = 1,--签到界面
			  ["UISetting"]                 = 1,--设置界面
			  ["UIShop"]                    = 1,--商城
			  ["UISpree"]                   = 1,--幸运大礼包
			  ["UIShopDiamond"]             = 1,--充值界面
			 -- ["UILoading"]                 = 1,--充值界面
			  ["UITask"]                    = 1--每日任务
			  }
	  