
local AppBase = class("AppBase")
local textureCache = cc.Director:getInstance():getTextureCache()
AppBase.lastAddedView = DataStructures.Stacqueue.new("AppBase_addedViewQueue") 
AppBase.views = {}
AppBase.RootScene = G_ROOTSCENE



function AppBase:ctor(configs)
    -- print('==============================>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.AppBase:ctor')
    self.configs_ = {
        viewsRoot  = "app.views",
        widgetsRoot = "app.widgets",
        dataRoot = "app.data",
        modelsRoot = "app.models",
        defaultSceneName = "UIShop",
    }

    for k, v in pairs(configs or {}) do
        self.configs_[k] = v
    end

    if type(self.configs_.viewsRoot) ~= "table" then
        self.configs_.viewsRoot = {self.configs_.viewsRoot}
    end 
    if type(self.configs_.widgetsRoot) ~= "table" then
        self.configs_.widgetsRoot = {self.configs_.widgetsRoot}
    end
    if type(self.configs_.modelsRoot) ~= "table" then
        self.configs_.modelsRoot = {self.configs_.modelsRoot}
    end
    if type(self.configs_.dataRoot) ~= "table" then
        self.configs_.dataRoot = {self.configs_.dataRoot}
    end
    
    self._views = AppBase.views

    if DEBUG > 1 then
        dump(self.configs_, "AppBase configs")
    end

    if CC_SHOW_FPS then
        cc.Director:getInstance():setDisplayStats(true)
    end

    -- event
    self:onCreate()
end





function AppBase:run(initSceneName, ...)
    initSceneName = initSceneName or self.configs_.defaultSceneName
    self:enterScene(initSceneName, ...)
end

function AppBase:addViewEX()
    -- body
    -- self.
end

function AppBase:addView(name, zOrder, ...)
    
    local uiName11, uiInstanceName22 = self:checkName(name) 
    printf("====>>>>adding view:%s<<<<====",uiName11)
    local view = self:getView(name) 
    if view then
        dump(name)
        printWarning('↑↑↑↑↑↑↑该VIEW已存在，将返回已存在的实例。') 
        return view 
    end 
    local uiName, uiInstanceName = self:checkName(name)   
    if uiName then
        printf("[[[[[[[[[[[[[[CREATING %s ...........",uiName)

        -- local view = {name_="VIEW_IS_LOADING_FOR_"..uiName.."_POS_"..(AppBase.lastAddedView:getSize()+1)}
        
        -- printf("[[[SSSIIIZZEEE:%s",AppBase.lastAddedView:getSize())
        -- AppBase.lastAddedView:enqueue(view)
        -- printf("[[[SSSIIIZZEEE:%s AFTER",AppBase.lastAddedView:getSize())
        -- print('=======================before ('..uiName..') ADDING VIEW======================')
        -- AppBase.lastAddedView:iterator( function(k,v)
                -- printf("k:%s,v:%s,(%s)",k,v,v.name_)
            -- end )
        -- local currPos =   AppBase.lastAddedView:getSize()  
        local view = self:createView(uiName, ...)
        -- AppBase.lastAddedView:setItemAt(currPos,view)
		
		--友盟统计打开界面
		if UMENGUICOUNT[uiName] then
			local sendumeng = {}
			sendumeng['type'] = 'event'
			sendumeng['eventId'] = string.lower(uiName)
			LuaTools.setUmeng(sendumeng)
		end
		

        printf("[[[[[[[[[[[[[[[%s CREATED!",uiName)
        view.uiName=uiName
        view.uiInstanceName=uiInstanceName
        G_ROOTSCENE:add(view, zOrder)
        AppBase.views[uiName..uiInstanceName] = view
        AppBase.lastAddedView:enqueue(view)

        --local str = cc.Director:getInstance():getTextureCache():getCachedTextureInfo()
        --print('&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&')
        --print("ggg" .. str)
        --print('=======================after ADDING VIEW======================')
        AppBase.lastAddedView:iterator( function(k,v)
                printf("k:%s,v:%s,(%s)",k,v,v.name_)
            end )
		--cc.Director:getInstance():getTextureCache():removeUnusedTextures()
		--cc.Director:getInstance():getTextureCache():dumpCachedTextureInfo()  

        -- self:rearrangeBackCallbacks()
        return view
    end

end
function AppBase:createView(name, ...)
    for _, root in ipairs(self.configs_.viewsRoot) do
        local packageName = string.format("%s.%s", root, name)
        print("addView packageName")
        print(packageName)
            
        local status, view = xpcall(
            function()
                -- _G['package']['loaded'][packageName] = nil 
                unrequire(packageName)
                return require(packageName)
            end, 
            
            function(msg)
                if not string.find(msg, string.format("'%s' not found:", packageName)) then
                    print("load view error: ", msg)
                end
            end
        )
		
        local t = type(view)
        if status and (t == "table" or t == "userdata") then
            return view:create(self, name, ...)
        end
    end
    error(string.format("AppBase:createView() - not found view \"%s\" in search paths \"%s\"",
        name, table.concat(self.configs_.viewsRoot, ",")), 0)
end

function AppBase:checkName(name) 
    local uiName
    local uiInstanceName = ""
 
    if type(name) == "string" then
        uiName = name
    elseif type(name) == "table" then 
        uiName = name.uiName
        uiInstanceName = name.uiInstanceName  
    else--view
        uiName = name.uiName
        uiInstanceName = name.uiInstanceName   
    end
    return uiName,uiInstanceName
end

 
 

function AppBase:getView(name) 

    local uiName, uiInstanceName = self:checkName(name)  
    -- printf("getView=>uiName:%s,uiName:%s",uiName, uiInstanceName )
    if uiName then
        local ret =  AppBase.views[uiName..uiInstanceName]
        if tolua.isnull(ret) == false then
            return ret
        else
            AppBase.views[uiName..uiInstanceName] = nil
        end
    end
end

-- function AppBase:rearrangeBackCallbacks()
--     print("rearrangeBackCallbacks")
--     AppBase.lastAddedView:iterator( function(k,v)
--             printf("k:%s,v:%s,(%s)",k,v,v:getName())
--             local view = AppBase.lastAddedView:getItemAt(k)

--             view.lastBackCallbackStatus = view:isBackCallbackEnabled()
--             if view:isForceEnableBack() ~= true and view:isBackInited() == true then
--                 view:enableBack(false)
--             end 
--     end )
--     local lastView = AppBase.lastAddedView:getItemAt(AppBase.lastAddedView:getSize())
--     if lastView.lastBackCallbackStatus == true and lastView:isBackInited() then
--         lastView:enableBack(true)
--     end 
--     -- isForceEnableBack() 
--     -- body
-- end

function AppBase:removeView(_view) 

    local view = self:getView(_view)  
    -- printf("removeView=>getView:%s,",view)
    if view then
        local uiName, uiInstanceName = self:checkName(_view) 
        -- self:removeViewFromPool( view )
        -- self.goBackActionQueue:clear()
        local t = AppBase.lastAddedView:getItemIndexies(view)
        if t[1] then
            AppBase.lastAddedView:removeAt(t[1])
        end 
        AppBase.views[uiName..uiInstanceName] = nil
		view:removeAllChildren(true)
        view:removeFromParent()
		ccs.GUIReader:destroyInstance()--清理ＧＵＩ管理类
		--ccs.SceneReader:destroyInstance()--清理场景管理
		ccs.ActionManagerEx:destroyInstance()--清理动作
		textureCache:removeAllTextures()--释放掉不用的纹理
		--cc.SpriteFrameCache:getInstance():removeUnusedSpriteFrames()
		textureCache:removeUnusedTextures()--将引用计数器为1的图片释放掉
		--cc.Director:getInstance():getTextureCache():dumpCachedTextureInfo()  
		--local str = cc.Director:getInstance():getTextureCache():getCachedTextureInfo()
       -- print('&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&')
        --print("ggg" .. str)
					
    end  
end

function AppBase:createWidget(name, ...)
    for _, root in ipairs(self.configs_.widgetsRoot) do
        local packageName = string.format("%s.%s", root, name)
        local status, widget = xpcall(function()
            return require(packageName)
        end, function(msg)
            if not string.find(msg, string.format("'%s' not found:", packageName)) then
                print("load widget error: ", msg)
            end
        end)
        local t = type(widget)
        if status and (t == "table" or t == "userdata") then
            return widget:create(self, name, ...)
        end
    end
    error(string.format("AppBase:createWidget() - not found widget \"%s\" in search paths \"%s\"",
        name, table.concat(self.configs_.widgetsRoot, ",")), 0)
    --printWarning('警告！ 方法 AppBase:createWidget 即将作废,请使用 createView 代替。') 
end

function AppBase:createModel(name, ...)
    for _, root in ipairs(self.configs_.modelsRoot) do
        local packageName = string.format("%s.%s", root, name)
        local status, model = xpcall(function()
                return require(packageName)
            end, function(msg)
            if not string.find(msg, string.format("'%s' not found:", packageName)) then
                print("load model error: ", msg)
            end
        end)
        local t = type(model)
        if status and (t == "table" or t == "userdata") then
            return model:create(self, name, ...)
        end
    end
    error(string.format("AppBase:createModel() - not found model \"%s\" in search paths \"%s\"",
        name, table.concat(self.configs_.modelsRoot, ",")), 0)
    --printWarning('警告！ 方法 AppBase:createModel 即将作废,请使用 createView 代替。') 
end

function AppBase:createData(name, ...)
    for _, root in ipairs(self.configs_.dataRoot) do
        local packageName = string.format("%s.%s", root, name)
        local status, data = xpcall(function()
                return require(packageName)
            end, function(msg)
            if not string.find(msg, string.format("'%s' not found:", packageName)) then
                print("load data error: ", msg)
            end
        end)
        local t = type(data)
        if status and (t == "table" or t == "userdata") then
            return data:create(self, name, ...)
        end
    end
    error(string.format("AppBase:createData() - not found data \"%s\" in search paths \"%s\"",
        name, table.concat(self.configs_.dataRoot, ",")), 0)
    --printWarning('警告！ 方法 AppBase:createData 即将作废,请使用 createView 代替。') 
end

function AppBase:enumerateScene(handle, ...)
    -- for key, var in ipairs(self.scenes_) do
    --     handle(var, ...)
    -- end
end

function AppBase:enumerateView(scene, handle, ...)
    -- for key, var in pairs(self._views[scene] or {}) do
    --     if scene:getChildByName(key) then
    --         handle(var, ...)
    --     end
    -- end
end

function AppBase:callMethod(name, method, ...)
    printWarning(' 警告！ 方法 AppBase:callMethod 即将作废,请使用实例自行调用实例成员函数。') 
    local result = false
 
    local view = self:getView(name) 
    if view then
        if view[method] and type(view[method]) == 'function' then
            result = true
            view[method](view,...)
        end 
    end 
    return result
end

function AppBase:onCreate()
end

return AppBase
