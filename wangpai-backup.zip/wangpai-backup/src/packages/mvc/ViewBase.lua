
local ViewBase = class("ViewBase", cc.Node )
local spriteFrameCache = cc.SpriteFrameCache:getInstance()
local textureCache = cc.Director:getInstance():getTextureCache()

local scheduler = cc.Director:getInstance():getScheduler()
ViewBase.backCallbackPriority = 0
function ViewBase:onEnter()
end


function ViewBase:onExit()
    -- if self.myBackCallbackPriority ~= nil then
    --     self.myBackCallbackPriority = nil 
    --     ViewBase.backCallbackPriority = ViewBase.backCallbackPriority-1
    --     printf("reduced %s to %s",ViewBase.backCallbackPriority+1,ViewBase.backCallbackPriority)
    -- end
    -- G_BASEAPP.lastAddedView:dump()
end


function ViewBase:onEnterTransitionFinish()

end

-- function ViewBase:setBackCallback( callback )
--     if callback and type(callback) == 'function' then
--          self.doBackcallback = callback
--     end 
-- end

-- function ViewBase:isBackCallbackEnabled() 
--     return self.backButtonEnabled or false
-- end

-- function ViewBase:isBackInited()
--     return self.backInited or false
-- end

-- function ViewBase:isForceEnableBack() 
--     return self.fEnableBack or false
-- end

-- function ViewBase:forceEnableBack(enable)
--     self.fEnableBack = enable
-- end

-- function ViewBase:enableBack(enable,callback)

--     self:setBackCallback( callback )

--     -- if enable == true then 
--     --     ViewBase.backCallbackPriority= ViewBase.backCallbackPriority+1 
--     --     printf("ViewBase.backCallbackPriority is set to %s",ViewBase.backCallbackPriority)
--     --     self.myBackCallbackPriority =  ViewBase.backCallbackPriority
--     --     printf("%s Priority is set to %s",self.name_,self.myBackCallbackPriority)
--     -- end

--     if self.backButtonEnabled ~= true and enable == true then
--         self.backButtonEnabled  = true
--         self.backInited = true
--         if self.onKeyDown == nil then
--             self.onKeyDown = function(keyCode, event) 
--                 if keyCode == cc.KeyCode.KEY_BACK or keyCode == 7 then
--                     if self.doBackcallback and type(self.doBackcallback) == 'function' then
--                         -- print("curr:",ViewBase.backCallbackPriority,self.name_,self.myBackCallbackPriority)
--                         -- if  self.myBackCallbackPriority ==  ViewBase.backCallbackPriority then
--                             self.doBackcallback()
--                         -- end
--                     end
--                 end
--             end 
--         end


--         if self.backListener == nil then 
--             self.backListener = cc.EventListenerKeyboard:create()
--             self.backListener:registerScriptHandler(self.onKeyDown, cc.Handler.EVENT_KEYBOARD_RELEASED )  
--             self:getEventDispatcher():addEventListenerWithSceneGraphPriority(self.backListener, self)
--         end

--         return
--     end 

--     if enable == false then 
--         -- ViewBase.backCallbackPriority= ViewBase.backCallbackPriority-1
--         -- self.myBackCallbackPriority = nil
--         self.backButtonEnabled = nil 
--         return 
--     end

  
-- end

function ViewBase:onExitTransitionStart()
end

function ViewBase:addGobackEventAction(callback)
    -- body
    -- return nil
    self.goBackActionQueue:enqueue(callback)
end

function ViewBase:getGoBackActionQueue()
    return self.goBackActionQueue
end
 


function ViewBase:setLockGoback(isLock )
    self.isLockGoback = isLock
end

function ViewBase:ctor(app, name, ...)



    self.goBackActionQueue = DataStructures.Stacqueue.new("AppBase_goBackActionQueue","function")

    -- G_BASEAPP.lastAddedView:dump()

--    self:enableNodeEvents()
    self.isSkipped = false
    self:onNodeEvent("cleanup", self.onCleanupCallback)


    self:onNodeEvent("enter", self.onEnter)
    self:onNodeEvent("exit", self.onExit)
    self:onNodeEvent("enterTransitionFinish", self.onEnterTransitionFinish)
    self:onNodeEvent("exitTransitionStart", self.onExitTransitionStart) 
	
    local eventDispatcher = cc.Director:getInstance():getEventDispatcher()
    local customListenerBg = cc.EventListenerCustom:create("APP_ENTER_BACKGROUND_EVENT",
                                handler(self, self.onEnterBackground))
	local customListenerFg = cc.EventListenerCustom:create("APP_ENTER_FOREGROUND_EVENT",
                                handler(self, self.onEnterForGround))
    eventDispatcher:addEventListenerWithFixedPriority(customListenerBg, 1) 
    eventDispatcher:addEventListenerWithFixedPriority(customListenerFg, 1) 
	

    self.app_ = app
    self.name_ = name
--    self:setName(name)

    self.models_ = {}
    self.schedule_ = app:getModel("Schedule")
--[[
    -- check CSB resource file
    local res = rawget(self.class, "RESOURCE_FILENAME")
    if res then
        self:createResoueceNode(res)
    end

    local binding = rawget(self.class, "RESOURCE_BINDING")
    if res and binding then
        self:createResoueceBinding(binding)
    end

    if self.onCreate then self:onCreate(...) end

    local loading = self:getLoadingResource()
    if loading then
        self:createResoueceLoading(loading)
    end

    self:handleMessage()
--]]
---[[
    local preloading = rawget(self.class, "RESOURCE_PRELOADING")
    if not preloading then
        self:load(...)
    else
        local temp = {}

        for key, var in ipairs(preloading) do
            temp[var] = {["callback"] = "preLoadingCallback"}
        end
        
        self.preloading = temp

        self.arg = {...}

        self:createResoueceLoading(temp)
    end
--]]



    -- self:enableBack(true,function()
    --     print('enableBack name:',name)
    --     end)

end

function enumerateChilren(node,_callback) 
    local c = node:getChildren()
    for i=1,#c do
        enumerateChilren(c[i],_callback) 
        _callback(c[i]:getName(),c[i])
    end
end

function ViewBase:onEnterBackground()
end

function ViewBase:onEnterForGround()
end

function ViewBase:findChildByName(_name)
    print("looking child",_name)
    enumerateChilren(self,function(name,node)
        print('name:',name,"_name")
        if _name == name then

            print('child found:',name)
            return node
        end
    end) 
end

function ViewBase:setRawStuff()   
    -- getChild("blah")
    local prevMt = getmetatable(self.class)
    local prevIdx = rawget(self.class, "__index")
    local findChildByName = self.enumerateChildren 

    prevMt.__index = prevMt
    if prevMt.__supers == nil  then

        -- dump(self,"self")
        -- dump(tolua.getpeer(self),"tolua.getpeer(self)")
        -- dump(prevMt,"prevMt")
        -- dump(self.class,"self.class")
        -- dump(self.super,"self.super")
        -- print("self type:",tolua.type(self))
        -- print('self.class.__supers == nil') 
        prevMt.__index = prevMt.super
    else
        print('else')   
        prevMt.__index =   
        function(_, key)
            if self.class == nil then
                dump(self,"self")
                dump(tolua.getpeer(self),"tolua.getpeer(self)")
                dump(prevMt,"prevMt")
                dump(self.class,"self.class")
                dump(self.super,"self.super")
                print("self type:",tolua.type(self))
                print('self.class.__supers == nil')
            end
            local supers = prevMt.__supers
            for i = 1, #supers do
                local super = supers[i]
                if super[key] then  
                    return super[key]  
                else
                    local ret 
                    findChildByName(self,"//"..key,function(node)  
                        ret = node
                    end) 
                    return ret
                end 
            end
        end
    end

    setmetatable(self.class,prevMt)  
end

function ViewBase:bindStuff(name)
    self[name] = self:seekChild(name)
end

function ViewBase:seekChild(name)
    local ret 
    self:enumerateChildren("//"..name,function(node)  
        ret = node
    end) 
    return ret
end

function ViewBase:setSkipGoBack( _b )
    self.isSkipped = _b
end
function ViewBase:getSkipGoBack( )
    return self.isSkipped
end

function ViewBase:preLoadingCallback(path, names, texture)
    self.preloading[path] = nil

    if table.isEmpty(self.preloading) then
        self:load(unpack(self.arg))
    end
end

function ViewBase:load(...)
    self:setName(self.name_)

    -- check CSB resource file
    -- dump(self.class,'self.class')
    local res = rawget(self.class, "RESOURCE_FILENAME")
    if res then
        self:createResoueceNode(res)
    end
    
    -- self:setRawStuff() 
    if self.onCreate then self:onCreate(...) end

    local binding = rawget(self.class, "RESOURCE_BINDING")
    if res and binding then
        self:createResoueceBinding(binding)
    end

    local loading = self:getLoadingResource()
    if loading then
        self:createResoueceLoading(loading)
    end
    local size = cc.Director:getInstance():getWinSize()
    --printError('size.width:%d,size.height:%d',size.width,size.height)
    self.resourceNode_:setContentSize(size)
    self:setContentSize(size)
    
    ccui.Helper:doLayout(self.resourceNode_)
    -- self.app_:handleMessage(self)
end

function ViewBase:getApp()
    return self.app_
end

function ViewBase:getName()
    return self.name_
end

function ViewBase:getResourceNode()
    return self.resourceNode_
end

function ViewBase:setResourceNode(resourceNode)
    if self.resourceNode_ then
        self.resourceNode_:removeSelf()
        self.resourceNode_ = nil
    end

    self.resourceNode_ = resourceNode
end

function ViewBase:removeSelf()
    self.app_:removeView(self) 
end 
function ViewBase:eventCallFunc(sender)
    local name = sender:getCallbackName()

    self[name] = sender
    self.widgets_[name] = sender

    local temp = self
    function sender:removeSelf()
        self:removeFromParent()
        
        local suffix = name:match("%a+_(.+)")
        for key, var in pairs(temp.widgets_) do
            if key:match("(%a+)_" .. suffix .. ".*") then
                temp[key] = nil
                temp.widgets_[key] = nil
            end
        end
    end
end

function ViewBase:createResoueceNode(resourceFilename)
    if self.resourceNode_ then
        self.resourceNode_:removeSelf()
        self.resourceNode_ = nil
    end
    
    self.widgets_ = {}
    
    ScriptHandlerMgr:getInstance():registerScriptHandler(self, handler(self, self.eventCallFunc), cc.Handler.CALLFUNC)

    local function overrideUIButtonEnable(button)
        if button and tolua.type(button) == 'ccui.Button' then 
            button.___ButtonSFX = Sound.SoundTable['sfx']['Button'] 
            button.setButtonSFX = function(button,sfx)
                button.___ButtonSFX = sfx
            end
            button.___setEnabled = button.setEnabled 
            button.setEnabled = function(instance,b) 
                button.___setEnabled(instance,b) 
                local str = "["..button:getName().."] has following children:\n"
                local state = nil 
                if b == true then  
                    button.___GLstate = LuaTools.getShaderState() 
                else 
                    button.___GLstate = LuaTools.getShaderState('shaders/GreyScale.fsh') 
                end
                if button.___updateScheduler == nil then 
                    local function update(dt) 
                        LuaTools.setShaderOnUIWiget( button , button.___GLstate )
                    end 
                    button.___updateScheduler = scheduler:scheduleScriptFunc(update, 0.05, false)
                end
                if button.___nodeEventListner == nil then 
                    button.___nodeEventListner = function(event)
                        -- printf('####################### button:%s',event)
                        if "exitTransitionStart" == event and button.___updateScheduler then 
                            scheduler:unscheduleScriptEntry(button.___updateScheduler)
                            button.___updateScheduler = nil
                            button.___nodeEventListner = nil
                        end
                    end
                    if button.___nodeEventListner then 
                        button:registerScriptHandler(button.___nodeEventListner)
                    end
                end 
            end
        end
    end


    print('ViewBase:createResoueceNode:',resourceFilename)
    self.resourceNode_ = cc.CSLoader:createNode(resourceFilename,function(obj)
            self[obj:getName()] = obj
            overrideUIButtonEnable(obj)
            if obj and tolua.type(obj) == 'ccui.ListView' then
                obj:setScrollBarEnabled(false)
            end
            -- printf("loading %s",obj:getName())
    end)
    assert(self.resourceNode_, string.format("ViewBase:createResoueceNode() - load resouce node from file \"%s\" failed", resourceFilename))
    self:add(self.resourceNode_)
end

function ViewBase:genResoueceBindingCallback(var,widget, ...)
    local arg = {...}

    return function(event) 
    printf()
        if event.name == 'began' then
            if widget.___ButtonSFX and widget.dontPlayDefaultSFX ~= true then
                audio.playSound(widget.___ButtonSFX, false)
            end
        end
        if var[event.name] and self[var[event.name]] then

            self[var[event.name]](self, event, unpack(arg))
        end
    end
end

local event = {
    ["began"] = "onTouch",
    ["moved"] = "onTouch",
    ["ended"] = "onTouch",
    ["cancelled"] = "onTouch",
    
    ["TURNING"] = "onEvent",

    ["ON_SELECTED_ITEM_START"] = "onEvent",
    ["ON_SELECTED_ITEM_END"]   = "onEvent",
    
    ["ON_PERCENTAGE_CHANGED"]  = "onEvent",


    ["ATTACH_WITH_IME"] = "onEvent",
    ["DETACH_WITH_IME"] = "onEvent",
    ["INSERT_TEXT"]     = "onEvent",
    ["DELETE_BACKWARD"] = "onEvent",

    ["SCROLL_TO_TOP"] = "onScroll",
    ["SCROLL_TO_BOTTOM"] = "onScroll",
    ["SCROLL_TO_LEFT"] = "onScroll",
    ["SCROLL_TO_RIGHT"] = "onScroll",
    ["SCROLLING"] = "onScroll",
    ["BOUNCE_TOP"] = "onScroll",
    ["BOUNCE_BOTTOM"] = "onScroll",
    ["BOUNCE_LEFT"] = "onScroll",
    ["BOUNCE_RIGHT"] = "onScroll",
    
    
    
}

function ViewBase:createResoueceBinding(binding)
    assert(self.resourceNode_, "ViewBase:createResoueceBinding() - not load resource node")
--[[
    for nodeName, nodeBinding in pairs(binding) do
        local node = self.resourceNode_:getChildByName(nodeName)
        if nodeBinding.varname then
            self[nodeBinding.varname] = node
        end
        for _, event in ipairs(nodeBinding.events or {}) do
            if event.event == "touch" then
                node:onTouch(handler(self, self[event.method]))
            end
        end
    end
--]]

    for widget, callback in pairs(binding) do        
        if self[widget] then
            for key, var in pairs(callback) do
                --printInfo("[ViewBase:createResoueceBinding] event[key] = %s",event[key])

                if self[widget][event[key]] then
                    self[widget][event[key]](self[widget], self:genResoueceBindingCallback(callback,self[widget]))
                    if key== 'ON_SELECTED_ITEM_START' or key == 'ON_SELECTED_ITEM_END' then 
                        self[widget]:setScrollBarEnabled(false)  
                    end     
                end
            end
        end
    end
end

local widgetLoadImage = {["ImageView"] = "loadTexture", ["Layout"] = "setBackGroundImage"}
function ViewBase:genResoueceLoadingCallback(path, config)
    return function(texture)
        for key, var in pairs(config.names or {}) do
            if not self[var].getDescription then
                printf('self[%s]:%s(%s)',var,self[var],tolua.type(self[var]))
                printError("")
            end
            local description = self[var]:getDescription()

            if self[var][widgetLoadImage[description]] then
                self[var][widgetLoadImage[description]](self[var], path)
            end
        end

        if config.callback and self[config.callback] then
            self[config.callback](self, path, config.names, texture, config.parameter)
        end

--        local waiting = self.app_:getView("UIWaiting")
--    
----        assert(waiting,"[ViewBase:genResoueceLoadingCallback]")
--
--        if waiting then
--            waiting:increaseCount()
--    
--            if waiting:isCompleted() then
--                waiting:removeSelf()
--            end
--        end
    end
end

function ViewBase:createResoueceLoading(loading)
--    assert(self.resourceNode_, "ViewBase:createResoueceLoading() - not load resource node")
    
    if table.isEmpty(loading) then
    	return
    end
    
--    local waiting = self.app_:getView("UIWaiting")
--    if waiting then
--        waiting:setCountAndTotal(waiting:getCount(), waiting:getTotal() + table.nums(loading))
--    else
--        waiting = self.app_:addView("UIWaiting", 65535)
--        waiting:setCountAndTotal(0, table.nums(loading))
--    end
    
    for key, var in pairs(loading) do
        textureCache:addImageAsync(key, self:genResoueceLoadingCallback(key, var))
    end
end

function ViewBase:getLoadingResource()
    self["RESOURCE_LOADING"] = self["RESOURCE_LOADING"] or {}

    table.merge(self["RESOURCE_LOADING"], rawget(self.class, "RESOURCE_LOADING") or {})

    return self["RESOURCE_LOADING"]
end

function ViewBase:getPreloadingResource()
    return rawget(self.class, "RESOURCE_PRELOADING")
end

function ViewBase:addAsynchronousResource(config)
    local loading = self:getLoadingResource(config)
    
    table.merge(loading, config)
end

function ViewBase:addModel(name, ...)
    if self.models_[name] == nil then
        self.models_[name] = self.app_:createModel(name, ...)
    end

    return self.models_[name]
end

function ViewBase:getModel(name)
    return self.models_[name]
end

function ViewBase:removeModel(name)
    self.models_[name] = nil
end

function ViewBase:getSchedule(name)
    return self.schedule_:getSchedule(self, name)
end

function ViewBase:createSchedule(name, handler, interval, duration)
    return self.schedule_:addSchedule(self, name, handler, interval, duration)
end

function ViewBase:stopSchedule(name)
    self.schedule_:stopSchedule(self, name)
end

function ViewBase:searchPreloadingResource(preloading)
    local remove = clone(preloading)

    local function searchView(view)
        local temp = view:getPreloadingResource()
        if temp then
            for key, var in pairs(preloading) do
                for k, v in pairs(temp) do
                    if var == v then
                        remove[key] = nil
                    	break
                    end
                end
            end
        end
    end
    
    local function searchScene(scene)
        self.app_:enumerateView(scene, searchView)
    end
    
    self.app_:enumerateScene(searchScene)
    
    -- for key, var in ipairs(remove) do
    --     spriteFrameCache:removeSpriteFramesFromFile((var:gsub(".png", ".plist")))
    --     textureCache:removeTextureForKey(var)
    -- end
end

--------------------------------
-- @function [parent=#ViewBase] onCleanupCallback 
-- @param self 
function ViewBase:onCleanupCallback()
    printInfo("[ViewBase:onCleanupCallback]view = %s",self.name_)

    for key, var in pairs(self.models_) do
        if var.onCleanupCallback then
            var:onCleanupCallback()
    	end
    end
    
    self.schedule_:stopSchedule(self)

--    printInfo("[ViewBase:onCleanupCallback]begin = %s", textureCache:getCachedTextureInfo())

    local loading = self:getLoadingResource()
    if loading then
        for key, var in pairs(loading) do
            textureCache:unbindImageAsync(key)
            textureCache:removeTextureForKey(key)
        end
    end

    local preloading = self:getPreloadingResource()
    if preloading then
        self:searchPreloadingResource(preloading)
    end

--    printInfo("[ViewBase:onCleanupCallback]end = %s", textureCache:getCachedTextureInfo())

    self:clearLoadArmature()
    self:clearLoadImage()
end

--------------------------------
-- @function [parent=#ViewBase] clearLoadArmature 
-- @param self 
function ViewBase:clearLoadArmature()
    --自动unbind
    if self.loading_armature then
        local loader = self.app_:getModel("Loader")
        for k,v in pairs(self.loading_armature) do
            loader:unbindLoadArmature(v.path,v.name,v.callback)
        end
        self.loading_armature = nil
    end
end

--------------------------------
-- @function [parent=#ViewBase] loadArmature 
-- @param self 
function ViewBase:loadArmature(path,name,callback,param)
    local l ={}
    l.path = path
    l.name = name
    l.callback = callback
    l.param = param
    self.loading_armature = self.loading_armature or {}
    table.insert(self.loading_armature,l)
    local loader = self.app_:getModel("Loader")
    loader:loadArmature(path,name,callback,param)
end

--------------------------------
-- @function [parent=#ViewBase] clearLoadImage 
-- @param self 
function ViewBase:clearLoadImage()
    if self.loading_image then
        self.loading_armature = nil
        for key, var in pairs(self.loading_image) do
            textureCache:unbindImageAsync(var)
            textureCache:removeTextureForKey(var)
        end
    end
end

--------------------------------
-- @function [parent=#ViewBase] loadImage 
-- @param self 
function ViewBase:loadImage(path,callback)
    textureCache:unbindImageAsync(path)
    self.loading_image = self.loading_image or {}
    table.insert(self.loading_image,path);
    textureCache:addImageAsync(path, callback)
end

--------------------------------
-- @function [parent=#ViewBase] clearLoadNode
-- @param self 
function ViewBase:clearLoadNode()
    --自动unbind
    if self.loading_node then
        local loader = self.app_:getModel("Loader")
        for k,v in pairs(self.loading_node) do
            loader:unbindLoadNode(v.path,v.name,v.callback)
        end
        self.loading_node = nil
    end
end

--------------------------------
-- @function [parent=#ViewBase] loadNode 
-- @param self 
function ViewBase:loadNode(path,name,callback,param)
    local l ={}
    l.path = path
    l.name = name
    l.callback = callback
    l.param = param
    self.loading_node = self.loading_node or {}
    table.insert(self.loading_node,l)
    local loader = self.app_:getModel("Loader")
    loader:loadNode(path,name,callback,param)
end

--function ViewBase:showWithScene(transition, time, more)
--    self:setVisible(true)
--    local scene = display.newScene(self.name_)
--    scene:add(self)
--    display.runScene(scene, transition, time, more)
--    return self
--end


return ViewBase
