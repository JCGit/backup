
local ModelBase = class("ModelBase")

function ModelBase:ctor(app, name, ...)
    self.app_ = app
    self.name_ = name

    if self.onCreate then self:onCreate(...) end
end

function ModelBase:getApp()
    return self.app_
end

function ModelBase:getName()
    return self.name_
end

function ModelBase:getValue(key, default)
    return self[key] or default
end

function ModelBase:setValue(key, value)
    self[key] = value
end

function ModelBase:clear()
    self:onCreate()
end

function ModelBase:size()
    if self.isReadOnly then
        local metatable = getmetatable(self)
        return #(metatable.__index.class)
    else
        return #(self.class)
    end
end

function ModelBase:getSchedule(name)
    return self.app_:getModel("Schedule"):getSchedule(self, name)
end

function ModelBase:createSchedule(name, handler, interval, duration)
    return self.app_:getModel("Schedule"):addSchedule(self, name, handler, interval, duration)
end

function ModelBase:stopSchedule(name)
    self.app_:getModel("Schedule"):stopSchedule(self, name)
end

function ModelBase:iforeach(handler)
    local data
    if self.isReadOnly then
        local metatable = getmetatable(self)
        data = metatable.__index.class
    else
        data = self.class
    end
    
    for key, var in ipairs(data) do
    	handler(key, var)
    end
end

function ModelBase:foreach(handler)
    local data
    if self.isReadOnly then
        local metatable = getmetatable(self)
        data = metatable.__index.class
    else
        data = self.class
    end
    
    for key, var in pairs(data) do
    	handler(key, var)
    end
end

function ModelBase:readOnly(t)
    local proxy = {}
    local mt = {
        __index = t,
        __newindex = function (t,k,v)
            error("attempt to update a read-only table", 2)
        end
    }

    t.isReadOnly = true
    setmetatable(proxy, mt)
    return proxy
end

function ModelBase:extend(app, target, location, writable)
    local model, name

    if location then
        name = location:format(target)
    else
        name = "app.data." .. target
    end
    model = require(name)
    
    if type(model) ~= "table" and _G[target] then
    	model = _G[target]
        _G[target] = nil
        
        package.loaded[name] = model
    end
    
    if type(model) == "table" then
        local temp = extend(model,ModelBase):create(app, target)
        if not writable then
            return self:readOnly(temp)
        else
            return temp
        end
    end
end


function ModelBase:onCleanupCallback()
    if self.onCleanup then
        self:onCleanup()
    end

    self:unregisterProtocol()

    self.app_:getModel("Schedule"):stopSchedule(self)
end

return ModelBase
