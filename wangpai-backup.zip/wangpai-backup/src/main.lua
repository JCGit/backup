
-- cc.FileUtils:getInstance():setPopupNotify(false)
--cc.FileUtils:getInstance():addSearchPath("src/app")
--cc.FileUtils:getInstance():addSearchPath("src/app/views")
--cc.FileUtils:getInstance():addSearchPath("src/app/models")
--cc.FileUtils:getInstance():addSearchPath("src/app/message")
--cc.FileUtils:getInstance():addSearchPath("src/app/protobuf")
--cc.FileUtils:getInstance():addSearchPath("src/app/protocol")

cc.FileUtils:getInstance():addSearchPath("src/")
cc.FileUtils:getInstance():addSearchPath("res/")

require "config"
require "cocos.init" 
require "cocos.extension.ExtensionConstants"
require("app.models.UserCache")
require("app.data.DataStructures")
require("app.models.LuaTools")
require("app.models.Constants")

require("app.network.TCPManager")
require("app.network.TCPGearbox") 
require("app.models.cardutl")
require("app.models.Sound")
require("app.models.Blur")
print(G_SIGN_WN)
G_BASEAPP = nil
G_ROOTSCENE = nil
G_TXLOGININFO = {}--腾讯登录信息
G_UPDATEINFO = {}--更新数据
G_UPDATEINFOS = {} 
ISDEBUG = true
ISINIT = false--启动游戏标示
ISINITTIP = false--启动游戏标示
if not ISDEBUG then
    function print( ... )
    end
    function printf( ... )
    end
    function dump( ... )
    end
end

local function main() 

    display.setAutoScale({width = 1280,height=720,autoscale='EXACT_FIT'})
    G_CHANNELID = LuaTools.getChannelID()
	
	local CommonConfig = require("app.data.CommonConfig")
	local temp = CommonConfig[G_CHANNELID];
    if  temp and  _G.next(temp) ~= nil then 
    	for key, value in pairs(temp) do      
    		if temp[key] ~= nil then
    			G_CHANNEL_CONFIG[key] = temp[key];
    		end
    	end  
    end     
	
    local director = cc.Director:getInstance()
    local function start()

        -- director:setAnimationInterval(1.0 / 40) -- lock to 40 fps.
         local app = require("app.MyApp"):create()
         G_ROOTSCENE = display.newScene('UIDummyScene')
         display.runScene(G_ROOTSCENE)
    
		if ISINIT == false then ISINIT = true end
         --printWarning
         LuaTools.bindBackCallback(G_ROOTSCENE,app) 

         G_BASEAPP = app
         TCPGearbox.setup()
         
         local load = app:addView("UILoading")  
         load:setLoadingType( false )
         G_LOADINGVIEW = load 
	   load:setNextAction(function()
             printf('load:setNextAction')
             app:addView("UILogin") 
             local b = app:addView("UIDialog",-100000)  
             b:createSchedule("preload",function()
                 b:removeSelf()
             end,0.1)
	   end)
	   load:startProgress() 
    end

    local scheduler = require("app.models.QScheduler")

    local splash = display.newScene('Splash Scene')
    display.runScene(splash)
	
	local function splashUI()
		local splashSprite = cc.Sprite:create('res/background/splash.png')
		splash:addChild(splashSprite)
		splashSprite:setAnchorPoint(cc.p(0,0))
	end
	
	if G_CHANNELID == "xyy_xmly_wpddz" then
		local splashSprite = cc.Sprite:create('res/background/splash_xmly.png')
		splash:addChild(splashSprite)
		splashSprite:setAnchorPoint(cc.p(0,0))
		scheduler.performWithDelayGlobal(splashUI,2)
		
	else
		splashUI()
	end
	
    
    if (cc.PLATFORM_OS_WINDOWS == cc.Application:getInstance():getTargetPlatform()) then 
        start()
    else 
		if G_CHANNELID == "xyy_xmly_wpddz" then
			scheduler.performWithDelayGlobal(start,4)
		else
			scheduler.performWithDelayGlobal(start,2)
		end
         
		--华为初始化获取key
		--[[if G_CHANNELID == 'hyl_hw_01' then
			local myArgs = {
				  fast = 0,
				  unionid =G_CHANNELID
				  --did = self.pData.did
				}--借口数据
				  
			local ThirdSDKHandler = require('app.network.ThirdSDKHandler')
            ThirdSDKHandler.doSDKInit(function() 
				--初始化成功 
				scheduler.performWithDelayGlobal(start,2)
			end, function() print('onPendingCallback') end, function() 
				--初始化失败
				
			end, myArgs)
			
		else
			scheduler.performWithDelayGlobal(start,2)
		end
		]]
    end
    
	







        -- local modTbl = 
        -- {
        --     0,
        --     1,
        --     0,
        --     1,
        --     1,
        --     3,
        --     0,
        --     1,
        --     0
        -- }

        -- local out = {}
        -- for i=1,100000000 do
        --     local found = true
        --     for j=1,#modTbl do
        --         if i % j ~= modTbl[j] then 
        --             found = false
        --             break
        --         end
        --     end 
        --     if found == true then 
        --         table.insert(out,i)
        --         printf(i)
        --     end
        -- end
        -- dump(out,'out')
        -- for i=-1000,1000 do
        --     print(LuaTools.convertAmountChinese(i*10))
        -- end
        -- local

    -- local displayIDTable = 
    -- {
    --     true,
    --     false,
    --     false,
    --     false,
    --     false
    -- }
    -- local mySeatID = 4
    -- local function insertPlayerToDisplayTable(data)
    --     local idx =   ( data.seatID  - mySeatID   ) + 1
    --     if idx <= 0 then 
    --         idx = #displayIDTable + idx
    --     end
    --     data.idx =  idx--#displayIDTable - (idx % #displayIDTable)
    --     if data.seatID == mySeatID then 
    --         displayIDTable[1] = true
    --         data.displayID = 1  
    --         data.I_am_Self = true;
    --         return 1 
    --     end  
    --     -- local 
    --     -- for i=1,#displayIDTable do 
    --     --     local idx  = i
    --     --     if data.seatID < mySeatID then 
    --     --         idx =  #displayIDTable - i + 1 
    --     --         printf('idx:%s',idx)
    --     --     end
    --         local v = displayIDTable[idx] 
    --         if v == false then 
    --             displayIDTable[idx] = true
    --             data.displayID = idx  
    --             return idx
    --         end
    --     -- end 
    --     -- if 
    -- end


-- 0 1 2 3 4 5
-- 
        -- if seatID


        -- local playerTable = 
        -- {
        --     {
        --         seatID = 0
        --     },
        --     {
        --         seatID = 1,  
        --     },
        --     {
        --         seatID = 2
        --     },
        --     {
        --         seatID = 3
        --     },
        --     {
        --         seatID = 4
        --     },
        -- }    
        -- for k,v in pairs(playerTable) do 
        --     insertPlayerToDisplayTable(playerTable[k])
        -- end
        -- dump(playerTable)



 --  cardsReadyToSend  = {
 --     [1]  =  0x50,
 --     [2]  =  0x2D,
 --     [3]  =  0x1D,
 --     [4]  =  0x3D,
 --     [5]  =  0x4E,
 --     [6]  =  0x1E,
 --     [7]  =  0x3A,
 --     [8]  =  0x2A, 
 -- } 

-- local cardValid,cardType = Cardutl.checkCardOut(cardsReadyToSend , lastPlayedCards ) 
-- printf('cardValid:%s,cardType:%s',cardValid,cardType)

 getAllHandCardsValues = { 
 80,
62,
45,
29,
28,
59,
74,
58,
42,
57,
41,
72,
40,
22,
53,
35,
19,
     -- [6 ] = 0x17,
    -- [7 ] = 0x17,
    -- [8 ] = 0x17,
    -- [9 ] = 0x17,
    -- [10] = 0x16,
    -- [11] = 0x16,
    -- [12] = 0x16,
    -- [13] = 0x16,
    -- [14] = 0x15,
    -- [15] = 0x15,
    -- [16] = 0x15,
    -- [17] = 0x15,
    -- [18] = 0x14,
    -- [19] = 0x14,
    -- [20] = 0x14,
}  

lastPlayedCards  = {
 26,
25,
56,
23,
54,
 }

lastPlayedCardsType = "TYPE_STRAIGHT"


    printf('=============== BEGIN OF SHOW HINT LOGICS ==========')

    local hint = CardHints.new({
        lastPlayedCardsType = lastPlayedCardsType  ,
        lastPlayedCardValues = lastPlayedCards ,
        hasSwt = false,
        handCardTable = getAllHandCardsValues
        })
    hint:tip(false) 
    hint:getBigger(false) 

    printf('=============== END OF SHOW HINT LOGICS ==========')



        -- print(Cardutl.getPathForCard( 0x11 , nil,nil,"Douniu"))

-- getAllHandCardsValues = {
--     [1] = 0x15,
--     [2] = 0x25,
--     [3] = 0x35,
--     [4] = 0x46,
--     [5] = 0x26,
--     [6] = 0x36,
--     [7] = 0x47,
--     [8] = 0x27,
--     [9] = 0x37,
--     -- [3] = 0x47,
--     -- [4] = 0x36,
--     -- [5] = 0x45,
--     -- [6] = 0x34,
--     -- [7] = 0x43, 
-- }

-- lastPlayedCards = {
--     [1] = 0x23, 
--     [2] = 0x33, 
--     [3] = 0x43,  
--     [4] = 0x34, 
--     [5] = 0x14, 
--     [6] = 0x44,   
-- }
-- lastPlayedCardsType = 'TYPE_PLANE_0'

--     dump(lastPlayedCardsType,"lastPlayedCardsType")
--     Cardutl.dumpCardValues(lastPlayedCards,"lastPlayedCards")
--     Cardutl.dumpCardValues(getAllHandCardsValues,"getAllHandCardsValues")
--     local hint = CardHints.new({
--         lastPlayedCardType = lastPlayedCardsType  ,
--         lastPlayedCardValues = lastPlayedCards ,
--         hasSwt = false,
--         handCardTable = getAllHandCardsValues
--         })
--     dump(hint,"hint")
--     hint:getBigger(false) 
--     for k,v in pairs(hint.bigger) do
--         Cardutl.dumpCardValues(v,"hint.bigger_"..k) 
--     end

    for k,v in pairs(package.loaded) do
        printf('LOADED MODOULE:%s',k)
    end
    print("==>>config required.G_VERSION:",G_VERSION)
   
end

local status, msg = xpcall(main, __G__TRACKBACK__)

if not status then
    print(msg)
end